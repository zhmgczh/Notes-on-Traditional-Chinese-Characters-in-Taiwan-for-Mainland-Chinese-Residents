<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Spreadsheet Live Editor — row loading, edits overlay, finalize to _edited file.
 */
class SpreadsheetEditorService {

	private static $instance = null;

	const MAX_PER_PAGE     = 500;
	const DEFAULT_PER_PAGE = 100;
	const MAX_EDITS_BATCH  = 500;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_editor_overrides';
	}

	public function is_enabled() {
		return (bool) apply_filters( 'uci_enable_spreadsheet_editor', true );
	}

	public function is_supported_hash( $hash_key ) {
		global $wpdb;
		$hash_key = sanitize_key( $hash_key );
		if ( empty( $hash_key ) ) {
			return false;
		}
		$table = $wpdb->prefix . 'smackcsv_file_events';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT file_name FROM {$table} WHERE hash_key = %s LIMIT 1", $hash_key )
		);
		if ( ! $row || empty( $row->file_name ) ) {
			return false;
		}
		$ext = strtolower( pathinfo( $row->file_name, PATHINFO_EXTENSION ) );
		if ( empty( $ext ) ) {
			return false;
		}
		if ( $ext === 'xml' ) {
			return false;
		}
		return in_array( $ext, array( 'csv', 'txt', 'tsv', 'xls', 'xlsx', 'json' ), true );
	}

	/**
	 * Import pipeline reads this path (edited file when finalized).
	 */
	public function resolve_import_file_path( $hash_key, $upload_dir = null ) {
		return ImportFileResolver::getInstance()->resolve_import_file_path( $hash_key, $upload_dir );
	}

	public function get_meta( $hash_key ) {
		$hash_key = sanitize_key( $hash_key );
		$this->assert_hash( $hash_key );

		$columns     = $this->get_mapped_columns( $hash_key );
		$total_rows  = $this->get_total_data_rows( $hash_key );
		$has_edits   = $this->count_overrides( $hash_key ) > 0;
		$is_active   = (bool) get_option( 'sm_uci_editor_active_' . $hash_key );
		$import_type = $this->get_import_module( $hash_key );

		return array(
			'success'      => true,
			'hash_key'     => $hash_key,
			'columns'      => $columns,
			'total_rows'   => $total_rows,
			'has_edits'    => $has_edits,
			'is_finalized' => $is_active,
			'import_type'  => $import_type,
			'per_page'     => self::DEFAULT_PER_PAGE,
		);
	}

	/**
	 * Paginated mapped rows for the grid.
	 */
	public function get_rows( $hash_key, $args = array() ) {
		$hash_key = sanitize_key( $hash_key );
		$this->assert_hash( $hash_key );

		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$per_page = max( 1, min( self::MAX_PER_PAGE, (int) ( $args['per_page'] ?? self::DEFAULT_PER_PAGE ) ) );
		$search   = isset( $args['search'] ) ? sanitize_text_field( $args['search'] ) : '';
		$scope    = isset( $args['search_scope'] ) ? sanitize_text_field( $args['search_scope'] ) : 'all';
		$search_col = isset( $args['search_col'] ) ? (int) $args['search_col'] : -1;
		$mode     = isset( $args['search_mode'] ) ? sanitize_text_field( $args['search_mode'] ) : 'partial';
		$filter   = isset( $args['filter'] ) ? sanitize_text_field( $args['filter'] ) : '';
		$filter_col = isset( $args['filter_column'] ) ? (int) $args['filter_column'] : -1;
		$filter_val = isset( $args['filter_value'] ) ? sanitize_text_field( $args['filter_value'] ) : '';

		$columns    = $this->get_mapped_columns( $hash_key );
		$file_path  = $this->resolve_import_file_path( $hash_key );
		$import_type = $this->get_import_module( $hash_key );

		if ( $filter !== '' || $search !== '' ) {
			return $this->get_rows_filtered( $hash_key, $file_path, $columns, $import_type, $page, $per_page, $search, $scope, $search_col, $mode, $filter, $filter_col, $filter_val );
		}

		$offset_line = 1 + ( ( $page - 1 ) * $per_page );
		$raw         = $this->parse_file_chunk( $file_path, $offset_line, $per_page );
		$headers     = $raw['headers'];
		$overrides   = $this->get_overrides_for_rows( $hash_key, $this->line_numbers_for_chunk( $offset_line, count( $raw['rows'] ) ) );

		$rows_out = array();
		$total_errors = 0;
		$total_warnings = 0;
		$line = $offset_line;
		foreach ( $raw['rows'] as $parser_key => $row_values ) {
			if ( is_numeric( $parser_key ) ) {
				$line = (int) $parser_key;
			}
			$cells = $this->build_cell_map( $headers, $row_values, $columns, $hash_key, $line, $overrides );
			$validation = SpreadsheetValidator::getInstance()->validate_row_cells( $cells, $columns, $import_type );
			$total_errors += $validation['errors'];
			$total_warnings += $validation['warnings'];
			$rows_out[] = array(
				'row_number' => $line,
				'cells'      => $cells,
				'validation' => $validation['cells'],
				'error_count' => $validation['errors'],
				'warning_count' => $validation['warnings'],
			);
			++$line;
		}

		$total_rows = $this->get_total_data_rows( $hash_key );

		return array(
			'success'        => true,
			'rows'           => $rows_out,
			'page'           => $page,
			'per_page'       => $per_page,
			'total_rows'     => $total_rows,
			'total_pages'    => (int) ceil( $total_rows / $per_page ),
			'error_count'    => $total_errors,
			'warning_count'  => $total_warnings,
		);
	}

	public function ensure_editor_table_exists() {
		global $wpdb;
		$table = self::table_name();
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $found === $table ) {
			return true;
		}
		if ( class_exists( 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\Tables' ) ) {
			Tables::getInstance()->create_tables();
		}
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		return ( $found === $table );
	}

	public function save_edits( $hash_key, $edits ) {
		$hash_key = sanitize_key( $hash_key );
		$this->assert_hash( $hash_key );

		if ( ! $this->ensure_editor_table_exists() ) {
			return array(
				'success' => false,
				'message' => __( 'Spreadsheet editor database table is missing. Deactivate and reactivate the plugin, then try again.', 'wp-ultimate-csv-importer' ),
			);
		}

		if ( ! is_array( $edits ) || empty( $edits ) ) {
			return array( 'success' => true, 'updated' => 0 );
		}

		$edits = array_slice( $edits, 0, self::MAX_EDITS_BATCH );
		global $wpdb;
		$table   = self::table_name();
		$updated = 0;
		$now     = current_time( 'mysql' );
		$skipped = 0;

		foreach ( $edits as $edit ) {
			if ( ! is_array( $edit ) ) {
				continue;
			}
			$row_number = isset( $edit['row_number'] ) ? (int) $edit['row_number'] : 0;
			$col_index  = isset( $edit['col_index'] ) ? (int) $edit['col_index'] : -1;
			$value      = isset( $edit['value'] ) ? $edit['value'] : '';
			$header     = isset( $edit['col_header'] ) ? sanitize_text_field( $edit['col_header'] ) : '';

			if ( $row_number < 1 || $col_index < 0 ) {
				++$skipped;
				continue;
			}

			$value = $this->sanitize_cell_value( $value );
			$value = $this->escape_csv_injection( $value );

			$result = $wpdb->replace(
				$table,
				array(
					'hash_key'   => $hash_key,
					'row_number' => $row_number,
					'col_index'  => $col_index,
					'col_header' => $header,
					'cell_value' => $value,
					'updated_at' => $now,
				),
				array( '%s', '%d', '%d', '%s', '%s', '%s' )
			);
			if ( false === $result ) {
				return array(
					'success' => false,
					'message' => __( 'Failed to save spreadsheet edits. Please reload the page and try again.', 'wp-ultimate-csv-importer' ),
				);
			}
			++$updated;
		}

		return array(
			'success' => true,
			'updated' => $updated,
		);
	}

	/**
	 * Apply stored cell overrides onto parsed import rows (source of truth at import time).
	 *
	 * @param string $hash_key       Import session.
	 * @param array  $header_array   CSV headers from parser.
	 * @param array  $all_value_array Numeric list of row value arrays.
	 * @param int    $start_row_number 1-based data row number for first row in chunk.
	 * @return array
	 */
	public function merge_overrides_into_value_rows( $hash_key, $header_array, $all_value_array, $start_row_number ) {
		$override_total = $this->count_overrides( $hash_key );
		if ( empty( $all_value_array ) || $override_total === 0 ) {
			return $all_value_array;
		}

		$header_array = $this->normalize_header_array( $header_array );
		$columns      = $this->get_mapped_columns( $hash_key );
		$row_count    = count( $all_value_array );
		$row_nums     = range( (int) $start_row_number, (int) $start_row_number + $row_count - 1 );
		$overrides = $this->get_overrides_for_rows( $hash_key, $row_nums );

		if ( empty( $overrides ) ) {
			return $all_value_array;
		}

		$row_offset   = 0;
		$merged_rows  = array();

		foreach ( $all_value_array as $parser_key => $row_values ) {
			if ( ! is_array( $row_values ) ) {
				++$row_offset;
				continue;
			}
			// Parser keys are 1-based file line numbers (see SmackCSVParser::_parseCSV).
			if ( is_numeric( $parser_key ) ) {
				$rn = (int) $parser_key;
			} else {
				$rn = (int) $start_row_number + $row_offset;
			}
			if ( ! isset( $overrides[ $rn ] ) ) {
				$merged_rows[ $parser_key ] = $row_values;
				++$row_offset;
				continue;
			}
			foreach ( $columns as $col ) {
				$ci = (int) $col['col_index'];
				if ( ! isset( $overrides[ $rn ][ $ci ] ) ) {
					continue;
				}
				$header_idx = $this->find_header_index( $col['csv_header'], $header_array );
				if ( false === $header_idx ) {
					continue;
				}
				while ( count( $row_values ) <= $header_idx ) {
					$row_values[] = '';
				}
				$row_values[ $header_idx ] = $overrides[ $rn ][ $ci ];
			}
			$merged_rows[ $parser_key ] = $row_values;
			++$row_offset;
		}

		return $merged_rows;
	}

	/**
	 * Ensure overrides are materialized before import when user skipped finalize.
	 */
	public function ensure_import_ready( $hash_key ) {
		$hash_key = sanitize_key( $hash_key );
		$count    = $this->count_overrides( $hash_key );
		if ( $count === 0 ) {
			return;
		}
		$edited_path = $this->resolve_import_file_path( $hash_key );
		if ( get_option( 'sm_uci_editor_active_' . $hash_key ) && file_exists( $edited_path ) && strpos( $edited_path, '_edited' ) !== false ) {
			return;
		}
		$this->finalize( $hash_key );
	}

	public function validate_rows_request( $hash_key, $rows_payload ) {
		$hash_key    = sanitize_key( $hash_key );
		$columns     = $this->get_mapped_columns( $hash_key );
		$import_type = $this->get_import_module( $hash_key );
		$out         = array();
		$errors      = 0;
		$warnings    = 0;

		if ( ! is_array( $rows_payload ) ) {
			return array( 'success' => true, 'rows' => array(), 'error_count' => 0, 'warning_count' => 0 );
		}

		foreach ( $rows_payload as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row_number = (int) ( $row['row_number'] ?? 0 );
			$cells      = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			$validation = SpreadsheetValidator::getInstance()->validate_row_cells( $cells, $columns, $import_type );
			$errors    += $validation['errors'];
			$warnings  += $validation['warnings'];
			$out[] = array(
				'row_number'    => $row_number,
				'validation'    => $validation['cells'],
				'error_count'   => $validation['errors'],
				'warning_count' => $validation['warnings'],
			);
		}

		return array(
			'success'       => true,
			'rows'          => $out,
			'error_count'   => $errors,
			'warning_count' => $warnings,
		);
	}

	/**
	 * Materialize overlay into {hash}_edited and mark active for import.
	 */
	public function finalize( $hash_key ) {
		$hash_key = sanitize_key( $hash_key );
		$this->assert_hash( $hash_key );

		$upload_dir = UltimatePro::getInstance()->create_upload_dir();
		$original   = $upload_dir . $hash_key . '/' . $hash_key;
		$edited     = $upload_dir . $hash_key . '/' . $hash_key . '_edited';

		if ( ! file_exists( $original ) ) {
			return array( 'success' => false, 'message' => __( 'Import file not found.', 'wp-ultimate-csv-importer' ) );
		}

		$override_count = $this->count_overrides( $hash_key );
		if ( $override_count === 0 ) {
			delete_option( 'sm_uci_editor_active_' . $hash_key );
			if ( file_exists( $edited ) ) {
				wp_delete_file( $edited );
			}
			return array( 'success' => true, 'finalized' => false, 'message' => __( 'No edits to apply.', 'wp-ultimate-csv-importer' ) );
		}

		$all_overrides = $this->get_all_overrides_indexed( $hash_key );
		$validate_file = ValidateFile::getInstance();
		$delimiter     = $validate_file->getFileDelimiter( $original, 5 );
		if ( $delimiter === '\t' ) {
			$delimiter = "\t";
		}

		$in  = fopen( $original, 'r' );
		$out = fopen( $edited, 'w' );
		if ( ! $in || ! $out ) {
			if ( $in ) {
				fclose( $in );
			}
			if ( $out ) {
				fclose( $out );
			}
			return array( 'success' => false, 'message' => __( 'Could not open import file for finalize.', 'wp-ultimate-csv-importer' ) );
		}

		$headers = fgetcsv( $in, 0, $delimiter, '"', '\\' );
		if ( ! $headers ) {
			fclose( $in );
			fclose( $out );
			return array( 'success' => false, 'message' => __( 'Empty or invalid CSV header.', 'wp-ultimate-csv-importer' ) );
		}
		$headers = array_map( 'trim', $headers );
		fputcsv( $out, $headers, $delimiter, '"', '\\' );

		$columns   = $this->get_mapped_columns( $hash_key );
		$file_line = 0;
		while ( ( $data = fgetcsv( $in, 0, $delimiter, '"', '\\' ) ) !== false ) {
			++$file_line;
			$data = array_map( 'trim', $data );
			// Match SmackCSVParser: only numbered rows with a non-empty first column are imported.
			if ( empty( $data[0] ) ) {
				fputcsv( $out, $data, $delimiter, '"', '\\' );
				continue;
			}
			if ( isset( $all_overrides[ $file_line ] ) ) {
				$data = $this->apply_overrides_to_raw_row( $data, $headers, $columns, $all_overrides[ $file_line ] );
			}
			fputcsv( $out, $data, $delimiter, '"', '\\' );
		}

		fclose( $in );
		fclose( $out );

		update_option( 'sm_uci_editor_active_' . $hash_key, 1, false );

		return array(
			'success'   => true,
			'finalized' => true,
			'applied'   => $override_count,
		);
	}

	public function discard_edits( $hash_key ) {
		$hash_key = sanitize_key( $hash_key );
		$this->cleanup( $hash_key );
		return array( 'success' => true );
	}

	public function cleanup( $hash_key ) {
		global $wpdb;
		$hash_key = sanitize_key( $hash_key );
		$wpdb->delete( self::table_name(), array( 'hash_key' => $hash_key ), array( '%s' ) );
		delete_option( 'sm_uci_editor_active_' . $hash_key );
		$upload_dir = UltimatePro::getInstance()->create_upload_dir();
		$edited     = $upload_dir . $hash_key . '/' . $hash_key . '_edited';
		if ( file_exists( $edited ) ) {
			wp_delete_file( $edited );
		}
	}

	/* --------------------------------------------------------------------- */

	private function assert_hash( $hash_key ) {
		if ( ! $this->is_supported_hash( $hash_key ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Spreadsheet editor is not available for this file type.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	private function get_import_module( $hash_key ) {
		return $this->get_import_module_public( $hash_key );
	}

	/**
	 * Import module for a session (public API for Import Preview).
	 *
	 * @param string $hash_key Session hash key.
	 * @return string
	 */
	public function get_import_module_public( $hash_key ) {
		global $wpdb;
		$hash_key = sanitize_key( $hash_key );
		$t        = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$m        = $wpdb->get_var( $wpdb->prepare( "SELECT module FROM {$t} WHERE eventKey = %s ORDER BY id DESC LIMIT 1", $hash_key ) );
		return $m ? $m : 'Posts';
	}

	/**
	 * Stored mapping template for a session (public API for Import Preview).
	 *
	 * @param string $hash_key Session hash key.
	 * @return array<string, mixed>
	 */
	public function get_stored_mapping( $hash_key ) {
		return $this->get_mapping_array( sanitize_key( $hash_key ) );
	}

	/**
	 * Total data rows in import file (public API for Import Preview).
	 *
	 * @param string $hash_key Session hash key.
	 * @return int
	 */
	public function get_total_data_rows_public( $hash_key ) {
		return $this->get_total_data_rows( sanitize_key( $hash_key ) );
	}

	private function get_mapping_array( $hash_key ) {
		global $wpdb;
		$t = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$mapping = $wpdb->get_var( $wpdb->prepare( "SELECT mapping FROM {$t} WHERE eventKey = %s ORDER BY id DESC LIMIT 1", $hash_key ) );
		$map = $mapping ? @unserialize( $mapping ) : array();
		return is_array( $map ) ? $map : array();
	}

	public function get_mapped_columns( $hash_key ) {
		$map     = $this->get_mapping_array( $hash_key );
		$columns = array();
		$idx     = 0;
		foreach ( $map as $group_fields ) {
			if ( ! is_array( $group_fields ) ) {
				continue;
			}
			foreach ( $group_fields as $wp_field => $csv_header ) {
				if ( empty( $wp_field ) || $wp_field === 'AI_CONFIDENCE_SCORES' ) {
					continue;
				}
				if ( strpos( (string) $wp_field, '->' ) !== false ) {
					continue;
				}
				$header = is_string( $csv_header ) ? trim( $csv_header ) : '';
				if ( $header === '' || strtolower( $header ) === 'array' ) {
					continue;
				}
				$columns[] = array(
					'col_index'   => $idx,
					'csv_header'  => $header,
					'wp_field'    => $wp_field,
					'label'       => $wp_field,
				);
				++$idx;
			}
		}
		return $columns;
	}

	private function get_total_data_rows( $hash_key ) {
		global $wpdb;
		$table = $wpdb->prefix . 'smackcsv_file_events';
		$total = $wpdb->get_var( $wpdb->prepare( "SELECT total_rows FROM {$table} WHERE hash_key = %s", $hash_key ) );
		return max( 0, (int) $total );
	}

	private function count_overrides( $hash_key ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table_name() . ' WHERE hash_key = %s', $hash_key )
		);
	}

	private function parse_file_chunk( $file_path, $offset_line, $limit ) {
		$parser = new SmackCSVParser();
		$res    = $parser->parseCSV( $file_path, $offset_line, $limit );
		if ( ! is_array( $res ) ) {
			return array( 'headers' => array(), 'rows' => array() );
		}
		$headers = ! empty( $res['headers'][0] ) ? array_map( 'trim', (array) $res['headers'][0] ) : array();
		$rows    = isset( $res['values'] ) && is_array( $res['values'] ) ? $res['values'] : array();
		return array( 'headers' => $headers, 'rows' => $rows );
	}

	private function line_numbers_for_chunk( $start, $count ) {
		$nums = array();
		for ( $i = 0; $i < $count; $i++ ) {
			$nums[] = $start + $i;
		}
		return $nums;
	}

	private function get_overrides_for_rows( $hash_key, $row_numbers ) {
		global $wpdb;
		if ( empty( $row_numbers ) ) {
			return array();
		}
		$table   = self::table_name();
		$ids     = array_map( 'intval', $row_numbers );
		$in_list = implode( ',', $ids );
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT `row_number`, col_index, cell_value FROM {$table} WHERE hash_key = %s AND `row_number` IN ({$in_list})",
				$hash_key
			),
			ARRAY_A
		);
		$out  = array();
		foreach ( $rows as $r ) {
			$rn = (int) $r['row_number'];
			$ci = (int) $r['col_index'];
			if ( ! isset( $out[ $rn ] ) ) {
				$out[ $rn ] = array();
			}
			$out[ $rn ][ $ci ] = $r['cell_value'];
		}
		return $out;
	}

	private function get_all_overrides_indexed( $hash_key ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT `row_number`, col_index, cell_value, col_header FROM ' . self::table_name() . ' WHERE hash_key = %s',
				$hash_key
			),
			ARRAY_A
		);
		$out = array();
		foreach ( $rows as $r ) {
			$rn = (int) $r['row_number'];
			$ci = (int) $r['col_index'];
			if ( ! isset( $out[ $rn ] ) ) {
				$out[ $rn ] = array();
			}
			$out[ $rn ][ $ci ] = array(
				'value'  => $r['cell_value'],
				'header' => $r['col_header'],
			);
		}
		return $out;
	}

	private function normalize_header_array( $header_array ) {
		if ( ! is_array( $header_array ) ) {
			return array();
		}
		$out = array();
		foreach ( $header_array as $h ) {
			$out[] = $this->normalize_header_string( $h );
		}
		return $out;
	}

	private function normalize_header_string( $header ) {
		$header = is_string( $header ) ? $header : (string) $header;
		$header = preg_replace( '/^\xEF\xBB\xBF/', '', $header );
		return trim( $header );
	}

	/**
	 * @return int|false Numeric column index in file header row.
	 */
	private function find_header_index( $csv_header, $header_array ) {
		$csv_header = $this->normalize_header_string( $csv_header );
		$idx        = array_search( $csv_header, $header_array, true );
		if ( false !== $idx ) {
			return (int) $idx;
		}
		$csv_lower = strtolower( $csv_header );
		foreach ( $header_array as $i => $h ) {
			$norm = $this->normalize_header_string( $h );
			if ( $norm === $csv_header || strtolower( $norm ) === $csv_lower ) {
				return (int) $i;
			}
		}
		return false;
	}

	private function build_cell_map( $file_headers, $row_values, $columns, $hash_key, $row_number, $overrides ) {
		$file_headers = $this->normalize_header_array( $file_headers );
		$cells        = array();
		$row_over     = isset( $overrides[ $row_number ] ) ? $overrides[ $row_number ] : array();
		foreach ( $columns as $col ) {
			$ci     = (int) $col['col_index'];
			$header = $col['csv_header'];
			$val    = '';
			if ( isset( $row_over[ $ci ] ) ) {
				$val = $row_over[ $ci ];
			} else {
				$file_idx = $this->find_header_index( $header, $file_headers );
				if ( false !== $file_idx && isset( $row_values[ $file_idx ] ) ) {
					$val = $row_values[ $file_idx ];
				}
			}
			$cells[ $ci ] = is_string( $val ) ? $val : (string) $val;
		}
		return $cells;
	}

	private function apply_overrides_to_raw_row( $data, $headers, $columns, $row_overrides ) {
		$headers = $this->normalize_header_array( $headers );
		foreach ( $columns as $col ) {
			$ci = (int) $col['col_index'];
			if ( ! isset( $row_overrides[ $ci ] ) ) {
				continue;
			}
			$val    = is_array( $row_overrides[ $ci ] ) ? $row_overrides[ $ci ]['value'] : $row_overrides[ $ci ];
			$idx    = $this->find_header_index( $col['csv_header'], $headers );
			if ( false !== $idx ) {
				while ( count( $data ) <= $idx ) {
					$data[] = '';
				}
				$data[ $idx ] = $val;
			}
		}
		return $data;
	}

	private function get_rows_filtered( $hash_key, $file_path, $columns, $import_type, $page, $per_page, $search, $scope, $search_col, $mode, $filter, $filter_col, $filter_val ) {
		$matched = array();
		$scan    = 500;
		$offset  = 1;
		$total   = $this->get_total_data_rows( $hash_key );
		$headers_cache = null;
		$dup_counts  = array();
		if ( $filter === 'duplicates' && $filter_col >= 0 ) {
			$dup_counts = $this->count_column_values( $hash_key, $file_path, $columns, $filter_col );
		}

		while ( $offset <= $total ) {
			$raw = $this->parse_file_chunk( $file_path, $offset, $scan );
			if ( empty( $raw['rows'] ) ) {
				break;
			}
			if ( null === $headers_cache ) {
				$headers_cache = $raw['headers'];
			}
			$overrides = $this->get_overrides_for_rows( $hash_key, $this->line_numbers_for_chunk( $offset, count( $raw['rows'] ) ) );
			$line      = $offset;
			foreach ( $raw['rows'] as $parser_key => $row_values ) {
				if ( is_numeric( $parser_key ) ) {
					$line = (int) $parser_key;
				}
				$cells = $this->build_cell_map( $headers_cache, $row_values, $columns, $hash_key, $line, $overrides );
				if ( $this->row_matches_filter( $cells, $columns, $import_type, $search, $scope, $search_col, $mode, $filter, $filter_col, $filter_val, $dup_counts ) ) {
					$validation = SpreadsheetValidator::getInstance()->validate_row_cells( $cells, $columns, $import_type );
					$matched[] = array(
						'row_number'    => $line,
						'cells'         => $cells,
						'validation'    => $validation['cells'],
						'error_count'   => $validation['errors'],
						'warning_count' => $validation['warnings'],
					);
				}
				++$line;
			}
			$offset += $scan;
		}

		$total_matched = count( $matched );
		$slice_start   = ( $page - 1 ) * $per_page;
		$page_rows     = array_slice( $matched, $slice_start, $per_page );
		$err = 0;
		$warn = 0;
		foreach ( $page_rows as $r ) {
			$err += $r['error_count'];
			$warn += $r['warning_count'];
		}

		return array(
			'success'       => true,
			'rows'          => $page_rows,
			'page'          => $page,
			'per_page'      => $per_page,
			'total_rows'    => $total_matched,
			'total_pages'   => max( 1, (int) ceil( $total_matched / $per_page ) ),
			'filtered'      => true,
			'error_count'   => $err,
			'warning_count' => $warn,
		);
	}

	private function count_column_values( $hash_key, $file_path, $columns, $filter_col ) {
		$counts = array();
		$total  = $this->get_total_data_rows( $hash_key );
		$offset = 1;
		$scan   = 1000;
		$headers_cache = null;
		while ( $offset <= $total ) {
			$raw = $this->parse_file_chunk( $file_path, $offset, $scan );
			if ( empty( $raw['rows'] ) ) {
				break;
			}
			if ( null === $headers_cache ) {
				$headers_cache = $raw['headers'];
			}
			$overrides = $this->get_overrides_for_rows( $hash_key, $this->line_numbers_for_chunk( $offset, count( $raw['rows'] ) ) );
			$line = $offset;
			foreach ( $raw['rows'] as $row_values ) {
				$cells = $this->build_cell_map( $headers_cache, $row_values, $columns, $hash_key, $line, $overrides );
				$val = isset( $cells[ $filter_col ] ) ? trim( strtolower( (string) $cells[ $filter_col ] ) ) : '';
				if ( $val !== '' ) {
					if ( ! isset( $counts[ $val ] ) ) {
						$counts[ $val ] = 0;
					}
					++$counts[ $val ];
				}
				++$line;
			}
			$offset += $scan;
		}
		return $counts;
	}

	private function row_matches_filter( $cells, $columns, $import_type, $search, $scope, $search_col, $mode, $filter, $filter_col, $filter_val, $dup_counts = array() ) {
		if ( $search !== '' ) {
			$found = false;
			$q     = strtolower( $search );
			if ( $scope === 'column' && $search_col >= 0 ) {
				$val = isset( $cells[ $search_col ] ) ? strtolower( (string) $cells[ $search_col ] ) : '';
				$found = ( $mode === 'exact' ) ? ( $val === $q ) : ( strpos( $val, $q ) !== false );
			} else {
				$hay = strtolower( implode( ' ', array_map( 'strval', $cells ) ) );
				$found = ( $mode === 'exact' ) ? ( $hay === $q ) : ( strpos( $hay, $q ) !== false );
			}
			if ( ! $found ) {
				return false;
			}
		}

		if ( $filter === 'empty' ) {
			foreach ( $cells as $v ) {
				if ( trim( (string) $v ) === '' ) {
					return true;
				}
			}
			return false;
		}

		if ( $filter === 'errors' ) {
			$v = SpreadsheetValidator::getInstance()->validate_row_cells( $cells, $columns, $import_type );
			return $v['errors'] > 0;
		}

		if ( $filter === 'warnings' ) {
			$v = SpreadsheetValidator::getInstance()->validate_row_cells( $cells, $columns, $import_type );
			return $v['warnings'] > 0;
		}

		if ( $filter === 'column_value' && $filter_col >= 0 && $filter_val !== '' ) {
			$val = isset( $cells[ $filter_col ] ) ? trim( (string) $cells[ $filter_col ] ) : '';
			return strcasecmp( $val, $filter_val ) === 0;
		}

		if ( $filter === 'duplicates' && $filter_col >= 0 ) {
			$val = isset( $cells[ $filter_col ] ) ? trim( strtolower( (string) $cells[ $filter_col ] ) ) : '';
			if ( $val === '' ) {
				return false;
			}
			return isset( $dup_counts[ $val ] ) && $dup_counts[ $val ] > 1;
		}

		return true;
	}

	private function sanitize_cell_value( $value ) {
		if ( is_array( $value ) ) {
			$value = implode( ',', $value );
		}
		return wp_check_invalid_utf8( wp_unslash( (string) $value ), true );
	}

	private function escape_csv_injection( $value ) {
		if ( $value === '' ) {
			return $value;
		}
		$first = substr( $value, 0, 1 );
		if ( in_array( $first, array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}
}
