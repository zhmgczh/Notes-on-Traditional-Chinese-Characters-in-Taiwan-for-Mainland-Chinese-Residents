<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Human-readable validation error explanations for Import Preview.
 *
 * Filter: uci_pro_error_explanation
 */
class ImportErrorExplanationService {

	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Built-in explanation templates keyed by error code.
	 *
	 * @return array<string, array{title:string,message:string,suggestion:string,severity:string}>
	 */
	private function get_builtin_templates() {
		return array(
			'missing_required_field' => array(
				'title'      => __( 'Missing Required Field', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'A required field for this import type has no value after mapping and transformation.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Map a CSV column to this field or provide a default/static value in mapping.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'missing_sku'            => array(
				'title'      => __( 'Missing Product SKU', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The SKU field is required for product imports but no value was found.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Map a CSV column to SKU or provide a default value.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'invalid_email'          => array(
				'title'      => __( 'Invalid Email Address', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The value is not a valid email address.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Correct the source data or add a transform to sanitize the email format.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'invalid_url'            => array(
				'title'      => __( 'Invalid URL', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The URL format appears invalid or incomplete.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Ensure URLs include a valid scheme (http/https) and correct path.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'warning',
			),
			'invalid_taxonomy'       => array(
				'title'      => __( 'Empty Taxonomy Value', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'A taxonomy field is mapped but no terms were provided for this row.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Map a CSV column containing category/tag names or provide a default term list.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'invalid_date'           => array(
				'title'      => __( 'Invalid Date', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The date value could not be parsed using supported import date formats.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS, or apply a date transform in mapping.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'duplicate_unique_id'    => array(
				'title'      => __( 'Duplicate Unique Identifier', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'This value already exists in WordPress and may cause duplicate or update conflicts.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Review duplicate handling settings or change the unique identifier value.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'warning',
			),
			'duplicate_in_preview'   => array(
				'title'      => __( 'Duplicate in Preview Rows', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The same unique identifier appears more than once in the preview subset.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Remove or fix duplicate rows in your source file before importing.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'invalid_post_status'    => array(
				'title'      => __( 'Invalid Post Status', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'The post status value is not recognized by WordPress.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Use publish, draft, pending, private, future, or trash.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'error',
			),
			'unbalanced_html'        => array(
				'title'      => __( 'Unbalanced HTML', 'wp-ultimate-csv-importer' ),
				'message'    => __( 'HTML content may contain unclosed or mismatched tags.', 'wp-ultimate-csv-importer' ),
				'suggestion' => __( 'Validate HTML in the source or use a content cleanup transform.', 'wp-ultimate-csv-importer' ),
				'severity'   => 'warning',
			),
		);
	}

	/**
	 * Get human-readable explanation for an error code.
	 *
	 * @param string               $code    Error code.
	 * @param array<string, mixed> $context Optional context (field, import_type, etc.).
	 * @return array{title:string,message:string}
	 */
	public function getExplanation( $code, $context = array() ) {
		$object = $this->buildErrorObject( $code, '', $context );
		return array(
			'title'   => $object['title'],
			'message' => $object['message'],
		);
	}

	/**
	 * Get suggested fix for an error code.
	 *
	 * @param string               $code    Error code.
	 * @param array<string, mixed> $context Optional context.
	 * @return string
	 */
	public function getSuggestion( $code, $context = array() ) {
		$object = $this->buildErrorObject( $code, '', $context );
		return $object['suggestion'];
	}

	/**
	 * Build a structured error object for the preview UI.
	 *
	 * @param string               $code     Internal validation code.
	 * @param string               $severity Optional severity override (error|warning).
	 * @param array<string, mixed> $context  Field/import context.
	 * @return array<string, mixed>
	 */
	public function buildErrorObject( $code, $severity = '', $context = array() ) {
		$code       = sanitize_key( $code );
		$templates  = $this->get_builtin_templates();
		$template   = isset( $templates[ $code ] ) ? $templates[ $code ] : array(
			'title'      => __( 'Validation Issue', 'wp-ultimate-csv-importer' ),
			'message'    => __( 'A validation issue was detected for this field.', 'wp-ultimate-csv-importer' ),
			'suggestion' => __( 'Review the mapped value and source data.', 'wp-ultimate-csv-importer' ),
			'severity'   => 'warning',
		);

		$field_label = isset( $context['destination_field'] ) ? (string) $context['destination_field'] : '';
		if ( $field_label !== '' && $code === 'missing_required_field' ) {
			/* translators: %s: destination field name */
			$template['title'] = sprintf( __( 'Missing %s', 'wp-ultimate-csv-importer' ), $field_label );
		}

		$severity = $severity !== '' ? $severity : ( $template['severity'] ?? 'warning' );

		$object = array(
			'code'       => $code,
			'severity'   => $severity,
			'title'      => $template['title'],
			'message'    => $template['message'],
			'suggestion' => $template['suggestion'],
			'doc_url'    => ErrorDocumentationRegistry::getInstance()->get_link( $code ),
		);

		if ( ! empty( $context['destination_field'] ) ) {
			$object['field_identifier'] = (string) $context['destination_field'];
		}
		if ( ! empty( $context['exception_message'] ) ) {
			$object['exception_message'] = (string) $context['exception_message'];
		}
		if ( ! empty( $context['stack_trace'] ) ) {
			$object['stack_trace'] = (string) $context['stack_trace'];
		}
		if ( ! empty( $context['template_id'] ) ) {
			$object['template_id'] = (int) $context['template_id'];
		}

		return apply_filters( 'uci_pro_error_explanation', $object, $code, $context );
	}
}
