<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import {

	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	/**
	 * No-op Import Actions when hook_system is OFF (#1442 Phase 4).
	 * Keeps $is_import_active for SaveMapping compatibility; does not register WP meta hooks.
	 */
	class Actions {

		/** @var self|null */
		private static $instance = null;

		/** @var bool */
		public static $is_import_active = false;

		private function __construct() {
		}

		/**
		 * @return self
		 */
		public static function getInstance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * @param string $name Method name.
		 * @param array  $args Arguments.
		 * @return null
		 */
		public function __call( $name, $args ) {
			unset( $name, $args );
			return null;
		}
	}

	/**
	 * Pass-through Import Filters when hook_system is OFF (#1442 Phase 4).
	 */
	class Filters {

		/** @var self|null */
		private static $instance = null;

		private function __construct() {
		}

		/**
		 * @return self
		 */
		public static function getInstance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * @param string $name Method name.
		 * @param array  $args Arguments.
		 * @return mixed First argument (pass-through).
		 */
		public function __call( $name, $args ) {
			unset( $name );
			return array_key_exists( 0, $args ) ? $args[0] : null;
		}
	}
}

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export {

	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	/**
	 * No-op Export Actions when hook_system is OFF (#1442 Phase 4).
	 */
	class Actions {

		/** @var self|null */
		private static $instance = null;

		private function __construct() {
		}

		/**
		 * @return self
		 */
		public static function getInstance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * @param string $name Method name.
		 * @param array  $args Arguments.
		 * @return null
		 */
		public function __call( $name, $args ) {
			unset( $name, $args );
			return null;
		}
	}

	/**
	 * Pass-through Export Filters when hook_system is OFF (#1442 Phase 4).
	 */
	class Filters {

		/** @var self|null */
		private static $instance = null;

		private function __construct() {
		}

		/**
		 * @return self
		 */
		public static function getInstance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * @param string $name Method name.
		 * @param array  $args Arguments.
		 * @return mixed First argument (pass-through).
		 */
		public function __call( $name, $args ) {
			unset( $name );
			return array_key_exists( 0, $args ) ? $args[0] : null;
		}
	}
}
