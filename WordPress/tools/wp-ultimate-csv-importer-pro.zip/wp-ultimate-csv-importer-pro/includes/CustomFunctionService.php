<?php
/**
 * Secure loader and evaluator for Header Manipulation custom functions.
 *
 * Functions are defined in wp-content/uploads/smack_uci_uploads/customFunction.php
 * (written via mapping UI ->cus2). Only registered function *calls* are executed;
 * arbitrary PHP from uploads is never eval()'d (CVE-2026-13353 mitigation).
 *
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CustomFunctionService {

	/** @var bool */
	private static $definitions_loaded = false;

	/** @var string[] */
	private static $registered_names = array();

	/**
	 * Tokens that must not appear in customFunction.php source.
	 *
	 * @var string[]
	 */
	private static $blocked_source_tokens = array(
		'eval',
		'assert',
		'create_function',
		'system',
		'exec',
		'shell_exec',
		'passthru',
		'proc_open',
		'popen',
		'pcntl_exec',
		'file_put_contents',
		'fopen',
		'fwrite',
		'unlink',
		'curl_exec',
		'curl_multi_exec',
		'base64_decode',
		'gzinflate',
		'include',
		'require',
		'include_once',
		'require_once',
		'ReflectionFunction',
		'ReflectionMethod',
		'$_GET',
		'$_POST',
		'$_REQUEST',
		'$_SERVER',
		'$_ENV',
		'GLOBALS',
		'phpinfo',
	);

	/**
	 * Absolute path to the uploads custom function file.
	 *
	 * @return string
	 */
	public static function get_file_path() {
		$upload = wp_upload_dir();
		return trailingslashit( $upload['basedir'] ) . 'smack_uci_uploads/customFunction.php';
	}

	/**
	 * Load function definitions once per request when the file passes validation.
	 *
	 * @return void
	 */
	public static function load_definitions() {
		if ( self::$definitions_loaded ) {
			return;
		}

		$path = self::get_file_path();
		if ( ! is_readable( $path ) ) {
			self::$definitions_loaded = true;
			return;
		}

		$content = (string) file_get_contents( $path );
		if ( ! self::is_source_safe( $content ) ) {
			self::log( 'custom_function_file_rejected', array( 'path' => $path ) );
			self::$definitions_loaded = true;
			return;
		}

		$names = self::extract_function_names( $content );
		$names = apply_filters( 'sm_uci_pro_custom_function_allowlist', $names, $path );
		if ( empty( $names ) ) {
			self::$definitions_loaded = true;
			return;
		}

		$before = get_defined_functions();
		$before_user = isset( $before['user'] ) ? $before['user'] : array();

		// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- Admin-scoped, validated source file.
		require_once $path;

		$after      = get_defined_functions();
		$after_user = isset( $after['user'] ) ? $after['user'] : array();
		$new_funcs  = array_diff( $after_user, $before_user );

		foreach ( $names as $name ) {
			if ( function_exists( $name ) ) {
				self::$registered_names[] = $name;
			}
		}

		// Log unexpected top-level definitions (helpers defined in the same file are OK if named in extract).
		foreach ( $new_funcs as $fn ) {
			if ( ! in_array( $fn, self::$registered_names, true ) && ! in_array( $fn, $names, true ) ) {
				self::log(
					'custom_function_unregistered_helper',
					array( 'function' => $fn )
				);
			}
		}

		self::$registered_names = array_values( array_unique( self::$registered_names ) );
		self::$definitions_loaded = true;

		self::log(
			'custom_function_definitions_loaded',
			array(
				'path'      => $path,
				'functions' => self::$registered_names,
			)
		);
	}

	/**
	 * Evaluate a single custom-function call expression after SafeExpressionEvaluator fails.
	 *
	 * @param string $expression e.g. bereken_awin_100g('4.46','896 gram product').
	 * @return mixed|null
	 */
	public static function evaluate_call( $expression ) {
		$expression = trim( (string) $expression );
		if ( $expression === '' ) {
			return null;
		}

		if ( ! self::is_call_expression_safe( $expression ) ) {
			self::log( 'custom_function_call_rejected', array( 'expression' => $expression ) );
			return null;
		}

		if ( ! preg_match( '/^([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$/s', $expression, $matches ) ) {
			return null;
		}

		$fn_name = $matches[1];
		self::load_definitions();

		if ( ! in_array( $fn_name, self::$registered_names, true ) || ! function_exists( $fn_name ) ) {
			self::log(
				'custom_function_not_registered',
				array(
					'function'   => $fn_name,
					'expression' => $expression,
				)
			);
			return null;
		}

		$args = self::parse_argument_list( $matches[2] );
		if ( null === $args ) {
			self::log(
				'custom_function_args_parse_failed',
				array(
					'function' => $fn_name,
					'args_raw' => $matches[2],
				)
			);
			return null;
		}

		self::log(
			'custom_function_call_entry',
			array(
				'function' => $fn_name,
				'args'     => $args,
			)
		);

		try {
			$result = call_user_func_array( $fn_name, $args );
		} catch ( \Throwable $e ) {
			self::log(
				'custom_function_call_error',
				array(
					'function' => $fn_name,
					'message'  => $e->getMessage(),
				)
			);
			return null;
		}

		self::log(
			'custom_function_call_return',
			array(
				'function' => $fn_name,
				'result'   => $result,
			)
		);

		return $result;
	}

	/**
	 * @param string $content File source.
	 * @return bool
	 */
	public static function is_source_safe( $content ) {
		$content = (string) $content;
		if ( $content === '' ) {
			return false;
		}
		if ( strpos( ltrim( $content ), '<?php' ) !== 0 ) {
			return false;
		}
		if ( preg_match( '/`|->/', $content ) ) {
			return false;
		}
		foreach ( self::$blocked_source_tokens as $token ) {
			if ( preg_match( '/\b' . preg_quote( $token, '/' ) . '\b/i', $content ) ) {
				return false;
			}
		}
		$has_fn = preg_match( '/function\s+[A-Za-z_][A-Za-z0-9_]*\s*\(/', $content );
		return (bool) $has_fn;
	}

	/**
	 * @param string $content PHP source.
	 * @return string[]
	 */
	public static function extract_function_names( $content ) {
		$names = array();
		if ( preg_match_all( '/function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/', (string) $content, $matches ) ) {
			$names = array_values( array_unique( $matches[1] ) );
		}
		return $names;
	}

	/**
	 * @param string $expression Call expression.
	 * @return bool
	 */
	private static function is_call_expression_safe( $expression ) {
		if ( preg_match( '/[`$]|->|::|\\\\/', $expression ) ) {
			return false;
		}
		foreach ( self::$blocked_source_tokens as $token ) {
			if ( preg_match( '/\b' . preg_quote( $token, '/' ) . '\b/i', $expression ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Parse comma-separated call arguments; literals via SafeExpressionEvaluator when available.
	 *
	 * @param string $args_string Raw text inside parentheses.
	 * @return array|null
	 */
	private static function parse_argument_list( $args_string ) {
		$args_string = trim( (string) $args_string );
		if ( $args_string === '' ) {
			return array();
		}

		$parts  = array();
		$buffer = '';
		$depth  = 0;
		$quote  = null;
		$len    = strlen( $args_string );

		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $args_string[ $i ];

			if ( null !== $quote ) {
				$buffer .= $ch;
				if ( $ch === $quote && ( $i === 0 || $args_string[ $i - 1 ] !== '\\' ) ) {
					$quote = null;
				}
				continue;
			}

			if ( $ch === '"' || $ch === "'" ) {
				$quote   = $ch;
				$buffer .= $ch;
				continue;
			}

			if ( $ch === '(' ) {
				++$depth;
				$buffer .= $ch;
				continue;
			}
			if ( $ch === ')' ) {
				--$depth;
				$buffer .= $ch;
				continue;
			}

			if ( $ch === ',' && 0 === $depth ) {
				$parts[] = trim( $buffer );
				$buffer  = '';
				continue;
			}

			$buffer .= $ch;
		}

		if ( null !== $quote || $depth !== 0 ) {
			return null;
		}

		$parts[] = trim( $buffer );
		$args    = array();

		foreach ( $parts as $part ) {
			if ( $part === '' ) {
				$args[] = '';
				continue;
			}
			if ( class_exists( '\Smackcoders\UCI\Core\SafeExpressionEvaluator' ) ) {
				$val = \Smackcoders\UCI\Core\SafeExpressionEvaluator::evaluate( $part );
				if ( null !== $val ) {
					$args[] = $val;
					continue;
				}
			}
			if ( is_numeric( $part ) ) {
				$args[] = strpos( $part, '.' ) !== false ? (float) $part : (int) $part;
				continue;
			}
			$lower = strtolower( $part );
			if ( in_array( $lower, array( 'true', 'false', 'null' ), true ) ) {
				$args[] = 'true' === $lower ? true : ( 'false' === $lower ? false : null );
				continue;
			}
			if ( strlen( $part ) >= 2 ) {
				$q = $part[0];
				if ( ( '"' === $q || "'" === $q ) && substr( $part, -1 ) === $q ) {
					$args[] = stripcslashes( substr( $part, 1, -1 ) );
					continue;
				}
			}
			return null;
		}

		return $args;
	}

	/**
	 * Optional no-op logger (kept for customFunction.php compatibility).
	 *
	 * @param string               $step Label.
	 * @param array<string, mixed> $data Context.
	 * @return void
	 */
	public static function log( $step, $data = array() ) {
		unset( $step, $data );
	}
}
