<?php
/**
 * Detach duplicate free-plugin AJAX handlers when Pro is active.
 *
 * Free and Pro register the same wp_ajax_* actions. Free handlers verify the
 * `smack-ultimate-csv-importer` nonce while Pro sends `smack-ultimate-csv-importer-pro`,
 * so the free callback runs first and returns 403 before Pro can handle the request.
 *
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProFreeAjaxDedup {

	/**
	 * Register late on plugins_loaded so free handlers are removed after both plugins bootstrap.
	 */
	public static function bootstrap() {
		add_action( 'plugins_loaded', array( __CLASS__, 'detach_free_handlers' ), 999 );
	}

	/**
	 * Remove overlapping free Core AJAX callbacks; Pro handlers remain registered.
	 */
	public static function detach_free_handlers() {
		if ( ! class_exists( '\Smackcoders\UCI\Core\UCICore' ) && ! class_exists( '\Smackcoders\UCI\Core\SaveMapping' ) ) {
			return;
		}

		self::detach_instance(
			'\Smackcoders\UCI\Core\SaveMapping',
			array(
				'saveTemplateFields'           => 'save_template_fields',
				'saveMappedFields'             => 'check_templatename_exists',
				'StartImport'                  => 'background_starts_function',
				'GetProgress'                  => 'import_detail_function',
				'ImportState'                  => 'import_state_function',
				'ImportStop'                   => 'import_stop_function',
				'checkmain_mode'               => 'checkmain_mode',
				'close_notification_action'    => 'handle_close_notification_action',
				'bulk_file_import'             => 'bulk_file_import_function',
				'bulk_import'                  => 'bulk_import',
				'PauseImport'                  => 'pause_import',
				'ResumeImport'                 => 'resume_import',
				'DeactivateMail'               => 'deactivate_mail',
				'smackuci_check_review_popup'  => 'smackuci_check_review_popup',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\DashboardController',
			array(
				'LineChart'                      => 'fetch_line_chart_data',
				'BarChart'                       => 'fetch_bar_chart_data',
				'dashboard_kpi_stats'            => 'fetch_kpi_stats',
				'dashboard_import_volume'        => 'fetch_import_volume',
				'dashboard_content_distribution' => 'fetch_content_distribution',
				'dashboard_recent_activity'      => 'fetch_recent_activity',
				'dashboard_quick_stats'          => 'fetch_quick_stats',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\MediaHandling',
			array(
				'zip_upload'    => 'zipImageUpload',
				'image_options' => 'imageOptions',
				'delete_image'  => 'deleteImage',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\ImportConfiguration',
			array(
				'updatefields' => 'get_update_fields',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\DragandDropExtension',
			array(
				'displayCSV' => 'display_csv_values',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\SendPassword',
			array(
				'settings_options' => 'settingsOptions',
				'get_options'      => 'showOptions',
				'get_setting'      => 'showsetting',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\SupportMail',
			array(
				'support_mail'          => 'supportMail',
				'toolset_state'         => 'toolsetState',
				'send_subscribe_email'  => 'sendSubscribeEmail',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\NeedHelperExtension',
			array(
				'needHelper' => 'Need_Helper',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\HelperExtension',
			array(
				'helperImport' => 'HelperImport',
				'helperSearch' => 'SearchWord',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\Security',
			array(
				'security_performance' => 'securityPerformance',
				'active_addons'        => 'activeAddons',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\MappingExtension',
			array(
				'mappingfields'   => 'mapping_field_function',
				'templateinfo'    => 'get_template_info',
				'search_template' => 'search_template',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\ExportExtension',
			array(
				'total_records' => 'totalRecords',
				'check_export'  => 'checkExport',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\LogManager',
			array(
				'display_log'         => 'display_log',
				'download_log'        => 'download_log',
				'download_media_log'  => 'download_media_log',
				'download_failed_log' => 'download_failed_log',
				'delete_log'          => 'delete_log',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\TemplateManager',
			array(
				'displayTemplates'       => 'display_templates',
				'saveTemplate'           => 'save_template',
				'deleteTemplate'         => 'delete_template',
				'download_template_file' => 'download_template_file',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\DesktopUpload',
			array(
				'get_desktop'        => 'upload_function',
				'oneClickUpload'     => 'upload_function',
				'get_csv_delimiter'  => 'get_csv_delimiter',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\FtpUpload',
			array(
				'get_ftp_url'     => 'upload_function',
				'get_ftp_details' => 'getFtpDetails',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\UrlUpload',
			array(
				'get_csv_url' => 'upload_function',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\XmlHandler',
			array(
				'get_parse_xml' => 'parse_xml',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\InstallAddons',
			array(
				'install_plugins' => 'install',
				'install_addon'   => 'separateaddons',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\SingleImportExport',
			array(
				'handle_export_csv' => 'export_single_post_as_csv',
				'handle_import_csv' => 'import_single_post_as_csv',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\ImportHelpers',
			array(
				'check_import' => 'checkImport',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\ImportResumeController',
			array(
				'get_interrupted_imports' => 'get_interrupted_imports',
				'resume_import_session'   => 'resume_import_session',
				'discard_import_session'  => 'discard_import_session',
			)
		);

		self::detach_instance(
			'\Smackcoders\UCI\Core\CsvValidationController',
			array(
				'validate_csv_preflight' => 'validate_csv_preflight',
			)
		);
	}

	/**
	 * @param string              $class  Fully-qualified class name.
	 * @param array<string,string> $actions Map of AJAX action => method name.
	 */
	private static function detach_instance( $class, array $actions ) {
		if ( ! class_exists( $class ) || ! method_exists( $class, 'getInstance' ) ) {
			return;
		}

		$instance = $class::getInstance();
		foreach ( $actions as $action => $method ) {
			if ( method_exists( $instance, $method ) ) {
				remove_action( 'wp_ajax_' . $action, array( $instance, $method ) );
			}
		}
	}
}
