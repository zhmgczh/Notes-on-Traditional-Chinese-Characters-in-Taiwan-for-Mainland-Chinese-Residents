<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Row/cell validation for Spreadsheet Live Editor (reuses AIErrorDetection rules).
 */
class SpreadsheetValidator {

	private static $instance = null;

	private $email_fields = array( 'user_email', 'comment_author_email', 'billing_email', 'shipping_email' );
	private $date_fields  = array( 'post_date', 'post_modified', 'post_date_gmt', 'post_modified_gmt', 'comment_date', 'user_registered' );
	private $url_fields   = array( 'featured_image', '_wp_attached_file', 'product_url', 'user_url', 'thumbnail_id', 'guid' );
	private $date_formats = array( 'Y-m-d', 'Y-m-d H:i:s', 'm/d/Y', 'd/m/Y', 'Y/m/d', 'd-m-Y', 'm-d-Y' );
	private $valid_post_statuses = array( 'publish', 'draft', 'pending', 'private', 'trash', 'future', 'inherit', 'published', 'draft' );

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Validate one cell.
	 *
	 * @return array{level:string,message:string} level: ok|warning|error
	 */
	public function validate_cell( $value, $wp_field, $import_type = '' ) {
		$value    = is_string( $value ) ? trim( $value ) : '';
		$wp_field = is_string( $wp_field ) ? trim( $wp_field ) : '';

		if ( $value === '' ) {
			return array( 'level' => 'ok', 'message' => '' );
		}

		if ( in_array( $wp_field, $this->email_fields, true ) && ! is_email( $value ) ) {
			return array(
				'level'   => 'error',
				'message' => __( 'Invalid email address.', 'wp-ultimate-csv-importer' ),
			);
		}

		if ( in_array( $wp_field, $this->date_fields, true ) && ! $this->is_valid_date( $value ) ) {
			return array(
				'level'   => 'error',
				'message' => __( 'Invalid date format.', 'wp-ultimate-csv-importer' ),
			);
		}

		if ( $wp_field === 'post_status' && ! in_array( strtolower( $value ), array_map( 'strtolower', $this->valid_post_statuses ), true ) ) {
			return array(
				'level'   => 'error',
				'message' => __( 'Invalid post status.', 'wp-ultimate-csv-importer' ),
			);
		}

		if ( in_array( $wp_field, $this->url_fields, true ) && ! $this->is_valid_url( $value ) ) {
			return array(
				'level'   => 'warning',
				'message' => __( 'URL may be invalid or unreachable.', 'wp-ultimate-csv-importer' ),
			);
		}

		if ( ( $wp_field === 'post_content' || strpos( $wp_field, 'wysiwyg' ) !== false ) && ! $this->is_html_balanced( $value ) ) {
			return array(
				'level'   => 'warning',
				'message' => __( 'Unbalanced HTML tags.', 'wp-ultimate-csv-importer' ),
			);
		}

		return array( 'level' => 'ok', 'message' => '' );
	}

	/**
	 * Validate a mapped row (associative cells keyed by col_index).
	 *
	 * @param array $cells [ col_index => value ]
	 * @param array $columns Column meta from SpreadsheetEditorService.
	 * @return array{errors:int,warnings:int,cells:array}
	 */
	public function validate_row_cells( $cells, $columns, $import_type = '' ) {
		$errors   = 0;
		$warnings = 0;
		$cell_out = array();

		foreach ( $columns as $col ) {
			$idx = (int) $col['col_index'];
			$val = isset( $cells[ $idx ] ) ? $cells[ $idx ] : ( isset( $cells[ (string) $idx ] ) ? $cells[ (string) $idx ] : '' );
			$res = $this->validate_cell( $val, $col['wp_field'] ?? '', $import_type );
			$cell_out[ $idx ] = $res;
			if ( $res['level'] === 'error' ) {
				++$errors;
			} elseif ( $res['level'] === 'warning' ) {
				++$warnings;
			}
		}

		return array(
			'errors'   => $errors,
			'warnings' => $warnings,
			'cells'    => $cell_out,
		);
	}

	private function is_valid_date( $value ) {
		foreach ( $this->date_formats as $format ) {
			$dt = \DateTime::createFromFormat( $format, $value );
			if ( $dt && $dt->format( $format ) === $value ) {
				return true;
			}
		}
		$ts = strtotime( $value );
		return $ts !== false;
	}

	private function is_valid_url( $value ) {
		if ( filter_var( $value, FILTER_VALIDATE_URL ) ) {
			return true;
		}
		return (bool) preg_match( '#^https?://#i', $value );
	}

	private function is_html_balanced( $value ) {
		if ( strpos( $value, '<' ) === false ) {
			return true;
		}
		$stripped = wp_strip_all_tags( $value, true );
		return strlen( $stripped ) > 0 || trim( $value ) === '';
	}
}
