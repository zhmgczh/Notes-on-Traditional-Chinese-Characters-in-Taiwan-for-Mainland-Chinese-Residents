<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared blank/unmapped preserve rule for WooCommerce update-mode imports (#1442).
 *
 * Rule: unmapped OR blank CSV value → return existing value.
 * Mapped non-blank → return CSV value.
 */
class ImportValueResolver {

	/**
	 * @param mixed  $csv_value      Value from the current CSV row.
	 * @param mixed  $existing_value Stored value on the target record.
	 * @param bool   $is_mapped      Whether the field is mapped in the template.
	 * @param string $field_key      Optional field identifier for filters.
	 * @return mixed
	 */
	public static function resolve( $csv_value, $existing_value, $is_mapped, $field_key = '' ) {
		$resolved = self::resolve_internal( $csv_value, $existing_value, $is_mapped );

		/**
		 * Filter resolved import value for extensions.
		 *
		 * @param mixed  $resolved       Resolved value after the preserve-blank rule.
		 * @param mixed  $csv_value      Raw CSV value.
		 * @param mixed  $existing_value Existing stored value.
		 * @param bool   $is_mapped      Whether the field is mapped.
		 * @param string $field_key      Field identifier.
		 */
		return apply_filters( 'sm_uci_pro_resolve_import_value', $resolved, $csv_value, $existing_value, $is_mapped, $field_key );
	}

	/**
	 * Whether an import field should be applied in update mode.
	 *
	 * @param mixed  $csv_value CSV value.
	 * @param bool   $is_mapped Whether mapped in template.
	 * @param string $mode      Import mode (Insert|Update).
	 * @return bool
	 */
	public static function should_apply_in_update_mode( $csv_value, $is_mapped, $mode = 'Update' ) {
		if ( 'Update' !== $mode ) {
			return true;
		}
		if ( ! $is_mapped ) {
			return false;
		}
		return ! self::is_blank( $csv_value );
	}

	/**
	 * @param mixed $value Value to test.
	 * @return bool
	 */
	public static function is_blank( $value ) {
		if ( null === $value ) {
			return true;
		}
		if ( is_array( $value ) ) {
			return empty( $value );
		}
		return trim( (string) $value ) === '';
	}

	/**
	 * @param array|string $map       Mapping section (field => CSV column/formula).
	 * @param string       $field_key Field key.
	 * @return bool
	 */
	public static function is_field_mapped( $map, $field_key ) {
		if ( ! is_array( $map ) || ! array_key_exists( $field_key, $map ) ) {
			return false;
		}
		if ( is_array( $map[ $field_key ] ) ) {
			return false;
		}
		$mapped_value = trim( (string) $map[ $field_key ] );
		if ( preg_match( '/^\{([^}]+)\}$/', $mapped_value, $matches ) ) {
			$mapped_value = trim( $matches[1] );
		}
		return $mapped_value !== '' && strtolower( $mapped_value ) !== '--select--';
	}

	/**
	 * @param mixed $csv_value      CSV value.
	 * @param mixed $existing_value Existing value.
	 * @param bool  $is_mapped      Mapped flag.
	 * @return mixed
	 */
	private static function resolve_internal( $csv_value, $existing_value, $is_mapped ) {
		if ( ! $is_mapped || self::is_blank( $csv_value ) ) {
			return $existing_value;
		}
		return $csv_value;
	}
}
