<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Canonical feature toggle registry for #1442.
 *
 * Fresh installs: all 15 features default OFF until explicitly enabled in Feature Modules.
 */
class FeatureRegistry {

	const OPTION_KEY = 'sm_uci_pro_feature_toggles';

	/** @var self|null */
	private static $instance = null;

	/** @var array<string, bool>|null In-request cache of option states. */
	private static $states_cache = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Canonical feature definitions (IDs are stable API for FeatureLoader).
	 *
	 * @return array<string, array{id: string, label: string, description: string, since: string}>
	 */
	public static function get_definitions() {
		$definitions = array(
			'ai_import'             => array(
				'id'          => 'ai_import',
				'label'       => 'AI Import Features',
				'description' => 'AI natural language import, field mapping, governance, and related AIBootstrap modules.',
				'since'       => '8.16',
			),
			'wpbakery'              => array(
				'id'          => 'wpbakery',
				'label'       => 'WPBakery Page Builder',
				'description' => 'WPBakery import and export field extensions.',
				'since'       => '8.15',
			),
			'bricks_builder'        => array(
				'id'          => 'bricks_builder',
				'label'       => 'Bricks Builder',
				'description' => 'Bricks Builder import and export field extensions.',
				'since'       => '8.15',
			),
			'oxygen_builder'        => array(
				'id'          => 'oxygen_builder',
				'label'       => 'Oxygen Builder',
				'description' => 'Oxygen Builder import and export field extensions.',
				'since'       => '8.16',
			),
			'db_migration'          => array(
				'id'          => 'db_migration',
				'label'       => 'External Database Migration',
				'description' => 'Import from external database sources via DatabaseMigrationBootstrap.',
				'since'       => '8.16',
			),
			'google_sheets'         => array(
				'id'          => 'google_sheets',
				'label'       => 'Google Sheets Upload',
				'description' => 'Google Sheets HTTP transport and spreadsheet upload workflow.',
				'since'       => '8.15',
			),
			'automation_api'        => array(
				'id'          => 'automation_api',
				'label'       => 'REST API & Webhooks',
				'description' => 'Automation API (uci-pro/v1), webhooks, and REST import endpoints.',
				'since'       => '8.16',
			),
			'hook_system'           => array(
				'id'          => 'hook_system',
				'label'       => 'Extended Import/Export Hooks',
				'description' => 'Expanded HooksHandler import/export action and filter surface added in 8.16.',
				'since'       => '8.16',
			),
			'media_queue'           => array(
				'id'          => 'media_queue',
				'label'       => 'Media Download Queue',
				'description' => 'Background media download queue (MediaBootstrap); baseline uses inline MediaHandling only.',
				'since'       => '8.16',
			),
			'woo_native_csv'        => array(
				'id'          => 'woo_native_csv',
				'label'       => 'WooCommerce Native CSV',
				'description' => 'WooCommerce native product CSV import compatibility layer.',
				'since'       => '8.16',
			),
			'spreadsheet_editor'    => array(
				'id'          => 'spreadsheet_editor',
				'label'       => 'Spreadsheet Live Editor',
				'description' => 'In-browser spreadsheet editor for import files.',
				'since'       => '8.16',
			),
			'import_preview'        => array(
				'id'          => 'import_preview',
				'label'       => 'Import Preview',
				'description' => 'Pre-import validation and preview UI.',
				'since'       => '8.16',
			),
			'import_retry'          => array(
				'id'          => 'import_retry',
				'label'       => 'Failed Record Retry',
				'description' => 'Retry queue for failed import records.',
				'since'       => '8.16',
			),
			'import_resume'         => array(
				'id'          => 'import_resume',
				'label'       => 'Import Resume / Recovery',
				'description' => 'Resume interrupted imports from saved state.',
				'since'       => '8.16',
			),
			'woo_surecart_migration' => array(
				'id'          => 'woo_surecart_migration',
				'label'       => 'Woo → SureCart Migration',
				'description' => 'WooCommerce to SureCart migration modules.',
				'since'       => '8.15',
			),
		);

		return apply_filters( 'uci_pro_feature_registry_definitions', $definitions );
	}

	/**
	 * Whether a feature is enabled. Unknown IDs return false. Missing option => OFF.
	 *
	 * @param string $id Feature ID.
	 * @return bool
	 */
	public static function is_enabled( $id ) {
		return self::getInstance()->is_feature_enabled( $id );
	}

	/**
	 * @param string $id Feature ID.
	 * @return bool
	 */
	public function is_feature_enabled( $id ) {
		$id          = sanitize_key( $id );
		$definitions = self::get_definitions();

		if ( ! isset( $definitions[ $id ] ) ) {
			return false;
		}

		if ( null === self::$states_cache ) {
			$stored = get_option( self::OPTION_KEY, false );
			if ( false === $stored || ! is_array( $stored ) ) {
				self::$states_cache = array();
			} else {
				self::$states_cache = $stored;
			}
		}

		if ( ! array_key_exists( $id, self::$states_cache ) ) {
			return false;
		}

		return (bool) self::$states_cache[ $id ];
	}

	/**
	 * All features with metadata and resolved enabled state.
	 *
	 * @return array<string, array{id: string, label: string, description: string, since: string, enabled: bool}>
	 */
	public static function get_all() {
		return self::getInstance()->get_all_features();
	}

	/**
	 * @return array<string, array{id: string, label: string, description: string, since: string, enabled: bool}>
	 */
	public function get_all_features() {
		$result      = array();
		$definitions = self::get_definitions();

		foreach ( $definitions as $id => $meta ) {
			$result[ $id ] = array_merge(
				$meta,
				array(
					'enabled' => $this->is_feature_enabled( $id ),
				)
			);
		}

		return $result;
	}

	/**
	 * List of enabled feature IDs only.
	 *
	 * @return string[]
	 */
	public static function get_enabled_ids() {
		return self::getInstance()->get_enabled_feature_ids();
	}

	/**
	 * @return string[]
	 */
	public function get_enabled_feature_ids() {
		$enabled = array();

		foreach ( self::get_definitions() as $id => $meta ) {
			if ( $this->is_feature_enabled( $id ) ) {
				$enabled[] = $id;
			}
		}

		return $enabled;
	}

	/**
	 * Default toggle state map (all false) for fresh installs / reset.
	 *
	 * @return array<string, bool>
	 */
	public static function get_default_states() {
		$states = array();
		foreach ( array_keys( self::get_definitions() ) as $id ) {
			$states[ $id ] = false;
		}
		return $states;
	}

	/**
	 * Persist toggle states (unknown keys ignored; missing keys keep current state or default OFF).
	 *
	 * @param array<string, bool|int|string> $states Feature ID => enabled flag.
	 * @return bool
	 */
	public static function save_states( array $states ) {
		$definitions = self::get_definitions();
		$current     = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}

		foreach ( $states as $id => $value ) {
			$id = sanitize_key( $id );
			if ( ! isset( $definitions[ $id ] ) ) {
				continue;
			}
			$current[ $id ] = (bool) $value;
		}

		self::$states_cache = $current;
		return update_option( self::OPTION_KEY, $current, false );
	}

	/**
	 * Seed all-OFF defaults for fresh installs when option is missing.
	 */
	public static function ensure_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			$defaults = self::get_default_states();
			add_option( self::OPTION_KEY, $defaults, false );
			self::$states_cache = $defaults;
		}
	}

	private function __construct() {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// error_log( '[UCI Pro] FeatureRegistry loaded with ' . count( self::get_definitions() ) . ' features.' );
		}
	}
}
