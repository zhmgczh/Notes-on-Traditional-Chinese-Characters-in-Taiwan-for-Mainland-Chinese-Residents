<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Row and field validation for Import Preview (reuses SpreadsheetValidator rules).
 *
 * Filters: uci_pro_preview_validation_rules, uci_pro_preview_validation_result
 */
class ImportValidationService {

	private static $instance = null;

	/** @var SpreadsheetValidator */
	private $cell_validator;

	/** @var ImportErrorExplanationService */
	private $explanation_service;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->cell_validator        = SpreadsheetValidator::getInstance();
		$this->explanation_service = ImportErrorExplanationService::getInstance();
	}

	/**
	 * Taxonomy-like destination fields.
	 *
	 * @return array<int, string>
	 */
	private function get_taxonomy_fields() {
		return array(
			'post_category',
			'category',
			'post_tag',
			'tags',
			'product_cat',
			'product_tag',
			'taxonomy',
			'term',
			'product_categories',
			'product_tags',
		);
	}

	/**
	 * Fields used as unique identifiers for duplicate detection.
	 *
	 * @return array<int, string>
	 */
	private function get_unique_identifier_fields() {
		return array(
			'ID',
			'post_title',
			'post_name',
			'_sku',
			'PRODUCTSKU',
			'VARIATIONSKU',
			'user_email',
			'user_login',
			'comment_ID',
			'order_id',
		);
	}

	/**
	 * Required fields by import module (when mapped).
	 *
	 * @param string $import_type Import module key.
	 * @return array<int, string>
	 */
	public function get_required_fields_for_type( $import_type ) {
		$import_type = (string) $import_type;
		$defaults    = array(
			'Posts'                 => array( 'post_title' ),
			'Pages'                 => array( 'post_title' ),
			'Users'                 => array( 'user_email' ),
			'WooCommerce'           => array( 'post_title' ),
			'WooCommerceVariations' => array( 'VARIATIONSKU' ),
			'Comments'              => array( 'comment_content' ),
			'Taxonomies'            => array( 'term' ),
		);

		$fields = isset( $defaults[ $import_type ] ) ? $defaults[ $import_type ] : array( 'post_title' );

		if ( in_array( $import_type, array( 'WooCommerce', 'product' ), true ) ) {
			$fields[] = '_sku';
			$fields[] = 'PRODUCTSKU';
		}

		return array_values( array_unique( $fields ) );
	}

	/**
	 * Default validation rules (extensible via filter).
	 *
	 * @param string               $import_type Import module.
	 * @param string               $hash_key    Session hash.
	 * @return array<int, callable>
	 */
	public function get_validation_rules( $import_type, $hash_key ) {
		$service = $this;
		$rules   = array(
			function ( $field, $original, $transformed, $ctx ) use ( $service ) {
				return $service->rule_required_field( $field, $original, $transformed, $ctx );
			},
			function ( $field, $original, $transformed, $ctx ) use ( $service ) {
				return $service->rule_cell_format( $field, $original, $transformed, $ctx );
			},
			function ( $field, $original, $transformed, $ctx ) use ( $service ) {
				return $service->rule_taxonomy( $field, $original, $transformed, $ctx );
			},
			function ( $field, $original, $transformed, $ctx ) use ( $service ) {
				return $service->rule_duplicate_preview( $field, $original, $transformed, $ctx );
			},
			function ( $field, $original, $transformed, $ctx ) use ( $service ) {
				return $service->rule_duplicate_database( $field, $original, $transformed, $ctx );
			},
		);

		return apply_filters( 'uci_pro_preview_validation_rules', $rules, $import_type, $hash_key );
	}

	/**
	 * Validate a single mapped field.
	 *
	 * @param array<string, mixed> $field     Field preview payload.
	 * @param array<string, mixed> $context   Row/import context.
	 * @return array{validation_status:string,issues:array<int,array>}
	 */
	public function validateField( $field, $context = array() ) {
		$issues  = array();
		$import_type = isset( $context['import_type'] ) ? (string) $context['import_type'] : '';
		$hash_key    = isset( $context['hash_key'] ) ? (string) $context['hash_key'] : '';
		$rules       = $this->get_validation_rules( $import_type, $hash_key );

		$destination = isset( $field['destination_field'] ) ? (string) $field['destination_field'] : '';
		$original    = isset( $field['original_value'] ) ? (string) $field['original_value'] : '';
		$transformed = isset( $field['transformed_value'] ) ? (string) $field['transformed_value'] : '';

		$rule_context = array_merge(
			$context,
			array(
				'destination_field' => $destination,
				'source_field'      => isset( $field['source_field'] ) ? (string) $field['source_field'] : '',
				'is_mapped'         => ! empty( $field['is_mapped'] ),
			)
		);

		foreach ( $rules as $rule ) {
			if ( ! is_callable( $rule ) ) {
				continue;
			}
			try {
				$result = call_user_func( $rule, $destination, $original, $transformed, $rule_context );
				if ( is_array( $result ) && ! empty( $result ) ) {
					if ( isset( $result['code'] ) ) {
						$issues[] = $result;
					} else {
						foreach ( $result as $item ) {
							if ( is_array( $item ) && ! empty( $item['code'] ) ) {
								$issues[] = $item;
							}
						}
					}
				}
			} catch ( \Throwable $e ) {
				$issues[] = $this->explanation_service->buildErrorObject(
					'validation_exception',
					'error',
					array_merge(
						$rule_context,
						array(
							'exception_message' => $e->getMessage(),
							'stack_trace'       => $e->getTraceAsString(),
						)
					)
				);
			}
		}

		$status = 'success';
		foreach ( $issues as $issue ) {
			if ( ( $issue['severity'] ?? '' ) === 'error' ) {
				$status = 'error';
				break;
			}
			if ( ( $issue['severity'] ?? '' ) === 'warning' && $status !== 'error' ) {
				$status = 'warning';
			}
		}

		$output = array(
			'validation_status' => $status,
			'issues'            => $issues,
		);

		return apply_filters( 'uci_pro_preview_validation_result', $output, $field, $context );
	}

	/**
	 * Validate all fields in a preview row.
	 *
	 * @param array<string, mixed> $row     Row with fields[].
	 * @param array<string, mixed> $context Import context.
	 * @return array<string, mixed>
	 */
	public function validateRow( $row, $context = array() ) {
		$fields = isset( $row['fields'] ) && is_array( $row['fields'] ) ? $row['fields'] : array();
		$validated_fields = array();
		$row_status       = 'success';

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$result = $this->validateField( $field, $context );
			$field['validation_status'] = $result['validation_status'];
			$field['issues']            = $result['issues'];
			$validated_fields[]         = $field;

			if ( $result['validation_status'] === 'error' ) {
				$row_status = 'error';
			} elseif ( $result['validation_status'] === 'warning' && $row_status !== 'error' ) {
				$row_status = 'warning';
			}
		}

		$row['fields']             = $validated_fields;
		$row['validation_status']  = $row_status;

		return $row;
	}

	/**
	 * Aggregate validation counts across preview rows.
	 *
	 * @param array<int, array<string, mixed>> $rows Preview rows.
	 * @return array{total_rows:int,valid_rows:int,warning_rows:int,error_rows:int}
	 */
	public function getValidationSummary( $rows ) {
		$summary = array(
			'total_rows'   => count( $rows ),
			'valid_rows'   => 0,
			'warning_rows' => 0,
			'error_rows'   => 0,
		);

		foreach ( $rows as $row ) {
			$status = isset( $row['validation_status'] ) ? $row['validation_status'] : 'success';
			if ( $status === 'error' ) {
				++$summary['error_rows'];
			} elseif ( $status === 'warning' ) {
				++$summary['warning_rows'];
			} else {
				++$summary['valid_rows'];
			}
		}

		return $summary;
	}

	/**
	 * Required field rule.
	 *
	 * @param string               $field       Destination field.
	 * @param string               $original    Original value.
	 * @param string               $transformed Transformed value.
	 * @param array<string, mixed> $context     Context.
	 * @return array<string, mixed>|null
	 */
	private function rule_required_field( $field, $original, $transformed, $context ) {
		if ( empty( $context['is_mapped'] ) ) {
			return null;
		}

		$import_type = isset( $context['import_type'] ) ? (string) $context['import_type'] : '';
		$required    = $this->get_required_fields_for_type( $import_type );

		if ( ! in_array( $field, $required, true ) ) {
			return null;
		}

		if ( trim( $transformed ) !== '' ) {
			return null;
		}

		$code = ( in_array( $field, array( '_sku', 'PRODUCTSKU' ), true ) ) ? 'missing_sku' : 'missing_required_field';

		return $this->explanation_service->buildErrorObject( $code, 'error', $context );
	}

	/**
	 * Email, URL, date, and post status validation via SpreadsheetValidator.
	 *
	 * @param string               $field       Destination field.
	 * @param string               $original    Original value.
	 * @param string               $transformed Transformed value.
	 * @param array<string, mixed> $context     Context.
	 * @return array<string, mixed>|null
	 */
	private function rule_cell_format( $field, $original, $transformed, $context ) {
		$value = trim( $transformed ) !== '' ? $transformed : $original;
		if ( $value === '' ) {
			return null;
		}

		$import_type = isset( $context['import_type'] ) ? (string) $context['import_type'] : '';
		$res         = $this->cell_validator->validate_cell( $value, $field, $import_type );

		if ( empty( $res['level'] ) || $res['level'] === 'ok' ) {
			return null;
		}

		$code_map = array(
			'Invalid email address.'           => 'invalid_email',
			'Invalid date format.'             => 'invalid_date',
			'URL may be invalid or unreachable.' => 'invalid_url',
			'Invalid post status.'             => 'invalid_post_status',
			'Unbalanced HTML tags.'            => 'unbalanced_html',
		);

		$message = isset( $res['message'] ) ? (string) $res['message'] : '';
		$code    = 'invalid_email';
		foreach ( $code_map as $needle => $mapped ) {
			if ( stripos( $message, str_replace( '.', '', $needle ) ) !== false || $message === $needle ) {
				$code = $mapped;
				break;
			}
		}

		if ( stripos( $message, 'email' ) !== false ) {
			$code = 'invalid_email';
		} elseif ( stripos( $message, 'date' ) !== false ) {
			$code = 'invalid_date';
		} elseif ( stripos( $message, 'url' ) !== false ) {
			$code = 'invalid_url';
		} elseif ( stripos( $message, 'status' ) !== false ) {
			$code = 'invalid_post_status';
		} elseif ( stripos( $message, 'html' ) !== false ) {
			$code = 'unbalanced_html';
		}

		return $this->explanation_service->buildErrorObject(
			$code,
			$res['level'] === 'error' ? 'error' : 'warning',
			$context
		);
	}

	/**
	 * Taxonomy empty check when field is mapped.
	 *
	 * @param string               $field       Destination field.
	 * @param string               $original    Original value.
	 * @param string               $transformed Transformed value.
	 * @param array<string, mixed> $context     Context.
	 * @return array<string, mixed>|null
	 */
	private function rule_taxonomy( $field, $original, $transformed, $context ) {
		if ( empty( $context['is_mapped'] ) ) {
			return null;
		}

		$field_lower = strtolower( $field );
		$is_tax      = false;
		foreach ( $this->get_taxonomy_fields() as $tax_field ) {
			if ( $field_lower === strtolower( $tax_field ) || strpos( $field_lower, 'tax' ) !== false ) {
				$is_tax = true;
				break;
			}
		}

		if ( ! $is_tax ) {
			return null;
		}

		$value = trim( $transformed ) !== '' ? $transformed : $original;
		if ( $value !== '' ) {
			return null;
		}

		return $this->explanation_service->buildErrorObject( 'invalid_taxonomy', 'error', $context );
	}

	/**
	 * Duplicate unique identifier within preview batch.
	 *
	 * @param string               $field       Destination field.
	 * @param string               $original    Original value.
	 * @param string               $transformed Transformed value.
	 * @param array<string, mixed> $context     Context.
	 * @return array<string, mixed>|null
	 */
	private function rule_duplicate_preview( $field, $original, $transformed, $context ) {
		if ( ! in_array( $field, $this->get_unique_identifier_fields(), true ) ) {
			return null;
		}

		$value = trim( $transformed ) !== '' ? $transformed : trim( $original );
		if ( $value === '' ) {
			return null;
		}

		$seen_key = $field . '::' . strtolower( $value );
		if ( ! isset( $context['seen_identifiers'] ) || ! is_array( $context['seen_identifiers'] ) ) {
			return null;
		}

		if ( isset( $context['seen_identifiers'][ $seen_key ] ) && (int) $context['seen_identifiers'][ $seen_key ] !== (int) ( $context['row_number'] ?? 0 ) ) {
			return $this->explanation_service->buildErrorObject( 'duplicate_in_preview', 'error', $context );
		}

		return null;
	}

	/**
	 * Duplicate unique identifier against existing WordPress records.
	 *
	 * @param string               $field       Destination field.
	 * @param string               $original    Original value.
	 * @param string               $transformed Transformed value.
	 * @param array<string, mixed> $context     Context.
	 * @return array<string, mixed>|null
	 */
	private function rule_duplicate_database( $field, $original, $transformed, $context ) {
		if ( ! in_array( $field, $this->get_unique_identifier_fields(), true ) ) {
			return null;
		}

		$value = trim( $transformed ) !== '' ? $transformed : trim( $original );
		if ( $value === '' ) {
			return null;
		}

		$exists = false;

		if ( $field === 'user_email' && is_email( $value ) ) {
			$exists = (bool) email_exists( $value );
		} elseif ( $field === 'user_login' ) {
			$exists = (bool) username_exists( $value );
		} elseif ( in_array( $field, array( '_sku', 'PRODUCTSKU' ), true ) && function_exists( 'wc_get_product_id_by_sku' ) ) {
			$exists = (bool) wc_get_product_id_by_sku( wc_clean( $value ) );
		} elseif ( $field === 'post_title' ) {
			global $wpdb;
			$exists = (bool) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_status != 'trash' LIMIT 1",
					$value
				)
			);
		} elseif ( $field === 'ID' && is_numeric( $value ) ) {
			$exists = (bool) get_post( (int) $value );
		}

		if ( ! $exists ) {
			return null;
		}

		return $this->explanation_service->buildErrorObject( 'duplicate_unique_id', 'warning', $context );
	}
}
