<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maps validation error codes to external documentation URLs for the Import Preview UI.
 *
 * Filter: uci_pro_error_documentation_links
 */
class ErrorDocumentationRegistry {

	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Default documentation URLs keyed by validation error code.
	 *
	 * @return array<string, string>
	 */
	public function get_default_links() {
		$base = 'https://www.smackcoders.com/documentation/wp-ultimate-csv-importer-pro/';

		return array(
			'missing_required_field' => $base . 'field-mapping-required-fields',
			'missing_sku'            => $base . 'woocommerce-product-import-sku',
			'invalid_email'          => $base . 'import-validation-email',
			'invalid_url'            => $base . 'import-validation-url',
			'invalid_taxonomy'       => $base . 'import-taxonomy-mapping',
			'invalid_date'           => $base . 'import-date-formats',
			'duplicate_unique_id'    => $base . 'duplicate-handling',
			'duplicate_in_preview'   => $base . 'duplicate-handling',
			'invalid_post_status'    => $base . 'post-status-import',
			'unbalanced_html'        => $base . 'html-content-import',
		);
	}

	/**
	 * Resolve documentation URL for an error code.
	 *
	 * @param string $code Validation error code.
	 * @return string|null
	 */
	public function get_link( $code ) {
		$code  = sanitize_key( $code );
		$links = apply_filters( 'uci_pro_error_documentation_links', $this->get_default_links() );

		if ( ! is_array( $links ) || empty( $links[ $code ] ) ) {
			return null;
		}

		return esc_url( $links[ $code ] );
	}

	/**
	 * Whether a documentation link exists for the given code.
	 *
	 * @param string $code Validation error code.
	 * @return bool
	 */
	public function has_link( $code ) {
		return null !== $this->get_link( $code );
	}
}
