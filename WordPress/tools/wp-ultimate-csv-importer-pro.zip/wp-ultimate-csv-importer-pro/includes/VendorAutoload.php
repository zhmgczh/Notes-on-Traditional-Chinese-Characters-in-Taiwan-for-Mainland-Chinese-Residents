<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load Composer vendor autoload only when import/export features need it.
 * Avoids registering Guzzle and other shared libraries on every admin request.
 */
function load_vendor_autoload(): void {
	static $loaded = false;

	if ( $loaded ) {
		return;
	}

	$autoload = dirname( __DIR__ ) . '/vendor/autoload.php';
	if ( is_readable( $autoload ) ) {
		require_once $autoload;
		$loaded = true;
	}
}
