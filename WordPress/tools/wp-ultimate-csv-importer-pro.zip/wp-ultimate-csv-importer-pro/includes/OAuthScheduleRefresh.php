<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Proactive OAuth token refresh before scheduled cloud import batches (#1442).
 */
class OAuthScheduleRefresh {

	const DEFAULT_BUFFER_SECONDS = 300;

	/**
	 * Refresh Google Sheets listing credentials when expiry is within buffer.
	 *
	 * @param int $buffer_seconds Seconds before expiry to refresh.
	 * @return array{success: bool, message?: string}
	 */
	public static function ensure_gsheet_listing_token( $buffer_seconds = self::DEFAULT_BUFFER_SECONDS ) {
		$credentials = maybe_unserialize( get_option( 'gsheetlisting_oauth_credentials' ) );
		if ( ! is_array( $credentials ) || empty( $credentials['access_token'] ) ) {
			return array( 'success' => true );
		}

		$expiry = isset( $credentials['expires_in'] ) ? (int) $credentials['expires_in'] : 0;
		$buffer = (int) apply_filters( 'sm_uci_pro_oauth_refresh_buffer', $buffer_seconds );

		if ( $expiry > time() + $buffer ) {
			return array( 'success' => true );
		}

		if ( empty( $credentials['refresh_token'] ) || empty( $credentials['client_id'] ) || empty( $credentials['client_secret'] ) ) {
			return array(
				'success' => false,
				'message' => 'Google Sheets token expired and refresh token is missing.',
			);
		}

		$response = GoogleSheetsHttpTransport::remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
				'body'    => http_build_query(
					array(
						'client_id'     => $credentials['client_id'],
						'client_secret' => $credentials['client_secret'],
						'refresh_token' => $credentials['refresh_token'],
						'grant_type'    => 'refresh_token',
					)
				),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['access_token'] ) ) {
			$error = isset( $body['error_description'] ) ? $body['error_description'] : 'Google Sheets token refresh failed.';
			return array(
				'success' => false,
				'message' => $error,
			);
		}

		$credentials['access_token'] = sanitize_text_field( $body['access_token'] );
		$credentials['expires_in']   = time() + (int) ( $body['expires_in'] ?? 3600 );
		update_option( 'gsheetlisting_oauth_credentials', maybe_serialize( $credentials ) );

		return array( 'success' => true );
	}

	/**
	 * Refresh google_sheet_credentials (export / alternate OAuth handler).
	 *
	 * @param int $buffer_seconds Seconds before expiry to refresh.
	 * @return array{success: bool, message?: string}
	 */
	public static function ensure_google_sheet_credentials_token( $buffer_seconds = self::DEFAULT_BUFFER_SECONDS ) {
		$credentials = maybe_unserialize( get_option( 'google_sheet_credentials' ) );
		if ( ! is_array( $credentials ) || empty( $credentials['access_token'] ) ) {
			return array( 'success' => true );
		}

		$expiry = isset( $credentials['expires_at'] ) ? (int) $credentials['expires_at'] : 0;
		$buffer = (int) apply_filters( 'sm_uci_pro_oauth_refresh_buffer', $buffer_seconds );

		if ( $expiry > time() + $buffer ) {
			return array( 'success' => true );
		}

		if ( empty( $credentials['refresh_token'] ) || empty( $credentials['client_id'] ) || empty( $credentials['client_secret'] ) ) {
			return array(
				'success' => false,
				'message' => 'Google Sheets OAuth token expired and refresh token is missing.',
			);
		}

		$response = GoogleSheetsHttpTransport::remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
				'body'    => array(
					'client_id'     => $credentials['client_id'],
					'client_secret' => $credentials['client_secret'],
					'refresh_token' => $credentials['refresh_token'],
					'grant_type'    => 'refresh_token',
				),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['access_token'] ) ) {
			$error = isset( $body['error_description'] ) ? $body['error_description'] : 'Google OAuth token refresh failed.';
			return array(
				'success' => false,
				'message' => $error,
			);
		}

		$credentials['access_token'] = $body['access_token'];
		$credentials['expires_at']   = time() + (int) ( $body['expires_in'] ?? 3600 );
		update_option( 'google_sheet_credentials', maybe_serialize( $credentials ) );

		return array( 'success' => true );
	}

	/**
	 * Refresh Google Drive OAuth credentials when expiry is within buffer.
	 *
	 * @param int $buffer_seconds Seconds before expiry to refresh.
	 * @return array{success: bool, message?: string}
	 */
	public static function ensure_gdrive_token( $buffer_seconds = self::DEFAULT_BUFFER_SECONDS ) {
		if ( ! class_exists( GoogleDriveOAuthHandler::class ) ) {
			return array( 'success' => true );
		}

		$handler = GoogleDriveOAuthHandler::getInstance();
		if ( ! method_exists( $handler, 'ensure_access_token_for_schedule' ) ) {
			return array( 'success' => true );
		}

		return $handler->ensure_access_token_for_schedule( $buffer_seconds );
	}

	/**
	 * Refresh all known Google OAuth credential stores before a schedule batch.
	 *
	 * @return array{success: bool, message?: string}
	 */
	public static function ensure_all_for_schedule() {
		foreach ( array( 'ensure_gsheet_listing_token', 'ensure_google_sheet_credentials_token', 'ensure_gdrive_token' ) as $method ) {
			$result = self::$method();
			if ( empty( $result['success'] ) ) {
				return $result;
			}
		}
		return array( 'success' => true );
	}
}
