<?php
/**
 * Bootstrap helper for Importer_Dependency_Manager.
 *
 * @package Smackcoders\ImporterDependency
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load the shared dependency manager class from the first available Pro plugin.
 *
 * @return void
 */
	function smack_importer_load_dependency_manager_class() {
		if ( class_exists( 'Importer_Dependency_Manager' ) ) {
			return;
		}

		$candidate_paths = array(
			WP_PLUGIN_DIR . '/wp-ultimate-csv-importer-pro/includes/class-importer-dependency-manager.php',
			WP_PLUGIN_DIR . '/wp-importer-custom-fields-basic-pro/includes/class-importer-dependency-manager.php',
			WP_PLUGIN_DIR . '/wordpress-importer-for-wpml-pro/includes/class-importer-dependency-manager.php',
		);

		foreach ( $candidate_paths as $path ) {
			if ( file_exists( $path ) ) {
				require_once $path;
				break;
			}
		}
	}

/**
 * Initialize dependency manager for a Pro plugin.
 *
 * @param array<string, mixed> $config Pro plugin configuration.
 * @return Importer_Dependency_Manager|null
 */
	function smack_importer_dependency_manager_init( array $config ) {
		smack_importer_load_dependency_manager_class();

		if ( ! class_exists( 'Importer_Dependency_Manager' ) ) {
			return null;
		}

		$manager = Importer_Dependency_Manager::get_instance( $config );
		$manager->bootstrap();

		return $manager;
	}

/**
 * Resolve dependency manager asset base URL for shared CSS/JS.
 *
 * @param string $plugin_url Fallback plugin URL.
 * @return string
 */
	function smack_importer_dependency_asset_base_url( $plugin_url ) {
		$paths = array(
			WP_PLUGIN_DIR . '/wp-ultimate-csv-importer-pro/assets/js/dependency-manager.js' => plugins_url( 'assets/', WP_PLUGIN_DIR . '/wp-ultimate-csv-importer-pro/wp-ultimate-csv-importer-pro.php' ),
			WP_PLUGIN_DIR . '/wp-importer-custom-fields-basic-pro/assets/js/dependency-manager.js' => plugins_url( 'assets/', WP_PLUGIN_DIR . '/wp-importer-custom-fields-basic-pro/wp-importer-custom-fields-basic-pro.php' ),
			WP_PLUGIN_DIR . '/wordpress-importer-for-wpml-pro/assets/js/dependency-manager.js' => plugins_url( 'assets/', WP_PLUGIN_DIR . '/wordpress-importer-for-wpml-pro/wordpress-importer-wpml-pro.php' ),
		);

		foreach ( $paths as $file => $url ) {
			if ( file_exists( $file ) ) {
				return $url;
			}
		}

		return trailingslashit( $plugin_url );
	}
