<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Centralized module loading for #1442.
 *
 * Phase 2–3: optional bootstraps + builders / GSheet / media / woo native.
 * Phase 4: hook_system stub is loaded from wp-csv-custom-hooks.php;
 * spreadsheet / preview / retry / resume are gated in the main plugin bootstrap.
 */
class FeatureLoader {

	/**
	 * Load extension globs and feature bootstraps.
	 */
	public static function load_all() {
		self::load_core();
		self::load_features();
	}

	/**
	 * Whether Phase 4 optional service files should be considered loaded.
	 *
	 * @param string $feature_id FeatureRegistry ID.
	 * @return bool
	 */
	public static function is_phase4_service_active( $feature_id ) {
		return FeatureRegistry::is_enabled( $feature_id );
	}

	/**
	 * @param string $basename File basename.
	 * @return bool
	 */
	public static function should_load_upload_module( $basename ) {
		if ( 'GsheetUpload.php' === $basename && ! FeatureRegistry::is_enabled( 'google_sheets' ) ) {
			return false;
		}
		return true;
	}

	/**
	 * @param string $basename File basename.
	 * @return bool
	 */
	public static function should_load_extension_module( $basename ) {
		$toggle_map = array(
			'WPBakeryExtension.php' => 'wpbakery',
			'BricksExtension.php'    => 'bricks_builder',
			'OxygenExtension.php'    => 'oxygen_builder',
		);

		if ( isset( $toggle_map[ $basename ] ) ) {
			return FeatureRegistry::is_enabled( $toggle_map[ $basename ] );
		}

		return true;
	}

	/**
	 * @param string $basename File basename.
	 * @return bool
	 */
	public static function should_load_import_extension( $basename ) {
		$toggle_map = array(
			'WPBakeryImport.php' => 'wpbakery',
			'BricksImport.php'   => 'bricks_builder',
			'OxygenImport.php'   => 'oxygen_builder',
		);

		if ( isset( $toggle_map[ $basename ] ) ) {
			return FeatureRegistry::is_enabled( $toggle_map[ $basename ] );
		}

		return true;
	}

	/**
	 * @param string $basename File basename.
	 * @return bool
	 */
	public static function should_load_export_extension( $basename ) {
		$toggle_map = array(
			'WPBakeryExport.php' => 'wpbakery',
			'BricksExport.php'   => 'bricks_builder',
			'OxygenExport.php'   => 'oxygen_builder',
		);

		if ( isset( $toggle_map[ $basename ] ) ) {
			return FeatureRegistry::is_enabled( $toggle_map[ $basename ] );
		}

		return true;
	}

	/**
	 * Core import/export extension globs (always required for baseline I/E).
	 */
	public static function load_core() {
		$base = WCSVPLUGINDIR;

		$extension_uploader = glob( $base . 'extensionUploader/*.php' );
		if ( is_array( $extension_uploader ) ) {
			foreach ( $extension_uploader as $extension_upload_value ) {
				require_once $extension_upload_value;
			}
		}

		require_once $base . 'uploadModules/RemoteSourceProvider.php';

		$upload_modules = glob( $base . 'uploadModules/*.php' );
		if ( is_array( $upload_modules ) ) {
			foreach ( $upload_modules as $upload_module_value ) {
				if ( ! self::should_load_upload_module( basename( $upload_module_value ) ) ) {
					continue;
				}
				require_once $upload_module_value;
			}
		}

		$extension_modules = glob( $base . 'extensionModules/*.php' );
		if ( is_array( $extension_modules ) ) {
			foreach ( $extension_modules as $extension_module_value ) {
				if ( ! self::should_load_extension_module( basename( $extension_module_value ) ) ) {
					continue;
				}
				require_once $extension_module_value;
			}
		}

		$export_modules = glob( $base . 'exportExtensions/*.php' );
		if ( is_array( $export_modules ) ) {
			foreach ( $export_modules as $export_module_value ) {
				if ( ! self::should_load_export_extension( basename( $export_module_value ) ) ) {
					continue;
				}
				require_once $export_module_value;
			}
		}

		$manager_extension = glob( $base . 'managerExtensions/*.php' );
		if ( is_array( $manager_extension ) ) {
			foreach ( $manager_extension as $manager_extension_value ) {
				require_once $manager_extension_value;
			}
		}

		$import_extensions = glob( $base . 'importExtensions/*.php' );
		if ( is_array( $import_extensions ) ) {
			foreach ( $import_extensions as $import_extension_value ) {
				if ( ! self::should_load_import_extension( basename( $import_extension_value ) ) ) {
					continue;
				}
				require_once $import_extension_value;
			}
		}
	}

	/**
	 * Optional feature modules and bootstrap inits.
	 */
	public static function load_features() {
		$base = WCSVPLUGINDIR;

		$migration_modules = glob( $base . 'migrationModules/WooToSureCart/*.php' );
		if ( is_array( $migration_modules ) ) {
			foreach ( $migration_modules as $migration_module_value ) {
				require_once $migration_module_value;
			}
		}

		$migration_migrators = glob( $base . 'migrationModules/WooToSureCart/Migrators/*.php' );
		if ( is_array( $migration_migrators ) ) {
			foreach ( $migration_migrators as $migrator_value ) {
				require_once $migrator_value;
			}
		}

		if ( FeatureRegistry::is_enabled( 'ai_import' ) ) {
			$ai_features = glob( $base . 'ai/*.php' );
			if ( is_array( $ai_features ) ) {
				foreach ( $ai_features as $ai_feature_value ) {
					require_once $ai_feature_value;
				}
			}

			require_once $base . 'AI/AIBootstrap.php';
			AI\AIBootstrap::init();

			$ai_duplicate_detectors = glob( $base . 'ai/DuplicateDetector/*.php' );
			if ( is_array( $ai_duplicate_detectors ) ) {
				foreach ( $ai_duplicate_detectors as $ai_duplicate_detector_value ) {
					require_once $ai_duplicate_detector_value;
				}
			}
		}

		if ( FeatureRegistry::is_enabled( 'db_migration' ) ) {
			require_once $base . 'databaseMigration/DatabaseMigrationBootstrap.php';
			DatabaseMigration\DatabaseMigrationBootstrap::init();
		}

		if ( FeatureRegistry::is_enabled( 'automation_api' ) ) {
			require_once $base . 'automation/AutomationBootstrap.php';
			Automation\AutomationBootstrap::init();
		}

		if ( FeatureRegistry::is_enabled( 'media_queue' ) ) {
			require_once $base . 'media/MediaBootstrap.php';
			Media\MediaBootstrap::init();
		}

		if ( FeatureRegistry::is_enabled( 'woo_native_csv' ) ) {
			require_once $base . 'compatibility/WooCommerceNative/Bootstrap.php';
			WooCommerceNative\Bootstrap::init();
		}

		if ( class_exists( 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\MigrationController' ) ) {
			MigrationController::getInstance();
		}
	}
}
