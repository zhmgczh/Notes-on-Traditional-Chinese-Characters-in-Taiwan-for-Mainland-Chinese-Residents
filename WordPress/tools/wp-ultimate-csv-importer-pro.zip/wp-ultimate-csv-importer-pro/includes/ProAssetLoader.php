<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve Pro plugin asset URLs with optional fallback to the free plugin bundle.
 */
function get_pro_asset_url( $relative_path ) {
	$relative_path = ltrim( (string) $relative_path, '/' );
	$pro_root      = trailingslashit( WCSVPLUGINDIR );
	$pro_file      = WCSVPLUGINDIR . 'wp-ultimate-csv-importer-pro.php';

	if ( file_exists( $pro_root . $relative_path ) ) {
		return plugins_url( $relative_path, $pro_file );
	}

	$aliases = array(
		'assets/js/deps/jQueryFileTree.min.js' => 'assets/js/deps/jQueryFileTree.min_n.js',
	);

	if ( isset( $aliases[ $relative_path ] ) && file_exists( $pro_root . $aliases[ $relative_path ] ) ) {
		return plugins_url( $aliases[ $relative_path ], $pro_file );
	}

	$free_bootstrap = WP_PLUGIN_DIR . '/wp-ultimate-csv-importer/wp-ultimate-csv-importer.php';
	if ( file_exists( $free_bootstrap ) ) {
		$free_root = trailingslashit( dirname( $free_bootstrap ) );
		if ( file_exists( $free_root . $relative_path ) ) {
			return plugins_url( $relative_path, $free_bootstrap );
		}
	}

	return plugins_url( $relative_path, $pro_file );
}

/**
 * Stable script/style handle prefix for Pro admin assets.
 */
function get_pro_asset_handle_prefix() {
	return 'wsmack-uci-pro-';
}
