<?php
/**
 * Encrypt FTP/SFTP schedule credentials at rest (reuses DB migration cipher).
 *
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ScheduleCredentialCipher {

	/**
	 * @param string $plain Plaintext password.
	 * @return string Stored value (encrypted when possible).
	 */
	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( $plain === '' ) {
			return '';
		}
		self::load_cipher();
		if ( ! class_exists( __NAMESPACE__ . '\\DatabaseMigration\\Services\\CredentialCipher' ) ) {
			return $plain;
		}
		$enc = \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\CredentialCipher::encrypt( $plain );
		return $enc !== '' ? $enc : $plain;
	}

	/**
	 * @param string $stored DB value (encrypted or legacy plaintext).
	 * @return string Plaintext password.
	 */
	public static function decrypt( $stored ) {
		$stored = (string) $stored;
		if ( $stored === '' ) {
			return '';
		}
		self::load_cipher();
		if ( class_exists( __NAMESPACE__ . '\\DatabaseMigration\\Services\\CredentialCipher' ) ) {
			$dec = \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\CredentialCipher::decrypt( $stored );
			if ( $dec !== '' ) {
				return $dec;
			}
		}
		return $stored;
	}

	private static function load_cipher() {
		static $loaded = false;
		if ( $loaded ) {
			return;
		}
		$path = __DIR__ . '/../databaseMigration/Services/CredentialCipher.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
		$loaded = true;
	}
}
