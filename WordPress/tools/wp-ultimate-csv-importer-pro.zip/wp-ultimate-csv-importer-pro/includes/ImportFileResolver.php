<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves the on-disk import file path for a hash (original vs spreadsheet-edited copy).
 */
class ImportFileResolver {

	/** @var self|null */
	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @param string      $hash_key   Import event hash.
	 * @param string|null $upload_dir Optional uploads directory (trailing slash).
	 * @return string Absolute file path.
	 */
	public function resolve_import_file_path( $hash_key, $upload_dir = null ) {
		if ( null === $upload_dir ) {
			$upload_dir = UltimatePro::getInstance()->create_upload_dir();
		}
		$hash_key = sanitize_key( $hash_key );
		$edited   = $upload_dir . $hash_key . '/' . $hash_key . '_edited';
		$original = $upload_dir . $hash_key . '/' . $hash_key;
		if ( get_option( 'sm_uci_editor_active_' . $hash_key ) && file_exists( $edited ) ) {
			return $edited;
		}
		return $original;
	}
}
