<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-batch export state holder (#1442 Phase 3).
 *
 * Batch lifecycle (see ExportExtension):
 * - fetch_batch  → post IDs loaded into context
 * - format_batch → row data accumulated in ExportExtension::$data / temp_data
 * - write_batch  → finalDataToExport() + proceedExport()
 * - cleanup_batch → destroy(), ACF cache clear, GC
 *
 * Isolates scratch arrays, query offsets, module iterators, and module-specific
 * caches so ExportExtension can release memory after each AJAX batch without
 * retaining data on the export singleton.
 */
class ExportBatchContext {

	/** @var int Zero-based batch sequence within one export run. */
	private $batch_index = 0;

	/** @var int Query offset for the current batch. */
	private $offset = 0;

	/** @var int Maximum records to process in the current batch. */
	private $limit = 0;

	/** @var string Export module identifier (e.g. Posts, CustomPosts). */
	private $module = '';

	/** @var string Optional post type / sub-module slug. */
	private $optional_type = '';

	/** @var int[] Post IDs fetched for the current batch. */
	private $post_ids = array();

	/** @var array<int|string,mixed> Row data accumulated while formatting the batch. */
	private $temp_data = array();

	/** @var string[] Header column list for the current batch write. */
	private $headers = array();

	/**
	 * Module-specific iterators (Meta Box cloneable group index, ACF repeater row, etc.).
	 *
	 * @var array<string,mixed>
	 */
	private $iterators = array();

	/**
	 * Module-specific caches scoped to the current batch (ACF structure, Jet fields, etc.).
	 *
	 * @var array<string,mixed>
	 */
	private $module_caches = array();

	/** @var int Memory usage in bytes when the context was created. */
	private $start_memory_bytes = 0;

	/** @var int Highest observed memory usage for this context instance. */
	private $peak_memory_bytes = 0;

	/**
	 * @param array<string,mixed> $args Optional initial state:
	 *                                  offset, limit, module, optional_type, post_ids, headers, batch_index.
	 */
	public function __construct( array $args = array() ) {
		$this->start_memory_bytes = memory_get_usage( true );
		$this->peak_memory_bytes  = $this->start_memory_bytes;

		if ( ! empty( $args ) ) {
			$this->apply_args( $args );
		}
	}

	/**
	 * Apply export parameters for a batch.
	 *
	 * @param array<string,mixed> $args offset, limit, module, optional_type, post_ids, headers, batch_index.
	 * @return void
	 */
	public function apply_args( array $args ) {
		if ( array_key_exists( 'batch_index', $args ) ) {
			$this->batch_index = max( 0, (int) $args['batch_index'] );
		}
		if ( array_key_exists( 'offset', $args ) ) {
			$this->offset = max( 0, (int) $args['offset'] );
		}
		if ( array_key_exists( 'limit', $args ) ) {
			$this->limit = max( 0, (int) $args['limit'] );
		}
		if ( array_key_exists( 'module', $args ) ) {
			$this->module = sanitize_text_field( (string) $args['module'] );
		}
		if ( array_key_exists( 'optional_type', $args ) ) {
			$this->optional_type = sanitize_text_field( (string) $args['optional_type'] );
		}
		if ( array_key_exists( 'post_ids', $args ) && is_array( $args['post_ids'] ) ) {
			$this->post_ids = array_values( array_map( 'intval', $args['post_ids'] ) );
		}
		if ( array_key_exists( 'headers', $args ) && is_array( $args['headers'] ) ) {
			$this->headers = array_values( $args['headers'] );
		}
	}

	/**
	 * Clear batch-scoped state and advance to the next batch index.
	 *
	 * Retains module, optional_type, offset, and limit so the caller can update
	 * offset/limit for the next batch without reconfiguring the context.
	 *
	 * @return void
	 */
	public function reset() {
		$this->post_ids      = array();
		$this->temp_data     = array();
		$this->headers       = array();
		$this->iterators     = array();
		$this->module_caches = array();
		$this->batch_index++;
		$this->record_memory_peak();
	}

	/**
	 * Fully tear down batch state and encourage memory release.
	 *
	 * @return void
	 */
	public function destroy() {
		$this->batch_index     = 0;
		$this->offset          = 0;
		$this->limit           = 0;
		$this->module          = '';
		$this->optional_type   = '';
		$this->post_ids        = array();
		$this->temp_data       = array();
		$this->headers         = array();
		$this->iterators       = array();
		$this->module_caches   = array();
		$this->record_memory_peak();

		if ( function_exists( 'gc_collect_cycles' ) ) {
			gc_collect_cycles();
		}
	}

	/**
	 * Return current and peak memory usage for this context.
	 *
	 * @return array{current_bytes:int,peak_bytes:int,start_bytes:int,delta_bytes:int,batch_index:int}
	 */
	public function get_memory_usage() {
		$this->record_memory_peak();

		$current = memory_get_usage( true );
		$peak    = max( memory_get_peak_usage( true ), $this->peak_memory_bytes );

		return array(
			'current_bytes' => (int) $current,
			'peak_bytes'    => (int) $peak,
			'start_bytes'   => (int) $this->start_memory_bytes,
			'delta_bytes'   => (int) ( $current - $this->start_memory_bytes ),
			'batch_index'   => (int) $this->batch_index,
		);
	}

	/**
	 * @return int
	 */
	public function get_batch_index() {
		return $this->batch_index;
	}

	/**
	 * @return int
	 */
	public function get_offset() {
		return $this->offset;
	}

	/**
	 * @param int $offset Query offset.
	 * @return void
	 */
	public function set_offset( $offset ) {
		$this->offset = max( 0, (int) $offset );
	}

	/**
	 * @return int
	 */
	public function get_limit() {
		return $this->limit;
	}

	/**
	 * @param int $limit Batch size.
	 * @return void
	 */
	public function set_limit( $limit ) {
		$this->limit = max( 0, (int) $limit );
	}

	/**
	 * @return string
	 */
	public function get_module() {
		return $this->module;
	}

	/**
	 * @return string
	 */
	public function get_optional_type() {
		return $this->optional_type;
	}

	/**
	 * @return int[]
	 */
	public function get_post_ids() {
		return $this->post_ids;
	}

	/**
	 * @param int[] $post_ids Post IDs for the current batch.
	 * @return void
	 */
	public function set_post_ids( array $post_ids ) {
		$this->post_ids = array_values( array_map( 'intval', $post_ids ) );
	}

	/**
	 * @return array<int|string,mixed>
	 */
	public function get_temp_data() {
		return $this->temp_data;
	}

	/**
	 * @param array<int|string,mixed> $temp_data Batch row data.
	 * @return void
	 */
	public function set_temp_data( array $temp_data ) {
		$this->temp_data = $temp_data;
	}

	/**
	 * @param int|string $record_id Record key.
	 * @param mixed      $row       Formatted row payload.
	 * @return void
	 */
	public function set_temp_row( $record_id, $row ) {
		$this->temp_data[ $record_id ] = $row;
	}

	/**
	 * @return string[]
	 */
	public function get_headers() {
		return $this->headers;
	}

	/**
	 * @param string[] $headers Header column list.
	 * @return void
	 */
	public function set_headers( array $headers ) {
		$this->headers = array_values( $headers );
	}

	/**
	 * @param string $key Iterator key (e.g. metabox_group, acf_repeater).
	 * @return mixed|null
	 */
	public function get_iterator( $key ) {
		$key = (string) $key;
		return array_key_exists( $key, $this->iterators ) ? $this->iterators[ $key ] : null;
	}

	/**
	 * @param string $key   Iterator key.
	 * @param mixed  $value Iterator state.
	 * @return void
	 */
	public function set_iterator( $key, $value ) {
		$this->iterators[ (string) $key ] = $value;
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get_iterators() {
		return $this->iterators;
	}

	/**
	 * @param string $key Cache key.
	 * @return mixed|null
	 */
	public function get_module_cache( $key ) {
		$key = (string) $key;
		return array_key_exists( $key, $this->module_caches ) ? $this->module_caches[ $key ] : null;
	}

	/**
	 * @param string $key   Cache key.
	 * @param mixed  $value Cached value.
	 * @return void
	 */
	public function set_module_cache( $key, $value ) {
		$this->module_caches[ (string) $key ] = $value;
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get_module_caches() {
		return $this->module_caches;
	}

	/**
	 * Update tracked peak memory for this context.
	 *
	 * @return void
	 */
	private function record_memory_peak() {
		$current = memory_get_usage( true );
		$peak    = memory_get_peak_usage( true );

		if ( $current > $this->peak_memory_bytes ) {
			$this->peak_memory_bytes = $current;
		}
		if ( $peak > $this->peak_memory_bytes ) {
			$this->peak_memory_bytes = $peak;
		}
	}
}
