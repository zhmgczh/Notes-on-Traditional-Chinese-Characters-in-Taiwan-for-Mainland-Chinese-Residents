<?php
/**
 * Shared dependency manager for WP Ultimate CSV Importer Pro add-ons.
 *
 * Ensures the free WP Ultimate CSV Importer plugin is installed and active
 * before Pro features load. Provides guided onboarding via admin modal and AJAX.
 *
 * @package Smackcoders\ImporterDependency
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Importer_Dependency_Manager' ) ) {

	/**
	 * Manages free-plugin dependency checks, onboarding UI, and AJAX install/activate flows.
	 */
	class Importer_Dependency_Manager {

		/**
		 * Free plugin bootstrap file relative to wp-content/plugins.
		 */
		public const FREE_PLUGIN_FILE = 'wp-ultimate-csv-importer/wp-ultimate-csv-importer.php';

		/**
		 * WordPress.org plugin slug.
		 */
		public const FREE_PLUGIN_SLUG = 'wp-ultimate-csv-importer';

		/**
		 * Manual installation documentation URL.
		 */
		public const MANUAL_INSTALL_URL = 'https://wordpress.org/plugins/wp-ultimate-csv-importer/';

		/**
		 * Registered manager instances keyed by pro plugin basename.
		 *
		 * @var array<string, self>
		 */
		private static $instances = array();

		/**
		 * Pro plugin configuration.
		 *
		 * @var array<string, mixed>
		 */
		private $config = array();

		/**
		 * Whether bootstrap hooks have been registered.
		 *
		 * @var bool
		 */
		private $bootstrapped = false;

		/**
		 * Whether shared AJAX handlers are registered.
		 *
		 * @var bool
		 */
		private static $ajax_registered = false;

		/**
		 * Get or create a manager for a Pro plugin.
		 *
		 * @param array<string, mixed> $config {
		 *     Pro plugin configuration.
		 *
		 *     @type string   $pro_basename Pro plugin basename.
		 *     @type string   $pro_name     Human-readable Pro plugin name.
		 *     @type string   $text_domain  Text domain for translations.
		 *     @type string   $nonce_action Nonce action for AJAX requests.
		 *     @type string   $plugin_dir   Absolute path to Pro plugin directory.
		 *     @type string   $plugin_url   URL to Pro plugin directory.
		 *     @type string[] $admin_pages  Admin page slugs owned by this Pro plugin.
		 * }
		 * @return self
		 */
		public static function get_instance( array $config ) {
			$basename = isset( $config['pro_basename'] ) ? (string) $config['pro_basename'] : '';

			if ( '' === $basename ) {
				$basename = 'default';
			}

			if ( ! isset( self::$instances[ $basename ] ) ) {
				self::$instances[ $basename ] = new self( $config );
			}

			return self::$instances[ $basename ];
		}

		/**
		 * Constructor.
		 *
		 * @param array<string, mixed> $config Pro plugin configuration.
		 */
		private function __construct( array $config ) {
			$this->config = wp_parse_args(
				$config,
				array(
					'pro_basename' => '',
					'pro_name'     => __( 'Pro Extension', 'wp-ultimate-csv-importer' ),
					'text_domain'  => 'wp-ultimate-csv-importer',
					'nonce_action' => 'smack_importer_dependency',
					'plugin_dir'   => '',
					'plugin_url'   => '',
					'admin_pages'  => array(),
				)
			);
		}

		/**
		 * Register WordPress hooks for dependency validation and onboarding UI.
		 *
		 * @return void
		 */
		public function bootstrap() {
			if ( $this->bootstrapped || ! is_admin() ) {
				return;
			}

			$this->bootstrapped = true;

			add_action( 'admin_init', array( $this, 'validate_on_admin_init' ), 1 );
			add_action( 'activated_plugin', array( $this, 'validate_on_plugin_activation' ), 20, 2 );
			add_action( 'upgrader_process_complete', array( $this, 'validate_on_plugin_update' ), 20, 2 );
			add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'admin_footer', array( $this, 'render_dependency_modal' ) );

			add_action( 'wp_ajax_' . $this->get_ajax_action( 'activate' ), array( $this, 'handle_ajax_activation' ) );
			add_action( 'wp_ajax_' . $this->get_ajax_action( 'install' ), array( $this, 'handle_ajax_install' ) );
			add_action( 'wp_ajax_' . $this->get_ajax_action( 'dismiss' ), array( $this, 'handle_ajax_dismiss_notice' ) );
		}

		/**
		 * Whether the free plugin files exist on disk.
		 *
		 * @return bool
		 */
		public function is_free_plugin_installed() {
			return file_exists( WP_PLUGIN_DIR . '/' . self::FREE_PLUGIN_FILE );
		}

		/**
		 * Whether the free plugin is active (site or network).
		 *
		 * @return bool
		 */
		public function is_free_plugin_active() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( is_multisite() && is_plugin_active_for_network( self::FREE_PLUGIN_FILE ) ) {
				return true;
			}

			return is_plugin_active( self::FREE_PLUGIN_FILE );
		}

		/**
		 * Whether dependency is fully satisfied.
		 *
		 * @return bool
		 */
		public function is_dependency_resolved() {
			return $this->is_free_plugin_installed() && $this->is_free_plugin_active();
		}

		/**
		 * Validate dependency on admin dashboard load.
		 *
		 * @return void
		 */
		public function validate_on_admin_init() {
			if ( $this->is_dependency_resolved() ) {
				$this->clear_dismissed_notice_for_user();
				return;
			}

			if ( $this->should_show_modal_on_load() ) {
				add_filter( 'importer_dependency_show_modal_' . $this->get_config_id(), '__return_true' );
			}
		}

		/**
		 * Validate when any plugin is activated.
		 *
		 * @param string $plugin       Activated plugin basename.
		 * @param bool   $network_wide Whether activated network-wide.
		 * @return void
		 */
		public function validate_on_plugin_activation( $plugin, $network_wide ) {
			unset( $network_wide );

			if ( $plugin !== $this->config['pro_basename'] ) {
				return;
			}

			if ( $this->is_dependency_resolved() ) {
				return;
			}

			add_filter( 'importer_dependency_show_modal_' . $this->get_config_id(), '__return_true' );
			set_transient( $this->get_modal_transient_key(), 1, MINUTE_IN_SECONDS * 10 );
		}

		/**
		 * Validate after plugin updates.
		 *
		 * @param \WP_Upgrader $upgrader Upgrader instance.
		 * @param array        $options  Upgrade options.
		 * @return void
		 */
		public function validate_on_plugin_update( $upgrader, $options ) {
			unset( $upgrader );

			if ( empty( $options['action'] ) || 'update' !== $options['action'] ) {
				return;
			}

			if ( empty( $options['type'] ) || 'plugin' !== $options['type'] ) {
				return;
			}

			$updated_plugins = array();

			if ( ! empty( $options['plugins'] ) && is_array( $options['plugins'] ) ) {
				$updated_plugins = $options['plugins'];
			} elseif ( ! empty( $options['plugin'] ) ) {
				$updated_plugins = array( $options['plugin'] );
			}

			if ( ! in_array( $this->config['pro_basename'], $updated_plugins, true ) ) {
				return;
			}

			if ( $this->is_dependency_resolved() ) {
				return;
			}

			add_filter( 'importer_dependency_show_modal_' . $this->get_config_id(), '__return_true' );
		}

		/**
		 * Activate the free plugin programmatically.
		 *
		 * @return true|\WP_Error
		 */
		public function activate_free_plugin() {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return new \WP_Error(
					'permission_denied',
					__( 'You do not have permission to activate plugins.', 'wp-ultimate-csv-importer' )
				);
			}

			if ( ! $this->is_free_plugin_installed() ) {
				return new \WP_Error(
					'not_installed',
					__( 'WP Ultimate CSV Importer is not installed.', 'wp-ultimate-csv-importer' )
				);
			}

			if ( $this->is_free_plugin_active() ) {
				return true;
			}

			$result = activate_plugin( self::FREE_PLUGIN_FILE );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return true;
		}

		/**
		 * Download, install, and activate the free plugin.
		 *
		 * @return true|\WP_Error
		 */
		public function install_free_plugin() {
			if ( ! current_user_can( 'install_plugins' ) ) {
				return new \WP_Error(
					'permission_denied',
					__( 'You do not have permission to install plugins.', 'wp-ultimate-csv-importer' )
				);
			}

			if ( $this->is_free_plugin_active() ) {
				return true;
			}

			if ( ! $this->is_free_plugin_installed() ) {
				$install_result = $this->download_and_install_free_plugin();

				if ( is_wp_error( $install_result ) ) {
					return $install_result;
				}
			}

			return $this->activate_free_plugin();
		}

		/**
		 * Download and install the free plugin from WordPress.org.
		 *
		 * @return true|\WP_Error
		 */
		private function download_and_install_free_plugin() {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';

			$api = plugins_api(
				'plugin_information',
				array(
					'slug'   => self::FREE_PLUGIN_SLUG,
					'fields' => array(
						'sections' => false,
					),
				)
			);

			if ( is_wp_error( $api ) ) {
				return new \WP_Error(
					'api_error',
					__( 'Could not retrieve plugin information from WordPress.org.', 'wp-ultimate-csv-importer' ),
					$api->get_error_message()
				);
			}

			if ( empty( $api->download_link ) ) {
				return new \WP_Error(
					'download_unavailable',
					__( 'Download link for the free plugin is unavailable.', 'wp-ultimate-csv-importer' )
				);
			}

			$skin     = new \WP_Ajax_Upgrader_Skin();
			$upgrader = new \Plugin_Upgrader( $skin );
			$result   = $upgrader->install( $api->download_link );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( false === $result ) {
				$error_message = $skin->get_error_messages();
				$error_text    = is_array( $error_message ) ? implode( ' ', $error_message ) : __( 'Unknown installation error.', 'wp-ultimate-csv-importer' );

				return new \WP_Error( 'install_failed', $error_text );
			}

			return true;
		}

		/**
		 * AJAX handler: activate the free plugin.
		 *
		 * @return void
		 */
		public function handle_ajax_activation() {
			check_ajax_referer( $this->config['nonce_action'], 'nonce' );

			if ( ! current_user_can( 'activate_plugins' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'You do not have permission to activate plugins.', 'wp-ultimate-csv-importer' ),
						'code'    => 'permission_denied',
					),
					403
				);
			}

			$result = $this->activate_free_plugin();

			if ( is_wp_error( $result ) ) {
				wp_send_json_error(
					array(
						'message'       => __( 'The plugin was installed but could not be activated automatically.', 'wp-ultimate-csv-importer' ),
						'detail'        => $result->get_error_message(),
						'code'          => $result->get_error_code(),
						'manual_url'    => $this->get_manual_activate_url(),
						'troubleshoot'  => self::MANUAL_INSTALL_URL,
					),
					500
				);
			}

			delete_transient( $this->get_modal_transient_key() );
			$this->clear_dismissed_notice_for_user();

			wp_send_json_success(
				array(
					'message' => __( 'WP Ultimate CSV Importer has been activated successfully. Your Pro extension is now ready to use.', 'wp-ultimate-csv-importer' ),
					'reload'  => true,
				)
			);
		}

		/**
		 * AJAX handler: install and activate the free plugin.
		 *
		 * @return void
		 */
		public function handle_ajax_install() {
			check_ajax_referer( $this->config['nonce_action'], 'nonce' );

			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'You do not have permission to install plugins.', 'wp-ultimate-csv-importer' ),
						'code'    => 'permission_denied',
					),
					403
				);
			}

			$steps = array(
				'checking'    => __( 'Checking requirements...', 'wp-ultimate-csv-importer' ),
				'downloading' => __( 'Downloading plugin...', 'wp-ultimate-csv-importer' ),
				'installing'  => __( 'Installing plugin...', 'wp-ultimate-csv-importer' ),
				'activating'  => __( 'Activating plugin...', 'wp-ultimate-csv-importer' ),
				'completed'   => __( 'Completed', 'wp-ultimate-csv-importer' ),
			);

			$result = $this->install_free_plugin();

			if ( is_wp_error( $result ) ) {
				$is_activation_failure = 'not_installed' !== $result->get_error_code()
					&& $this->is_free_plugin_installed();

				wp_send_json_error(
					array(
						'message'      => $is_activation_failure
							? __( 'The plugin was installed but could not be activated automatically.', 'wp-ultimate-csv-importer' )
							: __( 'We couldn\'t automatically install the required free plugin.', 'wp-ultimate-csv-importer' ),
						'detail'       => $result->get_error_message(),
						'code'         => $result->get_error_code(),
						'manual_url'   => $is_activation_failure ? $this->get_manual_activate_url() : self::MANUAL_INSTALL_URL,
						'troubleshoot' => self::MANUAL_INSTALL_URL,
						'steps'        => $steps,
					),
					500
				);
			}

			delete_transient( $this->get_modal_transient_key() );
			$this->clear_dismissed_notice_for_user();

			wp_send_json_success(
				array(
					'message' => __( 'WP Ultimate CSV Importer was installed and activated successfully.', 'wp-ultimate-csv-importer' ),
					'steps'   => $steps,
					'reload'  => true,
				)
			);
		}

		/**
		 * AJAX handler: dismiss the admin notice.
		 *
		 * @return void
		 */
		public function handle_ajax_dismiss_notice() {
			check_ajax_referer( $this->config['nonce_action'], 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ) ), 403 );
			}

			update_user_meta( get_current_user_id(), $this->get_notice_dismiss_meta_key(), '1' );
			wp_send_json_success();
		}

		/**
		 * Render dismissible admin notice when dependency is unresolved.
		 *
		 * @return void
		 */
		public function render_admin_notice() {
			if ( ! current_user_can( 'manage_options' ) || $this->is_dependency_resolved() ) {
				return;
			}

			if ( $this->is_notice_dismissed_for_user() ) {
				return;
			}

			if ( $this->is_on_pro_admin_page() ) {
				return;
			}

			$pro_name = esc_html( $this->config['pro_name'] );
			?>
			<div
				class="notice notice-warning is-dismissible importer-dependency-notice"
				data-config-id="<?php echo esc_attr( $this->get_config_id() ); ?>"
				data-nonce="<?php echo esc_attr( wp_create_nonce( $this->config['nonce_action'] ) ); ?>"
			>
				<p>
					<strong><?php esc_html_e( 'WP Ultimate CSV Importer Required', 'wp-ultimate-csv-importer' ); ?></strong>
					<?php
					printf(
						/* translators: %s: Pro plugin name */
						esc_html__( '%s needs WP Ultimate CSV Importer (Free) to be installed and active.', 'wp-ultimate-csv-importer' ),
						$pro_name
					);
					?>
					<a href="#" class="importer-dependency-open-modal" data-config-id="<?php echo esc_attr( $this->get_config_id() ); ?>">
						<?php esc_html_e( 'Set up now', 'wp-ultimate-csv-importer' ); ?>
					</a>
				</p>
			</div>
			<?php
		}

		/**
		 * Render onboarding modal markup in admin footer.
		 *
		 * @return void
		 */
		public function render_dependency_modal() {
			if ( ! current_user_can( 'manage_options' ) || $this->is_dependency_resolved() ) {
				return;
			}

			if ( ! $this->should_render_modal() ) {
				return;
			}

			$scenario     = $this->is_free_plugin_installed() ? 'activate' : 'install';
			$primary_text = 'activate' === $scenario
				? __( 'Activate Free Plugin', 'wp-ultimate-csv-importer' )
				: __( 'Install & Activate Free Plugin', 'wp-ultimate-csv-importer' );

			$consent_text = 'install' === $scenario
				? __( 'WordPress will download and install WP Ultimate CSV Importer (Free) from the official plugin directory. Do you want to continue?', 'wp-ultimate-csv-importer' )
				: '';

			$config_id = $this->get_config_id();
			?>
			<div
				id="importer-dependency-modal-<?php echo esc_attr( $config_id ); ?>"
				class="importer-dependency-modal"
				role="dialog"
				aria-modal="true"
				aria-labelledby="importer-dependency-title-<?php echo esc_attr( $config_id ); ?>"
				data-config-id="<?php echo esc_attr( $config_id ); ?>"
				data-scenario="<?php echo esc_attr( $scenario ); ?>"
				data-auto-open="<?php echo $this->should_auto_open_modal() ? '1' : '0'; ?>"
				hidden
			>
				<div class="importer-dependency-modal__overlay" tabindex="-1"></div>
				<div class="importer-dependency-modal__dialog">
					<div class="importer-dependency-modal__header">
						<h2 id="importer-dependency-title-<?php echo esc_attr( $config_id ); ?>">
							<?php esc_html_e( 'WP Ultimate CSV Importer Required', 'wp-ultimate-csv-importer' ); ?>
						</h2>
						<button type="button" class="importer-dependency-modal__close" aria-label="<?php esc_attr_e( 'Close', 'wp-ultimate-csv-importer' ); ?>">&times;</button>
					</div>

					<div class="importer-dependency-modal__body">
						<p class="importer-dependency-modal__lead">
							<?php esc_html_e( 'The Pro extension requires WP Ultimate CSV Importer (Free) to be installed and activated before the Pro features can be used.', 'wp-ultimate-csv-importer' ); ?>
						</p>

						<div class="importer-dependency-modal__info">
							<p>
								<strong><?php esc_html_e( 'Why is this required?', 'wp-ultimate-csv-importer' ); ?></strong>
								<?php esc_html_e( 'Your Pro extension builds on the free importer. It adds advanced features on top of the core import engine.', 'wp-ultimate-csv-importer' ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'What happens next?', 'wp-ultimate-csv-importer' ); ?></strong>
								<?php
								if ( 'install' === $scenario ) {
									esc_html_e( 'We will install the free plugin from WordPress.org, activate it, and then your Pro features will be ready.', 'wp-ultimate-csv-importer' );
								} else {
									esc_html_e( 'We will activate the free plugin and then your Pro features will be ready to use.', 'wp-ultimate-csv-importer' );
								}
								?>
							</p>
						</div>

						<?php if ( 'install' === $scenario ) : ?>
							<div class="importer-dependency-modal__consent" hidden>
								<p><?php echo esc_html( $consent_text ); ?></p>
							</div>
						<?php endif; ?>

						<div class="importer-dependency-modal__progress" hidden>
							<ul class="importer-dependency-modal__steps">
								<li data-step="checking"><?php esc_html_e( 'Checking requirements...', 'wp-ultimate-csv-importer' ); ?></li>
								<li data-step="downloading"><?php esc_html_e( 'Downloading plugin...', 'wp-ultimate-csv-importer' ); ?></li>
								<li data-step="installing"><?php esc_html_e( 'Installing plugin...', 'wp-ultimate-csv-importer' ); ?></li>
								<li data-step="activating"><?php esc_html_e( 'Activating plugin...', 'wp-ultimate-csv-importer' ); ?></li>
								<li data-step="completed"><?php esc_html_e( 'Completed', 'wp-ultimate-csv-importer' ); ?></li>
							</ul>
						</div>

						<div class="importer-dependency-modal__message" hidden></div>
						<div class="importer-dependency-modal__error" hidden></div>
					</div>

					<div class="importer-dependency-modal__footer">
						<button type="button" class="button button-primary importer-dependency-modal__primary">
							<?php echo esc_html( $primary_text ); ?>
						</button>
						<button type="button" class="button importer-dependency-modal__cancel">
							<?php esc_html_e( 'Cancel', 'wp-ultimate-csv-importer' ); ?>
						</button>
						<a href="<?php echo esc_url( $this->get_manual_activate_url() ); ?>" class="button importer-dependency-modal__manual" hidden>
							<?php esc_html_e( 'Activate Manually', 'wp-ultimate-csv-importer' ); ?>
						</a>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Render onboarding screen for Pro admin pages when dependency is missing.
		 *
		 * @return void
		 */
		public function render_onboarding_screen() {
			?>
			<div class="importer-dependency-onboarding">
				<div class="importer-dependency-onboarding__card">
					<h2><?php esc_html_e( 'WP Ultimate CSV Importer Required', 'wp-ultimate-csv-importer' ); ?></h2>
					<p>
						<?php esc_html_e( 'The Pro extension requires WP Ultimate CSV Importer (Free) to be installed and activated before the Pro features can be used.', 'wp-ultimate-csv-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Use the setup guide below to get started in one step.', 'wp-ultimate-csv-importer' ); ?>
					</p>
					<button
						type="button"
						class="button button-primary button-hero importer-dependency-open-modal"
						data-config-id="<?php echo esc_attr( $this->get_config_id() ); ?>"
					>
						<?php
						echo esc_html(
							$this->is_free_plugin_installed()
								? __( 'Activate Free Plugin', 'wp-ultimate-csv-importer' )
								: __( 'Install & Activate Free Plugin', 'wp-ultimate-csv-importer' )
						);
						?>
					</button>
				</div>
			</div>
			<script>
				document.addEventListener('DOMContentLoaded', function () {
					var modal = document.querySelector('[data-config-id="<?php echo esc_js( $this->get_config_id() ); ?>"].importer-dependency-modal');
					if (modal && window.ImporterDependencyManager) {
						window.ImporterDependencyManager.openModal('<?php echo esc_js( $this->get_config_id() ); ?>');
					}
				});
			</script>
			<?php
		}

		/**
		 * Enqueue modal scripts and styles.
		 *
		 * @param string $hook_suffix Current admin page hook suffix.
		 * @return void
		 */
		public function enqueue_assets( $hook_suffix ) {
			unset( $hook_suffix );

			if ( ! current_user_can( 'manage_options' ) || $this->is_dependency_resolved() ) {
				return;
			}

			if ( ! $this->should_render_modal() && ! $this->should_show_notice_context() ) {
				return;
			}

			$handle = 'importer-dependency-manager';

			wp_enqueue_style(
				$handle,
				trailingslashit( $this->config['plugin_url'] ) . 'assets/css/dependency-manager.css',
				array(),
				'1.0.0'
			);

			wp_enqueue_script(
				$handle,
				trailingslashit( $this->config['plugin_url'] ) . 'assets/js/dependency-manager.js',
				array( 'jquery' ),
				'1.0.0',
				true
			);

			wp_localize_script(
				$handle,
				'ImporterDependencyConfig_' . $this->get_config_id(),
				array(
					'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
					'nonce'           => wp_create_nonce( $this->config['nonce_action'] ),
					'configId'        => $this->get_config_id(),
					'scenario'        => $this->is_free_plugin_installed() ? 'activate' : 'install',
					'actions'         => array(
						'activate' => $this->get_ajax_action( 'activate' ),
						'install'  => $this->get_ajax_action( 'install' ),
						'dismiss'  => $this->get_ajax_action( 'dismiss' ),
					),
					'strings'         => array(
						'installConsent'     => __( 'WordPress will download and install WP Ultimate CSV Importer (Free) from the official plugin directory. Do you want to continue?', 'wp-ultimate-csv-importer' ),
						'activateSuccess'    => __( 'WP Ultimate CSV Importer has been activated successfully. Your Pro extension is now ready to use.', 'wp-ultimate-csv-importer' ),
						'installSuccess'     => __( 'WP Ultimate CSV Importer was installed and activated successfully.', 'wp-ultimate-csv-importer' ),
						'installFailed'      => __( 'We couldn\'t automatically install the required free plugin.', 'wp-ultimate-csv-importer' ),
						'activateFailed'     => __( 'The plugin was installed but could not be activated automatically.', 'wp-ultimate-csv-importer' ),
						'permissionDenied'   => __( 'You do not have permission to perform this action.', 'wp-ultimate-csv-importer' ),
						'networkError'       => __( 'A network error occurred. Please check your connection and try again.', 'wp-ultimate-csv-importer' ),
						'manualInstallGuide' => __( 'Manual installation guide', 'wp-ultimate-csv-importer' ),
						'troubleshooting'    => __( 'Troubleshooting', 'wp-ultimate-csv-importer' ),
						'confirmInstall'     => __( 'Yes, Install Plugin', 'wp-ultimate-csv-importer' ),
						'cancel'             => __( 'Cancel', 'wp-ultimate-csv-importer' ),
						'activateManually'   => __( 'Activate Manually', 'wp-ultimate-csv-importer' ),
					),
					'manualUrl'       => self::MANUAL_INSTALL_URL,
					'activateUrl'     => $this->get_manual_activate_url(),
				)
			);

			wp_add_inline_script(
				$handle,
				'window.ImporterDependencyConfigs=window.ImporterDependencyConfigs||{};window.ImporterDependencyConfigs["' . esc_js( $this->get_config_id() ) . '"]=' . wp_json_encode(
					array(
						'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
						'nonce'     => wp_create_nonce( $this->config['nonce_action'] ),
						'configId'  => $this->get_config_id(),
						'scenario'  => $this->is_free_plugin_installed() ? 'activate' : 'install',
						'actions'   => array(
							'activate' => $this->get_ajax_action( 'activate' ),
							'install'  => $this->get_ajax_action( 'install' ),
							'dismiss'  => $this->get_ajax_action( 'dismiss' ),
						),
						'strings'   => array(
							'installConsent'     => __( 'WordPress will download and install WP Ultimate CSV Importer (Free) from the official plugin directory. Do you want to continue?', 'wp-ultimate-csv-importer' ),
							'activateSuccess'    => __( 'WP Ultimate CSV Importer has been activated successfully. Your Pro extension is now ready to use.', 'wp-ultimate-csv-importer' ),
							'installSuccess'     => __( 'WP Ultimate CSV Importer was installed and activated successfully.', 'wp-ultimate-csv-importer' ),
							'installFailed'      => __( 'We couldn\'t automatically install the required free plugin.', 'wp-ultimate-csv-importer' ),
							'activateFailed'     => __( 'The plugin was installed but could not be activated automatically.', 'wp-ultimate-csv-importer' ),
							'permissionDenied'   => __( 'You do not have permission to perform this action.', 'wp-ultimate-csv-importer' ),
							'networkError'       => __( 'A network error occurred. Please check your connection and try again.', 'wp-ultimate-csv-importer' ),
							'manualInstallGuide' => __( 'Manual installation guide', 'wp-ultimate-csv-importer' ),
							'troubleshooting'    => __( 'Troubleshooting', 'wp-ultimate-csv-importer' ),
							'confirmInstall'     => __( 'Yes, Install Plugin', 'wp-ultimate-csv-importer' ),
							'cancel'             => __( 'Cancel', 'wp-ultimate-csv-importer' ),
							'activateManually'   => __( 'Activate Manually', 'wp-ultimate-csv-importer' ),
						),
						'manualUrl' => self::MANUAL_INSTALL_URL,
						'activateUrl' => $this->get_manual_activate_url(),
					)
				) . ';',
				'before'
			);
		}

		/**
		 * Build a unique AJAX action name for this Pro plugin instance.
		 *
		 * @param string $action Action suffix (activate, install, dismiss).
		 * @return string
		 */
		private function get_ajax_action( $action ) {
			return 'importer_dependency_' . sanitize_key( $action ) . '_' . $this->get_config_id();
		}

		/**
		 * Whether the modal should render on the current request.
		 *
		 * @return bool
		 */
		private function should_render_modal() {
			return $this->is_on_pro_admin_page()
				|| $this->should_auto_open_modal()
				|| apply_filters( 'importer_dependency_show_modal_' . $this->get_config_id(), false );
		}

		/**
		 * Whether modal should auto-open.
		 *
		 * @return bool
		 */
		private function should_auto_open_modal() {
			return (bool) get_transient( $this->get_modal_transient_key() )
				|| $this->is_on_pro_admin_page();
		}

		/**
		 * Whether modal should show on admin init.
		 *
		 * @return bool
		 */
		private function should_show_modal_on_load() {
			return $this->is_on_pro_admin_page()
				|| (bool) get_transient( $this->get_modal_transient_key() );
		}

		/**
		 * Whether current screen is a Pro plugin admin page.
		 *
		 * @return bool
		 */
		private function is_on_pro_admin_page() {
			$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';

			if ( '' === $page || empty( $this->config['admin_pages'] ) ) {
				return false;
			}

			return in_array( $page, (array) $this->config['admin_pages'], true );
		}

		/**
		 * Whether notice-related assets should load.
		 *
		 * @return bool
		 */
		private function should_show_notice_context() {
			global $pagenow;

			return in_array( $pagenow, array( 'index.php', 'plugins.php' ), true );
		}

		/**
		 * Unique configuration identifier.
		 *
		 * @return string
		 */
		private function get_config_id() {
			return md5( (string) $this->config['pro_basename'] );
		}

		/**
		 * Transient key for auto-opening modal after activation.
		 *
		 * @return string
		 */
		private function get_modal_transient_key() {
			return 'importer_dep_modal_' . $this->get_config_id();
		}

		/**
		 * User meta key for dismissed notice.
		 *
		 * @return string
		 */
		private function get_notice_dismiss_meta_key() {
			return 'importer_dep_notice_dismissed_' . $this->get_config_id();
		}

		/**
		 * Whether notice was dismissed by current user.
		 *
		 * @return bool
		 */
		private function is_notice_dismissed_for_user() {
			return '1' === get_user_meta( get_current_user_id(), $this->get_notice_dismiss_meta_key(), true );
		}

		/**
		 * Clear dismissed notice when dependency is resolved.
		 *
		 * @return void
		 */
		private function clear_dismissed_notice_for_user() {
			delete_user_meta( get_current_user_id(), $this->get_notice_dismiss_meta_key() );
		}

		/**
		 * Manual activation URL for plugins screen.
		 *
		 * @return string
		 */
		private function get_manual_activate_url() {
			if ( ! $this->is_free_plugin_installed() ) {
				return self::MANUAL_INSTALL_URL;
			}

			return wp_nonce_url(
				admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( self::FREE_PLUGIN_FILE ) ),
				'activate-plugin_' . self::FREE_PLUGIN_FILE
			);
		}
	}
}
