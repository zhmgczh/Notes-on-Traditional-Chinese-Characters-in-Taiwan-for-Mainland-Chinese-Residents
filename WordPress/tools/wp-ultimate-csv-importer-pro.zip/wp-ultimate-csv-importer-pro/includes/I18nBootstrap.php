<?php
/**
 * WordPress text domain loading and UI language resolution.
 *
 * @package wp-ultimate-csv-importer-pro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class I18nBootstrap {

	const TEXT_DOMAIN     = 'wp-ultimate-csv-importer';
	const TEXT_DOMAIN_PRO = 'wp-ultimate-csv-importer-pro';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'load_textdomains' ), 0 );
	}

	/**
	 * Load plugin translation files for both declared text domains.
	 */
	public static function load_textdomains() {
		$plugin_rel_path = dirname( plugin_basename( WCSVPLUGINDIR . 'wp-ultimate-csv-importer-pro.php' ) ) . '/languages';

		$loaded_primary = load_plugin_textdomain( self::TEXT_DOMAIN, false, $plugin_rel_path );
		$loaded_pro     = load_plugin_textdomain( self::TEXT_DOMAIN_PRO, false, $plugin_rel_path );

		if ( ( ! $loaded_primary || ! $loaded_pro ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log(
				sprintf(
					'[WP Ultimate CSV Importer Pro] Text domain load issue. locale=%s primary=%s pro=%s path=%s',
					get_locale(),
					$loaded_primary ? 'ok' : 'failed',
					$loaded_pro ? 'ok' : 'failed',
					$plugin_rel_path
				)
			);
		}
	}

	/**
	 * Whether the active locale is Japanese.
	 *
	 * @param string|null $locale Optional locale override.
	 * @return bool
	 */
	public static function is_japanese_locale( $locale = null ) {
		$locale = null !== $locale ? $locale : get_locale();
		return in_array( $locale, array( 'ja', 'ja_JP' ), true );
	}

	/**
	 * Resolve translated React UI string map for the current locale.
	 *
	 * @return array<string, string>
	 */
	public static function get_ui_language_contents() {
		$language = get_locale();

		if ( 'it_IT' === $language ) {
			return LangIT::getInstance()->contents();
		}
		if ( in_array( $language, array( 'fr_FR', 'fr_BE' ), true ) ) {
			return LangFR::getInstance()->contents();
		}
		if ( in_array( $language, array( 'de_DE', 'de_AT' ), true ) ) {
			return LangGE::getInstance()->contents();
		}
		if ( 'es_ES' === $language ) {
			return LangES::getInstance()->contents();
		}
		if ( 'en_CA' === $language ) {
			return LangEN_CA::getInstance()->contents();
		}
		if ( 'en_GB' === $language ) {
			return LangEN_GB::getInstance()->contents();
		}
		if ( 'tr_TR' === $language ) {
			return LangTR::getInstance()->contents();
		}
		if ( 'ru_RU' === $language ) {
			return LangRU::getInstance()->contents();
		}
		if ( 'pt_BR' === $language ) {
			return LangPT::getInstance()->contents();
		}
		if ( self::is_japanese_locale( $language ) ) {
			return LangJA::getInstance()->contents();
		}
		if ( 'nl_NL' === $language ) {
			return LangNL::getInstance()->contents();
		}
		if ( 'en_ZA' === $language ) {
			return LangEN_ZA::getInstance()->contents();
		}

		return LangEN::getInstance()->contents();
	}

	/**
	 * Display label for import "Post Type" dropdown options (values stay English keys).
	 *
	 * @param string $key Import module label or registered post type slug.
	 * @return string
	 */
	public static function get_import_type_display_label( $key ) {
		$map = self::get_ui_language_contents();
		if ( isset( $map[ $key ] ) && '' !== $map[ $key ] ) {
			return $map[ $key ];
		}

		$post_type = get_post_type_object( $key );
		if ( $post_type && ! empty( $post_type->labels->singular_name ) ) {
			return $post_type->labels->singular_name;
		}

		return $key;
	}

	/**
	 * Display label for import taxonomy dropdown options.
	 *
	 * @param string $key Taxonomy slug.
	 * @return string
	 */
	public static function get_taxonomy_display_label( $key ) {
		$map = self::get_ui_language_contents();
		if ( isset( $map[ $key ] ) && '' !== $map[ $key ] ) {
			return $map[ $key ];
		}

		$taxonomy = get_taxonomy( $key );
		if ( $taxonomy && ! empty( $taxonomy->labels->singular_name ) ) {
			return $taxonomy->labels->singular_name;
		}

		return $key;
	}
}
