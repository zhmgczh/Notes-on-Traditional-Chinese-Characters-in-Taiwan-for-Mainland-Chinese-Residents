<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Centralized Smart Schedule state: locks, batch options, cron_status transitions.
 */
class ScheduleStateService {

	const STATUS_PENDING              = 'pending';
	const STATUS_PROCESSING           = 'processing';
	const STATUS_INITIALIZED          = 'initialized';
	const STATUS_WAITING_NEXT         = 'waiting for next schedule';
	const STATUS_WAITING_RETRY        = 'waiting for retry';
	const STATUS_COMPLETED            = 'completed';
	const STATUS_FAILED               = 'Failed';

	const COL_LAST_HEARTBEAT = 'last_heartbeat_at';
	const COL_RETRY_COUNT    = 'retry_count';
	const COL_MAX_RETRIES    = 'max_retries';

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_scheduled_import';
	}

	/**
	 * Atomically acquire run lock. Returns false if another worker holds the lock.
	 *
	 * @param int $schedule_id Schedule ID.
	 * @return bool
	 */
	public function acquire_lock( $schedule_id ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 ) {
			return false;
		}
		$table  = self::table_name();
		$rows   = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET isrun = 1 WHERE id = %d AND isrun = 0",
				$schedule_id
			)
		);
		return ( $rows > 0 );
	}

	/**
	 * @param int    $schedule_id Schedule ID.
	 * @param string $reason      Log reason.
	 */
	public function release_lock( $schedule_id, $reason = '' ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 ) {
			return;
		}
		$wpdb->update(
			self::table_name(),
			array( 'isrun' => 0 ),
			array( 'id' => $schedule_id ),
			array( '%d' ),
			array( '%d' )
		);
		if ( '' !== $reason && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( sprintf( '[UCI Pro Schedule] Lock released for schedule %d: %s', $schedule_id, $reason ) );
		}
	}

	/**
	 * Update scheduler heartbeat timestamp for an active run.
	 *
	 * @param int $schedule_id Schedule row ID.
	 */
	public function heartbeat( $schedule_id ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 ) {
			return;
		}
		$now = current_time( 'mysql', true );
		$wpdb->update(
			self::table_name(),
			array(
				self::COL_LAST_HEARTBEAT => $now,
				'updatedtime'            => $now,
			),
			array( 'id' => $schedule_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Atomically transition cron_status when the current value matches $from.
	 *
	 * @param int    $schedule_id Schedule row ID.
	 * @param string $from        Expected current status.
	 * @param string $to          Target status.
	 * @return bool True when the row was updated.
	 */
	public function transition( $schedule_id, $from, $to ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		$from        = (string) $from;
		$to          = (string) $to;
		if ( $schedule_id <= 0 || '' === $from || '' === $to ) {
			return false;
		}
		$table = self::table_name();
		$rows  = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET cron_status = %s, updatedtime = %s WHERE id = %d AND cron_status = %s",
				$to,
				current_time( 'mysql', true ),
				$schedule_id,
				$from
			)
		);
		return ( (int) $rows > 0 );
	}

	/**
	 * Detect schedules stuck with isrun=1 and a stale heartbeat; release lock and queue retry.
	 *
	 * @param int $timeout_seconds Seconds without heartbeat before a job is stale.
	 * @return int Number of schedules recovered.
	 */
	public function detect_stale_jobs( $timeout_seconds = 600 ) {
		global $wpdb;
		$timeout_seconds = max( 60, (int) apply_filters( 'sm_uci_pro_schedule_heartbeat_timeout', $timeout_seconds ) );
		$cutoff          = gmdate( 'Y-m-d H:i:s', time() - $timeout_seconds );
		$table           = self::table_name();

		$stale_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, cron_status, " . self::COL_RETRY_COUNT . ", " . self::COL_MAX_RETRIES . "
				FROM {$table}
				WHERE isrun = 1
				AND (
					( " . self::COL_LAST_HEARTBEAT . " IS NOT NULL AND " . self::COL_LAST_HEARTBEAT . " < %s )
					OR ( " . self::COL_LAST_HEARTBEAT . " IS NULL AND updatedtime < %s )
				)",
				$cutoff,
				$cutoff
			)
		);

		if ( empty( $stale_rows ) ) {
			return 0;
		}

		$recovered = 0;
		foreach ( $stale_rows as $row ) {
			$schedule_id = (int) $row->id;
			$this->release_lock( $schedule_id, 'stale_heartbeat_recovery' );
			$this->set_status( $schedule_id, self::STATUS_WAITING_RETRY );
			++$recovered;
		}

		return $recovered;
	}

	/**
	 * WP-Cron callback: recover stale schedule locks and heartbeat-stuck jobs.
	 */
	public static function run_heartbeat_cron() {
		$service = self::getInstance();
		$service->detect_stale_jobs();
		$service->recover_stale_locks();
	}

	/**
	 * @param int    $schedule_id Schedule ID.
	 * @param string $status      cron_status value.
	 */
	public function set_status( $schedule_id, $status ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 || '' === $status ) {
			return;
		}
		$wpdb->update(
			self::table_name(),
			array( 'cron_status' => $status ),
			array( 'id' => $schedule_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Clear batch pagination options for a schedule.
	 *
	 * @param int $schedule_id Schedule ID.
	 */
	public function reset_batch_options( $schedule_id ) {
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 ) {
			return;
		}
		delete_option( 'smack_csv_record_limit_' . $schedule_id );
		delete_option( 'smack_csv_page_number_' . $schedule_id );
		delete_option( 'smack_xml_record_limit_' . $schedule_id );
		delete_option( 'smack_xlsx_record_limit_' . $schedule_id );
	}

	/**
	 * Recover schedules stuck with isrun=1 longer than threshold.
	 */
	public function recover_stale_locks() {
		global $wpdb;
		$table         = self::table_name();
		$stale_minutes = (int) apply_filters( 'sm_uci_pro_schedule_stale_lock_minutes', 15 );
		$stale_minutes = max( 5, $stale_minutes );
		$cutoff        = gmdate( 'Y-m-d H:i:s', time() - ( $stale_minutes * MINUTE_IN_SECONDS ) );

		$stale_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, cron_status FROM {$table} WHERE isrun = 1 AND updatedtime < %s",
				$cutoff
			)
		);

		if ( empty( $stale_rows ) ) {
			return 0;
		}

		foreach ( $stale_rows as $row ) {
			$this->release_lock( (int) $row->id, 'stale_lock_recovery' );
		}

		return count( $stale_rows );
	}

	/**
	 * @param string $reason Failure message.
	 * @return bool
	 */
	public function is_retryable_failure( $reason ) {
		$reason = strtolower( (string) $reason );
		if ( '' === $reason ) {
			return false;
		}
		$needles = array(
			'no internet',
			'no_internet',
			'http_request_failed',
			'timed out',
			'timeout',
			'could not resolve host',
			'curl error 28',
			'ftp connection failed',
			'cannot download',
			'connection refused',
			'connection reset',
			'login incorrect',
			'please check credentials',
			'download failed',
		);
		foreach ( $needles as $needle ) {
			if ( strpos( $reason, $needle ) !== false ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Statuses that the cron poller may execute (excludes terminal Failed/completed).
	 *
	 * @return string[]
	 */
	public function get_actionable_statuses() {
		return array(
			self::STATUS_PENDING,
			self::STATUS_PROCESSING,
			self::STATUS_INITIALIZED,
			self::STATUS_WAITING_NEXT,
			self::STATUS_WAITING_RETRY,
		);
	}

	/**
	 * Resolve a stored schedule timezone to a valid DateTimeZone name.
	 * Accepts IANA names and UTC offsets (+00:00). Falls back to WP timezone, then UTC.
	 *
	 * @param string|null $stored_timezone Raw DB value.
	 * @return string
	 */
	public function resolve_timezone( $stored_timezone ) {
		$candidate = is_string( $stored_timezone ) ? trim( $stored_timezone ) : '';
		if ( '' !== $candidate && 'NULL' !== strtoupper( $candidate ) ) {
			try {
				new \DateTimeZone( $candidate );
				return $candidate;
			} catch ( \Exception $e ) {
				// Fall through to WordPress timezone.
			}
		}

		$wp_tz = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : '';
		if ( is_string( $wp_tz ) && '' !== $wp_tz ) {
			try {
				new \DateTimeZone( $wp_tz );
				return $wp_tz;
			} catch ( \Exception $e ) {
				// Fall through to UTC.
			}
		}

		return 'UTC';
	}

	/**
	 * Current wall-clock datetime in the given timezone (Y-m-d H:i:s).
	 *
	 * @param string|null $stored_timezone Raw DB timezone.
	 * @return string
	 */
	public function current_timestamp_for_timezone( $stored_timezone ) {
		$tz_name = $this->resolve_timezone( $stored_timezone );
		try {
			$date = new \DateTime( 'now', new \DateTimeZone( $tz_name ) );
			return $date->format( 'Y-m-d H:i:s' );
		} catch ( \Exception $e ) {
			return gmdate( 'Y-m-d H:i:s' );
		}
	}

	/**
	 * Whether nexrun is due relative to "now" in the schedule's own timezone.
	 *
	 * @param string      $nexrun           Stored nexrun datetime.
	 * @param string|null $stored_timezone  Schedule time_zone column.
	 * @return bool
	 */
	public function is_due( $nexrun, $stored_timezone ) {
		$nexrun = trim( (string) $nexrun );
		if ( '' === $nexrun || '0000-00-00 00:00:00' === $nexrun ) {
			return false;
		}
		$now = $this->current_timestamp_for_timezone( $stored_timezone );
		return ( $nexrun <= $now );
	}

	/**
	 * Fetch unlocked, actionable schedules that are due in their own timezone.
	 * Never uses another schedule's timezone for due detection.
	 *
	 * @param string $table Full schedule table name.
	 * @return object[]
	 */
	public function get_due_schedules( $table ) {
		global $wpdb;

		$status_list = $this->get_actionable_statuses();
		$placeholders = implode( ',', array_fill( 0, count( $status_list ), '%s' ) );
		$sql          = "SELECT * FROM {$table} WHERE isrun = 0 AND cron_status IN ({$placeholders}) ORDER BY id ASC";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders built from fixed status list.
		$candidates   = $wpdb->get_results( $wpdb->prepare( $sql, $status_list ) );

		if ( empty( $candidates ) ) {
			return array();
		}

		$due = array();
		foreach ( $candidates as $row ) {
			if ( $this->is_due( isset( $row->nexrun ) ? $row->nexrun : '', isset( $row->time_zone ) ? $row->time_zone : '' ) ) {
				$due[] = $row;
			}
		}

		return $due;
	}

	/**
	 * Persist a corrected timezone when the stored value was empty/invalid.
	 *
	 * @param string $table       Table name.
	 * @param int    $schedule_id Schedule ID.
	 * @param string $timezone    Resolved timezone.
	 */
	public function persist_timezone_if_missing( $table, $schedule_id, $timezone ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 || '' === $timezone ) {
			return;
		}
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET time_zone = %s WHERE id = %d AND (time_zone IS NULL OR time_zone = '' OR time_zone = 'NULL')",
				$timezone,
				$schedule_id
			)
		);
	}

	/**
	 * Read scheduler heartbeat metadata.
	 *
	 * @param int $schedule_id Schedule row ID.
	 * @return array{last_heartbeat_at: string|null, retry_count: int, max_retries: int}
	 */
	/**
	 * Exponential backoff delay before retry: min(300, 30 * 2^retry_count).
	 *
	 * @param int $retry_count Current retry count (after increment).
	 * @return int Seconds to wait.
	 */
	public function calculate_backoff_seconds( $retry_count ) {
		$retry_count = max( 0, (int) $retry_count );
		return min( 300, 30 * ( 2 ** $retry_count ) );
	}

	/**
	 * Reset retry_count for a schedule (success path).
	 *
	 * @param int $schedule_id Schedule row ID.
	 */
	public function reset_retry_count( $schedule_id ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 ) {
			return;
		}
		$wpdb->update(
			self::table_name(),
			array( self::COL_RETRY_COUNT => 0 ),
			array( 'id' => $schedule_id ),
			array( '%d' ),
			array( '%d' )
		);
		delete_transient( 'import_retry_' . $schedule_id );
	}

	/**
	 * Increment retry_count and return updated meta.
	 *
	 * @param int $schedule_id Schedule row ID.
	 * @return array{retry_count: int, max_retries: int}
	 */
	public function increment_retry_count( $schedule_id ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		$table       = self::table_name();
		if ( $schedule_id <= 0 ) {
			return array(
				'retry_count' => 0,
				'max_retries' => 3,
			);
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- column constants.
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET " . self::COL_RETRY_COUNT . " = " . self::COL_RETRY_COUNT . " + 1 WHERE id = %d",
				$schedule_id
			)
		);
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT " . self::COL_RETRY_COUNT . ", " . self::COL_MAX_RETRIES . " FROM {$table} WHERE id = %d",
				$schedule_id
			)
		);
		return array(
			'retry_count' => isset( $row->retry_count ) ? (int) $row->retry_count : 0,
			'max_retries' => isset( $row->max_retries ) ? (int) $row->max_retries : 3,
		);
	}

	/**
	 * Queue a retry with exponential backoff.
	 *
	 * @param int    $schedule_id    Schedule row ID.
	 * @param string $failure_reason Failure message for logging.
	 * @return bool True when retry was scheduled.
	 */
	public function schedule_retry( $schedule_id, $failure_reason = '' ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		if ( $schedule_id <= 0 || ! $this->is_retryable_failure( $failure_reason ) ) {
			return false;
		}

		$meta = $this->increment_retry_count( $schedule_id );
		if ( $meta['retry_count'] > $meta['max_retries'] ) {
			$this->reset_retry_count( $schedule_id );
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log(
					sprintf(
						'[UCI Pro Schedule] Schedule %d failed after %d retries: %s',
						$schedule_id,
						$meta['max_retries'],
						$failure_reason
					)
				);
			}
			return false;
		}

		$delay           = $this->calculate_backoff_seconds( $meta['retry_count'] );
		$next_retry_time = gmdate( 'Y-m-d H:i:s', time() + $delay );

		$wpdb->update(
			self::table_name(),
			array(
				'cron_status' => self::STATUS_WAITING_RETRY,
				'nexrun'      => $next_retry_time,
				'isrun'       => 0,
			),
			array( 'id' => $schedule_id ),
			array( '%s', '%s', '%d' ),
			array( '%d' )
		);

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log(
				sprintf(
					'[UCI Pro Schedule] Schedule %d retry %d/%d in %ds: %s',
					$schedule_id,
					$meta['retry_count'],
					$meta['max_retries'],
					$delay,
					$failure_reason
				)
			);
		}

		return true;
	}

	public function get_heartbeat_meta( $schedule_id ) {
		global $wpdb;
		$schedule_id = (int) $schedule_id;
		$defaults    = array(
			'last_heartbeat_at' => null,
			'retry_count'       => 0,
			'max_retries'       => 3,
		);
		if ( $schedule_id <= 0 ) {
			return $defaults;
		}
		$table = self::table_name();
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT last_heartbeat_at, retry_count, max_retries FROM {$table} WHERE id = %d",
				$schedule_id
			),
			ARRAY_A
		);
		if ( ! is_array( $row ) ) {
			return $defaults;
		}
		return array(
			'last_heartbeat_at' => ! empty( $row['last_heartbeat_at'] ) ? $row['last_heartbeat_at'] : null,
			'retry_count'       => isset( $row['retry_count'] ) ? (int) $row['retry_count'] : 0,
			'max_retries'       => isset( $row['max_retries'] ) ? (int) $row['max_retries'] : 3,
		);
	}
}
