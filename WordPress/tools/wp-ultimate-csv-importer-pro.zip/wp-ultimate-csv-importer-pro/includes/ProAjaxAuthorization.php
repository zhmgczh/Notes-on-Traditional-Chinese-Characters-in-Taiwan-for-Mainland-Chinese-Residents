<?php
/**
 * Pro plugin AJAX action list extension for centralized authorization.
 *
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProAjaxAuthorization {

	/**
	 * Bootstrap shared security classes from the free plugin.
	 */
	public static function bootstrap() {
		$free_base = WP_PLUGIN_DIR . '/wp-ultimate-csv-importer/includes/';
		$files     = array(
			'SecurityHelper.php',
			'SafeExpressionEvaluator.php',
			'AjaxAuthorization.php',
		);
		foreach ( $files as $file ) {
			$path = $free_base . $file;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}
		if ( class_exists( '\Smackcoders\UCI\Core\AjaxAuthorization' ) ) {
			\Smackcoders\UCI\Core\AjaxAuthorization::register();
		}
		add_filter( 'smack_uci_admin_ajax_actions', array( __CLASS__, 'extend_admin_actions' ) );
		require_once __DIR__ . '/ProFreeAjaxDedup.php';
		ProFreeAjaxDedup::bootstrap();
	}

	/**
	 * @param string[] $actions
	 * @return string[]
	 */
	public static function extend_admin_actions( $actions ) {
		$pro_actions = array(
			'saveTemplateFields',
			'saveMappedFields',
			'StartImport',
			'GetProgress',
			'ImportState',
			'ImportStop',
			'checkmain_mode',
			'PauseImport',
			'ResumeImport',
			'displayCSV',
			'bulk_file_import',
			'bulk_import',
			'get_sftp_url',
			'get_sftp_details',
			'get_server',
			'uci_rest_api_m1_test',
			'uci_rest_api_m1_prepare',
			'uci_rest_api_load_form_prefs',
			'onedrive_getauthorise',
			'onedrive_getaccess_token',
			'onedrive_handle_auth',
			'onedrive_refresh_access_token',
			'onedrive_list_files',
			'onedrive_search_files',
			'delete_onedrive_credentials',
			'gdrive_getauthorise',
			'gdrive_getaccess_token',
			'gdrive_handle_auth',
			'gdrive_refresh_access_token',
			'gdrive_list_files',
			'gdrive_search_files',
			'delete_gdrive_credentials',
			'get_ftps_url',
			'cancel_file',
			'save_schedule_info',
			'timezone',
			'schedule_woo_to_sure_migration',
			'get_woo_to_sure_current_progress',
			'save_surecart_token',
			'smack_wc_surecart_completed_modules',
			'smack_wc_surecart_get_module_count',
			'fetch_woocommerce_status',
			'uci_media_get_download_settings',
			'uci_media_save_download_settings',
			'uci_media_retry_failed',
			'download_file',
			'download_all_file',
			'delete_file',
			'delete_all_records',
			'delete_all_file',
			'trash_records',
			'display_events',
			'getfields',
			'get_export_fields',
			'get_post_titles',
			'get_post_types',
			'get_taxonomies',
			'get_authors',
			'get_lang_code',
			'export_template',
			'export_already_mapped',
			'DeleteExportTemplate',
			'parse_data',
			'preview_records',
			'parse_data_export_all',
			'get_exportable_modules',
			'uci_db_migration_test_connection',
			'uci_db_migration_save_connection',
			'uci_db_migration_list_connections',
			'uci_db_migration_delete_connection',
			'uci_db_migration_list_tables',
			'uci_db_migration_get_columns',
			'uci_db_migration_preview_rows',
			'uci_db_migration_prepare_import',
			'spreadsheet_get_meta',
			'spreadsheet_get_rows',
			'spreadsheet_save_edits',
			'spreadsheet_validate_rows',
			'spreadsheet_finalize',
			'spreadsheet_discard_edits',
			'get_retry_records',
			'retry_failed_records',
			'download_failed_records_csv',
			'get_import_retry_summary',
			'get_retry_audit_history',
			'uci_pro_get_import_preview',
			'uci_pro_retry_preview_validation',
			'uci_automation_get_api_key',
			'uci_automation_regenerate_api_key',
			'uci_automation_get_template_settings',
			'uci_automation_save_template_settings',
			'csv_options',
			'get_total_records',
			'disable_main_mode',
			'wp_ai_field_mapping',
			'smack_check_wysiwyg_fields',
			'delete_mapping_template_by_hashkey',
			'send_error_status',
			'media_report',
			'checkExtensions',
			'listuploads',
			'locklist',
			'BarChart',
			'dashboard_kpi_stats',
			'dashboard_import_volume',
			'dashboard_content_distribution',
			'dashboard_recent_activity',
			'dashboard_quick_stats',
			'wpquery_data',
			'gsheet_getauthorise',
			'getaccess_token',
			'handle_auth',
			'refresh_access_token',
			'list_sheet_data',
			'sheet_list',
			'get_sheet_gids',
			'getauthorise',
			'droprefresh_access_token',
			'get_sharedlink',
			'uci_ai_get_settings',
			'uci_ai_save_settings',
			'uci_ai_generate_batch',
			'uci_ai_get_reviews',
			'uci_ai_update_review',
			'uci_ai_bulk_review',
			'uci_ai_clear_reviews',
			'uci_ai_review_status',
			'delete_dropbox_credentials',
			'delete_gsheet_credentials',
			'zip_ngg_upload',
			'ai_natural_language_import',
			'handle_google_oauth_request',
			'check_google_sheet_credentials',
			'get_image_url',
			'get_test_result',
			'get_post_content',
			'get_export_template',
			'run_export',
			'parseDataToScheduleExport',
			'display_schedule',
			'delete_schedule',
			'edit_schedule',
			'update_schedule',
			'export_to_gsheet',
			'database_optimization_process',
			'export_display_log',
			'export_download_log',
			'export_delete_log',
			'rollback_now',
			'clear_rollback',
			'send_login_credentials_to_users',
			'get_sheet_setting',
			'uci_pro_get_feature_toggles',
			'uci_pro_save_feature_toggles',
			'saveTemplate',
		);
		return array_values( array_unique( array_merge( $actions, $pro_actions ) ) );
	}
}
