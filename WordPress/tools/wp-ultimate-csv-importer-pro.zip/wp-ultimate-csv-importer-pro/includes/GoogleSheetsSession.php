<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * In-request credential cache for Google Sheets / Drive API calls (#1442 Phase 3).
 */
class GoogleSheetsSession {

	/** @var array<string, mixed> */
	private static $credentials = array();

	/**
	 * @param string $option_key WordPress option name.
	 * @return mixed
	 */
	public static function get_credentials( $option_key ) {
		$key = (string) $option_key;
		if ( ! array_key_exists( $key, self::$credentials ) ) {
			self::$credentials[ $key ] = get_option( $key );
		}
		return self::$credentials[ $key ];
	}

	/**
	 * @param string $option_key Option name.
	 * @param mixed  $value      Credentials payload.
	 * @return void
	 */
	public static function set_credentials( $option_key, $value ) {
		self::$credentials[ (string) $option_key ] = $value;
		update_option( (string) $option_key, $value );
	}

	/**
	 * @return void
	 */
	public static function clear() {
		self::$credentials = array();
	}
}
