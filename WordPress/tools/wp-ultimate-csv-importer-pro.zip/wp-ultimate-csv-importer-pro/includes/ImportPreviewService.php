<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds import preview datasets without performing the actual import.
 *
 * Actions: uci_pro_before_preview_generation, uci_pro_after_preview_generation
 * Filters: uci_pro_preview_rows, uci_pro_preview_transformed_value
 */
class ImportPreviewService {

	private static $instance = null;

	const DEFAULT_ROW_LIMIT = 10;
	const MAX_ROW_LIMIT     = 25;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Whether import preview is enabled (filterable for backward compatibility).
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) apply_filters( 'uci_pro_enable_import_preview', true );
	}

	/**
	 * Build preview dataset for mapped import session.
	 *
	 * @param string               $hash_key Session hash key.
	 * @param array<string, mixed> $args     preview_limit, offset.
	 * @return array<string, mixed>
	 */
	public function build_preview( $hash_key, $args = array() ) {
		$hash_key = sanitize_key( $hash_key );
		if ( empty( $hash_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
			);
		}

		$sheet_service = SpreadsheetEditorService::getInstance();
		if ( ! $sheet_service->is_supported_hash( $hash_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'Import preview is not available for this file type.', 'wp-ultimate-csv-importer' ),
			);
		}

		do_action( 'uci_pro_before_preview_generation', $hash_key, $args );

		$limit = isset( $args['preview_limit'] ) ? (int) $args['preview_limit'] : self::DEFAULT_ROW_LIMIT;
		$limit = max( 1, min( self::MAX_ROW_LIMIT, $limit ) );
		$limit = (int) apply_filters( 'uci_pro_preview_rows', $limit, $hash_key, $args );

		$offset_line  = max( 1, (int) ( $args['offset'] ?? 1 ) );
		$import_type  = $this->get_import_module( $hash_key );
		$template_id  = $this->get_template_id( $hash_key );
		$map          = $sheet_service->get_stored_mapping( $hash_key );
		$file_path    = $sheet_service->resolve_import_file_path( $hash_key );
		$field_defs   = $this->flatten_mapping_fields( $map );
		$helpers      = ImportHelpers::getInstance();
		$validator    = ImportValidationService::getInstance();

		$parser_result = $this->parse_file_chunk( $file_path, $offset_line, $limit );
		$header_array  = $helpers->normalize_header_array( $parser_result['headers'] );
		$value_rows    = $parser_result['rows'];

		if ( ! empty( $value_rows ) && ! empty( $header_array ) ) {
			$value_rows = $sheet_service->merge_overrides_into_value_rows(
				$hash_key,
				$header_array,
				$value_rows,
				$offset_line
			);
		}

		$filter_handler = class_exists( 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\Hooks\\Import\\Filters' )
			? Hooks\Import\Filters::getInstance()
			: null;

		$rows           = array();
		$seen_ids       = array();
		$line           = $offset_line;

		foreach ( $value_rows as $parser_key => $value_array ) {
			if ( is_numeric( $parser_key ) ) {
				$line = (int) $parser_key;
			}

			if ( ! is_array( $value_array ) ) {
				++$line;
				continue;
			}

			$row_values = $value_array;
			if ( $filter_handler ) {
				$row_values = $filter_handler->apply_before_import_row_filter( $row_values, $hash_key, $line, $header_array );
			}

			$transformed_by_group = $this->resolve_transformed_values( $map, $header_array, $row_values, $hash_key, $line );
			$fields               = array();

			foreach ( $field_defs as $def ) {
				$destination = $def['destination_field'];
				$source      = $def['source_field'];
				$group       = $def['group'];
				$original    = $this->resolve_original_value( $source, $header_array, $row_values, $helpers );
				$transformed = isset( $transformed_by_group[ $group ][ $destination ] )
					? (string) $transformed_by_group[ $group ][ $destination ]
					: '';

				$transformed = apply_filters(
					'uci_pro_preview_transformed_value',
					$transformed,
					$destination,
					$original,
					$line,
					$hash_key,
					$map
				);

				$fields[] = array(
					'source_field'      => $source,
					'destination_field' => $destination,
					'original_value'    => $original,
					'transformed_value' => is_scalar( $transformed ) ? (string) $transformed : wp_json_encode( $transformed ),
					'is_mapped'         => true,
					'group'             => $group,
				);
			}

			$row = array(
				'row_number' => $line,
				'fields'     => $fields,
			);

			$context = array(
				'hash_key'          => $hash_key,
				'import_type'       => $import_type,
				'template_id'       => $template_id,
				'row_number'        => $line,
				'seen_identifiers'  => $seen_ids,
				'header_array'      => $header_array,
			);

			$row = $validator->validateRow( $row, $context );

			foreach ( $row['fields'] as $field ) {
				$dest = $field['destination_field'] ?? '';
				$val  = trim( (string) ( $field['transformed_value'] ?? '' ) );
				if ( $val === '' ) {
					$val = trim( (string) ( $field['original_value'] ?? '' ) );
				}
				if ( $dest !== '' && $val !== '' ) {
					$seen_ids[ $dest . '::' . strtolower( $val ) ] = $line;
				}
			}

			$rows[] = $row;
			++$line;
		}

		$total_rows = $sheet_service->get_total_data_rows_public( $hash_key );
		$summary    = $validator->getValidationSummary( $rows );

		$response = array(
			'success'                     => true,
			'rows'                        => $rows,
			'summary'                     => $summary,
			'preview_limit'               => $limit,
			'total_rows_in_file'          => $total_rows,
			'import_type'                 => $import_type,
			'template_id'                 => $template_id,
			'can_view_developer_details'  => current_user_can( 'manage_options' ),
		);

		do_action( 'uci_pro_after_preview_generation', $hash_key, $response, $args );

		return $response;
	}

	/**
	 * Re-validate a single preview row (retry action).
	 *
	 * @param string               $hash_key   Session hash.
	 * @param int                  $row_number Row number.
	 * @param array<string, mixed> $row_data   Optional row override from client.
	 * @return array<string, mixed>
	 */
	public function retry_row_validation( $hash_key, $row_number, $row_data = array() ) {
		$row_number = max( 1, (int) $row_number );
		$import_type = $this->get_import_module( $hash_key );
		$template_id = $this->get_template_id( $hash_key );

		if ( empty( $row_data['fields'] ) || ! is_array( $row_data['fields'] ) ) {
			$preview = $this->build_preview(
				$hash_key,
				array(
					'preview_limit' => 1,
					'offset'        => $row_number,
				)
			);
			if ( empty( $preview['success'] ) || empty( $preview['rows'][0] ) ) {
				return array(
					'success' => false,
					'message' => __( 'Could not reload row for validation.', 'wp-ultimate-csv-importer' ),
				);
			}
			$row = $preview['rows'][0];
		} else {
			$row = array(
				'row_number' => $row_number,
				'fields'     => $row_data['fields'],
			);
		}

		$context = array(
			'hash_key'    => $hash_key,
			'import_type' => $import_type,
			'template_id' => $template_id,
			'row_number'  => $row_number,
		);

		$row = ImportValidationService::getInstance()->validateRow( $row, $context );

		return array(
			'success' => true,
			'row'     => $row,
		);
	}

	/**
	 * Flatten mapping groups into preview field definitions.
	 *
	 * @param array<string, mixed> $map Stored mapping.
	 * @return array<int, array{group:string,destination_field:string,source_field:string}>
	 */
	private function flatten_mapping_fields( $map ) {
		$fields = array();
		if ( ! is_array( $map ) ) {
			return $fields;
		}

		foreach ( $map as $group => $group_fields ) {
			if ( ! is_array( $group_fields ) ) {
				continue;
			}
			foreach ( $group_fields as $wp_field => $csv_header ) {
				if ( empty( $wp_field ) || $wp_field === 'AI_CONFIDENCE_SCORES' ) {
					continue;
				}
				if ( strpos( (string) $wp_field, '->' ) !== false ) {
					continue;
				}
				$header = is_string( $csv_header ) ? trim( $csv_header ) : '';
				if ( $header === '' || strtolower( $header ) === 'array' ) {
					continue;
				}
				$fields[] = array(
					'group'             => (string) $group,
					'destination_field' => (string) $wp_field,
					'source_field'      => $header,
				);
			}
		}

		return $fields;
	}

	/**
	 * Resolve transformed values per mapping group using ImportHelpers.
	 *
	 * @param array<string, mixed> $map          Mapping.
	 * @param array<int, string>   $header_array Headers.
	 * @param array<int, string>   $value_array  Row values.
	 * @param string               $hash_key     Session hash.
	 * @param int                  $line_number  Row line.
	 * @return array<string, array<string, string>>
	 */
	private function resolve_transformed_values( $map, $header_array, $value_array, $hash_key, $line_number ) {
		$helpers = ImportHelpers::getInstance();
		$out     = array();

		if ( ! is_array( $map ) ) {
			return $out;
		}

		foreach ( $map as $group => $group_map ) {
			if ( ! is_array( $group_map ) || empty( $group_map ) ) {
				continue;
			}
			try {
				$values = $helpers->get_header_values( $group_map, $header_array, $value_array, $hash_key, $line_number );
				$out[ $group ] = is_array( $values ) ? $values : array();
			} catch ( \Throwable $e ) {
				$out[ $group ] = array();
			}
		}

		return $out;
	}

	/**
	 * Resolve original CSV value for a mapped source column.
	 *
	 * @param string             $source_field Source mapping value.
	 * @param array<int, string> $header_array Header row.
	 * @param array<int, string> $value_array  Data row.
	 * @param ImportHelpers      $helpers      Helper instance.
	 * @return string
	 */
	private function resolve_original_value( $source_field, $header_array, $value_array, $helpers ) {
		$source_field = trim( (string) $source_field );
		if ( $source_field === '' || strtolower( $source_field ) === 'header manipulation' ) {
			return '';
		}

		if ( preg_match( '/^\{[^}]+\}$/', $source_field ) ) {
			return $source_field;
		}

		$idx = $helpers->find_header_index( $source_field, $header_array );
		if ( false !== $idx && isset( $value_array[ $idx ] ) ) {
			return is_scalar( $value_array[ $idx ] ) ? (string) $value_array[ $idx ] : '';
		}

		if ( strpos( $source_field, '{' ) !== false ) {
			return $source_field;
		}

		return $source_field;
	}

	/**
	 * Parse a chunk of the import file.
	 *
	 * @param string $file_path   Absolute file path.
	 * @param int    $offset_line 1-based data row offset.
	 * @param int    $limit       Max rows.
	 * @return array{headers:array<int,string>,rows:array<int,array>}
	 */
	private function parse_file_chunk( $file_path, $offset_line, $limit ) {
		$parser = new SmackCSVParser();
		$res    = $parser->parseCSV( $file_path, $offset_line, $limit );
		if ( ! is_array( $res ) ) {
			return array( 'headers' => array(), 'rows' => array() );
		}
		$headers = ! empty( $res['headers'][0] ) ? (array) $res['headers'][0] : array();
		$rows    = isset( $res['values'] ) && is_array( $res['values'] ) ? $res['values'] : array();
		return array(
			'headers' => array_map( 'strval', $headers ),
			'rows'    => $rows,
		);
	}

	/**
	 * @param string $hash_key Session hash.
	 * @return string
	 */
	private function get_import_module( $hash_key ) {
		return SpreadsheetEditorService::getInstance()->get_import_module_public( $hash_key );
	}

	/**
	 * @param string $hash_key Session hash.
	 * @return int
	 */
	private function get_template_id( $hash_key ) {
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$id    = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE eventKey = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);
		return $id ? (int) $id : 0;
	}
}
