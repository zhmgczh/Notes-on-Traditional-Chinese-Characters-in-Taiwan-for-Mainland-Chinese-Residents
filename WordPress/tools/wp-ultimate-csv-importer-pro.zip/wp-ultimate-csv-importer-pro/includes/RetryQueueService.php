<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Failed import row retry queue (Pro-only).
 */
class RetryQueueService {

	private static $instance = null;

	const STATUS_PENDING = 'pending';
	const STATUS_SUCCESS = 'success';
	const STATUS_FAILED  = 'failed';

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_retry_queue';
	}

	public static function history_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_retry_history';
	}

	/**
	 * Capture a failed row after main_import_process (single hook for all import paths).
	 *
	 * @param string $session_id  Import hash_key / eventKey.
	 * @param int    $row_number  CSV/XML row index used in detailed_log.
	 * @param array  $header_array Header list for the row.
	 * @param array  $value_array  Values aligned with headers.
	 * @param string $module       Mapping module / post type.
	 * @param string $import_type  Insert or Update (file mode).
	 * @param array  $detail_log   Full detailed_log from CoreFieldsImport.
	 */
	public function maybe_capture_failed_row( $session_id, $row_number, $header_array, $value_array, $module, $import_type, $detail_log ) {
		if ( empty( $session_id ) || ! is_array( $detail_log ) ) {
			return;
		}

		$entry = isset( $detail_log[ $row_number ] ) ? $detail_log[ $row_number ] : null;
		$is_failed = $this->is_failed_log_entry( $entry );

		if ( ! $is_failed ) {
			return;
		}

		$failure_reason = $this->get_failure_message( $entry );

		if ( ! apply_filters( 'sm_uci_pro_enqueue_failed_row', true, $session_id, $row_number, $entry ) ) {
			return;
		}

		$row_payload = $this->ensure_row_payload(
			$session_id,
			(int) $row_number,
			array(
				'headers' => array_values( (array) $header_array ),
				'values'  => array_values( (array) $value_array ),
			)
		);

		if ( null === $row_payload ) {
			return;
		}

		$this->enqueue_failed_row(
			$session_id,
			(int) $row_number,
			$row_payload,
			$failure_reason,
			sanitize_text_field( (string) $module ),
			sanitize_text_field( (string) $import_type )
		);
	}

	/**
	 * Scan flushed detailed_log batch and enqueue missed failures.
	 *
	 * @param array<int|string,array<int,mixed>> $rows keyed by line number => value list.
	 */
	public function capture_from_detail_log_batch( $session_id, $detail_log, $header_array, $module, $import_type, $rows = array() ) {
		if ( empty( $session_id ) || ! is_array( $detail_log ) ) {
			return 0;
		}
		$captured = 0;
		foreach ( $detail_log as $line_number => $entry ) {
			if ( ! $this->is_failed_log_entry( $entry ) ) {
				continue;
			}
			$value_array = isset( $rows[ $line_number ] ) ? $rows[ $line_number ] : array();
			if ( $this->is_blank_row_values( $value_array ) ) {
				$from_file = $this->load_import_row_payload( $session_id, (int) $line_number, $header_array );
				if ( is_array( $from_file ) ) {
					$header_array = $from_file['headers'];
					$value_array  = $from_file['values'];
				} elseif ( $this->has_pending_row( $session_id, (int) $line_number ) ) {
					continue;
				}
			}
			$this->maybe_capture_failed_row(
				$session_id,
				(int) $line_number,
				$header_array,
				$value_array,
				$module,
				$import_type,
				array( $line_number => $entry )
			);
			$captured++;
		}
		return $captured;
	}

	public function reconcile_failed_counts( $session_id ) {
		global $wpdb;
		$pending   = $this->get_pending_count( $session_id );
		$log_table = $wpdb->prefix . 'import_detail_log';
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$log_table} SET failed = GREATEST(failed, %d) WHERE hash_key = %s",
				$pending,
				$session_id
			)
		);
		$this->sync_audit_columns( $session_id );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get_diagnostics( $session_id ) {
		global $wpdb;
		$log_table = $wpdb->prefix . 'import_detail_log';
		$counts    = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT created, updated, skipped, failed, total_records FROM {$log_table} WHERE hash_key = %s LIMIT 1",
				$session_id
			)
		);
		$stats = $this->get_session_stats( $session_id );

		return array(
			'import_detail_log' => array(
				'created' => isset( $counts->created ) ? (int) $counts->created : 0,
				'updated' => isset( $counts->updated ) ? (int) $counts->updated : 0,
				'skipped' => isset( $counts->skipped ) ? (int) $counts->skipped : 0,
				'failed'  => isset( $counts->failed ) ? (int) $counts->failed : 0,
			),
			'retry_queue'       => $stats,
		);
	}

	private function get_failure_message( $entry ) {
		if ( empty( $entry ) || ! is_array( $entry ) ) {
			return __( 'Import failed.', 'wp-ultimate-csv-importer' );
		}
		$parts = array();
		if ( ! empty( $entry['Message'] ) ) {
			$parts[] = wp_strip_all_tags( (string) $entry['Message'] );
		}
		if ( ! empty( $entry['Instruction'] ) ) {
			$parts[] = wp_strip_all_tags( (string) $entry['Instruction'] );
		}
		return ! empty( $parts ) ? implode( ' ', $parts ) : __( 'Import failed.', 'wp-ultimate-csv-importer' );
	}

	private function describe_why_not_queued( $entry ) {
		if ( empty( $entry ) || ! is_array( $entry ) ) {
			return 'No detailed_log entry for this row index.';
		}
		$state = isset( $entry['state'] ) ? $entry['state'] : '(no state)';
		return 'State=' . $state . ' — not classified as a retryable failure.';
	}

	private function get_log_text( $entry ) {
		if ( empty( $entry ) || ! is_array( $entry ) ) {
			return '';
		}
		$text = $this->get_failure_message( $entry );
		return $text;
	}

	/**
	 * @param array|null $entry detailed_log row.
	 */
	public function is_failed_log_entry( $entry ) {
		if ( empty( $entry ) || ! is_array( $entry ) ) {
			return false;
		}

		if ( isset( $entry['state'] ) && 'Failed' === $entry['state'] ) {
			return true;
		}

		if ( isset( $entry['state'] ) && in_array( $entry['state'], array( 'Inserted', 'Updated' ), true ) ) {
			return false;
		}

		$msg = $this->get_log_text( $entry );

		if ( preg_match(
			'/\b(already exists|SKIP mode|filter conditions|Duplicate Check|duplicate detection|skipped via|does not match the selected categories|AI Duplicate)\b/i',
			$msg
		) ) {
			return false;
		}

		if ( isset( $entry['state'] ) && 'Skipped' === $entry['state'] ) {
			if ( preg_match( '/^Skipped:\s*/i', $msg ) ) {
				return true;
			}
			if ( preg_match( '/\b(invalid|empty|required|error|malformed|not valid)\b/i', $msg ) ) {
				return true;
			}
		}

		if ( $msg && preg_match( '/\b(Can\'t insert|Update Failed|Failed to|Import failed|^Failed:)\b/i', $msg ) ) {
			return true;
		}

		return false;
	}

	/**
	 * @param array|null $entry detailed_log row.
	 */
	public function is_success_log_entry( $entry ) {
		if ( empty( $entry ) || ! is_array( $entry ) ) {
			return false;
		}
		return isset( $entry['state'] ) && in_array( $entry['state'], array( 'Inserted', 'Updated' ), true );
	}

	/**
	 * Insert or refresh a pending queue item for session + row.
	 */
	public function enqueue_failed_row( $session_id, $row_number, array $row_data, $failure_reason, $module, $import_type ) {
		global $wpdb;

		$table = self::table_name();
		$session_id = sanitize_text_field( $session_id );
		$row_number = (int) $row_number;

		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT retry_id, row_data FROM {$table} WHERE session_id = %s AND `row_number` = %d AND status = %s LIMIT 1",
				$session_id,
				$row_number,
				self::STATUS_PENDING
			)
		);

		$row_data = $this->ensure_row_payload( $session_id, $row_number, $row_data );
		if ( null === $row_data ) {
			return 0;
		}

		$encoded = wp_json_encode( $row_data );
		$now     = current_time( 'mysql' );

		if ( $existing ) {
			$new_score = $this->score_row_data_payload( $encoded );
			$old_score = $this->score_row_data_payload( $existing->row_data ?? '' );
			$update    = array(
				'failure_reason' => wp_strip_all_tags( (string) $failure_reason ),
				'module'         => $module,
				'import_type'    => $import_type,
				'created_at'     => $now,
			);
			if ( $new_score > $old_score ) {
				$update['row_data'] = $encoded;
			}
			$wpdb->update(
				$table,
				$update,
				array( 'retry_id' => (int) $existing->retry_id ),
				array_fill( 0, count( $update ), '%s' ),
				array( '%d' )
			);
			return (int) $existing->retry_id;
		}

		$wpdb->insert(
			$table,
			array(
				'session_id'     => $session_id,
				'row_number'     => $row_number,
				'module'         => $module,
				'import_type'    => $import_type,
				'row_data'       => $encoded,
				'failure_reason' => wp_strip_all_tags( (string) $failure_reason ),
				'status'         => self::STATUS_PENDING,
				'created_at'     => $now,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		$insert_id = (int) $wpdb->insert_id;
		if ( $insert_id > 0 ) {
			$this->sync_failed_counter( $session_id );
			$this->sync_audit_columns( $session_id );
		}

		return $insert_id;
	}

	/**
	 * Keep import_detail_log.failed in sync when rows enter the retry queue.
	 */
	private function sync_failed_counter( $session_id ) {
		global $wpdb;
		$log_table = $wpdb->prefix . 'import_detail_log';
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$log_table} SET failed = failed + 1 WHERE hash_key = %s",
				$session_id
			)
		);
	}

	public function get_pending_count( $session_id ) {
		global $wpdb;
		$table = self::table_name();
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT `row_number`) FROM {$table} WHERE session_id = %s AND status = %s",
				$session_id,
				self::STATUS_PENDING
			)
		);
	}

	/**
	 * Summary counts for UI / audit.
	 */
	public function get_session_stats( $session_id ) {
		global $wpdb;
		$table = self::table_name();

		$pending = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE session_id = %s AND status = %s",
				$session_id,
				self::STATUS_PENDING
			)
		);
		$recovered = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE session_id = %s AND status = %s",
				$session_id,
				self::STATUS_SUCCESS
			)
		);
		$failed_retry = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE session_id = %s AND status = %s",
				$session_id,
				self::STATUS_FAILED
			)
		);

		return array(
			'pending'          => $pending,
			'recovered'        => $recovered,
			'failed_after_retry' => $failed_retry,
			'total_queued'     => $pending + $recovered + $failed_retry,
		);
	}

	/**
	 * Paginated queue rows.
	 */
	public function get_records( $session_id, $page = 1, $per_page = 20, $status = null ) {
		global $wpdb;

		$table      = self::table_name();
		$page       = max( 1, (int) $page );
		$per_page   = min( 100, max( 1, (int) $per_page ) );
		$offset     = ( $page - 1 ) * $per_page;
		$session_id = sanitize_text_field( $session_id );

		$where  = 'session_id = %s';
		$params = array( $session_id );

		if ( ! empty( $status ) ) {
			$where   .= ' AND status = %s';
			$params[] = sanitize_text_field( $status );
		}

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		$total     = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) );

		$list_sql = "SELECT retry_id, session_id, `row_number`, module, import_type, failure_reason, status, created_at, retried_at
			FROM {$table} WHERE {$where} ORDER BY `row_number` ASC LIMIT %d OFFSET %d";
		$list_params = array_merge( $params, array( $per_page, $offset ) );

		$objects = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ) );
		$rows    = array();
		if ( is_array( $objects ) && ! empty( $objects ) ) {
			foreach ( $this->dedupe_queue_rows_by_line( $objects ) as $row ) {
				$rows[] = (array) $row;
			}
		}

		return array(
			'records'  => is_array( $rows ) ? $rows : array(),
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'pages'    => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
		);
	}

	public function mark_success( $retry_id ) {
		global $wpdb;
		$table = self::table_name();
		$wpdb->update(
			$table,
			array(
				'status'     => self::STATUS_SUCCESS,
				'retried_at' => current_time( 'mysql' ),
			),
			array( 'retry_id' => (int) $retry_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	public function mark_failed( $retry_id, $failure_reason ) {
		global $wpdb;
		$table = self::table_name();
		$wpdb->update(
			$table,
			array(
				'status'         => self::STATUS_PENDING,
				'failure_reason' => wp_strip_all_tags( (string) $failure_reason ),
				'retried_at'     => current_time( 'mysql' ),
			),
			array( 'retry_id' => (int) $retry_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Re-run pending rows through main_import_process (no new import session).
	 *
	 * @return array{success:bool,recovered:int,failed:int,processed:int,message?:string}
	 */
	public function process_retry_batch( $session_id, $batch_size = 25 ) {
		global $wpdb;

		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'success' => false,
				'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
			);
		}

		$session_id = sanitize_text_field( $session_id );
		$batch_size = min( 100, max( 1, (int) $batch_size ) );
		$table      = self::table_name();

		$this->prepare_session_for_retry( $session_id );

		$template_table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$file_table     = $wpdb->prefix . 'smackcsv_file_events';

		$template_row = $wpdb->get_row(
			$wpdb->prepare( "SELECT mapping, module FROM {$template_table} WHERE eventKey = %s LIMIT 1", $session_id )
		);
		if ( empty( $template_row ) ) {
			return array(
				'success' => false,
				'message' => __( 'Mapping template not found for this import session.', 'wp-ultimate-csv-importer' ),
			);
		}

		$map = maybe_unserialize( $template_row->mapping );
		if ( ! is_array( $map ) ) {
			$map = array();
		}

		$module = $template_row->module;
		$file_row = $wpdb->get_row(
			$wpdb->prepare( "SELECT mode FROM {$file_table} WHERE hash_key = %s LIMIT 1", $session_id )
		);
		$get_mode = ! empty( $file_row->mode ) ? $file_row->mode : 'Insert';

		$import_context = $this->resolve_retry_import_context( $module, $get_mode );
		$unmatched_row  = $import_context['unmatched_row'];
		$update_based_on = $import_context['update_based_on'];
		$check          = $import_context['check'];

		$pending_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE session_id = %s AND status = %s ORDER BY `row_number` ASC LIMIT %d",
				$session_id,
				self::STATUS_PENDING,
				$batch_size
			)
		);

		if ( empty( $pending_rows ) ) {
			return array(
				'success'   => true,
				'recovered' => 0,
				'failed'    => 0,
				'processed' => 0,
				'message'   => __( 'No pending failed records to retry.', 'wp-ultimate-csv-importer' ),
			);
		}

		$pending_rows = $this->dedupe_queue_rows_by_line( $pending_rows );

		$save_mapping = SaveMapping::getInstance();
		$core         = CoreFieldsImport::getInstance();
		$recovered    = 0;
		$failed       = 0;

		foreach ( $pending_rows as $queue_row ) {
			$row_data = $this->ensure_row_payload(
				$session_id,
				(int) $queue_row->row_number,
				json_decode( $queue_row->row_data, true )
			);
			if ( ! is_array( $row_data ) || empty( $row_data['headers'] ) || ! isset( $row_data['values'] ) ) {
				$reason = __( 'Invalid stored row data.', 'wp-ultimate-csv-importer' );
				$this->mark_failed( $queue_row->retry_id, $reason );
				$failed++;
				continue;
			}
			$this->maybe_persist_row_payload( (int) $queue_row->retry_id, $queue_row->row_data ?? '', $row_data );

			$line_number = (int) $queue_row->row_number;
			$core->detailed_log = array();

			try {
				$result = $save_mapping->main_import_process(
					$map,
					$row_data['headers'],
					$row_data['values'],
					$module,
					$get_mode,
					$line_number,
					$unmatched_row,
					$check,
					$session_id,
					$update_based_on,
					'',
					null,
					null,
					false,
					null
				);
			} catch ( \Throwable $e ) {
				$this->mark_failed( $queue_row->retry_id, $e->getMessage() );
				$failed++;
				continue;
			}

			$log_entry = isset( $result['detail_log'][ $line_number ] ) ? $result['detail_log'][ $line_number ] : array();

			if ( $this->is_success_log_entry( $log_entry ) ) {
				$this->mark_success( $queue_row->retry_id );
				$this->increment_recovered_counters( $session_id, $get_mode );
				$recovered++;
			} else {
				$reason = ! empty( $log_entry['Message'] ) ? $log_entry['Message'] : __( 'Retry failed.', 'wp-ultimate-csv-importer' );
				$this->mark_failed( $queue_row->retry_id, $reason );
				$failed++;
			}
		}

		$this->record_retry_history( $session_id, $recovered, $failed );
		$this->sync_audit_columns( $session_id );

		return array(
			'success'   => true,
			'recovered' => $recovered,
			'failed'    => $failed,
			'processed' => $recovered + $failed,
			'pending'   => $this->get_pending_count( $session_id ),
		);
	}

	/**
	 * Ensure import sidecar files exist before re-running rows.
	 */
	private function prepare_session_for_retry( $session_id ) {
		$upload = wp_upload_dir();
		if ( ! empty( $upload['error'] ) ) {
			return;
		}
		$session_id = sanitize_text_field( $session_id );
		$dir        = trailingslashit( $upload['basedir'] ) . 'smack_uci_uploads/imports/' . $session_id . '/';
		if ( ! wp_mkdir_p( $dir ) ) {
			return;
		}
		$txt = $dir . $session_id . '.txt';
		if ( ! file_exists( $txt ) ) {
			file_put_contents( $txt, '[]' );
		}
	}

	/**
	 * Match bulk import context for retry (Users vs posts, update field, etc.).
	 *
	 * @return array{unmatched_row:string,update_based_on:string,check:string}
	 */
	private function resolve_retry_import_context( $module, $get_mode ) {
		$pro_settings  = get_option( 'sm_uci_pro_settings', array() );
		$unmatched_row = isset( $pro_settings['unmatchedrow'] ) ? (string) $pro_settings['unmatchedrow'] : '';

		$update_based_on = get_option( 'csv_importer_update_using', '' );
		if ( empty( $update_based_on ) ) {
			$update_based_on = 'normal';
		}

		$module_l = strtolower( (string) $module );
		if ( 'users' === $module_l || str_contains( $module_l, 'user' ) ) {
			$check = 'user_email';
			if ( in_array( $update_based_on, array( 'normal', 'post_title', '' ), true ) ) {
				$update_based_on = 'user_email';
			}
		} elseif ( 'Update' === $get_mode ) {
			$check = 'post_title';
		} else {
			$check = 'post_title';
		}

		return array(
			'unmatched_row'   => $unmatched_row,
			'update_based_on' => $update_based_on,
			'check'           => $check,
		);
	}

	/**
	 * Update live import counters when a retry succeeds (same session, no new event).
	 */
	private function increment_recovered_counters( $session_id, $get_mode ) {
		global $wpdb;

		$log_table   = $wpdb->prefix . 'import_detail_log';
		$events_table = $wpdb->prefix . 'smackuci_events';

		if ( 'Update' === $get_mode ) {
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$log_table} SET updated = updated + 1, failed = GREATEST(failed - 1, 0) WHERE hash_key = %s",
					$session_id
				)
			);
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$events_table} SET updated = updated + 1, failed = GREATEST(failed - 1, 0), retry_recovered = retry_recovered + 1 WHERE eventKey = %s",
					$session_id
				)
			);
		} else {
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$log_table} SET created = created + 1, failed = GREATEST(failed - 1, 0) WHERE hash_key = %s",
					$session_id
				)
			);
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$events_table} SET created = created + 1, failed = GREATEST(failed - 1, 0), retry_recovered = retry_recovered + 1 WHERE eventKey = %s",
					$session_id
				)
			);
		}
	}

	public function record_retry_history( $session_id, $recovered, $failed ) {
		if ( $recovered <= 0 && $failed <= 0 ) {
			return;
		}

		global $wpdb;
		$table = self::history_table_name();

		$wpdb->insert(
			$table,
			array(
				'session_id'      => sanitize_text_field( $session_id ),
				'recovered_count' => (int) $recovered,
				'failed_count'    => (int) $failed,
				'user_id'         => get_current_user_id(),
				'retried_at'      => current_time( 'mysql' ),
			),
			array( '%s', '%d', '%d', '%d', '%s' )
		);
	}

	public function sync_audit_columns( $session_id ) {
		global $wpdb;
		$events_table = $wpdb->prefix . 'smackuci_events';
		$pending      = $this->get_pending_count( $session_id );

		$wpdb->update(
			$events_table,
			array( 'retry_remaining' => $pending ),
			array( 'eventKey' => $session_id ),
			array( '%d' ),
			array( '%s' )
		);
	}

	/**
	 * Build UTF-8 CSV for failed/pending rows and return a public download URL.
	 */
	public function build_failed_records_csv( $session_id, $status = self::STATUS_PENDING ) {
		global $wpdb;

		$session_id = sanitize_text_field( $session_id );
		$table      = self::table_name();
		$upload     = wp_upload_dir();

		if ( ! empty( $upload['error'] ) ) {
			return array(
				'success' => false,
				'message' => $upload['error'],
			);
		}

		$dir = trailingslashit( $upload['basedir'] ) . 'smack_uci_uploads/retry_logs/' . $session_id . '/';
		if ( ! wp_mkdir_p( $dir ) ) {
			return array(
				'success' => false,
				'message' => __( 'Could not create export directory.', 'wp-ultimate-csv-importer' ),
			);
		}

		$index_file = $dir . 'index.php';
		if ( ! file_exists( $index_file ) ) {
			file_put_contents( $index_file, '<?php' . PHP_EOL . '?>' );
		}

		$file_path = $dir . 'failed_records.csv';
		$file_url  = trailingslashit( $upload['baseurl'] ) . 'smack_uci_uploads/retry_logs/' . $session_id . '/failed_records.csv';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT retry_id, `row_number`, session_id, failure_reason, row_data, status FROM {$table} WHERE session_id = %s AND status = %s ORDER BY `row_number` ASC",
				$session_id,
				$status
			)
		);

		if ( empty( $rows ) ) {
			return array(
				'success' => false,
				'message' => __( 'No failed records found for export.', 'wp-ultimate-csv-importer' ),
			);
		}

		$rows = $this->dedupe_queue_rows_by_line( $rows );

		$fp = fopen( $file_path, 'w' );
		if ( ! $fp ) {
			return array(
				'success' => false,
				'message' => __( 'Could not write CSV file.', 'wp-ultimate-csv-importer' ),
			);
		}

		fprintf( $fp, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );

		$header_written = false;
		foreach ( $rows as $row ) {
			$payload = $this->ensure_row_payload(
				$session_id,
				(int) $row->row_number,
				json_decode( $row->row_data, true )
			);
			if ( ! is_array( $payload ) ) {
				continue;
			}
			$this->maybe_persist_row_payload( (int) $row->retry_id, $row->row_data ?? '', $payload );
			$headers = isset( $payload['headers'] ) ? (array) $payload['headers'] : array();
			$values  = isset( $payload['values'] ) ? (array) $payload['values'] : array();

			if ( ! $header_written ) {
				$csv_header = array_merge(
					array( 'row_number', 'session_id', 'failure_reason', 'retry_status' ),
					$headers
				);
				fputcsv( $fp, $csv_header );
				$header_written = true;
			}

			$line = array_merge(
				array( $row->row_number, $row->session_id, $row->failure_reason, $row->status ),
				$values
			);
			fputcsv( $fp, $line );
		}

		fclose( $fp );

		return array(
			'success'  => true,
			'file_url' => $file_url,
		);
	}

	public function delete_session_queue( $session_id ) {
		global $wpdb;
		$wpdb->delete( self::table_name(), array( 'session_id' => sanitize_text_field( $session_id ) ), array( '%s' ) );
		$wpdb->delete( self::history_table_name(), array( 'session_id' => sanitize_text_field( $session_id ) ), array( '%s' ) );

		$upload = wp_upload_dir();
		if ( empty( $upload['error'] ) ) {
			$dir = trailingslashit( $upload['basedir'] ) . 'smack_uci_uploads/retry_logs/' . sanitize_text_field( $session_id ) . '/';
			if ( is_dir( $dir ) ) {
				$files = glob( $dir . '*' );
				if ( is_array( $files ) ) {
					foreach ( $files as $file ) {
						if ( is_file( $file ) ) {
							unlink( $file );
						}
					}
				}
				@rmdir( $dir );
			}
		}
	}

	/**
	 * Keep one queue row per CSV line (prefer row_data with the most non-empty values).
	 *
	 * @param array<int,object> $rows
	 * @return array<int,object>
	 */
	private function dedupe_queue_rows_by_line( array $rows ) {
		$best = array();
		foreach ( $rows as $row ) {
			$key = (int) $row->row_number;
			if ( ! isset( $best[ $key ] ) ) {
				$best[ $key ] = $row;
				continue;
			}
			$current_score = $this->score_row_data_payload( $row->row_data ?? '' );
			$existing_score = $this->score_row_data_payload( $best[ $key ]->row_data ?? '' );
			if ( $current_score > $existing_score ) {
				$best[ $key ] = $row;
			}
		}
		return array_values( $best );
	}

	private function score_row_data_payload( $row_data ) {
		if ( is_array( $row_data ) ) {
			$row_data = wp_json_encode( $row_data );
		}
		$payload = json_decode( (string) $row_data, true );
		if ( ! is_array( $payload ) || empty( $payload['values'] ) || ! is_array( $payload['values'] ) ) {
			return 0;
		}
		$score = 0;
		foreach ( $payload['values'] as $value ) {
			if ( $value !== '' && $value !== null ) {
				$score++;
			}
		}
		return $score;
	}

	private function is_blank_row_values( $values ) {
		if ( ! is_array( $values ) || empty( $values ) ) {
			return true;
		}
		foreach ( $values as $value ) {
			if ( $value !== '' && $value !== null ) {
				return false;
			}
		}
		return true;
	}

	private function maybe_persist_row_payload( $retry_id, $stored_row_data, array $payload ) {
		if ( $retry_id <= 0 ) {
			return;
		}
		$new_score = $this->score_row_data_payload( $payload );
		$old_score = $this->score_row_data_payload( $stored_row_data );
		if ( $new_score <= $old_score ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			self::table_name(),
			array( 'row_data' => wp_json_encode( $payload ) ),
			array( 'retry_id' => $retry_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	private function has_pending_row( $session_id, $row_number ) {
		global $wpdb;
		$table = self::table_name();
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT retry_id FROM {$table} WHERE session_id = %s AND `row_number` = %d AND status = %s LIMIT 1",
				sanitize_text_field( $session_id ),
				(int) $row_number,
				self::STATUS_PENDING
			)
		);
	}

	/**
	 * Fill missing row payload from the stored import file when queue/export data is empty.
	 *
	 * @param array{headers?:array,values?:array}|null $payload
	 * @return array{headers:array,values:array}|null
	 */
	private function ensure_row_payload( $session_id, $row_number, $payload ) {
		$payload = is_array( $payload ) ? $payload : array();
		$headers = isset( $payload['headers'] ) ? array_values( (array) $payload['headers'] ) : array();
		$values  = isset( $payload['values'] ) ? array_values( (array) $payload['values'] ) : array();

		if ( ! $this->is_blank_row_values( $values ) ) {
			return array(
				'headers' => $headers,
				'values'  => $values,
			);
		}

		$from_file = $this->load_import_row_payload( $session_id, (int) $row_number, $headers );
		return is_array( $from_file ) ? $from_file : null;
	}

	/**
	 * Read one CSV row from the import file stored for this session.
	 *
	 * @return array{headers:array,values:array}|null
	 */
	public function load_import_row_payload( $session_id, $row_number, $header_array = array() ) {
		$file_path = $this->get_import_file_path( $session_id );
		if ( ! $file_path ) {
			return null;
		}

		if ( empty( $header_array ) ) {
			$header_array = $this->read_import_headers( $file_path );
		}
		if ( empty( $header_array ) ) {
			return null;
		}

		$values = $this->read_import_row_values( $file_path, (int) $row_number );
		if ( null === $values ) {
			return null;
		}

		$header_array = array_values( $header_array );
		$col_count    = count( $header_array );
		if ( count( $values ) < $col_count ) {
			$values = array_pad( $values, $col_count, '' );
		} elseif ( count( $values ) > $col_count ) {
			$values = array_slice( $values, 0, $col_count );
		}

		return array(
			'headers' => $header_array,
			'values'  => array_values( $values ),
		);
	}

	private function get_import_file_path( $session_id ) {
		$upload     = wp_upload_dir();
		$session_id = sanitize_text_field( $session_id );
		if ( ! empty( $upload['error'] ) || $session_id === '' ) {
			return '';
		}
		$file_path = trailingslashit( $upload['basedir'] ) . 'smack_uci_uploads/imports/' . $session_id . '/' . $session_id;
		return file_exists( $file_path ) ? $file_path : '';
	}

	/**
	 * @return array<int,string>
	 */
	private function read_import_headers( $file_path ) {
		$fp = fopen( $file_path, 'r' );
		if ( ! $fp ) {
			return array();
		}
		$delimiter = $this->detect_csv_delimiter( $file_path );
		$headers   = fgetcsv( $fp, 0, $delimiter, '"', '\\' );
		fclose( $fp );
		if ( ! is_array( $headers ) ) {
			return array();
		}
		return array_map( 'trim', $headers );
	}

	/**
	 * @return array<int,string>|null
	 */
	private function read_import_row_values( $file_path, $row_number ) {
		$fp = fopen( $file_path, 'r' );
		if ( ! $fp ) {
			return null;
		}

		$delimiter = $this->detect_csv_delimiter( $file_path );
		$line_idx  = 0;
		$data_idx  = 0;

		while ( ( $line = fgetcsv( $fp, 0, $delimiter, '"', '\\' ) ) !== false ) {
			if ( 0 === $line_idx ) {
				$line_idx++;
				continue;
			}

			$data_idx++;
			$file_line_number = $line_idx;

			if ( $data_idx === (int) $row_number || $file_line_number === (int) $row_number ) {
				fclose( $fp );
				return is_array( $line ) ? array_map(
					static function ( $value ) {
						return is_string( $value ) ? $value : (string) $value;
					},
					$line
				) : null;
			}

			$line_idx++;
		}

		fclose( $fp );
		return null;
	}

	private function detect_csv_delimiter( $file_path ) {
		if ( class_exists( __NAMESPACE__ . '\\SaveMapping' ) && isset( SaveMapping::$validatefile ) ) {
			$detected = SaveMapping::$validatefile->getFileDelimiter( $file_path, 5 );
			if ( $detected && $detected !== '\t' ) {
				return $detected;
			}
			if ( $detected === '\t' ) {
				return "\t";
			}
		}

		$fp = fopen( $file_path, 'r' );
		if ( ! $fp ) {
			return ',';
		}
		$sample = fgets( $fp );
		fclose( $fp );
		if ( ! is_string( $sample ) ) {
			return ',';
		}
		$delimiters = array( ',', ';', "\t", '|' );
		$best       = ',';
		$best_count = 0;
		foreach ( $delimiters as $delimiter ) {
			$count = count( str_getcsv( $sample, $delimiter, '"', '\\' ) );
			if ( $count > $best_count ) {
				$best_count = $count;
				$best       = $delimiter;
			}
		}
		return $best;
	}

	/**
	 * Resolve eventKey from log manager filename + revision.
	 */
	public function resolve_session_id_from_log( $filename, $revision ) {
		global $wpdb;
		$key = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT eventKey FROM {$wpdb->prefix}smackuci_events WHERE revision = %d AND original_file_name = %s LIMIT 1",
				(int) $revision,
				sanitize_file_name( $filename )
			)
		);
		return $key ? $key : '';
	}
}
