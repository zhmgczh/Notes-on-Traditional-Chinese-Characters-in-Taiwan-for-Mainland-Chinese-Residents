<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Dashboard {
	private static $dashboard_instance = null;
	private static $extension_instance = null;

	private function __construct() {
		add_action( 'wp_ajax_checkExtensions', array( $this, 'check_extensions' ) );
		add_action( 'wp_ajax_listuploads', array( $this, 'list_upload_function' ) );
		add_action( 'wp_ajax_locklist', array( $this, 'lock_list_function' ) );
		add_action( 'wp_ajax_BarChart', array( $this, 'fetch_BarStackedChart_data' ) );
		add_action( 'wp_ajax_dashboard_kpi_stats', array( $this, 'fetch_kpi_stats' ) );
		add_action( 'wp_ajax_dashboard_quick_stats', array( $this, 'fetch_quick_stats' ) );
		add_action( 'wp_ajax_dashboard_content_distribution', array( $this, 'fetch_content_distribution' ) );
		add_action( 'wp_ajax_dashboard_recent_activity', array( $this, 'fetch_recent_activity' ) );
		add_action( 'wp_ajax_dashboard_import_volume', array( $this, 'fetch_import_volume' ) );
	}

	public static function getInstance() {
		if ( Dashboard::$dashboard_instance == null ) {
			Dashboard::$dashboard_instance = new Dashboard();
			Dashboard::$extension_instance = new ExtensionHandler();
			return Dashboard::$dashboard_instance;
		}
		return Dashboard::$dashboard_instance;
	}

	/**
	 * Shared nonce and capability guard for dashboard AJAX handlers.
	 */
	private function verify_dashboard_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
		}
	}

	/**
	 * Returns the active import events table name.
	 *
	 * @return string
	 */
	private function get_events_table() {
		global $wpdb;
		return $wpdb->prefix . 'smackuci_events';
	}

	/**
	 * Resolves a human-readable label for an import type slug.
	 *
	 * @param string $import_type Raw import type from the events table.
	 * @return string
	 */
	private function resolve_import_type_label( $import_type ) {
		$available_types = array();
		foreach ( Dashboard::$extension_instance->get_import_post_types() as $name => $type ) {
			$available_types[ $name ] = $type;
		}
		foreach ( get_taxonomies() as $item => $taxonomy_name ) {
			$available_types[ $item ] = $taxonomy_name;
		}
		$available_types = array_flip( $available_types );

		if ( array_key_exists( $import_type, $available_types ) ) {
			return $available_types[ $import_type ];
		}

		return Dashboard::$extension_instance->import_name_as( $import_type );
	}

	/**
	 * Calculates period-over-period growth percentage.
	 *
	 * @param int $current
	 * @param int $previous
	 * @return int
	 */
	private function calculate_growth_percent( $current, $previous ) {
		$current  = (int) $current;
		$previous = (int) $previous;

		if ( $previous === 0 ) {
			return $current > 0 ? 100 : 0;
		}

		return (int) round( ( ( $current - $previous ) / $previous ) * 100 );
	}

	/**
	 * Sums a numeric column from active import events.
	 *
	 * @param string $column Column name.
	 * @param string $extra_where Optional SQL WHERE fragment (without WHERE).
	 * @return int
	 */
	private function sum_events_column( $column, $extra_where = '' ) {
		global $wpdb;
		$events_table = $this->get_events_table();
		$allowed      = array( 'created', 'updated', 'skipped', 'failed', 'processed', 'count' );
		if ( ! in_array( $column, $allowed, true ) ) {
			return 0;
		}

		$where = 'deletelog = 0';
		if ( $extra_where ) {
			$where .= ' AND ' . $extra_where;
		}

		return (int) $wpdb->get_var( "SELECT COALESCE(SUM({$column}), 0) FROM {$events_table} WHERE {$where}" );
	}

	/**
	 * Counts active import events.
	 *
	 * @param string $extra_where Optional SQL WHERE fragment (without WHERE).
	 * @return int
	 */
	private function count_events( $extra_where = '' ) {
		global $wpdb;
		$events_table = $this->get_events_table();
		$where        = 'deletelog = 0';
		if ( $extra_where ) {
			$where .= ' AND ' . $extra_where;
		}

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$events_table} WHERE {$where}" );
	}

	/**
	 * Returns KPI card metrics for the dashboard header.
	 */
	public function fetch_kpi_stats() {
		$this->verify_dashboard_request();
		global $wpdb;

		$events_table      = $this->get_events_table();
		$templates_table   = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$export_table      = $wpdb->prefix . 'sm_uci_addon_pro_export_template';
		$now               = current_time( 'mysql' );
		$current_start     = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days', strtotime( $now ) ) );
		$previous_start    = gmdate( 'Y-m-d H:i:s', strtotime( '-60 days', strtotime( $now ) ) );
		$month_start       = gmdate( 'Y-m-01 00:00:00', strtotime( $now ) );

		$imports_total = $this->count_events();
		$created_total = $this->sum_events_column( 'created' );
		$exports_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$export_table}" );
		$templates_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$templates_table}" );

		$imports_current = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$events_table} WHERE deletelog = 0 AND event_started_at >= %s",
				$current_start
			)
		);
		$imports_previous = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$events_table} WHERE deletelog = 0 AND event_started_at >= %s AND event_started_at < %s",
				$previous_start,
				$current_start
			)
		);

		$created_current = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(created), 0) FROM {$events_table} WHERE deletelog = 0 AND event_started_at >= %s",
				$current_start
			)
		);
		$created_previous = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(created), 0) FROM {$events_table} WHERE deletelog = 0 AND event_started_at >= %s AND event_started_at < %s",
				$previous_start,
				$current_start
			)
		);

		$exports_current = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$export_table} WHERE createdtime >= %s",
				$current_start
			)
		);
		$exports_previous = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$export_table} WHERE createdtime >= %s AND createdtime < %s",
				$previous_start,
				$current_start
			)
		);

		$templates_this_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$templates_table} WHERE createdtime >= %s",
				$month_start
			)
		);
		$imports_this_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$events_table} WHERE deletelog = 0 AND event_started_at >= %s",
				$month_start
			)
		);
		$templates_current = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$templates_table} WHERE createdtime >= %s",
				$current_start
			)
		);
		$templates_previous = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$templates_table} WHERE createdtime >= %s AND createdtime < %s",
				$previous_start,
				$current_start
			)
		);

		wp_send_json(
			array(
				'success' => true,
				'cards'   => array(
					'imports_run'      => array(
						'total'           => $imports_total,
						'recent_label'    => sprintf( '%d this month', $imports_this_month ),
						'growth_percent'  => $this->calculate_growth_percent( $imports_current, $imports_previous ),
					),
					'records_created'  => array(
						'total'          => $created_total,
						'growth_percent' => $this->calculate_growth_percent( $created_current, $created_previous ),
					),
					'records_exported' => array(
						'total'          => $exports_total,
						'growth_percent' => $this->calculate_growth_percent( $exports_current, $exports_previous ),
					),
					'total_templates'  => array(
						'total'          => $templates_total,
						'recent_label'   => sprintf( '%d added this month', $templates_this_month ),
						'growth_percent' => $this->calculate_growth_percent( $templates_current, $templates_previous ),
					),
				),
			)
		);
	}

	/**
	 * Returns quick summary statistics for the dashboard footer row.
	 */
	public function fetch_quick_stats() {
		$this->verify_dashboard_request();
		global $wpdb;

		$schedule_import_table = $wpdb->prefix . 'sm_uci_addon_pro_scheduled_import';
		$schedule_export_table = $wpdb->prefix . 'sm_uci_addon_pro_scheduled_export';
		$templates_table       = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$export_table          = $wpdb->prefix . 'sm_uci_addon_pro_export_template';
		$events_table          = $this->get_events_table();

		$scheduled_jobs = 0;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $schedule_import_table ) ) === $schedule_import_table ) {
			$scheduled_jobs += (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$schedule_import_table}" );
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $schedule_export_table ) ) === $schedule_export_table ) {
			$scheduled_jobs += (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$schedule_export_table}" );
		}

		$failed_jobs = (int) $wpdb->get_var( "SELECT COALESCE(SUM(failed), 0) FROM {$events_table} WHERE deletelog = 0" );
		$failed_jobs += (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$schedule_import_table} WHERE cron_status LIKE '%fail%' OR cron_status LIKE '%error%'"
		);

		$media_imported = (int) $wpdb->get_var(
			"SELECT COALESCE(SUM(created), 0) FROM {$events_table} WHERE deletelog = 0 AND import_type IN ('Media', 'ngg_pictures')"
		);

		wp_send_json(
			array(
				'success' => true,
				'stats'   => array(
					'total_imports'   => $this->count_events(),
					'total_exports'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$export_table}" ),
					'scheduled_jobs'  => $scheduled_jobs,
					'failed_jobs'     => $failed_jobs,
					'templates_saved' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$templates_table}" ),
					'media_imported'  => $media_imported,
				),
			)
		);
	}

	/**
	 * Returns record distribution grouped by import module/type.
	 */
	public function fetch_content_distribution() {
		$this->verify_dashboard_request();
		global $wpdb;

		$events_table = $this->get_events_table();
		$rows         = $wpdb->get_results(
			"SELECT import_type,
				COALESCE(SUM(created), 0) + COALESCE(SUM(updated), 0) + COALESCE(SUM(skipped), 0) + COALESCE(SUM(failed), 0) AS total
			FROM {$events_table}
			WHERE deletelog = 0
			GROUP BY import_type
			ORDER BY total DESC"
		);

		$grouped = array();
		$sum     = 0;
		foreach ( (array) $rows as $row ) {
			$label = $this->resolve_import_type_label( $row->import_type );
			$count = (int) $row->total;
			if ( $count <= 0 ) {
				continue;
			}
			if ( ! isset( $grouped[ $label ] ) ) {
				$grouped[ $label ] = 0;
			}
			$grouped[ $label ] += $count;
			$sum += $count;
		}

		$items = array();
		foreach ( $grouped as $label => $count ) {
			$items[] = array(
				'label'   => $label,
				'count'   => $count,
				'percent' => $sum > 0 ? (int) round( ( $count / $sum ) * 100 ) : 0,
			);
		}

		wp_send_json(
			array(
				'success' => true,
				'items'   => $items,
			)
		);
	}

	/**
	 * Returns the latest import activity rows for the dashboard table.
	 */
	public function fetch_recent_activity() {
		$this->verify_dashboard_request();
		global $wpdb;

		$limit = isset( $_POST['limit'] ) ? (int) $_POST['limit'] : 10;
		$limit = max( 1, min( 50, $limit ) );

		$events_table = $this->get_events_table();
		$rows         = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT original_file_name, revision, import_type, created, updated, skipped, failed,
					processing, is_terminated, count, processed, event_started_at, last_activity
				FROM {$events_table}
				WHERE deletelog = 0
				ORDER BY id DESC
				LIMIT %d",
				$limit
			)
		);

		$items = array();
		foreach ( (array) $rows as $row ) {
			$records = (int) $row->created + (int) $row->updated + (int) $row->skipped + (int) $row->failed;
			$date    = $row->event_started_at;
			if ( empty( $date ) || $date === '0000-00-00 00:00:00' ) {
				$date = $row->last_activity;
			}

			$status = 'Completed';
			if ( (int) $row->is_terminated === 1 ) {
				$status = 'Failed';
			} elseif ( (int) $row->processing === 1 && (int) $row->processed < (int) $row->count ) {
				$status = 'Processing';
			}

			$items[] = array(
				'filename' => $row->original_file_name,
				'revision' => (int) $row->revision,
				'activity' => sprintf( 'Import · %s', $row->original_file_name ),
				'module'   => $this->resolve_import_type_label( $row->import_type ),
				'created'  => (int) $row->created,
				'updated'  => (int) $row->updated,
				'skipped'  => (int) $row->skipped,
				'failed'   => (int) $row->failed,
				'records'  => $records,
				'status'   => $status,
				'date'     => $date,
			);
		}

		wp_send_json(
			array(
				'success' => true,
				'items'   => $items,
			)
		);
	}

	/**
	 * Returns import volume chart labels and counts for the selected period.
	 */
	public function fetch_import_volume() {
		$this->verify_dashboard_request();
		global $wpdb;

		$period       = isset( $_POST['period'] ) ? sanitize_key( wp_unslash( $_POST['period'] ) ) : 'yearly';
		$events_table = $this->get_events_table();
		$labels       = array();
		$counts       = array();
		$now          = current_time( 'timestamp' );

		if ( $period === 'weekly' ) {
			for ( $i = 11; $i >= 0; $i-- ) {
				$week_start = strtotime( '-' . $i . ' weeks monday this week', $now );
				$week_end   = strtotime( '+6 days 23:59:59', $week_start );
				$labels[]   = gmdate( 'M j', $week_start );
				$counts[]   = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COALESCE(SUM(created), 0) FROM {$events_table}
						WHERE deletelog = 0 AND event_started_at >= %s AND event_started_at <= %s",
						gmdate( 'Y-m-d H:i:s', $week_start ),
						gmdate( 'Y-m-d H:i:s', $week_end )
					)
				);
			}
		} elseif ( $period === 'monthly' ) {
			for ( $i = 11; $i >= 0; $i-- ) {
				$month_start = strtotime( gmdate( 'Y-m-01 00:00:00', strtotime( '-' . $i . ' months', $now ) ) );
				$month_end   = strtotime( gmdate( 'Y-m-t 23:59:59', $month_start ) );
				$labels[]    = gmdate( 'M Y', $month_start );
				$counts[]    = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COALESCE(SUM(created), 0) FROM {$events_table}
						WHERE deletelog = 0 AND event_started_at >= %s AND event_started_at <= %s",
						gmdate( 'Y-m-d H:i:s', $month_start ),
						gmdate( 'Y-m-d H:i:s', $month_end )
					)
				);
			}
		} else {
			for ( $i = 4; $i >= 0; $i-- ) {
				$year      = (int) gmdate( 'Y', strtotime( '-' . $i . ' years', $now ) );
				$labels[]  = (string) $year;
				$counts[]  = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COALESCE(SUM(created), 0) FROM {$events_table}
						WHERE deletelog = 0 AND YEAR(event_started_at) = %d",
						$year
					)
				);
			}
		}

		wp_send_json(
			array(
				'success' => true,
				'labels'  => $labels,
				'counts'  => $counts,
			)
		);
	}

	/**
	 * Returns stacked bar chart data grouped by import type.
	 */
	public function fetch_BarStackedChart_data() {
		$this->verify_dashboard_request();
		global $wpdb;

		$cli_template   = $wpdb->prefix . 'sm_uci_addon_pro_clitemplate';
		$log_table_name = $wpdb->prefix . 'import_detail_log';
		$events_table   = $this->get_events_table();
		$return_array   = array( 'success' => true );

		$get_list_of_imported_types = $wpdb->get_col( "SELECT DISTINCT import_type FROM {$events_table} WHERE deletelog = 0" );
		$cli_list_of_imported_types = $wpdb->get_col( "SELECT DISTINCT type FROM {$cli_template}" );

		if ( empty( $get_list_of_imported_types ) && ! empty( $cli_list_of_imported_types ) ) {
			$get_list_of_imported_types = $cli_list_of_imported_types;
		} else {
			foreach ( (array) $cli_list_of_imported_types as $import_type ) {
				if ( ! in_array( $import_type, $get_list_of_imported_types, true ) ) {
					$get_list_of_imported_types[] = $import_type;
				}
			}
		}

		foreach ( (array) $get_list_of_imported_types as $import_type ) {
			$import_type_data = $this->resolve_import_type_label( $import_type );

			$get_chart_data = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT COALESCE(SUM(created), 0) AS created, COALESCE(SUM(updated), 0) AS updated, COALESCE(SUM(skipped), 0) AS skipped
					FROM {$events_table}
					WHERE deletelog = 0 AND import_type = %s",
					$import_type
				)
			);

			$get_cli_data = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT COALESCE(SUM(log.created), 0) AS created, COALESCE(SUM(log.updated), 0) AS updated, COALESCE(SUM(log.skipped), 0) AS skipped
					FROM {$log_table_name} AS log
					INNER JOIN {$cli_template} AS cli ON cli.templatekey = log.templatekey
					WHERE cli.type = %s
					GROUP BY cli.type",
					$import_type
				)
			);

			$return_array[ $import_type_data ] = array(
				'created' => (int) ( $get_chart_data->created ?? 0 ) + (int) ( $get_cli_data->created ?? 0 ),
				'updated' => (int) ( $get_chart_data->updated ?? 0 ) + (int) ( $get_cli_data->updated ?? 0 ),
				'skipped' => (int) ( $get_chart_data->skipped ?? 0 ) + (int) ( $get_cli_data->skipped ?? 0 ),
			);
		}

		echo wp_json_encode( $return_array );
		wp_die();
	}

	public function list_upload_function() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
		}
		global $wpdb;
		$response        = array();
		$file_table_name = $wpdb->prefix . 'smackcsv_file_events';

		$last_data = $wpdb->get_results( "SELECT * FROM $file_table_name order by id desc limit 10", ARRAY_A );
		if ( ! $last_data ) {
			$response['success'] = false;
			$response['message'] = 'not exists';
			echo wp_json_encode( $response );
		} else {
			$response['success'] = true;
			$response['message'] = $last_data;
			echo wp_json_encode( $response );
		}

		wp_die();
	}

	public function get_config_bytes( $val ) {
		$val  = trim( $val );
		$last = strtolower( $val[ strlen( $val ) - 1 ] );
		switch ( $last ) {
			case 'g':
				$val *= 1024;
				// no break
			case 'm':
				$val *= 1024;
				// no break
			case 'k':
				$val *= 1024;
		}
		return $val;
	}

	public function lock_list_function() {
		$response        = array();
		global $wpdb;
		$file_table_name = $wpdb->prefix . 'smackcsv_file_events';
		$lock_data       = $wpdb->get_results( "SELECT * FROM $file_table_name WHERE `lock`=true" );
		if ( ! $lock_data ) {
			$response['success'] = false;
			$response['message'] = 'No lock exists';
			echo wp_json_encode( $response );
		} else {
			$response['success'] = true;
			$response['mesage']  = $lock_data;
			echo wp_json_encode( $response );
		}
		wp_die();
	}
}
