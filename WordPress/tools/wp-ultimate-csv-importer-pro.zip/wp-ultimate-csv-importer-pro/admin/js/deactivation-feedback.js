/**
 * Plugin deactivation feedback modal for the WordPress Plugins screen.
 */
( function ( $ ) {
	'use strict';

	if ( typeof smackDeactivationFeedback === 'undefined' ) {
		return;
	}

	var config = smackDeactivationFeedback;
	var strings = config.strings || {};
	var $overlay = null;
	var $modal = null;
	var $body = null;
	var $success = null;
	var $error = null;
	var $otherWrap = null;
	var $comment = null;
	var $submitBtn = null;
	var $skipBtn = null;
	var $spinner = null;
	var deactivateUrl = '';
	var lastFocusedElement = null;
	var isSubmitting = false;
	var successDelayMs = 1500;

	/**
	 * Cache DOM references.
	 */
	function cacheElements() {
		$overlay = $( '#smack-deactivation-feedback-overlay' );
		$modal = $( '#smack-deactivation-feedback-modal' );
		$body = $( '#smack-deactivation-feedback-body' );
		$success = $( '#smack-deactivation-feedback-success' );
		$error = $( '#smack-deactivation-feedback-error' );
		$otherWrap = $( '#smack-deactivation-feedback-other-wrap' );
		$comment = $( '#smack-deactivation-feedback-comment' );
		$submitBtn = $( '.smack-deactivation-feedback-submit' );
		$skipBtn = $( '.smack-deactivation-feedback-skip' );
		$spinner = $( '.smack-deactivation-feedback-spinner' );
	}

	/**
	 * Build a selector for this plugin's deactivate links.
	 *
	 * @return {string}
	 */
	function getDeactivateLinkSelector() {
		var encodedPlugin = encodeURIComponent( config.pluginBasename );

		return (
			'a[href*="action=deactivate"][href*="' + encodedPlugin + '"],' +
			'tr[data-plugin="' + config.pluginBasename + '"] .deactivate a,' +
			'#the-list tr[data-plugin="' + config.pluginBasename + '"] .row-actions .deactivate a,' +
			'#network-plugins tr[data-plugin="' + config.pluginBasename + '"] .row-actions .deactivate a'
		);
	}

	/**
	 * Whether the clicked element is a deactivate link for this plugin.
	 *
	 * @param {jQuery} $link Link element.
	 * @return {boolean}
	 */
	function isPluginDeactivateLink( $link ) {
		var href = $link.attr( 'href' ) || '';

		if ( href.indexOf( 'action=deactivate' ) === -1 ) {
			return false;
		}

		return (
			href.indexOf( encodeURIComponent( config.pluginBasename ) ) !== -1 ||
			href.indexOf( config.pluginBasename ) !== -1
		);
	}

	/**
	 * Toggle the "Other" comment field visibility.
	 */
	function toggleOtherField() {
		var selected = $( 'input[name="smack_deactivation_feedback_reason"]:checked' ).val();

		if ( selected === 'other' ) {
			$otherWrap.removeAttr( 'hidden' );
		} else {
			$otherWrap.attr( 'hidden', 'hidden' );
		}
	}

	/**
	 * Set submitting UI state.
	 *
	 * @param {boolean} submitting Whether AJAX is in progress.
	 */
	function setSubmitting( submitting ) {
		isSubmitting = submitting;
		$submitBtn.prop( 'disabled', submitting );
		$skipBtn.prop( 'disabled', submitting );

		if ( submitting ) {
			$spinner.addClass( 'is-active' );
			$submitBtn.addClass( 'is-busy' );
		} else {
			$spinner.removeClass( 'is-active' );
			$submitBtn.removeClass( 'is-busy' );
		}
	}

	/**
	 * Reset modal panels to the default form state.
	 */
	function resetModalState() {
		$body.removeAttr( 'hidden' );
		$success.attr( 'hidden', 'hidden' );
		$error.attr( 'hidden', 'hidden' ).text( '' );
		$( 'input[name="smack_deactivation_feedback_reason"][value="temporary_testing"]' ).prop( 'checked', true );
		$comment.val( '' );
		toggleOtherField();
		setSubmitting( false );
	}

	/**
	 * Show the success state before deactivation.
	 *
	 * @param {string} message Success message.
	 */
	function showSuccessState( message ) {
		$body.attr( 'hidden', 'hidden' );
		$error.attr( 'hidden', 'hidden' );
		$success.removeAttr( 'hidden' );

		if ( message ) {
			$success.find( '.smack-deactivation-feedback-success-message' ).text( message );
		}
	}

	/**
	 * Show an error message in the form.
	 *
	 * @param {string} message Error message.
	 */
	function showError( message ) {
		$error.text( message || strings.ajaxError ).removeAttr( 'hidden' );
	}

	/**
	 * Open the feedback modal.
	 *
	 * @param {string} url Deactivation URL to use after feedback.
	 */
	function openModal( url ) {
		deactivateUrl = url;
		lastFocusedElement = document.activeElement;
		resetModalState();

		$overlay.removeAttr( 'hidden' ).attr( 'aria-hidden', 'false' );
		$( 'body' ).addClass( 'smack-deactivation-feedback-open' );
		$modal.trigger( 'focus' );
	}

	/**
	 * Close the modal without deactivating.
	 */
	function closeModal() {
		if ( isSubmitting ) {
			return;
		}

		$overlay.attr( 'hidden', 'hidden' ).attr( 'aria-hidden', 'true' );
		$( 'body' ).removeClass( 'smack-deactivation-feedback-open' );
		deactivateUrl = '';
		resetModalState();

		if ( lastFocusedElement && typeof lastFocusedElement.focus === 'function' ) {
			lastFocusedElement.focus();
		}
	}

	/**
	 * Navigate to the stored deactivation URL.
	 */
	function proceedWithDeactivation() {
		if ( ! deactivateUrl ) {
			return;
		}

		window.location.href = deactivateUrl;
	}

	/**
	 * Submit feedback via AJAX, show success, then deactivate.
	 */
	function submitFeedback() {
		if ( isSubmitting || ! deactivateUrl ) {
			return;
		}

		var reason = $( 'input[name="smack_deactivation_feedback_reason"]:checked' ).val() || '';
		var comment = $comment.val() || '';

		$error.attr( 'hidden', 'hidden' ).text( '' );
		setSubmitting( true );

		$.ajax( {
			url: config.ajaxUrl,
			type: 'POST',
			dataType: 'json',
			data: {
				action: config.action,
				nonce: config.nonce,
				feedback_reason: reason,
				feedback_comment: comment,
			},
		} )
			.done( function ( response ) {
				if ( response && response.success ) {
					setSubmitting( false );
					showSuccessState(
						( response.data && response.data.message ) ? response.data.message : strings.successMessage
					);
					window.setTimeout( proceedWithDeactivation, successDelayMs );
					return;
				}

				setSubmitting( false );
				showError(
					( response && response.data && response.data.message ) ? response.data.message : strings.ajaxError
				);
			} )
			.fail( function ( xhr ) {
				setSubmitting( false );

				var message = strings.ajaxError;

				if ( xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ) {
					message = xhr.responseJSON.data.message;
				}

				showError( message );
			} );
	}

	/**
	 * Bind UI events.
	 */
	function bindEvents() {
		$( document ).on( 'click', getDeactivateLinkSelector(), function ( event ) {
			var $link = $( this );

			if ( ! isPluginDeactivateLink( $link ) ) {
				return;
			}

			event.preventDefault();
			event.stopPropagation();
			openModal( $link.attr( 'href' ) );
		} );

		$( document ).on( 'change', 'input[name="smack_deactivation_feedback_reason"]', toggleOtherField );

		$submitBtn.on( 'click', submitFeedback );

		$skipBtn.on( 'click', function () {
			if ( isSubmitting ) {
				return;
			}
			proceedWithDeactivation();
		} );

		$overlay.on( 'click', function ( event ) {
			if ( event.target === $overlay.get( 0 ) ) {
				closeModal();
			}
		} );

		$( '.smack-deactivation-feedback-close' ).on( 'click', closeModal );

		$( document ).on( 'keydown', function ( event ) {
			if ( ! $overlay.length || $overlay.is( '[hidden]' ) ) {
				return;
			}

			if ( event.key === 'Escape' || event.keyCode === 27 ) {
				event.preventDefault();
				closeModal();
			}
		} );
	}

	/**
	 * Initialize on DOM ready.
	 */
	$( function () {
		cacheElements();

		if ( ! $overlay.length || ! $modal.length ) {
			return;
		}

		bindEvents();
	} );
}( jQuery ) );
