<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Controllers\DatabaseMigrationController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DatabaseMigrationBootstrap {

	public static function init() {
		$base = __DIR__;
		require_once $base . '/Contracts/DatabaseConnectorInterface.php';
		require_once $base . '/Services/CredentialCipher.php';
		require_once $base . '/Connectors/AbstractPdoConnector.php';
		require_once $base . '/Connectors/MysqlConnector.php';
		require_once $base . '/Connectors/MariaDbConnector.php';
		require_once $base . '/Connectors/PostgreSqlConnector.php';
		require_once $base . '/Connectors/SqlServerConnector.php';
		require_once $base . '/Connectors/ConnectorFactory.php';
		require_once $base . '/Services/ConnectionRepository.php';
		require_once $base . '/Services/DbImportSessionService.php';
		require_once $base . '/Services/ExternalDbRowSource.php';
		require_once $base . '/Controllers/DatabaseMigrationController.php';

		DatabaseMigrationController::getInstance();
	}
}
