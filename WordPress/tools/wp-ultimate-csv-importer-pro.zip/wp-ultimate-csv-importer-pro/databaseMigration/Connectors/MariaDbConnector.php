<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** MariaDB uses the same PDO MySQL driver as MySQL. */
class MariaDbConnector extends MysqlConnector {
}
