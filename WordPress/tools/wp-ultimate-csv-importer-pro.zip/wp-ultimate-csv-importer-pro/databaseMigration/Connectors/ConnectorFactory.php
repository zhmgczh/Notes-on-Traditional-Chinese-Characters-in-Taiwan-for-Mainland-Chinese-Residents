<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Contracts\DatabaseConnectorInterface;
use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\ConnectionRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ConnectorFactory {

	/**
	 * @param array<string,mixed> $connection Row from ConnectionRepository.
	 * @return DatabaseConnectorInterface
	 */
	public static function from_connection_row( array $connection ) {
		$config = ConnectionRepository::connection_config_from_row( $connection );
		return self::create( $config );
	}

	/**
	 * @param array<string,mixed> $config host, port, database_name, username, password, db_type, ssl_enabled.
	 * @return DatabaseConnectorInterface
	 */
	public static function create( array $config ) {
		$type = isset( $config['db_type'] ) ? strtolower( (string) $config['db_type'] ) : 'mysql';
		switch ( $type ) {
			case 'mariadb':
				return new MariaDbConnector( $config );
			case 'pgsql':
			case 'postgresql':
				return new PostgreSqlConnector( $config );
			case 'sqlsrv':
			case 'mssql':
				return new SqlServerConnector( $config );
			case 'mysql':
			default:
				return new MysqlConnector( $config );
		}
	}
}
