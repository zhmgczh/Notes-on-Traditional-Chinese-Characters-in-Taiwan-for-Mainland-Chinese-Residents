<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

use PDO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SqlServerConnector extends AbstractPdoConnector {

	protected function buildDsn() {
		$drivers = PDO::getAvailableDrivers();
		if ( ! in_array( 'sqlsrv', $drivers, true ) && ! in_array( 'dblib', $drivers, true ) ) {
			throw new \RuntimeException( __( 'SQL Server PDO driver (sqlsrv) is not available on this server.', 'wp-ultimate-csv-importer' ) );
		}
		$host = (string) ( $this->config['host'] ?? '127.0.0.1' );
		$port = (int) ( $this->config['port'] ?? 1433 );
		$db   = (string) ( $this->config['database_name'] ?? '' );
		if ( in_array( 'sqlsrv', $drivers, true ) ) {
			return sprintf( 'sqlsrv:Server=%s,%d;Database=%s', $host, $port, $db );
		}
		return sprintf( 'dblib:host=%s:%d;dbname=%s', $host, $port, $db );
	}

	protected function pdoOptions() {
		return array( PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC );
	}

	protected function bracket( $name ) {
		$this->assertSafeIdentifier( $name );
		return '[' . $name . ']';
	}

	public function getTables( $search = null, $limit = 100, $offset = 0 ) {
		$this->connect();
		$sql  = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME";
		$stmt = $this->pdo->query( $sql );
		$all  = array();
		if ( $stmt ) {
			while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ) {
				if ( ! empty( $row['TABLE_NAME'] ) ) {
					$all[] = (string) $row['TABLE_NAME'];
				}
			}
		}
		if ( $search !== null && $search !== '' ) {
			$needle = strtolower( (string) $search );
			$all    = array_values(
				array_filter(
					$all,
					function ( $n ) use ( $needle ) {
						return strpos( strtolower( $n ), $needle ) !== false;
					}
				)
			);
		}
		$limit  = max( 1, min( 500, (int) $limit ) );
		$offset = max( 0, (int) $offset );
		return array( 'tables' => array_slice( $all, $offset, $limit ), 'total' => count( $all ) );
	}

	public function getColumns( $table ) {
		$this->connect();
		$this->assertSafeIdentifier( $table );
		$stmt = $this->pdo->prepare(
			'SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? ORDER BY ORDINAL_POSITION'
		);
		$stmt->execute( array( $table ) );
		$out = array();
		while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ) {
			$out[] = array(
				'name'     => (string) $row['COLUMN_NAME'],
				'type'     => (string) $row['DATA_TYPE'],
				'nullable' => strtoupper( (string) $row['IS_NULLABLE'] ) === 'YES',
				'key'      => '',
			);
		}
		return $out;
	}

	public function countRows( $table ) {
		$this->connect();
		$q = $this->bracket( $table );
		return (int) $this->pdo->query( 'SELECT COUNT(*) FROM ' . $q )->fetchColumn();
	}

	public function previewRows( $table, $limit = 20, $offset = 0, $order_column = null ) {
		return $this->getBatchRecords( $table, $limit, $offset, $order_column );
	}

	public function getBatchRecords( $table, $limit, $offset, $order_column = null ) {
		$this->connect();
		$limit  = max( 1, (int) $limit );
		$offset = max( 0, (int) $offset );
		$cols   = $this->getColumns( $table );
		$order  = $this->resolveOrderColumn( $cols, $order_column );
		$q      = $this->bracket( $table );
		$oc     = $this->bracket( $order );
		$sql    = 'SELECT * FROM ' . $q . ' ORDER BY ' . $oc . ' ASC OFFSET ' . $offset . ' ROWS FETCH NEXT ' . $limit . ' ROWS ONLY';
		$stmt   = $this->pdo->query( $sql );
		$rows   = $stmt ? $stmt->fetchAll( PDO::FETCH_ASSOC ) : array();
		return $this->rowsToHeaderValues( $rows );
	}
}
