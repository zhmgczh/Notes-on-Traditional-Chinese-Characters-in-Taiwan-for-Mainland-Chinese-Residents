<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

use PDO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PostgreSqlConnector extends AbstractPdoConnector {

	protected function buildDsn() {
		if ( ! in_array( 'pgsql', PDO::getAvailableDrivers(), true ) ) {
			throw new \RuntimeException( __( 'pdo_pgsql is not available on this server.', 'wp-ultimate-csv-importer' ) );
		}
		$host = (string) ( $this->config['host'] ?? '127.0.0.1' );
		$port = (int) ( $this->config['port'] ?? 5432 );
		$db   = (string) ( $this->config['database_name'] ?? '' );
		return sprintf( 'pgsql:host=%s;port=%d;dbname=%s', $host, $port, $db );
	}

	protected function pdoOptions() {
		return array( PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC );
	}

	protected function quoteIdent( $name ) {
		$this->assertSafeIdentifier( $name );
		return '"' . $name . '"';
	}

	public function getTables( $search = null, $limit = 100, $offset = 0 ) {
		$this->connect();
		$limit  = max( 1, min( 500, (int) $limit ) );
		$offset = max( 0, (int) $offset );
		$sql    = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name";
		$stmt   = $this->pdo->query( $sql );
		$all    = array();
		if ( $stmt ) {
			while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ) {
				if ( ! empty( $row['table_name'] ) ) {
					$all[] = (string) $row['table_name'];
				}
			}
		}
		if ( $search !== null && $search !== '' ) {
			$needle = strtolower( (string) $search );
			$all    = array_values(
				array_filter(
					$all,
					function ( $n ) use ( $needle ) {
						return strpos( strtolower( $n ), $needle ) !== false;
					}
				)
			);
		}
		return array( 'tables' => array_slice( $all, $offset, $limit ), 'total' => count( $all ) );
	}

	public function getColumns( $table ) {
		$this->connect();
		$this->assertSafeIdentifier( $table );
		$stmt = $this->pdo->prepare(
			'SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_schema = %s AND table_name = %s ORDER BY ordinal_position'
		);
		$stmt->execute( array( 'public', $table ) );
		$out = array();
		while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ) {
			$out[] = array(
				'name'     => (string) $row['column_name'],
				'type'     => (string) $row['data_type'],
				'nullable' => strtoupper( (string) $row['is_nullable'] ) === 'YES',
				'key'      => '',
			);
		}
		return $out;
	}

	public function countRows( $table ) {
		$this->connect();
		$q = $this->quoteIdent( $table );
		return (int) $this->pdo->query( 'SELECT COUNT(*) FROM ' . $q )->fetchColumn();
	}

	public function previewRows( $table, $limit = 20, $offset = 0, $order_column = null ) {
		return $this->getBatchRecords( $table, $limit, $offset, $order_column );
	}

	public function getBatchRecords( $table, $limit, $offset, $order_column = null ) {
		$this->connect();
		$limit  = max( 1, (int) $limit );
		$offset = max( 0, (int) $offset );
		$cols   = $this->getColumns( $table );
		$order  = $this->resolveOrderColumn( $cols, $order_column );
		$q      = $this->quoteIdent( $table );
		$oc     = $this->quoteIdent( $order );
		$sql    = 'SELECT * FROM ' . $q . ' ORDER BY ' . $oc . ' ASC LIMIT ' . $limit . ' OFFSET ' . $offset;
		$stmt   = $this->pdo->query( $sql );
		$rows   = $stmt ? $stmt->fetchAll( PDO::FETCH_ASSOC ) : array();
		return $this->rowsToHeaderValues( $rows );
	}
}
