<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Contracts\DatabaseConnectorInterface;
use PDO;
use PDOException;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractPdoConnector implements DatabaseConnectorInterface {

	/** @var array<string,mixed> */
	protected $config;

	/** @var PDO|null */
	protected $pdo;

	/**
	 * @param array<string,mixed> $config
	 */
	public function __construct( array $config ) {
		$this->config = $config;
	}

	abstract protected function buildDsn();

	/**
	 * @return array<int,mixed>
	 */
	abstract protected function pdoOptions();

	public function connect() {
		if ( $this->pdo instanceof PDO ) {
			return;
		}
		if ( ! class_exists( PDO::class ) ) {
			throw new \RuntimeException( __( 'PDO extension is required for database migration.', 'wp-ultimate-csv-importer' ) );
		}
		try {
			$this->pdo = new PDO(
				$this->buildDsn(),
				(string) ( $this->config['username'] ?? '' ),
				(string) ( $this->config['password'] ?? '' ),
				$this->pdoOptions()
			);
			$this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch ( PDOException $e ) {
			throw new \RuntimeException( $e->getMessage(), (int) $e->getCode(), $e );
		}
	}

	public function disconnect() {
		$this->pdo = null;
	}

	public function testConnection() {
		try {
			$this->connect();
			$version = $this->pdo ? (string) $this->pdo->getAttribute( PDO::ATTR_SERVER_VERSION ) : '';
			$this->disconnect();
			return array(
				'success'        => true,
				'message'        => __( 'Connection successful.', 'wp-ultimate-csv-importer' ),
				'server_version' => $version,
			);
		} catch ( \Throwable $e ) {
			$this->disconnect();
			return array(
				'success' => false,
				'message' => $e->getMessage(),
			);
		}
	}

	/**
	 * @param string $identifier Table or column name.
	 */
	protected function assertSafeIdentifier( $identifier ) {
		$identifier = (string) $identifier;
		if ( $identifier === '' || ! preg_match( '/^[a-zA-Z0-9_]+$/', $identifier ) ) {
			throw new \InvalidArgumentException( __( 'Invalid database identifier.', 'wp-ultimate-csv-importer' ) );
		}
	}

	/**
	 * @return array{headers:array<int,string>,rows:array<int,array<int,string>>}
	 */
	protected function rowsToHeaderValues( array $assoc_rows ) {
		if ( $assoc_rows === array() ) {
			return array( 'headers' => array(), 'rows' => array() );
		}
		$headers = array_keys( $assoc_rows[0] );
		$rows    = array();
		foreach ( $assoc_rows as $row ) {
			$line = array();
			foreach ( $headers as $h ) {
				$val = isset( $row[ $h ] ) ? $row[ $h ] : '';
				if ( is_scalar( $val ) || $val === null ) {
					$line[] = (string) $val;
				} else {
					$line[] = wp_json_encode( $val );
				}
			}
			$rows[] = $line;
		}
		return array( 'headers' => $headers, 'rows' => $rows );
	}

	/**
	 * @param array<int,array{name:string,type:string,nullable:bool,key:string}> $columns
	 */
	protected function resolveOrderColumn( $columns, $order_column = null ) {
		if ( $order_column ) {
			$this->assertSafeIdentifier( $order_column );
			return $order_column;
		}
		foreach ( $columns as $col ) {
			if ( ! empty( $col['key'] ) && stripos( (string) $col['key'], 'pri' ) !== false ) {
				return $col['name'];
			}
		}
		if ( ! empty( $columns[0]['name'] ) ) {
			$this->assertSafeIdentifier( $columns[0]['name'] );
			return $columns[0]['name'];
		}
		throw new \RuntimeException( __( 'Could not determine order column for pagination.', 'wp-ultimate-csv-importer' ) );
	}
}
