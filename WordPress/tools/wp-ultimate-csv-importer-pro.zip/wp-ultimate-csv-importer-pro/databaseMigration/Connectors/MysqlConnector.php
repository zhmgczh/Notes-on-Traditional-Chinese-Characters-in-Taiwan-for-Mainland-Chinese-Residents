<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors;

use PDO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MysqlConnector extends AbstractPdoConnector {

	protected function buildDsn() {
		$host = (string) ( $this->config['host'] ?? '127.0.0.1' );
		$port = (int) ( $this->config['port'] ?? 3306 );
		$db   = (string) ( $this->config['database_name'] ?? '' );
		return sprintf( 'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port, $db );
	}

	protected function pdoOptions() {
		$opts = array(
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		);
		if ( ! empty( $this->config['ssl_enabled'] ) ) {
			if ( defined( 'PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT' ) ) {
				$opts[ PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT ] = true;
			}
		}
		return $opts;
	}

	protected function quoteTable( $table ) {
		$this->assertSafeIdentifier( $table );
		return '`' . $table . '`';
	}

	protected function quoteColumn( $column ) {
		$this->assertSafeIdentifier( $column );
		return '`' . $column . '`';
	}

	public function getTables( $search = null, $limit = 100, $offset = 0 ) {
		$this->connect();
		$limit  = max( 1, min( 500, (int) $limit ) );
		$offset = max( 0, (int) $offset );
		$sql    = 'SHOW TABLES';
		$stmt   = $this->pdo->query( $sql );
		$all    = array();
		if ( $stmt ) {
			while ( $row = $stmt->fetch( PDO::FETCH_NUM ) ) {
				if ( isset( $row[0] ) ) {
					$all[] = (string) $row[0];
				}
			}
		}
		if ( $search !== null && $search !== '' ) {
			$needle = strtolower( (string) $search );
			$all    = array_values(
				array_filter(
					$all,
					function ( $name ) use ( $needle ) {
						return strpos( strtolower( $name ), $needle ) !== false;
					}
				)
			);
		}
		$total  = count( $all );
		$slice  = array_slice( $all, $offset, $limit );
		return array( 'tables' => $slice, 'total' => $total );
	}

	public function getColumns( $table ) {
		$this->connect();
		$q    = $this->quoteTable( $table );
		$stmt = $this->pdo->query( 'SHOW COLUMNS FROM ' . $q );
		$out  = array();
		if ( $stmt ) {
			while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ) {
				$out[] = array(
					'name'     => isset( $row['Field'] ) ? (string) $row['Field'] : '',
					'type'     => isset( $row['Type'] ) ? (string) $row['Type'] : '',
					'nullable' => isset( $row['Null'] ) && strtoupper( (string) $row['Null'] ) === 'YES',
					'key'      => isset( $row['Key'] ) ? (string) $row['Key'] : '',
				);
			}
		}
		return $out;
	}

	public function countRows( $table ) {
		$this->connect();
		$q   = $this->quoteTable( $table );
		$sql = 'SELECT COUNT(*) FROM ' . $q;
		return (int) $this->pdo->query( $sql )->fetchColumn();
	}

	public function previewRows( $table, $limit = 20, $offset = 0, $order_column = null ) {
		return $this->getBatchRecords( $table, $limit, $offset, $order_column );
	}

	public function getBatchRecords( $table, $limit, $offset, $order_column = null ) {
		$this->connect();
		$limit  = max( 1, (int) $limit );
		$offset = max( 0, (int) $offset );
		$cols   = $this->getColumns( $table );
		$order  = $this->resolveOrderColumn( $cols, $order_column );
		$q      = $this->quoteTable( $table );
		$oc     = $this->quoteColumn( $order );
		$select = '*';
		if ( ! empty( $cols ) ) {
			$parts = array();
			foreach ( $cols as $col ) {
				if ( ! empty( $col['name'] ) ) {
					$parts[] = $this->quoteColumn( $col['name'] );
				}
			}
			if ( ! empty( $parts ) ) {
				$select = implode( ', ', $parts );
			}
		}
		$sql  = 'SELECT ' . $select . ' FROM ' . $q . ' ORDER BY ' . $oc . ' ASC LIMIT ' . (int) $limit . ' OFFSET ' . (int) $offset;
		$stmt = $this->pdo->query( $sql );
		$rows = $stmt ? $stmt->fetchAll( PDO::FETCH_ASSOC ) : array();
		return $this->rowsToHeaderValues( $rows );
	}
}
