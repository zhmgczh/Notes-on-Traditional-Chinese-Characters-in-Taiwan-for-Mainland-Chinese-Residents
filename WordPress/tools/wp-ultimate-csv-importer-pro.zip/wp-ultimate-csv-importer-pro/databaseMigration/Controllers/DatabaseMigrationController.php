<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Controllers;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors\ConnectorFactory;
use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\ConnectionRepository;
use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DatabaseMigrationController {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$actions = array(
			'uci_db_migration_test_connection',
			'uci_db_migration_save_connection',
			'uci_db_migration_list_connections',
			'uci_db_migration_delete_connection',
			'uci_db_migration_list_tables',
			'uci_db_migration_get_columns',
			'uci_db_migration_preview_rows',
			'uci_db_migration_prepare_import',
		);
		foreach ( $actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, str_replace( 'uci_db_migration_', 'ajax_', $action ) ) );
		}
	}

	private function required_capability() {
		return apply_filters( 'uci_db_migration_capability', 'manage_options' );
	}

	private function verify_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( $this->required_capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ) ) );
		}
	}

	/**
	 * @return array<string,mixed>
	 */
	private function connection_input_from_post() {
		return array(
			'id'              => isset( $_POST['id'] ) ? (int) $_POST['id'] : 0,
			'connection_name' => isset( $_POST['connection_name'] ) ? wp_unslash( $_POST['connection_name'] ) : '',
			'db_type'         => isset( $_POST['db_type'] ) ? sanitize_key( wp_unslash( $_POST['db_type'] ) ) : 'mysql',
			'host'            => isset( $_POST['host'] ) ? wp_unslash( $_POST['host'] ) : '',
			'port'            => isset( $_POST['port'] ) ? (int) $_POST['port'] : 3306,
			'database_name'   => isset( $_POST['database'] ) ? wp_unslash( $_POST['database'] ) : ( isset( $_POST['database_name'] ) ? wp_unslash( $_POST['database_name'] ) : '' ),
			'username'        => isset( $_POST['username'] ) ? wp_unslash( $_POST['username'] ) : '',
			'password'        => isset( $_POST['password'] ) ? wp_unslash( $_POST['password'] ) : '',
			'ssl_enabled'     => isset( $_POST['ssl_enabled'] ) ? wp_unslash( $_POST['ssl_enabled'] ) : '',
		);
	}

	public function ajax_test_connection() {
		$this->verify_request();
		$input = $this->connection_input_from_post();
		if ( ! empty( $input['id'] ) && empty( $input['password'] ) ) {
			$row = ( new ConnectionRepository() )->get( (int) $input['id'] );
			if ( $row ) {
				$config = ConnectionRepository::connection_config_from_row( $row );
			} else {
				wp_send_json_error( array( 'message' => __( 'Connection not found.', 'wp-ultimate-csv-importer' ) ) );
			}
		} else {
			$config = array(
				'db_type'       => $input['db_type'],
				'host'          => sanitize_text_field( $input['host'] ),
				'port'          => (int) $input['port'],
				'database_name' => sanitize_text_field( $input['database_name'] ),
				'username'      => sanitize_text_field( $input['username'] ),
				'password'      => (string) $input['password'],
				'ssl_enabled'   => ! empty( $input['ssl_enabled'] ),
			);
		}
		$result = ConnectorFactory::create( $config )->testConnection();
		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $result );
		}
		wp_send_json_error( $result );
	}

	public function ajax_save_connection() {
		$this->verify_request();
		$repo   = new ConnectionRepository();
		$result = $repo->save( $this->connection_input_from_post() );
		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $result );
		}
		wp_send_json_error( $result );
	}

	public function ajax_list_connections() {
		$this->verify_request();
		wp_send_json_success( array( 'connections' => ( new ConnectionRepository() )->list_connections() ) );
	}

	public function ajax_delete_connection() {
		$this->verify_request();
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		wp_send_json_success( ( new ConnectionRepository() )->delete( $id ) );
	}

	/**
	 * @return \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Contracts\DatabaseConnectorInterface|null
	 */
	private function connector_from_request() {
		$connection_id = isset( $_POST['connection_id'] ) ? (int) $_POST['connection_id'] : 0;
		if ( $connection_id <= 0 ) {
			return null;
		}
		$row = ( new ConnectionRepository() )->get( $connection_id );
		if ( ! $row ) {
			return null;
		}
		return ConnectorFactory::from_connection_row( $row );
	}

	public function ajax_list_tables() {
		$this->verify_request();
		$connector = $this->connector_from_request();
		if ( ! $connector ) {
			wp_send_json_error( array( 'message' => __( 'Invalid connection.', 'wp-ultimate-csv-importer' ) ) );
		}
		$search = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$limit  = isset( $_POST['limit'] ) ? (int) $_POST['limit'] : 100;
		try {
			$connector->connect();
			$data = $connector->getTables( $search, $limit, $offset );
			$connector->disconnect();
			wp_send_json_success( $data );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public function ajax_get_columns() {
		$this->verify_request();
		$table = isset( $_POST['table'] ) ? sanitize_text_field( wp_unslash( $_POST['table'] ) ) : '';
		$connector = $this->connector_from_request();
		if ( ! $connector || $table === '' ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', 'wp-ultimate-csv-importer' ) ) );
		}
		try {
			$connector->connect();
			$cols = $connector->getColumns( $table );
			$connector->disconnect();
			wp_send_json_success( array( 'columns' => $cols ) );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public function ajax_preview_rows() {
		$this->verify_request();
		$table  = isset( $_POST['table'] ) ? sanitize_text_field( wp_unslash( $_POST['table'] ) ) : '';
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$limit  = isset( $_POST['limit'] ) ? min( 20, (int) $_POST['limit'] ) : 20;
		$connector = $this->connector_from_request();
		if ( ! $connector || $table === '' ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', 'wp-ultimate-csv-importer' ) ) );
		}
		try {
			$connector->connect();
			$cols   = $connector->getColumns( $table );
			$order  = '';
			foreach ( $cols as $c ) {
				if ( ! empty( $c['key'] ) && stripos( (string) $c['key'], 'pri' ) !== false ) {
					$order = $c['name'];
					break;
				}
			}
			if ( $order === '' && ! empty( $cols[0]['name'] ) ) {
				$order = $cols[0]['name'];
			}
			$batch = $connector->previewRows( $table, $limit, $offset, $order ?: null );
			$total = $connector->countRows( $table );
			$connector->disconnect();
			wp_send_json_success(
				array(
					'headers'    => $batch['headers'],
					'rows'       => $batch['rows'],
					'total_rows' => $total,
					'offset'     => $offset,
					'limit'      => $limit,
				)
			);
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public function ajax_prepare_import() {
		$this->verify_request();
		$connection_id = isset( $_POST['connection_id'] ) ? (int) $_POST['connection_id'] : 0;
		$table         = isset( $_POST['table'] ) ? sanitize_text_field( wp_unslash( $_POST['table'] ) ) : '';
		$hash_in       = isset( $_POST['HashKey'] ) ? sanitize_key( wp_unslash( $_POST['HashKey'] ) ) : '';

		$result = DbImportSessionService::getInstance()->prepare_import( $connection_id, $table, $hash_in );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$validate = \Smackcoders\UCI\Proaddons\UltimatePro\ValidateFile::getInstance();
		$file_path = '';
		$core = \Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro::getInstance();
		$upload_base = $core->create_upload_dir();
		if ( $upload_base ) {
			$file_path = $upload_base . $result['hashkey'] . '/' . $result['hashkey'];
		}
		$filesize_human = '0 B';
		if ( $file_path && file_exists( $file_path ) ) {
			$filesize_human = $validate->formatSizeUnits( filesize( $file_path ) );
		}

		wp_send_json_success(
			array_merge(
				$result,
				array(
					'success'   => true,
					'message'   => __( 'Database table prepared for import.', 'wp-ultimate-csv-importer' ),
					'file_size' => $filesize_human,
				)
			)
		);
	}
}
