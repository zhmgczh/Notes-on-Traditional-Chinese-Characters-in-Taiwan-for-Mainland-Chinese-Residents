<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface DatabaseConnectorInterface {

	/**
	 * @throws \RuntimeException
	 */
	public function connect();

	public function disconnect();

	/**
	 * @return array{success:bool,message:string,server_version?:string}
	 */
	public function testConnection();

	/**
	 * @return array{tables:array<int,string>,total:int}
	 */
	public function getTables( $search = null, $limit = 100, $offset = 0 );

	/**
	 * @return array<int,array{name:string,type:string,nullable:bool,key:string}>
	 */
	public function getColumns( $table );

	/**
	 * @return array{headers:array<int,string>,rows:array<int,array<int,string>>}
	 */
	public function previewRows( $table, $limit = 20, $offset = 0, $order_column = null );

	/**
	 * @return array{headers:array<int,string>,rows:array<int,array<int,string>>}
	 */
	public function getBatchRecords( $table, $limit, $offset, $order_column = null );

	public function countRows( $table );
}
