# Database Migration (Pro)

Direct import from external databases into WordPress using the existing CSV Importer pipeline (`main_import_process` / `bulk_import`).

## Supported sources

- **MySQL / MariaDB** — primary, PDO `mysql`
- **PostgreSQL** — requires `pdo_pgsql`
- **SQL Server** — requires `pdo_sqlsrv` (often unavailable on shared hosting)

## Admin UI

Upload dashboard → **Import from Database** tab.

## AJAX actions

All require `manage_options` and nonce `smack-ultimate-csv-importer-pro`:

- `uci_db_migration_test_connection`
- `uci_db_migration_save_connection`
- `uci_db_migration_list_connections`
- `uci_db_migration_delete_connection`
- `uci_db_migration_list_tables`
- `uci_db_migration_get_columns`
- `uci_db_migration_preview_rows`
- `uci_db_migration_prepare_import`

## Tables

- `{prefix}sm_uci_addon_pro_db_connections` — encrypted credentials
- `{prefix}sm_uci_addon_pro_db_import_sessions` — links `hash_key` to source table + cursor

## Filters

- `uci_db_migration_capability` — default `manage_options`
- `uci_db_migration_batch_size` — batch sizing (future)
