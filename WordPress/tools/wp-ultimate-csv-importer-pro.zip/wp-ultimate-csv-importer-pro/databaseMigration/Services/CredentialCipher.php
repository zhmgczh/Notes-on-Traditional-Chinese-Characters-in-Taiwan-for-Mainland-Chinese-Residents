<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Encrypts connection passwords at rest using site-specific keys.
 */
class CredentialCipher {

	/**
	 * @param string $plain Password or secret.
	 * @return string Base64 payload or empty string.
	 */
	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( $plain === '' ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}
		$key = hash( 'sha256', wp_salt( 'auth' ) . wp_salt( 'secure_auth' ), true );
		$iv  = random_bytes( 16 );
		$enc = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
		if ( false === $enc ) {
			return '';
		}
		return base64_encode( $iv . $enc );
	}

	/**
	 * @param string $payload Stored ciphertext.
	 * @return string Plaintext or empty on failure.
	 */
	public static function decrypt( $payload ) {
		$payload = (string) $payload;
		if ( $payload === '' ) {
			return '';
		}
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$raw = base64_decode( $payload, true );
		if ( false === $raw || strlen( $raw ) < 17 ) {
			return '';
		}
		$iv  = substr( $raw, 0, 16 );
		$enc = substr( $raw, 16 );
		$key = hash( 'sha256', wp_salt( 'auth' ) . wp_salt( 'secure_auth' ), true );
		$out = openssl_decrypt( $enc, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
		return false === $out ? '' : (string) $out;
	}
}
