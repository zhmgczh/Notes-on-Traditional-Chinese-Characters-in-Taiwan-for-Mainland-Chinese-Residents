<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors\ConnectorFactory;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fetches paginated rows from an external database for bulk_import.
 */
class ExternalDbRowSource {

	/**
	 * @param string $hash_key   Import session.
	 * @param int    $line_number 1-based first row index for this batch.
	 * @param int    $limit       Rows per batch.
	 * @return array{headers:array<int,string>,rows:array<int,array<int,string>>,error?:string}
	 */
	public static function fetch_page( $hash_key, $line_number, $limit ) {
		$svc     = DbImportSessionService::getInstance();
		$session = $svc->get_session( $hash_key );
		if ( ! $session ) {
			return array(
				'headers' => array(),
				'rows'    => array(),
				'error'   => __( 'Database import session not found. Please prepare the table again from Import from Database.', 'wp-ultimate-csv-importer' ),
			);
		}

		$stored_headers = self::headers_from_session( $session );

		$repo = new ConnectionRepository();
		$conn = $repo->get( (int) $session['connection_id'] );
		if ( ! $conn ) {
			return array(
				'headers' => array(),
				'rows'    => array(),
				'error'   => __( 'Saved database connection not found.', 'wp-ultimate-csv-importer' ),
			);
		}

		$table     = (string) $session['source_table'];
		$order_col = ! empty( $session['order_column'] ) ? (string) $session['order_column'] : null;
		$offset    = max( 0, (int) $line_number - 1 );
		$limit     = max( 1, (int) $limit );

		$connector = ConnectorFactory::from_connection_row( $conn );
		try {
			$connector->connect();
			$batch = $connector->getBatchRecords( $table, $limit, $offset, $order_col );
			$connector->disconnect();

			if ( ! empty( $stored_headers ) ) {
				$source_headers   = $batch['headers'];
				$batch['headers']   = $stored_headers;
				$batch['rows']      = self::align_rows_to_headers( $batch['rows'], $stored_headers, $source_headers );
			}

			global $wpdb;
			$wpdb->update(
				DbImportSessionService::sessions_table(),
				array(
					'last_offset' => $offset + count( $batch['rows'] ),
					'updated_at'  => current_time( 'mysql', true ),
				),
				array( 'hash_key' => sanitize_key( $hash_key ) ),
				array( '%d', '%s' ),
				array( '%s' )
			);

			return $batch;
		} catch ( \Throwable $e ) {
			return array(
				'headers' => $stored_headers,
				'rows'    => array(),
				'error'   => $e->getMessage(),
			);
		}
	}

	/**
	 * @param array<string,mixed> $session
	 * @return array<int,string>
	 */
	private static function headers_from_session( array $session ) {
		if ( empty( $session['options'] ) ) {
			return array();
		}
		$opts = json_decode( (string) $session['options'], true );
		if ( ! is_array( $opts ) || empty( $opts['headers'] ) || ! is_array( $opts['headers'] ) ) {
			return array();
		}
		return array_values( array_map( 'trim', $opts['headers'] ) );
	}

	/**
	 * Re-order numeric row values to match the header list used during mapping.
	 *
	 * @param array<int,array<int,string>> $rows
	 * @param array<int,string>            $target_headers
	 * @param array<int,string>            $source_headers
	 * @return array<int,array<int,string>>
	 */
	private static function align_rows_to_headers( $rows, $target_headers, $source_headers ) {
		if ( empty( $rows ) || empty( $target_headers ) ) {
			return is_array( $rows ) ? $rows : array();
		}
		$source_headers = array_values( $source_headers );
		$index_map      = array();
		foreach ( $target_headers as $t_idx => $name ) {
			$search = array_search( $name, $source_headers, true );
			if ( false === $search ) {
				$lower = strtolower( trim( $name ) );
				foreach ( $source_headers as $s_idx => $label ) {
					if ( strtolower( trim( (string) $label ) ) === $lower ) {
						$search = $s_idx;
						break;
					}
				}
			}
			$index_map[ $t_idx ] = ( false !== $search ) ? $search : null;
		}

		$aligned = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$line = array();
			foreach ( $target_headers as $t_idx => $name ) {
				$src_idx        = $index_map[ $t_idx ];
				$line[ $t_idx ] = ( null !== $src_idx && isset( $row[ $src_idx ] ) ) ? (string) $row[ $src_idx ] : '';
			}
			$aligned[] = $line;
		}
		return $aligned;
	}
}
