<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Connectors\ConnectorFactory;
use Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro;
use Smackcoders\UCI\Proaddons\UltimatePro\ValidateFile;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DbImportSessionService {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function sessions_table() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_db_import_sessions';
	}

	public function is_db_session( $hash_key ) {
		$hash_key = sanitize_key( (string) $hash_key );
		if ( $hash_key === '' ) {
			return false;
		}
		if ( get_option( 'smack_import_source_' . $hash_key ) === 'external_db' ) {
			return true;
		}
		global $wpdb;
		$table = self::sessions_table();
		$id    = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$table} WHERE hash_key = %s LIMIT 1", $hash_key )
		);
		return ! empty( $id );
	}

	/**
	 * @return array<string,mixed>|null
	 */
	public function get_session( $hash_key ) {
		global $wpdb;
		$hash_key = sanitize_key( (string) $hash_key );
		$row      = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::sessions_table() . ' WHERE hash_key = %s LIMIT 1', $hash_key ),
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Row count for UI/import loops. Stub CSV is header-only, so file_events.total_rows is often 0.
	 *
	 * @param string       $hash_key
	 * @param string|int|null $file_events_total Value from smackcsv_file_events.
	 * @return int
	 */
	public function resolve_import_total_rows( $hash_key, $file_events_total = null ) {
		$from_file = (int) $file_events_total;
		if ( ! $this->is_db_session( $hash_key ) ) {
			return $from_file;
		}
		$session = $this->get_session( $hash_key );
		if ( $session && isset( $session['row_count'] ) && (int) $session['row_count'] > 0 ) {
			return (int) $session['row_count'];
		}
		return $from_file;
	}

	/**
	 * @param int    $connection_id Saved connection.
	 * @param string $table         Source table.
	 * @param string $hash_key_in   Optional existing hash.
	 * @return array<string,mixed>|\WP_Error
	 */
	public function prepare_import( $connection_id, $table, $hash_key_in = '' ) {
		global $wpdb;

		$repo = new ConnectionRepository();
		$conn = $repo->get( (int) $connection_id );
		if ( ! $conn ) {
			return new \WP_Error( 'db_conn', __( 'Connection not found.', 'wp-ultimate-csv-importer' ) );
		}

		$table = sanitize_text_field( (string) $table );
		if ( $table === '' || ! preg_match( '/^[a-zA-Z0-9_]+$/', $table ) ) {
			return new \WP_Error( 'db_table', __( 'Invalid table name.', 'wp-ultimate-csv-importer' ) );
		}

		$connector = ConnectorFactory::from_connection_row( $conn );
		try {
			$connector->connect();
			$total     = $connector->countRows( $table );
			$columns   = $connector->getColumns( $table );
			$order_col = '';
			foreach ( $columns as $col ) {
				if ( ! empty( $col['key'] ) && stripos( (string) $col['key'], 'pri' ) !== false ) {
					$order_col = $col['name'];
					break;
				}
			}
			if ( $order_col === '' && ! empty( $columns[0]['name'] ) ) {
				$order_col = $columns[0]['name'];
			}
			$preview = $connector->previewRows( $table, 1, 0, $order_col ?: null );
			$headers = $preview['headers'];
			$connector->disconnect();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'db_read', $e->getMessage() );
		}

		if ( empty( $headers ) ) {
			return new \WP_Error( 'db_empty', __( 'Table has no readable columns.', 'wp-ultimate-csv-importer' ) );
		}

		$core = UltimatePro::getInstance();
		$upload_base = $core->create_upload_dir();
		if ( ! $upload_base ) {
			return new \WP_Error( 'upload_dir', __( 'Upload directory unavailable.', 'wp-ultimate-csv-importer' ) );
		}

		$hash_key = $hash_key_in !== '' ? sanitize_key( $hash_key_in ) : $core->convert_string2hash_key( 'db-import-' . $table . '-' . $connection_id );
		$file_name = 'db-import-' . substr( $hash_key, 0, 12 ) . '.csv';
		$upload_dir_path = $upload_base . $hash_key;
		if ( ! is_dir( $upload_dir_path ) ) {
			wp_mkdir_p( $upload_dir_path );
		}
		$file_path = $upload_base . $hash_key . '/' . $hash_key;
		$fp        = fopen( $file_path, 'w' );
		if ( ! $fp ) {
			return new \WP_Error( 'file', __( 'Could not create import stub file.', 'wp-ultimate-csv-importer' ) );
		}
		fputcsv( $fp, $headers, ',', '"', '\\' );
		fclose( $fp );

		$file_table = $wpdb->prefix . 'smackcsv_file_events';
		$existing_id = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$file_table} WHERE hash_key = %s ORDER BY id DESC LIMIT 1", $hash_key )
		);
		if ( $existing_id > 0 ) {
			$wpdb->update(
				$file_table,
				array(
					'file_name'  => $file_name,
					'total_rows' => (string) $total,
					'status'     => 'Downloaded',
					'lock'       => false,
				),
				array( 'id' => $existing_id ),
				array( '%s', '%s', '%s', '%d' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$file_table,
				array(
					'file_name'  => $file_name,
					'hash_key'   => $hash_key,
					'total_rows' => (string) $total,
					'status'     => 'Downloaded',
					'lock'       => false,
				),
				array( '%s', '%s', '%s', '%s', '%d' )
			);
		}

		update_option( 'smack_import_source_' . $hash_key, 'external_db', false );

		$sessions = self::sessions_table();
		$wpdb->delete( $sessions, array( 'hash_key' => $hash_key ), array( '%s' ) );
		$wpdb->insert(
			$sessions,
			array(
				'hash_key'      => $hash_key,
				'connection_id' => (int) $connection_id,
				'source_table'  => $table,
				'order_column'  => $order_col,
				'last_offset'   => 0,
				'row_count'     => (int) $total,
				'options'       => wp_json_encode( array( 'headers' => $headers ) ),
				'created_at'    => current_time( 'mysql', true ),
				'updated_at'    => current_time( 'mysql', true ),
			),
			array( '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
		);
		update_option( 'smack_csv_delimiter_' . $hash_key, ',' );

		$validate = ValidateFile::getInstance();
		$meta     = $validate->import_record_function( $hash_key, $file_name );

		// set_post_types() counts stub CSV lines (header only) and overwrites total_rows to 0.
		$wpdb->update(
			$file_table,
			array( 'total_rows' => (string) $total ),
			array( 'hash_key' => $hash_key ),
			array( '%s' ),
			array( '%s' )
		);

		do_action( 'uci_db_migration_import_prepared', $hash_key, (int) $connection_id, $table );

		return array(
			'hashkey'      => $hash_key,
			'filename'     => $file_name,
			'file_type'    => 'csv',
			'total_rows'   => (int) $total,
			'columns'      => $headers,
			'selectedtype' => $meta['selected type'] ?? '',
			'posttype'     => $meta['Post Type'] ?? array(),
			'taxonomy'     => $meta['Taxonomy'] ?? array(),
			'posttype_labels' => $meta['Post Type Labels'] ?? array(),
			'taxonomy_labels' => $meta['Taxonomy Labels'] ?? array(),
			'source_table' => $table,
			'connection_id' => (int) $connection_id,
		);
	}
}
