<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ConnectionRepository {

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_db_connections';
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function list_connections() {
		global $wpdb;
		$table = self::table_name();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY connection_name ASC", ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		$out = array();
		foreach ( $rows as $row ) {
			$out[] = $this->public_row( $row );
		}
		return $out;
	}

	/**
	 * @return array<string,mixed>|null
	 */
	public function get( $id ) {
		global $wpdb;
		$table = self::table_name();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ),
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * @param array<string,mixed> $input Posted fields.
	 * @return array{success:bool,message:string,id?:int}
	 */
	public function save( array $input ) {
		global $wpdb;
		$name = isset( $input['connection_name'] ) ? sanitize_text_field( $input['connection_name'] ) : '';
		if ( $name === '' ) {
			return array( 'success' => false, 'message' => __( 'Connection name is required.', 'wp-ultimate-csv-importer' ) );
		}
		$db_type = isset( $input['db_type'] ) ? sanitize_key( $input['db_type'] ) : 'mysql';
		$host    = isset( $input['host'] ) ? sanitize_text_field( $input['host'] ) : '';
		$port    = isset( $input['port'] ) ? (int) $input['port'] : 3306;
		$dbname  = isset( $input['database_name'] ) ? sanitize_text_field( $input['database_name'] ) : '';
		$user    = isset( $input['username'] ) ? sanitize_text_field( $input['username'] ) : '';
		$ssl     = ! empty( $input['ssl_enabled'] ) ? 1 : 0;
		$id      = isset( $input['id'] ) ? (int) $input['id'] : 0;

		if ( $host === '' || $dbname === '' || $user === '' ) {
			return array( 'success' => false, 'message' => __( 'Host, database, and username are required.', 'wp-ultimate-csv-importer' ) );
		}

		$password_enc = '';
		if ( ! empty( $input['password'] ) ) {
			$password_enc = CredentialCipher::encrypt( (string) $input['password'] );
			if ( $password_enc === '' ) {
				return array( 'success' => false, 'message' => __( 'Could not encrypt password.', 'wp-ultimate-csv-importer' ) );
			}
		} elseif ( $id > 0 ) {
			$existing = $this->get( $id );
			$password_enc = isset( $existing['password_enc'] ) ? (string) $existing['password_enc'] : '';
		} else {
			return array( 'success' => false, 'message' => __( 'Password is required for new connections.', 'wp-ultimate-csv-importer' ) );
		}

		$now   = current_time( 'mysql', true );
		$table = self::table_name();
		$data  = array(
			'connection_name' => $name,
			'db_type'         => $db_type,
			'host'            => $host,
			'port'            => $port,
			'database_name'   => $dbname,
			'username'        => $user,
			'password_enc'    => $password_enc,
			'ssl_enabled'     => $ssl,
			'updated_at'      => $now,
		);

		if ( $id > 0 ) {
			$wpdb->update( $table, $data, array( 'id' => $id ), array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s' ), array( '%d' ) );
			do_action( 'uci_db_migration_connection_saved', $id, 'update' );
			return array( 'success' => true, 'message' => __( 'Connection updated.', 'wp-ultimate-csv-importer' ), 'id' => $id );
		}

		$data['created_by'] = get_current_user_id();
		$data['created_at'] = $now;
		$ins                = $wpdb->insert(
			$table,
			$data,
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
		);
		if ( false === $ins ) {
			return array( 'success' => false, 'message' => __( 'Could not save connection.', 'wp-ultimate-csv-importer' ) );
		}
		$new_id = (int) $wpdb->insert_id;
		do_action( 'uci_db_migration_connection_saved', $new_id, 'create' );
		return array( 'success' => true, 'message' => __( 'Connection saved.', 'wp-ultimate-csv-importer' ), 'id' => $new_id );
	}

	/**
	 * @return array{success:bool,message:string}
	 */
	public function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table_name(), array( 'id' => (int) $id ), array( '%d' ) );
		return array( 'success' => true, 'message' => __( 'Connection deleted.', 'wp-ultimate-csv-importer' ) );
	}

	/**
	 * @param array<string,mixed> $row DB row with password_enc.
	 * @return array<string,mixed>
	 */
	public static function connection_config_from_row( array $row ) {
		return array(
			'db_type'       => isset( $row['db_type'] ) ? $row['db_type'] : 'mysql',
			'host'          => isset( $row['host'] ) ? $row['host'] : '',
			'port'          => isset( $row['port'] ) ? (int) $row['port'] : 3306,
			'database_name' => isset( $row['database_name'] ) ? $row['database_name'] : '',
			'username'      => isset( $row['username'] ) ? $row['username'] : '',
			'password'      => CredentialCipher::decrypt( isset( $row['password_enc'] ) ? $row['password_enc'] : '' ),
			'ssl_enabled'   => ! empty( $row['ssl_enabled'] ),
		);
	}

	/**
	 * @param array<string,mixed> $row
	 * @return array<string,mixed>
	 */
	private function public_row( array $row ) {
		unset( $row['password_enc'] );
		$row['password_set'] = true;
		return $row;
	}
}
