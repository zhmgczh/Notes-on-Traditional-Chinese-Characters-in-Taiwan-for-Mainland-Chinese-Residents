<?php
/********************************************************************************************
 * Plugin Name: WP Ultimate CSV Importer Pro
 * Description: Seamlessly create / update posts, custom posts, pages, products, media, SEO and contents  of premium plugins from your CSV data with ease.  The import / update can be scheduled at regular intervals. The Importer can pull files from remote servers via ftp or http protocol.
 * Version: 9.0
 * Requires PHP: 7.4
 * Text Domain: wp-ultimate-csv-importer
 * Domain Path: /languages
 * Author: Smackcoders
 * Plugin URI: https://goo.gl/kKWPui
 * Author URI: https://goo.gl/kKWPui
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 ********************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
define('WCSVPLUGINSLUG', 'wp-ultimate-csv-importer-pro');
define('WCSVPLUGINDIR', plugin_dir_path(__FILE__));
define('SM_UCI_PRO', plugin_basename(__FILE__));
define('WCSVPRO_MIN_FREE_VERSION', '8.1');

/**
 * Ensure export directory exists and block direct web access.
 */
function sm_uci_pro_ensure_exports_htaccess() {
	$upload      = wp_upload_dir();
	$exports_dir = $upload['basedir'] . '/smack_uci_uploads/exports/';
	if ( ! is_dir( $exports_dir ) ) {
		wp_mkdir_p( $exports_dir );
	}
	$htaccess_file = $exports_dir . '.htaccess';
	$rules         = "Options -Indexes\n<FilesMatch \"\.(csv|xml|xls|xlsx|json|tsv|zip|txt)$\">\n<IfModule mod_authz_core.c>\nRequire all granted\n</IfModule>\n<IfModule !mod_authz_core.c>\nAllow from all\n</IfModule>\n</FilesMatch>\n";
	if ( file_exists( $htaccess_file ) ) {
		@chmod( $htaccess_file, 0666 );
	}
	@file_put_contents( $htaccess_file, $rules );
	if ( file_exists( $htaccess_file ) ) {
		@chmod( $htaccess_file, 0644 );
	}
}
sm_uci_pro_ensure_exports_htaccess();

require_once __DIR__ . '/includes/FeatureRegistry.php';
require_once __DIR__ . '/includes/FeatureLoader.php';
require_once __DIR__ . '/includes/ImportFileResolver.php';
require_once __DIR__ . '/includes/ImportValueResolver.php';
require_once __DIR__ . '/includes/ScheduleCredentialCipher.php';
require_once __DIR__ . '/includes/ExportBatchContext.php';
require_once __DIR__ . '/includes/GoogleSheetsSession.php';
require_once __DIR__ . '/includes/OAuthScheduleRefresh.php';
\Smackcoders\UCI\Proaddons\UltimatePro\FeatureRegistry::ensure_defaults();

require_once __DIR__ . '/includes/importer-dependency-bootstrap.php';

/**
 * Dependency manager for free-plugin onboarding.
 *
 * @var Importer_Dependency_Manager|null
 */
global $smack_ultimate_pro_dependency_manager;
$smack_ultimate_pro_dependency_manager = smack_importer_dependency_manager_init(
	array(
		'pro_basename' => SM_UCI_PRO,
		'pro_name'     => 'WP Ultimate CSV Importer Pro',
		'text_domain'  => 'wp-ultimate-csv-importer',
		'nonce_action' => 'smack_importer_dependency_ultimate_pro',
		'plugin_dir'   => WCSVPLUGINDIR,
		'plugin_url'   => plugin_dir_url( __FILE__ ),
		'admin_pages'  => array( 'com.smackcoders.csvimporternewpro.menu' ),
	)
);

// require_once 'Plugin.php'; // Removed as Plugin class is now unified in Free version
require_once __DIR__ . '/includes/VendorAutoload.php';
require_once __DIR__ . '/includes/ProAjaxAuthorization.php';
\Smackcoders\UCI\Proaddons\UltimatePro\ProAjaxAuthorization::bootstrap();
if ( is_readable( __DIR__ . '/includes/CustomFunctionService.php' ) ) {
	require_once __DIR__ . '/includes/CustomFunctionService.php';
}
if ( ! function_exists( __NAMESPACE__ . '\\uci_custom_function_log' ) && ! function_exists( 'uci_custom_function_log' ) ) {
	/**
	 * Optional no-op logger for customFunction.php compatibility.
	 *
	 * @param string               $step Step label.
	 * @param array<string, mixed> $data Context.
	 */
	function uci_custom_function_log( $step, $data = array() ) {
		unset( $step, $data );
	}
}
require_once __DIR__ . '/includes/ProAssetLoader.php';
require_once __DIR__ . '/admin/class-deactivation-feedback.php';
require_once 'ErrorHandling.php';
require_once 'SmackCSVInstall.php';
require_once 'Uninstall.php';
require_once 'Tables.php';
require_once 'languages/LangIT.php';
require_once 'languages/LangUiExtras.php';
require_once 'languages/LangEN.php';
require_once 'languages/LangGE.php';
require_once 'languages/LangFR.php';
require_once 'languages/LangES.php';
require_once 'languages/LangJA.php';
require_once 'includes/I18nBootstrap.php';
require_once 'includes/ScheduleStateService.php';
require_once 'includes/SpreadsheetValidator.php';
require_once 'includes/ErrorDocumentationRegistry.php';
require_once 'includes/ImportErrorExplanationService.php';

// Phase 4: optional services only when FeatureRegistry toggles are ON.
if ( FeatureRegistry::is_enabled( 'import_retry' ) ) {
	require_once 'includes/RetryQueueService.php';
	require_once 'controllers/RetryController.php';
}
if ( FeatureRegistry::is_enabled( 'import_resume' ) ) {
	require_once 'includes/ImportResumeService.php';
	require_once 'controllers/ImportResumeController.php';
}
if ( FeatureRegistry::is_enabled( 'spreadsheet_editor' ) ) {
	require_once 'includes/SpreadsheetEditorService.php';
	require_once 'controllers/SpreadsheetEditorController.php';
}
if ( FeatureRegistry::is_enabled( 'import_preview' ) ) {
	require_once 'includes/ImportValidationService.php';
	require_once 'includes/ImportPreviewService.php';
	require_once 'controllers/ImportPreviewController.php';
}
require_once 'languages/LangNL.php';
include_once 'languages/LangRU.php';
include_once 'languages/LangPT.php';
include_once 'languages/LangTR.php';
include_once 'languages/LangenGB.php';
include_once 'languages/LangenCA.php';
include_once 'languages/LangenZA.php';
require_once 'SmackCSVParser.php';
require_once 'SmackCSVVars.php';
require_once 'SmackXLSX.php';
require_once 'FailedImagesUpdate.php';
require_once 'Preview.php';
require_once 'ClientMode.php';

include_once ABSPATH . 'wp-admin/includes/plugin.php';
include __DIR__ . '/wp-csv-hooks.php';
include __DIR__ . '/wp-csv-custom-hooks.php';

// Load Hook Testing Files
$testing_folders = array(
    // '/hook-testing/16-05-2026/action/',
    // '/hook-testing/16-05-2026/filter/',
    // '/hook-testing/18-05-2026/action/',
    // '/hook-testing/18-05-2026/filter/',
    // '/hook-testing/19-05-2026/action/',
    // '/hook-testing/19-05-2026/filter/',
    // '/hook-testing/20-05-2026/Export/filter/',
    // '/hook-testing/21-05-2026/Export/Filter/',
    // '/hook-testing/22-05-2026/Export/Action/',
	// '/hook-testing/25-05-2026/import/filter/'
);
// include_once __DIR__ . '/test-hook.php';

foreach ($testing_folders as $folder) {
    foreach (glob(__DIR__ . $folder . '*.php') as $test_file) {
        include_once $test_file;
    }
}

\Smackcoders\UCI\Proaddons\UltimatePro\FeatureLoader::load_all();

		require_once 'SaveMapping.php';
		require_once 'MediaHandling.php';
		require_once 'ImportConfiguration.php';
		require_once 'Dashboard.php';
		require_once 'DragandDropExtension.php';
		require_once 'extensions/profilepress/ProfilePressProperHandler.php';
		require_once 'scheduleExtensions/ScheduleExtension.php';
		require_once 'scheduleExtensions/ScheduleImport.php';
		require_once 'scheduleExtensions/ScheduleExport.php';
		require_once 'controllers/DBOptimizer.php';
		require_once 'controllers/SendPassword.php';
		require_once 'controllers/ImportEmailSuppression.php';
		add_action( 'init', [ \Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression::class, 'maybe_add_filters' ], 1 );
		require_once 'controllers/SupportMail.php';
		// Always load so Settings AJAX can return a clear disabled message when toggle is OFF.
		require_once 'controllers/GSheet.php';
		include_once('controllers/HelperExtension.php');
		include_once('controllers/NeedHelperExtension.php');
		require_once 'controllers/Security.php';
		require_once 'controllers/FeatureSettingsController.php';
		require_once 'ScheduleHandler.php';
		require_once 'SmackcliHandler.php';
		include_once('SingleImportExport.php');
		$singlecsv_class = new \Smackcoders\UCI\Proaddons\UltimatePro\SingleImportExport();

		if ( ! class_exists( 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\MigrationController' ) ) {
			foreach ( glob( __DIR__ . '/migrationModules/WooToSureCart/*.php' ) as $migration_file ) {
				require_once $migration_file;
			}
			foreach ( glob( __DIR__ . '/migrationModules/WooToSureCart/Migrators/*.php' ) as $migrator_file ) {
				require_once $migrator_file;
			}
		}

class UltimatePro {

	private static $instance = null;
    private static $table_instance = null;
    private static $desktop_upload_instance = null;
    private static $server_upload_instance = null;
    private static $url_upload_instance = null;
    private static $ftp_upload_instance = null;
    private static $ftps_upload_instance = null;
    private static $sftp_upload_instance = null;
    private static $xml_instance = null;
    private static $mapping_instance = null;
    private static $extension_instance = null;
    private static $save_mapping_instance = null;
    private static $plugin_instance = null;
    private static $helper_instance = null;
    private static $need_helper_instance = null;
    private static $ai_natural_language_import_instance = null;
    private static $migration_controller_instance = null;

    private static $import_config_instance = null;
    private static $dashboard_instance = null;
    private static $drag_drop_instance = null;
    private static $file_manager_instance = null;
    private static $template_manager_instance = null;
    private static $log_manager_instance = null;
    private static $schedule_manager_instance = null;
    private static $schedule_instance = null;
    private static $media_instance = null;
    private static $export_instance = null;
    private static $export_handler = null;
    private static $db_optimizer = null;
    private static $send_password = null;
    private static $nextgen_instance = null;
    private static $security = null;
    private static $support_instance = null;
    private static $uninstall = null;
    private static $failed_images_instance = null;
    private static $install = null;
    private static $schedule_export = null;
    private static $schedule_import = null;
    private static $en_instance = null;
    private static $italy_instance = null;
    private static $german_instance = null;
    private static $france_instance = null;
    private static $spanish_instance = null;
    private static $japanese_instance = null;
    private static $dutch_instance = null;
    private static $russian_instance = null;
    private static $portuguese_instance = null;
    private static $turkish_instance = null;
    private static $en_CA_instance = null;
    private static $en_GB_instance = null;
    private static $en_ZA_instance = null;
    private static $image_schedule_instance = null;

	public function __construct() {
		// add_action('sm_uci_load_addon_features', [$this, 'load_ultimate_pro_modules']);
		add_action('sm_uci_register_addon_schedulers', [$this, 'register_ultimate_pro_schedulers']);
		add_action('admin_menu', [$this, 'register_ultimate_pro_admin_menus'], 99);
		add_action('add_meta_boxes', [$this, 'product_import_export_metabox']);
		if ( FeatureRegistry::is_enabled( 'ai_import' ) ) {
			add_filter('wp_ai_client_default_request_timeout', function ($timeout) {
				return 120;
			});
		}
		add_filter('sm_uci_menu_title', function($title) {
			return __( 'Ultimate CSV Importer PRO', 'wp-ultimate-csv-importer' );
		});
		add_filter('sm_uci_menu_icon', function($icon) {
			return plugins_url("assets/images/wp-ultimate-csv-importer.png", __FILE__);
		});
		add_action('admin_enqueue_scripts', 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\enqueue_ultimate_pro_assets');
		add_action('admin_init', [$this, 'redirect_free_to_pro_menu']);
	}



	public static function getInstance() {
		if ( self::$instance === null ) {
			// Set instance FIRST so sub-classes that call UltimatePro::getInstance() don't recurse
			self::$instance = new UltimatePro();

			self::$table_instance                      = Tables::getInstance();
			self::$schedule_instance                   = ScheduleExtension::getInstance();
			self::$schedule_export                     = ScheduleExport::getInstance();
			self::$schedule_import                     = ScheduleImport::getInstance();
			self::$desktop_upload_instance             = DesktopUpload::getInstance();
			self::$server_upload_instance              = ServerUpload::getInstance();
			self::$url_upload_instance                 = UrlUpload::getInstance();
			self::$ftp_upload_instance                 = FtpUpload::getInstance();
			self::$ftps_upload_instance                = FtpsUpload::getInstance();
			self::$sftp_upload_instance                = SftpUpload::getInstance();
			self::$xml_instance                        = XmlHandler::getInstance();
			self::$mapping_instance                    = MappingExtension::getInstance();
			self::$extension_instance                  = new ExtensionHandler;
			self::$save_mapping_instance               = SaveMapping::getInstance();
			self::$media_instance                      = MediaHandling::getInstance();
			self::$import_config_instance              = ImportConfiguration::getInstance();
			self::$dashboard_instance                  = Dashboard::getInstance();
			self::$drag_drop_instance                  = DragandDropExtension::getInstance();
			self::$file_manager_instance               = FileManager::getInstance();
			self::$template_manager_instance           = TemplateManager::getInstance();
			self::$log_manager_instance                = LogManager::getInstance();
			self::$schedule_manager_instance           = ScheduleManager::getInstance();
			self::$export_instance                     = ExportExtension::getInstance();
			self::$export_handler                      = ExportHandler::getInstance();
			ExportAll::getInstance();
			self::$db_optimizer                        = DBOptimizer::getInstance();
			self::$send_password                       = SendPassword::getInstance();
			self::$nextgen_instance                    = NextGenGalleryImport::getInstance();
			self::$security                            = Security::getInstance();
			self::$support_instance                    = SupportMail::getInstance();
			self::$helper_instance                     = HelperExtension::getInstance();
			self::$need_helper_instance                = NeedHelperExtension::getInstance();
			self::$uninstall                           = SmackUCIUnInstall::getInstance();
			self::$install                             = SmackCSVInstall::getInstance();
			self::$italy_instance                      = LangIT::getInstance();
			self::$france_instance                     = LangFR::getInstance();
			self::$german_instance                     = LangGE::getInstance();
			self::$en_instance                         = LangEN::getInstance();
			self::$spanish_instance                    = LangES::getInstance();
			self::$japanese_instance                   = LangJA::getInstance();
			self::$dutch_instance                      = LangNL::getInstance();
			self::$en_CA_instance                      = LangEN_CA::getInstance();
			self::$en_GB_instance                      = LangEN_GB::getInstance();
			self::$en_ZA_instance                      = LangEN_ZA::getInstance();
			self::$russian_instance                    = LangRU::getInstance();
			self::$portuguese_instance                 = LangPT::getInstance();
			self::$turkish_instance                    = LangTR::getInstance();
			self::$failed_images_instance              = FailedImagesUpdate::getInstance();
			if ( FeatureRegistry::is_enabled( 'import_retry' ) && class_exists( __NAMESPACE__ . '\\RetryController' ) ) {
				RetryController::getInstance();
			}
			if ( FeatureRegistry::is_enabled( 'import_resume' ) && class_exists( __NAMESPACE__ . '\\ImportResumeController' ) ) {
				ImportResumeController::getInstance();
			}
			if ( FeatureRegistry::is_enabled( 'spreadsheet_editor' ) && class_exists( __NAMESPACE__ . '\\SpreadsheetEditorController' ) ) {
				SpreadsheetEditorController::getInstance();
			}
			if ( FeatureRegistry::is_enabled( 'import_preview' ) && class_exists( __NAMESPACE__ . '\\ImportPreviewController' ) ) {
				ImportPreviewController::getInstance();
			}
			FeatureSettingsController::getInstance();
			if ( FeatureRegistry::is_enabled( 'ai_import' ) ) {
				self::$ai_natural_language_import_instance = AI_Natural_Language_Imports::getInstance();
			}
			if ( class_exists( __NAMESPACE__ . '\\MigrationController' ) ) {
				self::$migration_controller_instance = MigrationController::getInstance();
			}
			add_action('after_plugin_row_' . plugin_basename(__FILE__), array(self::$install, 'after_plugin_row_meta'), 10, 3);
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( self::$install, 'plugin_row_meta' ), 10, 2 );

		}
		return self::$instance;
	}

	public static function is_woo_to_sure_available() {
		if (!function_exists('is_plugin_active')) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return ( class_exists('WooCommerce') || is_plugin_active('woocommerce/woocommerce.php') || class_exists('\SureCart\Models\Product') || class_exists('SureCart') || is_plugin_active('surecart/surecart.php') );
	}

	/**
	 * Admin notice when the free companion plugin is below the minimum supported version.
	 */
	public static function maybe_warn_free_plugin_version() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$free_basename = 'wp-ultimate-csv-importer/wp-ultimate-csv-importer.php';
		$free_path     = WP_PLUGIN_DIR . '/wp-ultimate-csv-importer/wp-ultimate-csv-importer.php';
		if ( ! file_exists( $free_path ) ) {
			return;
		}
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$free_data = get_plugin_data( $free_path, false, false );
		$free_ver  = isset( $free_data['Version'] ) ? $free_data['Version'] : '0';
		if ( version_compare( $free_ver, WCSVPRO_MIN_FREE_VERSION, '>=' ) ) {
			return;
		}
		add_action(
			'admin_notices',
			static function () use ( $free_ver ) {
				if ( ! current_user_can( 'manage_options' ) ) {
					return;
				}
				$update_url = self_admin_url( 'plugins.php' );
				echo '<div class="notice notice-warning"><p>';
				echo esc_html(
					sprintf(
						/* translators: 1: installed free version, 2: minimum required version */
						__( 'WP Ultimate CSV Importer Pro requires WP Ultimate CSV Importer free plugin version %2$s or newer (installed: %1$s). Please update the free plugin for full compatibility.', 'wp-ultimate-csv-importer' ),
						$free_ver,
						WCSVPRO_MIN_FREE_VERSION
					)
				);
				echo ' <a href="' . esc_url( $update_url ) . '">' . esc_html__( 'Go to Plugins', 'wp-ultimate-csv-importer' ) . '</a>';
				echo '</p></div>';
			}
		);
	}

	public function register_ultimate_pro_schedulers() {
		// Ultimate Pro specific scheduler registration
		if (!wp_next_scheduled('smack_uci_cron_scheduler')) {
			wp_schedule_event(time(), 'wp_ultimate_csv_importer_scheduled_csv_data', 'smack_uci_cron_scheduler');
		}
		if (!wp_next_scheduled('smack_uci_cron_scheduled_export')) {
			wp_schedule_event(time(), 'wp_ultimate_csv_importer_scheduled_export_data', 'smack_uci_cron_scheduled_export');
		}
		if (!wp_next_scheduled('smack_uci_schedule_heartbeat')) {
			wp_schedule_event(time(), 'smack_every_five_minutes', 'smack_uci_schedule_heartbeat');
		}
		
		add_action('smack_uci_cron_scheduler', ['Smackcoders\\UCI\\Proaddons\\UltimatePro\\UltimatePro', 'schedule_event_function']);
		add_action('smack_uci_cron_scheduled_export', ['Smackcoders\\UCI\\Proaddons\\UltimatePro\\ScheduleExport', 'smack_uci_cron_scheduled_export']);
		add_action('smack_uci_schedule_heartbeat', ['Smackcoders\\UCI\\Proaddons\\UltimatePro\\ScheduleStateService', 'run_heartbeat_cron']);
	}

	public static function schedule_event_function()
	{
		$schedule_obj = new ScheduleExtension();
		$schedule_obj->smack_uci_cron_scheduler();
	}

	public function register_ultimate_pro_admin_menus() {
		$plugin_pages = ['com.smackcoders.csvimporternewpro.menu'];
		remove_menu_page('com.smackcoders.csvimporternew.menu');
		add_menu_page(
			__( 'WP Ultimate CSV Importer PRO', 'wp-ultimate-csv-importer' ),
			__( 'WP Ultimate CSV Importer PRO', 'wp-ultimate-csv-importer' ),
			'manage_options',
			'com.smackcoders.csvimporternewpro.menu',
			['Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro', 'render_pro_main_page'],
			plugins_url('assets/images/wp-ultimate-csv-importer.png', __FILE__)
		);
		add_action('admin_head', ['Smackcoders\\UCI\\Proaddons\\UltimatePro\\UltimatePro', 'disable_admin_notices_on_custom_plugin_page']);
		add_filter('admin_body_class', ['Smackcoders\\UCI\\Proaddons\\UltimatePro\\UltimatePro', 'smack_uci_admin_body_class']);
	}

	public static function smack_uci_admin_body_class($classes) {
		$page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
		if ($page === 'com.smackcoders.csvimporternewpro.menu') {
			$classes .= ' smack-uci-pro-page ';
		}
		return $classes;
	}

	public static function disable_admin_notices_on_custom_plugin_page()
	{
		$page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
		if ($page === 'com.smackcoders.csvimporternewpro.menu') {
			echo '<style>.notice:not(.smack-uci-pro-notice), .update-nag, .updated:not(.smack-uci-pro-notice), .error:not(.smack-uci-pro-notice) { display:none !important; }</style>';
		}
	}

	public function redirect_free_to_pro_menu() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
		if ($page === 'com.smackcoders.csvimporternew.menu') {
			wp_safe_redirect(admin_url('admin.php?page=com.smackcoders.csvimporternewpro.menu'));
			exit;
		}
		if ($page === 'woo_to_sure' && !UltimatePro::is_woo_to_sure_available()) {
			wp_die(
				esc_html__('WooCommerce and SureCart must be active.', 'wp-ultimate-csv-importer'),
				esc_html__('Access Denied', 'wp-ultimate-csv-importer')
			);
		}
	}


	public static function render_pro_main_page( $check = false ) {
		global $smack_ultimate_pro_dependency_manager;

		if ( $smack_ultimate_pro_dependency_manager && ! $smack_ultimate_pro_dependency_manager->is_dependency_resolved() ) {
			if ( $check ) {
				return false;
			}

			$smack_ultimate_pro_dependency_manager->render_onboarding_screen();
			return false;
		}

		if ( $check ) {
			return true;
		}

		echo '<div id="wp-csv-importer-admin-pro"></div>';
		return true;
	}

	public function create_upload_dir($mode = null)
    {
        $upload = wp_upload_dir();
        $upload_dir = $upload['basedir'];
        if (!is_dir($upload_dir)) {
            return false;
        } else {
            $upload_dir = $upload_dir . '/smack_uci_uploads/imports/';
            if (!is_dir($upload_dir)) {
                wp_mkdir_p($upload_dir);
                chmod($upload_dir, 0755);

                $index_php_file = $upload_dir . 'index.php';
                if (!file_exists($index_php_file)) {
                    $file_content = '<?php' . PHP_EOL . '?>';
                    file_put_contents($index_php_file, $file_content);
                }
            }
            if ($mode != 'CLI') {
                chmod($upload_dir, 0777);
            }
            return $upload_dir;
        }

    }

	public function convert_string2hash_key($value)
    {
        $file_name = hash_hmac('md5', "$value" . time(), 'secret');
        return $file_name;

    }
	public static function product_import_export_metabox()
    {
        $post_type = get_post_type(get_the_ID());
        $all_post_types = get_post_types(array('public' => true), 'names');
        // Add the meta box if the post type is a standard one or a custom post type
        if (in_array($post_type, $all_post_types)) {
            add_meta_box(
                'smackcsv_product_id',           // Unique ID
                'Import/Export',                 // Box title
                array(__CLASS__, 'importandexport'),  // Callback function
                $post_type,                      // Post type
                'side',                          // Context ('normal', 'side', or 'advanced')
                'high'                           // Priority ('high' or 'low')
            );
        }

    }
	public static function importandexport($post)
    {
        ?>
        <div class="product-tab-containers">
            <div class="product-tab-menu">
                <button class="product-tab active" data-tab="tab1">Import</button>
                <button class="product-tab" data-tab="tab2">Export</button>
            </div>
            <div class="tab-content">
                <div id="tab1" class="tab-panel active">
                    <p>Import options go here. You can import your CSV file using the options provided.</p>
                    <input type="file" id="product-import-file" name="product-import-file" accept=".csv">
                    <div class="loading-bar">
                        <div id="loading-progress"></div>
                    </div>
                    <small id="product-import-status"></small>
                    <button id="upload-product-import-btn">Upload Import</button>
                    <button id="clear-btn">clear</button>
                    <small id="smack-imp-message"></small>
                    <p id="smack-message"></p>
                </div>
                <div id="tab2" class="tab-panel">
                    <p>Export options go here. You can export your CSV file using the options provided.</p>
                    <button id="product-export-btn"
                        style="margin: 20px auto 0; display: block; background-color: #007cba; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;margin-bottom:16px">Export
                        CSV</button>
                    <small id="smack-product-exp-message" style=" display: none; color:#FF0000; text-align: right;  "></small>
                </div>
            </div>
        </div>
        <style>

        </style>
        <script>

        </script>
        <script>
            // document.getElementById('my-custom-button').addEventListener('click', function(event) {
            //     event.preventDefault();
            //     alert('Button clicked!');
            // });
        </script>
        <?php

    }
}

function enqueue_ultimate_pro_assets($hook){
	$plugin_slug = get_pro_asset_handle_prefix();

	$is_plugin_page = ( strpos( $hook, 'csvimporternewpro' ) !== false );
	
	// Dynamically check if we are on a post edit screen that supports the metabox
	$is_post_page = false;
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) {
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if ( $screen && !empty($screen->post_type) ) {
			$all_post_types = get_post_types( array( 'public' => true ), 'names' );
			if ( in_array( $screen->post_type, $all_post_types ) ) {
				$is_post_page = true;
			}
		} else {
			// Fallback if screen is not available
			$is_post_page = true;
		}
	}

	if ( $is_plugin_page ) {
		// ── Global Assets (Loaded only on plugin pages) ──────────────────
		wp_enqueue_script(
			'ultimate-pro-react-app',
			get_pro_asset_url( 'assets/js/react-app.js' ),
			array( 'wp-element', 'wp-components', 'wp-i18n' ),
			'1.0',
			true
		);

		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugin_data = get_plugin_data( __FILE__ );
		
		$secure_uniquekey_csv = array(
			'url'       => admin_url( 'admin-ajax.php' ),
			'imagePath' => get_pro_asset_url( 'assets/images/' ),
			'plugin_version' => $plugin_data['Version'],
		);
		if ( current_user_can( 'manage_options' ) ) {
			$secure_uniquekey_csv['nonce'] = wp_create_nonce( 'smack-ultimate-csv-importer' );
		}
		wp_localize_script( 'ultimate-pro-react-app', 'smack_nonce_object', $secure_uniquekey_csv );

		$secure_uniquekey_csvs = array(
			'url'        => admin_url( 'admin-ajax.php' ),
			'admin_mode' => 1,
		);
		if ( current_user_can( 'manage_options' ) ) {
			$secure_uniquekey_csvs['nonce'] = wp_create_nonce( 'smack-ultimate-csv-importer' );
		}
		wp_localize_script( 'ultimate-pro-react-app', 'smack_nonce_object_client', $secure_uniquekey_csvs );
	}

	if ( $is_post_page ) {
		wp_enqueue_script(
			'ultimate-pro-react-product',
			get_pro_asset_url( 'assets/js/react-product-app.js' ),
			array( 'jquery' ),
			'1.0',
			true
		);

		$product_nonce_payload = array(
			'url' => admin_url( 'admin-ajax.php' ),
		);
		if ( current_user_can( 'manage_options' ) ) {
			$product_nonce_payload['nonce'] = wp_create_nonce( 'smack-ultimate-csv-importer-pro' );
		}
		wp_localize_script( 'ultimate-pro-react-product', 'smack_nonce_object_pro', $product_nonce_payload );

		wp_enqueue_style(
			$plugin_slug . 'csv-product-css',
			get_pro_asset_url( 'assets/css/deps/csv-product.css' )
		);
	}

	// Only load the rest on the Pro plugin's admin page
	if ( ! $is_plugin_page ) {
		return;
	}
	if ( ! UltimatePro::render_pro_main_page( true ) ) {
		return;
	}

	// ── JS dependencies ────────────────────────────────────────────────────────
	wp_register_script( $plugin_slug . 'jquery-ui-js', get_pro_asset_url( 'assets/js/deps/jquery-ui.min.js' ), array( 'jquery' ) );
	wp_enqueue_script( $plugin_slug . 'jquery-ui-js' );

	wp_register_script( $plugin_slug . 'popper', get_pro_asset_url( 'assets/js/deps/popper.js' ), array( 'jquery' ) );
	wp_enqueue_script( $plugin_slug . 'popper' );

	wp_register_script( $plugin_slug . 'bootstrap', get_pro_asset_url( 'assets/js/deps/bootstrap.min.js' ), array( 'jquery' ) );
	wp_enqueue_script( $plugin_slug . 'bootstrap' );

	wp_register_script( $plugin_slug . 'main-js', get_pro_asset_url( 'assets/js/deps/main.js' ), array( 'jquery' ) );
	wp_enqueue_script( $plugin_slug . 'main-js' );

	wp_register_script( $plugin_slug . 'file-tree', get_pro_asset_url( 'assets/js/deps/jQueryFileTree.min.js' ), array( 'jquery' ) );
	wp_enqueue_script( $plugin_slug . 'file-tree' );

	// ── Main admin script ──────────────────────────────────────────────────────
	wp_register_script(
		$plugin_slug . 'script_csv_importer',
		get_pro_asset_url( 'assets/js/admin-v7.3.js' ),
		array( 'react', 'wp-element', 'wp-components', 'wp-i18n', 'jquery' ),
		filemtime( WCSVPLUGINDIR . 'assets/js/admin-v7.3.js' ),
		true
	);
	wp_enqueue_script( $plugin_slug . 'script_csv_importer' );

	// ── CSS dependencies ───────────────────────────────────────────────────────
	wp_enqueue_style( $plugin_slug . 'bootstrap-css', get_pro_asset_url( 'assets/css/deps/bootstrap.min.css' ) );
	wp_enqueue_style( $plugin_slug . 'admin-menu-fix', get_pro_asset_url( 'assets/css/admin-menu-fix.css' ) );
	wp_enqueue_style( $plugin_slug . 'filepond-css', get_pro_asset_url( 'assets/css/deps/filepond.min.css' ) );
	wp_enqueue_style( $plugin_slug . 'csv-importer-css', get_pro_asset_url( 'assets/css/deps/csv-importer.css' ) );
	wp_enqueue_style( $plugin_slug . 'style-css', get_pro_asset_url( 'assets/css/deps/style.css' ) );
	wp_enqueue_style( $plugin_slug . 'react-datepicker-css', get_pro_asset_url( 'assets/css/deps/react-datepicker.css' ) );
	wp_enqueue_style( $plugin_slug . 'react-toastify-css', get_pro_asset_url( 'assets/css/deps/ReactToastify.css' ) );
	wp_enqueue_style( $plugin_slug . 'react-confirm-alert-css', get_pro_asset_url( 'assets/css/deps/react-confirm-alert.css' ) );
	wp_enqueue_style( 'font-awesome-all', get_pro_asset_url( 'assets/css/deps/font-awesome-all.css' ) );
	wp_enqueue_style( $plugin_slug . 'dashboard-css', get_pro_asset_url( 'assets/css/dashboard.css' ) );

	// Load modal isolation CSS in the footer so it wins over NextGEN jquery-modal.css.
	add_action(
		'admin_footer',
		static function () use ( $plugin_slug ) {
			static $enqueued = false;
			if ( $enqueued ) {
				return;
			}
			$enqueued = true;

			$deps = array( $plugin_slug . 'dashboard-css' );
			if ( wp_style_is( 'jquery-modal', 'enqueued' ) ) {
				$deps[] = 'jquery-modal';
			}

			wp_enqueue_style(
				$plugin_slug . 'modal-isolation-css',
				get_pro_asset_url( 'assets/css/modal-isolation.css' ),
				$deps,
				filemtime( WCSVPLUGINDIR . 'assets/css/modal-isolation.css' )
			);
		},
		9999
	);

	// ── Language detection – resolve translated strings for the React UI ────────
	$upload     = wp_upload_dir();
	$upload_url = $upload['baseurl'] . '/smack_uci_uploads/imports';
	$contents   = \Smackcoders\UCI\Proaddons\UltimatePro\I18nBootstrap::get_ui_language_contents();

	// ── Localize scripts ───────────────────────────────────────────────────────
	wp_localize_script( $plugin_slug . 'script_csv_importer', 'wpr_object', array(
		'file'                => wp_json_encode( $contents ),
		'imagePath'           => get_pro_asset_url( 'assets/images/' ),
		'logfielpath'         => $upload_url,
		'onedriveRedirectUri' => \Smackcoders\UCI\Proaddons\UltimatePro\OneDriveOAuthHandler::get_redirect_uri(),
	) );

	$import_preview_enabled = FeatureRegistry::is_enabled( 'import_preview' )
		&& class_exists( __NAMESPACE__ . '\\ImportPreviewService' )
		&& ImportPreviewService::getInstance()->is_enabled();

	$pro_nonce_payload = array(
		'url'                    => admin_url( 'admin-ajax.php' ),
		'import_preview_enabled' => $import_preview_enabled,
		'woo_to_sure_available'  => \Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro::is_woo_to_sure_available(),
		'plugin_version'         => $plugin_data['Version'],
		'enabled_features'         => FeatureRegistry::get_enabled_ids(),
		'currentUser'            => array(
			'name' => wp_get_current_user()->display_name,
		),
	);
	if ( current_user_can( 'manage_options' ) ) {
		$pro_nonce_payload['nonce'] = wp_create_nonce( 'smack-ultimate-csv-importer-pro' );
	}
	wp_localize_script( $plugin_slug . 'script_csv_importer', 'smack_nonce_object_pro', $pro_nonce_payload );

	$client_nonce_payload = array( 'admin_mode' => '1' );
	if ( current_user_can( 'manage_options' ) ) {
		$client_nonce_payload['nonce'] = wp_create_nonce( 'smack-ultimate-csv-importer-pro' );
	}
	wp_localize_script( $plugin_slug . 'script_csv_importer', 'smack_nonce_object_client', $client_nonce_payload );

}

// Instantiate the plugin class


$activate_plugin = SmackCSVInstall::getInstance();
$deactive_plugin = SmackUCIUnInstall::getInstance();

register_activation_hook( __FILE__, function () use ( $activate_plugin ) {
	
	$activate_plugin->install();
});

register_deactivation_hook(__FILE__, array('Smackcoders\\UCI\\Proaddons\\UltimatePro\\SmackUCIUnInstall', 'unInstall'));
register_uninstall_hook(__FILE__, array('Smackcoders\\UCI\\Proaddons\\UltimatePro\\SmackUCIUnInstall', 'unInstall'));

add_action('plugins_loaded', 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\onpluginsload');

function onpluginsload()
{
	add_action( 'init', array( \Smackcoders\UCI\Proaddons\UltimatePro\I18nBootstrap::class, 'load_textdomains' ), 0 );

	global $smack_ultimate_pro_dependency_manager;
	UltimatePro::getInstance();

	// Always register Smart Schedule poller hooks. Skipping this when the free
	// plugin dependency is unresolved left smack_uci_cron_scheduler events in
	// the cron array with no callback — schedules stayed Pending forever.
	do_action('sm_uci_register_addon_schedulers');

	// Remove legacy orphan email cron (no handler registered in Pro).
	if ( wp_next_scheduled( 'smack_uci_email_scheduler' ) ) {
		wp_clear_scheduled_hook( 'smack_uci_email_scheduler' );
	}

	UltimatePro::maybe_warn_free_plugin_version();

	if ( $smack_ultimate_pro_dependency_manager && ! $smack_ultimate_pro_dependency_manager->is_dependency_resolved() ) {
		return;
	}

    DeactivationFeedback::getInstance();
	// if(!class_exists('\Smackcoders\UCI\Core\UCICore') && $_GET['page'] !== 'com.smackcoders.csvimporternewpro.menu')
	// {
	// 	$free_plugin = 'wp-ultimate-csv-importer/wp-ultimate-csv-importer.php';
	// 			if ( is_plugin_active( $free_plugin ) ) {
	// 				return;
	// 			}
	// 			$install_url = wp_nonce_url(self_admin_url( 'update.php?action=install-plugin&plugin=wp-ultimate-csv-importer' ),'install-plugin_wp-ultimate-csv-importer');
	// 			$activate_url = wp_nonce_url(self_admin_url( 'plugins.php?action=activate&plugin=' . $free_plugin ),'activate-plugin_' . $free_plugin);
	// 			$is_installed = file_exists(WP_PLUGIN_DIR . '/wp-ultimate-csv-importer/wp-ultimate-csv-importer.php');
	// 			$action_link = $is_installed
	// 				? '<a href="' . esc_url( $activate_url ) . '">'
	// 					. esc_html__( 'Activate WP Ultimate CSV Importer Free Plugin', 'wp-ultimate-csv-importer' )
	// 				. '</a>'
	// 				: '<a href="' . esc_url( $install_url ) . '">'
	// 					. esc_html__( 'Install WP Ultimate CSV Importer Free Plugin', 'wp-ultimate-csv-importer' )
	// 				. '</a>';

	// 			wp_admin_notice(
	// 				sprintf(
	// 					'Core functionality of WP Ultimate CSV Importer Pro depends on the WP Ultimate CSV Importer Free plugin. %s',
	// 					$action_link
	// 				),
	// 				array(
	// 					'type'               => 'warning',
	// 					'dismissible'        => true,
	// 					'additional_classes' => array( 'ultimate-importer-notice' ),
	// 					'paragraph_wrap'     => true,
	// 				)
	// 			);
	// }
}
