<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates/updates ProfilePress customers + subscriptions.
 *
 * Uses ProfilePress core APIs for customers/subscriptions. Customer "since" (`ppress_customers.date_created`)
 * requires a single column UPDATE: ProfilePress does not persist that field via CustomerEntity::save() on update,
 * and "add" reads a formatted getter so MySQL never receives a valid datetime string.
 *
 * Triggered via `smack_csv_importer_user_saved` after ProfilePress meta is saved by ProfilePressImport.
 */
class ProfilePressProperHandler {
	/**
	 * Internal logger.
	 * Kept lightweight but enabled to support bulk troubleshooting.
	 *
	 * @param string $message
	 * @return void
	 */
	private static function log( $message ) {
	}

	/**
	 * Parse European date formats (DD-MM-YYYY) into MySQL datetime.
	 *
	 * Accepts:
	 * - DD-MM-YYYY
	 * - DD/MM/YYYY
	 * - DD-MM-YYYY HH:MM(:SS)
	 * - DD/MM/YYYY HH:MM(:SS)
	 * - YYYY-MM-DD (optional time)
	 *
	 * @param string $raw
	 * @return string Empty string when invalid/empty.
	 */
	private static function parse_eu_date_to_mysql_datetime( $raw ) {
		$raw = trim( (string) $raw );
		if ( $raw === '' ) {
			return '';
		}

		// Normalize separators (keep time part)
		$raw_norm = str_replace( '/', '-', $raw );

		// ISO-ish: YYYY-MM-DD[ HH:MM[:SS]]
		if ( preg_match( '/^(?<y>\d{4})-(?<m>\d{2})-(?<d>\d{2})(?:\s+(?<t>\d{1,2}:\d{2}(?::\d{2})?))?$/', $raw_norm, $m ) ) {
			$y = (int) $m['y'];
			$mo = (int) $m['m'];
			$d = (int) $m['d'];
			$t = isset( $m['t'] ) ? (string) $m['t'] : '';

			$hh = 0; $mm = 0; $ss = 0;
			if ( $t !== '' ) {
				if ( preg_match( '/^(?<hh>\d{1,2}):(?<mm>\d{2})(?::(?<ss>\d{2}))?$/', $t, $tm ) ) {
					$hh = (int) $tm['hh'];
					$mm = (int) $tm['mm'];
					$ss = isset( $tm['ss'] ) ? (int) $tm['ss'] : 0;
				}
			}

			return sprintf( '%04d-%02d-%02d %02d:%02d:%02d', $y, $mo, $d, $hh, $mm, $ss );
		}

		// European: DD-MM-YYYY[ HH:MM[:SS]]
		if ( preg_match( '/^(?<d>\d{1,2})-(?<m>\d{1,2})-(?<y>\d{4})(?:\s+(?<t>\d{1,2}:\d{2}(?::\d{2})?))?$/', $raw_norm, $m ) ) {
			$d = (int) $m['d'];
			$mo = (int) $m['m'];
			$y = (int) $m['y'];
			$t = isset( $m['t'] ) ? (string) $m['t'] : '';

			$hh = 0; $mm = 0; $ss = 0;
			if ( $t !== '' ) {
				if ( preg_match( '/^(?<hh>\d{1,2}):(?<mm>\d{2})(?::(?<ss>\d{2}))?$/', $t, $tm ) ) {
					$hh = (int) $tm['hh'];
					$mm = (int) $tm['mm'];
					$ss = isset( $tm['ss'] ) ? (int) $tm['ss'] : 0;
				}
			}

			return sprintf( '%04d-%02d-%02d %02d:%02d:%02d', $y, $mo, $d, $hh, $mm, $ss );
		}

		// Last resort: try strtotime (best-effort)
		$ts = strtotime( $raw );
		if ( $ts === false ) {
			return '';
		}
		return date_i18n( 'Y-m-d H:i:s', $ts );
	}

	/**
	 * Write `ppress_customers.date_created` to match CSV member start (Column S).
	 * Only updates `date_created`; verifies the row belongs to `$expected_user_id`.
	 *
	 * @param int    $customer_id       ProfilePress customer id.
	 * @param string $mysql_datetime     `Y-m-d H:i:s`
	 * @param int    $expected_user_id   WordPress user id.
	 * @return bool True if a row was updated.
	 */
	private static function sync_customer_date_created_column( $customer_id, $mysql_datetime, $expected_user_id ) {
		global $wpdb;

		$customer_id       = intval( $customer_id );
		$expected_user_id  = intval( $expected_user_id );
		$mysql_datetime    = trim( (string) $mysql_datetime );

		if ( $customer_id <= 0 || $expected_user_id <= 0 || $mysql_datetime === '' ) {
			return false;
		}
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $mysql_datetime ) ) {
			self::log( "PPRESS ERROR: sync_customer_date_created_column invalid datetime '{$mysql_datetime}'" );
			return false;
		}

		$table = $wpdb->prefix . 'ppress_customers';
		$uid   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT user_id FROM {$table} WHERE id = %d LIMIT 1",
				$customer_id
			)
		);
		$uid = (int) $uid;
		if ( $uid !== $expected_user_id ) {
			self::log(
				"PPRESS ERROR: sync_customer_date_created_column customer_id={$customer_id} user_id mismatch (row={$uid}, expected={$expected_user_id})"
			);
			return false;
		}

		$updated = $wpdb->update(
			$table,
			[ 'date_created' => $mysql_datetime ],
			[
				'id'      => $customer_id,
				'user_id' => $expected_user_id,
			],
			[ '%s' ],
			[ '%d', '%d' ]
		);

		if ( $updated === false ) {
			self::log( 'PPRESS ERROR: sync_customer_date_created_column DB update failed: ' . (string) $wpdb->last_error );
			return false;
		}

		return $updated > 0;
	}

	/**
	 * Legacy helper: translate CSV plan codes/names into ProfilePress plan names.
	 * Kept for backward compatibility with the legacy code path.
	 *
	 * @param string $raw_plan_name
	 * @return string
	 */
	private static function translate_plan_name( $raw_plan_name ) {
		$raw_plan_name = trim( (string) $raw_plan_name );
		if ( $raw_plan_name === '' ) {
			return '';
		}

		// Default mappings (customize via filter).
		$default_map = [
			// Common shorthand codes -> actual ProfilePress plan names
			'LID'      => 'Lidmaatschap',
			'PRT'      => 'Partnerlid',
			'PI'       => 'Permanent Introducé',
			'VRDN'     => 'Lid van Verdienste',
			'ERE'      => 'Erelidmaatschap',
			'BTN'      => 'Buitenlidmaatschap',
			'ZKN'      => 'Zakelijk lidmaatschap',
			'ASP'      => 'Aspirant lid',
			'ASPIRANT' => 'Aspirant lid',
			'PARTNER'  => 'Partnerlid',
			'INTRO'    => 'Permanent Introducé',
			'INTRODUCE'=> 'Permanent Introducé',
			'ERELID'   => 'Erelidmaatschap',
			'ERELIDMAATSCHAP' => 'Erelidmaatschap',
			'BUITEN'   => 'Buitenlidmaatschap',
			'ZAKELIJK' => 'Zakelijk lidmaatschap',
			'VERDIENSTE' => 'Lid van Verdienste',
			'LIDVANVERDIENSTE' => 'Lid van Verdienste',
		];

		$map = apply_filters( 'smack_uci_ppress_plan_name_map', $default_map, $raw_plan_name );
		$map = is_array( $map ) ? $map : $default_map;

		$key = strtoupper( $raw_plan_name );
		$key = preg_replace( '/\s+/', '', $key ); // tolerate spaces in codes

		if ( isset( $map[ $key ] ) && is_string( $map[ $key ] ) && trim( $map[ $key ] ) !== '' ) {
			return trim( $map[ $key ] );
		}

		return $raw_plan_name;
	}

	/**
	 * Convert CSV date strings to MySQL `Y-m-d`.
	 *
	 * @param string $date
	 * @return string Empty string if conversion fails.
	 */
	private static function convert_to_mysql_date( $date ) {
		$date = trim( (string) $date );
		if ( $date === '' ) {
			return '';
		}

		$ts = strtotime( $date );
		if ( $ts === false ) {
			return '';
		}

		return date( 'Y-m-d', $ts );
	}

	/**
	 * CSV plan code -> ProfilePress numeric `plan_id` mapping.
	 *
	 * @param string $raw_plan_code
	 * @return int|null
	 */
	private static function map_plan_code_to_plan_id( $raw_plan_code ) {
		$raw_plan_code = trim( (string) $raw_plan_code );
		if ( $raw_plan_code === '' ) {
			return null;
		}

		// If it's already numeric, trust it.
		if ( is_numeric( $raw_plan_code ) ) {
			return (int) $raw_plan_code;
		}

		$plan_mapping = [
			'LID'  => 3,
			'PRT'  => 4,
			'PI'   => 6,
			'VRDN' => 5,
			'ERE'  => 1,
			'BTN'  => 2,
			'ZKN'  => 7,
		];

		$key = strtoupper( $raw_plan_code );
		$key = preg_replace( '/\s+/', '', $key );

		if ( isset( $plan_mapping[ $key ] ) ) {
			return (int) $plan_mapping[ $key ];
		}

		return null;
	}

	/**
	 * Normalize CSV money strings into numeric decimal.
	 *
	 * @param string $amount_raw
	 * @return float
	 */
	private static function parse_amount( $amount_raw ) {
		$amount_raw = trim( (string) $amount_raw );
		if ( $amount_raw === '' ) {
			return 0.0;
		}

		// CSV amounts sometimes include currency symbols like "€ 210.00".
		$amount_clean = preg_replace( '/[^0-9,\.\-]/', '', $amount_raw );
		// If only comma exists, treat it as decimal separator.
		if ( strpos( $amount_clean, ',' ) !== false && strpos( $amount_clean, '.' ) === false ) {
			$amount_clean = str_replace( ',', '.', $amount_clean );
		}

		return is_numeric( $amount_clean ) ? (float) $amount_clean : 0.0;
	}

	/**
	 * Get table columns (cached).
	 *
	 * @param string $table
	 * @return array<int, string>
	 */
	private static function get_table_columns( $table ) {
		global $wpdb;
		static $cache = [];

		$table = (string) $table;
		if ( $table === '' ) {
			return [];
		}

		if ( isset( $cache[ $table ] ) ) {
			return $cache[ $table ];
		}

		$columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $table );
		$columns = is_array( $columns ) ? $columns : [];
		$cache[ $table ] = $columns;

		return $columns;
	}

	/**
	 * Ensure a ppress_customers row exists and return `customer_id`.
	 *
	 * @param int $user_id
	 * @return int|null
	 */
	private static function ensure_customer_row( $user_id ) {
		global $wpdb;

		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return null;
		}

		$customers_table = $wpdb->prefix . 'ppress_customers';
		$columns         = self::get_table_columns( $customers_table );
		if ( empty( $columns ) ) {
			self::log( "PPRESS ERROR: Missing table {$customers_table}" );
			return null;
		}

		// If the ProfilePress API exists, use it.
		if ( function_exists( 'ppress_create_customer' ) ) {
			$customer_id = ppress_create_customer( $user_id );
			if ( ! empty( $customer_id ) ) {
				return intval( $customer_id );
			}
			// Fall back to direct insert below if API fails.
		}

		// Fallback: minimal insert into ppress_customers.
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$customers_table} WHERE user_id = %d LIMIT 1",
				$user_id
			)
		);
		if ( $existing ) {
			return intval( $existing );
		}

		$required_customer_cols = [ 'user_id', 'total_spend', 'purchase_count', 'date_created' ];
		foreach ( $required_customer_cols as $col ) {
			if ( ! in_array( $col, $columns, true ) ) {
				self::log( "PPRESS ERROR: Customers table missing column '{$col}' ({$customers_table})" );
				return null;
			}
		}

		$ok = $wpdb->insert(
			$customers_table,
			[
				'user_id'         => $user_id,
				'total_spend'    => 0,
				'purchase_count' => 0,
				'date_created'   => current_time( 'mysql' ),
			],
			[ '%d', '%f', '%d', '%s' ]
		);

		if ( ! $ok ) {
			self::log( "PPRESS ERROR: Failed to insert customer row for user {$user_id}" );
			return null;
		}

		return intval( $wpdb->insert_id );
	}

	/**
	 * Get subscription row id for customer+plan.
	 *
	 * @param int $customer_id
	 * @param int $plan_id
	 * @return int|null
	 */
	private static function get_existing_subscription_id( $customer_id, $plan_id ) {
		global $wpdb;
		$customer_id = intval( $customer_id );
		$plan_id     = intval( $plan_id );

		if ( $customer_id <= 0 || $plan_id <= 0 ) {
			return null;
		}

		$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';
		$columns              = self::get_table_columns( $subscriptions_table );
		if ( empty( $columns ) ) {
			return null;
		}

		if ( ! in_array( 'customer_id', $columns, true ) || ! in_array( 'plan_id', $columns, true ) ) {
			return null;
		}

		$existing_subscription_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$subscriptions_table} WHERE customer_id = %d AND plan_id = %d ORDER BY id DESC LIMIT 1",
				$customer_id,
				$plan_id
			)
		);

		return $existing_subscription_id ? intval( $existing_subscription_id ) : null;
	}

	/**
	 * Insert or update subscription row with the required schema fields.
	 *
	 * @param int    $customer_id
	 * @param int    $plan_id
	 * @param string $status active|expired
	 * @param string $start_date Y-m-d
	 * @param string|null $end_date Y-m-d or null
	 * @param float  $amount
	 * @return int|null subscription id
	 */
	private static function upsert_subscription_row( $customer_id, $plan_id, $status, $start_date, $end_date, $amount ) {
		global $wpdb;

		$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';
		$sub_columns         = self::get_table_columns( $subscriptions_table );
		if ( empty( $sub_columns ) ) {
			return null;
		}

		// ProfilePress may name this column differently across versions.
		$start_col = in_array( 'created_date', $sub_columns, true )
			? 'created_date'
			: ( in_array( 'start_date', $sub_columns, true ) ? 'start_date' : '' );
		if ( $start_col === '' ) {
			self::log( "PPRESS ERROR: Subscriptions table missing start column ('created_date' or 'start_date') ({$subscriptions_table})" );
			return null;
		}

		$has_expiration_col = in_array( 'expiration_date', $sub_columns, true );
		$has_created_at_col = in_array( 'created_at', $sub_columns, true );

		$required_subscription_cols = [
			'customer_id',
			'plan_id',
			'status',
			'parent_order_id',
			'billing_frequency',
			'initial_amount',
			'initial_tax_rate',
			'initial_tax',
			'recurring_amount',
			'recurring_tax_rate',
			'recurring_tax',
			'total_payments',
			'profile_id',
		];
		foreach ( $required_subscription_cols as $col ) {
			if ( ! in_array( $col, $sub_columns, true ) ) {
				self::log( "PPRESS ERROR: Subscriptions table missing required column '{$col}' ({$subscriptions_table})" );
				return null;
			}
		}

		$existing_subscription_id = self::get_existing_subscription_id( $customer_id, $plan_id );
		$created_datetime         = $start_date . ' 00:00:00';
		$expiration_datetime      = $end_date ? ( $end_date . ' 00:00:00' ) : null;

		if ( $existing_subscription_id ) {
			$update_payload = [
				'status'            => $status,
				$start_col          => $created_datetime,
				'recurring_amount' => $amount,
			];
			if ( $has_expiration_col ) {
				$update_payload['expiration_date'] = $expiration_datetime;
			}

			$wpdb->update(
				$subscriptions_table,
				$update_payload,
				[ 'id' => intval( $existing_subscription_id ) ],
				null,
				[ '%d' ]
			);

			return intval( $existing_subscription_id );
		}

		// Insert new subscription. Use defaults for required NOT NULL columns.
		$insert_values = [
			'customer_id'         => intval( $customer_id ),
			'plan_id'             => intval( $plan_id ),
			'status'             => $status,
			$start_col           => $created_datetime,
			'expiration_date'   => $has_expiration_col ? $expiration_datetime : null,
			'parent_order_id'    => 0,
			'billing_frequency'  => '1_year',
			'initial_amount'     => 0,
			'initial_tax_rate'   => '',
			'initial_tax'        => '',
			'recurring_amount'   => $amount,
			'recurring_tax_rate' => '',
			'recurring_tax'       => '',
			'total_payments'     => 0,
			'trial_period'       => null,
			'profile_id'         => '',
			'notes'              => null,
		];

		if ( $has_created_at_col ) {
			$insert_values['created_at'] = current_time( 'mysql' );
		}

		// Only include columns that exist in this ProfilePress installation.
		foreach ( $insert_values as $col => $val ) {
			if ( ! in_array( $col, $sub_columns, true ) ) {
				unset( $insert_values[ $col ] );
			}
		}

		$ok = $wpdb->insert(
			$subscriptions_table,
			$insert_values,
			null
		);

		if ( ! $ok ) {
			self::log(
				'PPRESS ERROR: Failed to insert subscription row for customer=' . (string) $customer_id .
				' plan_id=' . (string) $plan_id . ' status=' . (string) $status
			);
			return null;
		}

		return intval( $wpdb->insert_id );
	}

	/**
	 * @param int   $user_id WordPress user ID.
	 * @param array $data    Mapped meta array (meta_key => value) created by ProfilePressImport.
	 * @param mixed $meta    Additional import mapping info (not required).
	 * @return void
	 */
	public static function handle_ppress_subscription( $user_id, $data = [], $meta = null ) {
		global $wpdb;

		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return;
		}

		// NOTE: We intentionally DO NOT write directly to ProfilePress tables here.
		// Customer + subscription creation/updates must happen only via ProfilePress core APIs.

		// (logs disabled)

		// Core API must exist.
		if ( ! function_exists( 'ppress_create_customer' ) ) {
			self::log( 'PPRESS ERROR: ppress_create_customer() not available.' );
			return;
		}
		if ( ! function_exists( 'ppress_subscribe_user_to_plan' ) ) {
			self::log( 'PPRESS ERROR: ppress_subscribe_user_to_plan() not available.' );
			return;
		}
		if ( ! class_exists( '\\ProfilePress\\Core\\Membership\\Models\\Subscription\\SubscriptionFactory' ) ) {
			self::log( 'PPRESS ERROR: SubscriptionFactory not available.' );
			return;
		}

		$plan_name_raw = trim( (string) get_user_meta( $user_id, 'pp_member_type', true ) );
		$plan_name     = self::translate_plan_name( $plan_name_raw );
		self::log( "PPRESS DEBUG: PlanNameRaw '{$plan_name_raw}' -> PlanName '{$plan_name}' for user {$user_id}" );
		if ( $plan_name === '' ) {
			// No plan mapped for this user row.
			self::log( "PPRESS SKIP: pp_member_type is empty for user {$user_id}" );
			return;
		}

		$start_raw  = trim( (string) get_user_meta( $user_id, 'pp_member_start', true ) );
		$end_raw    = trim( (string) get_user_meta( $user_id, 'pp_member_end', true ) );
		$amount_raw = trim( (string) get_user_meta( $user_id, 'pp_member_amount', true ) );
		self::log( "PPRESS DEBUG: Start='{$start_raw}' End='{$end_raw}' AmountRaw='{$amount_raw}' for user {$user_id}" );

		// Parse dates early for subscription + customer "since" sync.
		$start_dt = self::parse_eu_date_to_mysql_datetime( $start_raw );
		$end_dt   = '';
		if ( ! empty( $end_raw ) ) {
			$end_dt = self::parse_eu_date_to_mysql_datetime( $end_raw );
		}

		// Deep debug: dump any meta keys containing "member" for this user.
		// (logs disabled)

		// CSV amounts sometimes include currency symbols like "€ 210.00".
		// Normalize to a numeric decimal.
		$amount_clean = preg_replace( '/[^0-9,\.\-]/', '', $amount_raw );
		// If only comma exists, treat it as decimal separator.
		if ( strpos( $amount_clean, ',' ) !== false && strpos( $amount_clean, '.' ) === false ) {
			$amount_clean = str_replace( ',', '.', $amount_clean );
		}
		$amount = is_numeric( $amount_clean ) ? (float) $amount_clean : 0.0;

		// 4. CREATE / GET CUSTOMER (core).
		$customer_id = ppress_create_customer( $user_id );
		if ( is_wp_error( $customer_id ) ) {
			self::log( 'PPRESS ERROR: ppress_create_customer: ' . $customer_id->get_error_message() );
			return;
		}
		$customer_id = intval( $customer_id );
		self::log( 'PPRESS DEBUG: Customer ' . (string) $customer_id );

		if ( $customer_id <= 0 ) {
			self::log( "PPRESS ERROR: Customer not created for user {$user_id}" );
			return;
		}

		// Ensure customer is connected to this WP user (prevents wp_user null warnings in CustomerEntity getters).
		if ( class_exists( '\\ProfilePress\\Core\\Membership\\Models\\Customer\\CustomerFactory' ) ) {
			try {
				$customer_entity = \ProfilePress\Core\Membership\Models\Customer\CustomerFactory::fromId( $customer_id );
				if ( $customer_entity && empty( $customer_entity->user_id ) ) {
					$customer_entity->user_id = $user_id;
					$customer_entity->save();
				}
			} catch ( \Throwable $e ) {
				self::log( 'PPRESS ERROR: Customer entity update failed: ' . $e->getMessage() );
			}
		}

		// 5. MAP PLAN NAME → PLAN ID (safe select).
		// Different ProfilePress versions may store the display name in different columns.
		$plans_table = $wpdb->prefix . 'ppress_plans';

		$plan_id = 0;
		$plan_id = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE name = %s LIMIT 1", $plan_name )
		);
		if ( $plan_id <= 0 ) {
			$plan_id = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE LOWER(name) = LOWER(%s) LIMIT 1", $plan_name )
			);
		}
		if ( $plan_id <= 0 ) {
			// Fallback to title / plan_name if those columns exist.
			$columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $plans_table );
			$columns = is_array( $columns ) ? $columns : [];

			if ( in_array( 'title', $columns, true ) ) {
				$plan_id = (int) $wpdb->get_var(
					$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE title = %s LIMIT 1", $plan_name )
				);
				if ( $plan_id <= 0 ) {
					$plan_id = (int) $wpdb->get_var(
						$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE LOWER(title) = LOWER(%s) LIMIT 1", $plan_name )
					);
				}
			}

			if ( $plan_id <= 0 && in_array( 'plan_name', $columns, true ) ) {
				$plan_id = (int) $wpdb->get_var(
					$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE plan_name = %s LIMIT 1", $plan_name )
				);
				if ( $plan_id <= 0 ) {
					$plan_id = (int) $wpdb->get_var(
						$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE LOWER(plan_name) = LOWER(%s) LIMIT 1", $plan_name )
					);
				}
			}
		}

		self::log( 'PPRESS DEBUG: Plan ' . (string) $plan_id );

		if ( $plan_id <= 0 ) {
			// Helpful debug: show available plans so mapping can be corrected.
			$plan_rows = $wpdb->get_results( "SELECT * FROM {$plans_table} ORDER BY id ASC LIMIT 20", ARRAY_A );
			if ( is_array( $plan_rows ) && ! empty( $plan_rows ) ) {
				foreach ( $plan_rows as $r ) {
					$id    = $r['id'] ?? '';
					$name  = $r['name'] ?? '';
					$title = $r['title'] ?? '';
					$pname = $r['plan_name'] ?? '';
					self::log( "PPRESS DEBUG: Available plan id={$id} name='{$name}' title='{$title}' plan_name='{$pname}'" );
				}
			} else {
				self::log( 'PPRESS DEBUG: No plans returned from wp_ppress_plans (unexpected).' );
			}

			self::log( "PPRESS ERROR: Plan not found for '{$plan_name}' (map SoortLid to an existing plan name/title)" );
			return;
		}

		// 8. PREVENT DUPLICATES (core update if exists).
		$existing_subscription_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}ppress_subscriptions WHERE customer_id = %d AND plan_id = %d ORDER BY id DESC LIMIT 1",
				intval( $customer_id ),
				intval( $plan_id )
			)
		);

		$subscription_id = $existing_subscription_id ? intval( $existing_subscription_id ) : 0;

		// 6. CREATE SUBSCRIPTION USING CORE FUNCTION (only if not exists).
		if ( $subscription_id <= 0 ) {
			$order_data = [
				// fallback frequency; ProfilePress may override based on plan configuration
				'billing_frequency' => '1_year',
				'initial_amount'    => 0,
				'recurring_amount'  => $amount,
				'total_payments'    => 0,
			];

			$result = ppress_subscribe_user_to_plan(
				$plan_id,
				intval( $customer_id ),
				$order_data,
				false
			);

			if ( is_wp_error( $result ) ) {
				self::log( 'PPRESS ERROR: ppress_subscribe_user_to_plan failed: ' . $result->get_error_message() );
				return;
			}

			if ( is_array( $result ) && isset( $result['subscription_id'] ) ) {
				$subscription_id = intval( $result['subscription_id'] );
			} elseif ( is_numeric( $result ) ) {
				// Backward compatibility in case ProfilePress changes return type.
				$subscription_id = intval( $result );
			} else {
				self::log( 'PPRESS ERROR: Unexpected return from ppress_subscribe_user_to_plan().' );
				return;
			}
		}

		$subscription_id = $subscription_id ? intval( $subscription_id ) : 0;
		self::log( 'PPRESS DEBUG: Subscription ' . (string) $subscription_id );

		if ( $subscription_id <= 0 ) {
			self::log( "PPRESS ERROR: Subscription creation failed for user {$user_id}" );
			return;
		}

		// 7. FORCE STATUS (ACTIVE / EXPIRED) using entity API.
		try {
			$subscription = \ProfilePress\Core\Membership\Models\Subscription\SubscriptionFactory::fromId( $subscription_id );

			// Fix subscription created date from CSV (European DD-MM-YYYY).
			self::log( "PPRESS DEBUG: parsed pp_member_start raw='{$start_raw}' => '{$start_dt}' for user {$user_id}" );
			if ( $start_dt !== '' ) {
				$subscription->created_date = $start_dt;
			} else {
				self::log( "PPRESS ERROR: could not parse pp_member_start='{$start_raw}' for user {$user_id}" );
			}

			// Set expiration_date if CSV end date exists.
			if ( ! empty( $end_raw ) ) {
				self::log( "PPRESS DEBUG: parsed pp_member_end raw='{$end_raw}' => '{$end_dt}' for user {$user_id}" );
				if ( $end_dt === '' ) {
					self::log( "PPRESS ERROR: Invalid pp_member_end for user {$user_id}: '{$end_raw}'" );
					return;
				}
				$subscription->expiration_date = $end_dt;
			} else {
				// Lifetime: clear expiration if ProfilePress supports it.
				$subscription->expiration_date = null;
			}

			$now_ts = (int) current_time( 'timestamp' );
			if ( empty( $end_raw ) ) {
				$subscription->activate_subscription();
			} else {
				$end_ts = strtotime( $subscription->expiration_date );
				if ( $end_ts !== false && $end_ts >= $now_ts ) {
					$subscription->activate_subscription();
				} else {
					$subscription->expire( true );
				}
			}

			$subscription->save();

			// Customer "since" in ProfilePress UI reads `ppress_customers.date_created`.
			// Core CustomerEntity save cannot persist this on update; set column directly after subscription succeeds.
			if ( $start_dt !== '' ) {
				if ( self::sync_customer_date_created_column( $customer_id, $start_dt, $user_id ) ) {
					self::log( "PPRESS DEBUG: Customer date_created synced id={$customer_id} value='{$start_dt}' user_id={$user_id}" );
				}
			}

			// Debug: confirm final subscription status in DB (read-only).
			$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, status, created_date, expiration_date, recurring_amount
					 FROM {$subscriptions_table}
					 WHERE id = %d
					 LIMIT 1",
					$subscription_id
				),
				ARRAY_A
			);
			if ( is_array( $row ) && ! empty( $row ) ) {
				$st  = $row['status'] ?? '';
				$exp = $row['expiration_date'] ?? '';
				$cd  = $row['created_date'] ?? '';
				self::log( "PPRESS DEBUG: Saved subscription id={$subscription_id} status='{$st}' created_date='{$cd}' expiration_date='{$exp}'" );
			} else {
				self::log( "PPRESS DEBUG: Saved subscription row not found for id={$subscription_id}" );
			}

			// Also verify customer date_created was persisted.
			$customers_table = $wpdb->prefix . 'ppress_customers';
			$crow = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, date_created, user_id FROM {$customers_table} WHERE id = %d LIMIT 1",
					intval( $customer_id )
				),
				ARRAY_A
			);
			if ( is_array( $crow ) && ! empty( $crow ) ) {
				$cdate = $crow['date_created'] ?? '';
				self::log( "PPRESS DEBUG: Saved customer id={$customer_id} date_created='{$cdate}' user_id={$user_id}" );
			}
		} catch ( \Throwable $e ) {
			self::log( 'PPRESS ERROR: Subscription entity update failed: ' . $e->getMessage() );
			return;
		}
	}
}

/**
 * Hook callback wrapper (requested by your step: add_action(..., 'handle_ppress_subscription', 10, 3)).
 *
 * @param int   $user_id
 * @param array $data
 * @param mixed $meta
 */
function handle_ppress_subscription( $user_id, $data = [], $meta = null ) {
	ProfilePressProperHandler::handle_ppress_subscription( $user_id, $data, $meta );
}

add_action( 'smack_csv_importer_user_saved', 'Smackcoders\\WCSV\\handle_ppress_subscription', 10, 3 );

