<?php 

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import;

if (! defined('ABSPATH')) {
    die;
}

/**
 * Class Actions
 * Handles all action hooks related to the Import process.
 */
class Actions {
    
    private static $instance = null;

    /**
     * Flag to indicate whether an import is currently running.
     * Set to true when the import process begins, and false when it ends.
     * This prevents native WP hooks from firing globally outside our plugin.
     */
    public static $is_import_active = false;

    private function __construct() {
        // Post Meta
        add_action('added_post_meta', [$this, 'trigger_post_meta_hook'], 10, 4);
        add_action('updated_post_meta', [$this, 'trigger_post_meta_hook'], 10, 4);

        // User Meta
        add_action('added_user_meta', [$this, 'trigger_user_meta_hook'], 10, 4);
        add_action('updated_user_meta', [$this, 'trigger_user_meta_hook'], 10, 4);

        // Term Meta
        add_action('added_term_meta', [$this, 'trigger_term_meta_hook'], 10, 4);
        add_action('updated_term_meta', [$this, 'trigger_term_meta_hook'], 10, 4);
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Actions();
        }
        return self::$instance;
    }

    /**
     * Triggered when a post meta (custom field) is created or updated.
     * Fires the custom 'sm_uci_pro_update_post_meta' action if an import is active.
     *
     * @param int    $meta_id    The ID of the meta entry.
     * @param int    $object_id  The ID of the imported post.
     * @param string $meta_key   The name/key of the field being saved.
     * @param mixed  $meta_value The value imported into the field.
     */
    public function trigger_post_meta_hook($meta_id, $object_id, $meta_key, $meta_value) {
        if (self::$is_import_active) {
            do_action('sm_uci_pro_update_post_meta', $object_id, $meta_key, $meta_value);
        }
    }

    /**
     * Triggered when a user meta is created or updated.
     * Fires the custom 'sm_uci_pro_update_user_meta' action if an import is active.
     *
     * @param int    $meta_id    The ID of the meta entry.
     * @param int    $object_id  The ID of the imported user.
     * @param string $meta_key   The name/key of the field being saved.
     * @param mixed  $meta_value The value imported into the field.
     */
    public function trigger_user_meta_hook($meta_id, $object_id, $meta_key, $meta_value) {
        if (self::$is_import_active) {
            do_action('sm_uci_pro_update_user_meta', $object_id, $meta_key, $meta_value);
        }
    }

    /**
     * Triggered when a term meta is created or updated.
     * Fires the custom 'sm_uci_pro_update_term_meta' action if an import is active.
     *
     * @param int    $meta_id    The ID of the meta entry.
     * @param int    $object_id  The ID of the imported term.
     * @param string $meta_key   The name/key of the field being saved.
     * @param mixed  $meta_value The value imported into the field.
     */
    public function trigger_term_meta_hook($meta_id, $object_id, $meta_key, $meta_value) {
        if (self::$is_import_active) {
            do_action('sm_uci_pro_update_term_meta', $object_id, $meta_key, $meta_value);
        }
    }

    /**
     * Fired after a post/record is saved during import.
     * Equivalent to WP All Import's 'pmxi_saved_post'
     *
     * @param int|string $post_id The ID of the saved record.
     * @param array $data The data used for the import.
     * @param string $mode The import mode ('Insert' or 'Update').
     */
    public function fire_saved_post($post_id, $data, $mode) {
        if (!empty($post_id)) {
            $is_update = (strtolower($mode) === 'update') ? true : false;
            do_action('sm_uci_pro_saved_post', $post_id, $data, $is_update);
        }
    }

    /**
     * Fired each time an image is imported.
     * Equivalent to WP All Import's 'pmxi_gallery_image'
     *
     * @param int    $post_id                  The ID of the imported item.
     * @param int    $att_id                   The ID of the image that was imported.
     * @param string $filepath                 The local file path to the full size image.
     * @param bool   $is_keep_existing_images  Whether existing images are kept.
     */
    public function fire_gallery_image($post_id, $att_id, $filepath, $is_keep_existing_images = false) {
        if (self::$is_import_active) {
            do_action('sm_uci_pro_gallery_image', $post_id, $att_id, $filepath, $is_keep_existing_images);
        }
    }

    /**
     * Fired when an attachment is uploaded.
     * Equivalent to WP All Import's 'pmxi_attachment_uploaded'
     *
     * @param int    $post_id  The ID of the imported item.
     * @param int    $att_id   The ID of the uploaded attachment.
     * @param string $filepath The local file path to the uploaded file.
     */
    public function fire_attachment_uploaded($post_id, $att_id, $filepath) {
        if (self::$is_import_active) {
            do_action('sm_uci_pro_attachment_uploaded', $post_id, $att_id, $filepath);
        }
    }

    /**
     * Fired before any records are imported.
     * Equivalent to WP All Import's 'pmxi_before_xml_import'
     *
     * @param int|string $import_id The ID/hash of the import template.
     */
    public function fire_before_import($import_id) {
        if (!empty($import_id)) {
            do_action('sm_uci_pro_before_import', $import_id);
        }
    }

    /**
     * Fired after the import process is completed.
     * Equivalent to WP All Import's 'pmxi_after_xml_import'
     *
     * @param int|string $import_id The ID of the import template.
     * @param object|array $import_object Optional. The import object/data.
     */
    public function fire_after_import($import_id, $import_object = null) {
        if (!empty($import_id)) {
            do_action('sm_uci_pro_after_import', $import_id, $import_object);
        }
    }


    /**
     * Fired after a product variation is saved.
     * Equivalent to WP All Import's 'pmxi_product_variation_saved'
     *
     * @param int $variation_id The ID of the saved variation.
     */
    public function fire_product_variation_saved($variation_id) {
        if (!empty($variation_id)) {
            do_action('sm_uci_pro_product_variation_saved', $variation_id);
        }
    }

    /**
     * Fired when an import operation fails.
     *
     * @param \WP_Error $error The error object containing the failure details.
     */
    public function fire_import_failed($error) {
        do_action('sm_uci_pro_import_failed', $error);
    }

    /**
     * Fired before a post/record is created/imported.
     *
     * @param array $post_data The data of the post being imported.
     */
    public function fire_before_post_create($post_data) {
        if (isset($post_data['ID'])) {
            unset($post_data['ID']);
        }
        if (isset($post_data['id'])) {
            unset($post_data['id']);
        }
        do_action('sm_uci_before_post_create', $post_data);
    }

    /**
     * Fired after a post/record is created/imported.
     *
     * @param int|string $post_id The ID of the imported post.
     */
    public function fire_after_post_create($post_id) {
        if (!empty($post_id)) {
            do_action('sm_uci_after_post_create', $post_id);
        }
    }

    /**
     * Fired after a post/record is updated during import.
     *
     * @param int|string $post_id The ID of the updated post.
     */
    public function fire_after_post_update($post_id) {
        if (!empty($post_id)) {
            do_action('sm_uci_after_post_update', $post_id);
        }
    }

    /**
     * Fired before a post/record is updated during import.
     *
     * @param array $post_data The data of the post being updated.
     */
    public function fire_before_post_update($post_data) {
        do_action('sm_uci_before_post_update', $post_data);
    }

    /**
     * Fired before a user/woocommerce customer/profilepress user is created/updated during import.
     *
     * @param array  $data_array The data of the user being imported.
     * @param string $mode       The import mode ('Insert' or 'Update').
     */
    public function fire_before_user_import($data_array, $mode) {
        do_action('sm_uci_pro_before_user_import', $data_array, $mode);
    }

    /**
     * Fired after a user/woocommerce customer/profilepress user is created/updated during import.
     *
     * @param int|string $user_id        The ID of the imported user.
     * @param array      $data_array     The data of the user that was imported.
     * @param string     $mode_of_affect The operation performed ('Inserted' or 'Updated').
     */
    public function fire_after_user_import($user_id, $data_array, $mode_of_affect) {
        if (!empty($user_id)) {
            do_action('sm_uci_pro_after_user_import', $user_id, $data_array, $mode_of_affect);
        }
    }

    /**
     * Fired after a post, page, or custom post type is imported.
     * Supports post, page, and custom post types (cpt), custom taxonomy types (cct).
     * Passes id, mode (Insert/Update), and type for developer convenience.
     *
     * @param int|string $post_id The ID of the imported post.
     * @param string     $mode    The operation performed ('Insert' or 'Update').
     * @param string     $type    The post type being imported (e.g., 'post', 'page', 'product', or custom post type).
     */
    public function fire_after_post_import($post_id, $mode, $type) {
        if (!empty($post_id)) {
            do_action('sm_uci_afterpost_import', $post_id, $mode, $type);
        }
    }

    /**
     * Fired after a user import batch completes.
     * Passes id, mode, and type for developer convenience.
     *
     * @param int|string $user_id The ID of the imported user.
     * @param string     $mode    The operation performed ('Insert' or 'Update').
     * @param string     $type    The user type being imported (e.g., 'user', 'customer', 'profilepress_user').
     */
    public function fire_after_user_import_complete($user_id, $mode, $type = 'user') {
        if (!empty($user_id)) {
            do_action('sm_uci_pro_after_user_import_complete', $user_id, $mode, $type);
        }
    }

    /**
     * Fired after a taxonomy term is imported.
     * Passes id, mode, and type for developer convenience.
     *
     * @param int|string $term_id The ID of the imported taxonomy term.
     * @param string     $mode    The operation performed ('Insert' or 'Update').
     * @param string     $type    The taxonomy name being imported (e.g., 'category', 'post_tag', 'product_cat').
     */
    public function fire_after_taxonomy_import($term_id, $mode, $type) {
        if (!empty($term_id)) {
            do_action('sn_uci_pro_after_taxonomy_import', $term_id, $mode, $type);
        }
    }

    /**
     * Fired after a WooCommerce product or variation is imported.
     * Passes id, mode, and type for developer convenience.
     *
     * @param int|string $product_id The ID of the imported WooCommerce product/variation.
     * @param string     $mode       The operation performed ('Insert' or 'Update').
     * @param string     $type       The WooCommerce product type (e.g., 'simple', 'variable', 'variation', 'grouped', 'external').
     */
    public function fire_after_woocommerce_import($product_id, $mode, $type) {
        if (!empty($product_id)) {
            do_action('sm_uci_pro_after_woocommerce_import', $product_id, $mode, $type);
        }
    }

}
