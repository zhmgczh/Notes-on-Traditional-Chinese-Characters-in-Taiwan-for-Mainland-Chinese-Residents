<?php 

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import;

if (! defined('ABSPATH')) {
    die;
}

/**
 * Class Filters
 * Handles all filter hooks related to the Import process.
 */
class Filters {
    
    private static $instance = null;

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Filters();
        }
        return self::$instance;
    }

    /**
     * Apply a filter to modify ACF field values during import.
     * Equivalent to WP All Import's 'pmxi_acf_custom_field'
     *
     * @param mixed  $value      The value being imported.
     * @param int    $post_id    The ID of the imported item.
     * @param string $name       The ACF field name.
     * @param string $import_id  The unique import hash/ID.
     * @return mixed             The filtered value.
     */
    public function apply_acf_custom_filter($value, $post_id, $name, $import_id = '') {
        $original_value = $value;
        $value = apply_filters('sm_uci_pro_acf_custom', $value, $post_id, $name);
        
        // Also apply the global custom field filter as requested (equivalent to pmxi_custom_field)
        $existing_meta_keys = get_post_custom_keys($post_id) ?: [];
        $value = apply_filters('sm_uci_pro_custom_field', $value, $post_id, $name, $original_value, $existing_meta_keys, $import_id);
        
        return $value;
    }

    /**
     * Apply a filter to modify core post data before import.
     * Equivalent to WP All Import's 'pmxi_article_data'
     *
     * @param array  $articleData      The core post data being imported.
     * @param string $import_id        The import hash/ID.
     * @param object $post_to_update   The existing post object (if any).
     * @param array  $current_record   The raw data for the current record.
     * @return array                   The modified article data.
     */
    public function apply_article_data_filter($articleData, $import_id, $post_to_update, $current_record) {
        return apply_filters('sm_uci_pro_article_data', $articleData, $import_id, $post_to_update, $current_record);
    }

    /**
     * Apply a filter to modify custom field values before they are saved.
     * Equivalent to WP All Import's 'pmxi_custom_field'
     *
     * @param mixed  $value              The value being imported.
     * @param int    $post_id            The ID of the imported record.
     * @param string $key                The custom field key.
     * @param mixed  $original_value     The original, unprocessed value.
     * @param array  $existing_meta_keys List of existing meta keys for the post.
     * @param string $import_id          The unique import hash/ID.
     * @return mixed                     The modified value.
     */
    public function apply_custom_field_filter($value, $post_id, $key, $original_value, $existing_meta_keys, $import_id) {
        return apply_filters('sm_uci_pro_custom_field', $value, $post_id, $key, $original_value, $existing_meta_keys, $import_id);
    }

    /**
     * Apply a filter to modify taxonomy term information before import.
     * Equivalent to WP All Import's 'pmxi_single_category'
     *
     * @param array  $term_info  Array with term information (name, parent, assign, etc.).
     * @param string $tax_name   The taxonomy name.
     * @return array             The modified term information.
     */
    public function apply_single_category_filter($term_info, $tax_name) {
        return apply_filters('sm_uci_pro_single_category', $term_info, $tax_name);
    }

    /**
     * Apply a filter to control whether images are updated for the record.
     * Equivalent to WP All Import's 'pmxi_is_images_to_update'
     *
     * @param bool  $is_update                   Whether to update images.
     * @param array $articleData                 Current import item data.
     * @param array $current_process_record_data Parsed data for the current record.
     * @param int   $post_id                     The post ID.
     * @return bool                              The filtered value.
     */
    public function apply_is_images_to_update_filter($is_update, $articleData, $current_process_record_data, $post_id) {
        return apply_filters('sm_uci_pro_is_images_to_update', $is_update, $articleData, $current_process_record_data, $post_id);
    }


    /**
     * Apply a filter to control whether attachments are updated for the record.
     * Equivalent to WP All Import's 'pmxi_is_attachments_to_update'
     *
     * @param bool  $is_to_update     Whether the attachment should be updated or not.
     * @param int   $articleData      Contains a list of data related to the post/user/taxonomy being imported.
     * @param array $current_node Array of data for current import record.
     * @return bool                   The filtered value.
     */
    public function apply_is_attachments_to_update_filter($is_to_update, $articleData, $current_node) {
        return apply_filters('sm_uci_pro_is_attachments_to_update', $is_to_update, $articleData, $current_node);
    }

    /**
     * Apply a filter to control whether a post should be updated or skipped.
     * Equivalent to WP All Import's 'wp_all_import_is_post_to_update'
     *
     * @param bool  $continue   true to update, false to skip.
     * @param int   $post_id    The Post ID that's about to be updated.
     * @param array $node   An array containing the data for the current import record.
     * @param int   $import_id  The ID/hash of the import that's running.
     * @return bool             The filtered value.
     */
    public function apply_is_post_to_update_filter($continue, $post_id, $node, $import_id) {
        return apply_filters('sm_uci_import_is_post_to_update', $continue, $post_id, $node, $import_id);
    }

    /**
     * Apply a filter to control whether a post should be created or skipped.
     * Equivalent to WP All Import's 'wp_all_import_is_post_to_create'
     *
     * @param bool  $continue   true to create, false to skip.
     * @param array $node       An array containing the data for the current import record.
     * @param int   $import_id  The ID/hash of the import that's running.
     * @return bool             The filtered value.
     */
    public function apply_is_post_to_create_filter($continue, $node, $import_id) {
        return apply_filters('sm_uci_pro_is_post_to_create', $continue, $node, $import_id);
    }

    /**
     * Apply a filter to redirect where imported attachments/images get saved.
     * Equivalent to WP All Import's 'wp_all_import_attachments_uploads_dir'
     *
     * @param array  $uploads      Array with keys: path, url, subdir, basedir, baseurl, error.
     * @param array  $articleData  Contains a list of data related to the post/user/taxonomy being imported.
     * @param array  $current_node Array of data for current import record.
     * @param string $import_id    The ID/hash of the import that's running.
     * @return array               The filtered uploads array.
     */
    public function apply_attachments_uploads_dir_filter($uploads, $articleData, $current_node, $import_id) {
        return apply_filters('sm_uci_pro_attachments_uploads_dir', $uploads, $articleData, $current_node, $import_id);
    }

    /**
     * Apply a filter that allows modifying the attachment matched from the Media Library or uploads folder.
     * Equivalent to WP All Import's 'wp_all_import_get_image_from_gallery'
     *
     * @param WP_Post|null $attach      The matched attachment WP_Post object (has .ID, .post_title, .guid, etc.).
     * @param string       $image_name  The filename being matched (e.g. 'product-shoe.jpg').
     * @param string       $target_dir  Absolute path to the upload destination directory.
     * @return WP_Post|null             The filtered attachment object.
     */
    public function apply_get_image_from_gallery_filter($attach, $image_name, $target_dir) {
        return apply_filters('sm_uci_pro_get_image_from_gallery', $attach, $image_name, $target_dir);
    }

    /**
     * Apply a filter to intercept and modify the uploaded file data after an
     * attachment/image is saved to disk and before it is registered in the Media Library.
     * Equivalent to WP All Import's 'wp_all_import_handle_upload'
     *
     * @param array $file  Array with keys:
     *                     - 'file' (string) Absolute server path to the uploaded file.
     *                     - 'url'  (string) Public URL to the uploaded file.
     *                     - 'type' (string) MIME type of the uploaded file.
     * @return array       The filtered file array. Must always be returned.
     */
    public function apply_handle_upload_filter($file) {
        return apply_filters('sm_uci_pro_handle_upload', $file);
    }

    /**
     * Apply a filter to customize the filename of an image before it is saved to the Media Library.
     * Equivalent to WP All Import's 'wp_all_import_image_filename'
     *
     * @param string $filename    The current derived filename (e.g. 'product-image.jpg').
     * @param string $img_title   The image title from import settings (may be empty).
     * @param string $img_caption The image caption from import settings (may be empty).
     * @param string $img_alt     The image alt text from import settings (may be empty).
     * @param array  $articleData The full data array for the current import row.
     * @param string $import_id   The ID/hash of the import that's running.
     * @param string $img_url     The original source URL of the image.
     * @return string             The filtered filename. Must be non-empty and include the extension.
     */
    public function apply_image_filename_filter($filename, $img_title, $img_caption, $img_alt, $articleData, $import_id, $img_url) {
        return apply_filters('sm_uci_pro_image_filename', $filename, $img_title, $img_caption, $img_alt, $articleData, $import_id, $img_url);
    }

    /**
     * Apply a filter to customize the filename of an image imported via API or Add-Ons (ACF, Gallery, etc).
     * Equivalent to WP All Import's 'wp_all_import_api_image_filename'
     *
     * @param string $image_name The current derived filename.
     * @param string $img_url    The original source URL of the image.
     * @param int    $pid        The Post ID that the image is being attached to.
     * @return string            The filtered filename.
     */
    public function apply_api_image_filename_filter($image_name, $img_url, $pid) {
        return apply_filters('sm_uci_pro_api_image_filename', $image_name, $img_url, $pid);
    }

    /**
     * Apply a filter to dynamically change the FTP root directory.
     * Equivalent to WP All Import's 'wpai_ftp_root'
     *
     * @param string $root       The FTP root path (default '/').
     * @param string $import_id  The unique event hash key identifying this import configuration.
     * @return string            The modified FTP root path.
     */
    public function apply_ftp_root_filter($root, $import_id) {
        return apply_filters('sm_uci_pro_ftp_root', $root, $import_id);
    }

    /**
     * Apply a filter to define if the images section is enabled or disabled for a specific post type during import.
     * Equivalent to WP All Import's 'wp_all_import_is_images_section_enabled'
     *
     * @param bool   $enabled   Whether the images section is enabled or not. Returns true by default.
     * @param string $post_type The post type that's being imported.
     * @return bool             The filtered value.
     */
    public function apply_is_images_section_enabled_filter($enabled, $post_type) {
        return apply_filters('sm_uci_pro_is_images_section_enabled', $enabled, $post_type);
    }

    /**
     * Apply a filter to control whether a user/woocommerce customer/profilepress user should be created or skipped.
     *
     * @param bool   $continue     true to create, false to skip.
     * @param array  $data_array   An array containing the data for the current import record.
     * @param string $unikey_value The unique key value for the current record.
     * @return bool                The filtered value.
     */
    public function apply_is_user_to_create_filter($continue, $data_array, $unikey_value) {
        return apply_filters('sm_uci_pro_is_user_to_create', $continue, $data_array, $unikey_value);
    }

    /**
     * Apply a filter to modify user/woocommerce customer/profilepress user data before it is saved.
     *
     * @param array  $data_array   The user data being imported.
     * @param string $unikey_value The unique key value for the current record.
     * @return array               The modified user data.
     */
    public function apply_user_data_filter($data_array, $unikey_value) {
        return apply_filters('sm_uci_pro_user_data', $data_array, $unikey_value);
    }

    /**
     * Apply a filter to modify, add, remove, or replace the taxonomy terms assigned to a post during import.
     * Equivalent to WP All Import's 'wp_all_import_set_post_terms'
     *
     * @param array  $term_taxonomy_ids The term taxonomy IDs (or names/slugs) about to be assigned.
     * @param string $tx_name           The taxonomy being assigned.
     * @param int    $pid               The ID of the post being imported.
     * @param int|string $import_id     The ID/hash of the import that's running.
     * @return array                    The filtered term taxonomy IDs.
     */
    public function apply_setpost_terms_filter($term_taxonomy_ids, $tx_name, $pid, $import_id = '') {
        return apply_filters('sm_uci_pro_setpost_terms', $term_taxonomy_ids, $tx_name, $pid, $import_id);
    }

    /**
     * Apply a filter to intercept and override term existence checks.
     * Equivalent to WP All Import's 'wp_all_import_term_exists'
     *
     * @param mixed  $term_exists What term_exists() returned (null/int/array).
     * @param string $taxonomy    Context taxonomy.
     * @param string $term        The term being looked up (name, slug, or ID).
     * @param int    $parent      Parent term ID (0 if no parent).
     * @return mixed               Modified or original return value.
     */
    public function apply_term_exists_filter($term_exists, $taxonomy, $term, $parent = 0) {
        return apply_filters('sm_uci_pro_term_exists', $term_exists, $taxonomy, $term, $parent);
    }



    /**
     * Apply a filter to modify row data before main import processing.
     * Developers can intercept and modify the row data before it's processed by main_import_process.
     *
     * @param array  $row_data      The row data extracted from the import file.
     * @return array                The modified row data to be passed to main import.
     */
    public function apply_before_import_row_filter($row_data, $import_id = '', $line_number = 0, $header_array = array()) {
        return apply_filters('sm_uci_pro_import_row_data', $row_data, $import_id, $line_number, $header_array);
    }

    /**
     * Apply a filter to control whether duplicate checking is enabled for a specific import.
     * When disabled, the importer always creates new records instead of checking if they exist.
     * Equivalent to WP All Import's 'wp_all_import_is_check_duplicates'
     *
     * @param bool   $is_check_duplicates  Whether to check for duplicates. Default: true
     * @param string $import_id            The unique import template configuration hash.
     * @param string $type                 The post type or content type being imported.
     * @param string $post_type            The WordPress post type from the database perspective.
     * @return bool                        true to check for duplicates, false to skip checking.
     */
    public function apply_is_check_duplicates_filter($is_check_duplicates, $import_id, $type, $post_type) {
        return apply_filters('sm_uci_pro_import_is_check_duplicates', $is_check_duplicates, $import_id, $type, $post_type);
    }

}

