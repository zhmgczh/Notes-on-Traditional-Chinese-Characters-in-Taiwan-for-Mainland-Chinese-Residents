<?php 

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export;

if (! defined('ABSPATH')) {
    die;
}

/**
 * Class Actions
 * Handles all action hooks related to the Export process.
 */
class Actions {
    
    private static $instance = null;

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Actions();
        }
        return self::$instance;
    }

    /**
     * Fired at the start of an export before any data is processed.
     * Equivalent to WP All Export's 'pmxe_before_export'
     *
     * @param int $export_id The export ID.
     */
    public function fire_before_export($export_id) {
        if (!empty($export_id)) {
            do_action('sm_uci_pro_before_export', $export_id);
        }
    }

    /**
     * Fired after an export finishes successfully.
     * Equivalent to WP All Export's 'pmxe_after_export'
     *
     * @param int $export_id The export ID.
     * @param object $exportObj Full export data.
     */
    public function fire_after_export($export_id, $exportObj) {
        if (!empty($export_id)) {
            do_action('sm_uci_pro_after_export', $export_id, $exportObj);
        }
    }

    /**
     * Fired after each iteration (batch) during a cron-based scheduled export.
     * Equivalent to WP All Export's 'pmxe_after_iteration'
     *
     * @param int $export_id The export ID.
     * @param object $exportObj Full export data.
     */
    public function fire_after_iteration($export_id, $exportObj) {
        if (!empty($export_id)) {
            do_action('sm_uci_pro_after_iteration', $export_id, $exportObj);
        }
    }

    /**
     * Fired after each individual record (post) is written to the export file.
     * Equivalent to WP All Export's 'pmxe_exported_post'
     *
     * @param int $post_id The unique ID of the post/record.
     * @param object $exportObj Full export data.
     */
    public function fire_exported_post($post_id, $exportObj) {
        if (!empty($post_id)) {
            if (empty($exportObj->id) && !empty($exportObj->export_id)) {
                $exportObj->id = $exportObj->export_id;
            }
            do_action('sm_uci_pro_exported_post', $post_id, $exportObj);
        }
    }
}
