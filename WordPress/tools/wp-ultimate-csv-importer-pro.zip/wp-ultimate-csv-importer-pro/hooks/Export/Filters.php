<?php 

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export;

if (! defined('ABSPATH')) {
    die;
}

/**
 * Class Filters
 * Handles all filter hooks related to the Export process.
 */
class Filters {
    
    private static $instance = null;

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Filters();
        }
        return self::$instance;
    }

    /**
     * Apply a filter to intercept and modify every row written to the CSV file during export.
     * Equivalent to WP All Export's 'pmxe_csv_value'
     *
     * @param string $value The full CSV row string (one complete line at a time).
     * @return string       The filtered CSV row string.
     */
    public function apply_csv_value_filter($value) {
        return apply_filters('sm_uci_pro_csv_value', $value);
    }

    /**
     * Apply a filter to modify the WooCommerce regular price before it is written to the export.
     * Equivalent to WP All Export's 'pmxe_price' for regular price.
     *
     * @param string|float $price The regular price value.
     * @param int          $id    The product/variation post ID.
     * @return string|float       The filtered regular price.
     */
    public function apply_regular_price_filter($price, $id) {
        return apply_filters('sm_uci_pro_regular_price', $price, $id);
    }

    /**
     * Apply a filter to modify the WooCommerce sale price before it is written to the export.
     * Equivalent to WP All Export's 'pmxe_price' for sale price.
     *
     * @param string|float $price The sale price value.
     * @param int          $id    The product/variation post ID.
     * @return string|float       The filtered sale price.
     */
    public function apply_sale_price_filter($price, $id) {
        return apply_filters('sm_uci_pro_sale_price', $price, $id);
    }

    /**
     * Apply a filter to add, remove, or rename column headers in the exported CSV file.
     * Equivalent to WP All Export's 'wp_all_export_csv_headers'.
     *
     * @param array $headers An array of column header names.
     * @return array         The filtered array of column header names.
     */
    public function apply_export_csv_headers_filter($headers) {
        return apply_filters('sm_uci_pro_export_csv_headers', $headers);
    }

    /**
     * Apply a filter that fires after every single line is written to the CSV file.
     * Gives direct access to the file resource handle to write raw content.
     * Equivalent to WP All Export's 'wp_all_export_after_csv_line'.
     *
     * @param resource $stream The file pointer resource.
     * @return resource        The file pointer resource.
     */
    public function apply_export_after_csv_line_filter($stream) {
        return apply_filters('sm_uci_pro_export_after_csv_line', $stream);
    }

    
    /**
     * Apply a filter to intercept and modify WooCommerce field values during export.
     * Equivalent to WP All Export's 'pmxe_woo_field'.
     *
     * @param string $value      The field value.
     * @param string $field_name The name of the field (e.g. '_price', '_sku').
     * @param int    $pid        The product ID.
     * @return string            The filtered field value.
     */
    public function apply_export_woo_fields_filter($value, $field_name, $pid) {
        return apply_filters('sm_uci_pro_export_woo_fields', $value, $field_name, $pid);
    }

    /**
     * Apply a filter to intercept and modify WooCommerce product attribute values during export.
     * Equivalent to WP All Export's 'pmxe_woo_attribute'.
     *
     * @param string $atts     The attribute values (pipe-separated if multiple).
     * @param int    $pid      The product ID.
     * @param string $att_name The name/slug of the attribute.
     * @return string          The filtered attribute value.
     */
    public function apply_export_woo_attribute_filter($atts, $pid, $att_name) {
        return apply_filters('sm_uci_pro_export_woo_attribute', $atts, $pid, $att_name);
    }

    /**
     * Apply a filter to let developers narrow down the export ID list before processing begins.
     * Only IDs already present in the original list are allowed — any new IDs added by the callback
     * will be silently ignored (intersection guard).
     *
     * @param array  $ids    The original array of post/record IDs queried for export.
     * @param string $module The export module (e.g. 'Posts', 'WooCommerce', 'WooCommerceOrders').
     * @return array         The validated (intersected) array of IDs to export.
     */
    public function apply_export_post_ids_filter($ids, $module) {
        $filtered = apply_filters('sm_uci_pro_post_ids', $ids, $module);

        // Safety: only allow IDs that existed in the original query result.
        // Prevents injection of arbitrary IDs the current user should not export.
        if ( is_array($filtered) ) {
            return array_values( array_intersect( $filtered, $ids ) );
        }

        return $ids;
    }

    /**
     * Apply a filter to modify the post's title when exporting.
     * Equivalent to WP All Export's 'pmxe_post_title'.
     *
     * @param string $value Current post title.
     * @return string       The filtered post title.
     */
    public function apply_export_post_title_filter($value) {
        return apply_filters('sm_uci_pro_export_post_title', $value);
    }

    /**
     * Apply a filter to modify the post's content when exporting.
     * Equivalent to WP All Export's 'pmxe_post_content'.
     *
     * @param string $value Current post content.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post content.
     */
    public function apply_export_post_content_filter($value, $pid) {
        return apply_filters('sm_uci_pro_export_post_content', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's date when exporting.
     * Equivalent to WP All Export's 'pmxe_post_date'.
     *
     * @param string $value Current post date.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post date.
     */
    public function apply_export_post_date_filter($value, $pid) {
        return apply_filters('sm_uci_pro_post_date', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's status when exporting.
     * Equivalent to WP All Export's 'pmxe_post_status'.
     *
     * @param string $value Current post status.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post status.
     */
    public function apply_export_post_status_filter($value, $pid) {
        return apply_filters('sm_uci_pro_post_status', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's slug (post_name) when exporting.
     * Equivalent to WP All Export's 'pmxe_post_slug'.
     *
     * @param string $value Current post slug (post_name).
     * @param int    $pid   Current post ID.
     * @return string       The filtered post slug.
     */
    public function apply_export_post_slug_filter($value, $pid) {
        return apply_filters('sm_uci_pro_post_slug', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's excerpt when exporting.
     * Equivalent to WP All Export's 'pmxe_post_excerpt'.
     *
     * @param string $value Current post excerpt.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post excerpt.
     */
    public function apply_export_post_excerpt_filter($value, $pid) {
        return apply_filters('sm_uci_pro_export_post_excerpt', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's format when exporting.
     * Equivalent to WP All Export's 'pmxe_post_format'.
     *
     * @param string $value Current post format.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post format.
     */
    public function apply_export_post_format_filter($value, $pid) {
        return apply_filters('sm_uci_pro_export_post_format', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's author when exporting.
     * Equivalent to WP All Export's 'pmxe_post_author'.
     *
     * @param string $value Current post author.
     * @param int    $pid   Current post ID.
     * @return string       The filtered post author.
     */
    public function apply_export_post_author_filter($value, $pid) {
        return apply_filters('sm_uci_pro_export_post_author', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's ping status when exporting.
     * Equivalent to WP All Export's 'pmxe_ping_status'.
     *
     * @param string $value Current ping status.
     * @param int    $pid   Current post ID.
     * @return string       The filtered ping status.
     */
    public function apply_export_ping_status_filter($value, $pid) {
        return apply_filters('sm_uci_pro_export_ping_status', $value, $pid);
    }

    /**
     * Apply a filter to modify the post's taxonomy values when exporting.
     * Equivalent to WP All Export's 'pmxe_post_taxonomy'.
     *
     * @param string $value         Current post taxonomy term.
     * @param int    $pid           Current post ID.
     * @param string $taxonomy_slug The taxonomy slug.
     * @return string               The filtered post taxonomy.
     */
    public function apply_export_post_taxonomy_filter($value, $pid, $taxonomy_slug = '') {
        return apply_filters('sm_uci_pro_export_post_taxonomy', $value, $pid, $taxonomy_slug);
    }

    /**
     * Apply a filter to modify the exported term ID.
     * Equivalent to WP All Export's 'pmxe_term_id'.
     */
    public function apply_export_term_id_filter($term_id, $id) {
        $term_id = apply_filters('sm_uci_pro_term_id', $term_id, $id);
        return apply_filters('sm_uci_pro_export_term_id', $term_id, $id);
    }

    /**
     * Apply a filter to modify the exported term name.
     * Equivalent to WP All Export's 'pmxe_term_name'.
     */
    public function apply_export_term_name_filter($term_name, $id) {
        $term_name = apply_filters('sm_uci_pro_term_name', $term_name, $id);
        return apply_filters('sm_uci_pro_export_term_name', $term_name, $id);
    }

    /**
     * Apply a filter to modify the exported term slug.
     * Equivalent to WP All Export's 'pmxe_term_slug'.
     */
    public function apply_export_term_slug_filter($term_slug, $id) {
        $term_slug = apply_filters('sm_uci_pro_term_slug', $term_slug, $id);
        return apply_filters('sm_uci_pro_export_term_slug', $term_slug, $id);
    }

    /**
     * Apply a filter to modify the exported term description.
     * Equivalent to WP All Export's 'pmxe_term_description'.
     */
    public function apply_export_term_description_filter($term_description, $id) {
        $term_description = apply_filters('sm_uci_pro_term_description', $term_description, $id);
        return apply_filters('sm_uci_pro_export_term_description', $term_description, $id);
    }

    /**
     * Apply a filter to modify the exported term parent.
     * Equivalent to WP All Export's 'pmxe_term_parent'.
     */
    public function apply_export_term_parent_filter($term_parent, $id) {
        $term_parent = apply_filters('sm_uci_pro_term_parent', $term_parent, $id);
        return apply_filters('sm_uci_pro_export_term_parent', $term_parent, $id);
    }

    /**
     * Apply a filter to modify the exported comment ID.
     */
    public function apply_export_comment_id_filter($comment_id) {
        return apply_filters('sm_uci_pro_export_comment_id', $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment post ID.
     */
    public function apply_export_comment_post_id_filter($comment_post_id, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_post_id', $comment_post_id, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment author.
     */
    public function apply_export_comment_author_filter($comment_author, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_author', $comment_author, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment author email.
     */
    public function apply_export_comment_author_email_filter($comment_author_email, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_author_email', $comment_author_email, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment author URL.
     */
    public function apply_export_comment_author_url_filter($comment_author_url, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_author_url', $comment_author_url, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment author IP.
     */
    public function apply_export_comment_author_ip_filter($comment_author_ip, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_author_ip', $comment_author_ip, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment karma.
     */
    public function apply_export_comment_karma_filter($comment_karma, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_karma', $comment_karma, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment content.
     */
    public function apply_export_comment_content_filter($comment_content, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_content', $comment_content, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment date.
     */
    public function apply_export_comment_date_filter($comment_date, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_date', $comment_date, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment approved status.
     */
    public function apply_export_comment_approved_filter($comment_approved, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_approved', $comment_approved, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment user agent.
     */
    public function apply_export_comment_agent_filter($comment_agent, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_agent', $comment_agent, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment type.
     */
    public function apply_export_comment_type_filter($comment_type, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_type', $comment_type, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment parent.
     */
    public function apply_export_comment_parent_filter($comment_parent, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_parent', $comment_parent, $comment_id);
    }

    /**
     * Apply a filter to modify the exported comment status.
     */
    public function apply_export_comment_status_filter($comment_status, $comment_id) {
        return apply_filters('sm_uci_pro_export_comment_status', $comment_status, $comment_id);
    }

    /**
     * Apply a filter to modify the WPML language code of a post/taxonomy element before it is exported.
     * Equivalent to WP All Export's 'pmxe_trid_field'.
     *
     * @param string $language_code The WPML language code (e.g. en, fr, de).
     * @param string $element_name  The WPML element/translation group type or ID.
     * @param int    $pid           The current post/taxonomy term ID being exported.
     * @return string               The filtered language code.
     */
    public function apply_export_tried_field_filter($language_code, $element_name, $pid) {
        return apply_filters('sm_uci_pro_export_tried_field', $language_code, $element_name, $pid);
    }

}

