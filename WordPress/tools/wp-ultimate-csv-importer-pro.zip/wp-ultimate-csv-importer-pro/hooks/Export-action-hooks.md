# WP Ultimate CSV Importer Pro - Export Action Hooks Reference

This document provides a comprehensive technical reference for the custom export action hooks available in the **WP Ultimate CSV Importer Pro** plugin. These hooks allow developers to run custom code at key milestones during the export process.

---

## 1. Before Export Action Hook

---

### `sm_uci_pro_before_export`

##### Description
This action runs at the start of an export process before any actual record data is fetched, parsed, or processed. It provides the unique export template ID and is ideal for setting up custom export logs, cleaning temporary directories, or performing pre-flight checks and API notifications.

##### How it works
```
Export starts
    → sm_uci_pro_before_export fires
    → Data query and fetching begins
    → Row-by-row processing starts
    → Compilation to CSV/XML/XLSX
```

##### Parameters
* **`$export_id`** *(int)* *(Required)*
  The unique ID of the export template being executed. In **WP Ultimate CSV Importer Pro**, this corresponds to the ID in the `{wp_prefix}sm_uci_addon_pro_export_template` database table.

##### Source
* **File:** `hooks/Export/Actions.php`
* **Applied in:**
  * `exportExtensions/ExportExtension.php` (AJAX exports)
  * `scheduleExtensions/ScheduleExport.php` (Cron scheduled exports)

### Example Usage

#### Example: Create a custom audit log entry on export start
This example creates a custom log entry whenever an export starts, noting the timestamp and the export template ID.

```php
add_action( 'sm_uci_pro_before_export', 'wp_all_export_before_export', 10, 1 );

function wp_all_export_before_export( $export_id ) {
    // Run this for a specific export template or globally
    $log_message = sprintf(
        "[%s] Export process started for Export Template ID: %d\n",
        current_time( 'mysql' ),
        $export_id
    );

    // Save to a custom log file
    error_log( $log_message, 3, WP_CONTENT_DIR . '/export-audit.log' );
}
```

---

### Key Things to Remember

| Aspect | Detail |
| :--- | :--- |
| **Fires Once** | Unlike filter hooks that run row-by-row, this action fires exactly once at the absolute beginning of an export execution. |
| **No Data is Fetched Yet** | Runs before any database query is executed for the records, ensuring a clean pre-flight environment. |
| **Supports Scheduled Exports** | Fires both during interactive manual exports (via AJAX) and automated background cron exports. |
| **WP All Export Parity** | Equivalent to WP All Export's `pmxe_before_export` action hook. |

---

## 2. After Export Action Hook

---

### `sm_uci_pro_after_export`

##### Description
This action fires automatically after an export finishes successfully, giving you access to the export ID and the full export object so you can run custom logic such as sending emails, moving generated files, logging stats, or triggering external API webhooks.

##### How it works
```
Export runs → Export completes successfully → sm_uci_pro_after_export fires → Your function runs
```

##### Parameters
* **`$export_id`** *(int)* *(Required)*
  The unique ID of the export template being executed.
* **`$exportObj`** *(object)* *(Required)*
  Full export object holding export options, filename, and file path parameters.
  * `$exportObj->options['filepath']` (string) - Absolute path to the generated export file.
  * `$exportObj->options['filename']` (string) - The export template name.
  * `$exportObj->options['records']` (int) - The total row count exported.
  * `$exportObj->options['filesize']` (int) - The size of the generated export file in bytes.

##### Source
* **File:** `hooks/Export/Actions.php`
* **Applied in:**
  * `exportExtensions/ExportExtension.php` (AJAX exports & Cron scheduled exports completion)

---

### Example Usage

#### Example: Send an email notification when a specific export finishes
```php
add_action( 'sm_uci_pro_after_export', 'notify_after_export', 10, 2 );

function notify_after_export( $export_id, $exportObj ) {
    // Only trigger for export ID 3
    if ( $export_id == 3 ) {
        wp_mail(
            'admin@yoursite.com',
            'Export #3 Complete',
            'Your product export has finished successfully.'
        );
    }
}
```

---

### Key Things to Remember

| Aspect | Detail |
| :--- | :--- |
| **Fires Once at Completion** | Fires exactly once when the entire export process completes successfully. |
| **Complete File Availability** | The final compiled file (CSV, XML, XLS, etc.) is fully written and accessible at `$exportObj->options['filepath']`. |
| **WP All Export Parity** | Equivalent to WP All Export's `pmxe_after_export` action hook. |

---

## 3. After Iteration Action Hook

---

### `sm_uci_pro_after_iteration`

##### Description
This action hook fires automatically after each iteration (batch) during a cron-based/scheduled export. Unlike `sm_uci_pro_after_export` which fires once at the absolute end, this fires repeatedly — once per batch — allowing you to monitor or react to progress in real time.

##### How it works
```
Cron triggers scheduled export
       ↓
  Batch 1 runs → sm_uci_pro_after_iteration fires
       ↓
  Batch 2 runs → sm_uci_pro_after_iteration fires
       ↓
  Batch 3 runs → sm_uci_pro_after_iteration fires
       ↓
  Export finishes → sm_uci_pro_after_export fires
```

##### Parameters
* **`$export_id`** *(int)* *(Required)*
  The unique ID of the export template being executed.
* **`$exportObj`** *(object)* *(Required)*
  Full export object holding iteration options, filename, and file path parameters.
  * `$exportObj->options['iteration']` (int) - The current batch/iteration index (1-based).
  * `$exportObj->options['filepath']` (string) - Absolute path to the generated export file.
  * `$exportObj->options['filename']` (string) - The export template name.
  * `$exportObj->options['records']` (int) - The total row count exported.
  * `$exportObj->options['filesize']` (int) - The size of the generated export file in bytes.

##### Source
* **File:** `hooks/Export/Actions.php`
* **Applied in:**
  * `scheduleExtensions/ScheduleExport.php` (Cron scheduled exports per-batch completion)

---

### Example Usage

#### Example: Log progress after each batch iteration
```php
add_action( 'sm_uci_pro_after_iteration', 'log_export_iteration', 10, 2 );

function log_export_iteration( $export_id, $exportObj ) {
    if ( $export_id == 5 ) {
        $iteration = $exportObj->options['iteration'] ?? 'N/A';

        error_log( "Export #{$export_id} — Iteration {$iteration} completed at " . current_time('mysql') );
    }
}
```

---

### Key Things to Remember

| Aspect | Detail |
| :--- | :--- |
| **Fires Once Per Batch** | Fires at the end of every individual batch/iteration during a cron scheduled run. |
| **Ideal for Progress Monitoring** | Perfect for checking external conditions, logging iteration success, or tracking multi-batch progress. |
| **WP All Export Parity** | Equivalent to WP All Export's `pmxe_after_iteration` action hook. |

---

## 4. `sm_uci_pro_exported_post`

### Description
This action hook fires after each individual record (post) is written to the export file. It allows developers to execute row-level logic or post-processing on a per-record basis.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The unique ID of the record/post currently being written to the export file.
* **`$exportObj`** *(object)* *(Required)*
  Full export object holding current settings, module type, and export configuration.

##### Source
* **File:** `hooks/Export/Actions.php`
* **Applied in:**
  * `exportExtensions/ExportExtension.php` (After each record row has been written to the output stream)

---

### Example Usage

#### Example: Mark a post as exported by updating custom post metadata
```php
add_action( 'sm_uci_pro_exported_post', 'custom_mark_post_as_exported', 10, 2 );

function custom_mark_post_as_exported( $post_id, $exportObj ) {
    // Only perform for a specific export ID (e.g. Export #25)
    if ( $exportObj->id == 25 ) {
        update_post_meta( $post_id, '_last_exported_at', current_time( 'mysql' ) );
        update_post_meta( $post_id, '_is_exported', true );
    }
}
```

---

### Key Things to Remember

| Aspect | Detail |
| :--- | :--- |
| **Fires Per Row** | Executes for every single record in each batch of the export. Avoid expensive non-conditional tasks. |
| **WP All Export Parity** | Replaces and mirrors the behavior of `pmxe_exported_post`. |
| **Id Property Parity** | `$exportObj->id` is dynamically mapped to match WP All Export specifications. |