# WP Ultimate CSV Importer Pro - Custom Import Hooks Reference

This document provides a comprehensive technical reference for the custom action and filter hooks available in the **WP Ultimate CSV Importer Pro** plugin. To help developers quickly locate hooks, they are organized into four dedicated categories:

1. **Core and Post Import Hooks** (Lifecycle, custom fields, ACF, and FTP)
2. **User and Customer Import Hooks** (User registration and metadata)
3. **Taxonomy and Term Import Hooks** (Categories, tags, and hierarchies)
4. **Media and Attachment Import Hooks** (Images and file downloads)

---

## 1. Core and Post Import Hooks

Action and filter hooks related to the general import lifecycle, WordPress posts, custom post types, custom fields (meta), WooCommerce products/variations, and ACF integrations.

### Filter Hooks

#### `sm_uci_pro_resolve_import_value`

##### Description
Filters the resolved value for a single import field after the preserve-blank rule is applied in update mode. Unmapped or blank CSV values keep the existing stored value; mapped non-blank values use the CSV value.

##### Parameters
* **`$resolved`** *(mixed)* — Value after the built-in rule.
* **`$csv_value`** *(mixed)* — Raw CSV/mapped value for the row.
* **`$existing_value`** *(mixed)* — Value already stored on the target record.
* **`$is_mapped`** *(bool)* — Whether the field is mapped in the template.
* **`$field_key`** *(string)* — Field identifier (e.g. `post_title`, `PRODUCTSKU`).

##### Source
* **File:** `includes/ImportValueResolver.php`

---

### Action Hooks

#### `sm_uci_pro_before_import`

##### Description
Fires before any records are parsed or imported. Useful for setup operations, validating files, or triggering custom notifications at the start of an import session.

##### Parameters
* **`$import_id`** *(string)* *(Required)*
  The unique event hash key identifying this import configuration template.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_before_import', 'my_before_import_callback', 10, 1);

function my_before_import_callback($import_id) {
    // Log the start of the import session
    error_log("Import session started for configuration hash: " . $import_id);
}
```

---

#### `sm_uci_pro_saved_post`

##### Description
Fires immediately after a post, page, custom post type, or WooCommerce product is successfully saved (created or updated) in the database.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The ID of the saved post.
  * *Example value:* `45`
* **`$data`** *(array)* *(Required)*
  The fully mapped and processed data array used to populate the post.
  * *Example value:* `['post_title' => 'New Product', 'post_status' => 'publish', 'post_content' => 'Description...']`
* **`$is_update`** *(bool)* *(Required)*
  Whether the post was updated or newly inserted.
  * *Example value:* `true` (if updating), `false` (if creating)

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_saved_post', 'my_post_saved_callback', 10, 3);

function my_post_saved_callback($post_id, $data, $is_update) {
    if (!$is_update) {
        // Tag newly created posts with a custom meta identifier field
        update_post_meta($post_id, '_newly_imported_post', 'yes');
    }
}
```

---

#### `sm_uci_pro_update_post_meta`

##### Description
Fires immediately after a single custom field / post meta key-value pair is created, updated, or saved for any post during the import.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The ID of the post/object being imported.
  * *Example value:* `102`
* **`$meta_key`** *(string)* *(Required)*
  The custom field meta key being updated.
  * *Example value:* `'price'`
* **`$meta_value`** *(mixed)* *(Required)*
  The final raw value being saved to the database.
  * *Example value:* `'99.99'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_update_post_meta', 'my_meta_update_callback', 10, 3);

function my_meta_update_callback($post_id, $meta_key, $meta_value) {
    // If a custom price field is saved, update stock status accordingly
    if ($meta_key === 'price' && floatval($meta_value) <= 0.0) {
        update_post_meta($post_id, '_stock_status', 'outofstock');
    }
}
```

---

#### `sm_uci_pro_product_variation_saved`

##### Description
Fires after a WooCommerce product variation has been successfully created, updated, and saved during a product variation import.

##### Parameters
* **`$variation_id`** *(int)* *(Required)*
  The ID of the saved product variation.
  * *Example value:* `205`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_product_variation_saved', 'my_variation_saved_callback', 10, 1);

function my_variation_saved_callback($variation_id) {
    // Clear WooCommerce transients for the variation
    wc_delete_product_transients($variation_id);
}
```

---

#### `sm_uci_pro_after_import`

##### Description
Fires after the entire import process completes successfully. Provides details on row status, skipping, success rates, and the import file.

##### Parameters
* **`$import_id`** *(string)* *(Required)*
  The unique event hash key identifying this import configuration.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`
* **`$import_object`** *(object|array|null)* *(Optional)*
  An object containing details on records processed, remaining, failed, or skipped.
  * *Example value:*
    ```json
    {
      "id": 145,
      "file_name": "products.csv",
      "status": "Completed",
      "hash_key": "f25b6a3cfd7b2123d45ef6172bb4631e",
      "total_records": 100,
      "processing_records": 100,
      "remaining_records": 0,
      "failed": 2,
      "skipped": 5
    }
    ```

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_after_import', 'my_after_import_callback', 10, 2);

function my_after_import_callback($import_id, $import_object = null) {
    if ($import_object && $import_object->failed > 0) {
        // Send a custom Slack/email notification if failures occurred
        wp_mail('admin@example.com', 'Import Completed with Failures', "Import {$import_id} finished with {$import_object->failed} failures.");
    }
}
```

---

#### `sm_uci_before_post_create`

##### Description
Fires right before a new post is created in the database. Supports all custom post types, posts, pages, and WooCommerce products.

##### Parameters
* **`$post_data`** *(array)* *(Required)*
  The array of post fields that will be inserted.
  * *Example value:* `['post_title' => 'My Post', 'post_type' => 'post', 'post_status' => 'draft']`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_before_post_create', 'my_before_post_create_callback', 10, 1);

function my_before_post_create_callback($post_data) {
    // Enforce default post status to private for custom post types
    if (isset($post_data['post_type']) && $post_data['post_type'] === 'cpt_custom') {
        $post_data['post_status'] = 'private';
    }
}
```

---

#### `sm_uci_before_post_update`

##### Description
Fires right before an existing post is updated during the import pipeline.

##### Parameters
* **`$post_data`** *(array)* *(Required)*
  The array of post fields that are about to be updated. Contains the database `'ID'`.
  * *Example value:* `['ID' => 520, 'post_title' => 'Updated Post', 'post_type' => 'post']`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_before_post_update', 'my_before_post_update_callback', 10, 1);

function my_before_post_update_callback($post_data) {
    error_log("Updating Post ID " . $post_data['ID'] . " title to " . $post_data['post_title']);
}
```

---

#### `sm_uci_after_post_create`

##### Description
Fires immediately after a new post has been successfully inserted into the database.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The database ID of the newly created post.
  * *Example value:* `524`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_after_post_create', 'my_after_post_create_callback', 10, 1);

function my_after_post_create_callback($post_id) {
    // Generate static content or clear page caches
    error_log("Post ID {$post_id} was successfully created.");
}
```

---

#### `sm_uci_after_post_update`

##### Description
Fires immediately after an existing post has been updated.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The database ID of the updated post.
  * *Example value:* `524`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_after_post_update', 'my_after_post_update_callback', 10, 1);

function my_after_post_update_callback($post_id) {
    error_log("Post ID {$post_id} was successfully updated.");
}
```

---

### Filter Hooks

#### `sm_uci_pro_import_row_data`

##### Description
Allows developers to intercept and modify raw row data immediately before it's processed by the main import engine. This is useful for implementing custom data transformations, validations, or field manipulations on a per-row basis before the row is passed to `main_import_process()`.

##### Parameters
* **`$row_data`** *(array)* *(Required)*
  The raw parsed row data extracted from the import file.
  * Keys correspond to mapped column headers.
  * Values are the cell contents from the current row.
  * *Example value:* `['Product Name', '99.99', 'ABC123']`


##### Return
* **`array`** The modified row data array. Must be returned even if unchanged.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_import_row_data', 'my_before_import_row_filter', 10, 4);

function my_before_import_row_filter($row_data) {
   
   foreach($row_data as $key => $value){
    if($value ==='sku'){
      $row_data[$key] = 'SKU';
    }
   }
    
    return $row_data;
}
```

##### Additional Notes
- This filter fires **before** field mapping and main processing occurs.
- Modify the array keys and values freely—the returned data is passed directly to `main_import_process()`.
- Empty or falsy returns will cause the row to be skipped.
- Use this filter for data cleanup, validation, or transformation that applies across multiple fields.

---

#### `sm_uci_pro_acf_custom`

##### Description
Allows programmatically overriding or modifying Advanced Custom Fields (ACF) field values before they are validated and saved.

##### Parameters
* **`$value`** *(mixed)* *(Required)*
  The field value being imported.
  * *Example value:* `'custom_val'`
* **`$post_id`** *(int)* *(Required)*
  The ID of the post/object being imported.
  * *Example value:* `524`
* **`$name`** *(string)* *(Required)*
  The ACF field key name.
  * *Example value:* `'special_field'`

##### Return
* **`mixed`** The filtered custom field value.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_acf_custom', 'my_acf_custom_filter', 10, 3);

function my_acf_custom_filter($value, $post_id, $name) {
    if ($name === 'promo_code') {
        return strtoupper(trim($value));
    }
    return $value;
}
```

---

#### `sm_uci_pro_article_data`

##### Description
Allows developers to filter and modify core WordPress post fields (title, content, date, status, author) before any db transaction.

##### Parameters
* **`$articleData`** *(array)* *(Required)*
  The mapped core post field payload.
  * *Example value:* `['post_title' => 'My Product', 'post_status' => 'publish']`
* **`$import_id`** *(string)* *(Required)*
  The unique template hash ID.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`
* **`$post_to_update`** *(object|null)* *(Required)*
  The existing `WP_Post` object if performing an update; `null` if creating.
  * *Example value:* `get_post(520)` or `null`
* **`$current_record`** *(array)* *(Required)*
  The raw parsed row data for the current record.
  * *Example value:* `['Title' => 'My Product', 'SKU' => 'ABC']`

##### Return
* **`array`** The modified core post data array.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_article_data', 'my_article_data_filter', 10, 4);

function my_article_data_filter($articleData, $import_id, $post_to_update, $current_record) {
    // Append a custom suffix to the titles for imports running on a specific template
    if ($import_id === 'my_special_hash') {
        $articleData['post_title'] .= ' - Special Edition';
    }
    return $articleData;
}
```

---

#### `sm_uci_pro_custom_field`

##### Description
A centralized, highly powerful filter that intercepts post metadata (custom fields) updates. Fires for all standard, ACF, JetEngine, Pods, Meta Box, Toolset, CMB2, and native meta fields.

##### Parameters
* **`$value`** *(mixed)* *(Required)*
  The value being saved.
  * *Example value:* `'99.99'`
* **`$post_id`** *(int)* *(Required)*
  The ID of the post/object.
  * *Example value:* `102`
* **`$key`** *(string)* *(Required)*
  The custom field meta key.
  * *Example value:* `'price'`
* **`$original_value`** *(mixed)* *(Required)*
  The original, unprocessed value from the import file.
  * *Example value:* `'$99.99'`
* **`$existing_meta_keys`** *(array)* *(Required)*
  List of existing meta keys for this post.
  * *Example value:* `['price', '_sku', '_stock']`
* **`$import_id`** *(string)* *(Required)*
  The unique template hash ID.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`mixed`** The filtered custom field value.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_custom_field', 'my_custom_field_filter', 10, 6);

function my_custom_field_filter($value, $post_id, $key, $original, $existing, $import_id) {
    // Clean currency symbols from numeric price custom fields
    if ($key === 'price') {
        return floatval(str_replace(['$', ','], '', $value));
    }
    return $value;
}
```

---

#### `sm_uci_import_is_post_to_update`

##### Description
Fired before an existing post is updated. Returning `false` skips updating the post, leaving its current data unchanged.

##### Parameters
* **`$continue`** *(bool)* *(Required)*
  Whether to proceed with the update. Default: `true`
* **`$post_id`** *(int)* *(Required)*
  The ID of the existing post about to be updated.
  * *Example value:* `524`
* **`$current_node`** *(array)* *(Required)*
  Parsed record fields.
  * *Example value:* `['post_title' => 'Updated Product']`
* **`$import_id`** *(int|string)* *(Required)*
  The unique import template configuration hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`bool`** `true` to update the post; `false` to skip it.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_import_is_post_to_update', 'my_post_to_update_filter', 10, 4);

function my_post_to_update_filter($continue, $post_id, $current_node, $import_id) {
    // Do not update posts that are currently flagged as "Featured" on the site
    if (get_post_meta($post_id, '_is_featured', true) === 'yes') {
        return false;
    }
    return $continue;
}
```

---

#### `sm_uci_pro_is_post_to_create`

##### Description
Fired before a new post is created. Returning `false` skips importing the row as a new post.

##### Parameters
* **`$continue`** *(bool)* *(Required)*
  Whether to proceed with post creation. Default: `true`
* **`$current_node`** *(array)* *(Required)*
  Parsed record fields.
  * *Example value:* `['post_title' => 'My Product Name']`
* **`$import_id`** *(int|string)* *(Required)*
  The unique import template configuration hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`bool`** `true` to create the post; `false` to skip it.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_is_post_to_create', 'my_post_to_create_filter', 10, 3);

function my_post_to_create_filter($continue, $current_node, $import_id) {
    // Skip importing products that have an empty title
    if (empty($current_node['post_title'])) {
        return false;
    }
    return $continue;
}
```

---

#### `sm_uci_pro_import_is_check_duplicates`

##### Description
Controls whether duplicate checking is enabled or disabled for a specific import. When disabled, the importer always creates new records instead of checking if they already exist in the database.

##### Parameters
* **`$is_check_duplicates`** *(bool)* *(Required)*
  Whether to check for duplicates. Default: `true`
* **`$import_id`** *(string)* *(Required)*
  The unique import template configuration hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`
* **`$type`** *(string)* *(Required)*
  The post type or content type being imported.
  * *Example value:* `'WooCommerce Product'` or `'post'`
* **`$post_type`** *(string)* *(Required)*
  The WordPress post type (from the database perspective).
  * *Example value:* `'product'` or `'product_variation'`

##### Return
* **`bool`** `true` to check for duplicates (default behavior); `false` to skip duplicate checking and always create new records.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_import_is_check_duplicates', 'my_is_check_duplicates_filter', 10, 4);

function my_is_check_duplicates_filter($is_check_duplicates, $import_id, $type, $post_type) {
    // Disable duplicate checking for this specific import — always create new records
    if ($import_id === 'daily_product_feed_hash') {
        return false;
    }
    
    // For all other imports, keep default duplicate checking enabled
    return $is_check_duplicates;
}
```

##### Practical Scenarios
* **Daily product feed** — every CSV row is a new entry, disable duplicate checking: `return false;`
* **Event log import** — each row represents a unique event, disable duplicate checking: `return false;`
* **Production store** — never want duplicate products, keep enabled: `return true;`
* **Staging environment** — often want fresh data on each import run, disable: `return false;`

##### Key Behavior
* When `true` (default): The importer checks if a record already exists (by ID, SKU, title, etc.) and updates it if found, or creates a new one if not.
* When `false`: The importer skips all duplicate checks and always inserts new records, potentially creating duplicates if you re-run the same import.

---

#### `sm_uci_pro_ftp_root`

##### Description
Allows changing the base remote root directory for FTP, FTPS, or SFTP uploads and remote image downloads on a per-import basis.

##### Parameters
* **`$root`** *(string)* *(Required)*
  The starting root directory path. Default: `'/'`
* **`$import_id`** *(string)* *(Required)*
  The unique configuration template hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`string`** The modified remote root path.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_ftp_root', 'my_ftp_root_filter', 10, 2);

function my_ftp_root_filter($root, $import_id) {
    // If importing from Client B, point the FTP client base folder directly to their subfolder
    if ($import_id === 'client_b_hash_key') {
        return '/home/client_b/public_ftp/';
    }
    return $root;
}
```

---

#### `sm_uci_afterpost_import`

##### Description
Fires after a post, page, or custom post type (including custom taxonomy types) is successfully imported. Provides the post ID, operation mode, and post type to help developers identify what was imported.

##### Parameters
* **`$post_id`** *(int|string)* *(Required)*
  The ID of the imported post.
  * *Example value:* `524`
* **`$mode`** *(string)* *(Required)*
  The operation mode: `'Insert'` for new posts, `'Update'` for existing posts.
  * *Example value:* `'Insert'` or `'Update'`
* **`$type`** *(string)* *(Required)*
  The post type being imported. Supports: `'post'`, `'page'`, WooCommerce product types, custom post types, or custom taxonomy types.
  * *Example value:* `'post'`, `'page'`, `'product'`, or any custom post type slug

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_afterpost_import', 'my_after_post_import_callback', 10, 3);

function my_after_post_import_callback($post_id, $mode, $type) {
    // Log all imported posts by type
    error_log("[$mode] Imported {$type} with ID: {$post_id}");
    
    // Trigger custom actions based on post type
    if ($type === 'product') {
        // Update WooCommerce inventory cache
        wc_delete_product_transients($post_id);
    } elseif ($type === 'post') {
        // Regenerate featured image thumbnails for blog posts
        if (has_post_thumbnail($post_id)) {
            wp_update_attachment_metadata(get_post_thumbnail_id($post_id), wp_generate_attachment_metadata(get_post_thumbnail_id($post_id), get_attached_file(get_post_thumbnail_id($post_id))));
        }
    }
}
```

---


#### `sm_uci_pro_after_woocommerce_import`

##### Description
Fires after a WooCommerce product or product variation is successfully imported. Provides the product ID, operation mode, and product type (simple, variable, variation, etc.) to help developers perform WooCommerce-specific post-import tasks.

##### Parameters
* **`$product_id`** *(int|string)* *(Required)*
  The ID of the imported WooCommerce product or variation.
  * *Example value:* `315`
* **`$mode`** *(string)* *(Required)*
  The operation mode: `'Insert'` for new products, `'Update'` for existing products.
  * *Example value:* `'Insert'` or `'Update'`
* **`$type`** *(string)* *(Required)*
  The WooCommerce product type. Common values: `'simple'`, `'variable'`, `'variation'`, `'grouped'`, `'external'`, `'bundle'`, etc.
  * *Example value:* `'simple'`, `'variable'`, `'variation'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_after_woocommerce_import', 'my_after_woocommerce_import_callback', 10, 3);

function my_after_woocommerce_import_callback($product_id, $mode, $type) {
    // Regenerate product data and clear caches
    $product = wc_get_product($product_id);
    
    if ($product) {
        // Clear transients
        wc_delete_product_transients($product_id);
        
        // Update search indices if new product
        if ($mode === 'Insert') {
            do_action('woocommerce_product_set_stock', $product);
        }
        
        // Handle variable product logic
        if ($type === 'variable') {
            $product->update_attributes();
        }
        
        // Log imported products
        error_log("[$mode] Imported WooCommerce {$type} product with ID: {$product_id}");
    }
}
```

---



Action and filter hooks related to user insertion, WooCommerce customer synchronization, ProfilePress metadata, and validation payloads.

---
## 2. User and Customer Import Hooks

#### `sm_uci_pro_after_user_import_complete`

##### Description
Fires after a user, WooCommerce customer, or ProfilePress user is successfully imported. Provides the user ID, operation mode, and user type to help developers respond to user creation or updates with extended context.

##### Parameters
* **`$user_id`** *(int|string)* *(Required)*
  The ID of the imported user.
  * *Example value:* `23`
* **`$mode`** *(string)* *(Required)*
  The operation mode: `'Insert'` for new users, `'Update'` for existing users.
  * *Example value:* `'Insert'` or `'Update'`
* **`$type`** *(string)* *(Optional)*
  The user type being imported. Default: `'user'`. Can be `'user'`, `'customer'`, `'profilepress_user'`, or other integrated user types.
  * *Example value:* `'user'`, `'customer'`, `'profilepress_user'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_after_user_import_complete', 'my_user_import_complete_callback', 10, 3);

function my_user_import_complete_callback($user_id, $mode, $type) {
    // Create welcome email template based on user type
    $user = get_user_by('id', $user_id);
    
    if ($type === 'customer' && $mode === 'Insert') {
        // Send WooCommerce welcome email to new customers
        WC()->mailer();
        do_action('woocommerce_new_customer_email_notification', $user_id);
    } elseif ($type === 'user' && $mode === 'Insert') {
        // Send welcome email to new users
        wp_mail($user->user_email, 'Welcome!', "Welcome to our site, {$user->user_login}");
    }
}
```

---

### Action Hooks

#### `sm_uci_pro_before_user_import`

##### Description
Fires before a user, WooCommerce customer, or ProfilePress user record is created or updated in the database.

##### Parameters
* **`$data_array`** *(array)* *(Required)*
  The user data array being processed.
  * *Example value:* `['user_login' => 'john_doe', 'user_email' => 'john@example.com']`
* **`$mode`** *(string)* *(Required)*
  The operational mode of the import: `'Insert'` or `'Update'`.
  * *Example value:* `'Insert'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_before_user_import', 'my_before_user_import_callback', 10, 2);

function my_before_user_import_callback($data_array, $mode) {
    if ($mode === 'Insert' && empty($data_array['user_pass'])) {
        // Enforce user password rules for new users
        $data_array['user_pass'] = wp_generate_password();
    }
}
```

---

#### `sm_uci_pro_after_user_import`

##### Description
Fires after a user, WooCommerce customer, or ProfilePress user record has been successfully saved to the database.

##### Parameters
* **`$user_id`** *(int)* *(Required)*
  The database user ID of the saved record.
  * *Example value:* `23`
* **`$data_array`** *(array)* *(Required)*
  The user data fields imported.
  * *Example value:* `['user_login' => 'john_doe', 'user_email' => 'john@example.com']`
* **`$mode_of_affect`** *(string)* *(Required)*
  The type of operation performed: `'Inserted'` or `'Updated'`.
  * *Example value:* `'Inserted'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_after_user_import', 'my_after_user_import_callback', 10, 3);

function my_after_user_import_callback($user_id, $data_array, $mode_of_affect) {
    if ($mode_of_affect === 'Inserted') {
        // Trigger default password reset emails for new users
        retrieve_password($data_array['user_login']);
    }
}
```

---

### Filter Hooks

#### `sm_uci_pro_is_user_to_create`

##### Description
Determines whether a user, WooCommerce customer, or ProfilePress user record should be created or updated. Returning `false` skips the row.

##### Parameters
* **`$continue`** *(bool)* *(Required)*
  Whether to proceed with user creation/update. Default: `true`
* **`$data_array`** *(array)* *(Required)*
  Parsed user details array.
  * *Example value:* `['user_email' => 'john@example.com', 'user_login' => 'john_doe']`
* **`$unikey_value`** *(string)* *(Required)*
  The unique key identifier for the current record.
  * *Example value:* `'john@example.com'`

##### Return
* **`bool`** `true` to proceed; `false` to skip the record.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_is_user_to_create', 'my_user_to_create_filter', 10, 3);

function my_user_to_create_filter($continue, $data_array, $unikey_value) {
    // Block imports for users using temp/disposable email addresses
    if (strpos($data_array['user_email'], '@mailinator.com') !== false) {
        return false;
    }
    return $continue;
}
```

---

#### `sm_uci_pro_user_data`

##### Description
Allows programmatically filtering, validating, and updating the mapped payload array for any user before they are inserted or updated.

##### Parameters
* **`$data_array`** *(array)* *(Required)*
  The mapped payload of user columns.
  * *Example value:* `['first_name' => 'John', 'role' => 'subscriber', 'user_pass' => '...']`
* **`$unikey_value`** *(string)* *(Required)*
  The unique key identifier for the current record.
  * *Example value:* `'john@example.com'`

##### Return
* **`array`** The modified user payload array.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_user_data', 'my_user_data_filter', 10, 2);

function my_user_data_filter($data_array, $unikey_value) {
    // Ensure all user first names are properly capitalized
    if (!empty($data_array['first_name'])) {
        $data_array['first_name'] = ucfirst(strtolower($data_array['first_name']));
    }
    return $data_array;
}
```

---

## 3. Taxonomy and Term Import Hooks

Filter hooks related to taxonomy hierarchy mapping, terms attachment, and existence queries during taxonomy imports.

---

### Filter Hooks

#### `sm_uci_pro_single_category`

##### Description
Allows modifying term characteristics (name, parent, assign state) before terms are matched, created, or assigned to a post.

##### Parameters
* **`$term_into`** *(array)* *(Required)*
  An array containing term characteristics:
  * **`name`** *(string)* The name of the term. Example: `'Electronics'`
  * **`parent`** *(mixed)* The parent term name or ID. Example: `'Gadgets'`
  * **`assign`** *(bool)* Set to `false` to skip importing/assigning this term.
  * **`is_mapping`** *(string|int)* Whether term mapping is enabled.
  * **`hierarchy_level`** *(int)* Depth in hierarchy.
  * **`max_hierarchy_level`** *(int)* Max depth.
* **`$tax_name`** *(string)* *(Required)*
  The taxonomy name.
  * *Example value:* `'product_cat'`

##### Return
* **`array`** The modified term configuration array.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_single_category', 'my_single_category_filter', 10, 2);

function my_single_category_filter($term_into, $tax_name) {
    // Ignore and skip assigning draft terms
    if ($tax_name === 'category' && strpos($term_into['name'], 'Draft') !== false) {
        $term_into['assign'] = false;
    }
    return $term_into;
}
```

---

#### `sm_uci_pro_setpost_terms`

##### Description
Allows developers to intercept, modify, add, or replace the term taxonomy IDs (or names) about to be assigned to a post.

##### Parameters
* **`$term_taxonomy_ids`** *(array)* *(Required)*
  Array of term taxonomy IDs or names/slugs about to be assigned.
  * *Example value:* `[82, 83]`
* **`$tx_name`** *(string)* *(Required)*
  The taxonomy being updated.
  * *Example value:* `'product_brand'`
* **`$pid`** *(int)* *(Required)*
  The ID of the post being modified.
  * *Example value:* `621`
* **`$import_id`** *(string)* *(Required)*
  The unique template configuration hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`array`** The filtered array of term identifiers to apply.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_setpost_terms', 'my_setpost_terms_filter', 10, 4);

function my_setpost_terms_filter($term_taxonomy_ids, $tx_name, $pid, $import_id) {
    // Automatically inject a default category if the post ends up with no terms
    if ($tx_name === 'category' && empty($term_taxonomy_ids)) {
        $default_term = get_term_by('slug', 'uncategorized', 'category');
        if ($default_term) {
            $term_taxonomy_ids[] = $default_term->term_taxonomy_id;
        }
    }
    return $term_taxonomy_ids;
}
```

---

#### `sm_uci_pro_term_exists`

##### Description
Intercepts checks determining whether a taxonomy term exists before creating it. Overrides the lookup value to implement synonym aliases, case-insensitivity toggles, or force creation.

##### Parameters
* **`$term_exists`** *(mixed)* *(Required)*
  What core `term_exists()` returned. `null` or `0` if not found; `term_id` (integer) or array containing `'term_id'` and `'term_taxonomy_id'` keys if found.
  * *Example value:* `['term_id' => 82, 'term_taxonomy_id' => 82]` or `null`
* **`$taxonomy`** *(string)* *(Required)*
  The target taxonomy.
  * *Example value:* `'product_brand'`
* **`$term`** *(string)* *(Required)*
  The term name, slug, or ID being queried.
  * *Example value:* `'Apple'`
* **`$parent`** *(int)* *(Required)*
  The parent term ID; `0` if none.
  * *Example value:* `0`

##### Return
* **`mixed`** `null` or `0` if not found; an integer or array with `term_id` and `term_taxonomy_id` if found.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_term_exists', 'my_term_exists_filter', 10, 4);

function my_term_exists_filter($term_exists, $taxonomy, $term, $parent) {
    // If the term was not located, look up matching synonyms or aliases
    if (!$term_exists) {
        $synonyms = [
            'Tees' => 'T-Shirts',
            'Mobiles' => 'Smartphones'
        ];
        
        if (isset($synonyms[$term])) {
            return term_exists($synonyms[$term], $taxonomy, $parent);
        }
    }
    return $term_exists;
}
```

---

### Action Hooks

#### `sn_uci_pro_after_taxonomy_import`

##### Description
Fires after a taxonomy term (category, tag, or custom taxonomy) is successfully imported. Provides the term ID, operation mode, and taxonomy name to help developers update associated indices or caches.

##### Parameters
* **`$term_id`** *(int|string)* *(Required)*
  The ID of the imported taxonomy term.
  * *Example value:* `42`
* **`$mode`** *(string)* *(Required)*
  The operation mode: `'Insert'` for new terms, `'Update'` for existing terms.
  * *Example value:* `'Insert'` or `'Update'`
* **`$type`** *(string)* *(Required)*
  The taxonomy name. Examples: `'category'`, `'post_tag'`, `'product_cat'`, `'product_brand'`, or any custom taxonomy slug.
  * *Example value:* `'category'`, `'product_cat'`, or custom taxonomy name

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sn_uci_pro_after_taxonomy_import', 'my_after_taxonomy_import_callback', 10, 3);

function my_after_taxonomy_import_callback($term_id, $mode, $type) {
    // Update category counts for search indices
    if ($type === 'category' || $type === 'post_tag') {
        wp_update_term_count_now([$term_id], $type);
    }
    
    // Clear term-specific caches
    clean_term_cache($term_id, $type);
    
    // Log imported taxonomies
    error_log("[$mode] Imported {$type} term with ID: {$term_id}");
}
```

---

## 4. Media and Attachment Import Hooks

Action and filter hooks related to media files, image downloading, attachment registration, and folder routing.

---

### Action Hooks

#### `sm_uci_pro_gallery_image`

##### Description
Fires each time an image (featured image or gallery image attachment) is downloaded, registered, and successfully assigned to a post.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The ID of the post/object the image was assigned to.
  * *Example value:* `102`
* **`$att_id`** *(int)* *(Required)*
  The ID of the newly assigned image attachment in the Media Library.
  * *Example value:* `422`
* **`$filepath`** *(string)* *(Required)*
  The local server path to the downloaded image file.
  * *Example value:* `'/var/www/html/wp-content/uploads/2026/05/watch.jpg'`
* **`$is_keep_existing_images`** *(bool)* *(Required)*
  Whether existing gallery images were preserved during the import.
  * *Example value:* `true`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_gallery_image', 'my_gallery_image_callback', 10, 4);

function my_gallery_image_callback($post_id, $att_id, $filepath, $is_keep_existing) {
    // Perform custom image optimization or metadata updates upon assignment
    update_post_meta($att_id, '_imported_via_connector', 'yes');
}
```

---

#### `sm_uci_pro_attachment_uploaded`

##### Description
Fires when a non-image attachment (e.g. PDF, ZIP document) is successfully uploaded and registered in the Media Library during import.

##### Parameters
* **`$post_id`** *(int)* *(Required)*
  The ID of the parent post/object.
  * *Example value:* `102`
* **`$att_id`** *(int)* *(Required)*
  The ID of the newly created attachment post.
  * *Example value:* `423`
* **`$filepath`** *(string)* *(Required)*
  The absolute server path to the uploaded file.
  * *Example value:* `'/var/www/html/wp-content/uploads/2026/05/datasheet.pdf'`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_attachment_uploaded', 'my_attachment_uploaded_callback', 10, 3);

function my_attachment_uploaded_callback($post_id, $att_id, $filepath) {
    error_log("Attachment ID {$att_id} uploaded to Post ID {$post_id} at: {$filepath}");
}
```

---

#### `sm_uci_pro_import_failed`

##### Description
Fires when an import error or critical exception is caught, such as a remote media download failure, broken connection, or file corruption.

##### Parameters
* **`$error`** *(\WP_Error)* *(Required)*
  A WordPress error object detailing the failure type, code, and debugging message.
  * *Example value:* `new \WP_Error('import_failed', 'Media failed to import: http://...')`

##### Source
* **File:** `hooks/Import/Actions.php`

##### Example Usage
```php
add_action('sm_uci_pro_import_failed', 'my_import_failed_callback', 10, 1);

function my_import_failed_callback($error) {
    error_log("IMPORT ERROR [{$error->get_error_code()}]: " . $error->get_error_message());
}
```

---

### Filter Hooks

#### `sm_uci_pro_is_images_to_update`

##### Description
Controls whether media downloads and image attachments should run for the current record.

##### Parameters
* **`$is_images_to_update`** *(bool)* *(Required)*
  Whether to import/update images. Default: `true`
* **`$articleData`** *(array)* *(Required)*
  Core post data.
  * *Example value:* `['post_title' => 'Watch', 'post_type' => 'post']`
* **`$current_process_record_data`** *(array)* *(Required)*
  Parsed import fields for the row.
  * *Example value:* `['ImageURL' => 'http://...']`
* **`$post_id`** *(int)* *(Required)*
  The ID of the post being updated.
  * *Example value:* `102`

##### Return
* **`bool`** `true` to import/update images; `false` to skip.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_is_images_to_update', 'my_images_update_filter', 10, 4);

function my_images_update_filter($is_update, $articleData, $xml_node, $post_id) {
    // If the post already has a featured image, skip downloading images
    if (has_post_thumbnail($post_id)) {
        return false;
    }
    return $is_update;
}
```

---

#### `sm_uci_pro_is_attachments_to_update`

##### Description
Controls whether documents or non-image file attachments should be updated/uploaded for the current record.

##### Parameters
* **`$is_to_update`** *(bool)* *(Required)*
  Whether to import/update attachments. Default: `true`
* **`$articleData`** *(array)* *(Required)*
  Core post data.
  * *Example value:* `['post_title' => 'Product Manual']`
* **`$current_xml_node`** *(array)* *(Required)*
  Parsed import fields for the row.
  * *Example value:* `['AttachmentURL' => 'http://...']`

##### Return
* **`bool`** `true` to import/update attachments; `false` to skip.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_is_attachments_to_update', 'my_attachments_update_filter', 10, 3);

function my_attachments_update_filter($is_to_update, $articleData, $current_xml_node) {
    // Skip attachment downloads for out-of-stock items
    if (isset($current_xml_node['StockStatus']) && $current_xml_node['StockStatus'] === 'outofstock') {
        return false;
    }
    return $is_to_update;
}
```

---

#### `sm_uci_pro__attachments_uploads_dir`

##### Description
Enables dynamic routing of imported attachments and images to a custom directory on your server instead of the default WP uploads directory structure.

##### Parameters
* **`$uploads`** *(array)* *(Required)*
  Directory information array (comparable to `wp_upload_dir()`):
  * **`path`** *(string)* Path to save file. Example: `'/var/www/html/wp-content/uploads/2026/05'`
  * **`url`** *(string)* File URL. Example: `'http://example.com/wp-content/uploads/2026/05'`
  * **`subdir`** *(string)* Subfolder. Example: `'/2026/05'`
  * **`basedir`** *(string)* Base uploads path. Example: `'/var/www/html/wp-content/uploads'`
  * **`baseurl`** *(string)* Base uploads URL. Example: `'http://example.com/wp-content/uploads'`
  * **`error`** *(bool)* Error indicator. Example: `false`
* **`$articleData`** *(array)* *(Required)*
  Mapped post data.
  * *Example value:* `['post_type' => 'product']`
* **`$current_node`** *(array)* *(Required)*
  Parsed record fields.
  * *Example value:* `['ImageURL' => 'http://...']`
* **`$import_id`** *(string|int)* *(Required)*
  The unique template configuration hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`

##### Return
* **`array`** The modified uploads directory details array.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro__attachments_uploads_dir', 'my_attachments_uploads_dir_filter', 10, 4);

function my_attachments_uploads_dir_filter($uploads, $articleData, $current_node, $import_id) {
    // Route image uploads to a dedicated 'products' folder instead of standard year/month folders
    $uploads['path']   = $uploads['basedir'] . '/products';
    $uploads['url']    = $uploads['baseurl'] . '/products';
    $uploads['subdir'] = '/products';
    return $uploads;
}
```

---

#### `sm_uci_pro_get_image_from_gallery`

##### Description
Allows intercepting and modifying the matched media attachment post when using the **"Use Existing Image"** matching mode. Returning `null` forces a new download.

##### Parameters
* **`$attach`** *(\WP_Post|null)* *(Required)*
  The matched media attachment post object, or `null` if no match was located.
  * *Example value:* `get_post(422)` or `null`
* **`$image_name`** *(string)* *(Required)*
  The filename search target.
  * *Example value:* `'product-shoe.jpg'`
* **`$target_dir`** *(string)* *(Required)*
  The absolute target upload directory.
  * *Example value:* `'/var/www/html/wp-content/uploads/2026/05'`

##### Return
* **`\WP_Post|null`** The selected attachment object, or `null`.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_get_image_from_gallery', 'my_get_image_from_gallery_filter', 10, 3);

function my_get_image_from_gallery_filter($attach, $image_name, $target_dir) {
    // Swap placeholder matches with a global fallback image
    if ($attach && strpos($image_name, 'placeholder') !== false) {
        $fallback = get_post(99); // Global placeholder image attachment ID
        if ($fallback) {
            return $fallback;
        }
    }
    return $attach;
}
```

---

#### `sm_uci_pro_handle_upload`

##### Description
Intercepts the file details immediately after downloading to disk, before it is registered in the WordPress Media Library. Useful for security scanning, type correction, or custom moves.

##### Parameters
* **`$file`** *(array)* *(Required)*
  File download payload:
  * **`file`** *(string)* Absolute server path to downloaded file. Example: `'/var/www/html/wp-content/uploads/custom-import/shoe.jpg'`
  * **`url`** *(string)* File URL. Example: `'http://example.com/wp-content/uploads/custom-import/shoe.jpg'`
  * **`type`** *(string)* MIME type. Example: `'image/jpeg'`

##### Return
* **`array`** The modified file details array.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_handle_upload', 'my_handle_upload_filter', 10, 1);

function my_handle_upload_filter($file) {
    // Move downloads to a secure directory outside the monthly folder
    $custom_dir = WP_CONTENT_DIR . '/uploads/secured-docs/';
    $custom_url = content_url('/uploads/secured-docs/');
    
    if (!file_exists($custom_dir)) {
        wp_mkdir_p($custom_dir);
    }
    
    if (isset($file['file'])) {
        $filename = basename($file['file']);
        $new_path = $custom_dir . $filename;
        if (rename($file['file'], $new_path)) {
            $file['file'] = $new_path;
            $file['url']  = $custom_url . $filename;
        }
    }
    return $file;
}
```

---

#### `sm_uci_pro_image_filename`

##### Description
Enables dynamic renaming of images right before they are downloaded to the server during core posts or WooCommerce product imports.

##### Parameters
* **`$filename`** *(string)* *(Required)*
  The derived target filename.
  * *Example value:* `'12345_randomhash.jpg'`
* **`$img_title`** *(string)* *(Required)*
  Mapped image title.
  * *Example value:* `'Nike Shoes'`
* **`$img_caption`** *(string)* *(Required)*
  Mapped caption.
  * *Example value:* `'A pair of red shoes'`
* **`$img_alt`** *(string)* *(Required)*
  Mapped alt text.
  * *Example value:* `'Nike Shoes Red'`
* **`$articleData`** *(array)* *(Required)*
  Current mapped record columns.
  * *Example value:* `['sku' => 'NK-123', 'post_title' => 'Nike Shoe']`
* **`$import_id`** *(string)* *(Required)*
  The unique configuration template hash.
  * *Example value:* `'f25b6a3cfd7b2123d45ef6172bb4631e'`
* **`$img_url`** *(string)* *(Required)*
  The original source URL.
  * *Example value:* `'http://external.com/nike.jpg'`

##### Return
* **`string`** The customized, sanitized filename.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_image_filename', 'my_image_filename_filter', 10, 7);

function my_image_filename_filter($filename, $img_title, $img_caption, $img_alt, $articleData, $import_id, $img_url) {
    // Standardize file name format using the product SKU
    if (isset($articleData['sku']) && !empty($articleData['sku'])) {
        $ext = pathinfo($img_url, PATHINFO_EXTENSION);
        if (empty($ext)) {
            $ext = 'jpg';
        }
        return sanitize_title($articleData['sku']) . '.' . $ext;
    }
    return $filename;
}
```

---

#### `sm_uci_pro_api_image_filename`

##### Description
Works exactly like `sm_uci_pro_image_filename` but targets non-featured images imported via Add-Ons (ACF images, WooCommerce gallery, JetEngine, custom meta fields).

##### Parameters
* **`$image_name`** *(string)* *(Required)*
  The derived target filename.
  * *Example value:* `'img_xh29sk.jpg'`
* **`$img_url`** *(string)* *(Required)*
  The original source URL.
  * *Example value:* `'http://external.com/nike.jpg'`
* **`$pid`** *(int)* *(Required)*
  The ID of the parent post the image is being attached to.
  * *Example value:* `102`

##### Return
* **`string`** The customized, sanitized filename.

##### Source
* **File:** `hooks/Import/Filters.php`

##### Example Usage
```php
add_filter('sm_uci_pro_api_image_filename', 'my_api_image_filename_filter', 10, 3);

function my_api_image_filename_filter($image_name, $img_url, $pid) {
    $post = get_post($pid);
    if ($post) {
        $ext = pathinfo($img_url, PATHINFO_EXTENSION);
        if (empty($ext)) {
            $ext = 'jpg';
        }
        // Rename with the post slug and a short hash of the image URL
        return sanitize_title($post->post_name) . '-' . substr(md5($img_url), 0, 6) . '.' . $ext;
    }
    return $image_name;
}
```

---

## WooCommerce Native CSV Compatibility

These filters extend the WooCommerce-native product CSV adapter (`compatibility/WooCommerceNative/`).

#### `sm_uci_pro_wc_native_header_map`

Alter the WooCommerce English header → Smack field key map.

```php
add_filter( 'sm_uci_pro_wc_native_header_map', function( $map ) {
    $map['Custom Header'] = 'my_smack_field';
    return $map;
} );
```

#### `sm_uci_pro_wc_native_detect`

Override format detection (`woocommerce_native` or `legacy`).

```php
add_filter( 'sm_uci_pro_wc_native_detect', function( $format, $headers ) {
    return $format;
}, 10, 2 );
```

#### `sm_uci_pro_wc_native_row`

Filter a converted Smack row after WC-native import conversion.

```php
add_filter( 'sm_uci_pro_wc_native_row', function( $smack_row, $wc_row ) {
    return $smack_row;
}, 10, 2 );
```

#### `sm_uci_pro_wc_native_export_row`

Filter a WooCommerce-native export row before CSV write.

```php
add_filter( 'sm_uci_pro_wc_native_export_row', function( $wc_row, $smack_row ) {
    return $wc_row;
}, 10, 2 );
```

### Export option

Product exports accept `csv_format`:

- `woocommerce_native` — WC-compatible headers/values (opt-in via Product CSV format)
- `legacy` — default; Smackcoders field mapping format (schedules without format also use legacy)
- `legacy` — Smackcoders proprietary headers (default for scheduled exports when format is unset)

Pass via POST `csv_format` or `conditions.csv_format.format`.
