# WP Ultimate CSV Importer Pro

Seamlessly create and update posts, custom posts, pages, products, media, SEO content, and premium plugin data from CSV with scheduled import and export support.

**Current Version:** 9.0  
**Requires PHP:** 7.4  
**Author:** [Smackcoders](https://www.smackcoders.com)

## Documentation

- [Product Page](https://www.smackcoders.com/wp-ultimate-csv-importer-pro.html)
- [Documentation](https://www.smackcoders.com/documentation/wp-ultimate-csv-importer-pro)
- [Live Demo](https://demo.smackcoders.com/wordpress/wp-admin/)
- [Private Trial](https://trial.smackcoders.com/index.html)

## Changelog

### 9.0

#### New Features

- Added: Feature Modules registry and toggle settings so optional modules can be disabled with zero runtime overhead #1442
- Added: Dependency manager and onboarding flow for Pro plugin requirements #1420
- Added: Complete The Events Calendar Pro import and export support #1439
- Added: WooCommerce built-in import/export compatibility support #1434
- Added: YIKES WooCommerce Product Tabs import and export support #26764
- Added: Bulk image file export with ZIP download option #26758
- Added: SureCart variant support, WooCommerce-to-SureCart migration improvements, and SureCart/WordPress ID cross-resolution in export workflows #1444
- Added: Support section UI for promoting other Pro plugins #1445

#### Enhancements

- Improved: Import performance — approximately 37.5% faster batch times vs 8.15.5 #1442
- Improved: Feature modules default OFF on fresh installs to reduce unused runtime cost #1442
- Improved: Export and media hardening with AI module gating #1442
- Enhanced: WooCommerce product gallery import to support multiple mapped image columns #26753
- Improved: Auto-map WooCommerce product attribute fields when CSV headers match #1418
- Improved: UI consistency across primary color, Need Help, and Spreadsheet sections #1437
- Modernized: Import Each Record section with a responsive design #445
- Improved: Support and Header section UI alignment and content #1445

#### Security

- Hardened: AJAX authorization, nonce handling, and import workflows; remediated CVE-2026-13353 related vulnerabilities #438
- Fixed: SQL injection vulnerability and hardened database queries #1443

#### Bug Fixes

- Fixed: Custom Fields Mapping section UI issues and responsiveness #1409
- Fixed: Dashboard record count calculation and display #1425
- Fixed: Mapping section UI and functionality in Import and Manager tabs #1430
- Fixed: Google Sheets published URL upload from URL
- Fixed: CPT/ACF export hang after the first post in a batch #25652
- Fixed: Meta Box custom fields export issue #26819
- Fixed: Media Remote Upload import issue #26819
- Fixed: Product tags not removed on blank import #26817
- Fixed: Export failure for specific custom post types #26846
- Fixed: Smart Schedule cron execution remaining in pending state #26831
- Fixed: Scheduled import and header manipulation issues #26831
- Fixed: WooCommerce product brand update issue during import #26853
- Fixed: Meta Box group cloneable field export truncation issue
- Fixed: Rank Math Dataset schema auto generation during import #26877
- Fixed: ACF field value import and import summary log issues #26877
- Fixed: WooCommerce product image and gallery import issue #26926
- Fixed: Release QA issues and improved plugin stability #1443

### 8.16

#### New Features

- Added: Bricks Builder complete Import and Export support #1240
- Added: Oxygen Builder complete Import and Export support #1239
- Added: Centralized hook architecture with WP All Import parity via HooksHandler singleton #1333
- Added: Import action and filter hooks across all import flows #1330
- Added: Export action hooks for extensible export workflows
- Added: Export filter hooks for WooCommerce, Posts, Taxonomy Terms, Comments, and WPML fields
- Added: Export data manipulation hooks for custom export transformations #1347
- Added: Duplicate check control hook for import workflow extensibility #1339
- Added: Row data filter hook to enable dynamic transformation before processing #1337
- Added: Post-import hooks for WooCommerce, CPT, user, and taxonomy modules #1340
- Added: REST API import with pagination v1 and existing importer pipeline integration
- Added: Module-based template grouping with pagination support #1328
- Added: Free plugin dependency notice and activation requirement for Pro

#### Enhancements

- Improved: Completed Japanese localization support across admin UI and components #1352

#### Bug Fixes

- Fixed: Regional English locale class naming mismatch for LangEN_ZA, LangEN_CA, and LangEN_GB #1350

### 8.15.5

- Fixed: Prevent default category loss when CSV category name differs from slug during post import #26361

### 8.15.4

- Fixed: 403 AJAX mapping save issue for custom header manipulation formulas #26393

### 8.15.3

- Fixed: Advanced Mode hang caused by attribute dropdown re-render loop #26432

### 8.15.2

- Fixed: Kadence theme UI conflict when Ultimate CSV Importer Pro is active #26505

### 8.15.1

- Fixed: SQL escaping issues for special characters during import and secured dynamic queries using wpdb prepare #26505

### 8.15

See `wp-ultimate-csv-importer.json` for the full version history and changelogs.

## Custom Hooks

Import and export hook references are available in the `hooks/` directory:

- `hooks/Custom-Hooks.md`
- `hooks/Export-action-hooks.md`
- `hooks/Export-filter-hooks.md`

## License

Proprietary and confidential. Copyright (C) Smackcoders. All Rights Reserved.
