<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

class AIMediaSEO
{
	public static $instance = null;

	public static function getInstance()
	{
		if (AIMediaSEO::$instance == null) {
			AIMediaSEO::$instance = new AIMediaSEO();
		}
		return AIMediaSEO::$instance;
	}

	public function resolve_media_settings_ai_prompts($media_settings, $header_array = null, $value_array = null)
	{
		if (empty($media_settings) || !is_array($media_settings)) {
			return $media_settings;
		}
		// error_log(print_r($media_settings,true).PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');
		// error_log(print_r($header_array,true).PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');
		// error_log(print_r($value_array,true).PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');

		$allowed_keys = array('title', 'caption', 'alttext', 'description', 'file_name');

		foreach ($allowed_keys as $key) {
			if (!isset($media_settings[$key]) || !is_string($media_settings[$key])) {
				continue;
			}

			$raw_value = trim($media_settings[$key]);
			$prompt = $this->extract_wp_ai_prompt($raw_value);
			if ($prompt === null || $prompt === '') {
				continue;
			}
			
			// error_log("[WCSV AI SEO] Found AI prompt for $key: " . substr($prompt, 0, 50) . "...".PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');

			$resolved_prompt = $this->replace_prompt_placeholders($prompt, $header_array, $value_array);
			// error_log("[WCSV AI SEO] Resolved prompt for $key: " . substr($resolved_prompt, 0, 100) . "...".PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');

			// Append strict formatting instruction to avoid conversational filler
			$strict_prompt = $resolved_prompt . "\n\nCRITICAL: Return ONLY the final result string for the " . $key . ". No preamble, no quotes, no explanations, no numbering, no conversational filler. Just the direct text.";

			$ai_provider = isset($media_settings[$key . '_ai_provider']) ? $media_settings[$key . '_ai_provider'] : '';
			$ai_model    = isset($media_settings[$key . '_ai_model']) ? $media_settings[$key . '_ai_model'] : '';

			$ai_output = $this->generate_text($strict_prompt, $ai_provider, $ai_model);
			// error_log("[WCSV AI SEO] AI output for $key length: " . (is_string($ai_output) ? strlen($ai_output) : 'N/A').PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');

			if (is_string($ai_output) && $ai_output !== '') {
				$cleaned_output = $this->clean_ai_output($ai_output);
				// error_log("[WCSV AI SEO] Cleaned output for $key: " . substr($cleaned_output, 0, 50) . "...".PHP_EOL,3,WP_CONTENT_DIR.'/AiSEO.log');
				$media_settings[$key] = $this->sanitize_ai_output($key, $cleaned_output);
			}
		}

		return $media_settings;
	}

	public function generate_text($prompt, $provider = '', $model = '', $max_tokens = '')
	{
		if (empty($prompt)) {
			// error_log("[WCSV AI SEO] generate_text: Prompt is empty.".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		if (!function_exists('wp_ai_client_prompt')) {
			// error_log("[WCSV AI SEO] generate_text: Function wp_ai_client_prompt DOES NOT exist.".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		if (!ConnectorsHelper::has_any_connector()) {
			// error_log("[WCSV AI SEO] generate_text: No AI connectors configured.".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		$builder = wp_ai_client_prompt($prompt);
		if (!$builder) {
			// error_log("[WCSV AI SEO] generate_text: Failed to initialize AI client builder.".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		if (!empty($provider)) {
			$configured = ConnectorsHelper::is_configured($provider);
			// error_log("[WCSV AI SEO] generate_text: Requested Provider: $provider. Configured: " . ($configured ? "YES" : "NO").PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			
			// Try to find the actual model object to force the provider
			$all_models = ConnectorsHelper::get_available_models();
			$provider_models = isset($all_models[$provider]) ? $all_models[$provider] : [];
			
			$target_model_obj = null;
			if (!empty($model)) {
				foreach ($provider_models as $m) {
					if ($m['id'] === $model || $m['name'] === $model) {
						// Assuming the metadata provides the model object. 
						// Wait, ConnectorsHelper::get_available_models returns an array of arrays.
						// I need the actual ModelInterface object.
					}
				}
			}

			if (!empty($provider)) {
			try {
				if (is_callable([$builder, 'using_provider'])) {
					// error_log("[WCSV AI SEO] generate_text: Calling using_provider('$provider')".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
					$builder = $builder->using_provider($provider);
				}
			} catch (\Exception $e) {
				// error_log("[WCSV AI SEO] generate_text: Provider '$provider' switching failed: " . $e->getMessage() . PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			}
		}

		if (!empty($model)) {
			try {
				$registry = \WordPress\AiClient\AiClient::defaultRegistry();
				// getProviderModel(string $idOrClassName, string $modelId, ?ModelConfig $modelConfig = null)
				$model_obj = $registry->getProviderModel($provider ?: '', $model);
				
				// error_log("[WCSV AI SEO] generate_text: Calling using_model for '" . $model . "'".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
				$builder = $builder->using_model($model_obj);
			} catch (\Exception $e) {
				// error_log("[WCSV AI SEO] generate_text: Model resolution failed for '$model' (Provider: ".($provider ?: 'default')."): " . $e->getMessage() . PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			}
		}

		if ($max_tokens !== '' && is_numeric($max_tokens)) {
			if (method_exists($builder, 'using_max_tokens')) {
				$builder = $builder->using_max_tokens((int) $max_tokens);
			}
		}

		$result = $builder->generate_text();

		if (is_wp_error($result)) {
			// error_log("[WCSV AI SEO] generate_text: WP_Error returned: " . $result->get_error_message().PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		if (empty($result)) {
			// error_log("[WCSV AI SEO] generate_text: AI client returned an empty result.".PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
			return false;
		}

		return is_string($result) ? $result : false;
	}
	}
	public function resolve_mapping_ai_prompts(&$map, &$header_array, &$all_value_array, $core_instance = null)
	{
		// error_log("[WCSV AI SEO] resolve_mapping_ai_prompts entry. Sections: " . implode(', ', array_keys($map)).PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
		$openAIKeys = array();
		$openAIValues = array();
		$openAInumberKeys = array();
		$openAInumberValues = array();
		$flag = false;

		foreach ($map as $section => $fields) {
			if (!is_array($fields) || ($section !== 'FEATURED_IMAGE_META' && $section !== 'ECOMMETA')) continue;
			foreach ($fields as $subKey => $subValue) {
				if (substr($subKey, -7) === '->AiSEO') {
					$flag = true;
					$value_header = str_replace("->AiSEO", "", $subKey);
					$openAIKeys[] = $value_header;
					$openAIValues[] = $subValue;
				}
				if (substr($subKey, -5) === '->num') {
					$value_header = str_replace("->num", "", $subKey);
					$openAInumberKeys[] = $value_header;
					$openAInumberValues[] = $subValue;
				}
			}
		}

		// error_log("[WCSV AI SEO] resolve_mapping_ai_prompts called. Flag: " . ($flag ? 'TRUE' : 'FALSE').PHP_EOL, 3, WP_CONTENT_DIR.'/AiSEO.log');
		if (!$flag) return;

		if ($core_instance) {
			$core_instance->generated_content = $flag;
		}

		$combinedArray = array_combine($openAIKeys, $openAIValues);
		$field_to_csv = array();
		foreach ($map as $section => $fields) {
			if (is_array($fields)) {
				foreach ($fields as $fieldKey => $csvCol) {
					if (strpos($fieldKey, '->AiSEO') === false) {
						$field_to_csv[trim($fieldKey)] = $csvCol;
					}
				}
			}
		}

		// Handle all mapped fields as text generation for SEO
		foreach ($combinedArray as $fieldKey => $template) {
			if (empty($template)) continue;

			$max_tokens = '';
			if (in_array($fieldKey, $openAInumberKeys, true)) {
				$num_idx = array_search($fieldKey, $openAInumberKeys, true);
				$max_tokens = $openAInumberValues[$num_idx];
			}

			$ai_provider = $this->extract_mapping_setting($map, $fieldKey, 'ai_provider');
			$ai_model    = $this->extract_mapping_setting($map, $fieldKey, 'ai_model');

			// error_log("[WCSV AI SEO] Resolved AI Config for $fieldKey: Provider: $ai_provider, Model: $ai_model" . PHP_EOL, 3, WP_CONTENT_DIR . '/AiSEO.log');

			$index = array_search($fieldKey, $header_array);
			if ($index === false) {
				$header_array[] = $fieldKey;
				$index = count($header_array) - 1;
				// error_log("[WCSV AI SEO DEBUG] Added header: $fieldKey at index: $index",3,WP_CONTENT_DIR.'/AiSEO.log');
			}

			$results = array();
			foreach ($all_value_array as $row_index => &$value_array) {
				// Check if it's a gallery-related meta field
				$is_gallery_meta = in_array($fieldKey, [
					'product_gallery_image_alt_text',
					'product_gallery_image_caption',
					'product_gallery_image_description',
					'product_gallery_image_title'
				]);

				$image_count = 1;
				if ($is_gallery_meta) {
					$gallery_header = isset($field_to_csv['product_image_gallery']) ? $field_to_csv['product_image_gallery'] : (isset($field_to_csv['_product_image_gallery']) ? $field_to_csv['_product_image_gallery'] : '');
					
					if ($gallery_header) {
						$gallery_val = $this->replace_mapping_placeholders('{' . $gallery_header . '}', $field_to_csv, $header_array, $value_array);
						
						// If the above failed (e.g. if gallery_header isn't recognized as a placeholder), try direct lookup in header_array
						if (empty($gallery_val) || strpos($gallery_val, '{') !== false) {
							$gallery_idx = array_search($gallery_header, $header_array);
							if ($gallery_idx !== false && isset($value_array[$gallery_idx])) {
								$gallery_val = $value_array[$gallery_idx];
							}
						}

						error_log("[WCSV AI SEO] Gallery Field: $fieldKey, Header: $gallery_header, Value: " . substr($gallery_val, 0, 50));

						if ($gallery_val && !empty(trim($gallery_val)) && strpos($gallery_val, '{') === false) {
							if (strpos($gallery_val, '|') !== false) {
								$image_count = count(explode('|', $gallery_val));
							} elseif (strpos($gallery_val, ',') !== false) {
								$image_count = count(explode(',', $gallery_val));
							} else {
								$image_count = 1;
							}
						}
						error_log("[WCSV AI SEO] Detected Image Count: $image_count");
					} else {
						// Check if it's an AI prompt for gallery generation
						$gallery_prompt = $this->extract_mapping_setting($map, 'product_image_gallery', 'openAI');
						if (empty($gallery_prompt)) {
							$gallery_prompt = $this->extract_mapping_setting($map, '_product_image_gallery', 'openAI');
						}
						
						if ($gallery_prompt) {
							error_log("[WCSV AI SEO] Detected AI Gallery Prompt: $gallery_prompt");
							if (preg_match('/(?:gallery\s+(\d+)\s+images|(\d+)\s+gallery\s+images)/i', $gallery_prompt, $matches)) {
								$image_count = !empty($matches[1]) ? (int)$matches[1] : (int)$matches[2];
							}
							error_log("[WCSV AI SEO] Detected AI Image Count: $image_count");
						}
					}
				}

				$generated_parts = [];
				for ($i = 0; $i < $image_count; $i++) {
					$raw_template = $this->replace_mapping_placeholders($template, $field_to_csv, $header_array, $value_array);
					$prompt = $this->extract_wp_ai_prompt($raw_template);
					if ($prompt === null || $prompt === '') {
						$prompt = $raw_template;
					}

					if (empty(trim($prompt))) {
						$prompt = "Generate a short description.";
					}

					// If generating for a specific image in a gallery, add a hint for variation
					if ($image_count > 1) {
						$prompt .= " (Variation " . ($i + 1) . " of $image_count for uniqueness)";
					}

					$generated = $this->generate_text($prompt, $ai_provider, $ai_model, $max_tokens);
					
					if (is_string($generated) && $generated !== '') {
						$generated = $this->clean_ai_output($generated);
					}
					$generated_parts[] = $generated;
				}
				
				$final_generated = implode('|', $generated_parts);
				$value_array[$index] = $final_generated;
				$results[] = $final_generated;
			}

			if ($core_instance) {
				$core_instance->openAI_response = array_merge($core_instance->openAI_response ?? [], $results);
			}

			// Ensure the mapping points to the new header dynamically in ANY section it appears
			foreach ($map as $section => &$fields) {
				if (is_array($fields) && isset($fields[$fieldKey . '->AiSEO'])) {
					$fields[$fieldKey] = $fieldKey;
					// error_log("[WCSV AI SEO DEBUG] Updated map[$section][$fieldKey] = $fieldKey",3,WP_CONTENT_DIR.'/AiSEO.log');
				}
			}
	}
	}
	private function replace_mapping_placeholders($template, $field_to_csv, $header_array, $value_array)
	{
		$helpers_instance = ImportHelpers::getInstance();
		$prompt = (string) $template;
		if (preg_match_all('/{([^}]*)}/', $prompt, $matches)) {
			if (!empty($matches[1]) && is_array($matches[1])) {
				foreach ($matches[1] as $k => $placeholder) {
					$placeholder = trim($placeholder);
					$header = isset($field_to_csv[$placeholder]) ? $field_to_csv[$placeholder] : $placeholder;
					$replacement = $helpers_instance->replace_header_with_values($header, $header_array, $value_array);
					$prompt = str_replace($matches[0][$k], $replacement, $prompt);
				}
			}
		}
		return trim($prompt);
	}

	private function extract_mapping_setting($map, $fieldKey, $setting)
	{
		$key_new = $fieldKey . '->' . $setting;
		$key_old = $fieldKey . '_' . $setting;
		foreach ($map as $section => $fields) {
			if (isset($fields[$key_new])) return $fields[$key_new];
			if (isset($fields[$key_old])) return $fields[$key_old];
		}
		return '';
	}


	private function extract_wp_ai_prompt($value)
	{
		if (!is_string($value) || $value === '') {
			return null;
		}

		$trimmed = trim($value);
		if (stripos($trimmed, 'wp_ai_prompt') === false) {
			return null;
		}

		if (preg_match('/^\s*wp_ai_prompt\s*:\s*(.+)\s*$/is', $trimmed, $matches)) {
			return trim($matches[1]);
		}

		if (preg_match('/^\s*wp_ai_prompt\s*\(\s*(.+)\s*\)\s*$/is', $trimmed, $matches)) {
			$inner = trim($matches[1]);
			$inner = preg_replace('/^([\'"])(.*)\1$/s', '$2', $inner);
			return trim($inner);
		}

		return null;
	}

	private function replace_prompt_placeholders($prompt, $header_array = null, $value_array = null)
	{
		if (!is_array($header_array) || !is_array($value_array)) {
			return $prompt;
		}

		if (count($header_array) !== count($value_array)) {
			return $prompt;
		}

		$replacements = array();
		foreach ($header_array as $index => $header) {
			if (!is_string($header)) {
				continue;
			}
			$header_key = trim($header);
			if ($header_key === '') {
				continue;
			}
			$replacements['{' . $header_key . '}'] = isset($value_array[$index]) ? (string) $value_array[$index] : '';
		}

		if (empty($replacements)) {
			return $prompt;
		}

		return strtr($prompt, $replacements);
	}

	private function sanitize_ai_output($key, $value)
	{
		$value = trim($value);
		if ($key === 'description') {
			return wp_kses_post($value);
		}
		return sanitize_text_field($value);
	}

	/**
	 * Extracts the core content from AI output, stripping preambles and selecting the first item if it's a list.
	 */
	private function clean_ai_output($text)
	{
		if (empty($text)) {
			return $text;
		}

		$text = trim($text);

		// Remove leading/trailing quotes (single, double, or stylized)
		$text = preg_replace('/^["\'\x{201C}\x{2018}]|["\'\x{201D}\x{2019}]$/u', '', $text);

		// If AI returns a list (1. ..., 2. ...) or bullet points, extract the first one
		if (preg_match('/^\d+\.\s*(.+)$/m', $text, $matches)) {
			$text = trim($matches[1]);
		} elseif (preg_match('/^[-*•]\s*(.+)$/m', $text, $matches)) {
			$text = trim($matches[1]);
		}

		// If it still has "Here are..." or "The SEO title is..." type preambles, try to find the part after the colon
		// but only if it's a short result that looks like a title/caption.
		if (preg_match('/^(?:Here are|Here is|The \w+ is|Result):\s*(.+)$/is', $text, $matches)) {
			$text = trim($matches[1]);
		}
		
		// Final trim and cleanup of any remaining outer quotes if they were nested
		$text = trim($text, "\"' \t\n\r\0\x0B");
		
		return $text;
	}
}

