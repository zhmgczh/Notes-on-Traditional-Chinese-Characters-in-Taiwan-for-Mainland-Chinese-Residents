<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/


namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class AI_Natural_Language_Imports {

    public static $instance = null;
    private $folder_path = WP_CONTENT_DIR . '/uploads/smack_uci_uploads/imports';

    /** Mirrors app/admin/helper/index.js languagePropertyId resultKey values. */
    private static $plugin_id_to_result_key_json = '';
    private static $plugin_id_to_result_key = array(
        "core_fields" => "CORE",
        "media_fields" => "MEDIA",
        "featured_fields" => "FEATURED_IMAGE_META",
        "acf_image_meta_fields" => "ACFIMAGEMETA",
        "terms_and_taxonomies" => "TERMS",
        "wordpress_custom_fields" => "CORECUSTFIELDS",
        "directory_pro_fields" => "DPF",
        "acf_pro_fields" => "ACF",
        "acf_fields" => "ACF",
        "acf_group_fields" => "GF",
        "acf_repeater_fields" => "RF",
        "acf_pro_repeater_fields" => "RF",
        "acf_repeater_of_repeater_fields" => "RRF",
        "acf_flexible_fields" => "FC",
        "types_fields" => "TYPES",
        "types_image_meta_fields" => "TYPESIMAGEMETA",
        "pods_fields" => "PODS",
        "pods_image_meta_fields" => "PODSIMAGEMETA",
        "lifter_course_settings_fields" => "LIFTERCOURSE",
        "lifter_quiz_settings_fields" => "LIFTERQUIZ",
        "lifter_review_settings_fields" => "LIFTERREVIEW",
        "lifter_coupon_settings_fields" => "LIFTERCOUPON",
        "lifter_lesson_settings_fields" => "LIFTERLESSON",
        "course_settings_fields_stm" => "STMCOURSE",
        "curriculum_settings_fields_stm" => "STMCURRICULUM",
        "lesson_settings_fields_stm" => "STMLESSON",
        "quiz_settings_fields_stm" => "STMQUIZ",
        "question_settings_fields_stm" => "STMQUESTION",
        "order_settings_fields_stm" => "STMORDER",
        "custom_fields_suite_fields" => "CFS",
        "all_in_one_seo_fields" => "AIOSEO",
        "yoast_seo_fields" => "YOASTSEO",
        "slim_seo_fields" => "SLIMSEO",
        "profilepress_fields" => "PROFILEPRESS",
        "EDD_DOWNLOADS" => "EDD_DOWNLOADS",
        "EDD_ORDERS" => "EDD_ORDERS",
        "EDD_CUSTOMERS" => "EDD_CUSTOMERS",
        "EDD_DISCOUNTS" => "EDD_DISCOUNTS",
        "SURECART_PRODUCTS" => "SURECART_PRODUCTS",
        "SURECART_ORDERS" => "SURECART_ORDERS",
        "SURECART_CUSTOMERS" => "SURECART_CUSTOMERS",
        "SURECART_SUBSCRIPTIONS" => "SURECART_SUBSCRIPTIONS",
        "SURECART_COUPONS" => "SURECART_COUPONS",
        "SURECART_REPORTS" => "SURECART_REPORTS",
        "surecart_core_fields" => "SURECART_CORE",
        "surecart_product_meta" => "SURECART_PRODUCT_META",
        "surecart_order_meta" => "SURECART_ORDER_META",
        "surecart_customer_meta" => "SURECART_CUSTOMER_META",
        "FLUENTCART_PRODUCTS" => "FLUENTCART_PRODUCTS",
        "FLUENTCART_ORDERS" => "FLUENTCART_ORDERS",
        "FLUENTCART_CUSTOMERS" => "FLUENTCART_CUSTOMERS",
        "FLUENTCART_COUPONS" => "FLUENTCART_COUPONS",
        "wpcomplete_fields" => "WPCOMPLETE",
        "seopress_fields" => "SEOPRESS",
        "elementor_meta_fields" => "ELEMENTOR",
        "rank_math_fields" => "RANKMATH",
        "rank_math_pro_fields" => "RANKMATH",
        "billing_and_shipping_information" => "BSI",
        "custom_fields_wp_members" => "WPMEMBERS",
        "custom_fields_members" => "MEMBERS",
        "product_meta_fields" => "ECOMMETA",
        "product_attr_fields" => "ATTRMETA",
        "product_bundle_meta_fields" => "BUNDLEMETA",
        "listing_meta_fields" => "LISTINGMETA",
        "wprentals_meta_fields" => "OWNERMETA",
        "wprentals_owner_fields" => "PROPERTYMETA",
        "product_image_meta_fields" => "PRODUCTIMAGEMETA",
        "order_meta_fields" => "ORDERMETA",
        "ppom_meta_fields" => "PPOMMETA",
        "eventcalendar_meta_fields" => "EventCalendarMeta",
        "eventcalendar_venue_fields" => "EventCalendarVenue",
        "eventcalendar_organizer_fields" => "EventCalendarOrganizer",
        "eventcalendar_custom_fields" => "EventCalendarCustom",
        "eventcalendar_recurrence_fields" => "EventCalendarRecurrence",
        "eventcalendar_series_fields" => "EventCalendarSeries",
        "eventcalendar_tickets_fields" => "EventCalendarTickets",
        "epo_meta_fields" => "EPOMETA",
        "wcpa_meta_fields" => "WCPAMETA",
        "fpf_meta_fields" => "FPFMETA",
        "coupon_meta_fields" => "COUPONMETA",
        "refund_meta_fields" => "REFUNDMETA",
        "wp_ecom_custom_fields" => "WPECOMMETA",
        "events_manager_fields" => "EVENTS",
        "nextgen_gallery_fields" => "NEXTGEN",
        "wpml_fields" => "WPML",
        "cmb2_fields" => "CMB2",
        "bp_fields" => "BP",
        "jet_booking_fields" => "JEBOOKING",
        "jet_review_fields" => "JEREVIEW",
        "jetengine_fields" => "JE",
        "jetengine_rf_fields" => "JERF",
        "jetenginecpt_fields" => "JECPT",
        "jetenginecpt_rf_fields" => "JECPTRF",
        "jetenginecct_fields" => "JECCT",
        "jetenginecct_rf_fields" => "JECCTRF",
        "jetenginetaxonomy_fields" => "JETAX",
        "jetenginetaxonomy_rf_fields" => "JETAXRF",
        "jetengine_rel_fields" => "JEREL",
        "course_settings_fields" => "LPCOURSE",
        "curriculum_settings_fields" => "LPCURRICULUM",
        "lesson_settings_fields" => "LPLESSON",
        "quiz_settings_fields" => "LPQUIZ",
        "question_settings_fields" => "LPQUESTION",
        "order_settings_fields" => "LPORDER",
        "forum_attributes_fields" => "FORUM",
        "topic_attributes_fields" => "TOPIC",
        "reply_attributes_fields" => "REPLY",
        "Polylang_settings_fields" => "POLYLANG",
        "metabox_fields" => "METABOX",
        "acpt_fields" => "ACPT",
        "metabox_relations_fields" => "METABOXRELATION",
        "metabox_group_fields" => "METABOXGROUP",
        "job_listing_fields" => "JOB",
        "fifu_post_settings_fields" => "FIFUPOSTS",
        "fifu_page_settings_fields" => "FIFUPAGE",
        "fifu_custompost_settings_fields" => "FIFUCUSTOMPOST"
    );


    public static function getInstance()
    {
        if (AI_Natural_Language_Imports::$instance == null) {
            AI_Natural_Language_Imports::$instance = new AI_Natural_Language_Imports;
            self::$plugin_id_to_result_key_json = json_encode(self::$plugin_id_to_result_key);
        }
        return AI_Natural_Language_Imports::$instance;
    }

    public function __construct() {
        add_action('wp_ajax_ai_natural_language_import', array($this, 'ai_natural_language_import'));
    }

    public function ai_natural_language_import() {
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
        }

        if (!ConnectorsHelper::is_wp_ai_available() || !ConnectorsHelper::has_any_connector()) {
            wp_send_json_error(['message' => __('Please configure your AI API key in the settings before using AI row removal.', 'wp-ultimate-csv-importer-pro')]);
            return;
        }

        $file_hash = isset($_POST['file_hash']) ? sanitize_text_field(wp_unslash($_POST['file_hash'])) : '';
        $user_prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';
        $provider = isset($_POST['provider']) ? sanitize_text_field(wp_unslash($_POST['provider'])) : '';
        $model = isset($_POST['model']) ? sanitize_text_field(wp_unslash($_POST['model'])) : '';
        if (empty($file_hash) || empty($user_prompt)) {
            wp_send_json_error(['message' => __('Invalid file or prompt.', 'wp-ultimate-csv-importer-pro')]);
            return;
        }

        $file_dir = $this->folder_path . '/' . $file_hash;
        $file_path = $file_dir . '/' . $file_hash;

        if (!file_exists($file_path)) {
            wp_send_json_error(['message' => __('File not found.', 'wp-ultimate-csv-importer-pro')]);
            return;
        }

        if ($this->is_xml_file($file_path)) {
            $csv_content = $this->convert_xml_to_csv($file_path);
            if (is_wp_error($csv_content)) {
                wp_send_json_error(['message' => $csv_content->get_error_message()]);
                return;
            }
            file_put_contents($file_path, $csv_content);
        } elseif ($this->is_excel_file($file_path)) {
            $csv_content = $this->convert_excel_to_csv($file_path);
            if (is_wp_error($csv_content)) {
                wp_send_json_error(['message' => $csv_content->get_error_message()]);
                return;
            }
            file_put_contents($file_path, $csv_content);
        } elseif ($this->is_tsv_file($file_path)) {
            $csv_content = $this->convert_tsv_to_csv($file_path);
            if (is_wp_error($csv_content)) {
                wp_send_json_error(['message' => $csv_content->get_error_message()]);
                return;
            }
            file_put_contents($file_path, $csv_content);
        }

        $available_post_types = ExtensionHandler::getInstance()->get_import_post_types();
        $sample_data = $this->get_csv_sample($file_path, 3);

        $logic = $this->get_logic_analysis($user_prompt, $available_post_types, $sample_data['headers'], $sample_data['rows'], $provider, $model);
        if (is_wp_error($logic)) {
            wp_send_json_error(['message' => $logic->get_error_message()]);
            return;
        }

        // Persist the AI skip condition immediately for use in the import phase
        if (!empty($logic['ai_skip_condition'])) {
            update_option('smack_uci_ai_skip_condition_' . $file_hash, $logic['ai_skip_condition']);
        } else {
            delete_option('smack_uci_ai_skip_condition_' . $file_hash);
        }


        $identified_post_type = $logic['post_type'];

        $mapping_result = $this->get_mapping_analysis($user_prompt, $identified_post_type, $sample_data['headers'], $sample_data['rows'], $logic, $provider, $model);
        $mapping_result = $this->addHeaderManipulationToMappingResult($mapping_result);
        if (is_wp_error($mapping_result)) {
            wp_send_json_error(['message' => $mapping_result->get_error_message()]);
            return;
        }

        $mapping_data = $this->get_mapping_data($identified_post_type, $file_hash);
        if (is_wp_error($mapping_data)) {
            wp_send_json_error(['message' => $mapping_data->get_error_message()]);
            return;
        }

        $mh = $logic['media_handling'] ?? [];
        $image_options = [
            'media_handle_option'      => true,
            'use_ExistingImage'        => isset($mh['use_ExistingImage']) ? (bool) $mh['use_ExistingImage'] : true,
            'overwriteImage'           => !empty($mh['overwriteImage']),
            'newImage'                 => !empty($mh['newImage']),
            'postContent_image_option' => false,
            'title'                    => '',
            'file_name'                => '',
            'caption'                  => '',
            'alttext'                  => '',
            'description'              => '',
            'thumbnail'                => false,
            'medium'                   => false,
            'medium_large'             => false,
            'large'                    => false,
            'custom'                   => false,
            'custom_slug'              => '',
            'custom_width'             => '',
            'custom_height'            => '',
            'slugonly'                 => false,
            'directoryPath'            => false,
            'retainPath'               => false,
        ];

        $import_mode = $logic['mode'] ?? 'Insert';

        wp_send_json_success(array_merge([
            'message'              => __('Import strategy analyzed and mapped successfully.', 'wp-ultimate-csv-importer-pro'),
            'post_type'            => $identified_post_type,
            'mode'                 => $import_mode,
            'import_mode'          => $import_mode,
            'file_iteration'       => $logic['file_iteration'] ?? 5,
            'rollback'             => !empty($logic['rollback']),
            'identified_post_type' => $identified_post_type,
            'media_handling'       => $image_options,
            'mapping_result'       => $mapping_result['mapped_fields'],
            'mapped_filter'        => $mapping_result['mapped_filter'] ?? [],
            'skip_condition'       => $logic['ai_skip_condition'] ?? '',
        ], $mapping_data));
    }

    public function get_csv_sample($file_path, $count = 5) {
        $headers = [];
        $rows = [];
        if (($handle = fopen($file_path, "r")) !== FALSE) {
            $headers = fgetcsv($handle);
            $i = 0;
            while ($i < $count && ($data = fgetcsv($handle)) !== FALSE) {
                $rows[] = $data;
                $i++;
            }
            fclose($handle);
        }
        return ['headers' => $headers, 'rows' => $rows];
    }

    protected function get_plugin_id_to_result_key_map() {
        static $map = null;
        if ($map === null) {
            $map = self::$plugin_id_to_result_key;
            if (!is_array($map)) {
                $map = [];
            }
        }
        return $map;
    }

    protected function addHeaderManipulationToMappingResult($mapping_result) {
        if (!is_array($mapping_result) || !isset($mapping_result['mapped_fields']) || !is_array($mapping_result['mapped_fields'])) {
            return $mapping_result;
        }

        $mapped_fields = $mapping_result['mapped_fields'];
        foreach ($mapped_fields as $section => $fields) {
            if (!is_array($fields)) {
                continue;
            }
            foreach ($fields as $key => $value) {
                if (is_string($key) && strpos($key, '->code') !== false) {
                    $new_key = trim(str_replace('->code', '', $key));
                    if ($new_key !== '') {
                        // Force Header Manipulation whenever a ->code exists
                        $mapped_fields[$section][$new_key] = 'Header Manipulation';
                    }
                }
            }
        }

        $mapping_result['mapped_fields'] = $mapped_fields;
        return $mapping_result;
    }
    /**
     * Flattens MappingExtension::mapping_fields() widgets into the same shape SaveMapping::wp_ai_field_mapping_handler expects.
     */
    protected function flatten_mapping_extension_fields_for_ai($fields_raw) {
        $fields = [];
        foreach ($fields_raw as $plugin_obj) {
            if (!is_array($plugin_obj)) {
                continue;
            }
            foreach ($plugin_obj as $plugin_id => $field_list) {
                if (empty($plugin_id) || !is_array($field_list)) {
                    continue;
                }
                foreach ($field_list as $field) {
                if (!is_array($field)) {
                    continue;
                }
                if (isset($field['name']) && is_array($field['name'])) {
                    foreach ($field['name'] as $subfield) {
                        if (isset($subfield['name'], $subfield['label'])) {
                            $fields[] = [
                                'name'     => (string) $subfield['name'],
                                'label'    => (string) $subfield['label'],
                                'pluginId' => $plugin_id,
                            ];
                        }
                    }
                } elseif (isset($field['name'])) {
                    $fields[] = [
                        'name'     => (string) $field['name'],
                        'label'    => isset($field['label']) ? (string) $field['label'] : '',
                        'pluginId' => $plugin_id,
                    ];
                }
            }
        }
    }
    return $fields;
}

    protected function nested_mapping_from_wp_ai_flat(array $flat_fields, array $final_mapping) {
        $map = $this->get_plugin_id_to_result_key_map();
        $nested = [];

        foreach ($flat_fields as $field) {
            $name = $field['name'];
            $plugin_id = isset($field['pluginId']) ? $field['pluginId'] : 'unknown';
            if (!isset($map[$plugin_id])) {
                continue;
            }
            $rk = $map[$plugin_id];
            if (!isset($final_mapping[$name])) {
                continue;
            }
            $fm = $final_mapping[$name];
            $val = isset($fm['value']) ? $fm['value'] : null;
            $conf = isset($fm['confidence']) ? (int) $fm['confidence'] : 0;
            if ($val !== null && $val !== '' && $conf > 0) {
                if (!isset($nested[$rk])) {
                    $nested[$rk] = [];
                }
                $nested[$rk][$name] = $val;
            }
        }

        return $nested;
    }

    protected function normalize_row_filters($filters) {
        if (!is_array($filters)) {
            return [];
        }
        $out = [];
        foreach ($filters as $f) {
            if (!is_array($f) || empty($f['element']) || empty($f['rule'])) {
                continue;
            }
            $out[] = [
                'element'   => (string) $f['element'],
                'rule'      => (string) $f['rule'],
                'value'     => isset($f['value']) ? (string) $f['value'] : '',
                'condition' => isset($f['condition']) ? (string) $f['condition'] : '',
            ];
        }
        return $out;
    }

    /**
     * Corrects AI formulas to use the exact case-sensitive CSV header names.
     * E.g. $data['Regular Price'] -> $data['regular_price']
     */
    protected function normalize_formula_headers($formula, $headers) {
        if (!is_string($formula) || empty($headers)) {
            return $formula;
        }

        // Regex for $data['...'] or $data["..."]
        return preg_replace_callback('/\$data\[([\'"])(.*?)\1\]/', function($matches) use ($headers) {
            $quote = $matches[1];
            $key = trim($matches[2]);
            $lk = strtolower($key);

            // 1. Exact Match Priority (Case-Insensitive)
            foreach ($headers as $h) {
                if (strtolower(trim($h)) === $lk) {
                    return '$data[' . $quote . $h . $quote . ']';
                }
            }

            // 2. Fuzzy Match (Partial)
            foreach ($headers as $h) {
                $lh = strtolower(trim($h));
                if (strpos($lh, $lk) !== false || strpos($lk, $lh) !== false) {
                     return '$data[' . $quote . $h . $quote . ']';
                }
            }
            
            return $matches[0];
        }, $formula);
    }

    /**
     * Normalizes planner JSON post_type to ExtensionHandler::get_import_post_types() keys (labels).
     * The planner AI (single call in get_logic_analysis) must output a valid label; this only maps exact key, internal id, or case-insensitive label.
     *
     * @return string|\WP_Error
     */
    protected function resolve_import_post_type_key($candidate, array $available_post_types) {
        $c = trim((string) $candidate);

        if ($c !== '' && isset($available_post_types[$c])) {
            return $c;
        }

        if ($c !== '') {
            foreach ($available_post_types as $key => $val) {
                if (strcasecmp((string) $val, $c) === 0) {
                    return $key;
                }
            }
            foreach ($available_post_types as $key => $val) {
                if (strcasecmp($key, $c) === 0) {
                    return $key;
                }
            }
        }

        return new \WP_Error(
            'post_type_invalid',
            __('The import planner did not return a valid post_type label. In your prompt, name the module exactly as in the plugin list (e.g. WooCommerce Product), then try again.', 'wp-ultimate-csv-importer-pro')
        );
    }

    /**
     * Prefer downloading/creating new attachments when the user asks for new images/files.
     */
    protected function maybe_apply_new_media_from_prompt(array $media_handling, $user_prompt) {
        $p = strtolower($user_prompt);
        $wants_new = (
            (strpos($p, 'new') !== false || strpos($p, 'create') !== false || strpos($p, 'download') !== false || strpos($p, 'import') !== false)
            && (strpos($p, 'image') !== false || strpos($p, 'media') !== false || strpos($p, 'file') !== false || strpos($p, 'attachment') !== false)
        );
        if ($wants_new || (strpos($p, 'always') !== false && strpos($p, 'new') !== false)) {
            $media_handling['newImage'] = true;
            $media_handling['use_ExistingImage'] = false;
            $media_handling['overwriteImage'] = !empty($media_handling['overwriteImage']);
        }
        return $media_handling;
    }

    /**
     * Phase 1: import type, mode, iteration, media, rollback, header renames, transformations, filters.
     */
    protected function get_logic_analysis($user_prompt, $available_post_types, $headers, $sample_rows, $provider = '', $model = '') {
        $all_post_type_labels = array_keys($available_post_types);
        $allowed_labels_json = wp_json_encode($all_post_type_labels, JSON_UNESCAPED_UNICODE);
        $targetContext = wp_json_encode($available_post_types, JSON_UNESCAPED_UNICODE);

        $header_preview = is_array($headers) ? implode(', ', array_slice(array_map('strval', $headers), 0, 200)) : '';
        $first_h = (isset($headers[0]) && !empty($headers[0])) ? (string)$headers[0] : 'CSVHeaderName';

        // Auto-match headers for common concepts to guide AI (Priority: Exact Match)
        $price_h = ""; $sale_price_h = ""; $stock_h = "";
        foreach ($headers as $h) {
            $lh = strtolower(trim((string)$h));
            // Exact/Near-Exact matches take priority
            if (empty($price_h) && in_array($lh, ['regular price', 'regular_price', 'reg_price', 'price'])) {
                $price_h = (string)$h;
            }
            if (empty($sale_price_h) && in_array($lh, ['sale price', 'sale_price', 'saleprice', 'sales_price'])) {
                $sale_price_h = (string)$h;
            }
            if (empty($stock_h) && in_array($lh, ['stock', 'quantity', 'qty', 'stock_qty', 'stock_status'])) {
                $stock_h = (string)$h;
            }
        }
        // Fallback to Fuzzy/Partial matches ONLY if exact ones weren't found
        if (empty($price_h) || empty($sale_price_h) || empty($stock_h)) {
            foreach ($headers as $h) {
                $lh = strtolower((string)$h);
                if (empty($price_h) && strpos($lh, 'price') !== false && strpos($lh, 'sale') === false) {
                    $price_h = (string)$h;
                }
                if (empty($sale_price_h) && strpos($lh, 'sale') !== false && strpos($lh, 'price') !== false) {
                    $sale_price_h = (string)$h;
                }
                if (empty($stock_h) && (strpos($lh, 'stock') !== false || strpos($lh, 'qty') !== false)) {
                    $stock_h = (string)$h;
                }
            }
        }
        $match_hint =
            ($price_h ? "MATCHED REGULAR PRICE HEADER: '{$price_h}'. " : "") .
            ($sale_price_h ? "MATCHED SALE PRICE HEADER: '{$sale_price_h}'. " : "") .
            ($stock_h ? "MATCHED STOCK HEADER: '{$stock_h}'. " : "");

        $system_prompt = "You are a WordPress CSV import planner. Read the instruction and CSV headers.\n" .
            "Return ONLY valid JSON (no markdown, no commentary).\n\n" .
            "IMPORT TYPE — Set \"post_type\" to EXACTLY one string from the JSON array ALLOWED_POST_TYPE_LABELS below (copy spelling and spacing). " .
            "You may also use the internal module id from parentheses in POST TYPES (e.g. WooCommerce) — the server maps it to the label. " .
            "Do not use generic words alone (e.g. Posts, product, WooCommerce) unless they are a full label or valid internal id from the list.\n" .
            "Example: WooCommerce catalog items → \"post_type\": \"WooCommerce Product\".\n\n" .
            "ALLOWED_POST_TYPE_LABELS (pick one for post_type):\n" . $allowed_labels_json . "\n\n" .
            "POST TYPES (detail):\n" . $targetContext . "\n" .
            "CSV HEADERS: " . $header_preview . "\n\n" .
            "HINT: " . $match_hint . "If the user refers to concepts like 'Price' or 'Stock', use these pre-matched headers if available. " . 
            "IMPORTANT: WooCommerce products use '_sale_price' (for Sale Price), '_regular_price' (Regular Price), and '_stock' (Stock). " .
            "CRITICAL: NEVER use the 'stock' header for 'price' calculations.\n\n" .
            "JSON SCHEMA:\n" .
            "{\n" .
            "  \"post_type\": \"\",\n" .
            "  \"mode\": \"Insert\" or \"Update\",\n" .
            "  \"file_iteration\": 1,\n" .
            "  \"rollback\": false,\n" .
            "  \"media_handling\": {\n" .
            "    \"use_ExistingImage\": true,\n" .
            "    \"overwriteImage\": false,\n" .
            "    \"newImage\": false\n" .
            "  },\n" .
            "  \"header_renames\": {},\n" .
            "  \"suggested_map\": {\n" .
            "    \"_sale_price\": \"return round( (float) str_replace(',','', \$data['YOUR_PRICE_HEADER']) * 0.5, 2);\"\n" .
            "  },\n" .
            "  \"ai_skip_condition\": \"return (int)\$data['YOUR_STOCK_HEADER'] < 10 ? 'skip:Stock check failed' : 'proceed';\",\n" .
            "  \"filters\": [\n" .
            "    { \"element\": \"{$first_h}\", \"rule\": \"is_empty\", \"value\": \"\", \"condition\": \"AND\" }\n" .
            "  ]\n" .
            "}\n\n" .
            "Rules:\n" .
            "- file_iteration: user-requested batch size (e.g. 1).\n" .
            "- media_handling: If the user wants to always download/create NEW media files (not reuse existing library images), set newImage: true and use_ExistingImage: false.\n" .
            "- WooCommerce products: use post_type \"WooCommerce Product\". For sale price = 50% of regular price, map to \"_sale_price\".\n" .
            "- rollback: true only if the user wants backup / safe rollback before import.\n" .
            "- suggested_map: JSON object where keys are WordPress field names and values are PHP snippets (strings) starting with \"return ...;\". DO NOT wrap in a function block or define a new function name; just return the value. CRITICAL: When iterating through \$data['header_name'] in formulas, you MUST use the EXACT strings from the CSV HEADERS list above. NEVER use get_post_meta() or fetch existing database values. ALWAYS use the provided \$data['YOUR_CSV_HEADER'] for calculations. CRITICAL: For multi-value fields (like WooCommerce 'upsell_ids' or 'crosssell_ids'), you MUST separate multiple values with a pipe ('|') instead of a comma. Example: return 'ID1|ID2';\n" .
            "- WooCommerce Field Guide: Use '_sale_price' for Sale Price, '_regular_price' for Regular Price, and '_stock' for Stock. CRITICAL: Ensure you match 'Price' instructions to Price headers and 'Stock' instructions to Stock headers. Do not mix them up.\n" .
            "- ai_skip_condition: used for \"Skip Row\" logic. Provide a PHP snippet using \$data['HeaderName'] that returns a string starting with 'skip:Reason' if the row should be skipped (e.g. \"return (int)\$data['stock'] <= 0 ? 'skip:Out of stock' : 'proceed';\"). CRITICAL: Always use the exact header name from the CSV HEADERS list. Return 'proceed' if it should NOT be skipped. Omit if not requested.\n" .
            "- filters: row skip rules; element must be an actual CSV header.\n";

        $full_prompt = $system_prompt . "\n\nUser instruction:\n" . $user_prompt;
        $builder = wp_ai_client_prompt($full_prompt);
        if (!empty($provider)) {
            $builder->using_provider($provider);
        }
        if (!empty($model)) {
            $builder->using_model_preference($model);
        }
        $ai_result = $builder->generate_text();
        

        if (is_wp_error($ai_result)) {
            return $ai_result;
        }
        if (empty($ai_result) || !is_string($ai_result)) {
            return new \WP_Error('logic_failed', __('AI returned an empty response for import planning.', 'wp-ultimate-csv-importer-pro'));
        }

        $cleaned = trim(preg_replace('/^```(?:json)?\s*|\s*```$/m', '', str_replace(['```json', '```'], '', trim($ai_result))));
        $decoded = json_decode($cleaned, true);

        if (!$decoded || !isset($decoded['post_type'])) {
            return new \WP_Error('logic_failed', __('Phase 1 import planning failed.', 'wp-ultimate-csv-importer-pro'));
        }

        $resolved_post_type = $this->resolve_import_post_type_key(
            $decoded['post_type'],
            $available_post_types
        );
        if (is_wp_error($resolved_post_type)) {
            return $resolved_post_type;
        }
        $decoded['post_type'] = $resolved_post_type;

        $mode = isset($decoded['mode']) ? $decoded['mode'] : 'Insert';
        if (is_string($mode) && strcasecmp($mode, 'update') === 0) {
            $mode = 'Update';
        } else {
            $mode = 'Insert';
        }
        $decoded['mode'] = $mode;

        $decoded['file_iteration'] = isset($decoded['file_iteration']) ? max(1, min(50, (int) $decoded['file_iteration'])) : 5;

        if (!isset($decoded['media_handling']) || !is_array($decoded['media_handling'])) {
            $decoded['media_handling'] = [
                'use_ExistingImage' => true,
                'overwriteImage'    => false,
                'newImage'          => false,
            ];
        }

        $decoded['media_handling'] = $this->maybe_apply_new_media_from_prompt($decoded['media_handling'], $user_prompt);

        $decoded['rollback'] = !empty($decoded['rollback']);

        if (!isset($decoded['suggested_map']) || !is_array($decoded['suggested_map'])) {
            $decoded['suggested_map'] = [];
        }
        if (!isset($decoded['header_renames']) || !is_array($decoded['header_renames'])) {
            $decoded['header_renames'] = [];
        }
        if (!isset($decoded['filters']) || !is_array($decoded['filters'])) {
            $decoded['filters'] = [];
        }
        if (!isset($decoded['ai_skip_condition'])) {
            $decoded['ai_skip_condition'] = '';
        }

        // 1. Normalize formula headers for ALL fields in suggested_map
        if (isset($decoded['suggested_map']) && is_array($decoded['suggested_map'])) {
            foreach ($decoded['suggested_map'] as $key => $val) {
                if (is_string($val)) {
                    $decoded['suggested_map'][$key] = $this->normalize_formula_headers($val, $headers);
                }
            }
        }

        // 2. Normalize headers in ai_skip_condition
        if (!empty($decoded['ai_skip_condition'])) {
            $decoded['ai_skip_condition'] = $this->normalize_formula_headers($decoded['ai_skip_condition'], $headers);
        }

        return $decoded;
    }

    protected function apply_manual_logic_overrides(&$decoded, $user_prompt, $price_h, $stock_h) {
        return; // Deprecated: AI handles logic dynamically now
        $lp = strtolower($user_prompt);

        // 1. Price Adjustment Override — detect intent and compute the correct multiplier
        $is_increase = (bool) preg_match('/\b(?:increase|raise|boost|add|bump)\b/i', $user_prompt);
        $is_decrease = (bool) preg_match('/\b(?:decrease|reduce|lower|cut|drop|discount)\b/i', $user_prompt);

        if (preg_match('/(\d+(?:\.\d+)?)\s*%/i', $user_prompt, $pm)) {
            $percent    = (float) $pm[1];
            $multiplier = null;

            if ($is_increase) {
                $multiplier = round(1 + $percent / 100, 10); // e.g. 10% → 1.10
            } elseif ($is_decrease) {
                $multiplier = round(1 - $percent / 100, 10); // e.g. 10% → 0.90
            }

            $touches_regular = strpos($lp, 'regular price') !== false || strpos($lp, 'regular_price') !== false;
            $touches_sale    = strpos($lp, 'sale price') !== false    || strpos($lp, 'sale_price') !== false;

            if ($multiplier !== null) {
                // Increase or decrease: apply to each mentioned price field
                if ($touches_regular && !empty($price_h)) {
                    $decoded['suggested_map']['_regular_price'] =
                        "return round((float)str_replace(',','',\$data['{$price_h}']) * {$multiplier}, 2);";
                }
                if ($touches_sale) {
                    $src_h = !empty($sale_price_h) ? $sale_price_h : $price_h;
                    if (!empty($src_h)) {
                        $decoded['suggested_map']['_sale_price'] =
                            "return round((float)str_replace(',','',\$data['{$src_h}']) * {$multiplier}, 2);";
                    }
                }
            } elseif ($touches_sale && $touches_regular && !empty($price_h)) {
                // "Set sale price to X% of regular price" → multiply by X/100
                $set_mult = round($percent / 100, 10);
                $decoded['suggested_map']['_sale_price'] =
                    "return round((float)str_replace(',','',\$data['{$price_h}']) * {$set_mult}, 2);";
            }
        }

        // 2. Skip Row Override (e.g. skip if stock below 10)
        if (strpos($lp, 'skip') !== false && (strpos($lp, 'stock') !== false || strpos($lp, 'qty') !== false) && !empty($stock_h)) {
            $dist_above = -1;
            $dist_below = -1;
            $dist_zero = -1;
            $threshold_above = -1;
            $threshold_below = -1;

            $skip_pos = stripos($user_prompt, 'skip');

            if (preg_match('/(?:above|greater than|more than|>)\s*(\d+)/i', $user_prompt, $sm, PREG_OFFSET_CAPTURE)) {
                $pos = $sm[0][1];
                $threshold_above = (int)$sm[1][0];
                $dist_above = abs($pos - $skip_pos);
            }
            if (preg_match('/(?:below|less than|lower than|<)\s*(\d+)/i', $user_prompt, $sm, PREG_OFFSET_CAPTURE)) {
                $pos = $sm[0][1];
                $threshold_below = (int)$sm[1][0];
                $dist_below = abs($pos - $skip_pos);
            }
            if (preg_match('/(?:is|==|=|equals)?\s*\b0\b/i', $user_prompt, $sm, PREG_OFFSET_CAPTURE)) {
                $pos = $sm[0][1];
                $dist_zero = abs($pos - $skip_pos);
            }

            $min_dist = PHP_INT_MAX;
            $choice = '';

            if ($dist_above !== -1 && $dist_above < $min_dist) {
                $min_dist = $dist_above;
                $choice = 'above';
            }
            if ($dist_below !== -1 && $dist_below < $min_dist) {
                $min_dist = $dist_below;
                $choice = 'below';
            }
            if ($dist_zero !== -1 && $dist_zero < $min_dist) {
                $min_dist = $dist_zero;
                $choice = 'zero';
            }

            if ($choice === 'above') {
                $decoded['ai_skip_condition'] = "return (int)\$data['{$stock_h}'] > {$threshold_above} ? 'skip:Stock check (>{$threshold_above})' : 'proceed';";
            } elseif ($choice === 'below') {
                $decoded['ai_skip_condition'] = "return (int)\$data['{$stock_h}'] < {$threshold_below} ? 'skip:Stock check (<{$threshold_below})' : 'proceed';";
            } elseif ($choice === 'zero') {
                $decoded['ai_skip_condition'] = "return (int)\$data['{$stock_h}'] <= 0 ? 'skip:Out of stock' : 'proceed';";
            }
        }
    }

    /**
     * Phase 2: same pipeline as wp_ajax_wp_ai_field_mapping (exact match + AI), then nest by section and attach ->code formulas.
     */
    protected function get_mapping_analysis($user_prompt, $post_type, $headers, $sample_rows, $logic_from_phase1, $provider = '', $model = '') {
        $mapping_extension = MappingExtension::getInstance();
        $fields_raw = $mapping_extension->mapping_fields($post_type);

        $flat_fields = $this->flatten_mapping_extension_fields_for_ai($fields_raw);
        if (empty($flat_fields)) {
            return new \WP_Error('no_mapping_fields', __('No mapping fields available for this import type.', 'wp-ultimate-csv-importer-pro'));
        }

        $headers = array_map(function ($h) {
            return ltrim((string) $h, "\xEF\xBB\xBF");
        }, $headers);

        $save_mapping = SaveMapping::getInstance();
        $exact_mapping = $save_mapping->wp_ai_field_mapping_exact_match($flat_fields, $headers);

        $unmatched_fields = [];
        foreach ($flat_fields as $field) {
            if (!isset($exact_mapping[$field['name']])) {
                $unmatched_fields[] = $field;
            }
        }

        $ai_mapping = [];
        if (!empty($unmatched_fields)) {
            $extra = '';
            $renames = $logic_from_phase1['header_renames'] ?? [];
            if (!empty($renames)) {
                $extra .= "\n\nHeader aliases (optional hints): " . wp_json_encode($renames);
            }
            $suggested_map = $logic_from_phase1['suggested_map'] ?? [];
            if (!empty($suggested_map)) {
                $extra .= "\n\nPlanned formulas (fields may map to source columns first): " . wp_json_encode($suggested_map);
            }
            $mapping_instruction = $user_prompt . $extra;
            $prompt = $save_mapping->wp_ai_field_mapping_build_prompt($unmatched_fields, $headers, $sample_rows, $post_type, $mapping_instruction);

            if (function_exists('wp_ai_client_prompt')) {
                $builder = wp_ai_client_prompt($prompt);
                if (!empty($model)) {
                    $builder->using_model_preference($model);
                }
                $ai_result_raw = $builder->generate_text();
                if (!is_wp_error($ai_result_raw) && !empty($ai_result_raw)) {
                    $ai_mapping = $save_mapping->wp_ai_field_mapping_parse_response($ai_result_raw);
                }
            }
        }

        $final_mapping = [];
        $ai_keys_lower = array_change_key_case($ai_mapping, CASE_LOWER);

        foreach ($flat_fields as $field) {
            $name = $field['name'];
            $name_lower = strtolower($name);

            if (isset($exact_mapping[$name])) {
                $final_mapping[$name] = $exact_mapping[$name];
            } elseif (isset($ai_keys_lower[$name_lower])) {
                foreach ($ai_mapping as $ai_key => $ai_data) {
                    if (strtolower((string) $ai_key) === $name_lower) {
                        $final_mapping[$name] = $ai_data;
                        break;
                    }
                }
            }
            if (!isset($final_mapping[$name])) {
                $final_mapping[$name] = [
                    'value'      => null,
                    'confidence' => 0,
                ];
            }
        }

        $nested = $this->nested_mapping_from_wp_ai_flat($flat_fields, $final_mapping);

        // Map AI-suggested formulas to their correct section (e.g. ECOMMETA)
        $suggested_map = $logic_from_phase1['suggested_map'] ?? [];
        $rk_map = $this->get_plugin_id_to_result_key_map();
        $field_to_rk = [];
        foreach ($flat_fields as $f) {
            $pid = $f['pluginId'] ?? 'unknown';
            if (isset($rk_map[$pid])) {
                $rk = $rk_map[$pid];
                $name = (string) $f['name'];
                $field_to_rk[$name] = ['rk' => $rk, 'orig' => $name];
                $field_to_rk[ltrim($name, '_')] = ['rk' => $rk, 'orig' => $name];
            }
        }

        foreach ($suggested_map as $wp_field => $formula) {
            if (empty($wp_field) || !is_string($formula)) {
                continue;
            }
            $orig_wp_field = (string) $wp_field;
            $formula = $this->normalize_formula_headers((string) $formula, $headers);
            $found_section = null;
            $final_field_name = $orig_wp_field;


            // 1. Try exact match in already mapped sections
            foreach ($nested as $section => &$sec_fields) {
                if (isset($sec_fields[$orig_wp_field])) {
                    $found_section = $section;
                    break;
                }
            }
            unset($sec_fields);

            // 2. Try normalized match (strip leading underscore)
            if (!$found_section) {
                $norm_wp_field = ltrim($orig_wp_field, '_');
                foreach ($nested as $section => &$sec_fields) {
                    if (isset($sec_fields[$norm_wp_field])) {
                        $found_section = $section;
                        $final_field_name = $norm_wp_field;
                        break;
                    }
                }
                unset($sec_fields);
            }

            // 3. Look up in the metadata catalog (even if not yet mapped)
            if (!$found_section) {
                if (isset($field_to_rk[$orig_wp_field])) {
                    $found_section = $field_to_rk[$orig_wp_field]['rk'];
                    $final_field_name = $field_to_rk[$orig_wp_field]['orig'];
                } elseif (isset($field_to_rk[ltrim($orig_wp_field, '_')])) {
                    $norm_wp_field = ltrim($orig_wp_field, '_');
                    $found_section = $field_to_rk[$norm_wp_field]['rk'];
                    $final_field_name = $field_to_rk[$norm_wp_field]['orig'];
                }
            }

            // Apply to results
            $target_section = $found_section ?: 'CORE';
            if (!isset($nested[$target_section])) {
                $nested[$target_section] = [];
            }
            // Ensure UI treats this field as "Header Manipulation" when a ->code formula exists.
            // Force it even if it was already mapped to a CSV header.
            $nested[$target_section][$final_field_name] = 'Header Manipulation';
            $nested[$target_section][$final_field_name . '->code'] = $formula;
        }

        return [
            'mapped_fields' => $nested,
            'mapped_filter' => $this->normalize_row_filters($logic_from_phase1['filters'] ?? []),
        ];
    }

    protected function get_mapping_data($post_type, $file_hash) {
        $file_dir = $this->folder_path . '/' . $file_hash;
        $file_path = $file_dir . '/' . $file_hash;

        if (!file_exists($file_path)) {
            return new \WP_Error('file_not_found', __('CSV file not found for mapping.', 'wp-ultimate-csv-importer-pro'));
        }

        $headers = [];
        if (($h = fopen($file_path, "r")) !== FALSE) {
            $headers = fgetcsv($h);
            fclose($h);
        }

        if (empty($headers)) {
            return new \WP_Error('no_headers', __('Could not read CSV headers.', 'wp-ultimate-csv-importer-pro'));
        }

        $headers = array_map('trim', $headers);

        $mapping_extension = MappingExtension::getInstance();
        $fields = $mapping_extension->mapping_fields($post_type);

        $total_rows = 0;
        if (($h = fopen($file_path, "r")) !== FALSE) {
            while (fgetcsv($h) !== FALSE) {
                $total_rows++;
            }
            fclose($h);
            $total_rows--;
        }

        return [
            'csv_fields'    => $headers,
            'fields'        => $fields,
            'total_records' => $total_rows,
            'show_template' => false
        ];
    }

    protected function is_xml_file($file_path) {
        $handle = fopen($file_path, 'r');
        $sample = fread($handle, 512);
        fclose($handle);
        return (strpos($sample, '<?xml') !== false || strpos($sample, '<rss') !== false || (strpos($sample, '<') !== false && strpos($sample, '>') !== false && preg_match('/^\s*<[^!>]/', $sample)));
    }

    protected function convert_xml_to_csv($file_path) {
        $xml = simplexml_load_file($file_path);
        if ($xml === false) {
            return new \WP_Error('xml_parse_error', __('Failed to parse XML file.', 'wp-ultimate-csv-importer-pro'));
        }

        $all_records = [];
        $all_headers = [];

        $children = $xml->children();
        if ($children->count() === 0) {
            return new \WP_Error('no_records', __('XML file contains no records.', 'wp-ultimate-csv-importer-pro'));
        }

        foreach ($children as $child) {
            $flat = $this->flatten_xml_node($child);
            if (!empty($flat)) {
                $all_records[] = $flat;
                $all_headers = array_unique(array_merge($all_headers, array_keys($flat)));
            }
        }

        if (empty($all_records)) {
            return new \WP_Error('no_data', __('No translatable data found in XML.', 'wp-ultimate-csv-importer-pro'));
        }

        $csv_output = implode(',', array_map(function($h) { return '"' . str_replace('"', '""', $h) . '"'; }, $all_headers)) . "\n";
        foreach ($all_records as $record) {
            $row = [];
            foreach ($all_headers as $header) {
                $val = isset($record[$header]) ? $record[$header] : '';
                $row[] = '"' . str_replace('"', '""', (string)$val) . '"';
            }
            $csv_output .= implode(',', $row) . "\n";
        }

        return $csv_output;
    }

    protected function flatten_xml_node($node, $prefix = '') {
        $result = [];

        foreach ($node->attributes() as $name => $value) {
            $attr_path = $prefix ? $prefix . '@' . $name : '@' . $name;
            $result[$attr_path] = (string)$value;
        }

        $children = $node->children();
        if ($children->count() > 0) {
            foreach ($children as $name => $child) {
                $child_path = $prefix ? $prefix . '/' . $name : $name;
                $flattened = $this->flatten_xml_node($child, $child_path);
                foreach ($flattened as $k => $v) {
                    $result[$k] = $v;
                }
            }
        } else {
            if ($prefix !== '') {
                $result[$prefix] = trim((string)$node);
            }
        }
        return $result;
    }

    protected function is_excel_file($file_path) {
        $handle = fopen($file_path, 'r');
        $bytes = fread($handle, 8);
        fclose($handle);
        // PK\x03\x04 is XLSX (ZIP based)
        // \xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1 is XLS (Compound File Binary Format)
        if (strpos($bytes, "PK\x03\x04") === 0 || strpos($bytes, "\xD0\xCF\x11\xE0") === 0) {
            return true;
        }
        return false;
    }

    protected function is_tsv_file($file_path) {
        $handle = fopen($file_path, 'r');
        $first_line = fgets($handle);
        fclose($handle);
        return (strpos($first_line, "\t") !== false);
    }

    protected function convert_excel_to_csv($file_path) {
        if (!class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
            return new \WP_Error('missing_library', __('Excel library (PhpSpreadsheet) not found.', 'wp-ultimate-csv-importer-pro'));
        }
        try {
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file_path);
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
            $writer->setDelimiter(',');
            $writer->setEnclosure('');
            $writer->setLineEnding("\r\n");
            $writer->setSheetIndex(0); 
            
            ob_start();
            $writer->save('php://output');
            $csv_content = ob_get_clean();
            
            return $csv_content;
        } catch (\Exception $e) {
            return new \WP_Error('excel_convert_error', $e->getMessage());
        }
    }

    protected function convert_tsv_to_csv($file_path) {
        if (($handle = fopen($file_path, "r")) !== FALSE) {
            $csv_output = "";
            while (($data = fgetcsv($handle, 0, "\t")) !== FALSE) {
                $f = fopen('php://memory', 'r+');
                fputcsv($f, $data);
                rewind($f);
                $csv_output .= stream_get_contents($f);
                fclose($f);
            }
            fclose($handle);
            return $csv_output;
        }
        return new \WP_Error('tsv_read_error', __('Failed to read TSV file.', 'wp-ultimate-csv-importer-pro'));
    }
}
