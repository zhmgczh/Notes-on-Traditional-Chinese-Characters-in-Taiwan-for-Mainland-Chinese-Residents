<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/


namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class Semantic_Ai_Duplicate_Detector {

    protected $threshold = 0.80;

    /**
     * Semantic_Ai_Duplicate_Detector constructor.
     *
     * @param float $threshold
     */
    public function __construct($threshold = 0.80) {
        $this->threshold = $threshold;
    }

    /**
     * Get the fields to check for duplicate detection.
     * For semantic similarity, we use a single field.
     *
     * @param string $post_type
     * @return string
     */
    public function get_fields($post_type) {
        $post_type = strtolower(trim($post_type));
        $fields = [
            'post' => 'post_title',
            'posts' => 'post_title',
            'page' => 'post_title',
            'pages' => 'post_title',
            'product' => 'PRODUCTSKU',
            'product_variation' => 'PRODUCTSKU',
            'users' => 'user_email',
            'user' => 'user_email',
            'profilepress' => 'user_email',
            'profilepress users' => 'user_email'
        ];
        
        if (isset($fields[$post_type])) {
            return $fields[$post_type];
        }

        // Fallback for Custom Post Types - almost all have post_title
        // We exclude specific modules that use different primary fields
        $non_title_modules = ['users', 'user', 'profilepress', 'profilepress users', 'comments', 'gfentries', 'customerreviews'];
        if (!in_array($post_type, $non_title_modules)) {
            return 'post_title';
        }

        return '';
    }

    /**
     * Extract cleaned keywords from text for hashing.
     *
     * @param string $title
     * @return array
     */
    public function extract_tokens($title) {
        $title = strtolower($title);
        $words = preg_split('/[\s\-]+/', $title, -1, PREG_SPLIT_NO_EMPTY);
        
        $noise_words = ['with', 'and', 'the', 'for', 'was', 'were', 'his', 'her', 'its'];
        $cleaned = [];

        foreach ($words as $word) {
            $word = trim($word);
            if (empty($word)) continue;

            // Remove pure numbers
            if (is_numeric($word)) continue;
            
            // Remove alphanumeric chip/model patterns (e.g. a16, m2)
            if (preg_match('/^[a-z]\d+$/i', $word) || preg_match('/^\d+[a-z]$/i', $word)) continue;
            
            // Words shorter than 2 characters (was 3)
            if (strlen($word) < 2) continue;
            
            // Common noise words
            if (in_array($word, $noise_words)) continue;
            
            $cleaned[] = $word;
        }

        // Fallback: If everything was filtered out, keep the original words (excluding very short ones)
        if (empty($cleaned) && !empty($words)) {
            foreach ($words as $word) {
                if (strlen($word) >= 2) {
                    $cleaned[] = $word;
                }
            }
        }

        return array_unique($cleaned);
    }

    /**
     * Generate a 64-bit SimHash fingerprint for the given text.
     *
     * @param string $text
     * @return string 64-bit binary string
     */
    public function generate_simhash( $text ) {
        $tokens = $this->extract_tokens($text);
        if (empty($tokens)) {
            // If no tokens, use a hash of the full normalized text to avoid collisions
            $full_hash = md5($this->normalize($text));
            $binary = "";
            for ($i = 0; $i < 16; $i++) {
                $binary .= str_pad(base_convert($full_hash[$i], 16, 2), 4, '0', STR_PAD_LEFT);
            }
            return str_pad($binary, 64, '0');
        }

        $v = array_fill(0, 64, 0);

        foreach ($tokens as $token) {
            // Generate a 64-bit hash for the token
            $hash = md5($token);
            $h1 = hexdec(substr($hash, 0, 8));
            $h2 = hexdec(substr($hash, 8, 8));
            
            for ($i = 0; $i < 32; $i++) {
                if (($h1 >> $i) & 1) $v[$i]++; else $v[$i]--;
            }
            for ($i = 0; $i < 32; $i++) {
                if (($h2 >> $i) & 1) $v[$i + 32]++; else $v[$i + 32]--;
            }
        }

        $fingerprint = "";
        for ($i = 0; $i < 64; $i++) {
            $fingerprint .= ($v[$i] > 0) ? "1" : "0";
        }

        return $fingerprint;
    }

    /**
     * Calculate similarity based on Hamming Distance of SimHash fingerprints.
     *
     * @param string $hash1
     * @param string $hash2
     * @return float
     */
    public function simhash_similarity( $hash1, $hash2 ) {
        $distance = 0;
        for ($i = 0; $i < 64; $i++) {
            if ($hash1[$i] !== $hash2[$i]) {
                $distance++;
            }
        }
        return 1 - ($distance / 64);
    }

    public function normalize($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9 ]/', '', $text);
        return trim($text);
    }

    /**
     * Semantic similarity using PHP
     */
    public function similarity($text1, $text2) {

        $text1 = $this->normalize($text1);
        $text2 = $this->normalize($text2);

        if (empty($text1) || empty($text2)) {
            return ($text1 === $text2) ? 1.0 : 0.0;
        }

        similar_text($text1, $text2, $percent);

        return $percent / 100;
    }

    /**
     * Detect similarity
     */
    public function detect($text1, $text2) {
        // Step 0: Exact Match
        if (trim($text1) === trim($text2)) {
            error_log("AI DETECTOR: EXACT MATCH FOUND!");
            return [
                'type'         => 'exact_match',
                'score'        => 1.0,
                'is_duplicate' => true,
            ];
        }

        // Step 1: Static Vector Hashing (SimHash)
        $hash1 = $this->generate_simhash( $text1 );
        $hash2 = $this->generate_simhash( $text2 );
        $simhash_score = $this->simhash_similarity( $hash1, $hash2 );

        // Step 2: Fallback to PHP similarity
        $score = $this->similarity($text1, $text2);
        
        // Take the maximum of both scores for better accuracy
        $final_score = max($simhash_score, $score);

        return [
            'type'  => $simhash_score >= $score ? 'static_vector_hashing' : 'semantic_fallback',
            'score' => $final_score,
            'is_duplicate' => $final_score >= $this->threshold
        ];
    }
}