<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

use WordPress\AiClient\Providers\Models\Enums\CapabilityEnum;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI-powered duplicate detector using true Vector Hashing (Embeddings).
 *
 * Uses the WordPress Beta AI Client to generate embedding vectors
 * and calculates similarity using cosine similarity.
 */
class Vector_Ai_Duplicate_Detector {

    protected $threshold = 0.85;
    protected $model_id = "";

    /**
     * Get the fields to check for duplicate detection.
     * For vector hashing, we use two fields.
     *
     * @param string $post_type
     * @return array
     */
    public function get_fields($post_type) {
        $fields = [
            'post' => ['post_title', 'post_content'],
            'page' => ['post_title', 'post_content'],
            'product' => ['post_title', 'PRODUCTSKU'],
            'product_variation' => ['post_title', 'PRODUCTSKU'],
            'Users' => ['user_login', 'user_email'],
            'users' => ['user_login', 'user_email'],
            'user' => ['user_login', 'user_email']
        ];
        return $fields[$post_type] ?? array();
    }

    /**
     * Vector_Ai_Duplicate_Detector constructor.
     *
     * @param string $model_id
     * @param float  $threshold
     */
    public function __construct( $model_id = "", $threshold = 0.85 ) {
        $this->model_id  = $model_id;
        $this->threshold = $threshold;
    }

    /**
     * Extract cleaned keywords from text for hashing.
     * Uses the optimized logic provided for product systems.
     *
     * @param string $title
     * @return array
     */
    public function extract_tokens($title) {
        $title = strtolower($title);
        $words = preg_split('/[\s\-]+/', $title, -1, PREG_SPLIT_NO_EMPTY);
        
        $noise_words = ['with', 'and', 'the'];
        $cleaned = [];

        foreach ($words as $word) {
            // Remove pure numbers
            if (is_numeric($word)) continue;
            
            // Remove alphanumeric chip/model patterns (e.g. a16, m2)
            if (preg_match('/^[a-z]\d+$/i', $word) || preg_match('/^\d+[a-z]$/i', $word)) continue;
            
            // Words shorter than 3 characters
            if (strlen($word) < 3) continue;
            
            // Common noise words
            if (in_array($word, $noise_words)) continue;
            
            $cleaned[] = $word;
        }

        return array_unique($cleaned);
    }

    /**
     * Generate a 64-bit SimHash fingerprint for the given text.
     *
     * @param string $text
     * @return string 64-bit binary string
     */
    public function generate_simhash( $text ) {
        $tokens = $this->extract_tokens($text);
        if (empty($tokens)) {
            return str_repeat('0', 64);
        }

        $v = array_fill(0, 64, 0);

        foreach ($tokens as $token) {
            // Generate a 64-bit hash for the token using MD5
            $hash = md5($token);
            $h1 = hexdec(substr($hash, 0, 8));
            $h2 = hexdec(substr($hash, 8, 8));
            
            // Treat as a 64-bit combined value
            for ($i = 0; $i < 32; $i++) {
                if (($h1 >> $i) & 1) $v[$i]++; else $v[$i]--;
            }
            for ($i = 0; $i < 32; $i++) {
                if (($h2 >> $i) & 1) $v[$i + 32]++; else $v[$i + 32]--;
            }
        }

        $fingerprint = "";
        for ($i = 0; $i < 64; $i++) {
            $fingerprint .= ($v[$i] > 0) ? "1" : "0";
        }

        return $fingerprint;
    }

    /**
     * Calculate similarity based on Hamming Distance of SimHash fingerprints.
     *
     * @param string $hash1
     * @param string $hash2
     * @return float
     */
    public function simhash_similarity( $hash1, $hash2 ) {
        $distance = 0;
        for ($i = 0; $i < 64; $i++) {
            if ($hash1[$i] !== $hash2[$i]) {
                $distance++;
            }
        }
        return 1 - ($distance / 64);
    }

    /**
     * Get embedding vector for a text string using the WordPress Beta AI Client.
     *
     * @param string $text The input text to embed.
     * @return float[]|false Array of floats (embedding vector) or false on failure.
     */
    public function get_embedding( $text ) {
        $cache_key = 'smk_wpai_emb_' . \md5( $text . '||' . $this->model_id );
        $cached    = \get_transient( $cache_key );

        if ( $cached !== false ) {
            return $cached;
        }

        if ( ! \function_exists( 'wp_ai_client_prompt' ) ) {
            return false;
        }

        try {
            $builder = \wp_ai_client_prompt();
            $builder->with_text( $text );

            // Use the provided model if set, otherwise prefer high-performance embedding models
            $preferred_models = ! empty( $this->model_id ) ? [ $this->model_id ] : [ 'text-embedding-3-small', 'text-embedding-004' ];
            $builder->using_model_preference( ...$preferred_models );

            // Attempt to generate embedding result
            $result = $builder->generate_result( CapabilityEnum::embeddingGeneration() );

            if ( \is_wp_error( $result ) ) {
                return false;
            }

            $additional_data = $result->getAdditionalData();
            if ( ! empty( $additional_data['embedding'] ) && \is_array( $additional_data['embedding'] ) ) {
                $embedding = $additional_data['embedding'];
                \set_transient( $cache_key, $embedding, 7 * \DAY_IN_SECONDS );
                return $embedding;
            }

            return false;

        } catch ( \Exception $e ) {
            return false;
        }
    }

    /**
     * Cosine similarity between two embedding vectors.
     *
     * @param float[] $a
     * @param float[] $b
     * @return float Similarity score between 0 and 1.
     */
    public function cosine_similarity( $a, $b ) {
        if ( ! $a || ! $b || \count( $a ) !== \count( $b ) ) {
            return 0.0;
        }

        $dot   = 0.0;
        $normA = 0.0;
        $normB = 0.0;

        foreach ( $a as $i => $val ) {
            $dot   += $val * $b[ $i ];
            $normA += $val * $val;
            $normB += $b[ $i ] * $b[ $i ];
        }

        if ( $normA == 0 || $normB == 0 ) {
            return 0.0;
        }

        return $dot / ( \sqrt( $normA ) * \sqrt( $normB ) );
    }

    /**
     * Detect similarity between two texts.
     *
     * @param string $text1
     * @param string $text2
     * @return array{type:string, score:float, is_duplicate:bool}
     */
    public function detect( $text1, $text2 ) {
        // Method 1: AI Embeddings (True Vector Comparison) - Primary
        $emb1 = $this->get_embedding( $text1 );
        $emb2 = $this->get_embedding( $text2 );

        if ( $emb1 !== false && $emb2 !== false ) {
            $score = $this->cosine_similarity( $emb1, $emb2 );
            return [
                'type'         => 'vector_hashing_ai_embeddings',
                'score'        => $score,
                'is_duplicate' => $score > $this->threshold,
            ];
        }

        // Method 2: Vector Hashing (SimHash - Locality Sensitive Hashing) - Fallback
        $hash1 = $this->generate_simhash( $text1 );
        $hash2 = $this->generate_simhash( $text2 );
        $simhash_score = $this->simhash_similarity( $hash1, $hash2 );

        if ( $simhash_score > 0.0 ) {
             return [
                'type'         => 'vector_hashing_simhash',
                'score'        => $simhash_score,
                'is_duplicate' => $simhash_score > $this->threshold,
            ];
        }

        // Final Fallback: Local PHP comparison
        $text1_n = $this->extract_tokens( $text1 );
        $text2_n = $this->extract_tokens( $text2 );
        $text1_s = \implode( ' ', $text1_n );
        $text2_s = \implode( ' ', $text2_n );

        \similar_text( $text1_s, $text2_s, $percent );
        $score = $percent / 100;

        return [
            'type'         => 'fallback_similar_text',
            'score'        => $score,
            'is_duplicate' => $score > $this->threshold,
        ];
    }
}