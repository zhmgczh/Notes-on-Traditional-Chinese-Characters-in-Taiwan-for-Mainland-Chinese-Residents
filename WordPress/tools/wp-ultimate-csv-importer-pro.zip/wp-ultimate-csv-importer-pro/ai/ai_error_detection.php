<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/


namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class AIErrorDetection{

    private static $instance = null;
    private $check_links_keys = ['featured_image', '_wp_attached_file','product_url','user_url','thumbnail_id'];
    private $numerical_fields = ['stock', 'quantity'];
    private $option_key_prefix = 'smack_ai_error_detection_';
    private $max_sample_rows = 100;
    private $valid_post_statuses = ['publish', 'draft', 'pending', 'private', 'trash', 'future', 'inherit','Published','Draft'];
    private $date_formats = ['Y-m-d', 'Y-m-d H:i:s', 'm/d/Y', 'd/m/Y', 'Y/m/d', 'd-m-Y', 'm-d-Y', 'Y-d-m', 'd-Y-m', 'd/m/Y H:i', 'm/d/Y H:i:s'];
    private $email_fields = ['user_email', 'comment_author_email','billing_email','shipping_email'];
    private $date_fields = ['post_date', 'post_modified', 'post_date_gmt', 'post_modified_gmt', 'comment_date', 'user_registered'];
    private $wp_usernames = null;
    private $import_type = null;


    private function setImportType($import_type)
    {
        $this->import_type = $import_type;
    }

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new AIErrorDetection();
        }
        return self::$instance;
    }

    public function ai_error_detection_handler()
    {
        $hash_key = isset($_POST['HashKey']) ? \sanitize_key($_POST['HashKey']) : '';
        $import_type = isset($_POST['Types']) ? \sanitize_text_field($_POST['Types']) : '';
        $this->setImportType($import_type);
        
        if (empty($hash_key)) {
            return ['success' => true, 'has_errors' => false, 'data' => []];
        }

        $mappingFields = isset($_POST['MappedFields']) ? $_POST['MappedFields'] : '';
        $mapped_fields = ImportHelpers::decode_mapping_payload($mappingFields);
        if (!\is_array($mapped_fields)) {
            $mapped_fields = [];
        }
        $selected_type = isset($_POST['Types']) ? \sanitize_text_field($_POST['Types']) : 'Posts';

        $field_labels_map = [];

        try {
            $mapping_extension = MappingExtension::getInstance();
            $all_available_fields = $mapping_extension->mapping_fields($selected_type);

            $flatten_labels = function ($fields) use (&$flatten_labels, &$field_labels_map) {
                if (!\is_array($fields)) {
                    return;
                }
                foreach ($fields as $key => $data) {
                    if (\is_array($data)) {
                        if (isset($data['name']) && isset($data['label'])) {
                            $field_labels_map[$data['name']] = $data['label'];
                        } else {
                            $flatten_labels($data);
                        }
                    } elseif (\is_string($data) && \is_string($key) && !empty($data) && !empty($key)) {
                        // Struct: ['Label' => 'internal_name']
                        if (\strpos($data, '_') !== false || \strlen($data) < \strlen($key)) {
                            $field_labels_map[$data] = $key;
                        } else {
                            $field_labels_map[$key] = $data;
                        }
                    }
                }
            };
            $flatten_labels($all_available_fields);
        } catch (\Throwable $e) {
            // Error fetching labels
        }

        $flat_mapped_fields = [];
        if (\is_array($mapped_fields)) {
            foreach ($mapped_fields as $group_name => $group_fields) {
                if (\is_array($group_fields)) {
                    foreach ($group_fields as $wp_field => $csv_header) {
                        if (!empty($wp_field) && $wp_field !== 'AI_CONFIDENCE_SCORES') {
                            $header_value = \is_string($csv_header) ? \trim($csv_header) : '';
                            if ($header_value === 'Array' || empty($header_value) || $header_value === '--select--') {
                                $header_value = '';
                            }
                            
                            // Include all mapped fields to correctly identify "used" CSV headers
                            if (!empty($header_value)) {
                                $flat_mapped_fields[$wp_field] = $header_value;
                            }
                        }
                    }
                }
            }
        }

        $file_data = $this->get_file_data($hash_key);
        $headers = $file_data['headers'] ?? [];
        $rows = $file_data['rows'] ?? [];

        $detection_data = [
            'duplicate_fields'  => $this->check_duplicate_fields($flat_mapped_fields, $field_labels_map),
            'invalid_fields'    => $this->check_invalid_fields($flat_mapped_fields, $headers, $rows, $selected_type, $field_labels_map),
            'broken_links'      => $this->check_broken_links($flat_mapped_fields, $headers, $rows, $field_labels_map),
            'wysiwyg_html_tags' => $this->check_wysiwyg_html_tags($flat_mapped_fields, $headers, $rows, $selected_type, $field_labels_map),
            'empty_rows'        => $this->check_empty_rows($headers, $rows),
            'empty_columns'     => $this->check_empty_columns($flat_mapped_fields, $headers, $rows, $field_labels_map),
            'unused_headers'    => $this->check_unused_headers($flat_mapped_fields, $headers),
        ];

        $has_errors = !empty($detection_data['duplicate_fields'])
            || !empty($detection_data['invalid_fields'])
            || !empty($detection_data['broken_links'])
            || !empty($detection_data['wysiwyg_html_tags'])
            || !empty($detection_data['empty_rows'])
            || !empty($detection_data['empty_columns'])
            || !empty($detection_data['unused_headers']);

        $option_key = $this->option_key_prefix . $hash_key;
        \update_option($option_key, $detection_data, false);

        return [
            'success'   => !$has_errors,
            'has_errors' => $has_errors,
            'data'      => $detection_data,
        ];
    }

    /**
     * Get file path and parse rows by file type (csv, xlsx, xml, tsv).
     * Uses hash_key to fetch file_name from wp_smackcsv_file_events.
     */
    private function get_file_data($hash_key)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'smackcsv_file_events';
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT file_name FROM {$table_name} WHERE hash_key = %s",
            $hash_key
        ));
        if (!$result || empty($result->file_name)) {
            return ['headers' => [], 'rows' => []];
        }
        $file_name = $result->file_name;
        $file_extension = \strtolower(\pathinfo($file_name, PATHINFO_EXTENSION));
        if (empty($file_extension)) {
            $file_extension = 'xml';
        }
        if (\in_array($file_extension, ['xlsx', 'xls', 'json'])) {
            $file_extension = 'xlsx' === $file_extension || 'xls' === $file_extension ? 'xlsx' : 'json';
        }

        $smackcsv_instance = UltimatePro::getInstance();
        $upload_dir = $smackcsv_instance->create_upload_dir();
        $file_path = $upload_dir . $hash_key . '/' . $hash_key;
        if (!\file_exists($file_path) || !\is_readable($file_path)) {
            return ['headers' => [], 'rows' => []];
        }

        if (\version_compare(PHP_VERSION, '8.1.0', '<') && !\ini_get('auto_detect_line_endings')) {
            \ini_set('auto_detect_line_endings', true);
        }

        $validate_file = ValidateFile::getInstance();
        $headers = [];
        $rows = [];
        $delim = ',';
        $detected_delim = $validate_file->getFileDelimiter($file_path, 5);
        if ($detected_delim) {
            $delim = ($detected_delim === '\t') ? "\t" : $detected_delim;
        }

        if ($file_extension === 'csv' || $file_extension === 'txt') {
            if ($delim === "\t") {
                $lines = \file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (!empty($lines)) {
                    $headers = \array_map('trim', \explode("\t", $lines[0]));
                    $count = 0;
                    for ($i = 1; $i < \count($lines) && $count < $this->max_sample_rows; $i++) {
                        $vals = \array_map('trim', \explode("\t", $lines[$i]));
                        if (\count($vals) === \count($headers)) {
                            $rows[] = \array_combine($headers, $vals);
                            $count++;
                        }
                    }
                }
            } else {
                $h = \fopen($file_path, 'r');
                if ($h) {
                    $row0 = \fgetcsv($h, 0, $delim, '"', '\\');
                    if ($row0) {
                        $headers = \array_map('trim', $row0);
                        $header_count = \count($headers);
                        $count = 0;
                        while (($data = \fgetcsv($h, 0, $delim, '"', '\\')) !== false && $count < $this->max_sample_rows) {
                            if (!empty(\array_filter($data))) {
                                $vals = \array_map('trim', \array_slice($data, 0, $header_count));
                                if (\count($vals) < $header_count) {
                                    $vals = \array_pad($vals, $header_count, '');
                                }
                                $rows[] = \array_combine($headers, $vals);
                                $count++;
                            }
                        }
                    }
                    \fclose($h);
                }
            }
        } elseif ($file_extension === 'tsv') {
            $lines = \file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (!empty($lines)) {
                $headers = \array_map('trim', \explode("\t", $lines[0]));
                $count = 0;
                for ($i = 1; $i < \count($lines) && $count < $this->max_sample_rows; $i++) {
                    $vals = \array_map('trim', \explode("\t", $lines[$i]));
                    if (\count($vals) === \count($headers)) {
                        $rows[] = \array_combine($headers, $vals);
                        $count++;
                    }
                }
            }
        } elseif ($file_extension === 'xlsx') {
            if ($xlsx = SimpleXLSX::parse($file_path)) {
                $get_file = $xlsx->rows();
                if (!empty($get_file)) {
                    $headers = \array_map('trim', (array) $get_file[0]);
                    $header_count = \count($headers);
                    $count = 0;
                    for ($i = 1; $i < \count($get_file) && $count < $this->max_sample_rows; $i++) {
                        $val = $get_file[$i];
                        if (\is_array($val) && \count($val) >= $header_count) {
                            $vals = \array_map('trim', \array_slice($val, 0, $header_count));
                            $rows[] = \array_combine($headers, $vals);
                            $count++;
                        }
                    }
                }
            } else {
                // Fallback to CSV if it's a converted XLSX/XLS file
                $h = \fopen($file_path, 'r');
                if ($h) {
                    $data = \fgetcsv($h, 0, $delim, '"', '\\');
                    if ($data !== false) {
                        $headers = \array_map('trim', (array) $data);
                        $header_count = \count($headers);
                        $count = 0;
                        while (($data = \fgetcsv($h, 0, $delim, '"', '\\')) !== false && $count < $this->max_sample_rows) {
                            if (!empty(\array_filter($data))) {
                                $vals = \array_map('trim', \array_slice($data, 0, $header_count));
                                if (\count($vals) < $header_count) {
                                    $vals = \array_pad($vals, $header_count, '');
                                }
                                $rows[] = \array_combine($headers, $vals);
                                $count++;
                            }
                        }
                    }
                    \fclose($h);
                }
            }
        } elseif ($file_extension === 'xml') {
            $xml = @simplexml_load_file($file_path);
            if ($xml) {
                $items = null;
                if (isset($xml->channel->item)) {
                    $items = $xml->channel->item;
                } elseif (isset($xml->item)) {
                    $items = $xml->item;
                } else {
                    $children = $xml->children();
                    $first = $children[0] ?? null;
                    if ($first && \count($children) > 1) {
                        $items = $children;
                    } elseif ($first) {
                        $items = [$first];
                    }
                }
                if ($items !== null) {
                    $first_item = $items[0];
                    if ($first_item) {
                        $first_arr = (array) $first_item;
                        foreach (\array_keys($first_arr) as $k) {
                            if (\strpos((string) $k, "\0") === false && \substr($k, 0, 1) !== '@') {
                                $headers[] = $k;
                            }
                        }
                        $idx = 0;
                        foreach ($items as $child) {
                            if ($idx >= $this->max_sample_rows) {
                                break;
                            }
                            $arr = (array) $child;
                            $row = [];
                            foreach ($headers as $h) {
                                $v = isset($arr[$h]) ? $arr[$h] : '';
                                $row[$h] = \is_object($v) ? \trim((string) $v) : \trim((string) $v);
                            }
                            $rows[] = $row;
                            $idx++;
                        }
                    }
                }
            }
        } elseif ($file_extension === 'json') {
            $json_content = \file_get_contents($file_path);
            $decoded = \json_decode($json_content, true);
            if ($decoded && \is_array($decoded)) {
                $first = \reset($decoded);
                if (\is_array($first)) {
                    $headers = \array_keys($first);
                    $count = 0;
                    foreach ($decoded as $item) {
                        if ($count >= $this->max_sample_rows) {
                            break;
                        }
                        if (\is_array($item)) {
                            $rows[] = $item;
                            $count++;
                        }
                    }
                }
            } else {
                // Fallback to CSV if it's a converted JSON file
                $h = \fopen($file_path, 'r');
                if ($h) {
                    $data = \fgetcsv($h, 0, $delim, '"', '\\');
                    if ($data !== false) {
                        $headers = \array_map('trim', (array) $data);
                        $header_count = \count($headers);
                        $count = 0;
                        while (($data = \fgetcsv($h, 0, $delim, '"', '\\')) !== false && $count < $this->max_sample_rows) {
                            if (!empty(\array_filter($data))) {
                                $vals = \array_map('trim', \array_slice($data, 0, $header_count));
                                if (\count($vals) < $header_count) {
                                    $vals = \array_pad($vals, $header_count, '');
                                }
                                $rows[] = \array_combine($headers, $vals);
                                $count++;
                            }
                        }
                    }
                    \fclose($h);
                }
            }
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    private function get_row_value($row, $csv_header)
    {
        if (!\is_array($row) || empty($csv_header)) {
            return '';
        }
        return isset($row[$csv_header]) ? \trim((string) $row[$csv_header]) : '';
    }


    private function get_wp_usernames()
    {
        if ($this->wp_usernames === null) {
            $users = \get_users(['fields' => ['user_login']]);
            $this->wp_usernames = \is_array($users) ? \array_map(function($u) {
                return $u->user_login ?? '';
            }, $users) : [];
        }
        return $this->wp_usernames;
    }


    public function check_unused_headers($flat_mapped_fields, $headers = [])
    {
        $mapped_headers = \array_values($flat_mapped_fields);
        $unused = \array_diff($headers, $mapped_headers);
        
        if (empty($unused)) {
            return [];
        }

        $unused_data = [];
        foreach ($unused as $header) {
            $unused_data[$header] = [
                'label'   => $header,
                'message' => 'This CSV header is not mapped to any WordPress field.'
            ];
        }

        return $unused_data;
    }


    public function check_duplicate_fields($flat_mapped_fields, $field_labels_map = [])
    {
        $csv_headers = [];
        foreach ($flat_mapped_fields as $val) {
            $cleaned = \is_string($val) ? \trim($val) : '';
            if (!empty($cleaned) && \strtolower($cleaned) !== 'array') {
                $csv_headers[] = $cleaned;
            }
        }

        $counts = \array_count_values($csv_headers);
        $duplicates = [];
        foreach ($counts as $csv_header => $count) {
            if ($count > 1) {
                $wp_fields_keys = \array_keys(\array_filter($flat_mapped_fields, function ($val) use ($csv_header) {
                    return (string) $val === $csv_header;
                }));
                
                $wp_fields_display = [];
                foreach ($wp_fields_keys as $key) {
                    $label = $field_labels_map[$key] ?? $key;
                    $wp_fields_display[] = $label;
                }
                if(strpos($csv_header ,'Manipulation')) continue;
                $duplicates[$csv_header] = [
                    'fields_keys' => $wp_fields_keys,
                    'fields' => $wp_fields_display,
                    'message' => "CSV column '{$csv_header}' is mapped to multiple WordPress fields: " . \implode(', ', $wp_fields_display)
                ];
            }
        }
        return $duplicates;
    }

    public function check_invalid_fields($flat_mapped_fields, $headers = [], $rows = [], $selected_type = 'Posts', $field_labels_map = [])
    {
        $invalid = [];

        if (isset($flat_mapped_fields['post_status']) && !empty($flat_mapped_fields['post_status'])) {
            $csv_header = \trim((string) $flat_mapped_fields['post_status']);
            $bad_rows = [];
            foreach ($rows as $idx => $row) {
                $val = $this->get_row_value($row, $csv_header);
                if ($val !== '' && !\in_array(\strtolower($val), \array_map('strtolower', $this->valid_post_statuses), true)) {
                    $bad_rows[] = $idx + 2;
                }
            }
            if (!empty($bad_rows)) {
                $label = $field_labels_map['post_status'] ?? 'post_status';
                $invalid['post_status'] = [
                    'label' => $label,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'valid' => $this->valid_post_statuses,
                    'message' => "Invalid status for '{$label}'. Allowed values: " . \implode(', ', $this->valid_post_statuses)
                ];
            }
        }

        foreach ($this->date_fields as $field) {
            if (!isset($flat_mapped_fields[$field]) || \trim((string) $flat_mapped_fields[$field]) === '') {
                continue;
            }
            $csv_header = \trim((string) $flat_mapped_fields[$field]);
            $bad_rows = [];
            foreach ($rows as $idx => $row) {
                $val = $this->get_row_value($row, $csv_header);
                if ($val !== '' && !$this->is_valid_date($val)) {
                    $bad_rows[] = $idx + 2;
                }
            }
            if (!empty($bad_rows)) {
                $label = $field_labels_map[$field] ?? $field;
                $invalid[$field] = [
                    'label' => $label,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'valid_formats' => $this->date_formats,
                    'message' => "Invalid date format for '{$label}'. Expected: " . \implode(', ', \array_slice($this->date_formats, 0, 3)) . " ..."
                ];
            }
        }

        if (isset($flat_mapped_fields['post_author']) && !empty($flat_mapped_fields['post_author'])) {
            $csv_header = \trim((string) $flat_mapped_fields['post_author']);
            $bad_rows = [];
            $valid_usernames = $this->get_wp_usernames();
            foreach ($rows as $idx => $row) {
                $val = $this->get_row_value($row, $csv_header);
                if ($val !== '' && !\in_array($val, $valid_usernames, true)) {
                    $bad_rows[] = $idx + 2;
                }
            }
            if (!empty($bad_rows)) {
                $label = $field_labels_map['post_author'] ?? 'post_author';
                $invalid['post_author'] = [
                    'label' => $label,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'message' => "Invalid author '{$label}'. The username '{$val}' does not exist in WordPress."
                ];
            }
        }

        return $invalid;
    }

    /**
     * Check WYSIWYG and post_content fields for unbalanced HTML tags.
     */
    public function check_wysiwyg_html_tags($flat_mapped_fields, $headers = [], $rows = [], $selected_type = 'Posts', $field_labels_map = [])
    {
        $issues = [];
        $wysiwyg_fields = $this->get_wysiwyg_fields($selected_type);

        foreach ($wysiwyg_fields as $field) {
            if (!isset($flat_mapped_fields[$field]) || \trim((string) $flat_mapped_fields[$field]) === '') {
                continue;
            }
            $csv_header = \trim((string) $flat_mapped_fields[$field]);
            $bad_rows = [];
            foreach ($rows as $idx => $row) {
                $val = $this->get_row_value($row, $csv_header);
                if ($val !== '' && !$this->is_html_tags_balanced($val)) {
                    $bad_rows[] = $idx + 2;
                }
            }
            if (!empty($bad_rows)) {
                $label = $field_labels_map[$field] ?? $field;
                $issues[$field] = [
                    'label'        => $label,
                    'csv_header'   => $csv_header,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'total_invalid' => \count($bad_rows),
                    'message'      => "Unbalanced HTML tags found in '{$label}'; ensure all opened tags are properly closed.",
                ];
            }
        }

        return $issues;
    }

    private function is_html_tags_balanced($value)
    {
        // Void tags that don't need a closing tag
        $void_tags = ['img', 'br', 'hr', 'input', 'link', 'meta', 'source', 'track', 'wbr', 'video'];
        
        // Find all tags: <tag ...> or </tag>
        \preg_match_all('/<(\/?[a-zA-Z0-9]+)([^>]*)>/', (string)$value, $matches);
        
        $stack = [];
        foreach ($matches[1] as $tag) {
            $tag = \strtolower($tag);
            
            // If it's a closing tag
            if (\substr($tag, 0, 1) === '/') {
                $closing_tag = \substr($tag, 1);
                if (\in_array($closing_tag, $void_tags)) {
                    continue; // Skip closing void tags if they exist (though they shouldn't)
                }
                
                if (empty($stack) || \array_pop($stack) !== $closing_tag) {
                    return false; // Imbalance
                }
            } else {
                // It's an opening tag
                if (!\in_array($tag, $void_tags)) {
                    $stack[] = $tag;
                }
            }
        }
        
        return empty($stack);
    }

    public function check_empty_rows($headers = [], $rows = [])
    {
        $empty_row_indices = [];
        foreach ($rows as $idx => $row) {
            $is_empty = true;
            foreach ($row as $val) {
                if (\trim((string)$val) !== '') {
                    $is_empty = false;
                    break;
                }
            }
            if ($is_empty) {
                $empty_row_indices[] = $idx + 2;
            }
        }

        if (empty($empty_row_indices)) {
            return [];
        }

        return [
            'empty_row_indices' => \array_slice($empty_row_indices, 0, 10),
            'total_empty' => \count($empty_row_indices),
            'message' => 'Completely empty rows found in the imported file.'
        ];
    }


    private function get_wysiwyg_fields($import_type)
    {
        $wysiwyg = ['post_content', 'post_excerpt'];

        try {
            $mapping_extension = MappingExtension::getInstance();
            $fields = $mapping_extension->mapping_fields($import_type);
            $extracted = $this->extract_wysiwyg_field_names($fields);
            $wysiwyg = \array_unique(\array_merge($wysiwyg, $extracted));
        } catch (\Throwable $e) {
            // Fallback to core WYSIWYG fields only
        }

        $acf_wysiwyg = $this->get_acf_wysiwyg_field_names($import_type);
        $jet_wysiwyg = $this->get_jetengine_wysiwyg_field_names($import_type);
        $wysiwyg = \array_unique(\array_merge($wysiwyg, $acf_wysiwyg, $jet_wysiwyg));

        return \array_values(\array_filter($wysiwyg));
    }

    private function extract_wysiwyg_field_names($fields)
    {
        $names = [];
        if (!\is_array($fields)) {
            return $names;
        }
        foreach ($fields as $group_key => $group_value) {
            if (!\is_array($group_value)) {
                continue;
            }
            foreach ($group_value as $field_key => $field_data) {
                if (\is_array($field_data) && isset($field_data['type']) && $field_data['type'] === 'wysiwyg') {
                    $names[] = \is_string($field_key) ? $field_key : (isset($field_data['name']) ? $field_data['name'] : '');
                }
                if (\is_string($field_key) && \stripos($field_key, 'wysiwyg') !== false) {
                    $names[] = $field_key;
                }
            }
        }
        return \array_filter($names);
    }

    private function get_acf_wysiwyg_field_names($import_type)
    {
        global $wpdb;
        $names = [];
        if (!\function_exists('acf_get_field_groups') || !\function_exists('acf_get_fields')) {
            $groups = $wpdb->get_col($wpdb->prepare(
                "SELECT ID FROM {$wpdb->prefix}posts WHERE post_type = 'acf-field-group' AND post_status != 'trash'"
            ));
            if (empty($groups)) {
                return $names;
            }
            foreach ($groups as $group_id) {
                $fields = $wpdb->get_results($wpdb->prepare(
                    "SELECT post_name, post_excerpt, post_content FROM {$wpdb->prefix}posts WHERE post_type = 'acf-field' AND post_status != 'trash' AND post_parent = %d",
                    $group_id
                ));
                foreach ($fields as $f) {
                    $content = \maybe_unserialize($f->post_content);
                    if (\is_array($content) && isset($content['type']) && $content['type'] === 'wysiwyg') {
                        $names[] = $f->post_excerpt ?: $f->post_name;
                    }
                }
            }
        } else {
            $post_type = ('Posts' === $import_type) ? 'post' : (('Pages' === $import_type) ? 'page' : $import_type);
            $groups = \acf_get_field_groups(['post_type' => $post_type]);
            foreach ($groups as $group) {
                $fields = \acf_get_fields($group['key']);
                if (\is_array($fields)) {
                    foreach ($fields as $field) {
                        if (isset($field['type']) && $field['type'] === 'wysiwyg') {
                            $names[] = $field['name'] ?? $field['key'] ?? '';
                        }
                    }
                }
            }
        }
        return \array_filter($names);
    }

    private function get_jetengine_wysiwyg_field_names($import_type)
    {
        global $wpdb;
        $names = [];
        $slug = $import_type;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT meta_fields FROM {$wpdb->prefix}jet_post_types WHERE slug = %s AND status = 'publish' LIMIT 1",
            $slug
        ));
        if (!$row || empty($row->meta_fields)) {
            return $names;
        }
        $meta = \maybe_unserialize($row->meta_fields);
        if (!\is_array($meta)) {
            return $names;
        }
        foreach ($meta as $field) {
            if (\is_array($field) && isset($field['type']) && $field['type'] === 'wysiwyg' && !empty($field['name'])) {
                $names[] = $field['name'];
            }
        }
        return $names;
    }

    private function is_valid_date($value)
    {
        $value = \trim((string) $value);
        if ($value === '') {
            return true;
        }
        foreach ($this->date_formats as $format) {
            $d = \DateTime::createFromFormat($format, $value);
            if ($d && $d->format($format) === $value) {
                return true;
            }
        }
        if (\strtotime($value) !== false) {
            return true;
        }
        return false;
    }

    public function check_broken_links($flat_mapped_fields, $headers = [], $rows = [], $field_labels_map = [])
    {
        $broken = [];
        foreach ($this->check_links_keys as $key) {
            if (!isset($flat_mapped_fields[$key]) || \trim((string) $flat_mapped_fields[$key]) === '') {
                continue;
            }
            $csv_header = \trim((string) $flat_mapped_fields[$key]);
            $bad_rows = [];
            foreach ($rows as $idx => $row) {
                $val = $this->get_row_value($row, $csv_header);
                if ($val === '') {
                    continue;
                }
                if (\filter_var($val, \FILTER_VALIDATE_URL) === false && !\is_numeric($val)) {
                    $bad_rows[] = $idx + 2;
                }
            }
            if (!empty($bad_rows)) {
                $label = $field_labels_map[$key] ?? $key;
                $broken[$key] = [
                    'label'      => $label,
                    'csv_header' => $csv_header,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'total_invalid' => \count($bad_rows),
                ];
            }
        }
        return $broken;
    }

    private function eliminateWooCommerceProductFields($mapped_fields)
    {
        foreach($mapped_fields as $key => $value) {
            if(!empty($value)) {
                if(strpos($key, 'product_attribute_name') !== false || strpos($key, 'product_attribute_value') !== false || strpos($key, 'product_attribute_visible') !== false || strpos($key, 'product_attribute_variation') !== false || strpos($key, 'parent') !== false || strpos($key, 'position') !== false || strpos($key, '_edit_last') !== false || strpos($key, 'file_paths') !== false || strpos($key, 'download_type') !== false || strpos($key, 'downloadable_files') !== false) {
                    unset($mapped_fields[$key]);
                }
            }
        }
        return $mapped_fields;
    }

    private function getFinalmapped_fields($mapped_fields)
    {
        switch ($this->import_type) {
            case 'WooCommerce Product':
                $mapped_fields = $this->eliminateWooCommerceProductFields($mapped_fields);
                break;
            default:
                break;
        }
       
        return $mapped_fields;
    }

    public function check_empty_columns($flat_mapped_fields, $headers = [], $rows = [], $field_labels_map = [])
    {
        $empty_columns = [];
        if (empty($rows)) {
            return [];
        }

        $flat_mapped_fields = $this->getFinalmapped_fields($flat_mapped_fields);
        error_log(print_r($flat_mapped_fields,true),3,WP_CONTENT_DIR.'/ai_detect.log');
        foreach ($flat_mapped_fields as $wp_field => $csv_header) {
            if (empty($csv_header)) {
                continue;
            }

            // Check if csv_header actually exists in the file headers
            if (!\in_array($csv_header, $headers)) {
                continue;
            }

            $is_empty_for_all_rows = true;
            foreach ($rows as $row) {
                $val = $this->get_row_value($row, $csv_header);
                $trimmed_val = \trim((string)$val);
                if ($trimmed_val !== '' && \strtolower($trimmed_val) !== 'array') {
                    $is_empty_for_all_rows = false;
                    break;
                }
            }

            if ($is_empty_for_all_rows) {
                $label = $field_labels_map[$wp_field] ?? $wp_field;
                $bad_rows = [];
                foreach ($rows as $idx => $row) {
                    $bad_rows[] = $idx + 2;
                }
                $empty_columns[$wp_field] = [
                    'label' => $label,
                    'csv_header' => $csv_header,
                    'invalid_rows' => \array_slice($bad_rows, 0, 10),
                    'total_invalid' => \count($bad_rows),
                    'message' => "Mapped CSV column '{$csv_header}' for '{$label}' has no data in the imported rows."
                ];
            }
        }

        return $empty_columns;
    }

}