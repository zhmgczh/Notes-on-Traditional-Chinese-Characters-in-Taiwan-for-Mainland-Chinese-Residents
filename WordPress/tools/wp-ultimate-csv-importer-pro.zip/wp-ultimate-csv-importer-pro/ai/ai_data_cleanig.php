<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/


namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class Smack_AI_Cleaner {

	private static $instance = null;

	private  $local_rules = [
		'clean_html',
	];

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Initialization
	}

	/**
	 * Process a batch of rows through the cleaning pipeline.
	 */
	public function clean_batch( $rows, $map, $headers = [], $use_ai = true ) {
		$ai_available = $use_ai && $this->is_ai_available();
		
		// 1. Identify WYSIWYG Columns (Indices)
		$wysiwyg_indices = $this->get_wysiwyg_column_indices( $headers, $map );
		if ( empty( $wysiwyg_indices ) ) {
			return $rows;
		}

		// 2. Local Sanitization (ALWAYS)
		foreach ( $rows as $index => &$row ) {
			foreach ( $wysiwyg_indices as $col_index ) {
				if ( isset( $row[ $col_index ] ) && ! empty( $row[ $col_index ] ) ) {
					$row[ $col_index ] = $this->clean_html( $row[ $col_index ] );
				}
			}
		}
		unset( $row );

		if ( ! $ai_available ) {
			return $rows;
		}

		// 3. Collect Items for AI Polishing
		$needs_polishing = [];
		foreach ( $rows as $row_idx => $row ) {
			foreach ( $wysiwyg_indices as $col_idx ) {
				if ( isset( $row[ $col_idx ] ) && ! empty( $row[ $col_idx ] ) ) {
					$needs_polishing[] = [
						'row' => $row_idx,
						'col' => $col_idx,
						'val' => $row[ $col_idx ]
					];
				}
			}
		}

		if ( empty( $needs_polishing ) ) {
			return $rows;
		}

		// 4. Batch Process with AI (In Chunks of 10 to save tokens)
		$chunks = array_chunk( $needs_polishing, 20 );
		foreach ( $chunks as $chunk ) {
			
			// --- METHOD SELECTION ---
			// Uncomment the method you wish to test:

			// METHOD 1: Original Delimiter Method
			// $cleaned_values = $this->ai_batch_polish( array_column( $chunk, 'val' ) );

			// METHOD 2: AI Formula (Structured JSON) - Best for AI reliability
			$cleaned_values = $this->ai_batch_polish_json( array_column( $chunk, 'val' ) );

			// METHOD 3: Hybrid Approach (Local wp_kses parser + AI) - Fastest & Cheapest
			// $cleaned_values = $this->ai_batch_polish_hybrid( array_column( $chunk, 'val' ) );
			
			if ( is_array( $cleaned_values ) && count( $cleaned_values ) === count( $chunk ) ) {
				foreach ( $chunk as $i => $item ) {
					$rows[ $item['row'] ][ $item['col'] ] = $cleaned_values[ $i ];
				}
			}
		}

		return $rows;
	}

	/**
	 * Identifies which column indices are WYSIWYG fields based on the mapping and headers.
	 */
	private function get_wysiwyg_column_indices( $headers, $map ) {
		$indices = [];
		$wysiwyg_targets = [ 'post_content', 'post_excerpt', 'wysiwyg' ];

		foreach ( $map as $group ) {
			if ( ! is_array( $group ) ) continue;
			foreach ( $group as $wp_field => $csv_header ) {
				if ( $wp_field === 'post_content' || strpos( $wp_field, 'wysiwyg' ) !== false ) {
					// Find which index this header corresponds to
					$found_index = array_search( $csv_header, $headers );
					if ( false !== $found_index ) {
						$indices[] = $found_index;
					}
				}
			}
		}
		return array_unique( $indices );
	}

	private function clean_html( $text ) {
		if ( empty( $text ) ) return $text;
		$text = preg_replace( '/<(script|style)[^>]*?>.*?<\/\\1>/si', '', $text );
		$text = preg_replace( '/<!--.*?-->/s', '', $text );
		$text = str_replace( '&nbsp;', ' ', $text );
		return trim( $text );
	}

	private function is_ai_available() {
		return function_exists( 'wp_ai_client_prompt' );
	}

	public function pre_import_clean_csv( $hash_key, $map ) {
       

		$upload_dir = \Smackcoders\UCI\Proaddons\UltimatePro\SaveMapping::$smackcsv_instance->create_upload_dir();
		$file_path = $upload_dir . $hash_key . '/' . $hash_key;
		
		if ( ! file_exists( $file_path ) ) return;

		$rows = [];
		$headers = [];
		if ( ( $handle = fopen( $file_path, "r" ) ) !== FALSE ) {
			$headers = fgetcsv( $handle );
			while ( ( $data = fgetcsv( $handle ) ) !== FALSE ) {
				$rows[] = $data;
			}
			fclose( $handle );
		}

		if ( empty( $headers ) || empty( $rows ) ) return;

		// We can reuse clean_batch since it handles chunking and mapping logic
		$cleaned_rows = $this->clean_batch( $rows, $map, $headers, true );

		if ( ! empty( $cleaned_rows ) ) {
			if ( ( $out = fopen( $file_path, "w" ) ) !== FALSE ) {
				fputcsv( $out, $headers );
				foreach ( $cleaned_rows as $row ) {
					fputcsv( $out, $row );
				}
				fclose( $out );
			}
		}
	}

	/**
	 * Groups multiple content blocks into a single AI request.
	 */
	private function ai_batch_polish( $contents ) {
		$delimiter = "[[ITEM_SEP]]";
		$input_text = implode( "\n$delimiter\n", $contents );

		$prompt = "You are an expert data cleaner. Your task is to clean the following HTML content blocks.

        Below are " . count($contents) . " blocks of content separated by '$delimiter'.

        RULES:
        1. Fix broken, unclosed, or uneven HTML tags (e.g., <b>, <i>, <p>, <div>, <ul>).
        2. Remove redundant `<br>`, excessive newlines, and empty tags.
        3. Standardize phone numbers to (XXX) XXX-XXXX and dates to YYYY-MM-DD.
        4. Preserve WordPress shortcodes (e.g., [caption]).
        5. You MUST return exactly " . count($contents) . " blocks, separated by '$delimiter'.
        6. Do NOT add any extra text, explanations, or markdown code blocks. Just return the cleaned blocks and separators.

        CONTENT TO CLEAN:
        $input_text
        ";

		if (!ConnectorsHelper::has_any_connector()) {
		}

		$ai_result = wp_ai_client_prompt( $prompt );

		$response = '';
		
		if ( is_wp_error( $ai_result ) ) {
		} elseif ( is_string( $ai_result ) ) {
			$response = $ai_result;
		} elseif ( is_object( $ai_result ) && method_exists( $ai_result, 'generate_text' ) ) {
			$text_result = $ai_result->generate_text();
			if ( is_wp_error( $text_result ) ) {
			} else {
				$response = $text_result;
			}
		}

		if ( empty( $response ) ) return null;

		$cleaned_blocks = explode( $delimiter, $response );
		$cleaned_blocks = array_map( 'trim', $cleaned_blocks );

		// Only return exactly what we sent
		return array_slice( $cleaned_blocks, 0, count( $contents ) );
	}

	/**
	 * METHOD 2: AI Formula (Structured JSON)
	 * Explicitly forces the AI to output parseable JSON instead of raw text blocks.
	 */
	private function ai_batch_polish_json( $contents ) {
		$block_data = [];
		foreach ($contents as $i => $content) {
			$block_data[] = ['id' => $i, 'html' => $content];
		}
		// Wrap in outer array so string encoding doesn't crash on quote escape
		$json_input = wp_json_encode(['blocksToClean' => $block_data]);

		$prompt = "You are an expert data cleaner handling complex WYSIWYG tags.

        RULES:
        1. Fix broken, unclosed, or uneven HTML tags (e.g., <b>, <i>, <p>, <div>, <ul>).
        2. Remove redundant `<br>`, excessive newlines, and empty tags.
        3. Standardize phone numbers to (XXX) XXX-XXXX and dates to YYYY-MM-DD.
        4. Preserve WordPress shortcodes (e.g., [caption]).
        5. Return ONLY a valid JSON output matching the exact structure below. Do NOT add Markdown markdown styling (like ```json), explanations, or extra text.

        {
        \"cleanedBlocks\": [
            {\"id\": 0, \"html\": \"cleaned html here\"},
            {\"id\": 1, \"html\": \"cleaned html here\"}
        ]
        }

        CONTENT TO CLEAN (JSON Format):
        " . $json_input;

		$ai_result = wp_ai_client_prompt( $prompt );
		$response = '';
		if ( is_wp_error( $ai_result ) ) {
		} elseif ( is_string( $ai_result ) ) {
			$response = $ai_result;
		} elseif ( is_object( $ai_result ) && method_exists( $ai_result, 'generate_text' ) ) {
			$text_result = $ai_result->generate_text();
			if ( ! is_wp_error( $text_result ) ) {
				$response = $text_result;
			}
		}

		if ( empty( $response ) ) return null;

		// Strip potential markdown backticks AI adds by default
		$response = preg_replace('/```json|```/', '', $response);
		$response = trim($response);
		
		$decoded = json_decode($response, true);
		if ( ! $decoded || ! isset($decoded['cleanedBlocks']) || count($decoded['cleanedBlocks']) !== count($contents) ) {
			return null;
		}

		$cleaned_blocks = [];
		foreach ($decoded['cleanedBlocks'] as $block) {
			$cleaned_blocks[] = $block['html'];
		}
		return array_slice( $cleaned_blocks, 0, count( $contents ) ); 
	}

	/**
	 * METHOD 3: Hybrid Approach (Local Parser + AI)
	 * Instant 0-token HTML balancing using WordPress native functions, followed by AI semantic checks.
	 */
	private function ai_batch_polish_hybrid( $contents ) {
		// 1. FAST LOCAL PROCESS: wp_kses_post guarantees safely balanced HTML
		$local_cleaned = [];
		foreach ( $contents as $html ) {
			$balanced = wp_kses_post( $html );
			// Remove arbitrary redundant breaks locally instantly
			$balanced = str_replace( ['<br><br>', '<br/><br/>'], '<br>', $balanced );
			$local_cleaned[] = $balanced;
		}

		// 2. AI TARGETED TASKS: Only ask AI to do things PHP local parsers cannot (semantic analysis).
		$delimiter = "[[ITEM_SEP]]";
		$input_text = implode( "\n$delimiter\n", $local_cleaned );

		$prompt = "You are an expert data cleaner. The following HTML blocks are ALREADY balanced and secure.
		
        Below are " . count($local_cleaned) . " blocks of content separated by '$delimiter'.

        RULES:
        1. Standardize phone numbers to (XXX) XXX-XXXX and dates to YYYY-MM-DD.
        2. Fix basic grammatical casing or obvious spacing issues.
        3. Preserve ALL existing HTML structure identically.
        4. You MUST return exactly " . count($local_cleaned) . " blocks, separated by '$delimiter'.
        5. Do NOT add any extra text or format differently.

        CONTENT TO CLEAN:
        $input_text
        ";
		
		$ai_result = wp_ai_client_prompt( $prompt );
		$response = '';
		if ( is_wp_error( $ai_result ) ) {
		} elseif ( is_string( $ai_result ) ) {
			$response = $ai_result;
		} elseif ( is_object( $ai_result ) && method_exists( $ai_result, 'generate_text' ) ) {
			$text_result = $ai_result->generate_text();
			if ( ! is_wp_error( $text_result ) ) {
				$response = $text_result;
			}
		}

		if ( empty( $response ) ) return $local_cleaned; // Fallback to safely balanced local copy!

		$cleaned_blocks = explode( $delimiter, $response );
		$cleaned_blocks = array_map( 'trim', $cleaned_blocks );

		// If AI failed to return correct count, fallback to local_cleaned immediately to prevent data loss.
		if ( count( $cleaned_blocks ) !== count( $local_cleaned ) ) {
			return $local_cleaned; 
		}

		return array_slice( $cleaned_blocks, 0, count( $contents ) );
	}
}

