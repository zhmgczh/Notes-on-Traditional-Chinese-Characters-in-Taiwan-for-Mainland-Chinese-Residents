<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro admin settings for the Advanced Media Download Engine.
 * Stored in a single option to avoid new database tables.
 */
class MediaDownloadSettings {

	const OPTION_KEY = 'sm_uci_pro_media_download_settings';

	/**
	 * Default configuration (backward compatible: queue off = legacy inline downloads).
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		return array(
			'enable_queue'              => false,
			'queue_batch_size'          => 10,
			'enable_auto_retry'         => true,
			'max_retry_count'           => 3,
			'connection_timeout'        => 10,
			'download_timeout'          => 30,
			'duplicate_handling'        => 'reuse_existing',
			'featured_fallback'         => 'none',
			'placeholder_attachment_id' => 0,
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public static function get_all() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return array_merge( self::defaults(), $stored );
	}

	/**
	 * Connection timeout in seconds (CURLOPT_CONNECTTIMEOUT).
	 *
	 * @return int
	 */
	public static function get_connection_timeout() {
		return max( 1, (int) self::get( 'connection_timeout', 10 ) );
	}

	/**
	 * Full download / request timeout in seconds.
	 *
	 * @param string $file_ext Optional extension hint (reserved for callers).
	 * @return int
	 */
	public static function get_download_timeout( $file_ext = '' ) {
		unset( $file_ext );
		return max( 5, (int) self::get( 'download_timeout', 30 ) );
	}

	/**
	 * Maximum inline download attempts (including the first try).
	 *
	 * @return int
	 */
	public static function get_max_retry_count() {
		return max( 1, (int) self::get( 'max_retry_count', 3 ) );
	}

	/**
	 * Exponential backoff delay before a retry: min(120, 5 * 2^(attempt-1)).
	 *
	 * @param int $attempt Attempt number (1-based).
	 * @return int Seconds to wait.
	 */
	public static function retry_backoff_seconds( $attempt ) {
		$attempt = max( 1, (int) $attempt );
		return min( 120, 5 * ( 2 ** ( $attempt - 1 ) ) );
	}

	/**
	 * @param int $attempt Attempt number (1-based).
	 * @return int Microseconds to wait.
	 */
	public static function retry_backoff_microseconds( $attempt ) {
		return self::retry_backoff_seconds( $attempt ) * 1000000;
	}

	/**
	 * @param string $key Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::get_all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		$defaults = self::defaults();
		return array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $default;
	}

	/**
	 * Sanitize and persist settings from admin POST.
	 *
	 * @param array<string, mixed> $input Raw input.
	 * @return array<string, mixed>
	 */
	public static function save( $input ) {
		$duplicate = isset( $input['duplicate_handling'] ) ? sanitize_key( $input['duplicate_handling'] ) : 'reuse_existing';
		if ( ! in_array( $duplicate, array( 'skip_duplicate', 'reuse_existing', 'force_new' ), true ) ) {
			$duplicate = 'reuse_existing';
		}

		$fallback = isset( $input['featured_fallback'] ) ? sanitize_key( $input['featured_fallback'] ) : 'none';
		if ( ! in_array( $fallback, array( 'first_gallery', 'placeholder', 'none' ), true ) ) {
			$fallback = 'none';
		}

		$settings = array(
			'enable_queue'                => ! empty( $input['enable_queue'] ),
			'queue_batch_size'            => max( 1, min( 100, (int) ( $input['queue_batch_size'] ?? 10 ) ) ),
			'enable_auto_retry'           => ! empty( $input['enable_auto_retry'] ),
			'max_retry_count'             => max( 0, min( 20, (int) ( $input['max_retry_count'] ?? 3 ) ) ),
			'connection_timeout'          => max( 1, min( 120, (int) ( $input['connection_timeout'] ?? 10 ) ) ),
			'download_timeout'            => max( 5, min( 600, (int) ( $input['download_timeout'] ?? 30 ) ) ),
			'duplicate_handling'          => $duplicate,
			'featured_fallback'           => $fallback,
			'placeholder_attachment_id' => absint( $input['placeholder_attachment_id'] ?? 0 ),
		);

		update_option( self::OPTION_KEY, $settings );
		return $settings;
	}
}
