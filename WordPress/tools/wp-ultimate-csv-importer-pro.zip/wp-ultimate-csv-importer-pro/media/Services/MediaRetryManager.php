<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracks and retries failed media downloads using shortcode_manager.image_meta JSON.
 */
class MediaRetryManager {

	/**
	 * Encode retry payload into image_meta column (backward compatible with existing JSON).
	 *
	 * @param string $failure_reason Human-readable reason.
	 * @param int    $retry_count    Current count.
	 * @param string $hash_key       Import hash.
	 * @param int    $line_number    CSV line.
	 * @return string JSON.
	 */
	public static function build_meta_payload( $failure_reason, $retry_count, $hash_key = '', $line_number = 0 ) {
		return wp_json_encode(
			array(
				'engine'          => 'advanced_media',
				'failure_reason'  => sanitize_text_field( $failure_reason ),
				'retry_count'     => (int) $retry_count,
				'import_id'       => sanitize_text_field( $hash_key ),
				'record_id'       => (int) $line_number,
				'last_attempt_ts' => time(),
			)
		);
	}

	/**
	 * @param string|null $image_meta Stored JSON.
	 * @return array<string, mixed>
	 */
	public static function parse_meta( $image_meta ) {
		if ( empty( $image_meta ) ) {
			return array();
		}
		$decoded = json_decode( $image_meta, true );
		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Record failure on shortcode row (creates row if missing).
	 *
	 * @param int    $post_id        Post ID.
	 * @param int    $media_id       Placeholder attachment ID.
	 * @param string $url            Source URL.
	 * @param string $reason         Failure reason.
	 * @param string $hash_key       Import hash.
	 * @param int    $line_number    Line number.
	 * @param string $image_shortcode Shortcode key.
	 */
	public static function record_failure( $post_id, $media_id, $url, $reason, $hash_key, $line_number, $image_shortcode = 'engine_retry' ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ultimate_csv_importer_shortcode_manager';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, image_meta FROM {$table} WHERE post_id = %d AND media_id = %d LIMIT 1",
				$post_id,
				$media_id
			)
		);

		$meta   = self::parse_meta( $row ? $row->image_meta : '' );
		$count  = isset( $meta['retry_count'] ) ? (int) $meta['retry_count'] : 0;
		$payload = self::build_meta_payload( $reason, $count, $hash_key, $line_number );

		if ( $row ) {
			$wpdb->update(
				$table,
				array(
					'status'      => 'failed',
					'image_meta'  => $payload,
					'original_image' => $url,
				),
				array( 'id' => (int) $row->id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'post_id'         => $post_id,
					'image_shortcode' => $image_shortcode,
					'media_id'        => $media_id,
					'original_image'  => $url,
					'status'          => 'failed',
					'image_meta'      => $payload,
					'hash_key'        => $hash_key,
				),
				array( '%d', '%s', '%d', '%s', '%s', '%s', '%s' )
			);
		}
	}

	/**
	 * Whether automatic retry is allowed for this row.
	 *
	 * @param string|null $image_meta Stored meta.
	 * @return bool
	 */
	public static function can_auto_retry( $image_meta ) {
		if ( ! MediaDownloadSettings::get( 'enable_auto_retry', true ) ) {
			return false;
		}
		$meta  = self::parse_meta( $image_meta );
		$count = isset( $meta['retry_count'] ) ? (int) $meta['retry_count'] : 0;
		$max   = (int) MediaDownloadSettings::get( 'max_retry_count', 3 );
		return $count < $max;
	}

	/**
	 * Exponential backoff seconds: min(120, 5 * 2^(attempt-1)).
	 *
	 * @param int $attempt 1-based attempt number.
	 * @return int
	 */
	public static function backoff_seconds( $attempt ) {
		if ( class_exists( MediaDownloadSettings::class ) ) {
			return MediaDownloadSettings::retry_backoff_seconds( $attempt );
		}
		$attempt = max( 1, (int) $attempt );
		return min( 120, 5 * ( 2 ** ( $attempt - 1 ) ) );
	}

	/**
	 * Increment retry count after a failed attempt.
	 *
	 * @param int $shortcode_row_id DB row id.
	 */
	public static function increment_retry( $shortcode_row_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_shortcode_manager';
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT image_meta, original_image, hash_key FROM {$table} WHERE id = %d", $shortcode_row_id ) );
		if ( ! $row ) {
			return;
		}
		$meta  = self::parse_meta( $row->image_meta );
		$count = isset( $meta['retry_count'] ) ? (int) $meta['retry_count'] : 0;
		$wpdb->update(
			$table,
			array( 'image_meta' => self::build_meta_payload( $meta['failure_reason'] ?? 'retry', $count + 1, $row->hash_key ?? '', $meta['record_id'] ?? 0 ) ),
			array( 'id' => $shortcode_row_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Remove legacy stub rows created before retry fix (media_id=0 / engine_retry).
	 */
	public static function cleanup_invalid_retry_stubs() {
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_shortcode_manager';
		$deleted = $wpdb->query(
			"DELETE FROM {$table} WHERE status = 'failed' AND ( media_id = 0 OR image_shortcode = 'engine_retry' )"
		);
		return (int) $deleted;
	}

	/**
	 * Whether a shortcode row is eligible for FailedImagesUpdate retry.
	 *
	 * @param object $row DB row.
	 * @return bool
	 */
	public static function is_retryable_row( $row ) {
		if ( empty( $row->media_id ) || (int) $row->media_id <= 0 ) {
			return false;
		}
		if ( isset( $row->image_shortcode ) && 'engine_retry' === $row->image_shortcode ) {
			return false;
		}
		return true;
	}

	/**
	 * Attach engine retry metadata to an existing failed shortcode row (after placeholder exists).
	 *
	 * @param int    $post_id   Post ID.
	 * @param int    $media_id  Placeholder attachment ID.
	 * @param string $reason    Failure reason.
	 * @param string $hash_key  Import hash.
	 * @param int    $line      CSV line.
	 */
	public static function annotate_existing_failure( $post_id, $media_id, $reason, $hash_key = '', $line = 0 ) {
		global $wpdb;
		if ( $post_id <= 0 || $media_id <= 0 ) {
			return;
		}
		$table = $wpdb->prefix . 'ultimate_csv_importer_shortcode_manager';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, image_meta FROM {$table} WHERE post_id = %d AND media_id = %d AND status = %s LIMIT 1",
				$post_id,
				$media_id,
				'failed'
			)
		);
		if ( ! $row ) {
			return;
		}
		$meta    = self::parse_meta( $row->image_meta );
		$count   = isset( $meta['retry_count'] ) ? (int) $meta['retry_count'] : 0;
		$payload = self::build_meta_payload( $reason, $count, $hash_key, $line );
		$wpdb->update(
			$table,
			array( 'image_meta' => $payload ),
			array( 'id' => (int) $row->id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Process automatic retries for failed shortcode rows (cron-safe, batched).
	 *
	 * @param int $limit Max rows per run.
	 * @return int Number processed.
	 */
	public static function process_auto_retries( $limit = 20 ) {
		global $wpdb;

		if ( ! MediaDownloadSettings::get( 'enable_auto_retry', true ) ) {
			return 0;
		}

		self::cleanup_invalid_retry_stubs();

		$table = $wpdb->prefix . 'ultimate_csv_importer_shortcode_manager';
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status = %s AND media_id > 0 AND image_shortcode != %s ORDER BY id ASC LIMIT %d",
				'failed',
				'engine_retry',
				$limit
			)
		);

		if ( empty( $rows ) ) {
			return 0;
		}

		$processed = 0;
		$failed_updater = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\FailedImagesUpdate' )
			? \Smackcoders\UCI\Proaddons\UltimatePro\FailedImagesUpdate::getInstance()
			: null;

		foreach ( $rows as $row ) {
			if ( ! self::is_retryable_row( $row ) ) {
				continue;
			}
			if ( ! self::can_auto_retry( $row->image_meta ) ) {
				continue;
			}

			$meta        = self::parse_meta( $row->image_meta );
			$retry_count = isset( $meta['retry_count'] ) ? (int) $meta['retry_count'] : 0;
			$last_ts     = isset( $meta['last_attempt_ts'] ) ? (int) $meta['last_attempt_ts'] : 0;
			$backoff     = MediaDownloadSettings::retry_backoff_seconds( $retry_count + 1 );
			if ( $last_ts > 0 && ( time() - $last_ts ) < $backoff ) {
				continue;
			}

			self::increment_retry( (int) $row->id );

			if ( $failed_updater && method_exists( $failed_updater, 'failed_image_update' ) ) {
				$meta        = self::parse_meta( $row->image_meta );
				$line_number = isset( $meta['record_id'] ) ? (int) $meta['record_id'] : 0;
				$post_values = array(
					'post_title' => $row->post_title ?? '',
				);
				// Featured retry path expects featured_image in row data.
				if ( ! empty( $row->image_shortcode ) && false !== strpos( $row->image_shortcode, 'Featured' ) ) {
					$post_values['featured_image'] = $row->original_image;
				}

				$failed_updater->failed_image_update(
					$line_number,
					$post_values,
					(int) $row->post_id,
					$row->post_title ?? '',
					$row->original_image,
					$row->hash_key ?? '',
					null,
					$row->import_type ?? 'post',
					(int) $row->media_id,
					null,
					null
				);
			}
			$processed++;
		}

		return $processed;
	}
}
