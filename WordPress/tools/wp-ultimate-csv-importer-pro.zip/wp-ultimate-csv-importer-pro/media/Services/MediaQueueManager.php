<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * External image download queue (per import hash_key) stored in options — no new tables.
 */
class MediaQueueManager {

	const OPTION_PREFIX = 'sm_uci_media_queue_';
	const CRON_HOOK     = 'sm_uci_pro_media_queue_cron';

	/** @var int Downloads performed in the current HTTP request. */
	private static $request_download_count = 0;

	/**
	 * Register cron schedule for deferred downloads.
	 */
	public static function register_cron() {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_cron_interval' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'cron_process_all' ) );

		if ( MediaDownloadSettings::get( 'enable_queue', false ) && ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 60, 'sm_uci_media_every_minute', self::CRON_HOOK );
		}
	}

	/**
	 * @param array<string, mixed> $schedules WP schedules.
	 * @return array<string, mixed>
	 */
	public static function add_cron_interval( $schedules ) {
		if ( ! isset( $schedules['sm_uci_media_every_minute'] ) ) {
			$schedules['sm_uci_media_every_minute'] = array(
				'interval' => 60,
				'display'  => __( 'UCI Pro Media Queue (1 min)', 'wp-ultimate-csv-importer-pro' ),
			);
		}
		return $schedules;
	}

	/**
	 * @param string $hash_key Import session hash.
	 * @return string Option name.
	 */
	public static function option_name( $hash_key ) {
		return self::OPTION_PREFIX . sanitize_key( $hash_key );
	}

	/**
	 * Whether another inline download is allowed this request.
	 *
	 * @return bool
	 */
	public static function can_download_inline() {
		if ( ! MediaDownloadSettings::get( 'enable_queue', false ) ) {
			return true;
		}
		$batch = (int) apply_filters(
			'sm_uci_pro_media_queue_batch_size',
			(int) MediaDownloadSettings::get( 'queue_batch_size', 10 )
		);
		return self::$request_download_count < max( 1, $batch );
	}

	/**
	 * Track an inline download for per-request throttling.
	 */
	public static function track_inline_download() {
		self::$request_download_count++;
	}

	/**
	 * Enqueue a deferred download job.
	 *
	 * @param string               $hash_key Import hash.
	 * @param array<string, mixed> $job      Serializable job context.
	 */
	public static function enqueue( $hash_key, $job ) {
		if ( '' === $hash_key || ! is_array( $job ) ) {
			return;
		}
		$job['queued_at'] = time();
		$option           = self::option_name( $hash_key );
		$queue            = get_option( $option, array() );
		if ( ! is_array( $queue ) ) {
			$queue = array();
		}
		$queue[] = $job;
		update_option( $option, $queue, false );
	}

	/**
	 * @param string $hash_key Import hash.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_queue( $hash_key ) {
		$queue = get_option( self::option_name( $hash_key ), array() );
		return is_array( $queue ) ? $queue : array();
	}

	/**
	 * Process queued downloads for one import session.
	 *
	 * @param string $hash_key Import hash.
	 * @param int    $limit    Max jobs.
	 * @return int Processed count.
	 */
	public static function process_batch( $hash_key, $limit = 0 ) {
		if ( '' === $hash_key ) {
			return 0;
		}
		if ( $limit <= 0 ) {
			$limit = (int) MediaDownloadSettings::get( 'queue_batch_size', 10 );
		}
		$limit = max( 1, min( 50, $limit ) );

		$option = self::option_name( $hash_key );
		$queue  = get_option( $option, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			return 0;
		}

		$processor = MediaDownloadProcessor::getInstance();
		$media     = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::getInstance();
		$processed = 0;
		$remaining = array();

		foreach ( $queue as $index => $job ) {
			if ( $processed >= $limit ) {
				$remaining[] = $job;
				continue;
			}
			if ( ! is_array( $job ) || empty( $job['url'] ) ) {
				continue;
			}

			$attach_id = $media->media_handling(
				$job['url'],
				(int) ( $job['post_id'] ?? 0 ),
				isset( $job['data_array'] ) ? $job['data_array'] : null,
				$job['plugin'] ?? null,
				$job['import_type'] ?? null,
				$job['acf_wpname_element'] ?? null,
				$hash_key,
				null,
				null,
				isset( $job['header_array'] ) ? $job['header_array'] : null,
				isset( $job['value_array'] ) ? $job['value_array'] : null,
				null,
				null,
				(int) ( $job['line_number'] ?? 0 ),
				isset( $job['indexs'] ) ? $job['indexs'] : null,
				$job['acf_image_meta'] ?? null,
				$job['media_type'] ?? null,
				isset( $job['media_id'] ) ? $job['media_id'] : null,
				$job['jet_child_object_id'] ?? null,
				$job['parent_object_id'] ?? null,
				'MediaUpdate',
				! empty( $job['featured'] )
			);

			if ( empty( $attach_id ) ) {
				$processor->record_http_failure(
					$job['url'],
					'queued_download_failed',
					(int) ( $job['post_id'] ?? 0 ),
					(int) ( $job['line_number'] ?? 0 ),
					$hash_key
				);
				$remaining[] = $job;
			} else {
				MediaMetadataMapper::apply(
					$attach_id,
					isset( $job['metadata'] ) ? $job['metadata'] : MediaMetadataMapper::from_row_data( $job['data_array'] ?? array(), ! empty( $job['featured'] ) )
				);
				MediaDuplicateDetector::stamp_source_url( $attach_id, $job['url'] );
			}
			$processed++;
		}

		if ( empty( $remaining ) ) {
			delete_option( $option );
		} else {
			update_option( $option, $remaining, false );
		}

		return $processed;
	}

	/**
	 * Cron: process queues for active imports (chunked).
	 */
	public static function cron_process_all() {
		global $wpdb;
		$events = $wpdb->get_col(
			"SELECT hash_key FROM {$wpdb->prefix}smackcsv_file_events WHERE progress < 100 LIMIT 20"
		);
		if ( empty( $events ) ) {
			return;
		}
		foreach ( $events as $hash_key ) {
			self::process_batch( $hash_key );
		}
		MediaRetryManager::process_auto_retries( 15 );
	}

	/**
	 * After each AJAX bulk batch, drain part of the queue for this import.
	 *
	 * @param string $hash_key Import hash.
	 */
	public static function after_import_batch( $hash_key ) {
		if ( ! MediaDownloadSettings::get( 'enable_queue', false ) ) {
			return;
		}
		self::process_batch( $hash_key );
	}
}
