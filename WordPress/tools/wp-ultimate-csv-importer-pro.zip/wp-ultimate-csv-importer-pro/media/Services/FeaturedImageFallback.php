<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Featured image fallback when primary download fails.
 */
class FeaturedImageFallback {

	/**
	 * Apply configured fallback and set post thumbnail when possible.
	 *
	 * @param int                  $post_id     Post ID.
	 * @param int                  $failed_id   Failed attachment ID (optional).
	 * @param array<string, mixed> $post_values Row data (gallery URLs, etc.).
	 * @return int Attachment ID used for thumbnail, or 0.
	 */
	public static function apply( $post_id, $failed_id, $post_values = array() ) {
		$mode = MediaDownloadSettings::get( 'featured_fallback', 'none' );
		if ( 'none' === $mode || $post_id <= 0 ) {
			return 0;
		}

		$fallback_id = 0;

		if ( 'first_gallery' === $mode ) {
			$gallery_raw = '';
			if ( ! empty( $post_values['product_image_gallery'] ) ) {
				$gallery_raw = $post_values['product_image_gallery'];
			} elseif ( ! empty( $post_values['gallery'] ) ) {
				$gallery_raw = $post_values['gallery'];
			}
			$urls = MediaGalleryImporter::parse_urls( $gallery_raw );
			foreach ( $urls as $url ) {
				if ( is_numeric( $url ) ) {
					$fallback_id = (int) $url;
					break;
				}
				$existing = MediaDuplicateDetector::find_existing( $url );
				if ( $existing > 0 ) {
					$fallback_id = $existing;
					break;
				}
			}
			// Use first successful gallery attachment on product if already imported.
			if ( 0 === $fallback_id && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $post_id );
				if ( $product && method_exists( $product, 'get_gallery_image_ids' ) ) {
					$gallery_ids = $product->get_gallery_image_ids();
					if ( ! empty( $gallery_ids[0] ) ) {
						$fallback_id = (int) $gallery_ids[0];
					}
				}
			}
		} elseif ( 'placeholder' === $mode ) {
			$fallback_id = (int) MediaDownloadSettings::get( 'placeholder_attachment_id', 0 );
			if ( $fallback_id <= 0 ) {
				// Reuse plugin loading-image placeholder if present.
				global $wpdb;
				$fallback_id = (int) $wpdb->get_var(
					"SELECT ID FROM {$wpdb->posts} WHERE post_name LIKE 'loading-image%' AND post_type = 'attachment' LIMIT 1"
				);
			}
		}

		/**
		 * Filter featured image fallback attachment ID.
		 *
		 * @param int   $fallback_id Attachment ID.
		 * @param int   $post_id     Post ID.
		 * @param int   $failed_id   Original failed attachment.
		 * @param string $mode       Fallback mode.
		 */
		$fallback_id = (int) apply_filters( 'sm_uci_pro_media_featured_fallback_id', $fallback_id, $post_id, $failed_id, $mode );

		if ( $fallback_id > 0 ) {
			set_post_thumbnail( $post_id, $fallback_id );
			return $fallback_id;
		}

		return 0;
	}

	/**
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */
	public static function is_failed_placeholder( $attachment_id ) {
		if ( $attachment_id <= 0 ) {
			return true;
		}
		$post = get_post( $attachment_id );
		return $post && 'image-failed' === $post->post_title;
	}
}
