<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parses gallery URL lists (comma, pipe, or array) for product/ACF galleries.
 */
class MediaGalleryImporter {

	/** Suffix for additional Product Gallery column mappings (e.g. product_image_gallery@@2). */
	const GALLERY_COLUMN_MAP_SUFFIX = '@@';

	/**
	 * Whether a mapping key is an extra Product Gallery source column.
	 *
	 * @param string $key Mapping field key.
	 * @return bool
	 */
	public static function is_extra_gallery_column_key( $key ) {
		$key = (string) $key;
		return (bool) preg_match( '/^product_image_gallery' . preg_quote( self::GALLERY_COLUMN_MAP_SUFFIX, '/' ) . '\d+$/', $key );
	}

	/**
	 * Sort order for gallery mapping keys (base field first, then @@1, @@2, …).
	 *
	 * @param string $key Mapping field key.
	 * @return int
	 */
	public static function gallery_column_sort_order( $key ) {
		$key = (string) $key;
		if ( 'product_image_gallery' === $key ) {
			return 0;
		}
		if ( preg_match( '/^product_image_gallery' . preg_quote( self::GALLERY_COLUMN_MAP_SUFFIX, '/' ) . '(\d+)$/', $key, $matches ) ) {
			return (int) $matches[1];
		}
		return PHP_INT_MAX;
	}

	/**
	 * Combine resolved gallery source strings (pipe-separated columns and/or multi-column values).
	 *
	 * @param array<int, string> $sources Resolved cell values in mapping order.
	 * @return string Pipe-separated gallery value for existing import handlers.
	 */
	public static function combine_sources( array $sources ) {
		$urls = array();
		foreach ( $sources as $source ) {
			$source = trim( (string) $source );
			if ( '' === $source ) {
				continue;
			}
			foreach ( self::parse_urls( $source ) as $url ) {
				$url = trim( (string) $url );
				if ( '' !== $url ) {
					$urls[] = $url;
				}
			}
		}
		return implode( '|', $urls );
	}

	/**
	 * Normalize gallery field value to a trimmed URL list.
	 *
	 * @param mixed $value CSV cell or array.
	 * @return array<int, string>
	 */
	public static function parse_urls( $value ) {
		if ( is_array( $value ) ) {
			$urls = array();
			foreach ( $value as $item ) {
				$item = trim( (string) $item );
				if ( '' !== $item ) {
					$urls[] = $item;
				}
			}
			return $urls;
		}

		$value = trim( (string) $value );
		if ( '' === $value ) {
			return array();
		}

		if ( is_numeric( $value ) ) {
			return array( $value );
		}

		if ( strpos( $value, '|' ) !== false ) {
			$parts = explode( '|', $value );
		} elseif ( strpos( $value, ',' ) !== false ) {
			$parts = explode( ',', $value );
		} else {
			$parts = array( $value );
		}

		$urls = array();
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( '' !== $part ) {
				$urls[] = $part;
			}
		}
		return $urls;
	}

	/**
	 * Whether an attachment ID represents a successful import (not a failed placeholder).
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */
	public static function is_successful_attachment( $attachment_id ) {
		$attachment_id = (int) $attachment_id;
		if ( $attachment_id <= 0 ) {
			return false;
		}

		$post = get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return false;
		}
		if ( 'image-failed' === $post->post_title ) {
			return false;
		}
		if ( get_post_meta( $attachment_id, '_uci_media_import_failed', true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Import gallery URLs and return attachment IDs (WooCommerce _product_image_gallery compatible).
	 * Each URL is processed in isolation; failures do not abort the gallery.
	 *
	 * @param mixed                $value         Gallery field value.
	 * @param callable             $import_callback Callback( $url, $index ) => attachment ID.
	 * @return array<int, int>
	 */
	public static function import_urls( $value, $import_callback ) {
		$urls  = self::parse_urls( $value );
		$ids   = array();
		$index = 0;
		foreach ( $urls as $url ) {
			$aid = 0;
			try {
				if ( is_numeric( $url ) ) {
					$aid = (int) $url;
				} elseif ( is_callable( $import_callback ) ) {
					$aid = (int) call_user_func( $import_callback, $url, $index );
				}
			} catch ( \Throwable $e ) {
				$aid = 0;
			}
			if ( self::is_successful_attachment( $aid ) ) {
				$ids[] = $aid;
			}
			$index++;
		}
		return $ids;
	}

	/**
	 * Apply WooCommerce product gallery meta from attachment IDs.
	 *
	 * @param int        $product_id Product ID.
	 * @param array<int> $ids        Attachment IDs.
	 */
	public static function assign_woocommerce_gallery( $product_id, $ids ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 || empty( $ids ) ) {
			return;
		}

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product && method_exists( $product, 'set_gallery_image_ids' ) ) {
				$product->set_gallery_image_ids( $ids );
				$product->save();
				return;
			}
		}
		update_post_meta( $product_id, '_product_image_gallery', implode( ',', $ids ) );
	}
}
