<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detects existing attachments by source URL hash (preferred), exact GUID,
 * and filename only when the source is not a distinct remote URL.
 *
 * CDN catalogs often reuse the same basename (e.g. 1_org_zoom.jpg) for different
 * images. Basename/title matching alone must never collapse those into one attachment.
 */
class MediaDuplicateDetector {

	const META_URL_HASH = '_smack_uci_source_url_hash';

	/**
	 * Resolve duplicate policy before HTTP download.
	 *
	 * @param string $url       Remote or local image URL.
	 * @param string $filename  Target basename.
	 * @return int|null Attachment ID to reuse, 0 to skip download, null to proceed with new download.
	 */
	public static function resolve( $url, $filename = '' ) {
		$mode = MediaDownloadSettings::get( 'duplicate_handling', 'reuse_existing' );
		if ( 'force_new' === $mode ) {
			return null;
		}

		$existing = self::find_existing( $url, $filename );
		if ( empty( $existing ) ) {
			return null;
		}

		/**
		 * Filter duplicate resolution before import reuses an attachment.
		 *
		 * @param int    $existing    Attachment ID.
		 * @param string $url         Source URL.
		 * @param string $mode        duplicate_handling setting.
		 */
		$existing = (int) apply_filters( 'sm_uci_pro_media_duplicate_found', $existing, $url, $mode );

		if ( 'skip_duplicate' === $mode ) {
			return 0;
		}

		return $existing;
	}

	/**
	 * Whether the value looks like an absolute http(s) URL with a unique path.
	 *
	 * @param string $url Source value.
	 * @return bool
	 */
	public static function is_remote_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return false;
		}
		return (bool) preg_match( '#^https?://#i', $url );
	}

	/**
	 * Whether an attachment is safe to reuse for this exact source URL.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $url           Source URL or local filename.
	 * @return bool
	 */
	public static function attachment_matches_source( $attachment_id, $url ) {
		$attachment_id = (int) $attachment_id;
		$url           = trim( (string) $url );
		if ( $attachment_id <= 0 || $url === '' ) {
			return false;
		}

		$post = get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type || 'image-failed' === $post->post_title ) {
			return false;
		}

		// Exact GUID / attachment URL match.
		$att_url = (string) wp_get_attachment_url( $attachment_id );
		if ( $post->guid === $url || $att_url === $url ) {
			return true;
		}

		$expected_hash = self::url_hash( $url );
		$stored_hash   = (string) get_post_meta( $attachment_id, self::META_URL_HASH, true );
		if ( $stored_hash !== '' && hash_equals( $stored_hash, $expected_hash ) ) {
			return true;
		}

		// Remote URLs with identical basenames (e.g. …/uuid-a/1_org_zoom.jpg vs …/uuid-b/1_org_zoom.jpg)
		// must not match on filename alone.
		if ( self::is_remote_url( $url ) ) {
			return false;
		}

		// Local filename / relative path: allow basename match when no conflicting source hash.
		if ( $stored_hash !== '' && ! hash_equals( $stored_hash, $expected_hash ) ) {
			return false;
		}

		$attached = (string) get_attached_file( $attachment_id );
		$attached_base = $attached !== '' ? basename( $attached ) : '';
		$req_base      = basename( $url );
		if ( $attached_base !== '' && $req_base !== '' && $attached_base === $req_base ) {
			return true;
		}

		$title = sanitize_file_name( pathinfo( $req_base, PATHINFO_FILENAME ) );
		if ( $title !== '' && $post->post_title === $title ) {
			return true;
		}

		return false;
	}

	/**
	 * @param string $url      Image URL.
	 * @param string $filename Optional basename hint.
	 * @return int Attachment ID or 0.
	 */
	public static function find_existing( $url, $filename = '' ) {
		global $wpdb;

		$url = trim( (string) $url );
		if ( '' === $url ) {
			return 0;
		}

		$hash = self::url_hash( $url );
		$by_hash = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
				self::META_URL_HASH,
				$hash
			)
		);
		if ( ! empty( $by_hash ) ) {
			$att = get_post( (int) $by_hash );
			if ( $att && 'attachment' === $att->post_type && 'image-failed' !== $att->post_title ) {
				return (int) $by_hash;
			}
		}

		$guid_match = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid = %s AND post_title != 'image-failed' LIMIT 1",
				$url
			)
		);
		if ( ! empty( $guid_match ) ) {
			return (int) $guid_match;
		}

		// Filename / title fallback — never for distinct remote URLs (same basename, different assets).
		if ( self::is_remote_url( $url ) ) {
			return 0;
		}

		if ( '' === $filename ) {
			$filename = basename( $url );
		}

		if ( '' !== $filename ) {
			$title = sanitize_file_name( pathinfo( $filename, PATHINFO_FILENAME ) );
			if ( '' !== $title ) {
				$by_title = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_title = %s AND post_title != 'image-failed' LIMIT 1",
						$title
					)
				);
				if ( ! empty( $by_title ) && self::attachment_matches_source( (int) $by_title, $url ) ) {
					return (int) $by_title;
				}
			}
		}

		return 0;
	}

	/**
	 * Persist source URL hash on attachment for future imports.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $url           Source URL.
	 */
	public static function stamp_source_url( $attachment_id, $url ) {
		if ( $attachment_id <= 0 || '' === trim( (string) $url ) ) {
			return;
		}
		update_post_meta( $attachment_id, self::META_URL_HASH, self::url_hash( $url ) );
	}

	/**
	 * @param string $url URL.
	 * @return string
	 */
	public static function url_hash( $url ) {
		return hash( 'sha256', strtolower( trim( $url ) ) );
	}
}
