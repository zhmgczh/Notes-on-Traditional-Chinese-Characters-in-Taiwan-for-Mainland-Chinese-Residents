<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maps alt text, title, caption, and description onto attachments after creation.
 */
class MediaMetadataMapper {

	/**
	 * Apply per-field metadata from CSV row or global smack_image_options.
	 *
	 * @param int                  $attachment_id Attachment ID.
	 * @param array<string, mixed> $field_map     Keys: alt, title, caption, description.
	 */
	public static function apply( $attachment_id, $field_map = array() ) {
		if ( $attachment_id <= 0 || ! is_array( $field_map ) ) {
			return;
		}

		$alt         = isset( $field_map['alt'] ) ? (string) $field_map['alt'] : '';
		$title       = isset( $field_map['title'] ) ? (string) $field_map['title'] : '';
		$caption     = isset( $field_map['caption'] ) ? (string) $field_map['caption'] : '';
		$description = isset( $field_map['description'] ) ? (string) $field_map['description'] : '';

		// Global media options still apply when row-level values are empty.
		// Skip unresolved mapping field keys (e.g. "featured_image_title") so they
		// are never written as literal attachment titles across every product.
		$media_handle = get_option( 'smack_image_options' );
		if ( is_array( $media_handle ) && ! empty( $media_handle['media_settings'] ) ) {
			$ms = $media_handle['media_settings'];
			$is_unresolved = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling' )
				? array( '\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling', 'is_unresolved_media_seo_value' )
				: null;
			if ( '' === $alt && ! empty( $ms['alttext'] ) && ( ! $is_unresolved || ! call_user_func( $is_unresolved, $ms['alttext'] ) ) ) {
				$alt = $ms['alttext'];
			}
			if ( '' === $title && ! empty( $ms['title'] ) && ( ! $is_unresolved || ! call_user_func( $is_unresolved, $ms['title'] ) ) ) {
				$title = $ms['title'];
			}
			if ( '' === $caption && ! empty( $ms['caption'] ) && ( ! $is_unresolved || ! call_user_func( $is_unresolved, $ms['caption'] ) ) ) {
				$caption = $ms['caption'];
			}
			if ( '' === $description && ! empty( $ms['description'] ) && ( ! $is_unresolved || ! call_user_func( $is_unresolved, $ms['description'] ) ) ) {
				$description = $ms['description'];
			}
		}

		$post_update = array( 'ID' => $attachment_id );
		$changed     = false;

		if ( '' !== $title ) {
			$post_update['post_title'] = $title;
			$changed                   = true;
		}
		if ( '' !== $caption ) {
			$post_update['post_excerpt'] = $caption;
			$changed                     = true;
		}
		if ( '' !== $description ) {
			$post_update['post_content'] = $description;
			$changed                     = true;
		}

		if ( $changed ) {
			wp_update_post( $post_update );
		}

		if ( '' !== $alt ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
		}

		/**
		 * Fires after engine metadata mapping runs.
		 *
		 * @param int                  $attachment_id Attachment ID.
		 * @param array<string, mixed> $field_map     Applied map.
		 */
		do_action( 'sm_uci_pro_media_metadata_mapped', $attachment_id, $field_map );
	}

	/**
	 * Build metadata map from featured/gallery CSV keys on the import row.
	 *
	 * @param array<string, mixed> $data_array Post/row data.
	 * @param bool                 $featured   Featured image context.
	 * @return array<string, string>
	 */
	public static function from_row_data( $data_array, $featured = false ) {
		if ( ! is_array( $data_array ) ) {
			return array();
		}

		if ( $featured ) {
			return array(
				'alt'         => isset( $data_array['featured_image_alt_text'] ) ? (string) $data_array['featured_image_alt_text'] : '',
				'title'       => isset( $data_array['featured_image_title'] ) ? (string) $data_array['featured_image_title'] : '',
				'caption'     => isset( $data_array['featured_image_caption'] ) ? (string) $data_array['featured_image_caption'] : '',
				'description' => isset( $data_array['featured_image_description'] ) ? (string) $data_array['featured_image_description'] : '',
			);
		}

		return array();
	}
}
