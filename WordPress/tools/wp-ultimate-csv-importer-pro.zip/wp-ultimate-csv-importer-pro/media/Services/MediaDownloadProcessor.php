<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * HTTP download wrapper with configurable timeouts and failure recording.
 */
class MediaDownloadProcessor {

	/** @var self|null */
	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Build wp_remote_get args using admin timeout settings.
	 *
	 * @param string $file_ext File extension hint.
	 * @return array<string, mixed>
	 */
	public function get_http_args( $file_ext = '' ) {
		$download_timeout   = MediaDownloadSettings::get_download_timeout( $file_ext );
		$connection_timeout = MediaDownloadSettings::get_connection_timeout();

		$args = array(
			'timeout'            => $download_timeout,
			'connection_timeout' => $connection_timeout,
			'redirection'        => 5,
			'user-agent'         => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
			'headers'            => array(
				'Connection' => 'close',
			),
		);

		return apply_filters( 'sm_uci_pro_media_before_download', $args, $file_ext );
	}

	/**
	 * Download remote body via WordPress HTTP API.
	 *
	 * @param string $url      URL.
	 * @param string $file_ext Extension.
	 * @return array{body: string, code: int, error?: string}|null
	 */
	public function fetch_remote( $url, $file_ext = '' ) {
		if ( ! MediaQueueManager::can_download_inline() ) {
			return null;
		}

		MediaQueueManager::track_inline_download();

		$args               = $this->get_http_args( $file_ext );
		$timeout            = isset( $args['timeout'] ) ? (int) $args['timeout'] : MediaDownloadSettings::get_download_timeout( $file_ext );
		$connection_timeout = isset( $args['connection_timeout'] ) ? (int) $args['connection_timeout'] : MediaDownloadSettings::get_connection_timeout();
		$user_agent         = isset( $args['user-agent'] ) ? (string) $args['user-agent'] : '';

		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling' ) ) {
			$fetched = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::fetch_remote_image(
				$url,
				$user_agent,
				$timeout,
				null,
				$connection_timeout,
				$file_ext
			);
			if ( is_wp_error( $fetched ) ) {
				return array(
					'body'  => '',
					'code'  => (int) $fetched->get_error_data( 'status' ),
					'error' => $fetched->get_error_message(),
				);
			}
			return array(
				'body' => (string) $fetched['body'],
				'code' => (int) $fetched['code'],
			);
		}

		$response = wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) ) {
			return array(
				'body'  => '',
				'code'  => 0,
				'error' => $response->get_error_message(),
			);
		}

		return array(
			'body' => (string) wp_remote_retrieve_body( $response ),
			'code' => (int) wp_remote_retrieve_response_code( $response ),
		);
	}

	/**
	 * @param string $url       URL.
	 * @param string $reason    Failure reason.
	 * @param int    $post_id   Post ID.
	 * @param int    $line      Line number.
	 * @param string $hash_key  Import hash.
	 */
	public function record_http_failure( $url, $reason, $post_id = 0, $line = 0, $hash_key = '' ) {
		// Placeholder + shortcode rows are created in MediaHandling for FailedImagesUpdate.
	}

	/**
	 * Queue download when per-request batch limit is reached.
	 *
	 * @param string               $hash_key Import hash.
	 * @param array<string, mixed> $context  Job context for MediaQueueManager.
	 * @return bool True if queued (caller should skip inline download).
	 */
	public function maybe_defer_download( $hash_key, $context ) {
		if ( ! MediaDownloadSettings::get( 'enable_queue', false ) ) {
			return false;
		}
		if ( MediaQueueManager::can_download_inline() ) {
			return false;
		}
		$context['url'] = $context['url'] ?? '';
		MediaQueueManager::enqueue( $hash_key, $context );
		return true;
	}
}
