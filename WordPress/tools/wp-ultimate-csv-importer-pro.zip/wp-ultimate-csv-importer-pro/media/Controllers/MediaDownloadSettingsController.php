<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media\Controllers;

use Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadSettings;
use Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaQueueManager;
use Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin AJAX for Media Download Settings and manual retry trigger.
 */
class MediaDownloadSettingsController {

	/** @var self|null */
	protected static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}
		return self::$instance;
	}

	/**
	 * Register AJAX handlers.
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_uci_media_get_download_settings', array( $this, 'ajax_get_settings' ) );
		add_action( 'wp_ajax_uci_media_save_download_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_uci_media_retry_failed', array( $this, 'ajax_retry_failed' ) );
	}

	/**
	 * @return bool
	 */
	private function authorize_admin() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'wp-ultimate-csv-importer-pro' ) ), 403 );
			return false;
		}
		return true;
	}

	/**
	 * Load settings for React settings tab.
	 */
	public function ajax_get_settings() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		wp_send_json_success( MediaDownloadSettings::get_all() );
	}

	/**
	 * Save settings from React settings tab.
	 */
	public function ajax_save_settings() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		$input = array(
			'enable_queue'                => ! empty( $_POST['enable_queue'] ),
			'queue_batch_size'            => isset( $_POST['queue_batch_size'] ) ? intval( $_POST['queue_batch_size'] ) : 10,
			'enable_auto_retry'           => ! empty( $_POST['enable_auto_retry'] ),
			'max_retry_count'             => isset( $_POST['max_retry_count'] ) ? intval( $_POST['max_retry_count'] ) : 3,
			'connection_timeout'          => isset( $_POST['connection_timeout'] ) ? intval( $_POST['connection_timeout'] ) : 10,
			'download_timeout'            => isset( $_POST['download_timeout'] ) ? intval( $_POST['download_timeout'] ) : 30,
			'duplicate_handling'          => isset( $_POST['duplicate_handling'] ) ? sanitize_key( wp_unslash( $_POST['duplicate_handling'] ) ) : 'reuse_existing',
			'featured_fallback'           => isset( $_POST['featured_fallback'] ) ? sanitize_key( wp_unslash( $_POST['featured_fallback'] ) ) : 'none',
			'placeholder_attachment_id' => isset( $_POST['placeholder_attachment_id'] ) ? intval( $_POST['placeholder_attachment_id'] ) : 0,
		);
		$saved = MediaDownloadSettings::save( $input );
		if ( ! empty( $saved['enable_queue'] ) ) {
			MediaQueueManager::register_cron();
		}
		wp_send_json_success( $saved );
	}

	/**
	 * Manual retry of failed media (batch).
	 */
	public function ajax_retry_failed() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		$limit   = isset( $_POST['limit'] ) ? max( 1, min( 100, intval( $_POST['limit'] ) ) ) : 25;
		$cleaned = MediaRetryManager::cleanup_invalid_retry_stubs();
		$count   = MediaRetryManager::process_auto_retries( $limit );
		wp_send_json_success(
			array(
				'retried'          => $count,
				'stubs_removed'    => $cleaned,
			)
		);
	}
}
