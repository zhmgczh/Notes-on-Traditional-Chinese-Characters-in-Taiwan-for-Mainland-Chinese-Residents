<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Media;

use Smackcoders\UCI\Proaddons\UltimatePro\Media\Controllers\MediaDownloadSettingsController;
use Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadSettings;
use Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaQueueManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstrap Advanced Media Download Engine (Pro).
 */
class MediaBootstrap {

	/**
	 * Load services and register hooks.
	 */
	public static function init() {
		$base = __DIR__;
		require_once $base . '/Services/MediaDownloadSettings.php';
		require_once $base . '/Services/MediaDuplicateDetector.php';
		require_once $base . '/Services/MediaMetadataMapper.php';
		require_once $base . '/Services/MediaRetryManager.php';
		require_once $base . '/Services/MediaQueueManager.php';
		require_once $base . '/Services/MediaDownloadProcessor.php';
		require_once $base . '/Services/MediaGalleryImporter.php';
		require_once $base . '/Services/FeaturedImageFallback.php';
		require_once $base . '/Controllers/MediaDownloadSettingsController.php';

		MediaDownloadSettingsController::getInstance();
		MediaQueueManager::register_cron();

		add_action( 'uci_pro_after_import_batch', array( MediaQueueManager::class, 'after_import_batch' ), 10, 1 );
	}
}
