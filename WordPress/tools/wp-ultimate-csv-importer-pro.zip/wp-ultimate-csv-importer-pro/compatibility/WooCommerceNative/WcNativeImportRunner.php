<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

use Smackcoders\UCI\Proaddons\UltimatePro\CoreFieldsImport;
use Smackcoders\UCI\Proaddons\UltimatePro\ImportHelpers;
use Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression;
use Smackcoders\UCI\Proaddons\UltimatePro\LogManager;
use Smackcoders\UCI\Proaddons\UltimatePro\SaveMapping;
use Smackcoders\UCI\Proaddons\UltimatePro\SpreadsheetEditorService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Routes WooCommerce-native CSV imports through WooCommerce's own product CSV importer.
 */
class WcNativeImportRunner {

	const POS_TRANSIENT_TTL = DAY_IN_SECONDS;

	/** @var string Active import hash for WC importer hooks. */
	private static $active_hash_key = '';

	/** @var int[] Product IDs created/updated in the active batch. */
	private static $active_product_ids = array();

	/**
	 * @param string $hash_key     Import session hash.
	 * @param string $import_type  Module/type from template.
	 * @param string $file_extension File extension.
	 * @return bool
	 */
	public static function should_run( $hash_key, $import_type, $file_extension ) {
		if ( ! function_exists( 'wc_get_product' ) || ! defined( 'WC_ABSPATH' ) ) {
			return false;
		}
		if ( ! class_exists( 'WC_Product_CSV_Importer' ) ) {
			require_once WC_ABSPATH . 'includes/import/class-wc-product-csv-importer.php';
		}
		if ( ! class_exists( 'WC_Product_CSV_Importer' ) ) {
			return false;
		}
		if ( ! in_array( $file_extension, array( 'csv', 'txt' ), true ) ) {
			return false;
		}
		$import_type = self::resolve_import_type( $hash_key, $import_type );
		if ( ! FormatDetector::is_woo_product_module( $import_type ) ) {
			return false;
		}
		return FormatDetector::is_native_import( $hash_key );
	}

	/**
	 * Resolve WooCommerce product import module when mapping template row is missing.
	 *
	 * @param string $hash_key    Import hash.
	 * @param string $import_type Module from template or caller.
	 * @return string
	 */
	public static function resolve_import_type( $hash_key, $import_type = '' ) {
		if ( FormatDetector::is_woo_product_module( $import_type ) ) {
			return $import_type;
		}

		global $wpdb;
		$table  = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$module = $wpdb->get_var(
			$wpdb->prepare( "SELECT module FROM {$table} WHERE eventKey = %s LIMIT 1", $hash_key )
		);
		if ( FormatDetector::is_woo_product_module( $module ) ) {
			return (string) $module;
		}

		$stored = FormatDetector::get_import_module( $hash_key );
		if ( FormatDetector::is_woo_product_module( $stored ) ) {
			return $stored;
		}

		if ( FormatDetector::is_native_import( $hash_key ) ) {
			return 'WooCommerce Product';
		}

		return (string) $import_type;
	}

	/**
	 * Ensure mapping template row exists for WC-native imports (no manual mapping required).
	 *
	 * @param string $hash_key   Hash.
	 * @param string $module     Import module.
	 * @param string $file_name  CSV file name.
	 */
	public static function ensure_mapping_template( $hash_key, $module, $file_name ) {
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$exists = $wpdb->get_var(
			$wpdb->prepare( "SELECT eventKey FROM {$table} WHERE eventKey = %s LIMIT 1", $hash_key )
		);
		if ( $exists ) {
			return;
		}
		$mapping = serialize(
			array(
				'CORE'     => array(),
				'ECOMMETA' => array(),
				'ATTRMETA' => array(),
			)
		);
		$wpdb->insert(
			$table,
			array(
				'templatename'   => 'wc-native-auto',
				'mapping'        => $mapping,
				'mapping_filter' => '',
				'createdtime'    => current_time( 'mysql' ),
				'module'         => $module,
				'csvname'        => $file_name,
				'eventKey'       => $hash_key,
				'mapping_type'   => 'wc_native',
			)
		);
	}

	/**
	 * Run one AJAX batch using WC_Product_CSV_Importer.
	 *
	 * @param array<string,mixed> $args Import context.
	 * @return bool True when batch handled (caller should skip Smack row loop).
	 */
	public static function run_batch( array $args ) {
		global $wpdb, $core_instance;

		$hash_key           = $args['hash_key'];
		$upload_dir         = $args['upload_dir'];
		$page_number        = (int) $args['page_number'];
		$file_iteration     = (int) $args['file_iteration'];
		$get_mode           = $args['get_mode'];
		$selected_type      = $args['selected_type'];
		$file_name          = $args['file_name'];
		$file_extension     = $args['file_extension'];
		$total_rows         = (int) $args['total_rows'];
		$log_table_name     = $args['log_table_name'];
		$helpers_instance   = $args['helpers_instance'];
		$log_manager_instance = $args['log_manager_instance'];
		$add_header         = ! empty( $args['add_header'] );

		if ( $file_iteration <= 0 ) {
			$file_iteration = 30;
		}

		if ( $page_number === 1 ) {
			delete_transient( self::pos_transient_key( $hash_key ) );
			delete_transient( self::row_transient_key( $hash_key ) );
			delete_transient( self::mapping_transient_key( $hash_key ) );
			ImportBridge::on_before_import( $hash_key );
		}

		self::begin_batch_hooks( $hash_key );

		$file_path = ImportFileResolver::getInstance()->resolve_import_file_path( $hash_key, $upload_dir );
		if ( ! is_readable( $file_path ) ) {
			self::end_batch_hooks();
			return false;
		}

		if ( ! class_exists( 'WC_Product_CSV_Importer_Controller' ) ) {
			require_once WC_ABSPATH . 'includes/admin/importers/class-wc-product-csv-importer-controller.php';
		}
		if ( ! class_exists( 'WC_Product_CSV_Importer' ) ) {
			require_once WC_ABSPATH . 'includes/import/class-wc-product-csv-importer.php';
		}

		$wc_path = self::resolve_wc_import_file_path( $file_path, $file_extension );
		if ( ! is_readable( $wc_path ) ) {
			self::end_batch_hooks();
			return false;
		}

		$delimiter = SaveMapping::$validatefile->getFileDelimiter( $wc_path, 5 );
		if ( $delimiter === '\t' ) {
			$delimiter = "\t";
		}

		$prepared_path = $wc_path . '.wc-prepared.csv';
		if ( $page_number === 1 || ! file_exists( $prepared_path ) ) {
			$prepared = WcCsvImportPreparer::prepare( $wc_path, $delimiter );
			if ( $prepared ) {
				$prepared_path = $prepared;
			}
		}
		$file_path = file_exists( $prepared_path ) ? $prepared_path : $wc_path;

		$header_mapping = get_transient( self::mapping_transient_key( $hash_key ) );
		if ( ! is_array( $header_mapping ) || empty( $header_mapping ) ) {
			$raw_headers    = WcCsvMappingHelper::read_csv_headers( $file_path, $delimiter );
			$header_mapping = WcCsvMappingHelper::auto_map_headers( $raw_headers );
			set_transient( self::mapping_transient_key( $hash_key ), $header_mapping, self::POS_TRANSIENT_TTL );
		}

		$start_pos = (int) get_transient( self::pos_transient_key( $hash_key ) );
		$row_offset = (int) get_transient( self::row_transient_key( $hash_key ) );

		$params = array(
			'delimiter'         => $delimiter,
			'start_pos'         => $start_pos,
			'mapping'           => $header_mapping,
			'update_existing'   => ( $get_mode === 'Update' ),
			'lines'             => $file_iteration,
			'parse'             => true,
			'prevent_timeouts'  => true,
		);

		$importer = \WC_Product_CSV_Importer_Controller::get_importer( $file_path, $params );
		$results  = $importer->import();

		$core_instance = CoreFieldsImport::getInstance();
		if ( ! is_array( $core_instance->detailed_log ) ) {
			$core_instance->detailed_log = array();
		}

		$line = $row_offset;
		self::append_log_entries( $core_instance, $results, $get_mode, $line );

		$new_pos = (int) $importer->get_file_position();
		set_transient( self::pos_transient_key( $hash_key ), $new_pos, self::POS_TRANSIENT_TTL );
		set_transient( self::row_transient_key( $hash_key ), $line, self::POS_TRANSIENT_TTL );

		$processed = min( $line, $total_rows );
		$remaining = max( $total_rows - $processed, 0 );
		$percent   = $importer->get_percent_complete();

		foreach ( self::collect_product_ids( $results ) as $product_id ) {
			$helpers_instance->get_post_ids( $product_id, $hash_key );
		}

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$log_table_name} SET processing_records = %d, remaining_records = %d, status = %s WHERE hash_key = %s",
				$processed,
				$remaining,
				( $percent >= 100 ? 'Completed' : 'Processing' ),
				$hash_key
			)
		);

		if ( $percent >= 100 ) {
			self::finalize_import( $hash_key );
			ImportEmailSuppression::disable();
		}

		self::end_batch_hooks();

		if ( ! empty( $core_instance->detailed_log ) ) {
			$log_manager_instance->get_event_log(
				$hash_key,
				$file_name,
				$file_extension,
				$get_mode,
				$total_rows,
				$selected_type,
				$core_instance->detailed_log,
				$add_header
			);
			$core_instance->detailed_log = array();
		}

		return true;
	}

	/**
	 * @param object              $core_instance CoreFieldsImport instance.
	 * @param array<string,mixed> $results       WC importer results.
	 * @param string              $get_mode      Insert|Update.
	 * @param int                 $line          Line counter (by ref).
	 */
	private static function append_log_entries( $core_instance, array $results, $get_mode, &$line ) {
		$buckets = array(
			array( 'ids' => isset( $results['imported'] ) ? $results['imported'] : array(), 'state' => 'Inserted' ),
			array( 'ids' => isset( $results['imported_variations'] ) ? $results['imported_variations'] : array(), 'state' => 'Inserted' ),
			array( 'ids' => isset( $results['updated'] ) ? $results['updated'] : array(), 'state' => 'Updated' ),
		);

		foreach ( $buckets as $bucket ) {
			foreach ( (array) $bucket['ids'] as $product_id ) {
				$line++;
				$product = wc_get_product( (int) $product_id );
				$core_instance->detailed_log[ $line ] = array(
					'id'         => (int) $product_id,
					'post_title' => $product ? $product->get_name() : '',
					'post_type'  => $product ? $product->get_type() : 'product',
					'Status'     => $bucket['state'],
					'state'      => $bucket['state'],
					'Message'    => $bucket['state'] . ' via WooCommerce CSV importer',
					'adminLink'  => get_edit_post_link( (int) $product_id, true ),
					'webLink'    => $product ? get_permalink( $product ) : '',
				);
				if ( $product ) {
					update_post_meta( (int) $product_id, '_smack_uci_wc_native_import', current_time( 'mysql' ) );
				}
			}
		}

		foreach ( (array) ( isset( $results['skipped'] ) ? $results['skipped'] : array() ) as $error ) {
			$line++;
			$core_instance->detailed_log[ $line ] = self::log_from_error( $error, 'Skipped' );
		}

		foreach ( (array) ( isset( $results['failed'] ) ? $results['failed'] : array() ) as $error ) {
			$line++;
			$core_instance->detailed_log[ $line ] = self::log_from_error( $error, 'Failed' );
		}
	}

	/**
	 * @param \WP_Error|string $error Error.
	 * @param string           $state State label.
	 * @return array<string,mixed>
	 */
	private static function log_from_error( $error, $state ) {
		$message = is_wp_error( $error ) ? $error->get_error_message() : (string) $error;
		$data    = is_wp_error( $error ) ? $error->get_error_data() : array();
		$row     = is_array( $data ) && isset( $data['row'] ) ? $data['row'] : '';
		return array(
			'id'         => '',
			'post_title' => is_array( $data ) && ! empty( $data['sku'] ) ? (string) $data['sku'] : '',
			'post_type'  => 'product',
			'Status'     => $state,
			'state'      => $state,
			'Message'    => $message . ( $row !== '' ? ' (row ' . $row . ')' : '' ),
		);
	}

	/**
	 * @param array<string,mixed> $results WC import results.
	 * @return int[]
	 */
	private static function collect_product_ids( array $results ) {
		$ids = array();
		foreach ( array( 'imported', 'imported_variations', 'updated' ) as $key ) {
			if ( empty( $results[ $key ] ) || ! is_array( $results[ $key ] ) ) {
				continue;
			}
			foreach ( $results[ $key ] as $id ) {
				$ids[] = (int) $id;
			}
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * WooCommerce post-import cleanup (mirrors WC admin importer).
	 *
	 * @param string $hash_key Import hash.
	 */
	private static function finalize_import( $hash_key ) {
		ImportBridge::on_after_import( $hash_key );
		self::cleanup_import( $hash_key );
		self::remove_orphan_variations( $hash_key );
	}

	/**
	 * Trash variation posts left without a parent after WC import.
	 *
	 * @param string $hash_key Import hash.
	 */
	private static function remove_orphan_variations( $hash_key ) {
		$stored = get_transient( self::import_ids_transient_key( $hash_key ) );
		$ids    = is_array( $stored ) ? $stored : self::$active_product_ids;
		if ( empty( $ids ) ) {
			return;
		}
		foreach ( $ids as $product_id ) {
			$product = wc_get_product( (int) $product_id );
			if ( ! $product || ! $product->is_type( 'variation' ) ) {
				continue;
			}
			if ( (int) $product->get_parent_id() > 0 ) {
				continue;
			}
			wp_trash_post( (int) $product_id );
		}
		delete_transient( self::import_ids_transient_key( $hash_key ) );
	}

	/**
	 * Register WooCommerce importer hooks for the current AJAX batch.
	 *
	 * @param string $hash_key Import hash.
	 */
	private static function begin_batch_hooks( $hash_key ) {
		self::$active_hash_key    = $hash_key;
		self::$active_product_ids = array();
		if ( ! get_transient( self::import_ids_transient_key( $hash_key ) ) ) {
			set_transient( self::import_ids_transient_key( $hash_key ), array(), self::POS_TRANSIENT_TTL );
		}
		add_filter( 'woocommerce_product_import_pre_insert_product_object', array( __CLASS__, 'filter_pre_insert_product' ), 10, 2 );
		add_action( 'woocommerce_product_import_inserted_product_object', array( __CLASS__, 'on_inserted_product' ), 10, 2 );
	}

	/**
	 * Remove batch hooks.
	 */
	private static function end_batch_hooks() {
		remove_filter( 'woocommerce_product_import_pre_insert_product_object', array( __CLASS__, 'filter_pre_insert_product' ), 10 );
		remove_action( 'woocommerce_product_import_inserted_product_object', array( __CLASS__, 'on_inserted_product' ), 10 );
		self::$active_hash_key = '';
	}

	/**
	 * Block variations without a resolvable parent (WC core saves them as orphans otherwise).
	 *
	 * @param \WC_Product              $product Product.
	 * @param array<string,mixed>      $data    Parsed row.
	 * @return \WC_Product|\WP_Error
	 */
	public static function filter_pre_insert_product( $product, $data ) {
		if ( ! $product instanceof \WC_Product || ! $product->is_type( 'variation' ) ) {
			return $product;
		}

		$parent_id = (int) $product->get_parent_id();
		if ( $parent_id <= 0 && ! empty( $data['parent_id'] ) ) {
			$product->set_parent_id( (int) $data['parent_id'] );
			$parent_id = (int) $product->get_parent_id();
		}

		if ( $parent_id <= 0 && self::$active_hash_key !== '' && ! empty( $data['parent_id'] ) ) {
			$resolved = ImportBridge::resolve_parent_product_id( (string) $data['parent_id'], self::$active_hash_key );
			if ( $resolved > 0 ) {
				$product->set_parent_id( $resolved );
				$parent_id = $resolved;
			}
		}

		if ( $parent_id <= 0 ) {
			throw new \Exception(
				__( 'Variation skipped: parent product is not available in this import file.', 'wp-ultimate-csv-importer-pro' )
			);
		}

		return $product;
	}

	/**
	 * Track imported products for session maps and orphan cleanup.
	 *
	 * @param \WC_Product         $product Product.
	 * @param array<string,mixed> $data    Parsed row.
	 */
	public static function on_inserted_product( $product, $data ) {
		if ( ! $product instanceof \WC_Product || self::$active_hash_key === '' ) {
			return;
		}

		$product_id = (int) $product->get_id();
		if ( $product_id <= 0 ) {
			return;
		}

		self::$active_product_ids[] = $product_id;
		$stored = get_transient( self::import_ids_transient_key( self::$active_hash_key ) );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[] = $product_id;
		set_transient( self::import_ids_transient_key( self::$active_hash_key ), array_values( array_unique( $stored ) ), self::POS_TRANSIENT_TTL );

		$post_values = array(
			'ID'          => isset( $data['id'] ) ? $data['id'] : '',
			'PRODUCTSKU'  => isset( $data['sku'] ) ? $data['sku'] : '',
		);
		ImportBridge::register_imported_product( self::$active_hash_key, $product_id, $post_values );

		if ( $product->is_type( 'variation' ) && (int) $product->get_parent_id() <= 0 && ! empty( $data['parent_id'] ) ) {
			ImportBridge::queue_orphan_variation( self::$active_hash_key, $product_id, (string) $data['parent_id'] );
		}
	}

	/**
	 * WooCommerce post-import cleanup (mirrors WC admin importer).
	 *
	 * @param string $hash_key Import hash.
	 */
	private static function cleanup_import( $hash_key ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_original_id' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete(
			$wpdb->posts,
			array(
				'post_type'   => 'product',
				'post_status' => 'importing',
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete(
			$wpdb->posts,
			array(
				'post_type'   => 'product_variation',
				'post_status' => 'importing',
			)
		);
		delete_transient( self::pos_transient_key( $hash_key ) );
		delete_transient( self::row_transient_key( $hash_key ) );
		delete_transient( self::mapping_transient_key( $hash_key ) );
	}

	/**
	 * WooCommerce validates CSV paths by extension; Smack stores uploads as hash files without one.
	 *
	 * @param string $file_path      Resolved import file path.
	 * @param string $file_extension Original uploaded extension.
	 * @return string
	 */
	private static function resolve_wc_import_file_path( $file_path, $file_extension = 'csv' ) {
		if ( \WC_Product_CSV_Importer_Controller::is_file_valid_csv( $file_path ) ) {
			return $file_path;
		}

		$extension = in_array( $file_extension, array( 'csv', 'txt' ), true ) ? $file_extension : 'csv';
		$wc_path   = $file_path . '.' . $extension;

		if ( ! file_exists( $wc_path ) ) {
			if ( ! @symlink( $file_path, $wc_path ) ) {
				@copy( $file_path, $wc_path );
			}
		}

		if ( file_exists( $wc_path ) && \WC_Product_CSV_Importer_Controller::is_file_valid_csv( $wc_path ) ) {
			return $wc_path;
		}

		return $file_path;
	}

	/**
	 * @param string $hash_key Hash.
	 * @return string
	 */
	private static function mapping_transient_key( $hash_key ) {
		return 'sm_uci_wc_import_map_' . $hash_key;
	}

	/**
	 * @param string $hash_key Hash.
	 * @return string
	 */
	private static function pos_transient_key( $hash_key ) {
		return 'sm_uci_wc_import_pos_' . $hash_key;
	}

	/**
	 * @param string $hash_key Hash.
	 * @return string
	 */
	private static function row_transient_key( $hash_key ) {
		return 'sm_uci_wc_import_row_' . $hash_key;
	}

	/**
	 * @param string $hash_key Hash.
	 * @return string
	 */
	private static function import_ids_transient_key( $hash_key ) {
		return 'sm_uci_wc_import_ids_' . $hash_key;
	}
}
