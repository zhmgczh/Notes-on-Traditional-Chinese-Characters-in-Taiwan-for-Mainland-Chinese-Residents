<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parses WooCommerce Attribute N columns ↔ Smack product_attribute_*N fields.
 */
class AttributeColumnParser {

	/**
	 * Parse a WC attribute header into Smack key info.
	 *
	 * @param string $header Header label.
	 * @return array{n:int,role:string,smack_key:string}|null
	 */
	public static function parse_header( $header ) {
		$header = HeaderMap::normalize_header( $header );

		if ( preg_match( '/^Attribute\s+(\d+)\s+name$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'name',
				'smack_key' => 'product_attribute_name' . $n,
			);
		}
		if ( preg_match( '/^Attribute\s+(\d+)\s+value\(s\)$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'value',
				'smack_key' => 'product_attribute_value' . $n,
			);
		}
		if ( preg_match( '/^Attribute\s+(\d+)\s+visible$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'visible',
				'smack_key' => 'product_attribute_visible' . $n,
			);
		}
		if ( preg_match( '/^Attribute\s+(\d+)\s+global$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'taxonomy',
				'smack_key' => 'product_attribute_taxonomy' . $n,
			);
		}
		if ( preg_match( '/^Attribute\s+(\d+)\s+default$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'default',
				'smack_key' => 'product_attribute_default' . $n,
			);
		}

		return null;
	}

	/**
	 * Build WC header for a role/index.
	 *
	 * @param int    $n    1-based index.
	 * @param string $role name|value|visible|taxonomy|default.
	 * @return string
	 */
	public static function build_wc_header( $n, $role ) {
		$labels = array(
			'name'     => 'Attribute %d name',
			'value'    => 'Attribute %d value(s)',
			'visible'  => 'Attribute %d visible',
			'taxonomy' => 'Attribute %d global',
			'default'  => 'Attribute %d default',
		);
		if ( ! isset( $labels[ $role ] ) ) {
			return '';
		}
		return sprintf( $labels[ $role ], (int) $n );
	}

	/**
	 * Collect attribute slots from an associative WC row.
	 *
	 * @param array $row Associative row (WC headers => values).
	 * @return array<int, array{name:string,value:string,visible:string,taxonomy:string,default:string}>
	 */
	public static function collect_from_wc_row( array $row ) {
		$slots = array();
		foreach ( $row as $header => $value ) {
			$parsed = self::parse_header( $header );
			if ( ! $parsed ) {
				continue;
			}
			$n = $parsed['n'];
			if ( ! isset( $slots[ $n ] ) ) {
				$slots[ $n ] = array(
					'name'     => '',
					'value'    => '',
					'visible'  => '',
					'taxonomy' => '',
					'default'  => '',
				);
			}
			$slots[ $n ][ $parsed['role'] === 'taxonomy' ? 'taxonomy' : $parsed['role'] ] = $value;
		}
		ksort( $slots );
		return $slots;
	}

	/**
	 * Convert collected WC attribute slots into Smack flat fields.
	 *
	 * @param array $slots From collect_from_wc_row.
	 * @param bool  $is_variable Whether product is variable (defaults imply variation).
	 * @return array<string, string>
	 */
	public static function to_smack_fields( array $slots, $is_variable = false ) {
		$out     = array();
		$defaults = array();

		foreach ( $slots as $n => $slot ) {
			if ( $slot['name'] === '' && $slot['value'] === '' ) {
				continue;
			}
			$out[ 'product_attribute_name' . $n ]     = $slot['name'];
			$out[ 'product_attribute_value' . $n ]    = self::normalize_value_list( $slot['value'] );
			$out[ 'product_attribute_visible' . $n ]  = ValueConverter::wc_bool_to_smack( $slot['visible'] );
			$out[ 'product_attribute_taxonomy' . $n ] = ValueConverter::wc_bool_to_smack( $slot['taxonomy'] );

			$is_variation = '';
			if ( $slot['default'] !== '' || $is_variable ) {
				$is_variation = '1';
			}
			$out[ 'product_attribute_variation' . $n ] = $is_variation;

			if ( $slot['default'] !== '' && $slot['name'] !== '' ) {
				$defaults[] = sanitize_title( $slot['name'] ) . '|' . $slot['default'];
			}
		}

		if ( ! empty( $defaults ) ) {
			$out['default_attributes'] = implode( ',', $defaults );
		}

		return $out;
	}

	/**
	 * Normalize WC attribute value list (comma+space, escaped commas) to Smack pipe/comma style.
	 *
	 * @param string $value Raw value(s).
	 * @return string
	 */
	public static function normalize_value_list( $value ) {
		$value = (string) $value;
		if ( $value === '' ) {
			return '';
		}
		// Split on commas not preceded by backslash (WC implode_values style).
		$parts = preg_split( '/(?<!\\\\),\s*/', $value );
		$parts = array_map(
			function ( $p ) {
				return str_replace( '\\,', ',', trim( $p ) );
			},
			$parts
		);
		return implode( '|', array_filter( $parts, 'strlen' ) );
	}

	/**
	 * Convert Smack attribute fields on a row into WC Attribute N columns.
	 *
	 * @param array $smack_row Smack-keyed row data.
	 * @return array<string, string> WC header => value
	 */
	public static function to_wc_columns( array $smack_row ) {
		$max = 0;
		foreach ( array_keys( $smack_row ) as $key ) {
			if ( preg_match( '/^product_attribute_name(\d+)$/', $key, $m ) ) {
				$max = max( $max, (int) $m[1] );
			}
		}

		$out = array();
		for ( $n = 1; $n <= $max; $n++ ) {
			$name = isset( $smack_row[ 'product_attribute_name' . $n ] ) ? $smack_row[ 'product_attribute_name' . $n ] : '';
			if ( $name === '' && empty( $smack_row[ 'product_attribute_value' . $n ] ) ) {
				continue;
			}
			$value = isset( $smack_row[ 'product_attribute_value' . $n ] ) ? $smack_row[ 'product_attribute_value' . $n ] : '';
			// Smack often uses | — WC uses ", " with escaped commas inside values.
			$value = self::format_wc_attribute_values( $value );

			$taxonomy_raw = '';
			if ( isset( $smack_row[ 'product_attribute_taxonomy' . $n ] ) && $smack_row[ 'product_attribute_taxonomy' . $n ] !== '' ) {
				$taxonomy_raw = $smack_row[ 'product_attribute_taxonomy' . $n ];
			} elseif ( ! empty( $name ) && taxonomy_exists( 'pa_' . sanitize_title( $name ) ) ) {
				$taxonomy_raw = '1';
			} elseif ( ! empty( $name ) && function_exists( 'wc_attribute_taxonomy_id_by_name' ) && wc_attribute_taxonomy_id_by_name( $name ) ) {
				$taxonomy_raw = '1';
			} else {
				// Default global=1 when attribute looks like a registered WC taxonomy label.
				$taxonomy_raw = self::guess_is_global_attribute( $name ) ? '1' : '0';
			}

			$out[ self::build_wc_header( $n, 'name' ) ]     = $name;
			$out[ self::build_wc_header( $n, 'value' ) ]    = $value;
			$out[ self::build_wc_header( $n, 'visible' ) ]  = ValueConverter::smack_bool_to_wc( isset( $smack_row[ 'product_attribute_visible' . $n ] ) ? $smack_row[ 'product_attribute_visible' . $n ] : '' );
			$out[ self::build_wc_header( $n, 'taxonomy' ) ] = ValueConverter::smack_bool_to_wc( $taxonomy_raw );

			// Defaults from default_attributes when name matches.
			if ( ! empty( $smack_row['default_attributes'] ) && $name !== '' ) {
				$def = self::extract_default_for_attribute( $smack_row['default_attributes'], $name );
				if ( $def !== '' ) {
					$out[ self::build_wc_header( $n, 'default' ) ] = $def;
				}
			}
		}

		return $out;
	}

	/**
	 * Format attribute value list like WC_Product_CSV_Exporter (comma+space, escape commas).
	 *
	 * @param string $value Raw values (| or , separated).
	 * @return string
	 */
	public static function format_wc_attribute_values( $value ) {
		$value = (string) $value;
		if ( $value === '' ) {
			return '';
		}
		$parts = preg_split( '/\s*[|,]\s*/', $value );
		$parts = array_filter( array_map( 'trim', $parts ), 'strlen' );
		$escaped = array();
		foreach ( $parts as $part ) {
			$escaped[] = str_replace( ',', '\\,', $part );
		}
		return implode( ', ', $escaped );
	}

	/**
	 * @param string $name Attribute label.
	 * @return bool
	 */
	private static function guess_is_global_attribute( $name ) {
		$name = trim( (string) $name );
		if ( $name === '' || ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return false;
		}
		foreach ( (array) wc_get_attribute_taxonomies() as $tax ) {
			if ( isset( $tax->attribute_label ) && strcasecmp( $tax->attribute_label, $name ) === 0 ) {
				return true;
			}
			if ( isset( $tax->attribute_name ) && strcasecmp( $tax->attribute_name, sanitize_title( $name ) ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param string $default_attributes Smack default_attributes string.
	 * @param string $attr_name          Attribute label.
	 * @return string
	 */
	private static function extract_default_for_attribute( $default_attributes, $attr_name ) {
		$pairs = preg_split( '/\s*,\s*/', (string) $default_attributes );
		$slug  = sanitize_title( $attr_name );
		foreach ( $pairs as $pair ) {
			$parts = explode( '|', $pair, 2 );
			if ( count( $parts ) < 2 ) {
				continue;
			}
			$key = sanitize_title( $parts[0] );
			if ( $key === $slug || strcasecmp( $parts[0], $attr_name ) === 0 ) {
				return $parts[1];
			}
		}
		return '';
	}
}
