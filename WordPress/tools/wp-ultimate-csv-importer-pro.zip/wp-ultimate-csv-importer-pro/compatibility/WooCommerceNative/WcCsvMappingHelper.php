<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes WooCommerce core CSV header auto-mapping (same as WC admin importer).
 */
class WcCsvMappingHelper {

	/**
	 * Load WooCommerce importer dependencies.
	 */
	private static function ensure_loaded() {
		if ( ! class_exists( 'WP_Importer' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-importer.php';
		}
		if ( ! class_exists( 'WC_Product_CSV_Importer_Controller', false ) ) {
			require_once WC_ABSPATH . 'includes/admin/importers/class-wc-product-csv-importer-controller.php';
		}
		if ( ! function_exists( 'wc_importer_default_english_mappings' ) ) {
			require_once WC_ABSPATH . 'includes/admin/importers/mappings/mappings.php';
		}
	}

	/**
	 * Build CSV header => schema column mapping using WooCommerce's auto_map_columns().
	 *
	 * @param array $raw_headers Header row from CSV.
	 * @return array<string, string>
	 */
	public static function auto_map_headers( array $raw_headers ) {
		self::ensure_loaded();

		$mapper = new class() extends \WC_Product_CSV_Importer_Controller {
			/**
			 * @param array $raw_headers Headers.
			 * @return array
			 */
			public function map_headers( array $raw_headers ) {
				return $this->auto_map_columns( array_values( $raw_headers ), false );
			}
		};

		$mapped  = $mapper->map_headers( $raw_headers );
		$mapping = array();
		foreach ( $raw_headers as $header ) {
			$header = (string) $header;
			if ( $header === '' ) {
				continue;
			}
			if ( isset( $mapped[ $header ] ) ) {
				$mapping[ $header ] = $mapped[ $header ];
			} else {
				$mapping[ $header ] = $header;
			}
		}
		return $mapping;
	}

	/**
	 * Read CSV header row.
	 *
	 * @param string $file_path File path.
	 * @param string $delimiter Delimiter.
	 * @return array<int, string>
	 */
	public static function read_csv_headers( $file_path, $delimiter = ',' ) {
		if ( ! is_readable( $file_path ) ) {
			return array();
		}
		$handle = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( false === $handle ) {
			return array();
		}
		$row = fgetcsv( $handle, 0, $delimiter, '"', "\0" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fgetcsv
		fclose( $handle );
		if ( ! is_array( $row ) ) {
			return array();
		}
		$row = array_map( 'trim', $row );
		if ( isset( $row[0] ) && substr( bin2hex( $row[0] ), 0, 6 ) === 'efbbbf' ) {
			$row[0] = substr( $row[0], 3 );
		}
		return $row;
	}
}
