<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Images column: WC "url1, url2" ↔ Smack featured_image + product_image_gallery (pipe).
 */
class ImageFormatter {

	/**
	 * Split WC Images cell into featured + gallery.
	 *
	 * @param string $images_cell WC Images value.
	 * @return array{featured_image:string,product_image_gallery:string}
	 */
	public static function split_wc_images( $images_cell ) {
		$images_cell = (string) $images_cell;
		if ( $images_cell === '' ) {
			return array(
				'featured_image'        => '',
				'product_image_gallery' => '',
			);
		}

		$parts = self::explode_image_list( $images_cell );
		$featured = array_shift( $parts );
		$gallery  = ! empty( $parts ) ? implode( '|', $parts ) : '';

		return array(
			'featured_image'        => $featured ? $featured : '',
			'product_image_gallery' => $gallery,
		);
	}

	/**
	 * Merge Smack featured + gallery into WC Images cell.
	 *
	 * @param string $featured Featured URL.
	 * @param string $gallery  Pipe-separated gallery URLs.
	 * @return string
	 */
	public static function merge_to_wc_images( $featured, $gallery = '' ) {
		$urls = array();
		$featured = trim( (string) $featured );
		if ( $featured !== '' ) {
			$urls[] = $featured;
		}
		$gallery = (string) $gallery;
		if ( $gallery !== '' ) {
			foreach ( explode( '|', $gallery ) as $url ) {
				$url = trim( $url );
				if ( $url !== '' && ! in_array( $url, $urls, true ) ) {
					$urls[] = $url;
				}
			}
		}
		return implode( ', ', $urls );
	}

	/**
	 * Explode WC image list (comma-separated; respect escaped commas).
	 *
	 * @param string $value Raw cell.
	 * @return string[]
	 */
	public static function explode_image_list( $value ) {
		$separator = apply_filters( 'woocommerce_product_import_image_separator', ',' );
		// Prefer ", " then ",".
		$parts = array_map( 'trim', explode( $separator, (string) $value ) );
		return array_values(
			array_filter(
				$parts,
				function ( $p ) {
					return $p !== '';
				}
			)
		);
	}
}
