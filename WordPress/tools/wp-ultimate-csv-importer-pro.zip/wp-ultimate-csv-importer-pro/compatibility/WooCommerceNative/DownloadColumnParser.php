<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parses WooCommerce Download N columns ↔ Smack downloadable_files.
 */
class DownloadColumnParser {

	/**
	 * @param string $header Header label.
	 * @return array{n:int,role:string,smack_key:string}|null
	 */
	public static function parse_header( $header ) {
		$header = HeaderMap::normalize_header( $header );

		if ( preg_match( '/^Download\s+(\d+)\s+ID$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'id',
				'smack_key' => 'download_id_' . $n,
			);
		}
		if ( preg_match( '/^Download\s+(\d+)\s+name$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'name',
				'smack_key' => 'download_name_' . $n,
			);
		}
		if ( preg_match( '/^Download\s+(\d+)\s+URL$/i', $header, $m ) ) {
			$n = (int) $m[1];
			return array(
				'n'         => $n,
				'role'      => 'url',
				'smack_key' => 'download_url_' . $n,
			);
		}

		return null;
	}

	/**
	 * @param int    $n    Index.
	 * @param string $role id|name|url.
	 * @return string
	 */
	public static function build_wc_header( $n, $role ) {
		$labels = array(
			'id'   => 'Download %d ID',
			'name' => 'Download %d name',
			'url'  => 'Download %d URL',
		);
		if ( ! isset( $labels[ $role ] ) ) {
			return '';
		}
		return sprintf( $labels[ $role ], (int) $n );
	}

	/**
	 * Collect downloads from WC row and return Smack downloadable_files string.
	 * Format: name,url|name,url
	 *
	 * @param array $row WC associative row.
	 * @return string
	 */
	public static function to_smack_downloadable_files( array $row ) {
		$slots = array();
		foreach ( $row as $header => $value ) {
			$parsed = self::parse_header( $header );
			if ( ! $parsed ) {
				continue;
			}
			$n = $parsed['n'];
			if ( ! isset( $slots[ $n ] ) ) {
				$slots[ $n ] = array(
					'id'   => '',
					'name' => '',
					'url'  => '',
				);
			}
			$slots[ $n ][ $parsed['role'] ] = $value;
		}
		ksort( $slots );

		$files = array();
		foreach ( $slots as $slot ) {
			if ( $slot['url'] === '' && $slot['name'] === '' ) {
				continue;
			}
			$name    = $slot['name'] !== '' ? $slot['name'] : basename( (string) $slot['url'] );
			$files[] = $name . ',' . $slot['url'];
		}

		return implode( '|', $files );
	}

	/**
	 * Convert Smack downloadable_files to WC Download N columns.
	 *
	 * @param string $downloadable_files name,url|name,url
	 * @return array<string, string>
	 */
	public static function to_wc_columns( $downloadable_files ) {
		$downloadable_files = (string) $downloadable_files;
		if ( $downloadable_files === '' ) {
			return array();
		}

		$entries = explode( '|', $downloadable_files );
		$out     = array();
		$n       = 1;
		foreach ( $entries as $entry ) {
			$entry = trim( $entry );
			if ( $entry === '' ) {
				continue;
			}
			$parts = explode( ',', $entry, 2 );
			$name  = isset( $parts[0] ) ? trim( $parts[0] ) : '';
			$url   = isset( $parts[1] ) ? trim( $parts[1] ) : '';
			$out[ self::build_wc_header( $n, 'id' ) ]   = '';
			$out[ self::build_wc_header( $n, 'name' ) ] = $name;
			$out[ self::build_wc_header( $n, 'url' ) ]  = $url;
			$n++;
		}
		return $out;
	}
}
