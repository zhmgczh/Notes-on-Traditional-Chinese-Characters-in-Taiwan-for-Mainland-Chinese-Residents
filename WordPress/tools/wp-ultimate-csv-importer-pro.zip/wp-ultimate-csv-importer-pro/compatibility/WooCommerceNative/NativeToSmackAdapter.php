<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts a WooCommerce-native CSV row (associative) into Smack-keyed fields.
 */
class NativeToSmackAdapter {

	/**
	 * Convert one WC-native associative row to Smack field values.
	 *
	 * @param array $wc_row Header => value.
	 * @return array Smack field => value.
	 */
	public static function convert_row( array $wc_row ) {
		$normalized = array();
		foreach ( $wc_row as $header => $value ) {
			$normalized[ HeaderMap::normalize_header( (string) $header ) ] = $value;
		}

		$smack = array();

		// Standard columns via header map.
		foreach ( $normalized as $header => $value ) {
			$field = HeaderMap::resolve_header( $header );
			if ( ! $field ) {
				continue;
			}
			// Skip attribute/download specials handled below; Images handled specially.
			if ( strpos( $field, 'product_attribute_' ) === 0 || strpos( $field, 'download_' ) === 0 ) {
				continue;
			}
			if ( $field === 'featured_image' ) {
				continue;
			}
			$smack[ $field ] = $value;
		}

		// Type → product_type + downloadable + virtual.
		if ( isset( $normalized['Type'] ) ) {
			$type_info               = ValueConverter::parse_wc_type( $normalized['Type'] );
			$smack['product_type']   = $type_info['product_type'];
			$smack['downloadable']   = $type_info['downloadable'];
			$smack['virtual']        = $type_info['virtual'];
			$is_variable             = ( (int) $type_info['product_type'] === 4 || $type_info['type_string'] === 'variable' );
		} else {
			$is_variable = false;
		}

		// Published.
		if ( isset( $normalized['Published'] ) ) {
			$smack['post_status'] = ValueConverter::published_to_status( $normalized['Published'] );
		}

		// Featured.
		if ( isset( $normalized['Is featured?'] ) ) {
			$smack['featured']         = ValueConverter::wc_bool_to_smack( $normalized['Is featured?'] );
			$smack['featured_product'] = $smack['featured'];
		}

		// Visibility.
		if ( isset( $normalized['Visibility in catalog'] ) ) {
			$smack['visibility'] = ValueConverter::visibility_wc_to_smack( $normalized['Visibility in catalog'] );
		}

		// Descriptions.
		if ( isset( $normalized['Description'] ) ) {
			$smack['post_content'] = ValueConverter::description_wc_to_smack( $normalized['Description'] );
		}
		if ( isset( $normalized['Short description'] ) ) {
			$smack['post_excerpt'] = ValueConverter::description_wc_to_smack( $normalized['Short description'] );
		}

		// Stock / tax / backorders.
		if ( isset( $normalized['In stock?'] ) ) {
			$smack['stock_status'] = ValueConverter::stock_status_wc_to_smack( $normalized['In stock?'] );
		}
		if ( isset( $normalized['Backorders allowed?'] ) ) {
			$smack['backorders'] = ValueConverter::backorders_wc_to_smack( $normalized['Backorders allowed?'] );
		}
		if ( isset( $normalized['Tax status'] ) ) {
			$smack['tax_status'] = ValueConverter::tax_status_wc_to_smack( $normalized['Tax status'] );
		}
		if ( isset( $normalized['Sold individually?'] ) ) {
			$smack['sold_individually'] = ValueConverter::is_truthy( $normalized['Sold individually?'] ) ? 'yes' : 'no';
		}
		if ( isset( $normalized['Allow customer reviews?'] ) ) {
			$smack['comment_status'] = ValueConverter::reviews_wc_to_comment_status( $normalized['Allow customer reviews?'] );
		}

		if ( isset( $normalized['Date sale price starts'] ) ) {
			$smack['sale_price_dates_from'] = ValueConverter::sale_date_wc_to_smack( $normalized['Date sale price starts'] );
		}
		if ( isset( $normalized['Date sale price ends'] ) ) {
			$smack['sale_price_dates_to'] = ValueConverter::sale_date_wc_to_smack( $normalized['Date sale price ends'] );
		}
		if ( isset( $normalized['Low stock amount'] ) && $normalized['Low stock amount'] !== '' ) {
			$smack['low_stock_threshold'] = $normalized['Low stock amount'];
		}
		if ( isset( $normalized['Position'] ) && $normalized['Position'] !== '' ) {
			$smack['menu_order'] = $normalized['Position'];
		}

		// Manage stock when Stock qty present.
		if ( isset( $normalized['Stock'] ) && $normalized['Stock'] !== '' && strtolower( (string) $normalized['Stock'] ) !== 'parent' ) {
			$smack['manage_stock'] = 'yes';
			$smack['stock']        = $normalized['Stock'];
		}

		// Images.
		if ( isset( $normalized['Images'] ) ) {
			$images = ImageFormatter::split_wc_images( $normalized['Images'] );
			$smack['featured_image']        = $images['featured_image'];
			$smack['product_image_gallery'] = $images['product_image_gallery'];
		}

		// Parent / linked products.
		if ( isset( $normalized['Parent'] ) ) {
			$smack['parent'] = ValueConverter::parent_wc_to_smack( $normalized['Parent'] );
		}
		if ( isset( $normalized['Upsells'] ) ) {
			$smack['upsell_ids'] = ValueConverter::linked_products_wc_to_smack( $normalized['Upsells'] );
		}
		if ( isset( $normalized['Cross-sells'] ) ) {
			$smack['crosssell_ids'] = ValueConverter::linked_products_wc_to_smack( $normalized['Cross-sells'] );
		}
		if ( isset( $normalized['Grouped products'] ) ) {
			$smack['grouping_product'] = ValueConverter::linked_products_wc_to_smack( $normalized['Grouped products'] );
		}

		// Categories / tags: WC uses ", " — Smack accepts comma; hierarchy ">" is compatible.
		if ( isset( $normalized['Categories'] ) ) {
			$smack['product_category'] = $normalized['Categories'];
		}
		if ( isset( $normalized['Tags'] ) ) {
			$smack['product_tag'] = $normalized['Tags'];
		}

		// Dimension headers with units already resolved via HeaderMap::resolve_header.
		foreach ( array( 'Weight', 'Length', 'Width', 'Height' ) as $dim ) {
			foreach ( $normalized as $header => $value ) {
				if ( preg_match( '/^' . $dim . '\s*\(/i', $header ) ) {
					$smack[ strtolower( $dim ) ] = $value;
				}
			}
		}

		// Attributes.
		$attr_slots = AttributeColumnParser::collect_from_wc_row( $normalized );
		$attr_fields = AttributeColumnParser::to_smack_fields( $attr_slots, $is_variable );
		$smack       = array_merge( $smack, $attr_fields );

		// Downloads.
		$downloadable_files = DownloadColumnParser::to_smack_downloadable_files( $normalized );
		if ( $downloadable_files !== '' ) {
			$smack['downloadable_files'] = $downloadable_files;
			if ( empty( $smack['downloadable'] ) ) {
				$smack['downloadable'] = 'yes';
			}
		}

		// Meta: columns.
		foreach ( $normalized as $header => $value ) {
			if ( preg_match( '/^Meta:\s*(.+)$/i', $header, $m ) ) {
				$smack[ 'meta:' . trim( $m[1] ) ] = $value;
			}
		}

		/**
		 * Filter converted Smack row from WC-native CSV.
		 *
		 * @param array $smack  Smack fields.
		 * @param array $wc_row Original WC row.
		 */
		return apply_filters( 'sm_uci_pro_wc_native_row', $smack, $normalized );
	}

	/**
	 * Build auto-mapping: Smack field => CSV header (for mapping UI).
	 *
	 * @param array $headers CSV headers.
	 * @return array{CORE:array,ECOMMETA:array,ATTRMETA:array,TERMS:array,CORECUSTFIELDS:array}
	 */
	public static function build_auto_mapping( array $headers ) {
		$groups = array(
			'CORE'           => array(),
			'ECOMMETA'       => array(),
			'ATTRMETA'       => array(),
			'TERMS'          => array(),
			'CORECUSTFIELDS' => array(),
		);

		foreach ( $headers as $header ) {
			$header = HeaderMap::normalize_header( (string) $header );
			$field  = HeaderMap::resolve_header( $header );
			if ( ! $field ) {
				continue;
			}
			// Images maps to featured_image; also map gallery to same header for UI,
			// converter splits values later.
			$group = HeaderMap::get_field_group( $field );
			if ( ! isset( $groups[ $group ] ) ) {
				$groups[ $group ] = array();
			}
			$groups[ $group ][ $field ] = $header;

			if ( $field === 'featured_image' ) {
				$groups['ECOMMETA']['product_image_gallery'] = $header;
			}
			if ( $field === 'product_type' ) {
				$groups['ECOMMETA']['downloadable'] = $header;
				$groups['ECOMMETA']['virtual']      = $header;
			}
			if ( $field === 'featured' ) {
				$groups['ECOMMETA']['featured_product'] = $header;
			}
		}

		return $groups;
	}
}
