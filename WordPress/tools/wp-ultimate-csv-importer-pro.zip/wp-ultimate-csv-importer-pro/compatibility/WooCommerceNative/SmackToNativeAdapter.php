<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts Smack export row data into WooCommerce-native CSV columns.
 */
class SmackToNativeAdapter {

	/**
	 * Transform a Smack-keyed data row into WC-native header => value.
	 *
	 * @param array $smack_row Collected export data for one product/variation.
	 * @return array
	 */
	public static function convert_row( array $smack_row ) {
		// Normalize underscored meta keys commonly written by WooComExport.
		$aliases = array(
			'_regular_price'       => 'regular_price',
			'_sale_price'          => 'sale_price',
			'_stock'               => 'stock',
			'_stock_status'        => 'stock_status',
			'_downloadable'        => 'downloadable',
			'_virtual'             => 'virtual',
			'_purchase_note'       => 'purchase_note',
			'_thumbnail_id'        => 'featured_image',
			'_low_stock_threshold' => 'low_stock_threshold',
			'_global_unique_id'    => '_global_unique_id',
		);
		foreach ( $aliases as $from => $to ) {
			if ( ( ! isset( $smack_row[ $to ] ) || $smack_row[ $to ] === '' ) && isset( $smack_row[ $from ] ) && $smack_row[ $from ] !== '' ) {
				$smack_row[ $to ] = $smack_row[ $from ];
			}
		}

		$product_id = 0;
		if ( ! empty( $smack_row['ID'] ) && is_numeric( $smack_row['ID'] ) ) {
			$product_id = (int) $smack_row['ID'];
		} elseif ( ! empty( $smack_row['id'] ) && is_numeric( $smack_row['id'] ) ) {
			$product_id = (int) $smack_row['id'];
		}

		$product = ( $product_id && function_exists( 'wc_get_product' ) ) ? wc_get_product( $product_id ) : null;
		if ( $product instanceof \WC_Product ) {
			$smack_row = self::enrich_from_product( $smack_row, $product );
		}

		$wc = array();

		$order = HeaderMap::get_default_wc_column_order();
		foreach ( $order as $column_id => $header ) {
			$wc[ $header ] = self::get_column_value( $column_id, $header, $smack_row );
		}

		// Dynamic attribute columns.
		$attr_cols = AttributeColumnParser::to_wc_columns( $smack_row );
		$wc        = array_merge( $wc, $attr_cols );

		// Dynamic download columns.
		if ( ! empty( $smack_row['downloadable_files'] ) ) {
			$dl_cols = DownloadColumnParser::to_wc_columns( $smack_row['downloadable_files'] );
			$wc      = array_merge( $wc, $dl_cols );
		}

		// Meta: custom fields (keys starting with meta: or leftover custom).
		foreach ( $smack_row as $key => $value ) {
			if ( strpos( $key, 'meta:' ) === 0 ) {
				$meta_key = substr( $key, 5 );
				$wc[ 'Meta: ' . $meta_key ] = is_scalar( $value ) ? $value : '';
			}
		}

		/**
		 * Filter WC-native export row.
		 *
		 * @param array $wc        WC columns.
		 * @param array $smack_row Original Smack data.
		 */
		$wc = apply_filters( 'sm_uci_pro_wc_native_export_row', $wc, $smack_row );

		return $wc;
	}

	/**
	 * Align linked products, stock, and attribute taxonomy flags with live WC product (matches WC exporter).
	 *
	 * @param array       $smack_row Smack row.
	 * @param \WC_Product $product   Product.
	 * @return array
	 */
	private static function enrich_from_product( array $smack_row, $product ) {
		// Upsells / cross-sells as SKU or id:N (WC exporter style), not titles.
		$smack_row['upsell_ids']    = self::ids_to_wc_linked( $product->get_upsell_ids( 'edit' ) );
		$smack_row['crosssell_ids'] = self::ids_to_wc_linked( $product->get_cross_sell_ids( 'edit' ) );

		if ( $product->is_type( 'grouped' ) ) {
			$smack_row['grouping_product'] = self::ids_to_wc_linked( $product->get_children() );
		}

		if ( $product->is_type( 'variation' ) ) {
			$parent = wc_get_product( $product->get_parent_id() );
			if ( $parent ) {
				$parent_sku = $parent->get_sku( 'edit' );
				$smack_row['parent']    = $parent_sku !== '' ? $parent_sku : ( 'id:' . $parent->get_id() );
				$smack_row['PARENTSKU'] = $smack_row['parent'];
			}
			$manage = $product->get_manage_stock( 'edit' );
			if ( 'parent' === $manage ) {
				$smack_row['stock']  = 'parent';
				$smack_row['_stock'] = 'parent';
			}
		} else {
			// WC exporter only fills External URL / Button text for external products.
			if ( ! $product->is_type( 'external' ) ) {
				$smack_row['product_url'] = '';
				$smack_row['button_text'] = '';
			} else {
				$smack_row['product_url']  = $product->get_product_url();
				$smack_row['button_text'] = $product->get_button_text();
			}
		}

		// Ensure attribute taxonomy / visible flags exist from product attributes.
		$attributes = $product->get_attributes();
		if ( ! empty( $attributes ) && is_array( $attributes ) ) {
			$n = 1;
			foreach ( $attributes as $attribute ) {
				if ( is_a( $attribute, 'WC_Product_Attribute' ) ) {
					$name = wc_attribute_label( $attribute->get_name() );
					if ( empty( $smack_row[ 'product_attribute_name' . $n ] ) ) {
						$smack_row[ 'product_attribute_name' . $n ] = $name;
					}
					if ( ! isset( $smack_row[ 'product_attribute_taxonomy' . $n ] ) || $smack_row[ 'product_attribute_taxonomy' . $n ] === '' ) {
						$smack_row[ 'product_attribute_taxonomy' . $n ] = $attribute->is_taxonomy() ? '1' : '0';
					}
					if ( ! isset( $smack_row[ 'product_attribute_visible' . $n ] ) || $smack_row[ 'product_attribute_visible' . $n ] === '' ) {
						$smack_row[ 'product_attribute_visible' . $n ] = $attribute->get_visible() ? '1' : '0';
					}
					if ( empty( $smack_row[ 'product_attribute_value' . $n ] ) ) {
						if ( $attribute->is_taxonomy() ) {
							$terms = $attribute->get_terms();
							$vals  = array();
							if ( $terms ) {
								foreach ( $terms as $term ) {
									$vals[] = $term->name;
								}
							}
							$smack_row[ 'product_attribute_value' . $n ] = implode( '|', $vals );
						} else {
							$opts = $attribute->get_options();
							$smack_row[ 'product_attribute_value' . $n ] = is_array( $opts ) ? implode( '|', $opts ) : (string) $opts;
						}
					}
					$n++;
				} elseif ( $product->is_type( 'variation' ) && is_string( $attribute ) ) {
					// Variation attributes are slug => value map when using get_attributes() on variations... handled below.
					break;
				}
			}
		}

		if ( $product->is_type( 'variation' ) ) {
			$var_attrs = $product->get_attributes();
			$n         = 1;
			foreach ( $var_attrs as $taxonomy => $slug ) {
				$label = wc_attribute_label( $taxonomy );
				$term  = get_term_by( 'slug', $slug, $taxonomy );
				$value = ( $term && ! is_wp_error( $term ) ) ? $term->name : $slug;
				$smack_row[ 'product_attribute_name' . $n ]     = $label;
				$smack_row[ 'product_attribute_value' . $n ]    = $value;
				$smack_row[ 'product_attribute_taxonomy' . $n ] = taxonomy_exists( $taxonomy ) ? '1' : '0';
				$smack_row[ 'product_attribute_visible' . $n ]  = '';
				$n++;
			}
		}

		return $smack_row;
	}

	/**
	 * @param int[] $ids Product IDs.
	 * @return string Pipe-separated SKU or id:N (converted later to ", ").
	 */
	private static function ids_to_wc_linked( array $ids ) {
		$out = array();
		foreach ( $ids as $id ) {
			$p = wc_get_product( (int) $id );
			if ( ! $p ) {
				continue;
			}
			$sku = $p->get_sku( 'edit' );
			$out[] = $sku !== '' ? $sku : ( 'id:' . $p->get_id() );
		}
		return implode( '|', $out );
	}

	/**
	 * @param string $column_id WC column id.
	 * @param string $header    WC header.
	 * @param array  $row       Smack row.
	 * @return string
	 */
	private static function get_column_value( $column_id, $header, array $row ) {
		switch ( $column_id ) {
			case 'id':
				return isset( $row['ID'] ) ? (string) $row['ID'] : ( isset( $row['id'] ) ? (string) $row['id'] : '' );
			case 'type':
				$ptype = isset( $row['product_type'] ) ? $row['product_type'] : '';
				$dl    = isset( $row['downloadable'] ) ? $row['downloadable'] : ( isset( $row['_downloadable'] ) ? $row['_downloadable'] : '' );
				$virt  = isset( $row['virtual'] ) ? $row['virtual'] : ( isset( $row['_virtual'] ) ? $row['_virtual'] : '' );
				return ValueConverter::build_wc_type( $ptype, $dl, $virt );
			case 'sku':
				if ( ! empty( $row['PRODUCTSKU'] ) ) {
					return $row['PRODUCTSKU'];
				}
				if ( ! empty( $row['VARIATIONSKU'] ) ) {
					return $row['VARIATIONSKU'];
				}
				return isset( $row['sku'] ) ? $row['sku'] : '';
			case 'global_unique_id':
				return isset( $row['_global_unique_id'] ) ? $row['_global_unique_id'] : '';
			case 'name':
				return isset( $row['post_title'] ) ? $row['post_title'] : '';
			case 'published':
				$status = isset( $row['post_status'] ) ? $row['post_status'] : 'publish';
				return ValueConverter::status_to_published( $status );
			case 'featured':
				$feat = isset( $row['featured'] ) ? $row['featured'] : ( isset( $row['featured_product'] ) ? $row['featured_product'] : '' );
				return ValueConverter::smack_bool_to_wc( $feat );
			case 'catalog_visibility':
				return ValueConverter::visibility_smack_to_wc( isset( $row['visibility'] ) ? $row['visibility'] : '1' );
			case 'short_description':
				return ValueConverter::description_smack_to_wc( isset( $row['post_excerpt'] ) ? $row['post_excerpt'] : '' );
			case 'description':
				return ValueConverter::description_smack_to_wc( isset( $row['post_content'] ) ? $row['post_content'] : '' );
			case 'date_on_sale_from':
				return isset( $row['sale_price_dates_from'] ) ? $row['sale_price_dates_from'] : '';
			case 'date_on_sale_to':
				return isset( $row['sale_price_dates_to'] ) ? $row['sale_price_dates_to'] : '';
			case 'tax_status':
				return ValueConverter::tax_status_smack_to_wc( isset( $row['tax_status'] ) ? $row['tax_status'] : '' );
			case 'tax_class':
				return isset( $row['tax_class'] ) ? $row['tax_class'] : '';
			case 'stock_status':
				return ValueConverter::stock_status_smack_to_wc( isset( $row['stock_status'] ) ? $row['stock_status'] : ( isset( $row['_stock_status'] ) ? $row['_stock_status'] : '' ) );
			case 'stock':
				return isset( $row['stock'] ) ? $row['stock'] : ( isset( $row['_stock'] ) ? $row['_stock'] : '' );
			case 'low_stock_amount':
				return isset( $row['low_stock_threshold'] ) ? $row['low_stock_threshold'] : '';
			case 'backorders':
				return ValueConverter::backorders_smack_to_wc( isset( $row['backorders'] ) ? $row['backorders'] : '' );
			case 'sold_individually':
				return ValueConverter::smack_bool_to_wc( isset( $row['sold_individually'] ) ? $row['sold_individually'] : '' );
			case 'weight':
			case 'length':
			case 'width':
			case 'height':
				return isset( $row[ $column_id ] ) ? $row[ $column_id ] : '';
			case 'reviews_allowed':
				return ValueConverter::comment_status_to_reviews( isset( $row['comment_status'] ) ? $row['comment_status'] : '' );
			case 'purchase_note':
				return isset( $row['purchase_note'] ) ? $row['purchase_note'] : '';
			case 'sale_price':
				return isset( $row['sale_price'] ) ? $row['sale_price'] : '';
			case 'regular_price':
				return isset( $row['regular_price'] ) ? $row['regular_price'] : '';
			case 'category_ids':
				return isset( $row['product_category'] ) ? self::format_multi( $row['product_category'] ) : '';
			case 'tag_ids':
				return isset( $row['product_tag'] ) ? self::format_multi( $row['product_tag'] ) : '';
			case 'shipping_class_id':
				return isset( $row['product_shipping_class'] ) ? $row['product_shipping_class'] : '';
			case 'images':
				$featured = isset( $row['featured_image'] ) ? $row['featured_image'] : '';
				$gallery  = isset( $row['product_image_gallery'] ) ? $row['product_image_gallery'] : '';
				return ImageFormatter::merge_to_wc_images( $featured, $gallery );
			case 'download_limit':
				return isset( $row['download_limit'] ) ? $row['download_limit'] : '';
			case 'download_expiry':
				return isset( $row['download_expiry'] ) ? $row['download_expiry'] : '';
			case 'parent_id':
				$parent = isset( $row['parent'] ) ? $row['parent'] : ( isset( $row['PARENTSKU'] ) ? $row['PARENTSKU'] : '' );
				return ValueConverter::linked_products_smack_to_wc( $parent );
			case 'grouped_products':
				return ValueConverter::linked_products_smack_to_wc( isset( $row['grouping_product'] ) ? $row['grouping_product'] : '' );
			case 'upsell_ids':
				return ValueConverter::linked_products_smack_to_wc( isset( $row['upsell_ids'] ) ? $row['upsell_ids'] : '' );
			case 'cross_sell_ids':
				return ValueConverter::linked_products_smack_to_wc( isset( $row['crosssell_ids'] ) ? $row['crosssell_ids'] : '' );
			case 'product_url':
				return isset( $row['product_url'] ) ? $row['product_url'] : '';
			case 'button_text':
				return isset( $row['button_text'] ) ? $row['button_text'] : '';
			case 'menu_order':
				if ( isset( $row['menu_order'] ) && $row['menu_order'] !== '' ) {
					return $row['menu_order'];
				}
				return isset( $row['position'] ) ? $row['position'] : '';
			default:
				return '';
		}
	}

	/**
	 * Normalize multi-value separators to WC ", ".
	 *
	 * @param string $value Value.
	 * @return string
	 */
	private static function format_multi( $value ) {
		$value = (string) $value;
		$parts = preg_split( '/\s*[|,]\s*/', $value );
		$parts = array_filter( array_map( 'trim', $parts ), 'strlen' );
		return implode( ', ', $parts );
	}

	/**
	 * Build ordered header list for a set of converted rows (union of keys, WC default order first).
	 *
	 * @param array[] $rows Converted WC rows.
	 * @return string[]
	 */
	public static function build_headers_from_rows( array $rows ) {
		$default_headers = array_values( HeaderMap::get_default_wc_column_order() );
		$extra           = array();

		foreach ( $rows as $row ) {
			foreach ( array_keys( $row ) as $header ) {
				if ( ! in_array( $header, $default_headers, true ) && ! in_array( $header, $extra, true ) ) {
					$extra[] = $header;
				}
			}
		}

		// Sort extras: attributes, downloads, meta.
		usort(
			$extra,
			function ( $a, $b ) {
				$score = function ( $h ) {
					if ( preg_match( '/^Attribute\s+(\d+)/i', $h, $m ) ) {
						return 1000 + (int) $m[1];
					}
					if ( preg_match( '/^Download\s+(\d+)/i', $h, $m ) ) {
						return 2000 + (int) $m[1];
					}
					if ( preg_match( '/^Meta:/i', $h ) ) {
						return 3000;
					}
					return 4000;
				};
				return $score( $a ) - $score( $b );
			}
		);

		return array_merge( $default_headers, $extra );
	}
}
