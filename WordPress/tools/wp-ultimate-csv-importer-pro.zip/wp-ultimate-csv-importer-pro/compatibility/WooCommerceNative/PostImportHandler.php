<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Apply WC-native fields that are missing from the core product import switch
 * (categories, tags, featured image, stock status strings, linked product remap).
 */
class PostImportHandler {

	/**
	 * @param int                  $product_id  Product ID.
	 * @param array                $post_values Mapped values (may include merge_mapped_extras).
	 * @param array<string, mixed> $context     Import context.
	 */
	public static function apply( $product_id, array $post_values, array $context ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}

		self::apply_terms( $product_id, $post_values, $context );
		self::apply_featured_image( $product, $post_values, $context );
		self::apply_stock_status( $product, $post_values );
		self::apply_tax_class( $product, $post_values );
		self::apply_linked_products( $product, $post_values, $context );
		$product->save();

		$hash_key = isset( $context['hash_key'] ) ? $context['hash_key'] : '';
		if ( $hash_key !== '' ) {
			ImportBridge::register_imported_product( $hash_key, $product_id, $post_values );
		}
	}

	/**
	 * @param int                  $product_id  Product ID.
	 * @param array                $post_values Values.
	 * @param array<string, mixed> $context     Context.
	 */
	private static function apply_terms( $product_id, array $post_values, array $context ) {
		$term_data = array();
		if ( ! empty( $post_values['product_category'] ) ) {
			$term_data['product_category'] = $post_values['product_category'];
		}
		if ( ! empty( $post_values['product_tag'] ) ) {
			$term_data['product_tag'] = $post_values['product_tag'];
		}
		if ( empty( $term_data ) ) {
			return;
		}

		$terms_instance = \Smackcoders\UCI\Proaddons\UltimatePro\TermsandTaxonomiesImport::getInstance();
		$mode           = isset( $context['mode'] ) ? $context['mode'] : 'Insert';
		$line_number    = isset( $context['line_number'] ) ? $context['line_number'] : 0;
		$gmode          = isset( $context['gmode'] ) ? $context['gmode'] : '';

		$terms_instance->terms_taxo_import_function(
			$term_data,
			'WooCommerce Product',
			$product_id,
			$mode,
			$line_number,
			array(),
			$gmode,
			null
		);
	}

	/**
	 * @param \WC_Product          $product     Product.
	 * @param array                $post_values Values.
	 * @param array<string, mixed> $context     Context.
	 */
	private static function apply_featured_image( $product, array $post_values, array $context ) {
		if ( empty( $post_values['featured_image'] ) ) {
			return;
		}
		if ( $product->get_image_id() ) {
			// Allow update-mode replacements when a new featured image value is provided.
			$mode = isset( $context['mode'] ) ? (string) $context['mode'] : '';
			if ( strcasecmp( $mode, 'Update' ) !== 0 ) {
				return;
			}
		}

		$image = trim( (string) $post_values['featured_image'] );
		if ( $image === '' ) {
			return;
		}

		if ( is_numeric( $image ) ) {
			$product->set_image_id( (int) $image );
			return;
		}

		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling' ) ) {
			return;
		}

		$media_instance = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::getInstance();
		$line_number    = isset( $context['line_number'] ) ? $context['line_number'] : 0;
		$image_meta     = isset( $context['image_meta'] ) ? $context['image_meta'] : array();
		$unikey_value   = isset( $context['unikey_value'] ) ? $context['unikey_value'] : '';
		$hash_key       = isset( $context['hash_key'] ) ? $context['hash_key'] : '';

		$attachment_id = $media_instance->image_meta_table_entry(
			$line_number,
			$image_meta,
			$product->get_id(),
			'featured_image',
			$image,
			$hash_key !== '' ? $hash_key : $unikey_value,
			'product',
			'post',
			isset( $context['templatekey'] ) ? $context['templatekey'] : null,
			isset( $context['gmode'] ) ? $context['gmode'] : null,
			'',
			'',
			'',
			'',
			0
		);

		if ( $attachment_id ) {
			$product->set_image_id( (int) $attachment_id );
		}
	}

	/**
	 * @param \WC_Product $product     Product.
	 * @param array       $post_values Values.
	 */
	private static function apply_stock_status( $product, array $post_values ) {
		if ( empty( $post_values['stock_status'] ) ) {
			return;
		}

		$status = self::normalize_stock_status( $post_values['stock_status'] );
		if ( $status === '' || $product->is_type( 'external' ) ) {
			return;
		}

		if ( method_exists( $product, 'set_stock_status' ) ) {
			$product->set_stock_status( $status );
		}
	}

	/**
	 * @param \WC_Product $product     Product.
	 * @param array       $post_values Values.
	 */
	private static function apply_tax_class( $product, array $post_values ) {
		if ( empty( $post_values['tax_class'] ) ) {
			return;
		}
		$tax_class = trim( (string) $post_values['tax_class'] );
		if ( strtolower( $tax_class ) === 'parent' ) {
			if ( $product->is_type( 'variation' ) && method_exists( $product, 'set_tax_class' ) ) {
				$product->set_tax_class( '' );
			}
			return;
		}
		if ( method_exists( $product, 'set_tax_class' ) ) {
			$product->set_tax_class( $tax_class );
		}
	}

	/**
	 * @param \WC_Product          $product     Product.
	 * @param array                $post_values Values.
	 * @param array<string, mixed> $context     Context.
	 */
	private static function apply_linked_products( $product, array $post_values, array $context ) {
		$hash_key = isset( $context['hash_key'] ) ? $context['hash_key'] : '';

		if ( ! empty( $post_values['upsell_ids'] ) && method_exists( $product, 'set_upsell_ids' ) ) {
			$ids = ImportBridge::resolve_linked_product_ids( $post_values['upsell_ids'], $hash_key );
			if ( ! empty( $ids ) ) {
				$product->set_upsell_ids( $ids );
			} else {
				ImportBridge::queue_deferred_link( $hash_key, $product->get_id(), 'upsell_ids', $post_values['upsell_ids'] );
			}
		}
		if ( ! empty( $post_values['crosssell_ids'] ) && method_exists( $product, 'set_cross_sell_ids' ) ) {
			$ids = ImportBridge::resolve_linked_product_ids( $post_values['crosssell_ids'], $hash_key );
			if ( ! empty( $ids ) ) {
				$product->set_cross_sell_ids( $ids );
			} else {
				ImportBridge::queue_deferred_link( $hash_key, $product->get_id(), 'crosssell_ids', $post_values['crosssell_ids'] );
			}
		}
	}

	/**
	 * @param mixed $value Raw stock status.
	 * @return string instock|outofstock|onbackorder|''
	 */
	public static function normalize_stock_status( $value ) {
		$val = strtolower( trim( (string) $value ) );
		if ( in_array( $val, array( 'instock', 'outofstock', 'onbackorder' ), true ) ) {
			return $val;
		}
		if ( in_array( $val, array( '1', 'yes', 'true' ), true ) ) {
			return 'instock';
		}
		if ( in_array( $val, array( '0', 'no', 'false', '2' ), true ) ) {
			return 'outofstock';
		}
		if ( $val === 'backorder' ) {
			return 'onbackorder';
		}
		return $val;
	}
}
