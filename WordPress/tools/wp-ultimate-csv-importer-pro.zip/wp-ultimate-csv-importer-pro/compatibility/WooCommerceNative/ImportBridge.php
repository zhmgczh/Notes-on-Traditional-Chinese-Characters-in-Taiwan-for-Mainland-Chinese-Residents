<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks WooCommerce-native CSV detection and conversion into the import pipeline.
 */
class ImportBridge {

	/**
	 * Cached converted rows keyed by hash|line.
	 *
	 * @var array<string, array>
	 */
	private static $converted_cache = array();

	/**
	 * Original SKU => assigned SKU when Insert mode avoids duplicates (-IMP suffix).
	 *
	 * @var array<string, string>
	 */
	private static $sku_remap = array();

	/**
	 * @var array<string, bool>
	 */
	private static $sku_remap_loaded = array();

	/**
	 * Transient TTL for cross-request SKU remap during batched imports.
	 */
	const SKU_REMAP_TTL = 86400;

	/**
	 * Record SKU assigned during import so child rows (Parent column) resolve correctly.
	 *
	 * @param string $original Original CSV SKU.
	 * @param string $assigned SKU stored on the product.
	 * @param string $hash_key Import session hash (persists remap across AJAX chunks).
	 */
	public static function register_sku_remap( $original, $assigned, $hash_key = '' ) {
		$original = trim( (string) $original );
		$assigned = trim( (string) $assigned );
		if ( $original === '' || $assigned === '' || $original === $assigned ) {
			return;
		}
		if ( $hash_key !== '' ) {
			self::load_sku_remap( $hash_key );
		}
		self::$sku_remap[ $original ] = $assigned;
		if ( $hash_key !== '' ) {
			$stored = get_transient( self::sku_remap_transient_key( $hash_key ) );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			$stored[ $original ] = $assigned;
			set_transient( self::sku_remap_transient_key( $hash_key ), $stored, self::SKU_REMAP_TTL );
		}
	}

	/**
	 * Resolve parent SKU using import-time remapping (e.g. TEST-001 → TEST-001-IMP).
	 *
	 * @param string $sku Parent reference from CSV.
	 * @param string $hash_key Import session hash.
	 * @return string
	 */
	public static function resolve_parent_sku( $sku, $hash_key = '' ) {
		$sku = trim( (string) $sku );
		if ( $sku === '' ) {
			return '';
		}
		self::load_sku_remap( $hash_key );
		return isset( self::$sku_remap[ $sku ] ) ? self::$sku_remap[ $sku ] : $sku;
	}

	/**
	 * Get converted Smack row for a CSV line (for field verification logging).
	 *
	 * @param string $hash_key    Import hash.
	 * @param int    $line_number Line number.
	 * @return array|null
	 */
	public static function get_converted_row( $hash_key, $line_number ) {
		$cache_key = $hash_key . '|' . $line_number;
		return isset( self::$converted_cache[ $cache_key ] ) ? self::$converted_cache[ $cache_key ] : null;
	}

	/**
	 * Resolve linked product cell to IDs, applying SKU remap from Insert imports.
	 *
	 * @param string $value    Comma/pipe separated SKUs or IDs.
	 * @param string $hash_key Import hash.
	 * @return int[]
	 */
	public static function resolve_linked_product_ids( $value, $hash_key = '' ) {
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return array();
		}
		self::load_sku_remap( $hash_key );
		$value   = str_replace( '|', ',', $value );
		$parts   = preg_split( '/\s*,\s*/', $value );
		$ids     = array();
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( $part === '' ) {
				continue;
			}
			if ( preg_match( '/^id:(\d+)$/i', $part, $m ) ) {
				$mapped = self::lookup_csv_product_id( $hash_key, (int) $m[1] );
				$ids[]  = $mapped > 0 ? $mapped : (int) $m[1];
				continue;
			}
			if ( is_numeric( $part ) ) {
				$mapped = self::lookup_csv_product_id( $hash_key, (int) $part );
				$ids[]  = $mapped > 0 ? $mapped : (int) $part;
				continue;
			}
			$sku = self::resolve_parent_sku( $part, $hash_key );
			$id  = self::lookup_sku_product_id( $hash_key, $sku );
			if ( $id <= 0 ) {
				$id = ProductResolver::resolve_product_id( $sku );
			}
			if ( $id <= 0 && $sku !== $part ) {
				$id = ProductResolver::resolve_product_id( $part );
			}
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * @param string $hash_key Import hash.
	 * @return string
	 */
	private static function sku_remap_transient_key( $hash_key ) {
		return 'sm_uci_wc_sku_remap_' . $hash_key;
	}

	private static function sku_map_transient_key( $hash_key ) {
		return 'sm_uci_wc_sku_map_' . $hash_key;
	}

	private static function csv_id_map_transient_key( $hash_key ) {
		return 'sm_uci_wc_csv_id_map_' . $hash_key;
	}

	private static function deferred_links_transient_key( $hash_key ) {
		return 'sm_uci_wc_deferred_links_' . $hash_key;
	}

	private static function orphan_vars_transient_key( $hash_key ) {
		return 'sm_uci_wc_orphan_vars_' . $hash_key;
	}

	/**
	 * @param string $hash_key Import hash.
	 * @param string $sku      SKU.
	 * @param int    $product_id Product ID.
	 */
	private static function register_sku_product_id( $hash_key, $sku, $product_id ) {
		$sku = trim( (string) $sku );
		if ( $hash_key === '' || $sku === '' || ! $product_id ) {
			return;
		}
		$stored = get_transient( self::sku_map_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[ $sku ] = (int) $product_id;
		set_transient( self::sku_map_transient_key( $hash_key ), $stored, self::SKU_REMAP_TTL );
	}

	/**
	 * @param string $hash_key   Import hash.
	 * @param int    $csv_id     WC CSV ID column value.
	 * @param int    $product_id Product ID.
	 */
	private static function register_csv_product_id( $hash_key, $csv_id, $product_id ) {
		if ( $hash_key === '' || ! $csv_id || ! $product_id ) {
			return;
		}
		$stored = get_transient( self::csv_id_map_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[ (string) $csv_id ] = (int) $product_id;
		set_transient( self::csv_id_map_transient_key( $hash_key ), $stored, self::SKU_REMAP_TTL );
	}

	/**
	 * @param string $hash_key Import hash.
	 * @param string $sku      SKU.
	 * @return int
	 */
	private static function lookup_sku_product_id( $hash_key, $sku ) {
		$sku = trim( (string) $sku );
		if ( $hash_key === '' || $sku === '' ) {
			return 0;
		}
		$stored = get_transient( self::sku_map_transient_key( $hash_key ) );
		return ( is_array( $stored ) && isset( $stored[ $sku ] ) ) ? (int) $stored[ $sku ] : 0;
	}

	/**
	 * @param string $hash_key Import hash.
	 * @param int    $csv_id   CSV ID.
	 * @return int
	 */
	private static function lookup_csv_product_id( $hash_key, $csv_id ) {
		if ( $hash_key === '' || ! $csv_id ) {
			return 0;
		}
		$stored = get_transient( self::csv_id_map_transient_key( $hash_key ) );
		return ( is_array( $stored ) && isset( $stored[ (string) $csv_id ] ) ) ? (int) $stored[ (string) $csv_id ] : 0;
	}

	/**
	 * Load persisted SKU remap from transient (batched AJAX imports).
	 *
	 * @param string $hash_key Import hash.
	 */
	private static function load_sku_remap( $hash_key ) {
		if ( $hash_key === '' || ! empty( self::$sku_remap_loaded[ $hash_key ] ) ) {
			return;
		}
		$stored = get_transient( self::sku_remap_transient_key( $hash_key ) );
		if ( is_array( $stored ) ) {
			self::$sku_remap = array_merge( $stored, self::$sku_remap );
		}
		self::$sku_remap_loaded[ $hash_key ] = true;
	}

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'sm_uci_pro_import_row_data', array( __CLASS__, 'filter_import_row' ), 5, 4 );
		add_filter( 'sm_uci_pro_article_data', array( __CLASS__, 'filter_article_data' ), 5, 4 );
		add_action( 'sm_uci_pro_before_import', array( __CLASS__, 'on_before_import' ), 5, 1 );
		add_action( 'sm_uci_pro_after_import', array( __CLASS__, 'on_after_import' ), 20, 2 );
	}

	/**
	 * Clear session transients at import start.
	 *
	 * @param string $import_id Import hash.
	 */
	public static function on_before_import( $import_id ) {
		if ( empty( $import_id ) ) {
			return;
		}
		delete_transient( self::sku_remap_transient_key( $import_id ) );
		delete_transient( self::sku_map_transient_key( $import_id ) );
		delete_transient( self::csv_id_map_transient_key( $import_id ) );
		delete_transient( self::deferred_links_transient_key( $import_id ) );
		delete_transient( self::orphan_vars_transient_key( $import_id ) );
		self::$sku_remap        = array();
		self::$sku_remap_loaded = array();
	}

	/**
	 * Finalize deferred links and orphan variations after import completes.
	 *
	 * @param string       $import_id Import hash.
	 * @param object|array $import_object Import object.
	 */
	public static function on_after_import( $import_id, $import_object = null ) {
		if ( empty( $import_id ) ) {
			return;
		}
		self::flush_deferred_links( $import_id );
		self::retry_orphan_variations( $import_id );
	}

	/**
	 * Register product SKU and CSV ID for same-batch resolution.
	 *
	 * @param string $hash_key    Import hash.
	 * @param int    $product_id  Product ID.
	 * @param array  $post_values Mapped row values.
	 */
	public static function register_imported_product( $hash_key, $product_id, array $post_values = array() ) {
		if ( ! $hash_key || ! $product_id ) {
			return;
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		$sku = $product->get_sku();
		if ( $sku !== '' ) {
			self::register_sku_product_id( $hash_key, $sku, $product_id );
		}
		if ( ! empty( $post_values['ID'] ) && is_numeric( $post_values['ID'] ) ) {
			self::register_csv_product_id( $hash_key, (int) $post_values['ID'], $product_id );
		}
		if ( ! empty( $post_values['PRODUCTSKU'] ) ) {
			self::register_sku_product_id( $hash_key, (string) $post_values['PRODUCTSKU'], $product_id );
		}
		self::flush_deferred_links( $hash_key );
		self::retry_orphan_variations( $hash_key );
	}

	/**
	 * Resolve parent reference (SKU, id:N, numeric CSV ID) to product ID.
	 *
	 * @param string $parent_ref Parent cell value.
	 * @param string $hash_key   Import hash.
	 * @return int
	 */
	public static function resolve_parent_product_id( $parent_ref, $hash_key = '' ) {
		$parent_ref = trim( (string) $parent_ref );
		if ( $parent_ref === '' ) {
			return 0;
		}
		if ( preg_match( '/^id:(\d+)$/i', $parent_ref, $m ) ) {
			$mapped = self::lookup_csv_product_id( $hash_key, (int) $m[1] );
			if ( $mapped > 0 ) {
				return $mapped;
			}
			return ProductResolver::resolve_product_id( $parent_ref );
		}
		if ( is_numeric( $parent_ref ) ) {
			$mapped = self::lookup_csv_product_id( $hash_key, (int) $parent_ref );
			if ( $mapped > 0 ) {
				return $mapped;
			}
		}
		$sku = self::resolve_parent_sku( $parent_ref, $hash_key );
		$from_session = self::lookup_sku_product_id( $hash_key, $sku );
		if ( $from_session > 0 ) {
			return $from_session;
		}
		return ProductResolver::resolve_product_id( $sku );
	}

	/**
	 * Queue upsell/cross-sell when target products are not imported yet.
	 *
	 * @param string $hash_key   Import hash.
	 * @param int    $product_id Source product ID.
	 * @param string $field      upsell_ids|crosssell_ids.
	 * @param string $raw_value  Raw linked cell.
	 */
	public static function queue_deferred_link( $hash_key, $product_id, $field, $raw_value ) {
		if ( ! $hash_key || ! $product_id || $raw_value === '' ) {
			return;
		}
		$stored = get_transient( self::deferred_links_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[] = array(
			'product_id' => (int) $product_id,
			'field'      => $field,
			'value'      => (string) $raw_value,
		);
		set_transient( self::deferred_links_transient_key( $hash_key ), $stored, self::SKU_REMAP_TTL );
	}

	/**
	 * Queue variation for parent retry when parent is imported later in the batch.
	 *
	 * @param string $hash_key   Import hash.
	 * @param int    $variation_id Variation ID.
	 * @param string $parent_ref Parent reference from CSV.
	 */
	public static function queue_orphan_variation( $hash_key, $variation_id, $parent_ref ) {
		if ( ! $hash_key || ! $variation_id || $parent_ref === '' ) {
			return;
		}
		$stored = get_transient( self::orphan_vars_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[] = array(
			'variation_id' => (int) $variation_id,
			'parent_ref'   => (string) $parent_ref,
		);
		set_transient( self::orphan_vars_transient_key( $hash_key ), $stored, self::SKU_REMAP_TTL );
	}

	/**
	 * Retry deferred upsells/cross-sells after new products are registered.
	 *
	 * @param string $hash_key Import hash.
	 */
	public static function flush_deferred_links( $hash_key ) {
		if ( ! $hash_key ) {
			return;
		}
		$stored = get_transient( self::deferred_links_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) || empty( $stored ) ) {
			return;
		}
		$remaining = array();
		foreach ( $stored as $item ) {
			if ( empty( $item['product_id'] ) || empty( $item['field'] ) || empty( $item['value'] ) ) {
				continue;
			}
			$ids = self::resolve_linked_product_ids( $item['value'], $hash_key );
			if ( empty( $ids ) ) {
				$remaining[] = $item;
				continue;
			}
			$product = wc_get_product( (int) $item['product_id'] );
			if ( ! $product ) {
				continue;
			}
			if ( $item['field'] === 'upsell_ids' && method_exists( $product, 'set_upsell_ids' ) ) {
				$product->set_upsell_ids( $ids );
			} elseif ( $item['field'] === 'crosssell_ids' && method_exists( $product, 'set_cross_sell_ids' ) ) {
				$product->set_cross_sell_ids( $ids );
			}
			$product->save();
		}
		if ( empty( $remaining ) ) {
			delete_transient( self::deferred_links_transient_key( $hash_key ) );
		} else {
			set_transient( self::deferred_links_transient_key( $hash_key ), $remaining, self::SKU_REMAP_TTL );
		}
	}

	/**
	 * Link variations whose parent row appears later in the CSV batch.
	 *
	 * @param string $hash_key Import hash.
	 */
	public static function retry_orphan_variations( $hash_key ) {
		if ( ! $hash_key ) {
			return;
		}
		$stored = get_transient( self::orphan_vars_transient_key( $hash_key ) );
		if ( ! is_array( $stored ) || empty( $stored ) ) {
			return;
		}
		$remaining = array();
		foreach ( $stored as $item ) {
			if ( empty( $item['variation_id'] ) || empty( $item['parent_ref'] ) ) {
				continue;
			}
			$parent_id = self::resolve_parent_product_id( $item['parent_ref'], $hash_key );
			if ( $parent_id <= 0 ) {
				$remaining[] = $item;
				continue;
			}
			$variation = wc_get_product( (int) $item['variation_id'] );
			if ( ! $variation || ! $variation->is_type( 'variation' ) ) {
				continue;
			}
			$variation->set_parent_id( $parent_id );
			$variation->save();
			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients( $parent_id );
			}
		}
		if ( empty( $remaining ) ) {
			delete_transient( self::orphan_vars_transient_key( $hash_key ) );
		} else {
			set_transient( self::orphan_vars_transient_key( $hash_key ), $remaining, self::SKU_REMAP_TTL );
		}
	}

	/**
	 * @param string $hash_key Import hash.
	 * @param int    $line_number Line number.
	 * @return bool
	 */
	public static function has_converted_row( $hash_key, $line_number ) {
		return null !== self::get_converted_row( $hash_key, $line_number );
	}

	/**
	 * Detect format from headers and store for session; convert cell values in place
	 * so mapped Smack fields receive WC-compatible converted data.
	 *
	 * @param array  $value_array  Positional row values.
	 * @param string $import_id    Hash key.
	 * @param int    $line_number  Line number.
	 * @param array  $header_array Headers.
	 * @return array
	 */
	public static function filter_import_row( $value_array, $import_id = '', $line_number = 0, $header_array = array() ) {
		if ( ! is_array( $value_array ) || ! is_array( $header_array ) || empty( $header_array ) ) {
			return $value_array;
		}

		// Detect and persist format for the whole import session.
		if ( $import_id ) {
			$stored = get_transient( 'sm_uci_wc_csv_format_' . $import_id );
			if ( false === $stored ) {
				$format = FormatDetector::detect( $header_array );
				FormatDetector::store_for_import( $import_id, $format );
			} else {
				$format = $stored;
			}
		} else {
			$format = FormatDetector::detect( $header_array );
		}

		if ( $format !== HeaderMap::FORMAT_NATIVE ) {
			return $value_array;
		}

		$assoc = self::combine( $header_array, $value_array );
		$smack = NativeToSmackAdapter::convert_row( $assoc );

		$cache_key = $import_id . '|' . $line_number;
		self::$converted_cache[ $cache_key ] = $smack;

		// Rewrite positional values for mapped WC headers so converters apply when
		// get_header_values pulls by CSV header name.
		$new_values = $value_array;
		foreach ( $header_array as $idx => $header ) {
			$header = HeaderMap::normalize_header( (string) $header );
			$field  = HeaderMap::resolve_header( $header );
			if ( ! $field || ! array_key_exists( $idx, $new_values ) ) {
				continue;
			}
			if ( isset( $smack[ $field ] ) ) {
				$new_values[ $idx ] = $smack[ $field ];
			}
			// Special: Type header should yield product_type numeric for product_type mapping,
			// but downloadable/virtual also map to Type — keep raw Type for those via cache merge.
			if ( strcasecmp( $header, 'Type' ) === 0 && isset( $smack['product_type'] ) ) {
				$new_values[ $idx ] = $smack['product_type'];
			}
			if ( strcasecmp( $header, 'Images' ) === 0 && isset( $smack['featured_image'] ) ) {
				// featured_image mapping gets featured; gallery handled in merge_mapped_extras.
				$new_values[ $idx ] = $smack['featured_image'];
			}
			if ( strcasecmp( $header, 'Published' ) === 0 && isset( $smack['post_status'] ) ) {
				$new_values[ $idx ] = $smack['post_status'];
			}
			if ( strcasecmp( $header, 'Is featured?' ) === 0 && isset( $smack['featured'] ) ) {
				$new_values[ $idx ] = $smack['featured'];
			}
			if ( strcasecmp( $header, 'Visibility in catalog' ) === 0 && isset( $smack['visibility'] ) ) {
				$new_values[ $idx ] = $smack['visibility'];
			}
			if ( strcasecmp( $header, 'In stock?' ) === 0 && isset( $smack['stock_status'] ) ) {
				$new_values[ $idx ] = $smack['stock_status'];
			}
			if ( strcasecmp( $header, 'Backorders allowed?' ) === 0 && isset( $smack['backorders'] ) ) {
				$new_values[ $idx ] = $smack['backorders'];
			}
			if ( strcasecmp( $header, 'Tax status' ) === 0 && isset( $smack['tax_status'] ) ) {
				$new_values[ $idx ] = $smack['tax_status'];
			}
			if ( strcasecmp( $header, 'Allow customer reviews?' ) === 0 && isset( $smack['comment_status'] ) ) {
				$new_values[ $idx ] = $smack['comment_status'];
			}
			if ( strcasecmp( $header, 'Description' ) === 0 && isset( $smack['post_content'] ) ) {
				$new_values[ $idx ] = $smack['post_content'];
			}
			if ( strcasecmp( $header, 'Short description' ) === 0 && isset( $smack['post_excerpt'] ) ) {
				$new_values[ $idx ] = $smack['post_excerpt'];
			}
			if ( strcasecmp( $header, 'Parent' ) === 0 && isset( $smack['parent'] ) ) {
				$new_values[ $idx ] = $smack['parent'];
			}
			if ( strcasecmp( $header, 'Upsells' ) === 0 && isset( $smack['upsell_ids'] ) ) {
				$new_values[ $idx ] = $smack['upsell_ids'];
			}
			if ( strcasecmp( $header, 'Cross-sells' ) === 0 && isset( $smack['crosssell_ids'] ) ) {
				$new_values[ $idx ] = $smack['crosssell_ids'];
			}
			if ( strcasecmp( $header, 'Grouped products' ) === 0 && isset( $smack['grouping_product'] ) ) {
				$new_values[ $idx ] = $smack['grouping_product'];
			}
			if ( strcasecmp( $header, 'Date sale price starts' ) === 0 && isset( $smack['sale_price_dates_from'] ) ) {
				$new_values[ $idx ] = $smack['sale_price_dates_from'];
			}
			if ( strcasecmp( $header, 'Date sale price ends' ) === 0 && isset( $smack['sale_price_dates_to'] ) ) {
				$new_values[ $idx ] = $smack['sale_price_dates_to'];
			}
			if ( strcasecmp( $header, 'Low stock amount' ) === 0 && isset( $smack['low_stock_threshold'] ) ) {
				$new_values[ $idx ] = $smack['low_stock_threshold'];
			}
			if ( strcasecmp( $header, 'Position' ) === 0 && isset( $smack['menu_order'] ) ) {
				$new_values[ $idx ] = $smack['menu_order'];
			}
			if ( strcasecmp( $header, 'Sold individually?' ) === 0 && isset( $smack['sold_individually'] ) ) {
				$new_values[ $idx ] = $smack['sold_individually'];
			}
			// Attribute value lists.
			$attr = AttributeColumnParser::parse_header( $header );
			if ( $attr && isset( $smack[ $attr['smack_key'] ] ) ) {
				$new_values[ $idx ] = $smack[ $attr['smack_key'] ];
			}
		}

		return $new_values;
	}

	/**
	 * Merge derived fields (downloadable, virtual, gallery, attrs, downloads) into core post values.
	 *
	 * @param array  $article_data Article data.
	 * @param string $import_id    Hash.
	 * @param mixed  $post_to_update Existing post.
	 * @param array  $current_record Current record.
	 * @return array
	 */
	public static function filter_article_data( $article_data, $import_id, $post_to_update, $current_record ) {
		if ( ! FormatDetector::is_native_import( $import_id ) || ! is_array( $article_data ) ) {
			return $article_data;
		}
		// PRODUCTSKU from SKU already via mapping; ensure parent SKU fields.
		return $article_data;
	}

	/**
	 * Merge converted extras into a mapped data array (ECOMMETA/ATTRMETA/CORE).
	 *
	 * @param array  $mapped     Mapped field => value.
	 * @param string $hash_key   Import hash.
	 * @param int    $line_number Line.
	 * @return array
	 */
	public static function merge_mapped_extras( array $mapped, $hash_key, $line_number ) {
		if ( ! FormatDetector::is_native_import( $hash_key ) ) {
			return $mapped;
		}
		$cache_key = $hash_key . '|' . $line_number;
		if ( empty( self::$converted_cache[ $cache_key ] ) ) {
			return $mapped;
		}
		$smack = self::$converted_cache[ $cache_key ];

		$force_keys = array(
			'ID',
			'PRODUCTSKU',
			'post_title',
			'post_content',
			'post_excerpt',
			'post_status',
			'featured_image',
			'product_image_gallery',
			'product_type',
			'downloadable',
			'virtual',
			'regular_price',
			'sale_price',
			'sale_price_dates_from',
			'sale_price_dates_to',
			'tax_status',
			'tax_class',
			'stock',
			'stock_status',
			'manage_stock',
			'backorders',
			'low_stock_threshold',
			'sold_individually',
			'weight',
			'length',
			'width',
			'height',
			'visibility',
			'featured',
			'featured_product',
			'comment_status',
			'purchase_note',
			'menu_order',
			'product_category',
			'product_tag',
			'product_shipping_class',
			'product_brand',
			'upsell_ids',
			'crosssell_ids',
			'grouping_product',
			'parent',
			'default_attributes',
			'downloadable_files',
			'download_limit',
			'download_expiry',
			'product_url',
			'button_text',
		);

		foreach ( $force_keys as $key ) {
			if ( isset( $smack[ $key ] ) && $smack[ $key ] !== '' ) {
				$mapped[ $key ] = $smack[ $key ];
			}
		}

		// Attribute + custom meta columns.
		foreach ( $smack as $key => $value ) {
			if ( $value === '' || $value === null ) {
				continue;
			}
			if ( strpos( $key, 'product_attribute_' ) === 0 || strpos( $key, 'meta:' ) === 0 ) {
				$mapped[ $key ] = $value;
			}
		}

		return $mapped;
	}

	/**
	 * Mark products imported from WC-native CSV for easy admin identification.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $hash_key   Import session hash.
	 */
	public static function stamp_imported_product( $product_id, $hash_key = '' ) {
		if ( ! $product_id ) {
			return;
		}
		$is_native = FormatDetector::is_native_import( $hash_key );
		if ( ! $is_native ) {
			return;
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		update_post_meta( $product_id, '_smack_uci_wc_native_import', current_time( 'mysql' ) );
		if ( $product->get_sku() ) {
			update_post_meta( $product_id, '_smack_uci_wc_native_import_sku', $product->get_sku() );
		}
	}

	/**
	 * Enrich mapping AJAX response when WC headers detected.
	 *
	 * @param array  $response    AJAX response.
	 * @param array  $csv_fields  Headers.
	 * @param string $hash_key    Hash.
	 * @param string $import_type Import type.
	 * @return array
	 */
	public static function enrich_mapping_response( array $response, array $csv_fields, $hash_key = '', $import_type = '' ) {
		$user_format = $hash_key ? get_transient( 'sm_uci_wc_import_format_user_' . $hash_key ) : '';
		if ( $user_format && in_array( $user_format, array( HeaderMap::FORMAT_NATIVE, HeaderMap::FORMAT_LEGACY ), true ) ) {
			$format = $user_format;
		} else {
			$format = FormatDetector::detect( $csv_fields );
		}
		if ( $hash_key ) {
			FormatDetector::store_for_import( $hash_key, $format );
		}

		$response['wc_csv_format'] = $format;

		if ( $format !== HeaderMap::FORMAT_NATIVE ) {
			return $response;
		}

		$auto_map = NativeToSmackAdapter::build_auto_mapping( $csv_fields );
		$response['wc_native_auto_map'] = $auto_map;
		$response['wc_native_detected'] = true;

		if ( FormatDetector::is_woo_product_module( $import_type ) ) {
			$response['wc_native_importer']     = true;
			$response['wc_native_skip_mapping'] = true;
		}

		return $response;
	}

	/**
	 * @param array $headers Headers.
	 * @param array $values  Values.
	 * @return array
	 */
	private static function combine( array $headers, array $values ) {
		$assoc  = array();
		$values = array_values( $values );
		foreach ( array_values( $headers ) as $i => $header ) {
			$assoc[ HeaderMap::normalize_header( (string) $header ) ] = isset( $values[ $i ] ) ? $values[ $i ] : '';
		}
		return $assoc;
	}
}
