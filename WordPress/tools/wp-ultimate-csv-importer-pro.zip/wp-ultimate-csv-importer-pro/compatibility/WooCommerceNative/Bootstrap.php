<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstrap WooCommerce-native CSV compatibility layer.
 */
class Bootstrap {

	/**
	 * Load classes and register bridges.
	 */
	public static function init() {
		$dir = __DIR__;

		require_once $dir . '/HeaderMap.php';
		require_once $dir . '/FormatDetector.php';
		require_once $dir . '/ProductResolver.php';
		require_once $dir . '/ValueConverter.php';
		require_once $dir . '/ImageFormatter.php';
		require_once $dir . '/AttributeColumnParser.php';
		require_once $dir . '/DownloadColumnParser.php';
		require_once $dir . '/NativeToSmackAdapter.php';
		require_once $dir . '/SmackToNativeAdapter.php';
		require_once $dir . '/ImportBridge.php';
		require_once $dir . '/PostImportHandler.php';
		require_once $dir . '/ExportBridge.php';
		require_once $dir . '/WcNativeImportRunner.php';
		require_once $dir . '/WcCsvMappingHelper.php';
		require_once $dir . '/WcCsvImportPreparer.php';

		ImportBridge::init();
		ExportBridge::init();
	}
}
