<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bidirectional map between WooCommerce-native CSV headers and Smackcoders field keys.
 */
class HeaderMap {

	const FORMAT_NATIVE = 'woocommerce_native';
	const FORMAT_LEGACY = 'legacy';

	/**
	 * Exact English WC header → Smack field key.
	 *
	 * @return array<string, string>
	 */
	public static function get_wc_to_smack_map() {
		$map = array(
			'ID'                         => 'ID',
			'Type'                       => 'product_type',
			'SKU'                        => 'PRODUCTSKU',
			'GTIN, UPC, EAN, or ISBN'    => '_global_unique_id',
			'Name'                       => 'post_title',
			'Published'                  => 'post_status',
			'Is featured?'               => 'featured',
			'Visibility in catalog'      => 'visibility',
			'Short description'          => 'post_excerpt',
			'Description'                => 'post_content',
			'Date sale price starts'     => 'sale_price_dates_from',
			'Date sale price ends'       => 'sale_price_dates_to',
			'Tax status'                 => 'tax_status',
			'Tax class'                  => 'tax_class',
			'In stock?'                  => 'stock_status',
			'Stock'                      => 'stock',
			'Low stock amount'           => 'low_stock_threshold',
			'Backorders allowed?'        => 'backorders',
			'Sold individually?'         => 'sold_individually',
			'Allow customer reviews?'    => 'comment_status',
			'Purchase note'              => 'purchase_note',
			'Sale price'                 => 'sale_price',
			'Regular price'              => 'regular_price',
			'Categories'                 => 'product_category',
			'Tags'                       => 'product_tag',
			'Shipping class'             => 'product_shipping_class',
			'Images'                     => 'featured_image',
			'Download limit'             => 'download_limit',
			'Download expiry days'       => 'download_expiry',
			'Parent'                     => 'parent',
			'Grouped products'           => 'grouping_product',
			'Upsells'                    => 'upsell_ids',
			'Cross-sells'                => 'crosssell_ids',
			'External URL'               => 'product_url',
			'Button text'                => 'button_text',
			'Position'                   => 'menu_order',
			'Cost of goods'              => 'cogs_value',
			'Brands'                     => 'product_brand',
		);

		/**
		 * Filter WooCommerce-native header → Smack field map.
		 *
		 * @param array<string, string> $map Header map.
		 */
		return apply_filters( 'sm_uci_pro_wc_native_header_map', $map );
	}

	/**
	 * Smack field key → WC English header (for export).
	 *
	 * @return array<string, string>
	 */
	public static function get_smack_to_wc_map() {
		$flipped = array_flip( self::get_wc_to_smack_map() );
		// Prefer featured over featured_product for Is featured?
		$flipped['featured_product'] = 'Is featured?';
		$flipped['position']         = 'Position';
		$flipped['product_image_gallery'] = 'Images';
		return $flipped;
	}

	/**
	 * Default WC column order (column_id => English header), matching WC_Product_CSV_Exporter.
	 *
	 * @return array<string, string>
	 */
	public static function get_default_wc_column_order() {
		$weight_unit = function_exists( 'get_option' ) ? get_option( 'woocommerce_weight_unit', 'kg' ) : 'kg';
		$dim_unit    = function_exists( 'get_option' ) ? get_option( 'woocommerce_dimension_unit', 'cm' ) : 'cm';

		return array(
			'id'                 => 'ID',
			'type'               => 'Type',
			'sku'                => 'SKU',
			'global_unique_id'   => 'GTIN, UPC, EAN, or ISBN',
			'name'               => 'Name',
			'published'          => 'Published',
			'featured'           => 'Is featured?',
			'catalog_visibility' => 'Visibility in catalog',
			'short_description'  => 'Short description',
			'description'        => 'Description',
			'date_on_sale_from'  => 'Date sale price starts',
			'date_on_sale_to'    => 'Date sale price ends',
			'tax_status'         => 'Tax status',
			'tax_class'          => 'Tax class',
			'stock_status'       => 'In stock?',
			'stock'              => 'Stock',
			'low_stock_amount'   => 'Low stock amount',
			'backorders'         => 'Backorders allowed?',
			'sold_individually'  => 'Sold individually?',
			'weight'             => sprintf( 'Weight (%s)', $weight_unit ),
			'length'             => sprintf( 'Length (%s)', $dim_unit ),
			'width'              => sprintf( 'Width (%s)', $dim_unit ),
			'height'             => sprintf( 'Height (%s)', $dim_unit ),
			'reviews_allowed'    => 'Allow customer reviews?',
			'purchase_note'      => 'Purchase note',
			'sale_price'         => 'Sale price',
			'regular_price'      => 'Regular price',
			'category_ids'       => 'Categories',
			'tag_ids'            => 'Tags',
			'shipping_class_id'  => 'Shipping class',
			'images'             => 'Images',
			'download_limit'     => 'Download limit',
			'download_expiry'    => 'Download expiry days',
			'parent_id'          => 'Parent',
			'grouped_products'   => 'Grouped products',
			'upsell_ids'         => 'Upsells',
			'cross_sell_ids'     => 'Cross-sells',
			'product_url'        => 'External URL',
			'button_text'        => 'Button text',
			'menu_order'         => 'Position',
		);
	}

	/**
	 * Resolve a raw CSV header to a Smack field key.
	 *
	 * @param string $header Raw header.
	 * @return string|null
	 */
	public static function resolve_header( $header ) {
		$header = self::normalize_header( $header );
		if ( $header === '' ) {
			return null;
		}

		$map = self::get_wc_to_smack_map();
		if ( isset( $map[ $header ] ) ) {
			return $map[ $header ];
		}

		// Case-insensitive exact match.
		foreach ( $map as $wc_header => $smack_key ) {
			if ( strcasecmp( $wc_header, $header ) === 0 ) {
				return $smack_key;
			}
		}

		// Unit-suffixed dimension/weight headers: "Weight (kg)", "Length (cm)", etc.
		if ( preg_match( '/^Weight\s*\(/i', $header ) ) {
			return 'weight';
		}
		if ( preg_match( '/^Length\s*\(/i', $header ) ) {
			return 'length';
		}
		if ( preg_match( '/^Width\s*\(/i', $header ) ) {
			return 'width';
		}
		if ( preg_match( '/^Height\s*\(/i', $header ) ) {
			return 'height';
		}

		// Attribute N …
		$attr = AttributeColumnParser::parse_header( $header );
		if ( $attr ) {
			return $attr['smack_key'];
		}

		// Download N …
		$dl = DownloadColumnParser::parse_header( $header );
		if ( $dl ) {
			return $dl['smack_key'];
		}

		// Meta: key
		if ( preg_match( '/^Meta:\s*(.+)$/i', $header, $m ) ) {
			return 'meta:' . trim( $m[1] );
		}

		return null;
	}

	/**
	 * @param string $header Header label.
	 * @return string
	 */
	public static function normalize_header( $header ) {
		$header = (string) $header;
		// Strip UTF-8 BOM.
		if ( strncmp( $header, "\xEF\xBB\xBF", 3 ) === 0 ) {
			$header = substr( $header, 3 );
		}
		return trim( $header );
	}

	/**
	 * Mapping group for a Smack field key.
	 *
	 * @param string $smack_key Field key.
	 * @return string CORE|ECOMMETA|ATTRMETA|TERMS|CORECUSTFIELDS
	 */
	public static function get_field_group( $smack_key ) {
		$core = array( 'ID', 'post_title', 'post_content', 'post_excerpt', 'post_status', 'post_name', 'post_author', 'post_date', 'PRODUCTSKU', 'featured_image', 'menu_order', 'comment_status' );
		$terms = array( 'product_category', 'product_tag', 'product_brand' );

		if ( in_array( $smack_key, $core, true ) ) {
			return 'CORE';
		}
		if ( in_array( $smack_key, $terms, true ) ) {
			return 'TERMS';
		}
		if ( strpos( $smack_key, 'product_attribute_' ) === 0 ) {
			return 'ATTRMETA';
		}
		if ( strpos( $smack_key, 'meta:' ) === 0 ) {
			return 'CORECUSTFIELDS';
		}
		return 'ECOMMETA';
	}
}
