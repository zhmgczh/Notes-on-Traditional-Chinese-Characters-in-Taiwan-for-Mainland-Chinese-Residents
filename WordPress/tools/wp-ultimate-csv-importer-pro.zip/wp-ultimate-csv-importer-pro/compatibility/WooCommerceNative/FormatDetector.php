<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detects whether CSV headers match WooCommerce-native product export format.
 */
class FormatDetector {

	/**
	 * Signature headers that strongly indicate WC native format.
	 *
	 * @var string[]
	 */
	private static $strong_signals = array(
		'Type',
		'SKU',
		'Name',
		'Images',
		'Visibility in catalog',
		'Is featured?',
		'In stock?',
		'Attribute 1 name',
	);

	/**
	 * Legacy Smack headers that indicate non-WC format.
	 *
	 * @var string[]
	 */
	private static $legacy_signals = array(
		'PRODUCTSKU',
		'product_type',
		'product_category',
		'product_image_gallery',
		'product_attribute_name1',
		'post_title',
	);

	/**
	 * Detect format from a list of headers.
	 *
	 * @param array $headers CSV headers.
	 * @return string HeaderMap::FORMAT_NATIVE|HeaderMap::FORMAT_LEGACY
	 */
	public static function detect( array $headers ) {
		$normalized = array();
		foreach ( $headers as $h ) {
			$normalized[] = HeaderMap::normalize_header( (string) $h );
		}

		$legacy_hits = 0;
		foreach ( self::$legacy_signals as $signal ) {
			foreach ( $normalized as $h ) {
				if ( strcasecmp( $h, $signal ) === 0 ) {
					$legacy_hits++;
					break;
				}
			}
		}

		$wc_hits = 0;
		foreach ( self::$strong_signals as $signal ) {
			foreach ( $normalized as $h ) {
				if ( strcasecmp( $h, $signal ) === 0 ) {
					$wc_hits++;
					break;
				}
			}
		}

		// Attribute pattern without exact "Attribute 1 name".
		foreach ( $normalized as $h ) {
			if ( preg_match( '/^Attribute\s+\d+\s+name$/i', $h ) ) {
				$wc_hits++;
				break;
			}
		}

		$is_native = false;
		if ( $wc_hits >= 3 && $legacy_hits === 0 ) {
			$is_native = true;
		} elseif ( $wc_hits >= 4 && $wc_hits > $legacy_hits ) {
			$is_native = true;
		} elseif ( self::has_header( $normalized, 'Type' ) && self::has_header( $normalized, 'SKU' ) && self::has_header( $normalized, 'Name' ) && $legacy_hits === 0 ) {
			$is_native = true;
		}

		$format = $is_native ? HeaderMap::FORMAT_NATIVE : HeaderMap::FORMAT_LEGACY;

		/**
		 * Filter detected CSV format.
		 *
		 * @param string $format  Detected format.
		 * @param array  $headers Normalized headers.
		 */
		return apply_filters( 'sm_uci_pro_wc_native_detect', $format, $normalized );
	}

	/**
	 * @param array  $headers Headers.
	 * @param string $needle  Header to find.
	 * @return bool
	 */
	private static function has_header( array $headers, $needle ) {
		foreach ( $headers as $h ) {
			if ( strcasecmp( $h, $needle ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Persist detected format for an import session.
	 *
	 * @param string $hash_key Import hash.
	 * @param string $format   Format constant.
	 */
	public static function store_for_import( $hash_key, $format ) {
		if ( empty( $hash_key ) ) {
			return;
		}
		set_transient( 'sm_uci_wc_csv_format_' . $hash_key, $format, DAY_IN_SECONDS );
	}

	/**
	 * @param string $hash_key Import hash.
	 * @return string
	 */
	public static function get_for_import( $hash_key ) {
		if ( empty( $hash_key ) ) {
			return HeaderMap::FORMAT_LEGACY;
		}
		$format = get_transient( 'sm_uci_wc_csv_format_' . $hash_key );
		return $format ? $format : HeaderMap::FORMAT_LEGACY;
	}

	/**
	 * @param string $hash_key Import hash.
	 * @return bool
	 */
	public static function is_native_import( $hash_key ) {
		return self::get_for_import( $hash_key ) === HeaderMap::FORMAT_NATIVE;
	}

	/**
	 * Persist explicit user format choice (import UI), overriding auto-detection.
	 *
	 * @param string $hash_key Import hash.
	 * @param string $format   woocommerce_native|legacy.
	 */
	public static function store_user_format( $hash_key, $format ) {
		if ( empty( $hash_key ) ) {
			return;
		}
		$format = in_array( $format, array( HeaderMap::FORMAT_NATIVE, HeaderMap::FORMAT_LEGACY ), true )
			? $format
			: HeaderMap::FORMAT_LEGACY;
		self::store_for_import( $hash_key, $format );
		set_transient( 'sm_uci_wc_import_format_user_' . $hash_key, $format, DAY_IN_SECONDS );
	}

	/**
	 * Persist selected import module for sessions that skip manual mapping.
	 *
	 * @param string $hash_key Import hash.
	 * @param string $module   Import module label.
	 */
	public static function store_import_module( $hash_key, $module ) {
		if ( empty( $hash_key ) || empty( $module ) ) {
			return;
		}
		update_option( 'sm_uci_import_module_' . sanitize_key( $hash_key ), sanitize_text_field( $module ), false );
	}

	/**
	 * @param string $hash_key Import hash.
	 * @return string
	 */
	public static function get_import_module( $hash_key ) {
		if ( empty( $hash_key ) ) {
			return '';
		}
		return (string) get_option( 'sm_uci_import_module_' . sanitize_key( $hash_key ), '' );
	}

	/**
	 * @param string $import_type UI or canonical import type.
	 * @return bool
	 */
	public static function is_woo_product_module( $import_type ) {
		$type = strtolower( trim( (string) $import_type ) );
		if ( $type === '' ) {
			return false;
		}

		$exact = array(
			'woocommerce',
			'woocommerce product',
			'woocommerce product variations',
			'woocommercevariations',
			'wpecommerce products',
		);
		if ( in_array( $type, $exact, true ) ) {
			return true;
		}

		// Labels that clearly mean products, excluding other WC modules.
		if ( false !== strpos( $type, 'woocommerce' ) && false !== strpos( $type, 'product' ) ) {
			$excluded = array( 'order', 'coupon', 'customer', 'refund', 'categor', 'tag', 'attribute', 'review' );
			foreach ( $excluded as $needle ) {
				if ( false !== strpos( $type, $needle ) ) {
					return false;
				}
			}
			return true;
		}

		return false;
	}

	/**
	 * Whether this import session should use WooCommerce's CSV importer (user chose WC format).
	 *
	 * @param string $hash_key    Import hash.
	 * @param string $import_type Import module.
	 * @return bool
	 */
	public static function uses_wc_importer( $hash_key, $import_type = '' ) {
		return self::is_woo_product_module( $import_type ) && self::is_native_import( $hash_key );
	}
}
