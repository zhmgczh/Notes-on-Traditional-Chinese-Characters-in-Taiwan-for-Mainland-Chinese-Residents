<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve WooCommerce product references (ID, SKU, title, id:N) during import.
 */
class ProductResolver {

	/**
	 * @param string $identifier Raw reference from CSV.
	 * @return int Product ID or 0.
	 */
	public static function resolve_product_id( $identifier ) {
		$identifier = trim( (string) $identifier );
		if ( $identifier === '' ) {
			return 0;
		}

		if ( preg_match( '/^id:(\d+)$/i', $identifier, $m ) ) {
			$identifier = $m[1];
		}

		if ( is_numeric( $identifier ) ) {
			$product = wc_get_product( (int) $identifier );
			return ( $product && $product->get_id() ) ? (int) $product->get_id() : 0;
		}

		if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
			$by_sku = (int) wc_get_product_id_by_sku( $identifier );
			if ( $by_sku > 0 ) {
				return $by_sku;
			}
		}

		global $wpdb;
		$by_title = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type IN ('product','product_variation') AND post_title = %s AND post_status != 'trash' ORDER BY ID DESC LIMIT 1",
				$identifier
			)
		);
		return $by_title > 0 ? $by_title : 0;
	}

	/**
	 * Resolve a list cell (comma or pipe separated) to product IDs.
	 *
	 * @param string $value Linked products cell.
	 * @return int[]
	 */
	public static function resolve_product_id_list( $value ) {
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return array();
		}

		$value   = str_replace( '|', ',', $value );
		$parts   = preg_split( '/\s*,\s*/', $value );
		$ids     = array();

		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( $part === '' ) {
				continue;
			}
			$id = self::resolve_product_id( $part );
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}
}
