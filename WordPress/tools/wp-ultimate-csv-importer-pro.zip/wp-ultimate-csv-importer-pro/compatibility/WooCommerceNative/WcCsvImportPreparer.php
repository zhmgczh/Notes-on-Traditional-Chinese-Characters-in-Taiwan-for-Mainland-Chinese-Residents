<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sorts WooCommerce export CSV rows (parents before variations) and fills Parent when inferrable.
 */
class WcCsvImportPreparer {

	const TYPE_ORDER = array(
		'simple'           => 10,
		'variable'         => 20,
		'grouped'          => 30,
		'external'         => 40,
		'variation'        => 50,
		'subscription'     => 60,
		'variable-subscription' => 70,
	);

	/**
	 * Build import-ready CSV path (sorted + parent hints). Returns same path when already prepared.
	 *
	 * @param string $source_path   Original CSV path.
	 * @param string $delimiter     CSV delimiter.
	 * @return string|false Prepared file path or false on failure.
	 */
	public static function prepare( $source_path, $delimiter = ',' ) {
		if ( ! is_readable( $source_path ) ) {
			return false;
		}

		$prepared_path = $source_path . '.wc-prepared.csv';
		if ( file_exists( $prepared_path ) && filemtime( $prepared_path ) >= filemtime( $source_path ) ) {
			return $prepared_path;
		}

		$handle = fopen( $source_path, 'r' );
		if ( false === $handle ) {
			return false;
		}

		$headers = fgetcsv( $handle, 0, $delimiter, '"', '\\' );
		if ( ! is_array( $headers ) || empty( $headers ) ) {
			fclose( $handle );
			return false;
		}

		if ( isset( $headers[0] ) ) {
			$headers[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $headers[0] );
		}

		$header_map = array();
		foreach ( $headers as $idx => $header ) {
			$header_map[ strtolower( trim( (string) $header ) ) ] = $idx;
		}

		$type_idx   = isset( $header_map['type'] ) ? $header_map['type'] : null;
		$sku_idx    = isset( $header_map['sku'] ) ? $header_map['sku'] : null;
		$parent_idx = isset( $header_map['parent'] ) ? $header_map['parent'] : null;

		if ( null === $type_idx ) {
			fclose( $handle );
			return false;
		}

		$rows = array();
		while ( ( $row = fgetcsv( $handle, 0, $delimiter, '"', '\\' ) ) !== false ) {
			if ( ! is_array( $row ) || self::is_empty_row( $row ) ) {
				continue;
			}
			$rows[] = $row;
		}
		fclose( $handle );

		$sku_set = array();
		foreach ( $rows as $row ) {
			$type = strtolower( trim( (string) ( $row[ $type_idx ] ?? '' ) ) );
			if ( $sku_idx !== null && $type !== 'variation' ) {
				$sku = trim( (string) ( $row[ $sku_idx ] ?? '' ) );
				if ( $sku !== '' ) {
					$sku_set[ strtolower( $sku ) ] = true;
				}
			}
		}

		if ( $parent_idx !== null && $sku_idx !== null ) {
			foreach ( $rows as &$row ) {
				$type = strtolower( trim( (string) ( $row[ $type_idx ] ?? '' ) ) );
				if ( $type !== 'variation' ) {
					continue;
				}
				$parent = trim( (string) ( $row[ $parent_idx ] ?? '' ) );
				if ( $parent !== '' ) {
					continue;
				}
				$sku = trim( (string) ( $row[ $sku_idx ] ?? '' ) );
				$guess = self::infer_parent_ref( $sku );
				if ( $guess !== '' && isset( $sku_set[ strtolower( $guess ) ] ) ) {
					$row[ $parent_idx ] = $guess;
				}
			}
			unset( $row );
		}

		usort(
			$rows,
			function ( $a, $b ) use ( $type_idx ) {
				$ta = strtolower( trim( (string) ( $a[ $type_idx ] ?? '' ) ) );
				$tb = strtolower( trim( (string) ( $b[ $type_idx ] ?? '' ) ) );
				$oa = self::TYPE_ORDER[ $ta ] ?? 100;
				$ob = self::TYPE_ORDER[ $tb ] ?? 100;
				if ( $oa === $ob ) {
					return 0;
				}
				return ( $oa < $ob ) ? -1 : 1;
			}
		);

		$out = fopen( $prepared_path, 'w' );
		if ( false === $out ) {
			return false;
		}

		fputcsv( $out, $headers, $delimiter, '"', '\\' );
		foreach ( $rows as $row ) {
			fputcsv( $out, $row, $delimiter, '"', '\\' );
		}
		fclose( $out );

		return $prepared_path;
	}

	/**
	 * @param array $row CSV row.
	 * @return bool
	 */
	private static function is_empty_row( array $row ) {
		foreach ( $row as $cell ) {
			if ( trim( (string) $cell ) !== '' ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Infer parent SKU from variation SKU (SSk90-2 → SSk90, SSk90-2-IMP → SSk90-IMP).
	 *
	 * @param string $sku Variation SKU.
	 * @return string
	 */
	public static function infer_parent_ref( $sku ) {
		$sku = trim( (string) $sku );
		if ( $sku === '' ) {
			return '';
		}
		if ( preg_match( '/^(.+)-(\d+)((?:-IMP\d*)?)$/i', $sku, $matches ) ) {
			return $matches[1] . $matches[3];
		}
		return '';
	}
}
