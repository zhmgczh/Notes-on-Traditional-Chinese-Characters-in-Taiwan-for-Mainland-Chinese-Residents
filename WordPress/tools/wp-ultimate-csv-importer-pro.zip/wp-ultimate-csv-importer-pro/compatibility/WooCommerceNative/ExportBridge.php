<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies WooCommerce-native formatting on product exports when csv_format is set.
 */
class ExportBridge {

	/**
	 * Accumulated native rows for header union (per request).
	 *
	 * @var array[]
	 */
	private static $pending_native_rows = array();

	/**
	 * Whether current export uses native format.
	 *
	 * @var bool|null
	 */
	private static $is_native = null;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'sm_uci_pro_export_csv_headers', array( __CLASS__, 'filter_headers' ), 20 );
	}

	/**
	 * Replace headers with WC-native when active.
	 *
	 * @param array $headers Headers.
	 * @return array
	 */
	public static function filter_headers( $headers ) {
		if ( empty( $GLOBALS['smack_uci_csv_format'] ) || $GLOBALS['smack_uci_csv_format'] !== HeaderMap::FORMAT_NATIVE ) {
			return $headers;
		}
		return self::get_native_headers();
	}

	/**
	 * Resolve export CSV format.
	 *
	 * Rules:
	 * - Explicit POST/conditions csv_format wins.
	 * - Missing format (including WooCommerce Product) ⇒ legacy (user must opt into native).
	 * - Schedules without format ⇒ legacy (backward compatible).
	 *
	 * @param array  $conditions Export conditions.
	 * @param string $module     Module name.
	 * @param bool   $is_schedule Whether this is a scheduled export.
	 * @return string
	 */
	public static function resolve_format( $conditions = array(), $module = '', $is_schedule = false ) {
		$format = '';

		if ( ! empty( $_POST['csv_format'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$format = sanitize_key( wp_unslash( $_POST['csv_format'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		} elseif ( ! empty( $conditions['csv_format'] ) ) {
			if ( is_array( $conditions['csv_format'] ) && ! empty( $conditions['csv_format']['format'] ) ) {
				$format = sanitize_key( $conditions['csv_format']['format'] );
			} else {
				$format = sanitize_key( $conditions['csv_format'] );
			}
		} elseif ( ! empty( $conditions['specific_period']['csv_format'] ) ) {
			$format = sanitize_key( $conditions['specific_period']['csv_format'] );
		}

		if ( $format === HeaderMap::FORMAT_NATIVE || $format === HeaderMap::FORMAT_LEGACY ) {
			return $format;
		}

		return HeaderMap::FORMAT_LEGACY;
	}

	/**
	 * @param array  $conditions Conditions.
	 * @param string $module     Module.
	 * @param bool   $is_schedule Schedule flag.
	 * @return bool
	 */
	public static function is_native_export( $conditions = array(), $module = '', $is_schedule = false ) {
		if ( self::$is_native !== null ) {
			return self::$is_native;
		}
		self::$is_native = ( self::resolve_format( $conditions, $module, $is_schedule ) === HeaderMap::FORMAT_NATIVE );
		return self::$is_native;
	}

	/**
	 * Reset per-request state (call at export start).
	 *
	 * @param array  $conditions Conditions.
	 * @param string $module     Module.
	 * @param bool   $is_schedule Schedule.
	 */
	public static function begin_export( $conditions = array(), $module = '', $is_schedule = false ) {
		self::$pending_native_rows = array();
		self::$is_native           = ( self::resolve_format( $conditions, $module, $is_schedule ) === HeaderMap::FORMAT_NATIVE );
		$GLOBALS['smack_uci_csv_format'] = self::$is_native ? HeaderMap::FORMAT_NATIVE : HeaderMap::FORMAT_LEGACY;
		unset( $GLOBALS['smack_uci_wc_native_headers'] );

		if ( self::$is_native ) {
			// Seed attribute columns so headers are stable across AJAX batches.
			$max_attrs = 3;
			if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
				$taxonomies = wc_get_attribute_taxonomies();
				if ( is_array( $taxonomies ) ) {
					$max_attrs = max( $max_attrs, count( $taxonomies ) );
				}
			}
			$seed = array();
			for ( $n = 1; $n <= $max_attrs; $n++ ) {
				$seed[ AttributeColumnParser::build_wc_header( $n, 'name' ) ]     = '';
				$seed[ AttributeColumnParser::build_wc_header( $n, 'value' ) ]    = '';
				$seed[ AttributeColumnParser::build_wc_header( $n, 'visible' ) ]  = '';
				$seed[ AttributeColumnParser::build_wc_header( $n, 'taxonomy' ) ] = '';
				$seed[ AttributeColumnParser::build_wc_header( $n, 'default' ) ]  = '';
			}
			self::$pending_native_rows[] = array_merge( array_fill_keys( array_values( HeaderMap::get_default_wc_column_order() ), '' ), $seed );
		}
	}

	/**
	 * Convert batch of Smack export data (id => row) to WC-native rows.
	 *
	 * @param array $data Export data keyed by product ID.
	 * @return array Same structure with WC columns.
	 */
	public static function transform_export_data( array $data ) {
		if ( empty( $GLOBALS['smack_uci_csv_format'] ) || $GLOBALS['smack_uci_csv_format'] !== HeaderMap::FORMAT_NATIVE ) {
			return $data;
		}

		$headers = self::get_native_headers();
		$converted = array();
		foreach ( $data as $id => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			if ( empty( $row['ID'] ) ) {
				$row['ID'] = $id;
			}
			$native = SmackToNativeAdapter::convert_row( $row );
			// Pad to stable header set.
			$ordered = array();
			foreach ( $headers as $header ) {
				$ordered[ $header ] = isset( $native[ $header ] ) ? $native[ $header ] : '';
			}
			// Append any unexpected dynamic keys (downloads beyond seed) on first batch.
			foreach ( $native as $header => $value ) {
				if ( ! array_key_exists( $header, $ordered ) ) {
					$ordered[ $header ] = $value;
					if ( ! in_array( $header, $headers, true ) ) {
						$headers[] = $header;
					}
				}
			}
			$converted[ $id ] = $ordered;
			self::$pending_native_rows[] = $ordered;
		}

		// Persist expanded headers for subsequent batches in this request.
		$GLOBALS['smack_uci_wc_native_headers'] = $headers;

		return $converted;
	}

	/**
	 * Headers for current native export (union of default + dynamic columns seen).
	 *
	 * @return string[]
	 */
	public static function get_native_headers() {
		if ( ! empty( $GLOBALS['smack_uci_wc_native_headers'] ) && is_array( $GLOBALS['smack_uci_wc_native_headers'] ) ) {
			return $GLOBALS['smack_uci_wc_native_headers'];
		}
		if ( ! empty( self::$pending_native_rows ) ) {
			$headers = SmackToNativeAdapter::build_headers_from_rows( self::$pending_native_rows );
			$GLOBALS['smack_uci_wc_native_headers'] = $headers;
			return $headers;
		}
		return array_values( HeaderMap::get_default_wc_column_order() );
	}
}
