<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bidirectional value transforms between WooCommerce-native and Smack encodings.
 */
class ValueConverter {

	/**
	 * Parse WC Type cell into product_type + flags.
	 *
	 * @param string $type_cell e.g. "simple, downloadable, virtual".
	 * @return array{product_type:string|int,downloadable:string,virtual:string}
	 */
	public static function parse_wc_type( $type_cell ) {
		$parts = self::explode_list( (string) $type_cell );
		$downloadable = 'no';
		$virtual      = 'no';
		$base         = 'simple';

		foreach ( $parts as $part ) {
			$part = strtolower( trim( $part ) );
			if ( $part === 'downloadable' ) {
				$downloadable = 'yes';
				continue;
			}
			if ( $part === 'virtual' ) {
				$virtual = 'yes';
				continue;
			}
			if ( in_array( $part, array( 'simple', 'grouped', 'external', 'variable', 'variation', 'subscription', 'variable-subscription', 'bundle' ), true ) ) {
				$base = $part;
			}
		}

		$map = array(
			'simple'                => 1,
			'grouped'               => 2,
			'external'              => 3,
			'variable'              => 4,
			'subscription'          => 5,
			'variable-subscription' => 6,
			'bundle'                => 7,
			'variation'             => 8,
		);

		return array(
			'product_type' => isset( $map[ $base ] ) ? $map[ $base ] : 1,
			'downloadable' => $downloadable,
			'virtual'      => $virtual,
			'type_string'  => $base,
		);
	}

	/**
	 * Build WC Type cell from Smack fields.
	 *
	 * @param mixed  $product_type Smack product_type (int or string).
	 * @param string $downloadable yes/no/1/0.
	 * @param string $virtual      yes/no/1/0.
	 * @return string
	 */
	public static function build_wc_type( $product_type, $downloadable = '', $virtual = '' ) {
		$type_map = array(
			1 => 'simple',
			2 => 'grouped',
			3 => 'external',
			4 => 'variable',
			5 => 'subscription',
			6 => 'variable-subscription',
			7 => 'bundle',
			8 => 'variation',
		);

		if ( is_numeric( $product_type ) && isset( $type_map[ (int) $product_type ] ) ) {
			$base = $type_map[ (int) $product_type ];
		} elseif ( is_string( $product_type ) && $product_type !== '' ) {
			$base = strtolower( $product_type );
		} else {
			$base = 'simple';
		}

		$types = array( $base );
		if ( self::is_truthy( $downloadable ) ) {
			$types[] = 'downloadable';
		}
		if ( self::is_truthy( $virtual ) ) {
			$types[] = 'virtual';
		}
		return implode( ', ', $types );
	}

	/**
	 * WC Published → Smack post_status.
	 *
	 * @param mixed $published WC published value.
	 * @return string
	 */
	public static function published_to_status( $published ) {
		if ( $published === '' || $published === null ) {
			return 'publish';
		}
		if ( is_string( $published ) && ! is_numeric( $published ) ) {
			$lower = strtolower( $published );
			if ( in_array( $lower, array( 'true', 'yes' ), true ) ) {
				return 'publish';
			}
			if ( in_array( $lower, array( 'false', 'no' ), true ) ) {
				return 'private';
			}
			if ( in_array( $lower, array( 'publish', 'private', 'draft', 'pending', 'future' ), true ) ) {
				return $lower;
			}
		}
		$val = (float) $published;
		if ( $val === (float) -1 ) {
			return 'draft';
		}
		if ( $val === (float) 0 ) {
			return 'private';
		}
		return 'publish';
	}

	/**
	 * Smack post_status → WC Published.
	 *
	 * @param string $status Post status.
	 * @return string
	 */
	public static function status_to_published( $status ) {
		$status = strtolower( (string) $status );
		if ( $status === 'draft' || $status === 'pending' || $status === 'future' ) {
			return '-1';
		}
		if ( $status === 'private' ) {
			return '0';
		}
		return '1';
	}

	/**
	 * WC catalog visibility → Smack numeric.
	 *
	 * @param string $visibility WC visibility.
	 * @return string
	 */
	public static function visibility_wc_to_smack( $visibility ) {
		$map = array(
			'visible' => '1',
			'catalog' => '2',
			'search'  => '3',
			'hidden'  => '4',
		);
		$visibility = strtolower( trim( (string) $visibility ) );
		return isset( $map[ $visibility ] ) ? $map[ $visibility ] : $visibility;
	}

	/**
	 * Smack visibility → WC.
	 *
	 * @param mixed $visibility Smack value.
	 * @return string
	 */
	public static function visibility_smack_to_wc( $visibility ) {
		$map = array(
			'1' => 'visible',
			'2' => 'catalog',
			'3' => 'search',
			'4' => 'hidden',
		);
		$key = (string) $visibility;
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		$lower = strtolower( $key );
		if ( in_array( $lower, array( 'visible', 'catalog', 'search', 'hidden' ), true ) ) {
			return $lower;
		}
		return 'visible';
	}

	/**
	 * WC In stock? → Smack stock_status.
	 *
	 * @param mixed $stock_status WC value.
	 * @return string
	 */
	public static function stock_status_wc_to_smack( $stock_status ) {
		$val = strtolower( trim( (string) $stock_status ) );
		if ( $val === '1' || $val === 'yes' || $val === 'true' || $val === 'instock' ) {
			return 'instock';
		}
		if ( $val === 'backorder' || $val === 'onbackorder' ) {
			return 'onbackorder';
		}
		if ( $val === '0' || $val === 'no' || $val === 'false' || $val === 'outofstock' ) {
			return 'outofstock';
		}
		return $val;
	}

	/**
	 * Smack stock_status → WC In stock?.
	 *
	 * @param mixed $stock_status Smack value.
	 * @return string
	 */
	public static function stock_status_smack_to_wc( $stock_status ) {
		$val = strtolower( trim( (string) $stock_status ) );
		if ( $val === 'instock' || $val === '1' || $val === 'yes' ) {
			return '1';
		}
		if ( $val === 'onbackorder' || $val === 'backorder' ) {
			return 'backorder';
		}
		return '0';
	}

	/**
	 * WC Backorders → Smack numeric (1=no, 2=notify, 3=yes).
	 *
	 * @param mixed $backorders WC value.
	 * @return string
	 */
	public static function backorders_wc_to_smack( $backorders ) {
		$val = strtolower( trim( (string) $backorders ) );
		if ( $val === '1' || $val === 'yes' || $val === 'true' ) {
			return '3';
		}
		if ( $val === 'notify' ) {
			return '2';
		}
		if ( $val === '0' || $val === 'no' || $val === 'false' ) {
			return '1';
		}
		return $val;
	}

	/**
	 * Smack backorders → WC.
	 *
	 * @param mixed $backorders Smack value.
	 * @return string
	 */
	public static function backorders_smack_to_wc( $backorders ) {
		$val = strtolower( trim( (string) $backorders ) );
		if ( $val === '3' || $val === 'yes' ) {
			return '1';
		}
		if ( $val === '2' || $val === 'notify' ) {
			return 'notify';
		}
		return '0';
	}

	/**
	 * WC tax_status → Smack numeric.
	 *
	 * @param mixed $tax_status WC value.
	 * @return string
	 */
	public static function tax_status_wc_to_smack( $tax_status ) {
		$map = array(
			'taxable'  => '1',
			'shipping' => '2',
			'none'     => '3',
		);
		$val = strtolower( trim( (string) $tax_status ) );
		return isset( $map[ $val ] ) ? $map[ $val ] : $val;
	}

	/**
	 * Smack tax_status → WC.
	 *
	 * @param mixed $tax_status Smack value.
	 * @return string
	 */
	public static function tax_status_smack_to_wc( $tax_status ) {
		$map = array(
			'1' => 'taxable',
			'2' => 'shipping',
			'3' => 'none',
		);
		$key = (string) $tax_status;
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		$lower = strtolower( $key );
		if ( in_array( $lower, array( 'taxable', 'shipping', 'none' ), true ) ) {
			return $lower;
		}
		return 'taxable';
	}

	/**
	 * WC bool (1/0) → Smack yes/no or 1/''.
	 *
	 * @param mixed $value WC bool.
	 * @return string
	 */
	public static function wc_bool_to_smack( $value ) {
		if ( $value === '' || $value === null ) {
			return '';
		}
		return self::is_truthy( $value ) ? '1' : '0';
	}

	/**
	 * Smack bool → WC 1/0.
	 *
	 * @param mixed $value Smack value.
	 * @return string
	 */
	public static function smack_bool_to_wc( $value ) {
		if ( $value === '' || $value === null ) {
			return '';
		}
		return self::is_truthy( $value ) ? '1' : '0';
	}

	/**
	 * Reviews: WC 1/0 → comment_status open/closed.
	 *
	 * @param mixed $value WC reviews_allowed.
	 * @return string
	 */
	public static function reviews_wc_to_comment_status( $value ) {
		if ( $value === '' || $value === null ) {
			return '';
		}
		return self::is_truthy( $value ) ? 'open' : 'closed';
	}

	/**
	 * comment_status → WC reviews 1/0.
	 *
	 * @param mixed $status comment_status.
	 * @return string
	 */
	public static function comment_status_to_reviews( $status ) {
		$status = strtolower( (string) $status );
		if ( $status === 'open' || self::is_truthy( $status ) ) {
			return '1';
		}
		if ( $status === 'closed' || $status === '0' || $status === 'no' ) {
			return '0';
		}
		return '';
	}

	/**
	 * Convert WC description `\n` literals to real newlines.
	 *
	 * @param string $description Description.
	 * @return string
	 */
	public static function description_wc_to_smack( $description ) {
		$description = (string) $description;
		$description = str_replace( '\\\\n', "\n", $description );
		$description = str_replace( '\n', "\n", $description );
		return $description;
	}

	/**
	 * Convert newlines to WC `\n` literals.
	 *
	 * @param string $description Description.
	 * @return string
	 */
	public static function description_smack_to_wc( $description ) {
		$description = (string) $description;
		$description = str_replace( '\n', '\\\\n', $description );
		$description = str_replace( "\n", '\n', $description );
		return $description;
	}

	/**
	 * Normalize linked product list (SKU or id:N) for Smack (comma-separated IDs or titles/SKUs).
	 * Passes through SKUs; resolves id:N to numeric ID.
	 *
	 * @param string $value WC linked products cell.
	 * @return string
	 */
	public static function linked_products_wc_to_smack( $value ) {
		$parts  = self::explode_list( (string) $value );
		$result = array();
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( $part === '' ) {
				continue;
			}
			if ( class_exists( __NAMESPACE__ . '\\ProductResolver' ) ) {
				$id = ProductResolver::resolve_product_id( $part );
				if ( $id > 0 ) {
					$result[] = (string) $id;
					continue;
				}
			}
			if ( preg_match( '/^id:(\d+)$/i', $part, $m ) ) {
				$result[] = $m[1];
			} else {
				$result[] = $part;
			}
		}
		return implode( ',', $result );
	}

	/**
	 * WC sale date → Unix timestamp string for Smack importer.
	 *
	 * @param mixed $value Date cell.
	 * @return string
	 */
	public static function sale_date_wc_to_smack( $value ) {
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return '';
		}
		if ( is_numeric( $value ) ) {
			return (string) (int) $value;
		}
		$ts = strtotime( $value );
		return $ts ? (string) $ts : $value;
	}

	/**
	 * Build WC linked products from IDs/SKUs/names (prefer SKU).
	 *
	 * @param string $value Comma or pipe separated identifiers.
	 * @return string
	 */
	public static function linked_products_smack_to_wc( $value ) {
		$value = str_replace( '|', ',', (string) $value );
		$parts = self::explode_list( $value );
		$out   = array();

		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( $part === '' ) {
				continue;
			}
			if ( is_numeric( $part ) && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( (int) $part );
				if ( $product ) {
					$sku = $product->get_sku();
					$out[] = $sku !== '' ? $sku : ( 'id:' . $product->get_id() );
					continue;
				}
			}
			if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
				$id = wc_get_product_id_by_sku( $part );
				if ( $id ) {
					$out[] = $part;
					continue;
				}
			}
			// Title lookup.
			if ( function_exists( 'wc_get_products' ) ) {
				$found = wc_get_products(
					array(
						'limit' => 1,
						'name'  => $part,
						'return' => 'ids',
					)
				);
				if ( ! empty( $found ) ) {
					$product = wc_get_product( $found[0] );
					if ( $product ) {
						$sku = $product->get_sku();
						$out[] = $sku !== '' ? $sku : ( 'id:' . $product->get_id() );
						continue;
					}
				}
			}
			$out[] = $part;
		}

		return implode( ', ', $out );
	}

	/**
	 * Parent field: WC SKU or id:N → Smack parent (SKU preferred).
	 *
	 * @param string $value Parent cell.
	 * @return string
	 */
	public static function parent_wc_to_smack( $value ) {
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return '';
		}
		if ( preg_match( '/^id:(\d+)$/i', $value, $m ) ) {
			if ( function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( (int) $m[1] );
				if ( $product ) {
					$sku = $product->get_sku();
					return $sku !== '' ? $sku : $m[1];
				}
			}
			return $m[1];
		}
		return $value;
	}

	/**
	 * @param mixed $value Value.
	 * @return bool
	 */
	public static function is_truthy( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		$val = strtolower( trim( (string) $value ) );
		return in_array( $val, array( '1', 'yes', 'true', 'on' ), true );
	}

	/**
	 * Explode WC multi-value list (comma+space, escaped commas).
	 *
	 * @param string $value Cell value.
	 * @return string[]
	 */
	public static function explode_list( $value ) {
		$value = (string) $value;
		if ( $value === '' ) {
			return array();
		}
		$parts = preg_split( '/(?<!\\\\),\s*/', $value );
		return array_map(
			function ( $p ) {
				return str_replace( '\\,', ',', trim( $p ) );
			},
			$parts
		);
	}
}
