<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

class Tables {

	private static $instance = null;
	private static $smack_csv_instance = null;

	public static function getInstance() {
		if (Tables::$instance == null) {
			Tables::$instance = new Tables;
			Tables::$smack_csv_instance = UltimatePro::getInstance();
			Tables::$instance->create_tables();
			return Tables::$instance;
		}
		return Tables::$instance;
	}

	public function create_tables(){
		global $wpdb;

		//updated woo attribute 
		$get_pro_settings = get_option("sm_uci_pro_settings");
		if (!isset($get_pro_settings['woocomattr'])) {
			$get_pro_settings['woocomattr'] = true;
			update_option('sm_uci_pro_settings', $get_pro_settings);
		} 

		$result_01 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_export_template'");
		if($result_01 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_export_template'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_export_template TO {$wpdb->prefix}sm_uci_addon_pro_export_template");
			}
		}
		$result_02 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}clitemplate'");
		if($result_02 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_clitemplate'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE `{$wpdb->prefix}clitemplate` TO {$wpdb->prefix}sm_uci_addon_pro_clitemplate");
			}
		}
		$result_03 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_external_file_schedules'");
		if($result_03 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_external_file_schedules'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_external_file_schedules TO {$wpdb->prefix}sm_uci_addon_pro_external_file_schedules");
			}
		}
		$result_04 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_ftp_schedules'");
		if($result_04 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_ftp_schedules'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_ftp_schedules TO {$wpdb->prefix}sm_uci_addon_pro_ftp_schedules");
			}
		}
		$result_05 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_media_report'");
		if($result_05 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_media_report'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_media_report TO {$wpdb->prefix}sm_uci_addon_pro_media_report");
			}
		}
		$result_06 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}post_entries_table'");
		if($result_06 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_post_entries_table'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}post_entries_table TO {$wpdb->prefix}sm_uci_addon_pro_post_entries_table");
			}
		}
		$result_07 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_scheduled_export'");
		if($result_07 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_scheduled_export'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_scheduled_export TO {$wpdb->prefix}sm_uci_addon_pro_scheduled_export");
			}
		}
		$result_08 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}ultimate_csv_importer_scheduled_import'");
		if($result_08 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_scheduled_import'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}ultimate_csv_importer_scheduled_import TO {$wpdb->prefix}sm_uci_addon_pro_scheduled_import");
			}
		}
		$result_09 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}smack_field_types'");
		if($result_09 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_field_types'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}smack_field_types TO {$wpdb->prefix}sm_uci_addon_pro_field_types");
			}
		}
		$result_010 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}smack_sc_map'");
		if($result_010 != 0){
			$check_new = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}sm_uci_addon_pro_sc_map'");
			if($check_new == 0){
				$wpdb->query("RENAME TABLE {$wpdb->prefix}smack_sc_map TO {$wpdb->prefix}sm_uci_addon_pro_sc_map");
			}
		}

		

	
		$file_table_name = $wpdb->prefix ."smackcsv_file_events";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $file_table_name (
			`id` int(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			`file_name` VARCHAR(255) NOT NULL,
			`status` VARCHAR(255) NOT NULL,
			`mode` VARCHAR(255) NOT NULL,
			`hash_key` VARCHAR(255) NOT NULL,
			`templatekey` VARCHAR(32),
			`total_rows` longtext,
			`lock` BOOLEAN DEFAULT false,
			`progress` INT(6)) ENGINE=InnoDB" 
				);
			
		$image_media_table =  $wpdb->prefix ."sm_uci_addon_pro_media_report";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $image_media_table (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`hash_key` VARCHAR(255) NOT NULL,
			`templatekey` VARCHAR(32),
			`status` VARCHAR(255) DEFAULT 'pending',
			`module` VARCHAR(255) DEFAULT NULL,
			`image_type` VARCHAR(255) DEFAULT NULL,
			`success_count` VARCHAR(255) DEFAULT 0,
			`fail_count` VARCHAR(255) DEFAULT 0,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB"
				);

		$shortcode_table_name =  $wpdb->prefix ."ultimate_csv_importer_shortcode_manager";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $shortcode_table_name (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`post_id` INT(6),
			`post_title` VARCHAR(255) DEFAULT NULL,
			`image_shortcode` VARCHAR(255) NOT NULL,
			`media_id` INT(6) DEFAULT NULL,
			`original_image` TEXT NOT NULL,
			`indexs` INT(10) DEFAULT NULL,
			`status` VARCHAR(255) DEFAULT 'failed',
			`image_meta` TEXT DEFAULT NULL,
			`hash_key` VARCHAR(255) DEFAULT NULL,
			`import_type` VARCHAR(10) DEFAULT NULL,
			`file_name` VARCHAR(100) ,
			`jet_child_object_id` VARCHAR(20) DEFAULT NULL,
			`jet_parent_object_id` VARCHAR(20) DEFAULT NULL,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB"
				);

		$schedule_import_table = $wpdb->prefix ."sm_uci_addon_pro_scheduled_import";
		$table = $wpdb->query( "CREATE TABLE IF NOT EXISTS $schedule_import_table (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`templateid` int(10) NOT NULL,
			`importid` int(10) NOT NULL,
			`createdtime` datetime NOT NULL,
			`updatedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			`isrun` int(1) DEFAULT '0',
			`scheduledtimetorun` varchar(10) NOT NULL,
			`scheduleddate` date NOT NULL,
			`module` varchar(100) NOT NULL,
			`file_type` varchar(10) NOT NULL,
			`response` blob,
			`version` varchar(10) DEFAULT NULL,
			`event_key` varchar(100) DEFAULT NULL,
			`importbymethod` varchar(60) DEFAULT NULL,
			`import_limit` int(11) DEFAULT '1',
			`import_row_ids` blob default NULL,
			`frequency` int(5) DEFAULT '0',
			`start_limit` int(11) DEFAULT '0',
			`end_limit` int(11) DEFAULT '0',
			`lastrun` datetime DEFAULT '0000-00-00 00:00:00',
			`nexrun` datetime DEFAULT '0000-00-00 00:00:00',
			`scheduled_by_user` varchar(10) DEFAULT '1',
			`cron_status` varchar(30) DEFAULT 'pending',
			`import_mode` varchar(100) NOT NULL,
			`duplicate_headers` blob DEFAULT NULL,
			`time_zone` varchar(100) DEFAULT NULL,
			`hook_name` varchar(100) DEFAULT NULL,
			`check_manage_filter` tinyint(1) NOT NULL DEFAULT 0,
			`last_heartbeat_at` datetime DEFAULT NULL,
			`retry_count` int(11) NOT NULL DEFAULT 0,
			`max_retries` int(11) NOT NULL DEFAULT 3,
			PRIMARY KEY (`id`)) ENGINE=InnoDB"
				);
				
		$schedule_export_table = $wpdb->prefix ."sm_uci_addon_pro_scheduled_export";
		$table = $wpdb->query( "CREATE TABLE IF NOT EXISTS $schedule_export_table (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`module` varchar(100) NOT NULL,
			`export_mode` varchar(20) NOT NULL,
			`optionalType` varchar(100) DEFAULT NULL,
			`conditions` blob,
			`exclusions` blob,
			`file_name` varchar(100),
			`isrun` int(1) DEFAULT '0',
			`scheduleddate` date NOT NULL,
			`frequency` int(5) DEFAULT '0',
			`exportbymethod` varchar(60) DEFAULT NULL,
			`scheduledtimetorun` varchar(10) NOT NULL,
			`host_name` varchar(160),
			`host_port` int(5),
			`host_username` varchar(160),
			`host_password` varchar(160),
			`host_path` varchar(300),
			`file_type` varchar(10) NOT NULL,
			`start_limit` int(11) DEFAULT '0',
			`end_limit` int(11) DEFAULT '1000',
			`lastrun` datetime DEFAULT '0000-00-00 00:00:00',
			`nexrun` datetime DEFAULT '0000-00-00 00:00:00',
			`scheduled_by_user` varchar(10) DEFAULT '1',
			`cron_status` varchar(30) DEFAULT 'pending',
			`custom_options` blob DEFAULT NULL,
			`createdtime` datetime NOT NULL,
			`updatedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			`time_zone` varchar(100) DEFAULT NULL,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB"
				);

		$ftp_schedule_table = $wpdb->prefix . "sm_uci_addon_pro_ftp_schedules";
		$table = $wpdb->query( "
				CREATE TABLE IF NOT EXISTS $ftp_schedule_table (
					`id` int(10) NOT NULL AUTO_INCREMENT,
					`schedule_id` int(10) NOT NULL,
					`hostname` varchar(110) DEFAULT NULL,
					`username` varchar(110) DEFAULT NULL,
					`password` varchar(110) DEFAULT NULL,
					`initial_path` varchar(225) DEFAULT NULL,
					`filename` varchar(110) DEFAULT NULL,
					`port_no` int(5) DEFAULT NULL,
					`hosttype` varchar(110) DEFAULT NULL,
					PRIMARY KEY (`id`)
					) ENGINE=InnoDB");

		$external_url_schedule = $wpdb->prefix . "sm_uci_addon_pro_external_file_schedules";
		$table = $wpdb->query( "CREATE TABLE IF NOT EXISTS $external_url_schedule (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`schedule_id` int(10) NOT NULL,
			`file_url` text,
			`filename` varchar(255) DEFAULT NULL,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB");

		// AWIN / long feed URLs exceed varchar(255) and were truncated mid-columns
		// (e.g. ...description → ...descri), dropping search_price from scheduled downloads.
		$file_url_col = $wpdb->get_row( "SHOW COLUMNS FROM `{$external_url_schedule}` LIKE 'file_url'" );
		if ( $file_url_col && isset( $file_url_col->Type ) && stripos( $file_url_col->Type, 'text' ) === false ) {
			$wpdb->query( "ALTER TABLE `{$external_url_schedule}` MODIFY COLUMN `file_url` TEXT NULL" );
		}
		$template_table_name = $wpdb->prefix ."ultimate_csv_importer_mappingtemplate";
		$table = $wpdb->query( "CREATE TABLE IF NOT EXISTS $template_table_name (
			`id` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			`templatename` varchar(250) NOT NULL,
			`mapping` blob NOT NULL,
			`mapping_filter` blob NOT NULL,
			`createdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`deleted` int(1) DEFAULT '0',
			`templateused` int(10) DEFAULT '0',
			`mapping_type` varchar(30),
			`module` varchar(50) DEFAULT NULL,
			`csvname` varchar(250) DEFAULT NULL,
			`eventKey` varchar(60) DEFAULT NULL				
				) ENGINE = InnoDB "
				);  


		$export_template_table_name = $wpdb->prefix ."sm_uci_addon_pro_export_template";
		$table = $wpdb->query( "CREATE TABLE IF NOT EXISTS $export_template_table_name (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`filename` varchar(250) NOT NULL,
			`module` varchar(50) DEFAULT NULL,
			`optional_type` varchar(50) DEFAULT NULL,
			`export_type` varchar(50) DEFAULT NULL,
			`split` varchar(50) DEFAULT NULL,
			`split_limit` int(50) DEFAULT NULL,
			`category_name` varchar(50) DEFAULT NULL,
			`conditions` blob DEFAULT NULL,
			`event_exclusions` blob DEFAULT NULL,
			`export_mode` varchar(50) DEFAULT 'normal',
			`createdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`offset` int(50) DEFAULT 0,	
			`actual_start_date` varchar(250) DEFAULT NULL,
			`actual_end_date` varchar(250) DEFAULT NULL,
			`actual_schedule_date` varchar(250) DEFAULT NULL,
			PRIMARY KEY (`id`)		
			) ENGINE=InnoDB"
		);  


		$log_table_name = $wpdb->prefix ."import_detail_log";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $log_table_name (
			`id` int(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			`file_name` VARCHAR(255) NOT NULL,			
			`templatekey` VARCHAR(32),
			`status` VARCHAR(255) NOT NULL,
			`hash_key` VARCHAR(255) NOT NULL,
			`total_records` INT(6),
			`processing_records` INT(6) default 0,
			`remaining_records` INT(6) default 0,
			`filesize` VARCHAR(255) NOT NULL,
			`created` bigint(20) NOT NULL default 0,
			`updated` bigint(20) NOT NULL default 0,
			`skipped` bigint(20) NOT NULL default 0,
			`failed` bigint(20) NOT NULL default 0,
			`running` boolean not null default 1
				) ENGINE=InnoDB" 
				);

		$import_records_table = $wpdb->prefix ."smackuci_events";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $import_records_table (
			`id` bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			`revision` bigint(20) NOT NULL default 0,
			`name` varchar(255),
			`original_file_name` varchar(255),
			`friendly_name` varchar(255),
			`import_type` varchar(32),
			`filetype` text,
			`filepath` text,
			`eventKey` varchar(32),
			`registered_on` datetime NOT NULL default '0000-00-00 00:00:00',
			`parent_node` varchar(255),
			`processing` tinyint(1) NOT NULL default 0,
			`executing` tinyint(1) NOT NULL default 0,
			`triggered` tinyint(1) NOT NULL default 0,
			`event_started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`count` bigint(20) NOT NULL default 0,
			`processed` bigint(20) NOT NULL default 0,
			`created` bigint(20) NOT NULL default 0,
			`updated` bigint(20) NOT NULL default 0,
			`skipped` bigint(20) NOT NULL default 0,
			`deleted` bigint(20) NOT NULL default 0,
			`failed` bigint(20) NOT NULL default 0,
			`is_terminated` tinyint(1) NOT NULL default 0,
			`terminated_on` datetime NOT NULL default '0000-00-00 00:00:00',
			`last_activity` datetime NOT NULL default '0000-00-00 00:00:00',
			`siteid` int(11) NOT NULL DEFAULT 1,
			`month` varchar(60) DEFAULT NULL,
			`year` varchar(60) DEFAULT NULL,
			`deletelog` BOOLEAN DEFAULT false
				) ENGINE=InnoDB"
				);

		$custom_fields_table = $wpdb->prefix ."sm_uci_addon_pro_field_types";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $custom_fields_table (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`choices` varchar(160) NOT NULL,
			`fieldType` varchar(100) NOT NULL,
			`groupType` varchar(100) NOT NULL,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB"
				);

		$acf_fields_table = $wpdb->prefix ."ultimate_csv_importer_acf_fields";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $acf_fields_table (
			`id` int(10) NOT NULL AUTO_INCREMENT,
			`groupId` varchar(100) NOT NULL,
			`fieldId` varchar(100) NOT NULL,
			`fieldLabel` varchar(100) NOT NULL,
			`fieldName` varchar(100) NOT NULL,
			`fieldType` varchar(60) NOT NULL,
			`fdOption` varchar(100) DEFAULT NULL,
			PRIMARY KEY (`id`)
				) ENGINE=InnoDB"
				);

		$post_entries_table = $wpdb->prefix ."sm_uci_addon_pro_post_entries_table";
		$table = $wpdb->query("CREATE TABLE IF NOT EXISTS $post_entries_table (
					`ids` int(10) NOT NULL AUTO_INCREMENT,
					`ID` INT(6),
					`file_name` varchar(255) DEFAULT NULL,
					`type` varchar(255) DEFAULT NULL,
					`revision` INT(6),
					`status` varchar(255) DEFAULT NULL,
					PRIMARY KEY (`ids`)
					) ENGINE=InnoDB"
					);

		$clitemplate = $wpdb->prefix . "sm_uci_addon_pro_clitemplate";
		$clitemplate = $wpdb->query("CREATE TABLE IF NOT EXISTS $clitemplate (
			`ID` INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			`template_name` varchar(255) DEFAULT NULL,
			`file_name` varchar(255) DEFAULT NULL,
			`type` varchar(255) DEFAULT NULL,
			`templatekey` varchar(32),	
			`month` varchar(60) DEFAULT NULL,
			`year` varchar(60) DEFAULT NULL					
			) ENGINE=InnoDB"
			); 


		//summary log
		$summarylog = $wpdb->prefix . "summary";
		$wpdb->query("
		CREATE TABLE IF NOT EXISTS $summarylog (
		`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		`event_id` VARCHAR(255) NOT NULL,
		`post_id` INT  NULL,
		`post_title` VARCHAR(255)  NULL,
		`post_type` VARCHAR(255)  NULL,
		`status` VARCHAR(255)  NULL,
		`is_category` TINYINT NOT NULL,
		`associated_media` INT(250)  NULL,
		`failed_media` INT(250)  NULL
		) ENGINE=InnoDB;
		");

		//failed media log
		$failed_media = $wpdb->prefix . "failed_media";
		$wpdb->query("
		CREATE TABLE IF NOT EXISTS $failed_media (
		`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		`event_id` VARCHAR(255) NOT NULL,
		`post_id` INT NOT NULL,
		`media_id` INT NOT NULL,
		`title` VARCHAR(255)  NULL,
		`file_name` VARCHAR(255)  NULL,
		`caption` VARCHAR(255)  NULL,
		`description` VARCHAR(255)  NULL,
		`alt_text` VARCHAR(255)  NULL,
		`actual_url` VARCHAR(255)  NULL,
		`file_url` VARCHAR(255)  NULL,
		`status` VARCHAR(255)  NULL

		) ENGINE=InnoDB;
		");

		$column_exists = $wpdb->get_results("SHOW COLUMNS FROM `$schedule_import_table` LIKE 'check_manage_filter'");

		if (empty($column_exists)) {
			$wpdb->query("ALTER TABLE `$schedule_import_table` ADD COLUMN `check_manage_filter` TINYINT(1) NOT NULL DEFAULT 0");
		}

		$result = $wpdb->get_var("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_mappingtemplate` LIKE 'mapping_filter'");
		if(!$result){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_mappingtemplate` ADD COLUMN `mapping_filter` blob NULL AFTER `mapping`");
		}

		$result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}failed_media` LIKE 'post_title'");
		if($result){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}failed_media` CHANGE post_title title VARCHAR(20)");
		}
		$result_0 = $wpdb->get_row("SHOW COLUMNS FROM {$wpdb->prefix}smackcsv_file_events WHERE Field = 'total_rows'");
		if (strpos($result_0->Type, 'int')!==false) {
			$wpdb->query("ALTER TABLE {$wpdb->prefix}smackcsv_file_events MODIFY COLUMN total_rows longtext");
		}
		$result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'jet_child_object_id'");
		if($result == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN jet_child_object_id varchar(20)");
		}
		$result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'jet_parent_object_id'");
		if($result == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN jet_parent_object_id varchar(20)");
		}		
		$result_1 = $wpdb->query("SHOW INDEXES FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` WHERE Key_name='isrun'");
		if($result_1 == 0){
			$wpdb->query("ALTER TABLE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import ADD INDEX `isrun`(`isrun`);");
		}

		$result_2 = $wpdb->query("SHOW INDEXES FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_export` WHERE Key_name='isrun'");
		if($result_2 == 0){
			$wpdb->query("ALTER TABLE {$wpdb->prefix}sm_uci_addon_pro_scheduled_export ADD INDEX `isrun`(`isrun`);");
		}

		$result_3 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}import_detail_log` LIKE 'running'");
		if($result_3 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}import_detail_log` ADD COLUMN running boolean not null default 1");
		}

		$result_4 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}import_detail_log` LIKE 'templatekey'");
		if($result_4 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}import_detail_log` ADD COLUMN templatekey varchar(32)");
		}
		$result_5 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}import_detail_log` LIKE 'failed'");
		if($result_5 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}import_detail_log` ADD COLUMN failed bigint(20) NOT NULL default 0");
		}

		// $result_5 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'templatekey'");
		// if($result_5 == 0){
		// 	$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN templatekey varchar(32)");
		// }

		$result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_media_report` LIKE 'templatekey'");
		if($result == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_media_report` ADD COLUMN templatekey varchar(32)");
		}

		$result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}smackcsv_file_events` LIKE 'templatekey'");
		if($result == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}smackcsv_file_events` ADD COLUMN templatekey varchar(32)");
		}
		$schedule_result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` LIKE 'hook_name'");
		if($schedule_result == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` ADD COLUMN hook_name varchar(100) DEFAULT NULL;");
		}

		$heartbeat_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` LIKE 'last_heartbeat_at'" );
		if ( 0 === (int) $heartbeat_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` ADD COLUMN last_heartbeat_at datetime DEFAULT NULL" );
		}
		$retry_count_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` LIKE 'retry_count'" );
		if ( 0 === (int) $retry_count_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` ADD COLUMN retry_count int(11) NOT NULL DEFAULT 0" );
		}
		$max_retries_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` LIKE 'max_retries'" );
		if ( 0 === (int) $max_retries_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_scheduled_import` ADD COLUMN max_retries int(11) NOT NULL DEFAULT 3" );
		}

		$image_shortcode_result = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'original_image'");
		if($image_shortcode_result){
			$wpdb->query("ALTER table `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` MODIFY original_image TEXT NOT NULL;");
		}

		/** Added deletelog column for log manager deletion available from ultimate csv pro version 6.4  */
		$logmanager_result = $wpdb->query("SHOW COLUMNS FROM {$wpdb->prefix}smackuci_events LIKE 'deletelog'");
		if($logmanager_result == 0){
			$wpdb->query("ALTER table {$wpdb->prefix}smackuci_events ADD COLUMN deletelog BOOLEAN DEFAULT false;");
		}

		$result_failed_column = $wpdb->query("SHOW COLUMNS FROM {$wpdb->prefix}smackuci_events LIKE 'failed'");
		if($result_failed_column == 0){
			$wpdb->query("ALTER TABLE {$wpdb->prefix}smackuci_events ADD  COLUMN failed bigint(20) NOT NULL default 0");
		}

		$result_5 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_media_report` LIKE 'id'");
		if($result_5 == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}sm_uci_addon_pro_media_report` ADD COLUMN id int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY;");
		}

		// $result_6 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'id'");
		// if($result_6 == 0){
		// 	$wpdb->query("ALTER table `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN id int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY;");
		// }

		$result_7 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_post_entries_table` LIKE 'ids'");
		if($result_7 == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}sm_uci_addon_pro_post_entries_table` ADD COLUMN ids int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY;");
		}
		$result_16 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'indexs'");
		if($result_16 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN indexs int(10) DEFAULT NULL");
		}
		$result_8 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'import_type'");
		if($result_8 == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN import_type VARCHAR(10);");
		}
		$result_15 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'file_name'");
		if($result_15 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN file_name varchar(100)");
		}
		$result_12 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'post_title'");
		if($result_12 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN post_title varchar(255)");
		}
		$result_13 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'media_id'");
		if($result_13 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` ADD COLUMN media_id INT(6)");
		}
		$result_14 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'status'");
		if($result_14 == 1){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` Modify COLUMN status VARCHAR(255) DEFAULT 'failed'");
		}
		$result_17 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` LIKE 'hash_key'");
		if($result_17 == 1){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_shortcode_manager` Modify COLUMN hash_key VARCHAR(255) DEFAULT NULL ");
		}
		$result_18 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_export` LIKE 'type'");
		if($result_18 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_scheduled_export` ADD COLUMN type VARCHAR(255) DEFAULT NULL");
		}
		$result_19 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_scheduled_export` LIKE 'query_data'");
		if($result_19 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_scheduled_export` ADD COLUMN query_data VARCHAR(255) DEFAULT NULL ");
		}
		$result_20 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_export_template` LIKE 'type'");
		if($result_20 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_export_template` ADD COLUMN type VARCHAR(255) DEFAULT NULL");
		}
		$result_21 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_export_template` LIKE 'query_data'");
		if($result_21 == 0){
			$wpdb->query("ALTER TABLE `{$wpdb->prefix}sm_uci_addon_pro_export_template` ADD COLUMN query_data VARCHAR(255) DEFAULT NULL ");
		}
		$result_22 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_export_template` LIKE 'client_mode'");
		if($result_22 == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}sm_uci_addon_pro_export_template` ADD COLUMN client_mode varchar(50) DEFAULT NULL");
		}
		$result_23 = $wpdb->query("SHOW COLUMNS FROM `{$wpdb->prefix}sm_uci_addon_pro_export_template` LIKE 'client_mode_values'");
		if($result_23 == 0){
			$wpdb->query("ALTER table `{$wpdb->prefix}sm_uci_addon_pro_export_template` ADD COLUMN client_mode_values longtext DEFAULT NULL");
		}

		$retry_queue_table = $wpdb->prefix . 'sm_uci_addon_pro_retry_queue';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$retry_queue_table} (
			`retry_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`session_id` varchar(64) NOT NULL,
			`row_number` int(11) NOT NULL,
			`module` varchar(100) DEFAULT NULL,
			`import_type` varchar(32) DEFAULT NULL,
			`row_data` longtext NOT NULL,
			`failure_reason` text,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`created_at` datetime NOT NULL,
			`retried_at` datetime DEFAULT NULL,
			PRIMARY KEY (`retry_id`),
			KEY `session_status` (`session_id`, `status`),
			KEY `session_row` (`session_id`, `row_number`)
			) ENGINE=InnoDB"
		);

		$editor_overrides_table = $wpdb->prefix . 'sm_uci_addon_pro_editor_overrides';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$editor_overrides_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`hash_key` varchar(64) NOT NULL,
			`row_number` int(11) NOT NULL,
			`col_index` smallint(5) NOT NULL,
			`col_header` varchar(255) NOT NULL DEFAULT '',
			`cell_value` longtext,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `hash_row_col` (`hash_key`, `row_number`, `col_index`),
			KEY `hash_key_idx` (`hash_key`)
			) ENGINE=InnoDB"
		);

		$retry_history_table = $wpdb->prefix . 'sm_uci_addon_pro_retry_history';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$retry_history_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`session_id` varchar(64) NOT NULL,
			`recovered_count` int(11) NOT NULL DEFAULT 0,
			`failed_count` int(11) NOT NULL DEFAULT 0,
			`user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`retried_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			KEY `session_id` (`session_id`)
			) ENGINE=InnoDB"
		);

		$retry_recovered_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}smackuci_events` LIKE 'retry_recovered'" );
		if ( 0 === $retry_recovered_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}smackuci_events` ADD COLUMN retry_recovered bigint(20) NOT NULL DEFAULT 0" );
		}

		$retry_remaining_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}smackuci_events` LIKE 'retry_remaining'" );
		if ( 0 === $retry_remaining_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}smackuci_events` ADD COLUMN retry_remaining bigint(20) NOT NULL DEFAULT 0" );
		}

		$checkpoint_table = $wpdb->prefix . 'sm_uci_addon_pro_import_checkpoint';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$checkpoint_table} (
			`resume_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`import_hash` varchar(64) NOT NULL,
			`import_type` varchar(32) NOT NULL DEFAULT 'csv',
			`import_mode` varchar(32) NOT NULL DEFAULT 'bulk',
			`batch_number` int(11) NOT NULL DEFAULT 1,
			`page_number` int(11) NOT NULL DEFAULT 1,
			`line_number` int(11) NOT NULL DEFAULT 1,
			`processed_count` bigint(20) NOT NULL DEFAULT 0,
			`failed_count` bigint(20) NOT NULL DEFAULT 0,
			`skipped_count` bigint(20) NOT NULL DEFAULT 0,
			`state` varchar(20) NOT NULL DEFAULT 'PENDING',
			`queue_snapshot` longtext,
			`media_snapshot` longtext,
			`schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
			`file_name` varchar(255) DEFAULT NULL,
			`last_heartbeat_at` datetime DEFAULT NULL,
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`resume_id`),
			KEY `import_hash` (`import_hash`),
			KEY `state_heartbeat` (`state`, `last_heartbeat_at`)
			) ENGINE=InnoDB"
		);

		$ai_reviews_table = $wpdb->prefix . 'sm_uci_addon_pro_ai_reviews';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$ai_reviews_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`import_id` varchar(64) NOT NULL,
			`row_number` int(11) NOT NULL,
			`field_name` varchar(191) NOT NULL,
			`feature_type` varchar(32) NOT NULL DEFAULT '',
			`original_value` longtext,
			`suggested_value` longtext,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			KEY `import_status` (`import_id`, `status`),
			KEY `import_row` (`import_id`, `row_number`)
			) ENGINE=InnoDB"
		);

		$db_connections_table = $wpdb->prefix . 'sm_uci_addon_pro_db_connections';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$db_connections_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`connection_name` varchar(191) NOT NULL,
			`db_type` varchar(20) NOT NULL DEFAULT 'mysql',
			`host` varchar(255) NOT NULL,
			`port` smallint(5) UNSIGNED NOT NULL DEFAULT 3306,
			`database_name` varchar(191) NOT NULL,
			`username` varchar(191) NOT NULL,
			`password_enc` text NOT NULL,
			`ssl_enabled` tinyint(1) NOT NULL DEFAULT 0,
			`created_by` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `connection_name` (`connection_name`),
			KEY `created_by` (`created_by`)
			) ENGINE=InnoDB"
		);

		$db_import_sessions_table = $wpdb->prefix . 'sm_uci_addon_pro_db_import_sessions';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$db_import_sessions_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`hash_key` varchar(64) NOT NULL,
			`connection_id` bigint(20) UNSIGNED NOT NULL,
			`source_table` varchar(191) NOT NULL,
			`order_column` varchar(191) DEFAULT NULL,
			`last_offset` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`row_count` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`options` longtext,
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `hash_key` (`hash_key`),
			KEY `connection_id` (`connection_id`)
			) ENGINE=InnoDB"
		);

		$automation_jobs_table = $wpdb->prefix . 'sm_uci_addon_pro_automation_jobs';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$automation_jobs_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`template_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
			`schedule_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
			`hash_key` varchar(64) NOT NULL DEFAULT '',
			`status` varchar(20) NOT NULL DEFAULT 'queued',
			`trigger_source` varchar(20) NOT NULL DEFAULT 'api',
			`processed_count` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`total_count` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`started_at` datetime DEFAULT NULL,
			`ended_at` datetime DEFAULT NULL,
			`error_message` varchar(255) NOT NULL DEFAULT '',
			`baseline_log_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			KEY `template_id` (`template_id`),
			KEY `hash_key` (`hash_key`),
			KEY `status` (`status`)
			) ENGINE=InnoDB"
		);

		$automation_baseline_col = $wpdb->query( "SHOW COLUMNS FROM `{$automation_jobs_table}` LIKE 'baseline_log_id'" );
		if ( ! $automation_baseline_col ) {
			$wpdb->query( "ALTER TABLE `{$automation_jobs_table}` ADD COLUMN `baseline_log_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0 AFTER `error_message`" );
		}

		$automation_col = $wpdb->query( "SHOW COLUMNS FROM `{$wpdb->prefix}ultimate_csv_importer_mappingtemplate` LIKE 'automation_settings'" );
		if ( ! $automation_col ) {
			$wpdb->query( "ALTER TABLE `{$wpdb->prefix}ultimate_csv_importer_mappingtemplate` ADD COLUMN `automation_settings` longtext NULL AFTER `eventKey`" );
		}

		$ai_usage_log_table = $wpdb->prefix . 'sm_uci_addon_pro_ai_usage_log';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$ai_usage_log_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`import_id` varchar(64) NOT NULL DEFAULT '',
			`provider` varchar(32) NOT NULL DEFAULT '',
			`model` varchar(128) NOT NULL DEFAULT '',
			`operation` varchar(64) NOT NULL DEFAULT 'generate',
			`tokens_input` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`tokens_output` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`estimated_cost` decimal(12,6) NOT NULL DEFAULT 0.000000,
			`status` varchar(20) NOT NULL DEFAULT 'success',
			`error_message` text,
			`created_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			KEY `provider_created` (`provider`, `created_at`),
			KEY `import_op` (`import_id`, `operation`),
			KEY `status_created` (`status`, `created_at`)
			) ENGINE=InnoDB"
		);

		$ai_prompt_templates_table = $wpdb->prefix . 'sm_uci_addon_pro_ai_prompt_templates';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$ai_prompt_templates_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`slug` varchar(64) NOT NULL,
			`name` varchar(191) NOT NULL,
			`feature_type` varchar(32) NOT NULL DEFAULT 'custom',
			`body` longtext NOT NULL,
			`is_system` tinyint(1) NOT NULL DEFAULT 0,
			`created_at` datetime NOT NULL,
			`updated_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `slug` (`slug`)
			) ENGINE=InnoDB"
		);

		$row_log_table = $wpdb->prefix . 'sm_uci_addon_pro_import_row_log';
		$wpdb->query(
			"CREATE TABLE IF NOT EXISTS {$row_log_table} (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`import_hash` varchar(64) NOT NULL,
			`row_number` int(11) NOT NULL,
			`status` varchar(20) NOT NULL,
			`post_id` bigint(20) UNSIGNED DEFAULT NULL,
			`completed_at` datetime NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `hash_row` (`import_hash`, `row_number`),
			KEY `import_hash` (`import_hash`)
			) ENGINE=InnoDB"
		);
	}
}