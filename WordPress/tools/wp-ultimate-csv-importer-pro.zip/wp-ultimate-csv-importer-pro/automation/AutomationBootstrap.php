<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation;

use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Controllers\AutomationRestController;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Controllers\AutomationSettingsController;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\ImportTriggerService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstrap API / webhook import automation (Pro only).
 */
class AutomationBootstrap {

	/**
	 * Initialize automation module.
	 */
	public static function init() {
		$base = __DIR__;
		require_once $base . '/Services/ApiKeyService.php';
		require_once $base . '/Services/IpWhitelistValidator.php';
		require_once $base . '/Services/WebhookSignatureValidator.php';
		require_once $base . '/Services/TemplateAutomationSettings.php';
		require_once $base . '/Services/AutomationJobService.php';
		require_once $base . '/Services/ImportTriggerService.php';
		require_once $base . '/Controllers/AutomationRestController.php';
		require_once $base . '/Controllers/AutomationSettingsController.php';

		ImportTriggerService::register_hooks();
		add_action( 'rest_api_init', array( AutomationRestController::class, 'register_routes' ) );
		AutomationSettingsController::getInstance();
	}
}
