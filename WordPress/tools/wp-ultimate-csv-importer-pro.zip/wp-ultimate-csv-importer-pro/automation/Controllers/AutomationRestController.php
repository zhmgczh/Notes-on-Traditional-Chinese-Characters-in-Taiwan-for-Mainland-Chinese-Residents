<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Controllers;

use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\ApiKeyService;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\AutomationJobService;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\ImportTriggerService;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\TemplateAutomationSettings;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\WebhookSignatureValidator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public REST routes for API and webhook import triggers.
 */
class AutomationRestController {

	const NAMESPACE = 'uci-pro/v1';

	/**
	 * Register routes on rest_api_init.
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/import/(?P<template_id>\d+)/trigger',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'trigger_import' ),
				'permission_callback' => array( __CLASS__, 'api_key_permission' ),
				'args'                => array(
					'template_id' => array(
						'validate_callback' => function ( $value ) {
							return absint( $value ) > 0;
						},
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/import/status/(?P<job_id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_import_status' ),
				'permission_callback' => array( __CLASS__, 'api_key_permission' ),
				'args'                => array(
					'job_id' => array(
						'validate_callback' => function ( $value ) {
							return absint( $value ) > 0;
						},
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/webhook/(?P<template_id>\d+)',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_webhook' ),
				'permission_callback' => array( __CLASS__, 'webhook_permission' ),
				'args'                => array(
					'template_id' => array(
						'validate_callback' => function ( $value ) {
							return absint( $value ) > 0;
						},
					),
				),
			)
		);
	}

	/**
	 * Require a valid API key before trigger/status handlers run.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public static function api_key_permission( $request ) {
		$api_key = ApiKeyService::extract_key_from_request( $request );
		if ( ! ApiKeyService::validate( $api_key ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'Invalid API key.', 'wp-ultimate-csv-importer-pro' ),
				array( 'status' => 401 )
			);
		}
		return true;
	}

	/**
	 * Webhook routes validate HMAC signatures in the callback.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public static function webhook_permission( $request ) {
		return true;
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function trigger_import( $request ) {
		$template_id = absint( $request['template_id'] );
		$api_key     = ApiKeyService::extract_key_from_request( $request );

		if ( ! ApiKeyService::validate( $api_key ) ) {
			return new \WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Invalid API key.', 'wp-ultimate-csv-importer-pro' ) ),
				401
			);
		}

		$result = ImportTriggerService::queue_import( $template_id, AutomationJobService::SOURCE_API );
		if ( is_wp_error( $result ) ) {
			return self::error_response( $result );
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function get_import_status( $request ) {
		$job_id  = absint( $request['job_id'] );
		$api_key = ApiKeyService::extract_key_from_request( $request );

		if ( ! ApiKeyService::validate( $api_key ) ) {
			return new \WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Invalid API key.', 'wp-ultimate-csv-importer-pro' ) ),
				401
			);
		}

		$payload = AutomationJobService::get_status_payload( $job_id );
		if ( empty( $payload ) ) {
			return new \WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Job not found.', 'wp-ultimate-csv-importer-pro' ) ),
				404
			);
		}

		return new \WP_REST_Response( $payload, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function handle_webhook( $request ) {
		$template_id = absint( $request['template_id'] );
		$raw_body    = $request->get_body();
		$signature   = WebhookSignatureValidator::get_signature_from_request( $request );

		$settings = TemplateAutomationSettings::get_settings( $template_id );
		$secret   = isset( $settings['webhook_secret'] ) ? $settings['webhook_secret'] : '';

		if ( ! WebhookSignatureValidator::verify( $raw_body, $secret, $signature ) ) {
			return new \WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Invalid signature.', 'wp-ultimate-csv-importer-pro' ) ),
				401
			);
		}

		$result = ImportTriggerService::queue_import( $template_id, AutomationJobService::SOURCE_WEBHOOK );
		if ( is_wp_error( $result ) ) {
			return self::error_response( $result );
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * @param \WP_Error $error Error.
	 * @return \WP_REST_Response
	 */
	private static function error_response( $error ) {
		$status = 400;
		if ( is_array( $error->get_error_data() ) && isset( $error->get_error_data()['status'] ) ) {
			$status = (int) $error->get_error_data()['status'];
		}
		return new \WP_REST_Response(
			array(
				'success' => false,
				'message' => $error->get_error_message(),
				'code'    => $error->get_error_code(),
			),
			$status
		);
	}
}
