<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Controllers;

use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\ApiKeyService;
use Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services\TemplateAutomationSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin AJAX for API key and per-template automation settings.
 */
class AutomationSettingsController {

	protected static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}
		return self::$instance;
	}

	/**
	 * Register AJAX actions.
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_uci_automation_get_api_key', array( $this, 'ajax_get_api_key' ) );
		add_action( 'wp_ajax_uci_automation_regenerate_api_key', array( $this, 'ajax_regenerate_api_key' ) );
		add_action( 'wp_ajax_uci_automation_get_template_settings', array( $this, 'ajax_get_template_settings' ) );
		add_action( 'wp_ajax_uci_automation_save_template_settings', array( $this, 'ajax_save_template_settings' ) );
	}

	/**
	 * @return bool
	 */
	private function authorize_admin() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'wp-ultimate-csv-importer-pro' ) ), 403 );
			return false;
		}
		return true;
	}

	/**
	 * Masked API key status for settings UI.
	 */
	public function ajax_get_api_key() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		wp_send_json_success(
			array(
				'has_key'  => ApiKeyService::has_key(),
				'masked'   => ApiKeyService::masked_preview(),
				'endpoint' => rest_url( AutomationRestController::NAMESPACE . '/import/{template_id}/trigger' ),
			)
		);
	}

	/**
	 * Generate new site API key.
	 */
	public function ajax_regenerate_api_key() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		$key = ApiKeyService::regenerate();
		wp_send_json_success(
			array(
				'api_key' => $key,
				'masked'  => ApiKeyService::masked_preview(),
			)
		);
	}

	/**
	 * Load template automation settings.
	 */
	public function ajax_get_template_settings() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		$template_id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;
		if ( $template_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid template.', 'wp-ultimate-csv-importer-pro' ) ) );
			return;
		}
		wp_send_json_success( TemplateAutomationSettings::get_settings_for_display( $template_id ) );
	}

	/**
	 * Save template automation settings.
	 */
	public function ajax_save_template_settings() {
		if ( ! $this->authorize_admin() ) {
			return;
		}
		$template_id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;
		if ( $template_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid template.', 'wp-ultimate-csv-importer-pro' ) ) );
			return;
		}
		$input = array(
			'enable_api_trigger'       => ! empty( $_POST['enable_api_trigger'] ),
			'enable_webhook'           => ! empty( $_POST['enable_webhook'] ),
			'allowed_ips'              => isset( $_POST['allowed_ips'] ) ? wp_unslash( $_POST['allowed_ips'] ) : '',
			'webhook_secret'           => isset( $_POST['webhook_secret'] ) ? trim( (string) wp_unslash( $_POST['webhook_secret'] ) ) : '',
			'regenerate_webhook_secret' => ! empty( $_POST['regenerate_webhook_secret'] ),
		);
		$result = TemplateAutomationSettings::save_settings( $template_id, $input );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			return;
		}
		wp_send_json_success( TemplateAutomationSettings::get_settings_for_display( $template_id ) );
	}
}
