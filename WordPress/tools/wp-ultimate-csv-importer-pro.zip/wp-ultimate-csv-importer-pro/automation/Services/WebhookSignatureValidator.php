<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * HMAC-SHA256 webhook verification (X-UCI-Signature header).
 */
class WebhookSignatureValidator {

	const HEADER_NAME = 'X-UCI-Signature';

	/**
	 * @param string $raw_body   Raw request body.
	 * @param string $secret     Template webhook secret.
	 * @param string $signature  Header value (hex).
	 * @return bool
	 */
	public static function verify( $raw_body, $secret, $signature ) {
		$secret    = (string) $secret;
		$signature = strtolower( trim( (string) $signature ) );
		if ( $secret === '' || $signature === '' ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', (string) $raw_body, $secret );
		return hash_equals( $expected, $signature );
	}

	/**
	 * @param \WP_REST_Request|null $request REST request when available.
	 * @return string Header value from request.
	 */
	public static function get_signature_from_request( $request = null ) {
		if ( $request instanceof \WP_REST_Request ) {
			$header_names = array( 'x_uci_signature', 'X-UCI-Signature' );
			foreach ( $header_names as $header_name ) {
				$value = $request->get_header( $header_name );
				if ( is_string( $value ) && $value !== '' ) {
					return strtolower( trim( $value ) );
				}
			}
		}

		if ( isset( $_SERVER['HTTP_X_UCI_SIGNATURE'] ) ) {
			return strtolower( trim( (string) wp_unslash( $_SERVER['HTTP_X_UCI_SIGNATURE'] ) ) );
		}

		return '';
	}

	/**
	 * @deprecated Use get_signature_from_request().
	 * @return string
	 */
	public static function get_header_from_request() {
		return self::get_signature_from_request( null );
	}
}
