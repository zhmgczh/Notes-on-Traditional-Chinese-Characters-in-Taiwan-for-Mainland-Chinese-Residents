<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site-wide REST API key for automation triggers.
 */
class ApiKeyService {

	const OPTION_NAME = 'sm_uci_pro_automation_api_key';

	/**
	 * @return string Plain API key or empty if not generated.
	 */
	public static function get_key() {
		return (string) get_option( self::OPTION_NAME, '' );
	}

	/**
	 * @return bool
	 */
	public static function has_key() {
		return self::get_key() !== '';
	}

	/**
	 * @return string New key (64+ chars).
	 */
	public static function regenerate() {
		$key = wp_generate_password( 64, true, true );
		update_option( self::OPTION_NAME, $key, false );
		return $key;
	}

	/**
	 * Normalize key from REST/query/header without stripping special characters.
	 *
	 * Do not use sanitize_text_field() — keys from wp_generate_password() may contain
	 * &lt; &gt; &amp; etc. and would be truncated or altered.
	 *
	 * @param mixed $provided Raw value.
	 * @return string
	 */
	public static function normalize_provided_key( $provided ) {
		if ( is_array( $provided ) || is_object( $provided ) ) {
			return '';
		}
		return trim( (string) wp_unslash( $provided ) );
	}

	/**
	 * @param string $provided Key from request.
	 * @return bool
	 */
	public static function validate( $provided ) {
		$stored    = self::get_key();
		$provided  = self::normalize_provided_key( $provided );
		if ( $stored === '' || $provided === '' ) {
			return false;
		}
		return hash_equals( $stored, $provided );
	}

	/**
	 * Extract API key from a REST request (JSON body, query, or headers).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return string
	 */
	public static function extract_key_from_request( $request ) {
		$params = $request->get_json_params();
		if ( is_array( $params ) && isset( $params['api_key'] ) ) {
			$key = self::normalize_provided_key( $params['api_key'] );
			if ( $key !== '' ) {
				return $key;
			}
		}

		$key = self::normalize_provided_key( $request->get_param( 'api_key' ) );
		if ( $key !== '' ) {
			return $key;
		}

		$body = (string) $request->get_body();
		if ( $body !== '' ) {
			$decoded = json_decode( $body, true );
			if ( is_array( $decoded ) && isset( $decoded['api_key'] ) ) {
				$key = self::normalize_provided_key( $decoded['api_key'] );
				if ( $key !== '' ) {
					return $key;
				}
			}
		}

		$header_names = array( 'x_uci_api_key', 'X-UCI-API-Key', 'X-UCI-Api-Key' );
		foreach ( $header_names as $header_name ) {
			$header_val = $request->get_header( $header_name );
			if ( is_string( $header_val ) && $header_val !== '' ) {
				$key = self::normalize_provided_key( $header_val );
				if ( $key !== '' ) {
					return $key;
				}
			}
		}

		if ( isset( $_SERVER['HTTP_X_UCI_API_KEY'] ) ) {
			$key = self::normalize_provided_key( $_SERVER['HTTP_X_UCI_API_KEY'] );
			if ( $key !== '' ) {
				return $key;
			}
		}

		$auth = $request->get_header( 'authorization' );
		if ( is_string( $auth ) && stripos( $auth, 'bearer ' ) === 0 ) {
			return self::normalize_provided_key( substr( $auth, 7 ) );
		}

		return '';
	}

	/**
	 * Masked preview for admin UI.
	 *
	 * @return string
	 */
	public static function masked_preview() {
		if ( ! self::has_key() ) {
			return '';
		}
		return str_repeat( '*', 48 ) . substr( self::get_key(), -8 );
	}
}
