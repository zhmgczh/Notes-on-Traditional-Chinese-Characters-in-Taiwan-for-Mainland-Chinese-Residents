<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\ImportResumeService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Automation job records for API/webhook triggers.
 */
class AutomationJobService {

	const TABLE_SUFFIX = 'sm_uci_addon_pro_automation_jobs';

	const STATUS_QUEUED    = 'queued';
	const STATUS_RUNNING   = 'running';
	const STATUS_COMPLETED = 'completed';
	const STATUS_FAILED    = 'failed';

	const SOURCE_API      = 'api';
	const SOURCE_WEBHOOK  = 'webhook';
	const SOURCE_MANUAL   = 'manual';
	const SOURCE_SCHEDULER = 'scheduler';

	/**
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_SUFFIX;
	}

	/**
	 * @param int    $template_id   Template ID.
	 * @param string $trigger_source api|webhook.
	 * @param int    $schedule_id   Ephemeral schedule row ID.
	 * @return int Job ID.
	 */
	public static function create_job( $template_id, $trigger_source, $schedule_id = 0 ) {
		global $wpdb;
		$now = current_time( 'mysql', 1 );
		$wpdb->insert(
			self::table_name(),
			array(
				'template_id'     => absint( $template_id ),
				'schedule_id'     => absint( $schedule_id ),
				'hash_key'        => '',
				'status'          => self::STATUS_QUEUED,
				'trigger_source'  => sanitize_key( $trigger_source ),
				'processed_count' => 0,
				'total_count'     => 0,
				'started_at'      => null,
				'ended_at'        => null,
				'error_message'   => '',
				'baseline_log_id' => 0,
				'created_at'      => $now,
				'updated_at'      => $now,
			),
			array( '%d', '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * @param int    $job_id   Job ID.
	 * @param string $hash_key Event hash.
	 */
	public static function attach_hash_key( $job_id, $hash_key ) {
		global $wpdb;
		$wpdb->update(
			self::table_name(),
			array(
				'hash_key'   => sanitize_key( $hash_key ),
				'updated_at' => current_time( 'mysql', 1 ),
			),
			array( 'id' => absint( $job_id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * @param int $job_id Job ID.
	 * @return array<string, mixed>|null
	 */
	public static function get_job( $job_id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table_name() . ' WHERE id = %d LIMIT 1',
				absint( $job_id )
			),
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Sync progress from import_detail_log.
	 *
	 * @param int $job_id Job ID.
	 */
	public static function sync_progress_from_log( $job_id ) {
		$job = self::get_job( $job_id );
		if ( ! $job || empty( $job['hash_key'] ) ) {
			return;
		}
		global $wpdb;
		$baseline = isset( $job['baseline_log_id'] ) ? (int) $job['baseline_log_id'] : 0;
		$log      = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, total_records, processing_records, remaining_records, status FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s AND id > %d ORDER BY id DESC LIMIT 1",
				$job['hash_key'],
				$baseline
			),
			ARRAY_A
		);

		if ( ! $log ) {
			$total = self::get_expected_total_from_file( $job['hash_key'] );
			if ( $total > 0 && (int) $job['total_count'] === 0 ) {
				self::update_job( $job_id, array( 'total_count' => $total ) );
			}
			return;
		}

		$total     = (int) $log['total_records'];
		$processed = max( 0, (int) $log['processing_records'] );
		$status    = self::map_log_status( $log['status'], $job['status'] );
		self::update_job(
			$job_id,
			array(
				'total_count'     => $total,
				'processed_count' => $processed,
				'status'          => $status,
			)
		);
	}

	/**
	 * @param string $hash_key Event hash.
	 * @return int
	 */
	public static function get_expected_total_from_file( $hash_key ) {
		global $wpdb;
		$rows = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT total_rows FROM {$wpdb->prefix}smackcsv_file_events WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);
		if ( $rows === null || $rows === '' ) {
			return 0;
		}
		$decoded = json_decode( $rows, true );
		if ( is_numeric( $decoded ) ) {
			return (int) $decoded;
		}
		return (int) $rows;
	}

	/**
	 * Record current max log id so status only reflects this automation run.
	 *
	 * @param int    $job_id      Job ID.
	 * @param string $hash_key    Event hash.
	 * @param int    $schedule_id Schedule row ID.
	 */
	public static function prepare_fresh_run( $job_id, $hash_key, $schedule_id ) {
		global $wpdb;
		$baseline = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(id) FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s",
				$hash_key
			)
		);
		self::update_job(
			$job_id,
			array(
				'baseline_log_id' => $baseline,
				'status'          => self::STATUS_QUEUED,
				'processed_count' => 0,
				'total_count'     => self::get_expected_total_from_file( $hash_key ),
				'ended_at'        => null,
				'error_message'   => '',
			)
		);
		delete_option( 'smack_csv_page_number_' . absint( $schedule_id ) );
		delete_option( 'smack_csv_record_limit_' . absint( $schedule_id ) );
		update_option( 'smack_csv_page_number_' . absint( $schedule_id ), 0 );

		if ( class_exists( ImportResumeService::class ) ) {
			ImportResumeService::getInstance()->clear_row_progress_for_rerun( $hash_key );
		}
	}

	/**
	 * @param string $log_status import_detail_log status.
	 * @param string $current    Current job status.
	 * @return string
	 */
	private static function map_log_status( $log_status, $current ) {
		$log_status = strtolower( (string) $log_status );
		if ( $log_status === 'completed' ) {
			return self::STATUS_COMPLETED;
		}
		if ( strpos( $log_status, 'fail' ) !== false || $log_status === 'terminated' ) {
			return self::STATUS_FAILED;
		}
		if ( $log_status === 'processing' || $log_status === 'paused' ) {
			return self::STATUS_RUNNING;
		}
		return $current === self::STATUS_QUEUED ? self::STATUS_RUNNING : $current;
	}

	/**
	 * @param int                  $job_id Job ID.
	 * @param array<string, mixed> $fields Fields to update.
	 */
	public static function update_job( $job_id, $fields ) {
		global $wpdb;
		$allowed = array( 'status', 'processed_count', 'total_count', 'started_at', 'ended_at', 'error_message', 'schedule_id', 'hash_key', 'baseline_log_id' );
		$data    = array( 'updated_at' => current_time( 'mysql', 1 ) );
		$format  = array( '%s' );
		foreach ( $allowed as $key ) {
			if ( array_key_exists( $key, $fields ) ) {
				$data[ $key ] = $fields[ $key ];
				$format[]     = is_int( $fields[ $key ] ) ? '%d' : '%s';
			}
		}
		$wpdb->update( self::table_name(), $data, array( 'id' => absint( $job_id ) ), $format, array( '%d' ) );
	}

	/**
	 * @param int $job_id Job ID.
	 * @return array<string, mixed> REST status payload.
	 */
	public static function get_status_payload( $job_id ) {
		self::sync_progress_from_log( $job_id );
		$job = self::get_job( $job_id );
		if ( ! $job ) {
			return array();
		}
		$total     = (int) $job['total_count'];
		$processed = (int) $job['processed_count'];
		$percent   = $total > 0 ? (int) round( ( $processed / $total ) * 100 ) : 0;
		return array(
			'job_id'     => (string) $job['id'],
			'status'     => $job['status'],
			'processed'  => $processed,
			'total'      => $total,
			'percentage' => $percent,
		);
	}

	/**
	 * @param int    $job_id  Job ID.
	 * @param string $message Error text.
	 */
	public static function mark_failed( $job_id, $message = '' ) {
		self::update_job(
			$job_id,
			array(
				'status'        => self::STATUS_FAILED,
				'ended_at'      => current_time( 'mysql', 1 ),
				'error_message' => sanitize_text_field( $message ),
			)
		);
	}

	/** @var int Seconds before a queued job is treated as stuck. */
	const QUEUED_STALE_SECONDS = 90;

	/** @var int Seconds before a running job is treated as stuck. */
	const RUNNING_STALE_SECONDS = 2700;

	/**
	 * Fail automation jobs that never finished (cron missed, fatal error, etc.).
	 *
	 * @param string $hash_key Event hash.
	 */
	public static function release_stale_locks( $hash_key ) {
		global $wpdb;
		$hash_key = sanitize_key( $hash_key );
		if ( $hash_key === '' ) {
			return;
		}
		$table   = self::table_name();
		$now     = time();
		$pending = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, status, created_at, updated_at, started_at FROM {$table} WHERE hash_key = %s AND status IN ('queued','running')",
				$hash_key
			),
			ARRAY_A
		);
		if ( ! is_array( $pending ) ) {
			return;
		}
		foreach ( $pending as $row ) {
			$job_id    = (int) $row['id'];
			$status    = (string) $row['status'];
			$updated   = ! empty( $row['updated_at'] ) ? strtotime( $row['updated_at'] ) : 0;
			$created   = ! empty( $row['created_at'] ) ? strtotime( $row['created_at'] ) : 0;
			$reference = max( $updated, $created );
			$limit     = self::STATUS_RUNNING === $status ? self::RUNNING_STALE_SECONDS : self::QUEUED_STALE_SECONDS;
			if ( self::STATUS_QUEUED === $status && empty( $row['started_at'] ) ) {
				$limit = min( $limit, 60 );
			}
			if ( $reference > 0 && ( $now - $reference ) > $limit ) {
				self::mark_failed( $job_id, __( 'Timed out waiting for import worker.', 'wp-ultimate-csv-importer-pro' ) );
				delete_transient( 'uci_pro_auto_exec_' . $job_id );
				wp_clear_scheduled_hook( 'uci_pro_automation_execute', array( $job_id ) );
			}
		}
	}

	/**
	 * @param string $hash_key              Event hash.
	 * @param int    $queued_grace_seconds  Block if another job was queued within this window.
	 * @return bool
	 */
	public static function has_active_job( $hash_key, $queued_grace_seconds = 60 ) {
		global $wpdb;
		$hash_key = sanitize_key( $hash_key );
		if ( $hash_key === '' ) {
			return false;
		}
		$table = self::table_name();
		$running = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE hash_key = %s AND status = %s LIMIT 1",
				$hash_key,
				self::STATUS_RUNNING
			)
		);
		if ( ! empty( $running ) ) {
			return true;
		}
		$queued_grace_seconds = max( 30, (int) $queued_grace_seconds );
		$cutoff               = gmdate( 'Y-m-d H:i:s', time() - $queued_grace_seconds );
		$queued               = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE hash_key = %s AND status = %s AND created_at >= %s LIMIT 1",
				$hash_key,
				self::STATUS_QUEUED,
				$cutoff
			)
		);
		return ! empty( $queued );
	}

	/**
	 * @param int $job_id Job ID.
	 */
	public static function mark_running( $job_id ) {
		$job = self::get_job( $job_id );
		if ( $job && empty( $job['started_at'] ) ) {
			self::update_job(
				$job_id,
				array(
					'status'     => self::STATUS_RUNNING,
					'started_at' => current_time( 'mysql', 1 ),
				)
			);
		} else {
			self::update_job( $job_id, array( 'status' => self::STATUS_RUNNING ) );
		}
	}
}
