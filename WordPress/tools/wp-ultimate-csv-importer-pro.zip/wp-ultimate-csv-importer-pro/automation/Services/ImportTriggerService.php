<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\ScheduleExtension;
use Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Queues import runs via the same scheduler path as scheduled imports.
 */
class ImportTriggerService {

	const CRON_HOOK = 'uci_pro_automation_execute';

	/**
	 * Register cron handler once.
	 */
	public static function register_hooks() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'execute_job' ), 10, 1 );
	}

	/**
	 * @param int    $template_id Template ID.
	 * @param string $source      api|webhook.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function queue_import( $template_id, $source ) {
		$allowed = TemplateAutomationSettings::assert_trigger_allowed( $template_id, $source );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$template = TemplateAutomationSettings::get_template( $template_id );
		$hash_key = sanitize_key( $template['eventKey'] );

		if ( ! self::import_file_ready( $hash_key ) ) {
			return new \WP_Error(
				'import_not_ready',
				__( 'Import file or mapping session is not available for this template.', 'wp-ultimate-csv-importer-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( self::hash_is_busy( $hash_key ) ) {
			return new \WP_Error(
				'import_busy',
				__( 'An import is already running for this template session.', 'wp-ultimate-csv-importer-pro' ),
				array( 'status' => 409 )
			);
		}

		$schedule_id = self::create_ephemeral_schedule( $template_id, $template, $hash_key, $source );
		if ( ! $schedule_id ) {
			return new \WP_Error( 'queue_failed', __( 'Could not queue import.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 500 ) );
		}

		$job_id = AutomationJobService::create_job( $template_id, $source, $schedule_id );
		AutomationJobService::attach_hash_key( $job_id, $hash_key );
		AutomationJobService::prepare_fresh_run( $job_id, $hash_key, $schedule_id );

		self::dispatch_job( $job_id );

		/**
		 * Fires when an automation import job is queued.
		 *
		 * @param int    $job_id      Job ID.
		 * @param int    $template_id Template ID.
		 * @param string $source      Trigger source.
		 */
		do_action( 'uci_pro_automation_job_queued', $job_id, $template_id, $source );

		return array(
			'success' => true,
			'job_id'  => (string) $job_id,
			'status'  => AutomationJobService::STATUS_QUEUED,
		);
	}

	/**
	 * @param string $hash_key Event hash.
	 * @return bool
	 */
	private static function import_file_ready( $hash_key ) {
		global $wpdb;
		$file_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}smackcsv_file_events WHERE hash_key = %s LIMIT 1",
				$hash_key
			)
		);
		if ( ! $file_row ) {
			return false;
		}
		$upload_dir = UltimatePro::getInstance()->create_upload_dir();
		$path       = $upload_dir . $hash_key . '/' . $hash_key;
		return file_exists( $path );
	}

	/**
	 * @param string $hash_key Event hash.
	 * @return bool
	 */
	private static function hash_is_busy( $hash_key ) {
		AutomationJobService::release_stale_locks( $hash_key );

		if ( AutomationJobService::has_active_job( $hash_key ) ) {
			return true;
		}

		global $wpdb;
		$log_status = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT status FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);
		if ( $log_status && strtolower( (string) $log_status ) === 'processing' ) {
			if ( AutomationJobService::has_active_job( $hash_key, 30 ) ) {
				return true;
			}
			// Stale Processing log with no automation job — do not block API triggers.
			return false;
		}

		return false;
	}

	/**
	 * One-time schedule row consumed by ScheduleExtension::smack_uci_cron_scheduler / doSchedule.
	 *
	 * @param int                  $template_id Template ID.
	 * @param array<string, mixed> $template    Template row.
	 * @param string               $hash_key    Event key.
	 * @param string               $source      Trigger source.
	 * @return int Schedule ID or 0.
	 */
	private static function create_ephemeral_schedule( $template_id, $template, $hash_key, $source ) {
		global $wpdb;
		$table = $wpdb->prefix . 'sm_uci_addon_pro_scheduled_import';
		$now   = current_time( 'mysql', 0 );
		$date  = current_time( 'Y-m-d', 0 );
		$time  = current_time( 'H:i', 0 );
		$file  = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT file_name FROM {$wpdb->prefix}smackcsv_file_events WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);
		$file_type = 'csv';
		if ( $file && ! empty( $file->file_name ) ) {
			$ext = pathinfo( $file->file_name, PATHINFO_EXTENSION );
			if ( $ext ) {
				$file_type = sanitize_key( $ext );
			}
		}

		$wpdb->insert(
			$table,
			array(
				'templateid'          => absint( $template_id ),
				'importid'            => 0,
				'createdtime'         => $now,
				'scheduledtimetorun'  => $time,
				'scheduleddate'       => $date,
				'module'              => sanitize_text_field( $template['module'] ),
				'file_type'           => $file_type,
				'event_key'           => $hash_key,
				'importbymethod'      => 'automation_' . sanitize_key( $source ),
				'import_limit'        => 1,
				'frequency'           => 0,
				'nexrun'              => $now,
				'lastrun'             => $now,
				'scheduled_by_user'   => '0',
				'import_mode'         => 'Schedule',
				'duplicate_headers'   => '',
				'time_zone'           => function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : 'UTC',
				'cron_status'         => 'pending',
				'check_manage_filter' => 0,
				'isrun'               => 0,
			)
		);
		$schedule_id = (int) $wpdb->insert_id;
		if ( $schedule_id > 0 ) {
			$hook = 'smack_cron_schedule_function_' . $schedule_id;
			$wpdb->update( $table, array( 'hook_name' => $hook ), array( 'id' => $schedule_id ), array( '%s' ), array( '%d' ) );
		}
		return $schedule_id;
	}

	/**
	 * Queue WP-Cron and run import at end of request when cron is disabled (local dev).
	 *
	 * @param int $job_id Job ID.
	 */
	public static function dispatch_job( $job_id ) {
		$job_id = absint( $job_id );
		if ( ! wp_next_scheduled( self::CRON_HOOK, array( $job_id ) ) ) {
			wp_schedule_single_event( time(), self::CRON_HOOK, array( $job_id ) );
		}
		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
		add_action(
			'shutdown',
			static function () use ( $job_id ) {
				$job = AutomationJobService::get_job( $job_id );
				if ( ! $job || ! in_array( $job['status'], array( AutomationJobService::STATUS_QUEUED, AutomationJobService::STATUS_RUNNING ), true ) ) {
					return;
				}
				self::execute_job( $job_id );
			},
			999
		);
	}

	/**
	 * Cron callback: run one schedule batch via existing engine.
	 *
	 * @param int $job_id Job ID.
	 */
	public static function execute_job( $job_id ) {
		$job_id = absint( $job_id );
		$lock   = 'uci_pro_auto_exec_' . $job_id;
		if ( get_transient( $lock ) ) {
			return;
		}
		set_transient( $lock, 1, 120 );

		$job = AutomationJobService::get_job( $job_id );
		if ( ! $job ) {
			delete_transient( $lock );
			return;
		}

		AutomationJobService::mark_running( $job_id );

		global $wpdb;
		$schedule_id = (int) $job['schedule_id'];
		if ( $schedule_id <= 0 ) {
			AutomationJobService::mark_failed( $job_id, 'Missing schedule reference.' );
			delete_transient( $lock );
			return;
		}

		$schedule_table = $wpdb->prefix . 'sm_uci_addon_pro_scheduled_import';
		$row            = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$schedule_table} WHERE id = %d LIMIT 1", $schedule_id ),
			ARRAY_A
		);
		if ( ! $row ) {
			AutomationJobService::mark_failed( $job_id, 'Schedule row missing.' );
			delete_transient( $lock );
			return;
		}

		$wpdb->update(
			$schedule_table,
			array( 'isrun' => 1, 'cron_status' => 'initialized' ),
			array( 'id' => $schedule_id ),
			array( '%d', '%s' ),
			array( '%d' )
		);

		$data = array(
			'id'                  => $schedule_id,
			'eventkey'            => $row['event_key'],
			'duplicate_headers'   => $row['duplicate_headers'],
			'manage_filter_check' => ! empty( $row['check_manage_filter'] ),
			'frequency'           => (int) $row['frequency'],
			'lastrun'             => $row['lastrun'],
			'nexrun'              => $row['nexrun'],
			'import_mode'         => $row['import_mode'],
			'scheduleddate'       => $row['scheduleddate'],
			'scheduledtimetorun'  => $row['scheduledtimetorun'],
			'scheduled_by_user'   => $row['scheduled_by_user'],
			'automation_rerun'    => true,
		);

		$extension = ScheduleExtension::getInstance();
		$extension->doSchedule( $data, current_time( 'mysql', 0 ) );

		$cron_status = $wpdb->get_var(
			$wpdb->prepare( "SELECT cron_status FROM {$schedule_table} WHERE id = %d", $schedule_id )
		);
		AutomationJobService::sync_progress_from_log( $job_id );

		$job_after = AutomationJobService::get_job( $job_id );
		$has_new_log = false;
		if ( $job_after && ! empty( $job_after['hash_key'] ) ) {
			$baseline = (int) $job_after['baseline_log_id'];
			$new_log  = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s AND id > %d LIMIT 1",
					$job_after['hash_key'],
					$baseline
				)
			);
			$has_new_log = ! empty( $new_log );
		}

		if ( strtolower( (string) $cron_status ) === 'completed' && $has_new_log ) {
			AutomationJobService::update_job(
				$job_id,
				array(
					'status'   => AutomationJobService::STATUS_COMPLETED,
					'ended_at' => current_time( 'mysql', 1 ),
				)
			);
			$wpdb->update(
				$schedule_table,
				array( 'isrun' => 0, 'cron_status' => 'completed' ),
				array( 'id' => $schedule_id ),
				array( '%d', '%s' ),
				array( '%d' )
			);
			delete_transient( $lock );
			wp_clear_scheduled_hook( self::CRON_HOOK, array( $job_id ) );
			return;
		}

		if ( strtolower( (string) $cron_status ) === 'failed' ) {
			AutomationJobService::mark_failed( $job_id, 'Scheduled import failed.' );
			$wpdb->update(
				$schedule_table,
				array( 'isrun' => 0 ),
				array( 'id' => $schedule_id ),
				array( '%d' ),
				array( '%d' )
			);
			delete_transient( $lock );
			return;
		}

		delete_transient( $lock );
		if ( ! wp_next_scheduled( self::CRON_HOOK, array( $job_id ) ) ) {
			wp_schedule_single_event( time() + 30, self::CRON_HOOK, array( $job_id ) );
		}
	}
}
