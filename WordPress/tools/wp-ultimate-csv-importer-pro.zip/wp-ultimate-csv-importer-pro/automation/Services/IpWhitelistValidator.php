<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IPv4 single-IP and CIDR matching for automation endpoints.
 */
class IpWhitelistValidator {

	/**
	 * @param string $raw Multiline or comma-separated list.
	 * @return array<int, string> Normalized entries.
	 */
	public static function parse_list( $raw ) {
		$raw   = str_replace( array( "\r\n", "\r", "\n" ), ',', (string) $raw );
		$parts = array_map( 'trim', explode( ',', $raw ) );
		$out   = array();
		foreach ( $parts as $part ) {
			if ( $part !== '' ) {
				$out[] = $part;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * @param string $entry Single IP or CIDR.
	 * @return bool
	 */
	public static function is_valid_entry( $entry ) {
		$entry = trim( (string) $entry );
		if ( $entry === '' ) {
			return false;
		}
		if ( strpos( $entry, '/' ) !== false ) {
			return self::is_valid_cidr( $entry );
		}
		return (bool) filter_var( $entry, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
	}

	/**
	 * @param array<int, string> $entries
	 * @return bool
	 */
	public static function validate_all( $entries ) {
		foreach ( $entries as $entry ) {
			if ( ! self::is_valid_entry( $entry ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Empty whitelist = allow all (when automation IP check is enabled but list empty).
	 *
	 * @param string               $client_ip IPv4 address.
	 * @param array<int, string>   $whitelist Parsed entries.
	 * @return bool
	 */
	public static function is_allowed( $client_ip, $whitelist ) {
		if ( empty( $whitelist ) ) {
			return true;
		}
		$client_ip = trim( (string) $client_ip );
		if ( ! filter_var( $client_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return false;
		}
		$client_long = ip2long( $client_ip );
		if ( false === $client_long ) {
			return false;
		}
		foreach ( $whitelist as $entry ) {
			if ( strpos( $entry, '/' ) !== false ) {
				if ( self::ip_in_cidr( $client_long, $entry ) ) {
					return true;
				}
			} elseif ( $client_ip === $entry ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param string $ip Request IP.
	 * @return string
	 */
	public static function resolve_client_ip( $ip = '' ) {
		if ( $ip !== '' && filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return $ip;
		}
		$candidates = array();
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$xff = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			foreach ( explode( ',', $xff ) as $part ) {
				$candidates[] = trim( $part );
			}
		}
		if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$candidates[] = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		foreach ( $candidates as $candidate ) {
			if ( filter_var( $candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/**
	 * @param string $cidr e.g. 10.0.0.0/24
	 * @return bool
	 */
	private static function is_valid_cidr( $cidr ) {
		$parts = explode( '/', $cidr, 2 );
		if ( count( $parts ) !== 2 ) {
			return false;
		}
		$ip   = trim( $parts[0] );
		$mask = trim( $parts[1] );
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return false;
		}
		if ( ! ctype_digit( $mask ) ) {
			return false;
		}
		$mask_int = (int) $mask;
		return $mask_int >= 0 && $mask_int <= 32;
	}

	/**
	 * @param int    $client_long ip2long result (unsigned).
	 * @param string $cidr        IPv4 CIDR.
	 * @return bool
	 */
	private static function ip_in_cidr( $client_long, $cidr ) {
		list( $subnet, $bits ) = explode( '/', $cidr, 2 );
		$subnet_long = ip2long( $subnet );
		$bits        = (int) $bits;
		if ( false === $subnet_long || $bits < 0 || $bits > 32 ) {
			return false;
		}
		$mask = -1 << ( 32 - $bits );
		$mask = $mask & 0xFFFFFFFF;
		return ( $client_long & $mask ) === ( $subnet_long & $mask );
	}
}
