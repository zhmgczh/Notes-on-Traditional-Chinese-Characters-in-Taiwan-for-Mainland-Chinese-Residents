<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\Automation\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\CredentialCipher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-import-template automation settings stored in mappingtemplate.automation_settings.
 */
class TemplateAutomationSettings {

	/**
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		return array(
			'enable_api_trigger' => false,
			'enable_webhook'     => false,
			'webhook_secret'     => '',
			'allowed_ips'        => '',
		);
	}

	/**
	 * @param int $template_id Mapping template ID.
	 * @return array<string, mixed>|null Template row fields or null.
	 */
	public static function get_template( $template_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, templatename, module, eventKey, automation_settings FROM {$table} WHERE id = %d LIMIT 1",
				absint( $template_id )
			),
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * @param int $template_id Template ID.
	 * @return array<string, mixed>
	 */
	public static function get_settings( $template_id ) {
		$template = self::get_template( $template_id );
		if ( ! $template ) {
			return self::defaults();
		}
		$stored = array();
		if ( ! empty( $template['automation_settings'] ) ) {
			$decoded = json_decode( $template['automation_settings'], true );
			if ( is_array( $decoded ) ) {
				$stored = $decoded;
			}
		}
		$settings = array_merge( self::defaults(), $stored );
		if ( ! empty( $settings['webhook_secret_enc'] ) ) {
			$settings['webhook_secret'] = CredentialCipher::decrypt( $settings['webhook_secret_enc'] );
			unset( $settings['webhook_secret_enc'] );
		}
		return $settings;
	}

	/**
	 * Settings for admin display (secret masked).
	 *
	 * @param int $template_id Template ID.
	 * @return array<string, mixed>
	 */
	public static function get_settings_for_display( $template_id ) {
		$settings = self::get_settings( $template_id );
		if ( ! empty( $settings['webhook_secret'] ) ) {
			$settings['webhook_secret'] = '';
			$settings['webhook_secret_set'] = true;
		} else {
			$settings['webhook_secret_set'] = false;
		}
		return $settings;
	}

	/**
	 * @param int                  $template_id Template ID.
	 * @param array<string, mixed> $input       Raw input.
	 * @return true|\WP_Error
	 */
	public static function save_settings( $template_id, $input ) {
		global $wpdb;
		$template = self::get_template( $template_id );
		if ( ! $template ) {
			return new \WP_Error( 'template_not_found', __( 'Template not found.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 404 ) );
		}

		$allowed_ips_raw = isset( $input['allowed_ips'] ) ? sanitize_textarea_field( $input['allowed_ips'] ) : '';
		$entries         = IpWhitelistValidator::parse_list( $allowed_ips_raw );
		if ( $allowed_ips_raw !== '' && ! IpWhitelistValidator::validate_all( $entries ) ) {
			return new \WP_Error( 'invalid_ip_list', __( 'Invalid IP or CIDR in allowed IPs list.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 400 ) );
		}

		$current = self::get_settings( $template_id );
		$secret  = $current['webhook_secret'];
		if ( ! empty( $input['webhook_secret'] ) ) {
			$secret = self::normalize_webhook_secret( $input['webhook_secret'] );
		} elseif ( ! empty( $input['regenerate_webhook_secret'] ) ) {
			$secret = wp_generate_password( 48, true, true );
		}

		$payload = array(
			'enable_api_trigger' => ! empty( $input['enable_api_trigger'] ),
			'enable_webhook'     => ! empty( $input['enable_webhook'] ),
			'allowed_ips'        => $allowed_ips_raw,
		);
		if ( $secret !== '' ) {
			$payload['webhook_secret_enc'] = CredentialCipher::encrypt( $secret );
		}

		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$wpdb->update(
			$table,
			array( 'automation_settings' => wp_json_encode( $payload ) ),
			array( 'id' => absint( $template_id ) ),
			array( '%s' ),
			array( '%d' )
		);

		return true;
	}

	/**
	 * Preserve special characters in generated webhook secrets.
	 *
	 * @param mixed $value Raw secret.
	 * @return string
	 */
	private static function normalize_webhook_secret( $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			return '';
		}
		return trim( (string) wp_unslash( $value ) );
	}

	/**
	 * @param int $template_id Template ID.
	 * @return true|\WP_Error
	 */
	public static function assert_import_template( $template_id ) {
		global $wpdb;
		$template = self::get_template( $template_id );
		if ( ! $template ) {
			return new \WP_Error( 'template_not_found', __( 'Import template not found.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 404 ) );
		}
		$export_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}sm_uci_addon_pro_export_template WHERE id = %d LIMIT 1",
				absint( $template_id )
			)
		);
		if ( $export_id ) {
			return new \WP_Error( 'invalid_template', __( 'Template is not an import template.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 400 ) );
		}
		$module = isset( $template['module'] ) ? trim( (string) $template['module'] ) : '';
		if ( $module === '' ) {
			return new \WP_Error( 'invalid_template', __( 'Template has no import module.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 400 ) );
		}
		$event_key = isset( $template['eventKey'] ) ? sanitize_key( $template['eventKey'] ) : '';
		if ( $event_key === '' ) {
			return new \WP_Error( 'invalid_template', __( 'Template is not linked to an import file session.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 400 ) );
		}
		return true;
	}

	/**
	 * @param int    $template_id Template ID.
	 * @param string $source      api|webhook.
	 * @return true|\WP_Error
	 */
	public static function assert_trigger_allowed( $template_id, $source ) {
		$check = self::assert_import_template( $template_id );
		if ( is_wp_error( $check ) ) {
			return $check;
		}
		$settings = self::get_settings( $template_id );
		if ( $source === 'api' && empty( $settings['enable_api_trigger'] ) ) {
			return new \WP_Error( 'api_disabled', __( 'API trigger is disabled for this template.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 403 ) );
		}
		if ( $source === 'webhook' && empty( $settings['enable_webhook'] ) ) {
			return new \WP_Error( 'webhook_disabled', __( 'Webhook is disabled for this template.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 403 ) );
		}
		$entries = IpWhitelistValidator::parse_list( isset( $settings['allowed_ips'] ) ? $settings['allowed_ips'] : '' );
		if ( ! IpWhitelistValidator::is_allowed( IpWhitelistValidator::resolve_client_ip(), $entries ) ) {
			return new \WP_Error( 'ip_denied', __( 'Request IP is not allowed.', 'wp-ultimate-csv-importer-pro' ), array( 'status' => 403 ) );
		}
		return true;
	}
}
