<?php 

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (! defined('ABSPATH')) {
    exit;
}

// Load real hooks when hook_system ON; stub classes when OFF (#1442 Phase 4 Task 4.1).
if ( FeatureRegistry::is_enabled( 'hook_system' ) ) {
	require_once __DIR__ . '/hooks/Import/Actions.php';
	require_once __DIR__ . '/hooks/Import/Filters.php';
	require_once __DIR__ . '/hooks/Export/Actions.php';
	require_once __DIR__ . '/hooks/Export/Filters.php';
} else {
	require_once __DIR__ . '/includes/HooksHandlerStub.php';
}

/**
 * Class HooksHandler
 * Main entry point for accessing specialized hook handlers.
 */
class HooksHandler {
    
    private static $instance = null;

    private function __construct() {}

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new HooksHandler();
        }
        return self::$instance;
    }



    /**
     * Get the Import Actions handler.
     * @return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Actions
     */
    public function importActions() {
        return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Actions::getInstance();
    }

    /**
     * Get the Import Filters handler.
     * @return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Filters
     */
    public function importFilters() {
        return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Filters::getInstance();
    }

    /**
     * Get the Export Actions handler.
     * @return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export\Actions
     */
    public function exportActions() {
        return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export\Actions::getInstance();
    }

    /**
     * Get the Export Filters handler.
     * @return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export\Filters
     */
    public function exportFilters() {
        return \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Export\Filters::getInstance();
    }

}

// Initialize the import and export hook singletons early so their WP actions/filters are registered
add_action('plugins_loaded', function() {
    HooksHandler::getInstance()->importActions();
    HooksHandler::getInstance()->importFilters();
    HooksHandler::getInstance()->exportActions();
    HooksHandler::getInstance()->exportFilters();
});
