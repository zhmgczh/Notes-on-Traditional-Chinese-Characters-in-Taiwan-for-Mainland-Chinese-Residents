<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

if (class_exists('\Smackcoders\UCI\Proaddons\UltimatePro\ExportExtension')) {
	class ImageFileExport
	{
		const DEFAULT_ALLOWED_EXTENSIONS = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg');

		/** @var ImageFileExport|null */
		protected static $instance = null;

		/** @var ExportExtension|null */
		protected static $export_instance = null;

		public static function getInstance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
				self::$export_instance = ExportExtension::getInstance();
			}
			return self::$instance;
		}

		/**
		 * Export actual image files into a ZIP archive using the same filters as CSV export.
		 */
		public function exportImageFiles($module, $optionalType, $conditions, $offset, $limit, $is_filter, $headers, $mode, $eventExclusions)
		{
			$export = self::$export_instance;
			$image_ids = PostExport::getInstance()->getRecordsBasedOnPostTypes(
				$export->module,
				$export->optionalType,
				$export->conditions,
				$export->offset,
				$export->limit,
				'',
				''
			);

			if ($is_filter === 'filter_action') {
				return $this->buildFilterPreviewRows($image_ids, $headers);
			}

			if (empty($image_ids)) {
				if ($mode == null) {
					return $this->proceedImageFilesExport(array());
				}
				return array();
			}

			$is_preview = isset($_POST['isPreview']) && sanitize_text_field(wp_unslash($_POST['isPreview'])) === 'true';
			if ($is_preview) {
				$this->sendImageFilesPreviewResponse($image_ids);
			}

			if ($mode == null) {
				return $this->proceedImageFilesExport($image_ids);
			}

			return $this->buildFilterPreviewRows($image_ids, $headers);
		}

		/**
		 * @param array<int|string> $image_ids
		 * @return array<int, array<string, mixed>>
		 */
		protected function buildFilterPreviewRows($image_ids, $headers)
		{
			$rows = array();
			if (empty($image_ids)) {
				return $rows;
			}

			foreach ($image_ids as $id) {
				$id = (int) $id;
				$attachment = get_post($id);
				if (!$attachment) {
					continue;
				}

				$row = array();
				if (in_array('media_id', $headers, true)) {
					$row['media_id'] = $id;
				}
				if (in_array('caption', $headers, true)) {
					$row['caption'] = wp_get_attachment_caption($id) ?: '';
				}
				if (in_array('alt_text', $headers, true)) {
					$row['alt_text'] = get_post_meta($id, '_wp_attachment_image_alt', true) ?: '';
				}
				if (in_array('description', $headers, true)) {
					$row['description'] = $attachment->post_content ?: '';
				}
				if (in_array('file_name', $headers, true)) {
					$row['file_name'] = basename((string) get_attached_file($id)) ?: '';
				}
				if (in_array('title', $headers, true)) {
					$row['title'] = $attachment->post_title ?: '';
				}
				if (in_array('actual_url', $headers, true)) {
					$row['actual_url'] = wp_get_attachment_url($id) ?: '';
				}
				$rows[$id] = $row;
			}

			return self::$export_instance->finalDataToExport($rows);
		}

		/**
		 * @param array<int|string> $image_ids
		 */
		protected function proceedImageFilesExport($image_ids)
		{
			$export = self::$export_instance;

			try {
				if (!class_exists('ZipArchive')) {
					$this->sendImageFilesErrorResponse(__('ZipArchive is not available on this server.', 'wp-ultimate-csv-importer'), 'ziparchive_missing');
				}

				$paths = $this->getExportPaths();
				$state = $this->loadExportState($paths['state_path']);

				if ((int) $export->offset === 0) {
					$this->resetImageFilesExportArtifacts($paths);
					$state = $this->getDefaultExportState();
				}

				$zip_result = $this->addImagesToZip($paths['zip_path'], $image_ids, $state);
				if (is_wp_error($zip_result)) {
					$this->sendImageFilesErrorResponse($zip_result->get_error_message(), $zip_result->get_error_code());
				}

				$this->saveExportState($paths['state_path'], $state);
				$this->fireExportedAttachmentActions($image_ids);

				$export->offset = (int) $export->offset + (int) $export->limit;
				$is_complete = ((int) $export->offset) >= (int) $export->totalRowCount;

				if ($is_complete) {
					$this->finalizeImageFilesZip($paths, $state);
					$export->ClearedOptions();
					$this->sendImageFilesResponse(true, $paths['zip_url'], $paths['zip_path'], array(
						'status' => 'completed',
						'added_files' => (int) $state['added_count'],
						'skipped_files' => count($state['skipped']),
					));
					return;
				}

				$this->sendImageFilesResponse(false, '', $paths['zip_path'], array(
					'status' => 'in_progress',
					'added_files' => (int) $state['added_count'],
					'skipped_files' => count($state['skipped']),
				));
			} catch (\Throwable $e) {
				$this->sendImageFilesErrorResponse(
					__('Image file export failed unexpectedly.', 'wp-ultimate-csv-importer'),
					'batch_processing_exception'
				);
			}
		}

		/**
		 * @return array{upload_dir:string,upload_url:string,zip_path:string,zip_url:string,state_path:string,skipped_log_path:string}
		 */
		protected function getExportPaths()
		{
			$export = self::$export_instance;
			$upload_dir = WP_CONTENT_DIR . '/uploads/smack_uci_uploads/exports/';

			if (!is_dir($upload_dir)) {
				wp_mkdir_p($upload_dir);
			}

			$index_file = $upload_dir . 'index.php';
			if (!file_exists($index_file)) {
				@file_put_contents($index_file, '<?php' . PHP_EOL . '?>');
			}

			if (is_multisite()) {
				$upload_url = network_home_url() . '/wp-content/uploads/smack_uci_uploads/exports/';
			} else {
				$upload_url = trailingslashit(content_url('/uploads/smack_uci_uploads/exports', 'https'));
			}

			$zip_filename = sanitize_file_name($export->fileName) . '.zip';
			$state_filename = sanitize_file_name($export->fileName) . '.image-export-state.json';

			return array(
				'upload_dir' => $upload_dir,
				'upload_url' => $upload_url,
				'zip_path' => $upload_dir . $zip_filename,
				'zip_url' => $upload_url . $zip_filename,
				'state_path' => $upload_dir . $state_filename,
				'skipped_log_path' => $upload_dir . sanitize_file_name($export->fileName) . '.image-export-skipped.log',
			);
		}

		/**
		 * @param array{upload_dir:string,upload_url:string,zip_path:string,zip_url:string,state_path:string,skipped_log_path:string} $paths
		 */
		protected function resetImageFilesExportArtifacts($paths)
		{
			foreach (array($paths['zip_path'], $paths['state_path'], $paths['skipped_log_path']) as $file) {
				if (!empty($file) && file_exists($file)) {
					wp_delete_file($file);
				}
			}
		}

		/**
		 * @return array{used_names:array<string,int>,skipped:array<int,array<string,mixed>>,added_count:int}
		 */
		protected function getDefaultExportState()
		{
			return array(
				'used_names' => array(),
				'skipped' => array(),
				'added_count' => 0,
			);
		}

		/**
		 * @return array{used_names:array<string,int>,skipped:array<int,array<string,mixed>>,added_count:int}
		 */
		protected function loadExportState($state_path)
		{
			if (!file_exists($state_path)) {
				return $this->getDefaultExportState();
			}

			$raw = file_get_contents($state_path);
			if (empty($raw)) {
				return $this->getDefaultExportState();
			}

			$decoded = json_decode($raw, true);
			if (!is_array($decoded)) {
				return $this->getDefaultExportState();
			}

			return wp_parse_args($decoded, $this->getDefaultExportState());
		}

		/**
		 * @param array{used_names:array<string,int>,skipped:array<int,array<string,mixed>>,added_count:int} $state
		 */
		protected function saveExportState($state_path, $state)
		{
			@file_put_contents($state_path, wp_json_encode($state), LOCK_EX);
		}

		/**
		 * @param array<int|string> $image_ids
		 * @param array{used_names:array<string,int>,skipped:array<int,array<string,mixed>>,added_count:int} $state
		 * @return true|\WP_Error
		 */
		protected function addImagesToZip($zip_path, $image_ids, &$state)
		{
			$zip = new \ZipArchive();
			$flags = file_exists($zip_path) ? \ZipArchive::CREATE : (\ZipArchive::CREATE | \ZipArchive::OVERWRITE);
			$opened = $zip->open($zip_path, $flags);

			if (true !== $opened) {
				$error_message = $this->getZipArchiveErrorMessage($opened);
				return new \WP_Error(
					'zip_open_failed',
					sprintf(
						/* translators: %s: ZIP error details */
						__('Unable to create image export ZIP archive. %s', 'wp-ultimate-csv-importer'),
						$error_message
					)
				);
			}

			foreach ($image_ids as $attachment_id) {
				$attachment_id = (int) $attachment_id;
				if ($attachment_id <= 0) {
					continue;
				}

				$file_path = $this->resolveAttachmentFilePath($attachment_id);
				if (is_wp_error($file_path)) {
					$state['skipped'][] = array(
						'attachment_id' => $attachment_id,
						'reason' => $file_path->get_error_message(),
						'error_code' => $file_path->get_error_code(),
						'path' => (string) get_attached_file($attachment_id),
					);
					continue;
				}

				$entry_name = $this->buildZipEntryName($file_path, $attachment_id, $state['used_names']);
				$entry_name = apply_filters('sm_uci_pro_image_file_export_zip_entry_name', $entry_name, $attachment_id, $file_path);

				if (!$zip->addFile($file_path, $entry_name)) {
					$state['skipped'][] = array(
						'attachment_id' => $attachment_id,
						'reason' => __('Failed to add file to ZIP archive.', 'wp-ultimate-csv-importer'),
						'error_code' => 'zip_add_file_failed',
						'path' => $file_path,
					);
					continue;
				}

				$state['added_count']++;
			}

			if (!$zip->close()) {
				return new \WP_Error(
					'zip_close_failed',
					__('Unable to finalize image export ZIP archive.', 'wp-ultimate-csv-importer')
				);
			}

			return true;
		}

		/**
		 * @param int $code
		 * @return string
		 */
		protected function getZipArchiveErrorMessage($code)
		{
			$code = (int) $code;
			$messages = array(
				\ZipArchive::ER_OK => 'No error',
				\ZipArchive::ER_MULTIDISK => 'Multi-disk zip archives not supported',
				\ZipArchive::ER_RENAME => 'Renaming temporary file failed',
				\ZipArchive::ER_CLOSE => 'Closing zip archive failed',
				\ZipArchive::ER_SEEK => 'Seek error',
				\ZipArchive::ER_READ => 'Read error',
				\ZipArchive::ER_WRITE => 'Write error',
				\ZipArchive::ER_CRC => 'CRC error',
				\ZipArchive::ER_ZIPCLOSED => 'Containing zip archive was closed',
				\ZipArchive::ER_NOENT => 'No such file',
				\ZipArchive::ER_EXISTS => 'File already exists',
				\ZipArchive::ER_OPEN => 'Can not open file',
				\ZipArchive::ER_TMPOPEN => 'Failure to create temporary file',
				\ZipArchive::ER_ZLIB => 'Zlib error',
				\ZipArchive::ER_MEMORY => 'Memory allocation failure',
				\ZipArchive::ER_CHANGED => 'Entry has been changed',
				\ZipArchive::ER_COMPNOTSUPP => 'Compression method not supported',
				\ZipArchive::ER_EOF => 'Premature EOF',
				\ZipArchive::ER_INVAL => 'Invalid argument',
				\ZipArchive::ER_NOZIP => 'Not a zip archive',
				\ZipArchive::ER_INTERNAL => 'Internal error',
				\ZipArchive::ER_INCONS => 'Zip archive inconsistent',
				\ZipArchive::ER_REMOVE => 'Can not remove file',
				\ZipArchive::ER_DELETED => 'Entry has been deleted',
			);

			if (isset($messages[$code])) {
				return $messages[$code] . ' (code ' . $code . ')';
			}

			return 'Unknown ZIP error (code ' . $code . ')';
		}

		/**
		 * @return string|\WP_Error
		 */
		protected function resolveAttachmentFilePath($attachment_id)
		{
			$attached_file = get_attached_file($attachment_id);
			if (empty($attached_file)) {
				return new \WP_Error('missing_attached_file', __('Attachment file path is missing.', 'wp-ultimate-csv-importer'));
			}

			$real_file = realpath($attached_file);
			if (false === $real_file || !is_file($real_file) || !is_readable($real_file)) {
				return new \WP_Error(
					'missing_file',
					sprintf(
						/* translators: 1: attachment ID, 2: file path */
						__('Attachment #%1$d file does not exist or is not readable. Path: %2$s', 'wp-ultimate-csv-importer'),
						$attachment_id,
						$attached_file
					)
				);
			}

			if (!$this->isPathInsideUploads($real_file)) {
				return new \WP_Error('invalid_path', __('Attachment file path is outside the uploads directory.', 'wp-ultimate-csv-importer'));
			}

			$extension = strtolower(pathinfo($real_file, PATHINFO_EXTENSION));
			$allowed_extensions = apply_filters(
				'sm_uci_pro_image_file_export_allowed_extensions',
				self::DEFAULT_ALLOWED_EXTENSIONS,
				$attachment_id,
				$real_file
			);

			if (!in_array($extension, array_map('strtolower', (array) $allowed_extensions), true)) {
				return new \WP_Error(
					'unsupported_extension',
					sprintf(
						/* translators: %s: file extension */
						__('Unsupported image file extension: %s', 'wp-ultimate-csv-importer'),
						$extension
					)
				);
			}

			$checked = wp_check_filetype_and_ext($real_file, basename($real_file));
			if (!empty($checked['ext']) && !in_array(strtolower($checked['ext']), array_map('strtolower', (array) $allowed_extensions), true)) {
				return new \WP_Error('invalid_file_type', __('Attachment file type is not allowed for export.', 'wp-ultimate-csv-importer'));
			}

			return $real_file;
		}

		protected function isPathInsideUploads($real_file)
		{
			$upload_dir = wp_upload_dir();
			$base_dir = !empty($upload_dir['basedir']) ? realpath($upload_dir['basedir']) : false;
			if (!$base_dir) {
				return false;
			}

			$normalized_file = wp_normalize_path($real_file);
			$normalized_base = wp_normalize_path($base_dir);

			return strpos($normalized_file, trailingslashit($normalized_base)) === 0;
		}

		/**
		 * @param array<string,int> $used_names
		 */
		protected function buildZipEntryName($file_path, $attachment_id, &$used_names)
		{
			$basename = sanitize_file_name(basename($file_path));
			if ('' === $basename) {
				$basename = 'attachment-' . $attachment_id;
			}

			$entry_name = 'uploads/' . $basename;
			if (!isset($used_names[$entry_name])) {
				$used_names[$entry_name] = 1;
				return $entry_name;
			}

			$path_info = pathinfo($basename);
			$filename = $path_info['filename'] ?? $basename;
			$extension = isset($path_info['extension']) ? '.' . $path_info['extension'] : '';
			$entry_name = 'uploads/' . sanitize_file_name($filename . '_' . $attachment_id . $extension);
			$used_names[$entry_name] = 1;

			return $entry_name;
		}

		/**
		 * @param array{upload_dir:string,upload_url:string,zip_path:string,zip_url:string,state_path:string,skipped_log_path:string} $paths
		 * @param array{used_names:array<string,int>,skipped:array<int,array<string,mixed>>,added_count:int} $state
		 */
		protected function finalizeImageFilesZip($paths, $state)
		{
			$this->writeSkippedLog($paths['skipped_log_path'], $state['skipped']);

			if (!empty($state['skipped']) && file_exists($paths['skipped_log_path'])) {
				$zip = new \ZipArchive();
				if (true === $zip->open($paths['zip_path'], \ZipArchive::CREATE)) {
					$zip->addFile($paths['skipped_log_path'], 'export-skipped.log');
					$zip->close();
				}
			}

			$this->cleanupTempFiles($paths);
		}

		/**
		 * @param array{upload_dir:string,upload_url:string,zip_path:string,zip_url:string,state_path:string,skipped_log_path:string} $paths
		 */
		protected function cleanupTempFiles($paths)
		{
			foreach (array($paths['state_path'], $paths['skipped_log_path']) as $file) {
				if (!empty($file) && file_exists($file)) {
					wp_delete_file($file);
				}
			}
		}

		/**
		 * @param array<int,array<string,mixed>> $skipped
		 */
		protected function writeSkippedLog($log_path, $skipped)
		{
			if (empty($skipped)) {
				return;
			}

			$lines = array('attachment_id,reason,path');
			foreach ($skipped as $entry) {
				$lines[] = sprintf(
					'%d,"%s","%s"',
					(int) ($entry['attachment_id'] ?? 0),
					str_replace('"', '""', (string) ($entry['reason'] ?? '')),
					str_replace('"', '""', (string) ($entry['path'] ?? ''))
				);
			}

			@file_put_contents($log_path, implode(PHP_EOL, $lines) . PHP_EOL, LOCK_EX);
		}

		/**
		 * @param array<int|string> $image_ids
		 */
		protected function fireExportedAttachmentActions($image_ids)
		{
			$export = self::$export_instance;
			$is_preview = isset($_POST['isPreview']) && sanitize_text_field(wp_unslash($_POST['isPreview'])) === 'true';
			if ($is_preview || empty($image_ids)) {
				return;
			}

			foreach ($image_ids as $attachment_id) {
				$attachment_id = (int) $attachment_id;
				if ($attachment_id > 0) {
					\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->exportActions()->fire_exported_post($attachment_id, $export);
				}
			}
		}

		/**
		 * @param array<int|string> $image_ids
		 */
		protected function sendImageFilesPreviewResponse($image_ids)
		{
			$preview = array();
			$slice = array_slice((array) $image_ids, 0, 10);

			foreach ($slice as $attachment_id) {
				$attachment_id = (int) $attachment_id;
				$file_path = get_attached_file($attachment_id);
				$status = 'ok';
				$reason = '';

				$resolved = $this->resolveAttachmentFilePath($attachment_id);
				if (is_wp_error($resolved)) {
					$status = 'skipped';
					$reason = $resolved->get_error_message();
				}

				$preview[] = array(
					'attachment_id' => $attachment_id,
					'file_name' => $file_path ? basename($file_path) : '',
					'status' => $status,
					'reason' => $reason,
				);
			}

			header('Content-Type: application/json; charset=utf-8');
			echo wp_json_encode($preview, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
			wp_die();
		}

		protected function sendImageFilesResponse($success, $exported_file_url, $exported_path, $extra = array())
		{
			$export = self::$export_instance;
			$response = array_merge(
				array(
					'success' => (bool) $success,
					'new_offset' => (int) $export->offset,
					'limit' => (int) $export->limit,
					'total_row_count' => (int) $export->totalRowCount,
					'exported_file' => $exported_file_url,
					'exported_path' => $exported_path,
					'export_type' => 'zip',
					'image_export_mode' => 'files',
				),
				$extra
			);

			if (!$success) {
				$response['status'] = $response['status'] ?? 'in_progress';
			}

			if ($success) {
				$export_obj = $export;
				$export_obj->options = array(
					'filepath' => $exported_path,
					'filename' => $export->fileName,
					'records' => (int) $export->totalRowCount,
					'filesize' => (!empty($exported_path) && file_exists($exported_path)) ? filesize($exported_path) : 0,
				);
				\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->exportActions()->fire_after_export($export->export_id, $export_obj);
			}

			echo wp_json_encode($response);
			wp_die();
		}

		protected function sendImageFilesErrorResponse($message, $error_code = 'export_failed')
		{
			$export = self::$export_instance;

			echo wp_json_encode(
				array(
					'success' => false,
					'error' => true,
					'status' => 'failed',
					'new_offset' => (int) $export->offset,
					'limit' => (int) $export->limit,
					'total_row_count' => (int) $export->totalRowCount,
					'message' => (string) $message,
					'error_code' => (string) $error_code,
					'image_export_mode' => 'files',
				)
			);
			wp_die();
		}
	}
}
