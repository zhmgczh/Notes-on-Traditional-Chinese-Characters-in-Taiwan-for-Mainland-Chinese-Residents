<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class BricksExport {

	private static $instance = null;

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new BricksExport();
		}
		return self::$instance;
	}

	public function bricks_data_export($meta_value) {
		$bricks_data = maybe_unserialize($meta_value);
		if (empty($bricks_data)) return '';

		// Replace local URLs with placeholders for portability
		$site_url = get_site_url();
		if (is_array($bricks_data)) {
			$bricks_data = $this->prepare_data_for_export($bricks_data);
			$bricks_data_json = wp_json_encode($bricks_data);
		} else {
			$bricks_data_json = $bricks_data;
		}
		
		if (!empty($bricks_data_json)) {
			$bricks_data_json = str_replace($site_url, '{{SITE_URL}}', $bricks_data_json);
		}

		return base64_encode($bricks_data_json);
	}

	private function prepare_data_for_export($data) {
		if (is_array($data) && isset($data[0]) && is_array($data[0])) {
			$this->inline_bricks_templates($data);
		}

		if (is_array($data)) {
			// Handle internal links
			if (isset($data['type']) && $data['type'] === 'internal' && !empty($data['id']) && is_numeric($data['id'])) {
				$post = get_post($data['id']);
				if ($post) {
					$data['smack_post_title'] = $post->post_title;
				}
			}

			// Handle query loop include/exclude arrays
			if (isset($data['query']) && is_array($data['query'])) {
				if (isset($data['query']['include']) && is_array($data['query']['include'])) {
					$titles = [];
					foreach ($data['query']['include'] as $pid) {
						$p = get_post($pid);
						if ($p) $titles[] = $p->post_title;
					}
					if (!empty($titles)) {
						$data['query']['smack_include_titles'] = $titles;
					}
				}
				if (isset($data['query']['exclude']) && is_array($data['query']['exclude'])) {
					$titles = [];
					foreach ($data['query']['exclude'] as $pid) {
						$p = get_post($pid);
						if ($p) $titles[] = $p->post_title;
					}
					if (!empty($titles)) {
						$data['query']['smack_exclude_titles'] = $titles;
					}
				}
			}

			foreach ($data as $key => $value) {
				if (is_array($value)) {
					$data[$key] = $this->prepare_data_for_export($value);
				}
			}
		}
		return $data;
	}

	private function inline_bricks_templates(&$data) {
		if (!is_array($data)) return;

		$templates_to_process = true;
		while ($templates_to_process) {
			$templates_to_process = false;
			$new_data = [];
			
			foreach ($data as $index => $element) {
				if (isset($element['name']) && $element['name'] === 'template' && !empty($element['settings']['template'])) {
					$template_id = $element['settings']['template'];
					$template_meta = get_post_meta($template_id, '_bricks_page_content_2', true);
					$template_elements = maybe_unserialize($template_meta);
					
					if (is_array($template_elements) && !empty($template_elements)) {
						$templates_to_process = true;
						
						$prefix = 't' . $template_id . '_' . substr(md5(uniqid()), 0, 4) . '_';
						$root_ids = [];
						
						$id_map = [];
						foreach ($template_elements as $te) {
							if (isset($te['id'])) {
								$id_map[$te['id']] = $prefix . $te['id'];
							}
						}
						
						foreach ($template_elements as &$te) {
							if (isset($te['id']) && isset($id_map[$te['id']])) {
								$te['id'] = $id_map[$te['id']];
							}
							if (isset($te['parent'])) {
								if (empty($te['parent'])) {
									$root_ids[] = $te['id'];
									$te['parent'] = isset($element['parent']) ? $element['parent'] : 0;
								} elseif (isset($id_map[$te['parent']])) {
									$te['parent'] = $id_map[$te['parent']];
								}
							}
							if (isset($te['children']) && is_array($te['children'])) {
								foreach ($te['children'] as $ck => $cv) {
									if (isset($id_map[$cv])) {
										$te['children'][$ck] = $id_map[$cv];
									}
								}
							}
						}
						unset($te);

						$update_children = function(&$elements) use ($element, $root_ids) {
							foreach ($elements as &$el) {
								if (isset($el['children']) && is_array($el['children'])) {
									$child_index = array_search($element['id'], $el['children']);
									if ($child_index !== false) {
										array_splice($el['children'], $child_index, 1, $root_ids);
									}
								}
							}
						};
						$update_children($new_data);
						$update_children($data);
						
						foreach ($template_elements as $te) {
							$new_data[] = $te;
						}
					} else {
						$new_data[] = $element;
					}
				} else {
					$new_data[] = $element;
				}
			}
			if ($templates_to_process) {
				$data = $new_data;
			}
		}
	}

	public function bricks_option_export($option_name, $layout_raw = null) {
		$option_value = get_option($option_name, []);
		if (empty($option_value) || !is_array($option_value)) return '';

		$layout_data = maybe_unserialize($layout_raw);
		if (is_array($layout_data) && isset($layout_data[0]) && is_string($layout_data[0])) {
			$layout_data = maybe_unserialize($layout_data[0]);
		}
		
		if (is_string($layout_data)) {
			$json_decoded = json_decode($layout_data, true);
			if (is_array($json_decoded)) {
				$layout_data = $json_decoded;
			}
		}

		if (!is_array($layout_data) || empty($layout_data)) {
			// If not a Bricks page or empty layout, no assets are used
			return '';
		}

		$used_cids = [];
		$this->extract_cids($layout_data, $used_cids);
		$resolved_components = [];
		if (!empty($used_cids)) {
			do {
				$added_new = false;
				foreach ($option_value as $comp) {
					if (isset($comp['id']) && in_array($comp['id'], $used_cids)) {
						$already_resolved = false;
						foreach ($resolved_components as $rc) {
							if ($rc['id'] === $comp['id']) { $already_resolved = true; break; }
						}
						if (!$already_resolved) {
							if (isset($comp['elements']) && is_array($comp['elements'])) {
								$this->extract_cids($comp['elements'], $used_cids);
							}
							$resolved_components[] = $comp;
							$added_new = true;
						}
					}
				}
			} while ($added_new);
		}

		if ($option_name === 'bricks_components') {
			if (empty($resolved_components)) return '';

			foreach ($resolved_components as &$comp) {
				if (isset($comp['elements']) && is_array($comp['elements'])) {
					$comp['elements'] = $this->prepare_data_for_export($comp['elements']);
				}
				if (isset($comp['settings']) && is_array($comp['settings'])) {
					$comp['settings'] = $this->prepare_data_for_export($comp['settings']);
				}
			}
			$option_value = $resolved_components;
		}

		if ($option_name === 'bricks_global_classes') {
			$used_classes = [];
			$this->extract_global_classes($layout_data, $used_classes);

			// Also extract classes from all resolved components
			foreach ($resolved_components as $comp) {
				if (isset($comp['elements'])) {
					$this->extract_global_classes($comp['elements'], $used_classes);
				}
				if (isset($comp['settings'])) {
					$this->extract_global_classes($comp['settings'], $used_classes);
				}
			}

			if (empty($used_classes)) return '';

			$filtered_classes = [];
			foreach ($option_value as $class_obj) {
				if (isset($class_obj['id']) && in_array($class_obj['id'], $used_classes)) {
					$filtered_classes[] = $class_obj;
				}
			}
			$option_value = $filtered_classes;
		}
		
		if (empty($option_value)) return '';

		$json = wp_json_encode($option_value);
		$json = str_replace(get_site_url(), '{{SITE_URL}}', $json);
		
		return base64_encode($json);
	}

	private function extract_cids($data, &$cids) {
		if (is_array($data)) {
			if (isset($data['cid']) && !in_array($data['cid'], $cids)) {
				$cids[] = $data['cid'];
			}
			foreach ($data as $value) {
				if (is_array($value)) {
					$this->extract_cids($value, $cids);
				}
			}
		}
	}

	private function extract_global_classes($data, &$classes) {
		if (is_array($data)) {
			if (isset($data['_cssGlobalClasses']) && is_array($data['_cssGlobalClasses'])) {
				foreach ($data['_cssGlobalClasses'] as $class_id) {
					if (!in_array($class_id, $classes)) {
						$classes[] = $class_id;
					}
				}
			}
			foreach ($data as $key => $value) {
				if (is_array($value)) {
					$this->extract_global_classes($value, $classes);
				}
			}
		}
	}

	public function get_bricks_templates() {
		$args = [
			'post_type'      => 'bricks_template',
			'posts_per_page' => -1,
			'post_status'    => 'publish'
		];
		$query = new \WP_Query($args);
		$templates = $query->get_posts();

		$output = [];
		foreach ($templates as $template) {
			$bricks_data = get_post_meta($template->ID, '_bricks_page_content_2', true);
			$template_type = get_post_meta($template->ID, '_bricks_template_type', true);
			
			$output[] = [
				'ID'               => $template->ID,
				'Template Title'   => $template->post_title,
				'Template Content' => $template->post_content,
				'Layout JSON'      => $this->bricks_data_export($bricks_data),
				'Template Type'    => $template_type,
				'Status'           => $template->post_status,
			];
		}
		return $output;
	}
}
