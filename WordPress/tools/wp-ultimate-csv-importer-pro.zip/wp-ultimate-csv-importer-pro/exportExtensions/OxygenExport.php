<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class OxygenExport {

	public function __construct() {
	}

	/**
	 * Parse _ct_builder_json and return a | separated string of image URLs
	 */
	public function get_oxygen_media($post_id) {
		$json_data = get_post_meta($post_id, '_ct_builder_json', true);
		if (empty($json_data)) {
			return '';
		}

		$urls = [];
		// Extract URLs from JSON that look like images.
		// Common extensions for images:
		if (preg_match_all('/https?:\/\/[^\s"\'\\\\]+\.(?:jpg|jpeg|png|gif|svg|webp)/i', wp_unslash($json_data), $matches)) {
			if (!empty($matches[0])) {
				$urls = array_unique($matches[0]);
			}
		}

		// Oxygen often stores background images inside style objects or src attributes.
		// The regex above will capture standard absolute image URLs.
		
		return implode('|', $urls);
	}
}
