<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Enrich export rows for The Events Calendar CPTs with round-trip friendly columns.
 */
class EventCalendarExport {

	private static $instance = null;

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Whether the optional type is a TEC CPT.
	 *
	 * @param string $optional_type Optional type / CPT slug.
	 * @return bool
	 */
	public static function is_tec_export_type( $optional_type ) {
		$type = EventCalendarExtension::normalize_type( $optional_type );
		return in_array(
			$type,
			array( 'tribe_events', 'tribe_venue', 'tribe_organizer', 'tribe_event_series' ),
			true
		);
	}

	/**
	 * Enrich a single export row already populated with raw post meta.
	 *
	 * @param int    $post_id       Post ID.
	 * @param array  $row           Existing export row (by reference via ExportExtension::$data).
	 * @param string $optional_type CPT / optional type.
	 * @return array Enriched row fragment to merge.
	 */
	public function get_event_calendar_data( $post_id, array $row = array(), $optional_type = 'tribe_events' ) {
		if ( ! EventCalendarExtension::is_tec_active() ) {
			return array();
		}

		$type = EventCalendarExtension::normalize_type( $optional_type );
		$out  = array();

		switch ( $type ) {
			case 'tribe_events':
				$out = $this->export_event( $post_id, $row );
				break;
			case 'tribe_venue':
				$out = $this->export_venue_aliases( $post_id );
				break;
			case 'tribe_organizer':
				$out = $this->export_organizer_aliases( $post_id );
				break;
			case 'tribe_event_series':
				$out = $this->export_series( $post_id );
				break;
		}

		return $out;
	}

	/**
	 * @param int   $post_id Event ID.
	 * @param array $row     Existing row.
	 * @return array
	 */
	private function export_event( $post_id, array $row ) {
		$out = array();

		$start = get_post_meta( $post_id, '_EventStartDate', true );
		$end   = get_post_meta( $post_id, '_EventEndDate', true );

		if ( $start ) {
			$time = $this->extract_time_portion( $start );
			if ( '' !== $time ) {
				$out['event_start_time'] = $time;
			}
		}
		if ( $end ) {
			$time = $this->extract_time_portion( $end );
			if ( '' !== $time ) {
				$out['event_end_time'] = $time;
			}
		}

		// Venue expansion.
		$venue_id = (int) get_post_meta( $post_id, '_EventVenueID', true );
		if ( $venue_id ) {
			$out['event_venue_id']          = (string) $venue_id;
			$out['event_venue_name']        = get_the_title( $venue_id );
			$out['event_venue_description'] = get_post_field( 'post_content', $venue_id );
			$out['event_venue_address']     = (string) get_post_meta( $venue_id, '_VenueAddress', true );
			$out['event_venue_city']        = (string) get_post_meta( $venue_id, '_VenueCity', true );
			$out['event_venue_state']       = (string) get_post_meta( $venue_id, '_VenueState', true );
			$out['event_venue_province']    = (string) get_post_meta( $venue_id, '_VenueProvince', true );
			$out['event_venue_zip']         = (string) get_post_meta( $venue_id, '_VenueZip', true );
			$out['event_venue_country']     = (string) get_post_meta( $venue_id, '_VenueCountry', true );
			$out['event_venue_phone']       = (string) get_post_meta( $venue_id, '_VenuePhone', true );
			$out['event_venue_website']     = (string) get_post_meta( $venue_id, '_VenueURL', true );
			$out['event_venue_lat']         = (string) get_post_meta( $venue_id, '_VenueLat', true );
			$out['event_venue_lng']         = (string) get_post_meta( $venue_id, '_VenueLng', true );
			$out['event_venue_show_map']    = (string) get_post_meta( $venue_id, '_VenueShowMap', true );
			$out['event_venue_show_map_link'] = (string) get_post_meta( $venue_id, '_VenueShowMapLink', true );
		}

		// Organizers (multi).
		$organizer_ids = get_post_meta( $post_id, '_EventOrganizerID', false );
		if ( ! empty( $organizer_ids ) ) {
			$organizer_ids = array_map( 'intval', (array) $organizer_ids );
			$names = $emails = $phones = $webs = $descs = array();
			foreach ( $organizer_ids as $oid ) {
				if ( ! $oid ) {
					continue;
				}
				$names[]  = get_the_title( $oid );
				$emails[] = (string) get_post_meta( $oid, '_OrganizerEmail', true );
				$phones[] = (string) get_post_meta( $oid, '_OrganizerPhone', true );
				$webs[]   = (string) get_post_meta( $oid, '_OrganizerWebsite', true );
				$descs[]  = (string) get_post_field( 'post_content', $oid );
			}
			$out['event_organizer_id']          = implode( ',', $organizer_ids );
			$out['event_organizer_name']        = implode( ',', $names );
			$out['event_organizer_email']       = implode( ',', $emails );
			$out['event_organizer_phone']       = implode( ',', $phones );
			$out['event_organizer_website']     = implode( ',', $webs );
			$out['event_organizer_description'] = implode( '|', $descs );
		}

		// Recurrence (Pro).
		if ( EventCalendarExtension::is_tec_pro_active() ) {
			$recurrence = get_post_meta( $post_id, '_EventRecurrence', true );
			if ( ! empty( $recurrence ) && is_array( $recurrence ) ) {
				$out = array_merge( $out, $this->flatten_recurrence( $recurrence ) );
			}

			// Series.
			if ( function_exists( 'tec_event_series' ) ) {
				$series = tec_event_series( $post_id );
				if ( $series && ! empty( $series->ID ) ) {
					$out['event_series_id']    = (string) $series->ID;
					$out['event_series_title'] = $series->post_title;
				}
			} else {
				$rel = get_post_meta( $post_id, '_tec_relationship_event_to_series', true );
				if ( is_array( $rel ) && ! empty( $rel[0] ) ) {
					$sid = (int) $rel[0];
					$out['event_series_id']    = (string) $sid;
					$out['event_series_title'] = get_the_title( $sid );
				}
			}

			// Custom fields already exported as meta keys; ensure multi-value joined with |.
			if ( function_exists( 'tribe_get_option' ) ) {
				$custom_fields = tribe_get_option( 'custom-fields', array() );
				if ( is_array( $custom_fields ) ) {
					foreach ( $custom_fields as $field ) {
						if ( empty( $field['name'] ) ) {
							continue;
						}
						$values = get_post_meta( $post_id, $field['name'], false );
						if ( is_array( $values ) && count( $values ) > 1 ) {
							$out[ $field['name'] ] = implode( '|', $values );
						}
					}
				}
			}
		}

		return $out;
	}

	/**
	 * Flatten _EventRecurrence into CSV columns.
	 *
	 * @param array $recurrence Recurrence meta.
	 * @return array
	 */
	private function flatten_recurrence( array $recurrence ) {
		$out  = array();
		$rule = isset( $recurrence['rules'][0] ) ? $recurrence['rules'][0] : array();

		if ( empty( $rule ) ) {
			return $out;
		}

		$type = '';
		if ( ! empty( $rule['custom']['type'] ) ) {
			$type = $rule['custom']['type'];
		} elseif ( ! empty( $rule['type'] ) ) {
			$type = $rule['type'];
		}
		$out['recurrence_type'] = strtolower( (string) $type );

		if ( ! empty( $rule['custom']['interval'] ) ) {
			$out['recurrence_interval'] = (string) $rule['custom']['interval'];
		}

		if ( ! empty( $rule['custom']['week']['day'] ) && is_array( $rule['custom']['week']['day'] ) ) {
			$days = $rule['custom']['week']['day'];
			// Normalize numeric days to abbreviations when possible.
			$map = array( 1 => 'mon', 2 => 'tue', 3 => 'wed', 4 => 'thu', 5 => 'fri', 6 => 'sat', 7 => 'sun' );
			$norm = array();
			foreach ( $days as $d ) {
				$norm[] = isset( $map[ $d ] ) ? $map[ $d ] : (string) $d;
			}
			$out['recurrence_weekdays'] = implode( ',', $norm );
		}

		if ( ! empty( $rule['end-type'] ) ) {
			$out['recurrence_end_type'] = strtolower( (string) $rule['end-type'] );
		}
		if ( ! empty( $rule['end-count'] ) ) {
			$out['recurrence_end_count'] = (string) $rule['end-count'];
		}
		if ( ! empty( $rule['end'] ) ) {
			$out['recurrence_end_date'] = (string) $rule['end'];
		}
		if ( ! empty( $recurrence['description'] ) ) {
			$out['recurrence_description'] = (string) $recurrence['description'];
		}

		// Additional date rules / exclusions.
		$extra_dates = array();
		if ( ! empty( $recurrence['rules'] ) && is_array( $recurrence['rules'] ) ) {
			foreach ( $recurrence['rules'] as $r ) {
				if ( empty( $r['custom']['type'] ) ) {
					continue;
				}
				if ( 'Date' === $r['custom']['type'] && ! empty( $r['custom']['date']['date'] ) ) {
					$extra_dates[] = $r['custom']['date']['date'];
				}
			}
		}
		if ( ! empty( $extra_dates ) ) {
			$out['recurrence_additional_dates'] = implode( ',', $extra_dates );
		}

		$exclusions = array();
		if ( ! empty( $recurrence['exclusions'] ) && is_array( $recurrence['exclusions'] ) ) {
			foreach ( $recurrence['exclusions'] as $ex ) {
				if ( ! empty( $ex['custom']['date']['date'] ) ) {
					$exclusions[] = $ex['custom']['date']['date'];
				} elseif ( ! empty( $ex['EventStartDate'] ) ) {
					$exclusions[] = $ex['EventStartDate'];
				}
			}
		}
		if ( ! empty( $exclusions ) ) {
			$out['recurrence_exclusions'] = implode( ',', $exclusions );
		}

		return $out;
	}

	/**
	 * Extract H:i:s from a local wall-clock datetime without TZ conversion.
	 *
	 * @param string $datetime Datetime string.
	 * @return string
	 */
	private function extract_time_portion( $datetime ) {
		$datetime = trim( (string) $datetime );
		if ( preg_match( '/\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b/', $datetime, $m ) ) {
			$h = str_pad( (string) (int) $m[1], 2, '0', STR_PAD_LEFT );
			$i = $m[2];
			$s = isset( $m[3] ) && '' !== $m[3] ? $m[3] : '00';
			return $h . ':' . $i . ':' . $s;
		}
		return '';
	}

	/**
	 * Standalone venue export — ensure geo / map meta are present as named columns.
	 *
	 * @param int $post_id Venue ID.
	 * @return array
	 */
	private function export_venue_aliases( $post_id ) {
		$keys = array(
			'_VenueAddress',
			'_VenueCity',
			'_VenueState',
			'_VenueProvince',
			'_VenueStateProvince',
			'_VenueZip',
			'_VenueCountry',
			'_VenuePhone',
			'_VenueURL',
			'_VenueLat',
			'_VenueLng',
			'_VenueShowMap',
			'_VenueShowMapLink',
		);
		$out = array();
		foreach ( $keys as $key ) {
			$value = get_post_meta( $post_id, $key, true );
			if ( '' !== $value && false !== $value && null !== $value ) {
				$out[ $key ] = (string) $value;
			}
		}
		return $out;
	}

	/**
	 * Standalone organizer export — ensure contact meta columns are present.
	 *
	 * @param int $post_id Organizer ID.
	 * @return array
	 */
	private function export_organizer_aliases( $post_id ) {
		$keys = array( '_OrganizerPhone', '_OrganizerEmail', '_OrganizerWebsite' );
		$out  = array();
		foreach ( $keys as $key ) {
			$value = get_post_meta( $post_id, $key, true );
			if ( '' !== $value && false !== $value && null !== $value ) {
				$out[ $key ] = (string) $value;
			}
		}
		return $out;
	}

	/**
	 * @param int $post_id Series ID.
	 * @return array
	 */
	private function export_series( $post_id ) {
		$out = array();
		if ( class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Models\Series_Relationship' ) ) {
			try {
				$rels = \TEC\Events_Pro\Custom_Tables\V1\Models\Series_Relationship::where( 'series_post_id', '=', $post_id )->get();
				$ids  = array();
				if ( $rels ) {
					foreach ( $rels as $rel ) {
						if ( ! empty( $rel->event_post_id ) ) {
							$ids[] = (int) $rel->event_post_id;
						}
					}
				}
				if ( ! empty( $ids ) ) {
					$out['series_event_ids'] = implode( ',', $ids );
				}
			} catch ( \Throwable $e ) {
				// Soft fail.
			}
		}
		return $out;
	}
}
