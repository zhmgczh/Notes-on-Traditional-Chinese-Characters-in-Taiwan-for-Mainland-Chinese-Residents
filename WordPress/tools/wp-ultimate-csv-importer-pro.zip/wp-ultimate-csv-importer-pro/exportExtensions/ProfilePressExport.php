<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ProfilePressExport {
	protected static $instance = null;

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * Fetch all ProfilePress data for a single user.
	 *
	 * Returns a flat associative array ready to be merged into the export row.
	 * Every expected field is always present (empty string if no value), ensuring
	 * consistent CSV column layout across all users.
	 *
	 * @param  int   $user_id
	 * @param  array $all_field_keys  Full list of field keys from getProfilePressFields()
	 * @return array
	 */
	public function getProfilePressData( $user_id, $all_field_keys = [] ) {
		global $wpdb;

		if ( empty( $user_id ) ) {
			return [];
		}

		$user_id = intval( $user_id );

		// -------------------------------------------------------
		// 1. Pre-seed every known field with an empty string
		//    so no column is ever missing from the export row.
		// -------------------------------------------------------
		$pp_data = [];
		foreach ( $all_field_keys as $key => $label ) {
			$pp_data[ $key ] = '';
		}

		// -------------------------------------------------------
		// 2. WP users table fields (user_email, user_login, display_name)
		//    AND standard usermeta fields (first_name, last_name, etc.)
		// -------------------------------------------------------
		$user_obj = get_userdata( $user_id );
		if ( $user_obj ) {
			$pp_data['ID'] = (string) $user_id;
			// wp_users columns
			$wp_users_fields = [
				'user_email',
				'user_login',
				'display_name',
				'user_registered',
				'user_nicename',
				'user_url',
			];
			foreach ( $wp_users_fields as $field ) {
				$pp_data[ $field ] = (string) ( $user_obj->$field ?? '' );
			}
			// Standard usermeta fields (first_name, last_name, etc.)
			foreach ( ProfilePressExtension::STANDARD_USER_FIELDS as $field ) {
				$pp_data[ $field ] = (string) ( $user_obj->$field ?? '' );
			}
		}

		// -------------------------------------------------------
		// 3. Fetch all pp_* / ppress_* usermeta for the user
		// -------------------------------------------------------
		$raw_meta = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_key, meta_value
				 FROM {$wpdb->usermeta}
				 WHERE user_id = %d
				   AND ( meta_key LIKE 'pp_%' OR meta_key LIKE 'ppress_%' )",
				$user_id
			),
			ARRAY_A
		);

		// Build a lookup: meta_key => meta_value
		$meta_lookup = [];
		foreach ( $raw_meta as $row ) {
			$meta_lookup[ $row['meta_key'] ] = $row['meta_value'];
		}

		// -------------------------------------------------------
		// 4. Process each meta key
		// -------------------------------------------------------
		foreach ( $meta_lookup as $key => $value ) {

			// ---- A. Serialized pp_uploaded_files → flatten ----
			if ( $key === ProfilePressExtension::UPLOADED_FILES_KEY ) {
				$unserialized = @unserialize( $value );
				if ( is_array( $unserialized ) ) {
					foreach ( $unserialized as $subkey => $filename ) {
						$flat_key             = ProfilePressExtension::UPLOADED_FILES_KEY . '_' . $subkey;
						$pp_data[ $flat_key ] = (string) $filename;
					}
				}
				// Skip storing the raw blob
				continue;
			}

			// ---- B. Avatar / cover → convert filename to full URL ----
			if ( in_array( $key, ProfilePressExtension::FILE_FIELDS, true ) && ! empty( $value ) ) {
				// If value is already a URL, use it; otherwise build URL from filename
				if ( filter_var( $value, FILTER_VALIDATE_URL ) ) {
					$pp_data[ $key ] = $value;
				} else {
					$upload_dir      = wp_upload_dir();
					$base_url        = trailingslashit( $upload_dir['baseurl'] ) . 'profilepress/';
					$pp_data[ $key ] = $base_url . ltrim( $value, '/' );
				}
				continue;
			}

			// ---- C. All other pp_* / ppress_* keys ----
			if ( is_serialized( $value ) ) {
				// Non-file serialized value: JSON-encode for readability
				$decoded         = @unserialize( $value );
				$pp_data[ $key ] = is_array( $decoded ) || is_object( $decoded )
					? wp_json_encode( $decoded )
					: (string) $decoded;
			} else {
				$pp_data[ $key ] = (string) $value;
			}
		}

		// -------------------------------------------------------
		// 5. wp_ppress_customers columns
		// -------------------------------------------------------
		$customers_table = $wpdb->prefix . 'ppress_customers';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customers_table ) ) ) {
			$customer_row = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$customers_table} WHERE user_id = %d LIMIT 1", $user_id ),
				ARRAY_A
			);
			if ( $customer_row ) {
				foreach ( ProfilePressExtension::CUSTOMER_TABLE_FIELDS as $col ) {
					$pp_data[ $col ] = isset( $customer_row[ $col ] ) ? (string) $customer_row[ $col ] : '';
				}
			}
		}

		// -------------------------------------------------------
		// 6. ProfilePress subscriptions (plans -> subscriptions -> customers)
		// -------------------------------------------------------
		$plans_table         = $wpdb->prefix . 'ppress_plans';
		$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';

		// Only run the subscription join when tables exist.
		$tables_exist = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $plans_table ) )
			&& $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $subscriptions_table ) )
			&& $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customers_table ) );

		if ( $tables_exist ) {
			// Prefer active subscription, otherwise the newest subscription.
			$sub_row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT
						p.id AS plan_id,
						p.name AS plan_name,
						s.status AS subscription_status,
						s.created_date AS created_date,
						s.expiration_date AS expiration_date,
						s.recurring_amount AS recurring_amount
					FROM {$customers_table} c
					INNER JOIN {$subscriptions_table} s ON s.customer_id = c.id
					INNER JOIN {$plans_table} p ON p.id = s.plan_id
					WHERE c.user_id = %d
					ORDER BY (s.status = 'active') DESC, s.created_date DESC
					LIMIT 1",
					$user_id
				),
				ARRAY_A
			);

			if ( $sub_row ) {
				$pp_data['ppress_plan_id']         = isset( $sub_row['plan_id'] ) ? (string) $sub_row['plan_id'] : '';
				$pp_data['pp_member_type']       = isset( $sub_row['plan_name'] ) ? (string) $sub_row['plan_name'] : '';
				$pp_data['pp_member_start']      = isset( $sub_row['created_date'] ) ? (string) $sub_row['created_date'] : '';
				$pp_data['pp_member_end']        = isset( $sub_row['expiration_date'] ) ? (string) $sub_row['expiration_date'] : '';
				$pp_data['pp_member_amount']    = isset( $sub_row['recurring_amount'] ) ? (string) $sub_row['recurring_amount'] : '';
				$pp_data['subscription_status']  = isset( $sub_row['subscription_status'] ) ? (string) $sub_row['subscription_status'] : '';
			} else {
				// Avoid exporting stale meta if there is no subscription record.
				$pp_data['ppress_plan_id']         = '';
				$pp_data['pp_member_type']       = '';
				$pp_data['pp_member_start']      = '';
				$pp_data['pp_member_end']        = '';
				$pp_data['pp_member_amount']    = '';
				$pp_data['subscription_status']  = '';
			}
		}

		// -------------------------------------------------------
		// 7. Latest ProfilePress order (for roundtrip re-import)
		// -------------------------------------------------------
		$orders_table     = $wpdb->prefix . 'ppress_orders';
		$customers_table  = $wpdb->prefix . 'ppress_customers';
		$plans_table      = $wpdb->prefix . 'ppress_plans';

		$orders_exist = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $orders_table ) )
			&& $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customers_table ) );

		if ( $orders_exist ) {
			$order_row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT o.*
					 FROM {$customers_table} c
					 INNER JOIN {$orders_table} o ON o.customer_id = c.id
					 WHERE c.user_id = %d
					 ORDER BY o.id DESC
					 LIMIT 1",
					$user_id
				),
				ARRAY_A
			);

			if ( is_array( $order_row ) && ! empty( $order_row ) ) {
				// Attempt to resolve plan name if plan_id column exists.
				$plan_name = '';
				if ( isset( $order_row['plan_id'] ) && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $plans_table ) ) ) {
					$plan_id = intval( $order_row['plan_id'] );
					if ( $plan_id > 0 ) {
						$plan_name = (string) $wpdb->get_var(
							$wpdb->prepare( "SELECT name FROM {$plans_table} WHERE id = %d LIMIT 1", $plan_id )
						);
					}
				}

				$pp_data['ppress_order_plan_id'] = isset( $order_row['plan_id'] ) ? (string) $order_row['plan_id'] : '';
				$pp_data['ppress_order_plan_name'] = $plan_name;

				// Amount/total naming differs across versions.
				if ( isset( $order_row['amount'] ) ) {
					$pp_data['ppress_order_amount'] = (string) $order_row['amount'];
				} elseif ( isset( $order_row['total'] ) ) {
					$pp_data['ppress_order_amount'] = (string) $order_row['total'];
				} else {
					$pp_data['ppress_order_amount'] = '';
				}

				$pp_data['ppress_order_status'] = isset( $order_row['status'] ) ? (string) $order_row['status'] : '';
				$pp_data['ppress_order_payment_method'] = isset( $order_row['payment_method'] ) ? (string) $order_row['payment_method'] : '';
				$pp_data['ppress_order_transaction_id'] = isset( $order_row['transaction_id'] ) ? (string) $order_row['transaction_id'] : '';
				// Date columns vary; prefer date_created then created_at.
				$pp_data['ppress_order_date_created'] = isset( $order_row['date_created'] ) ? (string) $order_row['date_created'] : ( (string) ( $order_row['created_at'] ?? '' ) );
			} else {
				$pp_data['ppress_order_plan_id'] = '';
				$pp_data['ppress_order_plan_name'] = '';
				$pp_data['ppress_order_amount'] = '';
				$pp_data['ppress_order_status'] = '';
				$pp_data['ppress_order_payment_method'] = '';
				$pp_data['ppress_order_transaction_id'] = '';
				$pp_data['ppress_order_date_created'] = '';
			}
		}

		return $pp_data;
	}

	/**
	 * Count rows in ProfilePress custom tables (plans / orders).
	 *
	 * @param string $table_suffix e.g. ppress_plans, ppress_orders
	 * @param array  $conditions    Export conditions (optional date range)
	 * @return int
	 */
	public function count_ppress_table_rows( $table_suffix, $conditions = [] ) {
		global $wpdb;

		$table = $wpdb->prefix . preg_replace( '/[^a-z0-9_]/', '', $table_suffix );
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return 0;
		}

		$where  = '1=1';
		$params = [];
		if ( ! empty( $conditions['specific_period']['is_check'] ) && $conditions['specific_period']['is_check'] === 'true' ) {
			$date_col = $this->get_ppress_table_date_column( $table );
			if ( $date_col !== '' ) {
				$from = $conditions['specific_period']['from'] ?? '';
				$to   = $conditions['specific_period']['to'] ?? $from;
				if ( $from !== '' ) {
					if ( $from === $to ) {
						$where   .= " AND `{$date_col}` >= %s AND `{$date_col}` <= %s";
						$params[] = $from;
						$params[] = $from . ' 23:59:59';
					} else {
						$where   .= " AND `{$date_col}` >= %s AND `{$date_col}` <= %s";
						$params[] = $from;
						$params[] = $to . ' 23:59:59';
					}
				}
			}
		}

		$sql = "SELECT COUNT(*) FROM `{$table}` WHERE {$where}";
		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Fetch a batch of rows for CSV export (memory-friendly LIMIT/OFFSET).
	 *
	 * @param string $table_suffix
	 * @param array  $headers        Header keys to include
	 * @param array  $conditions
	 * @param int    $offset
	 * @param int    $limit
	 * @return array<int,array<string,string>> id => row
	 */
	public function fetch_ppress_table_rows( $table_suffix, $headers, $conditions, $offset, $limit ) {
		global $wpdb;

		$table = $wpdb->prefix . preg_replace( '/[^a-z0-9_]/', '', $table_suffix );
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return [];
		}

		$headers    = is_array( $headers ) ? $headers : [];
		$offset     = max( 0, (int) $offset );
		$limit      = max( 0, (int) $limit );
		$where      = '1=1';
		$params     = [];
		if ( ! empty( $conditions['specific_period']['is_check'] ) && $conditions['specific_period']['is_check'] === 'true' ) {
			$date_col = $this->get_ppress_table_date_column( $table );
			if ( $date_col !== '' ) {
				$from = $conditions['specific_period']['from'] ?? '';
				$to   = $conditions['specific_period']['to'] ?? $from;
				if ( $from !== '' ) {
					if ( $from === $to ) {
						$where   .= " AND `{$date_col}` >= %s AND `{$date_col}` <= %s";
						$params[] = $from;
						$params[] = $from . ' 23:59:59';
					} else {
						$where   .= " AND `{$date_col}` >= %s AND `{$date_col}` <= %s";
						$params[] = $from;
						$params[] = $to . ' 23:59:59';
					}
				}
			}
		}

		$sql = "SELECT * FROM `{$table}` WHERE {$where} ORDER BY id ASC";
		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}
		if ( $limit > 0 ) {
			$sql .= $wpdb->prepare( ' LIMIT %d OFFSET %d', $limit, $offset );
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return [];
		}

		$out      = [];
		$is_plans = ( strpos( $table_suffix, 'plans' ) !== false );

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$id = isset( $row['id'] ) ? (int) $row['id'] : 0;
			if ( $id < 1 ) {
				continue;
			}
			$out[ $id ] = [];
			foreach ( $headers as $h ) {
				if ( $is_plans && $h === 'plan_id' ) {
					$out[ $id ]['plan_id'] = (string) $id;
					continue;
				}
				if ( ! $is_plans && $h === 'order_id' ) {
					$out[ $id ]['order_id'] = (string) $id;
					continue;
				}
				if ( array_key_exists( $h, $row ) ) {
					$val = $row[ $h ];
					if ( is_array( $val ) || is_object( $val ) ) {
						$val = wp_json_encode( $val );
					}
					$out[ $id ][ $h ] = (string) $val;
				} else {
					$out[ $id ][ $h ] = '';
				}
			}
		}

		return $out;
	}

	/**
	 * @param string $full_table
	 * @return string Date column name or empty
	 */
	private function get_ppress_table_date_column( $full_table ) {
		global $wpdb;

		$candidates = [ 'date_created', 'created_at', 'created_date', 'updated_at' ];
		$cols       = $wpdb->get_col( "SHOW COLUMNS FROM `{$full_table}`", 0 );
		if ( ! is_array( $cols ) ) {
			return '';
		}
		foreach ( $candidates as $c ) {
			if ( in_array( $c, $cols, true ) ) {
				return $c;
			}
		}
		return '';
	}
}
