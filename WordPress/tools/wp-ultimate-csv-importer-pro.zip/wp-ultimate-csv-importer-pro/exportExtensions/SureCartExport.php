<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

/**
 * Class SureCartExport
 * Handles all SureCart export functionality
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */
class SureCartExport
{
	protected static $instance = null, $export_instance;
	public $totalRowCount;
	public $plugin;

	public static function getInstance()
	{
		if (null == self::$instance) {
			self::$instance = new self;
			SureCartExport::$export_instance = ExportExtension::getInstance();
		}
		return self::$instance;
	}

	/**
	 * SureCartExport constructor.
	 */
	public function __construct()
	{
		$this->plugin = class_exists("Smackcoders\UCI\Core\UCICore") ? \Smackcoders\UCI\Core\UCICore::getInstance() : null;
	}

	/**
	 * Export SureCart Products data
	 * 
	 * @param int $id Product ID
	 * @return void
	 */
	public function getSureCartProductDataMaster($id)
    {
        global $wpdb;

        if (!is_plugin_active('surecart/surecart.php')) {
            return;
        }

        $input_id = $id;

        // Resolve SureCart string ID to WP post ID if present
        $sc_id = '';
        if (!is_numeric($id)) {
            $sc_id = $id;
            $id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s LIMIT 1",
                $sc_id
            ));
        } else {
            $sc_id = get_post_meta($id, 'sc_id', true);
        }

        $product = null;
        if (!empty($sc_id) && class_exists('\SureCart\Models\Product')) {
            try {
                $product = \SureCart\Models\Product::with(['prices', 'product_collections', 'shipping_profile', 'variants'])->find($sc_id);
            } catch (\Exception $e) {}
        }

        if (!$product && !$id) {
            return; // Can't fetch from API and no local post ID
        }
        
        $post_type = $id ? $wpdb->get_var(
            $wpdb->prepare("SELECT post_type FROM {$wpdb->posts} WHERE ID = %d", $id)
        ) : '';

        if ($id && $post_type !== 'sc_product') {
            return;
        }

        // Gather from API Model first
        $api_data = [];
        if ($product) {
            $api_data['product_name'] = $product->name ?? '';
            $api_data['sku'] = $product->sku ?? '';
            $api_data['product_type'] = !empty($product->has_variants) ? 'variable' : 'simple';
            $api_data['stock_enabled'] = !empty($product->stock_enabled) ? 'yes' : 'no';
            $api_data['stock_quantity'] = $product->stock_adjustment ?? 0;
            $api_data['allow_purchase_out_of_stock'] = !empty($product->allow_out_of_stock_purchases) ? 'yes' : 'no';
            $api_data['tax_enabled'] = !empty($product->tax_enabled) ? 'yes' : 'no';
            $api_data['tax_status'] = $product->tax_status ?? '';
            
            // Prices
            $price_amount = '';
            $compare_at_price = '';
            $recurring_interval_count = '';
            $recurring_interval_period = '';
            if (!empty($product->active_prices) && is_array($product->active_prices)) {
                $price_obj = is_object($product->active_prices[0]) ? $product->active_prices[0] : (object)$product->active_prices[0];
                if (isset($price_obj->amount)) {
                    $price_amount = floatval($price_obj->amount) / 100;
                }
                if (isset($price_obj->compare_at_amount)) {
                    $compare_at_price = floatval($price_obj->compare_at_amount) / 100;
                }
                if (!empty($price_obj->recurring_interval_count)) {
                    $recurring_interval_count = $price_obj->recurring_interval_count;
                }
                if (!empty($price_obj->recurring_interval)) {
                    $recurring_interval_period = $price_obj->recurring_interval;
                    $api_data['product_type'] = 'subscription';
                }
            }
            $api_data['price'] = $price_amount;
            $api_data['compare_at_price'] = $compare_at_price;
            $api_data['recurring_interval'] = $recurring_interval_count;
            $api_data['recurring_period'] = $recurring_interval_period;

            // SEO
            $api_data['seo_title'] = $product->page_title ?? '';
            $api_data['seo_description'] = $product->meta_description ?? '';
            
            // Collections
            $collections = [];
            $pc = $product->product_collections ?? [];
            $pc_data = is_object($pc) && isset($pc->data) ? $pc->data : (is_array($pc) && isset($pc['data']) ? $pc['data'] : []);
            foreach ($pc_data as $collection) {
                $coll = is_object($collection) ? $collection : (object)$collection;
                if (!empty($coll->name)) {
                    $collections[] = $coll->name;
                }
            }
            $api_data['product_collections'] = implode(',', $collections);

            // Shipping Profile
            $sp = $product->shipping_profile ?? [];
            $sp_name = is_object($sp) ? ($sp->name ?? '') : ($sp['name'] ?? '');
            $api_data['shipping_profile'] = $sp_name;
            
            // License
            if (isset($product->metadata) && is_object($product->metadata) && isset($product->metadata->license)) {
                $api_data['license'] = $product->metadata->license;
            } elseif (isset($product->metadata) && is_array($product->metadata) && isset($product->metadata['license'])) {
                $api_data['license'] = $product->metadata['license'];
            } elseif (isset($product->license)) {
                $api_data['license'] = $product->license;
            }
            if (isset($product->metadata) && is_object($product->metadata) && isset($product->metadata->license_count)) {
                $api_data['license_count'] = $product->metadata->license_count;
            } elseif (isset($product->metadata) && is_array($product->metadata) && isset($product->metadata['license_count'])) {
                $api_data['license_count'] = $product->metadata['license_count'];
            } elseif (isset($product->license_count)) {
                $api_data['license_count'] = $product->license_count;
            }
            
            // Downloads for normal product
            if (!empty($product->id) && class_exists('\SureCart\Models\Download')) {
                try {
                    $downloads = \SureCart\Models\Download::where(['product' => $product->id])->get();
                    $download_links = [];
                    if (!empty($downloads) && !empty($downloads->data)) {
                        foreach ($downloads->data as $dl) {
                            $download_links[] = ($dl->name ?? '') . ',' . ($dl->url ?? '');
                        }
                    }
                    if (!empty($download_links)) {
                        $api_data['download_files'] = implode('|', $download_links);
                    }
                } catch (\Throwable $e) {}
            }
            
            // Variants
            $variant_str = '';
            if (!empty($product->options)) {
                $opts = is_object($product->options) ? $product->options : (array)$product->options;
                $opts_data = is_object($opts) && isset($opts->data) ? $opts->data : (is_array($opts) && isset($opts['data']) ? $opts['data'] : $opts);
                $var_arr = [];
                foreach ($opts_data as $opt) {
                    $o = is_object($opt) ? $opt : (object)$opt;
                    if (!empty($o->name) && !empty($o->values)) {
                        $var_arr[] = $o->name . ':' . implode(',', $o->values);
                    }
                }
                $variant_str = implode('|', $var_arr);
            }
            $api_data['variant_options'] = $variant_str;

            // Individual Variant Details
            $variant_index = 1;
            if (!empty($product->variants)) {
                $variants_data = is_object($product->variants) && isset($product->variants->data) ? $product->variants->data : (is_array($product->variants) && isset($product->variants['data']) ? $product->variants['data'] : $product->variants);
                foreach ($variants_data as $variant) {
                    $v = is_object($variant) ? $variant : (object)$variant;
                    $api_data["variant_sku_$variant_index"] = $v->sku ?? '';
                    $api_data["variant_stock_$variant_index"] = $v->inventory ?? '';
                    $api_data["variant_weight_$variant_index"] = $v->weight ?? '';
                    $api_data["variant_purchase_limit_$variant_index"] = $v->purchase_limit ?? '';
                    $api_data["variant_download_enable_$variant_index"] = !empty($v->downloads_enabled) ? 'yes' : 'no';
                    
                    // Options (attributes)
                    $opts = [];
                    if (!empty($v->option_1)) $opts[] = $v->option_1;
                    if (!empty($v->option_2)) $opts[] = $v->option_2;
                    if (!empty($v->option_3)) $opts[] = $v->option_3;
                    $api_data["variant_attributes_$variant_index"] = implode(',', $opts);
                    
                    // New variant properties
                    $api_data["variant_product_type_$variant_index"] = !empty($v->physical) ? 'physical' : 'digital';
                    $api_data["variant_length_$variant_index"] = $v->length ?? '';
                    $api_data["variant_width_$variant_index"] = $v->width ?? '';
                    $api_data["variant_height_$variant_index"] = $v->height ?? '';
                    $api_data["variant_unit_$variant_index"] = $v->unit ?? '';
                    $api_data["variant_auto_fulfillment_$variant_index"] = !empty($v->auto_fulfillment) ? 'yes' : 'no';
                    $api_data["variant_tax_charge_$variant_index"] = !empty($v->charge_tax) ? 'yes' : 'no';
                    $api_data["variant_allow_backorders_$variant_index"] = !empty($v->allow_out_of_stock_purchases) ? 'yes' : 'no';
                    
                    if (isset($v->metadata) && is_array($v->metadata) && isset($v->metadata['license'])) {
                        $api_data["variant_license_$variant_index"] = $v->metadata['license'];
                    } elseif (isset($v->license)) {
                        $api_data["variant_license_$variant_index"] = $v->license;
                    }
                    if (isset($v->metadata) && is_array($v->metadata) && isset($v->metadata['license_count'])) {
                        $api_data["variant_license_count_$variant_index"] = $v->metadata['license_count'];
                    } elseif (isset($v->license_count)) {
                        $api_data["variant_license_count_$variant_index"] = $v->license_count;
                    }
                    
                    // Fetch Price
                    if (!empty($v->id) && class_exists('\SureCart\Models\Price')) {
                        try {
                            $price_models = \SureCart\Models\Price::where(['variant' => $v->id])->get();
                            if (!empty($price_models) && !empty($price_models->data[0])) {
                                $api_data["variant_price_$variant_index"] = floatval($price_models->data[0]->amount) / 100;
                            }
                        } catch (\Throwable $e) {}
                    }
                    
                    // Media
                    if (isset($v->metadata) && is_array($v->metadata) && isset($v->metadata['wp_media'])) {
                        $media_url = wp_get_attachment_url($v->metadata['wp_media']);
                        if ($media_url) {
                            $api_data["variant_media_$variant_index"] = $media_url;
                        }
                    }

                    // Downloads
                    if (!empty($v->id) && class_exists('\SureCart\Models\Download')) {
                        try {
                            $downloads = \SureCart\Models\Download::where(['variant' => $v->id])->get();
                            $download_links = [];
                            if (!empty($downloads) && !empty($downloads->data)) {
                                foreach ($downloads->data as $dl) {
                                    $download_links[] = ($dl->name ?? '') . ',' . ($dl->url ?? '');
                                }
                            }
                            $api_data["variant_download_$variant_index"] = implode('|', $download_links);
                        } catch (\Throwable $e) {}
                    }

                    $variant_index++;
                }
            }
        }

        // Gather from WP Meta as fallback
        $sku = $id ? get_post_meta($id, 'sku', true) : '';
        $price = $id ? get_post_meta($id, 'price', true) : '';
        if (empty($price) && $id) $price = get_post_meta($id, 'min_price_amount', true);
        $sale_price = $id ? get_post_meta($id, 'sale_price', true) : '';
        if (empty($sale_price) && $id) $sale_price = get_post_meta($id, 'scratch_display_amount', true);

        $stock_enabled = $id ? get_post_meta($id, 'stock_enabled', true) : '';
        $stock_quantity = $id ? get_post_meta($id, 'available_stock', true) : '';
        $allow_purchase_out_of_stock = $id ? get_post_meta($id, 'allow_out_of_stock_purchases', true) : '';
        $tax_enabled = $id ? get_post_meta($id, 'tax_enabled', true) : '';
        $tax_status = $id ? get_post_meta($id, 'tax_status', true) : '';
        
        $recurring_interval = $id ? get_post_meta($id, 'recurring_interval', true) : '';
        $recurring_period = $id ? get_post_meta($id, 'recurring_period', true) : '';
        $recurring_price = $id ? get_post_meta($id, 'recurring_price', true) : '';
        $variants = $id ? get_post_meta($id, 'variants', true) : '';
        $recurring = $id ? get_post_meta($id, 'recurring', true) : '';
        $download_files = $id ? get_post_meta($id, 'download_files', true) : '';

        // Product type fallback
        $product_type = 'simple';
        if (!empty($variants)) {
            $product_type = 'variable';
        } elseif ($recurring) {
            $product_type = 'subscription';
        }

        // Featured image
        $featured_image_url = '';
        if ($id) {
            $thumbnail_id = (int) get_post_thumbnail_id($id);
            $featured_image_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : '';
        }

        // Gallery images
        $gallery_ids = $id ? get_post_meta($id, 'gallery_images', true) : '';
        $gallery_urls = [];
        if (!empty($gallery_ids) && is_array($gallery_ids)) {
            foreach ($gallery_ids as $gallery_id) {
                $gallery_url = wp_get_attachment_url($gallery_id);
                if ($gallery_url) {
                    $gallery_urls[] = $gallery_url;
                }
            }
        }

        // Categories & Tags
        $categories = $id ? wp_get_post_terms($id, 'sc_product_category', ['fields' => 'names']) : [];
        if (is_wp_error($categories)) $categories = [];
        $tags = $id ? wp_get_post_terms($id, 'sc_product_tag', ['fields' => 'names']) : [];
        if (is_wp_error($tags)) $tags = [];

        // Format download files
        $download_files_output = '';
        if (!empty($download_files) && is_array($download_files)) {
            foreach ($download_files as $file) {
                if (!empty($file['file'])) {
                    $download_files_output .= 'file_name:' . ($file['name'] ?? '') . ',file_url:' . ($file['file'] ?? '') . ' | ';
                }
            }
            $download_files_output = rtrim($download_files_output, ' | ');
        }

        // Fallback merge
        $final_id = $id ?: $sc_id;
        $row_data = [];
        $row_data['product_id'] = $final_id;
        $row_data['sc_id'] = $sc_id;
        $row_data['product_name'] = $api_data['product_name'] ?? ($id ? get_the_title($id) : '');
        $row_data['post_title'] = $row_data['product_name'];
        $row_data['post_content'] = $id ? get_post_field('post_content', $id) : '';
        $row_data['post_excerpt'] = $id ? get_post_field('post_excerpt', $id) : '';
        $row_data['post_status'] = $id ? get_post_status($id) : 'publish';
        
        $row_data['sku'] = $api_data['sku'] ?? $sku;
        $row_data['price'] = $api_data['price'] ?? $price;
        $row_data['sale_price'] = $sale_price ?: '';
        $row_data['compare_at_price'] = $api_data['compare_at_price'] ?? '';
        
        $row_data['stock_enabled'] = $api_data['stock_enabled'] ?? ($stock_enabled ? 'yes' : 'no');
        $row_data['stock_quantity'] = $api_data['stock_quantity'] ?? ($stock_quantity ?: 0);
        $row_data['allow_purchase_out_of_stock'] = $api_data['allow_purchase_out_of_stock'] ?? ($allow_purchase_out_of_stock ? 'yes' : 'no');
        
        $row_data['tax_enabled'] = $api_data['tax_enabled'] ?? ($tax_enabled ? 'yes' : 'no');
        $row_data['tax_status'] = $api_data['tax_status'] ?? ($tax_status ?: '');
        $row_data['tax_rate'] = ''; // It's complex to resolve tax rate from SDK without extra API calls, leaving it for mapping
        
        // Populate the dynamic variant fields to the main export data array
        for ($i = 1; $i <= 50; $i++) {
            if (isset($api_data["variant_sku_$i"]) || isset($api_data["variant_price_$i"])) {
                $row_data["variant_price_$i"] = $api_data["variant_price_$i"] ?? '';
                $row_data["variant_sku_$i"] = $api_data["variant_sku_$i"] ?? '';
                $row_data["variant_stock_$i"] = $api_data["variant_stock_$i"] ?? '';
                $row_data["variant_weight_$i"] = $api_data["variant_weight_$i"] ?? '';
                $row_data["variant_media_$i"] = $api_data["variant_media_$i"] ?? '';
                $row_data["variant_purchase_limit_$i"] = $api_data["variant_purchase_limit_$i"] ?? '';
                $row_data["variant_download_enable_$i"] = $api_data["variant_download_enable_$i"] ?? '';
                $row_data["variant_download_$i"] = $api_data["variant_download_$i"] ?? '';
            }
        }
        
        $row_data['featured_image'] = $featured_image_url;
        $row_data['gallery_images'] = implode(',', $gallery_urls);
        $row_data['product_type'] = $api_data['product_type'] ?? $product_type;
        
        $row_data['recurring_interval'] = $api_data['recurring_interval'] ?? $recurring_interval;
        $row_data['recurring_period'] = $api_data['recurring_period'] ?? $recurring_period;
        $row_data['recurring_price'] = $recurring_price ?: '';
        
        $row_data['variants'] = is_array($variants) ? json_encode($variants) : $variants;
        $row_data['variant_options'] = $api_data['variant_options'] ?? '';
        
        $row_data['product_categories'] = !empty($categories) ? implode(',', $categories) : '';
        $row_data['product_tags'] = !empty($tags) ? implode(',', $tags) : '';
        $row_data['product_collections'] = $api_data['product_collections'] ?? '';
        $row_data['shipping_profile'] = $api_data['shipping_profile'] ?? '';
        
        $row_data['seo_title'] = $api_data['seo_title'] ?? '';
        $row_data['seo_description'] = $api_data['seo_description'] ?? '';
        
        $row_data['download_files'] = $download_files_output;

        SureCartExport::$export_instance->data[$input_id] = $row_data;
    }

	/**
	 * Export SureCart Orders data
	 * 
	 * @param int $id Order ID
	 * @return void
	 */
	public function getSureCartOrderDataMaster($id)
	{
		if (!is_plugin_active('surecart/surecart.php') || !class_exists('\\SureCart\\Models\\Order')) {
			return;
		}

		// Support both cloud UUID (from PostExport) and WP post ID (from WPQueryExport)
		$lookup_id = $id;
		if (is_numeric($id) && (int) $id === (float) $id && $id < 2147483647) {
			$sc_id = get_post_meta($id, 'sc_id', true);
			if ($sc_id) {
				$lookup_id = $sc_id;
			}
		}

		$order = \SureCart\Models\Order::with(['billing_address', 'shipping_address'])->find($lookup_id);
		if (!$order) {
			return;
		}


		// Get order data
		// Map internal status to user-friendly status
		$status_mapping = [
			'void' => 'canceled',
			'payment_failed' => 'failed',
			'requires_approval' => 'requires_approval',
			// 'paid' => 'paid', // Implicit
			// 'processing' => 'processing', // Implicit
			// 'draft' => 'draft' // Implicit
		];
		$order_status = $status_mapping[$order->status] ?? $order->status;
		$order_date = $order->created_at; // Default

		// Attempt to get data from Order attributes
		$total = $order->total_amount;
		$subtotal = $order->subtotal_amount;
		$tax_amount = $order->tax_amount;
		$discount_amount = $order->discount_amount;
		$shipping_amount = $order->shipping_amount;
		$currency = $order->currency;

		$billing_address = $order->billing_address;
		$shipping_address = $order->shipping_address;
		$line_items = $order->line_items;
		$payment_method = $order->payment_method;
		$payment_status = $order->payment_status;
		$transaction_id = $order->transaction_id;
		$customer_id = $order->customer_id;

		// Fallback: Fetch from Checkout if total is missing and checkout_id exists
		// IMPORTANT: Also fetch line_items and discount (for coupon) from Checkout
		$subscription_id = $order->subscription_id ?? '';
		$coupon_code = '';
		if (!empty($order->checkout_id)) {
			if (class_exists('\\SureCart\\Models\\Checkout')) {
				// Include discount to get coupon/promotion code
				$checkout = \SureCart\Models\Checkout::with(['line_items', 'billing_address', 'shipping_address', 'discount', 'promotion_codes'])->find($order->checkout_id);
				if ($checkout) {
					// Always prefer line_items from checkout (Order API often doesn't include them)
					if (!empty($checkout->line_items)) {
						$line_items = $checkout->line_items;
					}

					// Get other data only if missing from order
					if (empty($total)) {
						$total = $checkout->total_amount;
						$subtotal = $checkout->subtotal_amount;
						$tax_amount = $checkout->tax_amount;
						$discount_amount = $checkout->discount_amount;
						$shipping_amount = $checkout->shipping_amount;
						$currency = $checkout->currency;

						$billing_address = $checkout->billing_address;
						$shipping_address = $checkout->shipping_address;

						if (empty($payment_method))
							$payment_method = $checkout->payment_method;
						if (empty($transaction_id))
							$transaction_id = $checkout->payment_intent_id;
						if (empty($customer_id))
							$customer_id = $checkout->customer_id;

						// Also update date if missing from order (unlikely but safe)
						if (empty($order_date))
							$order_date = $checkout->created_at;
					}
					// Extract coupon code from checkout discount
					if (empty($coupon_code) && !empty($checkout->discount)) {
						$disc = $checkout->discount;
						// Normalise: if $disc is an object, pull its attributes array
						if (is_object($disc) && method_exists($disc, 'getAttributes')) {
							$disc_arr = $disc->getAttributes();
						} elseif (is_object($disc)) {
							$disc_arr = json_decode(wp_json_encode($disc), true) ?: [];
						} else {
							$disc_arr = (array) $disc;
						}

						// SureCart API: discount->coupon and discount->promotion are bare UUID strings.
						// We must look them up separately to get the human-readable code.
						// Priority: Promotion->code (the user-visible code e.g. "GSA100"),
						//           then Coupon->name (the coupon's internal name e.g. "Gowtham").
						$coupon_uuid = $disc_arr['coupon'] ?? null;
						$promotion_uuid = $disc_arr['promotion'] ?? null;

						// --- 1. Try Promotion model first (has the actual code field) ---
						if (!empty($promotion_uuid) && is_string($promotion_uuid) && class_exists('\SureCart\Models\Promotion')) {
							try {
								$promo_model = \SureCart\Models\Promotion::find($promotion_uuid);
								if ($promo_model) {
									$coupon_code = $promo_model->code ?? $promo_model->name ?? '';
								}
							} catch (\Throwable $e) {
								// ignore – fall through to coupon lookup
							}
						}

						// --- 2. Fall back to Coupon model (name is the coupon identifier) ---
						if (empty($coupon_code) && !empty($coupon_uuid) && is_string($coupon_uuid) && class_exists('\SureCart\Models\Coupon')) {
							try {
								$coupon_model = \SureCart\Models\Coupon::find($coupon_uuid);
								if ($coupon_model) {
									$coupon_code = $coupon_model->code ?? $coupon_model->name ?? '';
								}
							} catch (\Throwable $e) {
								// ignore
							}
						}

						// Last resort: raw UUID is better than nothing
						if (empty($coupon_code) && !empty($coupon_uuid)) {
							$coupon_code = $coupon_uuid;
						}
					}
				}
			}
		}
		// Extract subscription_id from order or first subscription line_item
		if (empty($subscription_id) && !empty($line_items)) {
			$items_arr = is_array($line_items) ? $line_items : (isset($line_items->data) ? $line_items->data : []);
			foreach ((array) $items_arr as $item) {
				$sub_id = is_object($item) ? ($item->subscription_id ?? null) : ($item['subscription_id'] ?? null);
				if (!empty($sub_id)) {
					$subscription_id = $sub_id;
					break;
				}
			}
		}
		// Line Items Conversion (Collection support, ensure import-friendly JSON)
		$line_items_output = '';

		if (is_object($line_items) && method_exists($line_items, 'toArray')) {
			$line_items = $line_items->toArray();
		} elseif (is_object($line_items) && isset($line_items->data)) {
			$line_items = $line_items->data;
		}
		if (!empty($line_items) && is_array($line_items)) {
			// Convert each item to array for consistent JSON (objects may not serialize all props)
			$items_array = [];
			foreach ($line_items as $item) {
				if (is_object($item)) {
					$items_array[] = json_decode(wp_json_encode($item), true);
				} else {
					$items_array[] = is_array($item) ? $item : (array) $item;
				}
			}
			// Sort by 'ad' (display order) or created_at to preserve line item order
			usort($items_array, function ($a, $b) {
				$a_val = $a['ad'] ?? $a['created_at'] ?? 0;
				$b_val = $b['ad'] ?? $b['created_at'] ?? 0;
				return (is_numeric($a_val) && is_numeric($b_val)) ? ($a_val <=> $b_val) : 0;
			});
			// Exclude bump/upsell items for re-import (bumps require parent product, cause checkout.invalid)
			$main_items = array_values(array_filter($items_array, function ($item) {
				$bump = $item['bump'] ?? null;
				return empty($bump);
			}));
			$line_items_output = !empty($main_items) ? wp_json_encode($main_items) : wp_json_encode($items_array);
		}


		// CUSTOMER DATA FALLBACKS
		$customer_email = $order->customer_email ?? '';
		$customer_name = '';

		if ($customer_id) {
			if (!isset($customer)) {
				$customer = \SureCart\Models\Customer::find($customer_id);
			}
			if ($customer) {
				$customer_name = $customer->name;
				if (empty($customer_email)) {
					$customer_email = $customer->email;
				}
			}
		}

		if (empty($customer_email) && !empty($order->checkout_id)) {
			if (!isset($checkout)) {
				$checkout = \SureCart\Models\Checkout::with(['billing_address', 'shipping_address'])->find($order->checkout_id);
			}
			if ($checkout) {
				$customer_email = $checkout->email;
			}
		}

		// Address Conversion Logic fallback to Checkout and Customer
		if (empty((array) $billing_address) && !empty($order->checkout_id)) {
			if (!isset($checkout)) {
				$checkout = \SureCart\Models\Checkout::with(['billing_address', 'shipping_address'])->find($order->checkout_id);
			}
			if ($checkout) {
				$billing_address = $checkout->billing_address;
			}
		}
		if (empty((array) $billing_address) && $customer_id) {
			if (!isset($customer)) {
				$customer = \SureCart\Models\Customer::find($customer_id);
			}
			if ($customer) {
				$billing_address = $customer->billing_address;
			}
		}

		if (empty((array) $shipping_address) && !empty($order->checkout_id)) {
			if (!isset($checkout)) {
				$checkout = \SureCart\Models\Checkout::with(['billing_address', 'shipping_address'])->find($order->checkout_id);
			}
			if ($checkout) {
				$shipping_address = $checkout->shipping_address;
			}
		}
		if (empty((array) $shipping_address) && $customer_id) {
			if (!isset($customer)) {
				$customer = \SureCart\Models\Customer::find($customer_id);
			}
			if ($customer) {
				$shipping_address = $customer->shipping_address;
			}
		}

		// Final fallback for billing: if still empty and matches shipping
		if (empty((array) $billing_address) && !empty((array) $shipping_address)) {
			// Check order attributes for billing_matches_shipping
			$attributes = $order->getAttributes();
			$checkout_attributes = isset($checkout) ? $checkout->getAttributes() : [];

			if (!empty($attributes['billing_matches_shipping']) || !empty($checkout_attributes['billing_matches_shipping'])) {
				$billing_address = $shipping_address;
			}
		}


		// Billing Address Conversion
		if (is_object($billing_address) && method_exists($billing_address, 'toArray')) {
			$billing_address = $billing_address->toArray();
		} elseif (is_object($billing_address) && isset($billing_address->data)) {
			$billing_address = (array) $billing_address->data;
		} elseif (is_object($billing_address)) {
			$billing_address = json_decode(wp_json_encode($billing_address), true);
		} else {
			$billing_address = (array) $billing_address;
		}

		// Shipping Address Conversion
		if (is_object($shipping_address) && method_exists($shipping_address, 'toArray')) {
			$shipping_address = $shipping_address->toArray();
		} elseif (is_object($shipping_address) && isset($shipping_address->data)) {
			$shipping_address = (array) $shipping_address->data;
		} elseif (is_object($shipping_address)) {
			$shipping_address = json_decode(wp_json_encode($shipping_address), true);
		} else {
			$shipping_address = (array) $shipping_address;
		}


		// Extract address fields using SureCart's actual property names (line_1/address_1, line_2/address_2)
		$billing_name = $billing_address['name'] ?? '';
		$billing_name_parts = explode(' ', trim($billing_name), 2);
		$billing_first_name = $billing_name_parts[0] ?? '';
		$billing_last_name = $billing_name_parts[1] ?? '';
		$billing_address_line_1 = $billing_address['line_1'] ?? $billing_address['address_1'] ?? '';
		$billing_address_line_2 = $billing_address['line_2'] ?? $billing_address['address_2'] ?? '';
		$billing_city = $billing_address['city'] ?? '';
		$billing_state = $billing_address['state'] ?? '';
		$billing_postal_code = $billing_address['postal_code'] ?? '';
		$billing_country = $billing_address['country'] ?? '';

		$shipping_name = $shipping_address['name'] ?? '';
		$shipping_name_parts = explode(' ', $shipping_name, 2);
		$shipping_first_name = $shipping_name_parts[0] ?? '';
		$shipping_last_name = $shipping_name_parts[1] ?? '';
		$shipping_address_line_1 = $shipping_address['line_1'] ?? $shipping_address['address_1'] ?? '';
		$shipping_address_line_2 = $shipping_address['line_2'] ?? $shipping_address['address_2'] ?? '';
		$shipping_city = $shipping_address['city'] ?? '';
		$shipping_state = $shipping_address['state'] ?? '';
		$shipping_postal_code = $shipping_address['postal_code'] ?? '';
		$shipping_country = $shipping_address['country'] ?? '';

		$order_date = $order->created_at;
		// Convert Unix timestamp to MySQL datetime for import compatibility
		if (is_numeric($order_date)) {
			$order_date = gmdate('Y-m-d H:i:s', intval($order_date));
		} elseif (is_string($order_date) && preg_match('/^\d{10,11}$/', trim($order_date))) {
			$order_date = gmdate('Y-m-d H:i:s', intval($order_date));
		}

		// Fallback customer_name from billing/shipping if customer->name empty
		if (empty(trim($customer_name))) {
			$customer_name = trim($billing_first_name . ' ' . $billing_last_name);
		}
		if (empty(trim($customer_name))) {
			$customer_name = trim($shipping_first_name . ' ' . $shipping_last_name);
		}

		// Normalize payment_method: SureCart may return processor UUID; import expects "card", "paypal", etc.
		if (!empty($payment_method) && preg_match('/^[a-f0-9\-]{36}$/i', trim($payment_method))) {
			$payment_method = 'card';
		}

		// Set export data
		SureCartExport::$export_instance->data[$id]['sc_id'] = $order->id ?? $lookup_id ?? $id;
		SureCartExport::$export_instance->data[$id]['order_id'] = $id;
		SureCartExport::$export_instance->data[$id]['order_number'] = $order_number ?: '';
		SureCartExport::$export_instance->data[$id]['order_status'] = $order_status ?: 'pending';
		SureCartExport::$export_instance->data[$id]['order_date'] = $order_date;
		SureCartExport::$export_instance->data[$id]['order_total'] = $total ?: 0;
		SureCartExport::$export_instance->data[$id]['order_subtotal'] = $subtotal ?: 0;
		SureCartExport::$export_instance->data[$id]['order_tax'] = $tax_amount ?: 0;
		SureCartExport::$export_instance->data[$id]['order_shipping'] = $shipping_amount ?: 0;
		SureCartExport::$export_instance->data[$id]['currency'] = $currency ?: '';
		SureCartExport::$export_instance->data[$id]['customer_id'] = $customer_id ?: '';
		SureCartExport::$export_instance->data[$id]['customer_name'] = $customer_name ?: '';
		SureCartExport::$export_instance->data[$id]['customer_email'] = $customer_email;
		SureCartExport::$export_instance->data[$id]['billing_first_name'] = $billing_first_name;
		SureCartExport::$export_instance->data[$id]['billing_last_name'] = $billing_last_name;
		SureCartExport::$export_instance->data[$id]['billing_address_line_1'] = $billing_address_line_1;
		SureCartExport::$export_instance->data[$id]['billing_address_line_2'] = $billing_address_line_2;
		SureCartExport::$export_instance->data[$id]['billing_city'] = $billing_city;
		SureCartExport::$export_instance->data[$id]['billing_state'] = $billing_state;
		SureCartExport::$export_instance->data[$id]['billing_postal_code'] = $billing_postal_code;
		SureCartExport::$export_instance->data[$id]['billing_country'] = $billing_country;
		SureCartExport::$export_instance->data[$id]['shipping_first_name'] = $shipping_first_name;
		SureCartExport::$export_instance->data[$id]['shipping_last_name'] = $shipping_last_name;
		SureCartExport::$export_instance->data[$id]['shipping_address_line_1'] = $shipping_address_line_1;
		SureCartExport::$export_instance->data[$id]['shipping_address_line_2'] = $shipping_address_line_2;
		SureCartExport::$export_instance->data[$id]['shipping_city'] = $shipping_city;
		SureCartExport::$export_instance->data[$id]['shipping_state'] = $shipping_state;
		SureCartExport::$export_instance->data[$id]['shipping_postal_code'] = $shipping_postal_code;
		SureCartExport::$export_instance->data[$id]['shipping_country'] = $shipping_country;
		SureCartExport::$export_instance->data[$id]['total'] = $total ?: 0;
		SureCartExport::$export_instance->data[$id]['subtotal'] = $subtotal ?: 0;
		SureCartExport::$export_instance->data[$id]['tax_amount'] = $tax_amount ?: 0;
		SureCartExport::$export_instance->data[$id]['discount_amount'] = $discount_amount ?: 0;
		SureCartExport::$export_instance->data[$id]['shipping_amount'] = $shipping_amount ?: 0;
		SureCartExport::$export_instance->data[$id]['payment_method'] = $payment_method;
		SureCartExport::$export_instance->data[$id]['payment_status'] = $payment_status ?: 'pending';
		SureCartExport::$export_instance->data[$id]['transaction_id'] = $transaction_id;
		SureCartExport::$export_instance->data[$id]['line_items'] = $line_items_output;
		SureCartExport::$export_instance->data[$id]['subscription_id'] = $subscription_id ?: '';
		SureCartExport::$export_instance->data[$id]['coupon_code'] = $coupon_code ?: '';

		// Metadata is array in model?
		$metadata_output = '';
		$metadata = (array) ($order->metadata ?? []);
		if (!empty($metadata)) {
			foreach ($metadata as $key => $value) {
				$metadata_output .= $key . ':' . (is_array($value) ? json_encode($value) : $value) . '|';
			}
		}
		SureCartExport::$export_instance->data[$id]['order_meta'] = rtrim($metadata_output, '|');
	}

	/**
	 * Export SureCart Customers data
	 * 
	 * @param int $id Customer ID
	 * @return void
	 */
	public function getSureCartCustomerDataMaster($id)
	{
		if (!is_plugin_active('surecart/surecart.php') || !class_exists('\\SureCart\\Models\\Customer')) {
			return;
		}

		// Support both cloud UUID (from PostExport) and WP post ID (from WPQueryExport)
		$lookup_id = $id;
		if (is_numeric($id) && (int) $id === (float) $id && $id < 2147483647) {
			$sc_id = get_post_meta($id, 'sc_id', true);
			if ($sc_id) {
				$lookup_id = $sc_id;
			}
		}

		$customer = \SureCart\Models\Customer::with(['billing_address', 'shipping_address'])->find($lookup_id);
		// Handle WP_Error or empty result - try post meta sc_id if first find failed
		if ((is_wp_error($customer) || !$customer) && $lookup_id === $id) {
			$sc_id = get_post_meta($id, 'sc_id', true);
			if ($sc_id) {
				$customer = \SureCart\Models\Customer::with(['billing_address', 'shipping_address'])->find($sc_id);
				if ($customer) {
					$lookup_id = $sc_id;
				}
			}
		}

		// Use meta fallback if still no valid customer object
		$use_meta_fallback = false;
		if (is_wp_error($customer) || !$customer) {
			$use_meta_fallback = true;
		}
		$purchase_count = 0;
		$lifetime_value = 0;
		$order_ids = '';
		$notes = '';

		if (!$use_meta_fallback) {
			// Get customer data from Model
			$customer_email = $customer->email ?? '';
			$customer_name = $customer->name ?? '';
			$first_name = $customer->first_name ?? '';
			$last_name = $customer->last_name ?? '';
			$user_id = $customer->wp_user_id ?? 0;
			// Fallback: If Model has no user ID, try lookup by email
			if (empty($user_id) && !empty($customer_email)) {
				$user = get_user_by('email', $customer_email);
				if ($user) {
					$user_id = $user->ID;
				}
			}
			$phone_number = $customer->phone ?? $customer->phone_number ?? '';
			$date_created = $customer->created_at ?? '';

			// ── Shipping Address ─────────────────────────────────────────
			// SureCart Customer API returns shipping_address as a full object with
			// line_1, line_2, city, state, postal_code, country, name.
			$shipping_address = $customer->shipping_address ?? [];
			if (is_object($shipping_address) && method_exists($shipping_address, 'toArray')) {
				$shipping_address = $shipping_address->toArray();
			} elseif (is_object($shipping_address)) {
				$shipping_address = json_decode(wp_json_encode($shipping_address), true);
			} else {
				$shipping_address = (array) $shipping_address;
			}

			// Tier 2: raw getAttributes() fallback
			if (empty($shipping_address) || empty($shipping_address['line_1'] ?? $shipping_address['address_1'] ?? '')) {
				$attrs = method_exists($customer, 'getAttributes') ? $customer->getAttributes() : [];
				if (!empty($attrs['shipping_address'])) {
					$sa = is_array($attrs['shipping_address'])
						? $attrs['shipping_address']
						: (is_object($attrs['shipping_address'])
							? json_decode(wp_json_encode($attrs['shipping_address']), true)
							: []);
					if (!empty($sa)) {
						$shipping_address = $sa;
					}
				}
			}

			// Tier 3: WP post meta
			if (empty($shipping_address) || empty($shipping_address['line_1'] ?? $shipping_address['address_1'] ?? '')) {
				$meta_shipping = get_post_meta($id, 'sc_shipping_address', true);
				if (is_array($meta_shipping) && !empty($meta_shipping)) {
					$shipping_address = $meta_shipping;
				}
			}

			// ── Billing Address ─────────────────────────────────────────
			// NOTE: SureCart Customer API always returns billing_address as []
			// (confirmed via debug log). The actual stored address comes via
			// billing_matches_shipping=true → use shipping_address as billing.
			$billing_address = $customer->billing_address ?? [];
			if (is_object($billing_address) && method_exists($billing_address, 'toArray')) {
				$billing_address = $billing_address->toArray();
			} elseif (is_object($billing_address)) {
				$billing_address = json_decode(wp_json_encode($billing_address), true);
			} else {
				$billing_address = (array) $billing_address;
			}

			// If billing is empty, check billing_matches_shipping flag (or just copy shipping)
			if (empty($billing_address) || empty($billing_address['line_1'] ?? $billing_address['address_1'] ?? '')) {
				$attrs = $attrs ?? (method_exists($customer, 'getAttributes') ? $customer->getAttributes() : []);
				$billing_matches_shipping = !empty($attrs['billing_matches_shipping']);

				if ($billing_matches_shipping || !empty($shipping_address)) {
					$billing_address = $shipping_address;
				}
			}

			// Final WP post meta fallback for billing
			if (empty($billing_address) || empty($billing_address['line_1'] ?? $billing_address['address_1'] ?? '')) {
				$meta_billing = get_post_meta($id, 'sc_billing_address', true);
				if (is_array($meta_billing) && !empty($meta_billing)) {
					$billing_address = $meta_billing;
				}
			}


			// Metadata
			$metadata = (array) ($customer->metadata ?? []);

			// Notes from customer
			$notes = $customer->notes ?? '';
			if (is_array($notes)) {
				$notes = implode("\n", $notes);
			}

			// Fetch purchase_count, lifetime_value, order_ids from Order API
			if (class_exists('\\SureCart\\Models\\Order') && !empty($customer->id)) {
				try {
					$orders = \SureCart\Models\Order::where(['customer_id' => $customer->id, 'limit' => 500])->get();
					if (!empty($orders)) {
						$order_id_list = [];
						$total = 0;
						foreach ($orders as $o) {
							$order_id_list[] = $o->id;
							$total += (int) ($o->total_amount ?? 0);
						}
						$purchase_count = count($order_id_list);
						$lifetime_value = $total / 100; // API amounts are typically in cents
						$order_ids = implode(',', $order_id_list);
					}
				} catch (\Throwable $e) {
				}
			}
		} else {
			// Fallback to Post Meta
			$customer_email = get_post_meta($id, 'sc_customer_email', true);
			$first_name = get_post_meta($id, 'sc_first_name', true);
			$last_name = get_post_meta($id, 'sc_last_name', true);
			$customer_name = $first_name . ' ' . $last_name;
			if (empty(trim($customer_name))) {
				$customer_name = get_post_meta($id, 'sc_customer_name', true);
			}
			if (empty(trim($customer_name))) {
				$customer_name = get_the_title($id);
			}

			// User ID Lookup
			$user_id = get_post_meta($id, 'sc_wp_user_id', true);
			if (empty($user_id) && !empty($customer_email)) {
				$user = get_user_by('email', $customer_email);
				if ($user) {
					$user_id = $user->ID;
				}
			}
			if (!$user_id)
				$user_id = 0;

			$phone_number = get_post_meta($id, 'sc_phone_number', true);
			$date_created = get_the_date('Y-m-d H:i:s', $id);

			// Construct billing address from meta
			// 1. Try generic array field
			$meta_billing = get_post_meta($id, 'sc_billing_address', true);
			if (is_array($meta_billing)) {
				$billing_address = [
					'address_1' => $meta_billing['line_1'] ?? $meta_billing['address_1'] ?? '',
					'address_2' => $meta_billing['line_2'] ?? $meta_billing['address_2'] ?? '',
					'city' => $meta_billing['city'] ?? '',
					'state' => $meta_billing['state'] ?? '',
					'postal_code' => $meta_billing['postal_code'] ?? '',
					'country' => $meta_billing['country'] ?? '',
				];
			} else {
				// 2. Try individual fields
				$billing_address = [
					'address_1' => get_post_meta($id, 'sc_billing_address_line_1', true),
					'address_2' => get_post_meta($id, 'sc_billing_address_line_2', true),
					'city' => get_post_meta($id, 'sc_billing_city', true),
					'state' => '',
					'postal_code' => '',
					'country' => get_post_meta($id, 'sc_billing_country', true),
				];
			}

			// Construct shipping address from meta
			// 1. Try generic array field
			$meta_shipping = get_post_meta($id, 'sc_shipping_address', true);
			if (is_array($meta_shipping)) {
				$shipping_address = [
					'address_1' => $meta_shipping['line_1'] ?? $meta_shipping['address_1'] ?? '',
					'address_2' => $meta_shipping['line_2'] ?? $meta_shipping['address_2'] ?? '',
					'city' => $meta_shipping['city'] ?? '',
					'state' => $meta_shipping['state'] ?? '',
					'postal_code' => $meta_shipping['postal_code'] ?? '',
					'country' => $meta_shipping['country'] ?? '',
				];
			} else {
				// 2. Try individual fields
				$shipping_address = [
					'address_1' => get_post_meta($id, 'sc_shipping_address_line_1', true),
					'address_2' => get_post_meta($id, 'sc_shipping_address_line_2', true),
					'city' => get_post_meta($id, 'sc_shipping_city', true),
					'state' => '',
					'postal_code' => '',
					'country' => get_post_meta($id, 'sc_shipping_country', true),
				];
			}

			// Metadata (raw or processed?)
			$metadata = [];
			// Maybe sc_metadata?
			$meta_json = get_post_meta($id, 'sc_metadata', true);
			if ($meta_json) {
				if (is_array($meta_json))
					$metadata = $meta_json;
				else
					$metadata = json_decode($meta_json, true) ?: [];
			}

			$notes = get_post_meta($id, 'sc_notes', true) ?: '';
		}


		$billing_address_line_1 = $billing_address['line_1'] ?? $billing_address['address_1'] ?? '';
		$billing_address_line_2 = $billing_address['line_2'] ?? $billing_address['address_2'] ?? '';
		$billing_city = $billing_address['city'] ?? '';
		$billing_state = $billing_address['state'] ?? '';
		$billing_postal_code = $billing_address['postal_code'] ?? '';
		$billing_country = $billing_address['country'] ?? '';

		$shipping_address_line_1 = $shipping_address['line_1'] ?? $shipping_address['address_1'] ?? '';
		$shipping_address_line_2 = $shipping_address['line_2'] ?? $shipping_address['address_2'] ?? '';
		$shipping_city = $shipping_address['city'] ?? '';
		$shipping_state = $shipping_address['state'] ?? '';
		$shipping_postal_code = $shipping_address['postal_code'] ?? '';
		$shipping_country = $shipping_address['country'] ?? '';

		$user_login = '';
		$user_email = '';
		if ($user_id > 0) {
			$user_data = get_userdata($user_id);
			if ($user_data) {
				$user_login = $user_data->user_login;
				$user_email = $user_data->user_email;
			}
		}

		// Set export data
		$customer_sc_id = !$use_meta_fallback ? ($customer->id ?? '') : get_post_meta($id, 'sc_id', true);
		SureCartExport::$export_instance->data[$id]['sc_id'] = $customer_sc_id ?: '';
		SureCartExport::$export_instance->data[$id]['customer_id'] = $id;
		SureCartExport::$export_instance->data[$id]['customer_email'] = $customer_email ?: '';
		SureCartExport::$export_instance->data[$id]['customer_name'] = $customer_name ?: '';
		SureCartExport::$export_instance->data[$id]['first_name'] = $first_name ?: '';
		SureCartExport::$export_instance->data[$id]['last_name'] = $last_name ?: '';
		SureCartExport::$export_instance->data[$id]['user_id'] = $user_id ?: 0;
		SureCartExport::$export_instance->data[$id]['user_login'] = $user_login;
		SureCartExport::$export_instance->data[$id]['user_email'] = $user_email;
		SureCartExport::$export_instance->data[$id]['phone_number'] = $phone_number ?: '';
		SureCartExport::$export_instance->data[$id]['date_created'] = $date_created;
		SureCartExport::$export_instance->data[$id]['billing_address_line_1'] = $billing_address_line_1 ?: '';
		SureCartExport::$export_instance->data[$id]['billing_address_line_2'] = $billing_address_line_2 ?: '';
		SureCartExport::$export_instance->data[$id]['billing_city'] = $billing_city ?: '';
		SureCartExport::$export_instance->data[$id]['billing_state'] = $billing_state ?: '';
		SureCartExport::$export_instance->data[$id]['billing_postal_code'] = $billing_postal_code ?: '';
		SureCartExport::$export_instance->data[$id]['billing_country'] = $billing_country ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_address_line_1'] = $shipping_address_line_1 ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_address_line_2'] = $shipping_address_line_2 ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_city'] = $shipping_city ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_state'] = $shipping_state ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_postal_code'] = $shipping_postal_code ?: '';
		SureCartExport::$export_instance->data[$id]['shipping_country'] = $shipping_country ?: '';
		SureCartExport::$export_instance->data[$id]['purchase_count'] = $purchase_count;
		SureCartExport::$export_instance->data[$id]['lifetime_value'] = $lifetime_value;
		SureCartExport::$export_instance->data[$id]['order_ids'] = $order_ids ?: '';
		SureCartExport::$export_instance->data[$id]['notes'] = $notes ?: '';

		$metadata_output = '';
		if (!empty($metadata)) {
			foreach ($metadata as $key => $value) {
				$metadata_output .= $key . ':' . (is_array($value) ? json_encode($value) : $value) . '|';
			}
		}
		SureCartExport::$export_instance->data[$id]['customer_meta'] = rtrim($metadata_output, '|');
	}

	/**
	 * Export SureCart Subscriptions data
	 * 
	 * @param int $id Subscription ID
	 * @return void
	 */
	public function getSureCartSubscriptionDataMaster($id)
	{
		if (!is_plugin_active('surecart/surecart.php') || !class_exists('\\SureCart\\Models\\Subscription')) {
			return;
		}

		$subscription = \SureCart\Models\Subscription::find($id);
		if (!$subscription) {
			return;
		}

		// Get subscription data from model
		$customer_id = $subscription->customer_id;
		$product_id = $subscription->product_id; // Check if this exists, often it's line items or plan_id
		// Wait, subscriptions in SureCart are usually tied to 'plan' or match the previous logic.
		// Assuming properties are similar to meta keys
		$order_id = $subscription->order_id;
		$subscription_status = $subscription->status;
		$interval = $subscription->interval; // monthly, yearly, etc.
		$interval_count = $subscription->interval_count ?? 1; // e.g. every 1 month

		// Pricing might be tricky, let's assume direct properties for now
		// Or if it's not available, empty is fine rather than wrong data.
		// $price = $subscription->amount ?? 0; // Check model properties in future if needed

		$start_date = $subscription->created_at;
		$end_date = $subscription->ends_at;
		$next_payment_date = $subscription->next_charge_at;
		$trial_end_date = $subscription->trial_ends_at;
		$cancel_date = $subscription->canceled_at;
		// $cancel_reason = $subscription->cancel_reason; // verify if exists

		// $billing_cycle_count = ?
		// $total_payments = ?

		// Get product name (if product_id is valid post ID or surecart product ID?)
		// SureCart Products are posts.
		$product_name = '';
		if ($product_id) {
			$product_name = get_the_title($product_id); // This works if product_id is a WP Post ID
			if (empty($product_name)) {
				// Try looking up surecart product?
			}
		}

		// Set export data
		SureCartExport::$export_instance->data[$id]['subscription_id'] = $id;
		// Customer Name
		$customer_name = '';
		if ($customer_id) {
			$customer = \SureCart\Models\Customer::find($customer_id);
			if ($customer) {
				SureCartExport::$export_instance->data[$id]['customer_email'] = $customer->email;
				$customer_name = $customer->name;
			}
		}

		SureCartExport::$export_instance->data[$id]['product_id'] = $product_id ?: '';
		SureCartExport::$export_instance->data[$id]['product_name'] = $product_name;
		SureCartExport::$export_instance->data[$id]['customer_name'] = $customer_name;
		SureCartExport::$export_instance->data[$id]['renewal_amount'] = $subscription->amount_amount ?? 0;
		SureCartExport::$export_instance->data[$id]['currency'] = $subscription->currency ?? '';
		SureCartExport::$export_instance->data[$id]['trial_end_date'] = $trial_end_date;
		SureCartExport::$export_instance->data[$id]['current_period_start'] = $subscription->current_period_starts_at ?? '';
		SureCartExport::$export_instance->data[$id]['current_period_end'] = $subscription->current_period_ends_at ?? '';
		SureCartExport::$export_instance->data[$id]['order_id'] = $order_id ?: '';
		SureCartExport::$export_instance->data[$id]['subscription_status'] = $subscription_status ?: 'active';
		SureCartExport::$export_instance->data[$id]['interval'] = $interval ?: '';
		// SureCartExport::$export_instance->data[$id]['period'] = $period ?: 'month';
		// SureCartExport::$export_instance->data[$id]['price'] = $price ?: 0;
		SureCartExport::$export_instance->data[$id]['start_date'] = $start_date;
		SureCartExport::$export_instance->data[$id]['end_date'] = $end_date ?: '';
		SureCartExport::$export_instance->data[$id]['next_payment_date'] = $next_payment_date ?: '';
		SureCartExport::$export_instance->data[$id]['trial_end_date'] = $trial_end_date ?: '';
		SureCartExport::$export_instance->data[$id]['cancel_date'] = $cancel_date ?: '';
		// SureCartExport::$export_instance->data[$id]['cancel_reason'] = $cancel_reason ?: '';
		// SureCartExport::$export_instance->data[$id]['billing_cycle_count'] = $billing_cycle_count ?: 0;
		// SureCartExport::$export_instance->data[$id]['total_payments'] = $total_payments ?: 0;

		$metadata_output = '';
		if (!empty($subscription->metadata) && is_array($subscription->metadata)) {
			foreach ($subscription->metadata as $key => $value) {
				$metadata_output .= $key . ':' . (is_array($value) ? json_encode($value) : $value) . '|';
			}
		}
		SureCartExport::$export_instance->data[$id]['subscription_meta'] = rtrim($metadata_output, '|');
	}

	/**
	 * Export SureCart Coupons data
	 * 
	 * @param int $id Coupon ID
	 * @return void
	 */
	public function getSureCartCouponDataMaster($id)
	{
		// 1. Determine if $id is a WP Post ID or a SureCart UUID
		$is_uuid = !is_numeric($id) && strlen($id) > 10; // Simple heuristic for UUID

		$coupon_code = '';
		$coupon_model = null;

		if (!$is_uuid) {
			// It's a WP Post ID (Imported Coupon)
			$coupon_code = get_post_meta($id, 'sc_coupon_code', true);

			// Try getting model via meta
			if (is_plugin_active('surecart/surecart.php') && class_exists('\\SureCart\\Models\\Coupon')) {
				$sc_id = get_post_meta($id, 'sc_id', true);
				if (!empty($sc_id)) {
					try {
						$coupon_model = \SureCart\Models\Coupon::find($sc_id);
					} catch (\Exception $e) { /* ignore */
					}
				}
			}
		} else {
			// It's a SureCart UUID (Native Coupon exported via custom flow?)
			// We cannot use get_post_meta on a UUID.
			if (is_plugin_active('surecart/surecart.php') && class_exists('\\SureCart\\Models\\Coupon')) {
				try {
					$coupon_model = \SureCart\Models\Coupon::find($id);
				} catch (\Exception $e) { /* ignore */
				}
			}
		}

		if (empty($coupon_code)) {
			if ($coupon_model) {
				$coupon_code = $coupon_model->code;
			} else {
				// Fallback to title
				$post = get_post($id);
				if ($post) {
					$coupon_code = $post->post_title;
				}
			}
		}


		// Define mapping: Export Key => [Meta Key, Model Property]
		$field_map = [
			'promotion_codes' => ['sc_promotion_code', 'promotion_code'], // New field
			'discount_type' => ['sc_discount_type', 'discount_type'],
			'discount_amount' => ['sc_discount_amount', 'amount'],
			'status' => ['sc_status', 'status'],
			'usage_limit' => ['sc_usage_limit', 'max_redemptions'],
			'usage_count' => ['sc_usage_count', 'times_redeemed'],
			'usage_limit_per_user' => ['sc_usage_limit_per_user', 'max_redemptions_per_customer'],
			'start_date' => ['sc_start_date', 'start_date'],
			'end_date' => ['sc_end_date', 'end_date'],
			'minimum_amount' => ['sc_minimum_amount', 'min_subtotal_amount'], // FIXED: min_amount -> min_subtotal_amount
			'maximum_amount' => ['sc_maximum_amount', 'max_subtotal_amount'], // FIXED: max_amount -> max_subtotal_amount
			'applies_to' => ['sc_applies_to', 'applies_to'],
			'duration' => ['sc_duration', 'duration'],
			'duration_in_months' => ['sc_duration_in_months', 'duration_in_months'],
			'currency' => ['sc_currency', 'currency'],
			'archived' => ['sc_archived', 'archived'],
			// Arrays need special handling
			'product_requirements' => ['sc_product_ids', 'product_ids'],
			'excluded_products' => ['sc_excluded_product_ids', 'excluded_product_ids'],
			'category_requirements' => ['sc_category_ids', 'category_ids'],
			'excluded_categories' => ['sc_excluded_category_ids', 'excluded_category_ids']
		];

		// Initialize data array
		SureCartExport::$export_instance->data[$id]['coupon_id'] = $id;

		// 1. Code
		$code_val = '';
		if (!$is_uuid) {
			$code_val = get_post_meta($id, 'sc_coupon_code', true);
		}
		if (empty($code_val) && $coupon_model) {
			$code_val = $coupon_model->code ?? $coupon_model->promotion_code ?? $coupon_model->name;
		}
		if (empty($code_val) && !$is_uuid) {
			$post = get_post($id);
			if ($post)
				$code_val = $post->post_title;
		}
		SureCartExport::$export_instance->data[$id]['coupon_code'] = $code_val;

		// NEW: Promotion Codes (if distinct from coupon_code)
		// Usually coupon_code IS the promotion code. But if user requests it separate:
		$promo_codes_val = '';
		if (!$is_uuid) {
			$promo_codes_val = get_post_meta($id, 'sc_promotion_code', true);
		}
		if (empty($promo_codes_val) && $coupon_model) {
			$p_code = $coupon_model->promotion_code ?? null;
			if (!empty($p_code)) {
				$promo_codes_val = $p_code;
			} else {
				$promo_codes_val = $code_val;
			}
		}
		$promo_response = \SureCart::request('promotions', [
			'method' => 'GET',
			'query' => [
				'coupon' => $sc_id
			]
		]);
		$promotion_code = [];

		foreach ($promo_response->data as $promo) {

			$usable = true;

			if (!empty($promo->archived)) {
				continue;
			}

			if (
				!empty($promo->max_redemptions) &&
				$promo->times_redeemed >= $promo->max_redemptions
			) {
				continue;
			}

			$promotion_code[] = $promo->code;

		}
		SureCartExport::$export_instance->data[$id]['promotion_codes'] = $promo_codes_val;

		// 2. Discount Type & Amount
		$disc_type = '';
		$disc_amount = '';
		if (!$is_uuid) {
			$disc_type = get_post_meta($id, 'sc_discount_type', true);
			$disc_amount = get_post_meta($id, 'sc_discount_amount', true);
		}

		if (empty($disc_type) && $coupon_model) {
			if (!empty($coupon_model->percent_off)) {
				$disc_type = 'percentage';
				$disc_amount = $coupon_model->percent_off;
			} elseif (!empty($coupon_model->amount_off)) {
				$disc_type = 'fixed';
				$disc_amount = $coupon_model->amount_off;
			} else {
				$disc_type = 'fixed';
				$disc_amount = 0;
			}
		}
		SureCartExport::$export_instance->data[$id]['discount_type'] = $disc_type;
		SureCartExport::$export_instance->data[$id]['discount_amount'] = $disc_amount;

		// 3. Status
		$status = '';
		if (!$is_uuid) {
			$status = get_post_meta($id, 'sc_status', true);
		}
		if (empty($status) && $coupon_model) {
			if (!empty($coupon_model->archived)) {
				$status = 'archived';
			} elseif (!empty($coupon_model->expired)) {
				$status = 'expired';
			} else {
				$status = 'active';
			}
		}
		SureCartExport::$export_instance->data[$id]['status'] = $status;

		// 4. Dates
		$start_date = '';
		if (!$is_uuid) {
			$start_date = get_post_meta($id, 'sc_start_date', true);
		}
		if (empty($start_date) && $coupon_model) {
			$start_date = $coupon_model->created_at;
			if (is_numeric($start_date))
				$start_date = date('Y-m-d H:i:s', $start_date);
		}
		SureCartExport::$export_instance->data[$id]['start_date'] = $start_date;

		$end_date = '';
		if (!$is_uuid) {
			$end_date = get_post_meta($id, 'sc_end_date', true);
		}
		if (empty($end_date) && $coupon_model) {
			$end_date = $coupon_model->redeem_by;
			if (is_numeric($end_date))
				$end_date = date('Y-m-d H:i:s', $end_date);
		}
		SureCartExport::$export_instance->data[$id]['end_date'] = $end_date;

		// 5. Limits & Amounts
		// Iterate through map
		foreach ($field_map as $export_key => $sources) {
			$meta_key = $sources[0];
			$model_prop = $sources[1];

			// Skip manually handled fields
			if (in_array($export_key, ['promotion_codes', 'discount_type', 'discount_amount', 'status', 'start_date', 'end_date']))
				continue;

			$val = '';
			if (!$is_uuid) {
				$val = get_post_meta($id, $meta_key, true);
			}
			if (empty($val) && $coupon_model) {
				$p_val = $coupon_model->$model_prop ?? null;
				if (!is_null($p_val)) {
					if (is_array($p_val))
						$val = implode(',', $p_val);
					else
						$val = $p_val;
				}
			}
			SureCartExport::$export_instance->data[$id][$export_key] = $val;
		}

		// 6. Applies To
		// (Handled in loop above via field map? No, appies_to needs logic?)
		// Actually, field map handles basic scalar. Check logic below.

		// Re-check logic for applies_to if logic is complex
		$applies_to = '';
		if (!$is_uuid) {
			$applies_to = get_post_meta($id, 'sc_applies_to', true);
		}
		if (empty($applies_to) && $coupon_model) {
			$applies_to = $coupon_model->filter_match_type ?? 'all';
		}
		SureCartExport::$export_instance->data[$id]['applies_to'] = $applies_to ?: 'all';


		// 7. First Order Only
		$first_order = '';
		if (!$is_uuid) {
			$first_order = get_post_meta($id, 'sc_first_order_only', true);
		}
		if ($first_order === '' && $coupon_model) {
			$first_order = $coupon_model->first_order_only ?? 0;
		}
		SureCartExport::$export_instance->data[$id]['first_order_only'] = $first_order;


		// Handle Coupon Meta (JSON)
		$sc_metadata = '';
		if (!$is_uuid) {
			$sc_metadata = get_post_meta($id, 'sc_metadata', true);
		}
		if (empty($sc_metadata) && $coupon_model) {
			$sc_metadata = $coupon_model->metadata;
		}

		$metadata_output = '';
		if (!empty($sc_metadata)) {
			$sc_metadata = (array) $sc_metadata;
			foreach ($sc_metadata as $key => $value) {
				$metadata_output .= $key . ':' . (is_array($value) ? json_encode($value) : $value) . '|';
			}
		}
		SureCartExport::$export_instance->data[$id]['coupon_meta'] = rtrim($metadata_output, '|');
	}
	/**
	 * Export SureCart Reports (Sales / Earnings / Tax / Fees)
	 * 
	 * @param string $report_type Type of report (sales, earnings, tax, fees, gateway_wise, product_wise)
	 * @param string $start_date Start date for report
	 * @param string $end_date End date for report
	 * @return void
	 */
	public function getSureCartReportsDataMaster($report_type = 'sales', $start_date = '', $end_date = '')
	{
		global $wpdb;

		if (!is_plugin_active('surecart/surecart.php')) {
			return;
		}

		$orders_table = $wpdb->prefix . 'posts';
		$postmeta_table = $wpdb->prefix . 'postmeta';

		// Set default date range if not provided
		if (empty($start_date)) {
			$start_date = date('Y-m-d', strtotime('-30 days'));
		}
		if (empty($end_date)) {
			$end_date = current_time('mysql');
		}

		$date_condition = $wpdb->prepare(
			"AND p.post_date >= %s AND p.post_date <= %s",
			$start_date,
			$end_date
		);

		$reports_data = array();
		$index = 0;

		switch ($report_type) {
			case 'sales':
			case 'earnings':
				// Get sales/earnings by date
				$query = "
					SELECT 
						DATE(p.post_date) as date,
						COUNT(DISTINCT p.ID) as order_count,
						SUM(CAST(pm_total.meta_value AS DECIMAL(10,2))) as total_earnings,
						SUM(CAST(pm_tax.meta_value AS DECIMAL(10,2))) as total_tax,
						SUM(CAST(pm_shipping.meta_value AS DECIMAL(10,2))) as total_shipping
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'total'
					LEFT JOIN $postmeta_table pm_tax ON p.ID = pm_tax.post_id AND pm_tax.meta_key = 'tax_amount'
					LEFT JOIN $postmeta_table pm_shipping ON p.ID = pm_shipping.post_id AND pm_shipping.meta_key = 'shipping_amount'
					WHERE p.post_type = 'sc_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY DATE(p.post_date)
					ORDER BY date DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					SureCartExport::$export_instance->data[$index]['report_date'] = $row->date;
					SureCartExport::$export_instance->data[$index]['order_count'] = $row->order_count;
					SureCartExport::$export_instance->data[$index]['total_earnings'] = $row->total_earnings;
					SureCartExport::$export_instance->data[$index]['total_tax'] = $row->total_tax ?: 0;
					SureCartExport::$export_instance->data[$index]['total_shipping'] = $row->total_shipping ?: 0;
					$index++;
				}
				break;

			case 'gateway_wise':
				// Get sales by payment gateway
				$query = "
					SELECT 
						pm_gateway.meta_value as gateway,
						COUNT(DISTINCT p.ID) as order_count,
						SUM(CAST(pm_total.meta_value AS DECIMAL(10,2))) as total_earnings
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'total'
					LEFT JOIN $postmeta_table pm_gateway ON p.ID = pm_gateway.post_id AND pm_gateway.meta_key = 'payment_method'
					WHERE p.post_type = 'sc_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY pm_gateway.meta_value
					ORDER BY total_earnings DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					SureCartExport::$export_instance->data[$index]['gateway'] = $row->gateway ?: 'manual';
					SureCartExport::$export_instance->data[$index]['order_count'] = $row->order_count;
					SureCartExport::$export_instance->data[$index]['total_earnings'] = $row->total_earnings;
					$index++;
				}
				break;

			case 'product_wise':
				// Get sales by product
				$payments = $wpdb->get_results($wpdb->prepare(
					"SELECT p.ID, pm_total.meta_value as total, pm_items.meta_value as line_items
					 FROM $orders_table p
					 LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'total'
					 LEFT JOIN $postmeta_table pm_items ON p.ID = pm_items.post_id AND pm_items.meta_key = 'line_items'
					 WHERE p.post_type = 'sc_order' AND p.post_status = 'publish' $date_condition
					 LIMIT 1000"
				));

				$product_stats = array();
				foreach ($payments as $payment) {
					$line_items = maybe_unserialize($payment->line_items);
					if (!empty($line_items) && is_array($line_items)) {
						foreach ($line_items as $item) {
							$product_id = isset($item['product_id']) ? intval($item['product_id']) : 0;
							if ($product_id > 0) {
								if (!isset($product_stats[$product_id])) {
									$product_stats[$product_id] = array(
										'product_id' => $product_id,
										'product_name' => get_the_title($product_id),
										'order_count' => 0,
										'total_earnings' => 0
									);
								}
								$product_stats[$product_id]['order_count']++;
								$item_total = isset($item['total']) ? floatval($item['total']) : floatval($payment->total);
								$product_stats[$product_id]['total_earnings'] += $item_total;
							}
						}
					}
				}

				foreach ($product_stats as $stat) {
					SureCartExport::$export_instance->data[$index]['product_id'] = $stat['product_id'];
					SureCartExport::$export_instance->data[$index]['product_name'] = $stat['product_name'];
					SureCartExport::$export_instance->data[$index]['order_count'] = $stat['order_count'];
					SureCartExport::$export_instance->data[$index]['total_earnings'] = $stat['total_earnings'];
					$index++;
				}
				break;

			case 'tax':
			case 'fees':
				// Get tax/fee breakdown
				$query = "
					SELECT 
						DATE(p.post_date) as date,
						SUM(CAST(pm_tax.meta_value AS DECIMAL(10,2))) as total_tax,
						SUM(CAST(pm_shipping.meta_value AS DECIMAL(10,2))) as total_shipping
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_tax ON p.ID = pm_tax.post_id AND pm_tax.meta_key = 'tax_amount'
					LEFT JOIN $postmeta_table pm_shipping ON p.ID = pm_shipping.post_id AND pm_shipping.meta_key = 'shipping_amount'
					WHERE p.post_type = 'sc_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY DATE(p.post_date)
					ORDER BY date DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					SureCartExport::$export_instance->data[$index]['report_date'] = $row->date;
					SureCartExport::$export_instance->data[$index]['total_tax'] = $row->total_tax ?: 0;
					SureCartExport::$export_instance->data[$index]['total_shipping'] = $row->total_shipping ?: 0;
					$index++;
				}
				break;
		}
	}

	/**
	 * Get filtered SureCart record IDs based on conditions and filters
	 * (specific_period, specific_status, specific_authors, specific_post_id, category_export, product_titles)
	 *
	 * @param string $module Module type (SURECART_PRODUCTS, SURECART_CUSTOMERS, SURECART_COUPONS, etc.)
	 * @param array $conditions Filter conditions array
	 * @param string $category_export Comma-separated category/collection names or IDs
	 * @param string $product_titles Comma-separated post titles or title search terms
	 * @return array Filtered record IDs
	 */
	public function getFilteredSureCartIDs($module, $conditions = [], $category_export = '', $product_titles = '')
	{
		global $wpdb;

		if (!is_plugin_active('surecart/surecart.php')) {
			return [];
		}

		// 1. Parse Date Period (specific_period)
		$is_period = !empty($conditions['specific_period']['is_check']) &&
			($conditions['specific_period']['is_check'] === 'true' || $conditions['specific_period']['is_check'] === true || $conditions['specific_period']['is_check'] === '1' || $conditions['specific_period']['is_check'] === 1);
		
		$from_date = $is_period ? ($conditions['specific_period']['from'] ?? '') : '';
		$to_date   = $is_period ? ($conditions['specific_period']['to'] ?? $from_date) : '';
		if (!empty($from_date) && empty($to_date)) {
			$to_date = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$from_date = $to_date;
		}

		// 2. Parse Specific Post ID (specific_post_id)
		$is_post_id = !empty($conditions['specific_post_id']['is_check']) &&
			($conditions['specific_post_id']['is_check'] === 'true' || $conditions['specific_post_id']['is_check'] === true || $conditions['specific_post_id']['is_check'] === '1' || $conditions['specific_post_id']['is_check'] === 1);
		$specific_ids = [];
		if ($is_post_id && !empty($conditions['specific_post_id']['post_id'])) {
			$resolved = ExportExtension::resolve_post_and_surecart_ids($conditions['specific_post_id']['post_id']);
			$specific_ids = !empty($resolved['all_identifiers']) ? $resolved['all_identifiers'] : array_filter(array_map('trim', explode(',', (string)$conditions['specific_post_id']['post_id'])));
		}

		// 3. Parse Status Filter (specific_status)
		$status_filter = '';
		if (!empty($conditions['specific_status']['status'])) {
			$status_filter = strtolower(trim($conditions['specific_status']['status']));
		} elseif (!empty($conditions['specific_status']['is_check']) && is_string($conditions['specific_status']['is_check']) && $conditions['specific_status']['is_check'] !== 'true' && $conditions['specific_status']['is_check'] !== 'false') {
			$status_filter = strtolower(trim($conditions['specific_status']['is_check']));
		}

		// 4. Parse Authors Filter (specific_authors)
		$author_filter = [];
		$is_author = !empty($conditions['specific_authors']['is_check']) &&
			($conditions['specific_authors']['is_check'] === 'true' || $conditions['specific_authors']['is_check'] === true || $conditions['specific_authors']['is_check'] === '1' || $conditions['specific_authors']['is_check'] === 1);
		if ($is_author && !empty($conditions['specific_authors']['author'])) {
			$author_filter = array_map('trim', explode(',', (string)$conditions['specific_authors']['author']));
			$author_filter = array_filter($author_filter);
		}

		// 5. Parse Categories / Collections Filter (category_export / specific_category)
		$cat_list = [];
		if (!empty($category_export)) {
			$cat_list = array_map('trim', explode(',', (string)$category_export));
		} elseif (!empty($conditions['specific_category']['category'])) {
			$cat_list = array_map('trim', explode(',', (string)$conditions['specific_category']['category']));
		} elseif (!empty($conditions['category_export'])) {
			$cat_list = array_map('trim', explode(',', (string)$conditions['category_export']));
		}
		$cat_list = array_filter($cat_list);

		// 6. Parse Post Titles Filter (product_titles / post_title_export / specific_title)
		$title_list = [];
		if (!empty($product_titles)) {
			$title_list = array_map('trim', explode(',', (string)$product_titles));
		} elseif (!empty($conditions['post_title_export'])) {
			$title_list = array_map('trim', explode(',', (string)$conditions['post_title_export']));
		} elseif (!empty($conditions['specific_title']['title'])) {
			$title_list = array_map('trim', explode(',', (string)$conditions['specific_title']['title']));
		}
		$title_list = array_filter($title_list);

		$match_title = function($target_text, $title_list) {
			if (empty($title_list)) return true;
			if (empty($target_text)) return false;
			foreach ($title_list as $t) {
				if (strcasecmp((string)$t, (string)$target_text) === 0 || stripos((string)$target_text, (string)$t) !== false) {
					return true;
				}
			}
			return false;
		};

		$match_author = function($post_author_id, $author_filter) {
			if (empty($author_filter)) return true;
			if (empty($post_author_id)) return false;
			foreach ($author_filter as $af) {
				if (is_numeric($af) && intval($af) === intval($post_author_id)) {
					return true;
				}
				$user = get_user_by('id', $post_author_id);
				if ($user && (strcasecmp($user->user_login, $af) === 0 || strcasecmp($user->user_email, $af) === 0)) {
					return true;
				}
			}
			return false;
		};

		// 1. SURECART_PRODUCTS
		if ($module == 'SURECART_PRODUCTS') {
			if (!class_exists('\\SureCart\\Models\\Product')) {
				return [];
			}
			try {
				$products = \SureCart\Models\Product::where(['limit' => 5000])->get();
				$filtered = [];

				if (!empty($products)) {
					foreach ($products as $product) {
						$sc_id = $product->id ?? '';
						$wp_id = '';
						if (!empty($sc_id)) {
							$wp_id = $wpdb->get_var($wpdb->prepare(
								"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s LIMIT 1",
								$sc_id
							));
						}
						if (!$wp_id && !empty($product->slug)) {
							$wp_id = $wpdb->get_var($wpdb->prepare(
								"SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'sc_product' LIMIT 1",
								$product->slug
							));
						}

						$target_id = $wp_id ?: $sc_id;
						if (empty($target_id)) {
							continue;
						}

						$post_obj = $wp_id ? get_post($wp_id) : null;

						// Filter 1: Specific Post ID
						if (!empty($specific_ids)) {
							$match_id = false;
							foreach ($specific_ids as $sid) {
								if (
									strcasecmp((string)$sid, (string)$target_id) === 0 ||
									strcasecmp((string)$sid, (string)$sc_id) === 0 ||
									($wp_id && strcasecmp((string)$sid, (string)$wp_id) === 0) ||
									(!empty($product->slug) && strcasecmp((string)$sid, (string)$product->slug) === 0) ||
									(!empty($product->name) && stripos((string)$product->name, (string)$sid) !== false)
								) {
									$match_id = true;
									break;
								}
							}
							if (!$match_id) continue;
						}

						// Filter 2: Specific Date Period
						if ($is_period && !empty($from_date) && !empty($to_date)) {
							$created_date = '';
							if (!empty($product->created_at)) {
								$created_date = is_numeric($product->created_at) ? date('Y-m-d', $product->created_at) : date('Y-m-d', strtotime($product->created_at));
							} elseif ($post_obj) {
								$created_date = date('Y-m-d', strtotime($post_obj->post_date));
							}
							if (!empty($created_date)) {
								if ($created_date < $from_date || $created_date > $to_date) continue;
							}
						}

						// Filter 3: Specific Status
						if (!empty($status_filter) && $status_filter !== 'all') {
							$post_status = $post_obj ? $post_obj->post_status : '';
							$is_archived = !empty($product->archived);

							if ($status_filter === 'archived' || $status_filter === 'trash') {
								if (!$is_archived && $post_status !== 'trash') continue;
							} elseif ($status_filter === 'publish') {
								if ($is_archived || ($post_status && $post_status !== 'publish')) continue;
							} elseif ($status_filter === 'draft') {
								if ($post_status && $post_status !== 'draft') continue;
							} else {
								if ($post_status && strtolower($post_status) !== $status_filter) continue;
							}
						}

						// Filter 4: Specific Author
						if (!empty($author_filter)) {
							$post_author = $post_obj ? $post_obj->post_author : 0;
							if (!$match_author($post_author, $author_filter)) continue;
						}

						// Filter 5: Specific Post Title
						if (!empty($title_list)) {
							$p_title = $product->name ?? ($post_obj ? $post_obj->post_title : '');
							if (!$match_title($p_title, $title_list)) continue;
						}

						// Filter 6: Specific Category / Collection
						if (!empty($cat_list)) {
							$match_cat = false;

							if ($wp_id) {
								$terms = wp_get_post_terms($wp_id, ['sc_product_category', 'sc_collection', 'sc_product_tag']);
								if (!is_wp_error($terms) && !empty($terms)) {
									foreach ($terms as $t) {
										foreach ($cat_list as $cl) {
											if (
												strcasecmp((string)$t->name, (string)$cl) === 0 ||
												strcasecmp((string)$t->slug, (string)$cl) === 0 ||
												(is_numeric($cl) && intval($t->term_id) === intval($cl))
											) {
												$match_cat = true;
												break 2;
											}
										}
									}
								}
							}

							if (!$match_cat && !empty($product->product_collections)) {
								foreach ($product->product_collections as $col) {
									$col_name = is_object($col) ? ($col->name ?? ($col->id ?? '')) : (is_array($col) ? ($col['name'] ?? ($col['id'] ?? '')) : (string)$col);
									foreach ($cat_list as $cl) {
										if (strcasecmp((string)$col_name, (string)$cl) === 0 || stripos((string)$col_name, (string)$cl) !== false) {
											$match_cat = true;
											break 2;
										}
									}
								}
							}

							if (!$match_cat) continue;
						}

						$filtered[] = $target_id;
					}
				}

				return $filtered;
			} catch (\Throwable $e) {
				return [];
			}
		}

		// 2. SURECART_COUPONS
		if ($module == 'SURECART_COUPONS') {
			if (!class_exists('\\SureCart\\Models\\Coupon')) {
				return [];
			}
			try {
				$coupons = \SureCart\Models\Coupon::where(['limit' => 5000])->get();
				$filtered = [];

				if (!empty($coupons)) {
					foreach ($coupons as $coupon) {
						$c_id = $coupon->id ?? '';
						if (empty($c_id)) continue;

						$c_name = $coupon->name ?? ($coupon->code ?? '');

						if (!empty($specific_ids)) {
							$match_id = false;
							foreach ($specific_ids as $sid) {
								if (
									strcasecmp((string)$sid, (string)$c_id) === 0 ||
									(!empty($c_name) && strcasecmp((string)$sid, (string)$c_name) === 0) ||
									(!empty($coupon->code) && strcasecmp((string)$sid, (string)$coupon->code) === 0)
								) {
									$match_id = true;
									break;
								}
							}
							if (!$match_id) continue;
						}

						if ($is_period && !empty($from_date) && !empty($to_date)) {
							$created_date = '';
							if (!empty($coupon->created_at)) {
								$created_date = is_numeric($coupon->created_at) ? date('Y-m-d', $coupon->created_at) : date('Y-m-d', strtotime($coupon->created_at));
							}
							if (!empty($created_date) && ($created_date < $from_date || $created_date > $to_date)) continue;
						}

						if (!empty($status_filter) && $status_filter !== 'all') {
							$is_archived = !empty($coupon->archived);
							if ($status_filter === 'archived' || $status_filter === 'trash') {
								if (!$is_archived) continue;
							} elseif ($status_filter === 'publish' || $status_filter === 'active') {
								if ($is_archived) continue;
							}
						}

						if (!empty($author_filter)) {
							$c_author = $coupon->created_by ?? 0;
							if (!$match_author($c_author, $author_filter)) continue;
						}

						if (!empty($title_list)) {
							if (!$match_title($c_name, $title_list)) continue;
						}

						$filtered[] = $c_id;
					}
				}

				return $filtered;
			} catch (\Throwable $e) {
				return [];
			}
		}

		// 3. SURECART_CUSTOMERS
		if ($module == 'SURECART_CUSTOMERS') {
			if (!class_exists('\\SureCart\\Models\\Customer')) {
				return [];
			}
			try {
				$customers = \SureCart\Models\Customer::where(['limit' => 5000])->get();
				$filtered = [];

				if (!empty($customers)) {
					foreach ($customers as $customer) {
						$cust_id = $customer->id ?? '';
						if (empty($cust_id)) continue;

						$c_email = $customer->email ?? '';
						$c_name  = $customer->name ?? '';

						if (!empty($specific_ids)) {
							$match_id = false;
							foreach ($specific_ids as $sid) {
								if (
									strcasecmp((string)$sid, (string)$cust_id) === 0 ||
									(!empty($c_email) && strcasecmp((string)$sid, (string)$c_email) === 0) ||
									(!empty($c_name) && stripos((string)$c_name, (string)$sid) !== false)
								) {
									$match_id = true;
									break;
								}
							}
							if (!$match_id) continue;
						}

						if ($is_period && !empty($from_date) && !empty($to_date)) {
							$created_date = '';
							if (!empty($customer->created_at)) {
								$created_date = is_numeric($customer->created_at) ? date('Y-m-d', $customer->created_at) : date('Y-m-d', strtotime($customer->created_at));
							}
							if (!empty($created_date) && ($created_date < $from_date || $created_date > $to_date)) continue;
						}

						if (!empty($status_filter) && $status_filter !== 'all') {
							$c_status = !empty($customer->status) ? strtolower($customer->status) : '';
							if (!empty($c_status) && $c_status !== $status_filter) continue;
						}

						if (!empty($author_filter)) {
							$user_id = $customer->wp_user_id ?? ($customer->user_id ?? 0);
							if (!$match_author($user_id, $author_filter)) continue;
						}

						if (!empty($title_list)) {
							if (!$match_title($c_name ?: $c_email, $title_list)) continue;
						}

						$filtered[] = $cust_id;
					}
				}

				return $filtered;
			} catch (\Throwable $e) {
				return [];
			}
		}

		// 4. SURECART_ORDERS
		if ($module == 'SURECART_ORDERS') {
			if (!class_exists('\\SureCart\\Models\\Order')) {
				return [];
			}
			try {
				$orders = \SureCart\Models\Order::where(['limit' => 5000])->get();
				$filtered = [];

				if (!empty($orders)) {
					foreach ($orders as $order) {
						$o_id = $order->id ?? '';
						if (empty($o_id)) continue;

						$o_num = $order->number ?? '';

						if (!empty($specific_ids)) {
							$match_id = false;
							foreach ($specific_ids as $sid) {
								if (strcasecmp((string)$sid, (string)$o_id) === 0 || (!empty($o_num) && strcasecmp((string)$sid, (string)$o_num) === 0)) {
									$match_id = true;
									break;
								}
							}
							if (!$match_id) continue;
						}

						if ($is_period && !empty($from_date) && !empty($to_date)) {
							$created_date = !empty($order->created_at) ? (is_numeric($order->created_at) ? date('Y-m-d', $order->created_at) : date('Y-m-d', strtotime($order->created_at))) : '';
							if (!empty($created_date) && ($created_date < $from_date || $created_date > $to_date)) continue;
						}

						if (!empty($status_filter) && $status_filter !== 'all') {
							$o_status = !empty($order->status) ? strtolower($order->status) : '';
							if (!empty($o_status) && $o_status !== $status_filter) continue;
						}

						if (!empty($author_filter)) {
							$o_author = $order->created_by ?? 0;
							if (!$match_author($o_author, $author_filter)) continue;
						}

						if (!empty($title_list)) {
							if (!$match_title($o_num, $title_list)) continue;
						}

						$filtered[] = $o_id;
					}
				}

				return $filtered;
			} catch (\Throwable $e) {
				return [];
			}
		}

		// 5. SURECART_SUBSCRIPTIONS
		if ($module == 'SURECART_SUBSCRIPTIONS') {
			if (!class_exists('\\SureCart\\Models\\Subscription')) {
				return [];
			}
			try {
				$subscriptions = \SureCart\Models\Subscription::where(['limit' => 5000])->get();
				$filtered = [];

				if (!empty($subscriptions)) {
					foreach ($subscriptions as $sub) {
						$sub_id = $sub->id ?? '';
						if (empty($sub_id)) continue;

						if (!empty($specific_ids)) {
							$match_id = false;
							foreach ($specific_ids as $sid) {
								if (strcasecmp((string)$sid, (string)$sub_id) === 0) {
									$match_id = true;
									break;
								}
							}
							if (!$match_id) continue;
						}

						if ($is_period && !empty($from_date) && !empty($to_date)) {
							$created_date = !empty($sub->created_at) ? (is_numeric($sub->created_at) ? date('Y-m-d', $sub->created_at) : date('Y-m-d', strtotime($sub->created_at))) : '';
							if (!empty($created_date) && ($created_date < $from_date || $created_date > $to_date)) continue;
						}

						if (!empty($status_filter) && $status_filter !== 'all') {
							$sub_status = !empty($sub->status) ? strtolower($sub->status) : '';
							if (!empty($sub_status) && $sub_status !== $status_filter) continue;
						}

						if (!empty($author_filter)) {
							$sub_author = $sub->created_by ?? 0;
							if (!$match_author($sub_author, $author_filter)) continue;
						}

						$filtered[] = $sub_id;
					}
				}

				return $filtered;
			} catch (\Throwable $e) {
				return [];
			}
		}

		return [];
	}

	/**
	 * Get all SureCart titles/names for a given post_type/module
	 *
	 * @param string $post_type Module type or CPT slug
	 * @return array List of titles/names
	 */
	public function get_surecart_post_titles($post_type)
	{
		$titles = [];
		if (!is_plugin_active('surecart/surecart.php')) {
			return $titles;
		}

		$module_map = [
			'SURECART_PRODUCTS' => 'sc_product',
			'SURECART_COUPONS'  => 'sc_coupon',
			'SURECART_CUSTOMERS' => 'sc_customer',
			'SURECART_ORDERS'    => 'sc_order',
			'SURECART_SUBSCRIPTIONS' => 'sc_subscription',
		];
		$cpt = isset($module_map[$post_type]) ? $module_map[$post_type] : $post_type;

		// 1. Query local CPT posts
		$posts = get_posts([
			'post_type'      => $cpt,
			'posts_per_page' => -1,
			'post_status'    => 'any',
			'fields'         => 'ids'
		]);
		if (!empty($posts)) {
			foreach ($posts as $post_id) {
				$post_obj = get_post($post_id);
				if ($post_obj && $post_obj->post_status !== 'trash' && !empty($post_obj->post_title)) {
					$titles[] = $post_obj->post_title;
				}
			}
		}

		// 2. Query SureCart SDK Models
		try {
			if ($post_type === 'SURECART_PRODUCTS' || $cpt === 'sc_product') {
				if (class_exists('\\SureCart\\Models\\Product')) {
					$items = \SureCart\Models\Product::where(['limit' => 5000])->get();
					if (!empty($items)) {
						foreach ($items as $item) {
							if (!empty($item->name)) $titles[] = $item->name;
						}
					}
				}
			} elseif ($post_type === 'SURECART_COUPONS' || $cpt === 'sc_coupon') {
				if (class_exists('\\SureCart\\Models\\Coupon')) {
					$items = \SureCart\Models\Coupon::where(['limit' => 5000])->get();
					if (!empty($items)) {
						foreach ($items as $item) {
							$name = $item->name ?? ($item->code ?? '');
							if (!empty($name)) $titles[] = $name;
						}
					}
				}
			} elseif ($post_type === 'SURECART_CUSTOMERS' || $cpt === 'sc_customer') {
				if (class_exists('\\SureCart\\Models\\Customer')) {
					$items = \SureCart\Models\Customer::where(['limit' => 5000])->get();
					if (!empty($items)) {
						foreach ($items as $item) {
							$name = $item->name ?? ($item->email ?? '');
							if (!empty($name)) $titles[] = $name;
						}
					}
				}
			} elseif ($post_type === 'SURECART_ORDERS' || $cpt === 'sc_order') {
				if (class_exists('\\SureCart\\Models\\Order')) {
					$items = \SureCart\Models\Order::where(['limit' => 5000])->get();
					if (!empty($items)) {
						foreach ($items as $item) {
							$name = $item->number ?? ($item->id ?? '');
							if (!empty($name)) $titles[] = $name;
						}
					}
				}
			} elseif ($post_type === 'SURECART_SUBSCRIPTIONS' || $cpt === 'sc_subscription') {
				if (class_exists('\\SureCart\\Models\\Subscription')) {
					$items = \SureCart\Models\Subscription::where(['limit' => 5000])->get();
					if (!empty($items)) {
						foreach ($items as $item) {
							if (!empty($item->id)) $titles[] = $item->id;
						}
					}
				}
			}
		} catch (\Throwable $e) {}

		return array_values(array_unique(array_filter($titles)));
	}
}


