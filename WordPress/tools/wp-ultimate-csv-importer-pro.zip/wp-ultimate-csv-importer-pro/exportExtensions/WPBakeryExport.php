<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bulk export helpers for vc_templates CPT (mirrors ElementorExport layout).
 */
class WPBakeryExport {

	/**
	 * Build a manifest of attachment ids used in VC shortcodes.
	 *
	 * Format: oldId:url|oldId:url
	 *
	 * @param int $post_id
	 * @param string|null $content
	 * @return string
	 */
	public static function build_media_files_manifest( $post_id, $content = null ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return '';
		}
		if ( $content === null ) {
			$content = (string) get_post_field( 'post_content', $post_id );
		}
		$content = (string) $content;
		if ( $content === '' || strpos( $content, '[vc_' ) === false ) {
			return '';
		}

		$ids = array();
		$prefer_url_by_id = array(); // id => url found in content (preserve ?id=)
		if ( preg_match_all( '/\\b(?:image|images|include|ids)=\"([0-9,]+)\"/i', $content, $m ) ) {
			foreach ( $m[1] as $csv ) {
				foreach ( preg_split( '/\\s*,\\s*/', (string) $csv ) as $id ) {
					$id = (int) trim( (string) $id );
					if ( $id > 0 ) {
						$ids[ $id ] = true;
					}
				}
			}
		}

		// Also capture ids embedded in URLs/classes, e.g. url(...?id=14772) or wp-image-14772.
		if ( preg_match_all( "/https?:\\/\\/[^\\s\\)\\\"']+/i", $content, $mu ) ) {
			foreach ( $mu[0] as $found_url ) {
				$found_url = (string) $found_url;
				if ( preg_match( '/[?&]id=(\\d+)/i', $found_url, $mid ) ) {
					$id = (int) $mid[1];
					if ( $id > 0 ) {
						$ids[ $id ] = true;
						if ( ! isset( $prefer_url_by_id[ $id ] ) ) {
							$prefer_url_by_id[ $id ] = $found_url;
						}
					}
				}
			}
		}
		if ( preg_match_all( '/\\bwp-image-(\\d+)\\b/i', $content, $m3 ) ) {
			foreach ( $m3[1] as $id ) {
				$id = (int) $id;
				if ( $id > 0 ) {
					$ids[ $id ] = true;
				}
			}
		}

		if ( empty( $ids ) ) {
			return '';
		}

		$pairs = array();
		foreach ( array_keys( $ids ) as $old_id ) {
			$url = isset( $prefer_url_by_id[ $old_id ] ) ? $prefer_url_by_id[ $old_id ] : wp_get_attachment_url( (int) $old_id );
			if ( $url ) {
				$pairs[] = $old_id . ':' . $url;
			}
		}
		return implode( '|', $pairs );
	}

	/**
	 * All saved WPBakery global templates, or one template by ID.
	 *
	 * @param int $template_id Optional template post ID.
	 * @return array<int, array<string, mixed>>
	 */
	public function templateExport( $template_id = 0 ) {
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WPBakeryExtension' ) || ! WPBakeryExtension::is_wpbakery_active() ) {
			return array();
		}
		$args = array(
			'post_type'      => 'vc_templates',
			'posts_per_page' => -1,
			'post_status'    => 'any',
		);
		$template_id = (int) $template_id;
		if ( $template_id > 0 ) {
			$args['p']              = $template_id;
			$args['posts_per_page'] = 1;
		}
		$query     = new \WP_Query( $args );
		$templates = $query->get_posts();
		$output    = array();

		foreach ( $templates as $template ) {
			$author_data      = get_userdata( $template->post_author );
			$custom_css       = (string) get_post_meta( $template->ID, '_wpb_post_custom_css', true );
			$short_css        = (string) get_post_meta( $template->ID, '_wpb_shortcodes_custom_css', true );
			$page_tpl         = (string) get_post_meta( $template->ID, '_wp_page_template', true );
			$editor_type      = (string) get_post_meta( $template->ID, '_wpb_vc_editor_type', true );
			$custom_layout    = (string) get_post_meta( $template->ID, '_wpb_post_custom_layout', true );
			$default_css_upd  = (string) get_post_meta( $template->ID, '_wpb_shortcodes_default_css_updated', true );
			$short_css_upd    = (string) get_post_meta( $template->ID, '_wpb_shortcodes_custom_css_updated', true );
			$default_css      = (string) get_post_meta( $template->ID, '_wpb_shortcodes_default_css', true );
			$custom_js_header = (string) get_post_meta( $template->ID, '_wpb_post_custom_js_header', true );
			$style_json  = wp_json_encode(
				array(
					'custom_css'                     => $custom_css,
					'shortcodes_css'                 => $short_css,
					'page_template'                  => $page_tpl,
					'vc_editor_type'                 => $editor_type,
					'post_custom_layout'             => $custom_layout,
					'shortcodes_default_css_updated' => $default_css_upd,
					'shortcodes_custom_css_updated'  => $short_css_upd,
					'shortcodes_default_css'         => $default_css,
					'post_custom_js_header'          => $custom_js_header,
				)
			);

			$output[] = array(
				'ID'               => $template->ID,
				'Template title'   => $template->post_title,
				'Template content' => $template->post_content,
				'Style'            => base64_encode( $style_json ),
				'Template type'    => 'wpbakery',
				'Created time'     => $template->post_date,
				'Created by'       => $author_data ? $author_data->display_name : '',
				'Template status'  => $template->post_status,
				'Category'         => '',
			);
		}

		return $output;
	}
}
