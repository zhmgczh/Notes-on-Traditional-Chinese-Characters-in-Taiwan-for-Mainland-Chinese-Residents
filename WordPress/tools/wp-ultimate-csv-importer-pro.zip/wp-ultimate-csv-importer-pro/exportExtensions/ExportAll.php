<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Orchestrates multi-module "Export All" by reusing ExportExtension batch engine.
 */
class ExportAll
{
	protected static $instance = null;

	/** @var ExportExtension */
	protected $export_extension;

	const TRANSIENT_PREFIX = 'smack_export_all_';
	const DEFAULT_BATCH_LIMIT = 1000;
	const TRANSIENT_TTL = 7200;

	public static function getInstance()
	{
		if (null === self::$instance) {
			self::$instance = new self();
			self::$instance->doHooks();
		}
		return self::$instance;
	}

	public function doHooks()
	{
		add_action('wp_ajax_parse_data_export_all', array($this, 'parseDataExportAll'));
		add_action('wp_ajax_get_exportable_modules', array($this, 'getExportableModulesAjax'));
	}

	public function __construct()
	{
		$this->export_extension = ExportExtension::getInstance();
	}

	/**
	 * AJAX: return dynamically discovered exportable modules.
	 */
	public function getExportableModulesAjax()
	{
		$this->verifyRequest();
		$modules = ExportHandler::getExportableModules();
		echo wp_json_encode(array(
			'success' => true,
			'modules' => $modules,
			'total'   => count($modules),
		));
		wp_die();
	}

	/**
	 * AJAX: process one batch of the current module or finalize the ZIP archive.
	 */
	public function parseDataExportAll()
	{
		$this->verifyRequest();

		$session_id = isset($_POST['export_all_session']) ? sanitize_text_field(wp_unslash($_POST['export_all_session'])) : '';

		if (empty($session_id)) {
			$this->initExportAllJob();
			return;
		}

		$state = $this->getJobState($session_id);
		if (empty($state)) {
			$this->sendJson(array(
				'success' => false,
				'error'   => true,
				'status'  => 'failed',
				'message' => __('Export All session expired or not found. Please start again.', 'wp-ultimate-csv-importer'),
			));
		}

		if (!empty($state['completed'])) {
			$this->sendJson($this->buildCompletedResponse($state));
			return;
		}

		$this->processExportAllBatch($session_id, $state);
	}

	/**
	 * Initialize a new Export All job and process the first batch.
	 */
	protected function initExportAllJob()
	{
		$modules = ExportHandler::getExportableModules();
		if (empty($modules)) {
			$this->sendJson(array(
				'success' => false,
				'error'   => true,
				'status'  => 'failed',
				'message' => __('No exportable modules found.', 'wp-ultimate-csv-importer'),
			));
		}

		$session_id = wp_generate_password(32, false, false);
		$zip_base   = $this->resolveZipBaseName();

		$state = array(
			'session_id'       => $session_id,
			'modules'          => $modules,
			'module_index'     => 0,
			'offset'           => 0,
			'export_type'      => sanitize_text_field($_POST['exp_type'] ?? 'csv'),
			'conditions'       => $this->parseConditionsFromPost(),
			'event_exclusions' => $this->parseEventExclusionsFromPost(),
			'completed_files'  => array(),
			'module_results'   => array(),
			'zip_base'         => $zip_base,
			'limit'            => $this->resolveBatchLimit(),
			'completed'        => false,
			'filter_fields'    => $this->parseFilterFieldsFromPost(),
		);

		$this->saveJobState($session_id, $state);
		$this->processExportAllBatch($session_id, $state);
	}

	/**
	 * Run a single batch for the active module; advance modules or build ZIP when done.
	 */
	protected function processExportAllBatch($session_id, array $state)
	{
		$total_modules = count($state['modules']);

		while ($state['module_index'] < $total_modules) {
			$current = $state['modules'][$state['module_index']];

			try {
				$result = $this->runModuleBatch($current, $state);
			} catch (\Throwable $e) {
				$result = array(
					'failed'  => true,
					'message' => $e->getMessage(),
				);
			}

			if (!empty($result['failed']) || !empty($result['error']) || ($result['status'] ?? '') === 'failed') {
				$this->recordModuleFailure($state, $current, $result['message'] ?? __('Export failed', 'wp-ultimate-csv-importer'));
				$state['module_index']++;
				$state['offset'] = 0;
				$this->resetExportInstanceData();
				$this->saveJobState($session_id, $state);
				continue;
			}

			$state['offset'] = intval($result['new_offset'] ?? 0);
			$total_rows      = intval($result['total_row_count'] ?? 0);
			$module_complete = !empty($result['success']) || ($total_rows > 0 && $state['offset'] >= $total_rows);

			if ($module_complete) {
				$this->recordModuleSuccess($state, $current, $result);
				$state['module_index']++;
				$state['offset'] = 0;
				$this->resetExportInstanceData();
				$this->saveJobState($session_id, $state);
				continue;
			}

			$this->saveJobState($session_id, $state);
			$this->sendJson($this->buildProgressResponse($state, $current, $result, false));
			return;
		}

		$state['completed'] = true;
		$zip_response       = $this->finalizeExportAllZip($state);
		$state                = array_merge($state, $zip_response);
		$this->saveJobState($session_id, $state);
		$this->sendJson($this->buildCompletedResponse($state));
	}

	/**
	 * Configure ExportExtension and run one batch via the existing export engine.
	 */
	protected function runModuleBatch(array $module_entry, array $state)
	{
		$export = $this->export_extension;
		$this->resetExportInstanceData();

		$module       = sanitize_text_field($module_entry['module']);
		$optionalType = isset($module_entry['optionalType']) ? sanitize_text_field($module_entry['optionalType']) : '';
		$file_slug    = sanitize_file_name($module_entry['file_slug']);

		$module       = $this->applyCustomPostRemapping($module, $optionalType);

		$export->module            = $module;
		$export->optionalType      = ($module === 'Taxonomies' || $module === 'CustomPosts') ? $optionalType : $export->getOptionalType($module);
		$export->exportType        = $state['export_type'];
		$export->conditions        = $state['conditions'];
		$export->eventExclusions   = $state['event_exclusions'];
		$export->fileName          = $file_slug;
		$export->offset            = intval($state['offset']);
		$export->limit             = intval($state['limit']);
		$export->checkSplit        = 'false';
		$export->export_mode       = 'export_all';
		$export->isMigration       = 'false';
		$export->isPreview         = '';
		$export->headers           = '';
		$export->data              = array();
		$export->export_id         = 0;
		$export->delimiter         = $export->setDelimiter($state['conditions']['delimiter'] ?? array());

		$filter_fields = $state['filter_fields'];
		$export->exportRoleChecked          = $filter_fields['exportRoleChecked'];
		$export->roleSelectedField          = $filter_fields['roleSelectedField'];
		$export->exportSelectedField        = $filter_fields['exportSelectedField'];
		$export->exportPaymentSelectedField = $filter_fields['exportPaymentSelectedField'];
		$export->exportUserProductChecked   = $filter_fields['exportUserProductChecked'];
		$export->userProductSelectedField   = $filter_fields['userProductSelectedField'];

		$export->exportData();

		if (empty($export->export_log) || !is_array($export->export_log)) {
			$export->resetExportBatchState();
			return array(
				'failed'  => true,
				'message' => __('Export engine returned no response.', 'wp-ultimate-csv-importer'),
			);
		}

		$batch_result = $export->export_log;
		$export->resetExportBatchState();
		unset( $export );

		return $batch_result;
	}

	/**
	 * Same CustomPosts optional-type remapping used by ExportExtension::parseData().
	 */
	protected function applyCustomPostRemapping($module, $optionalType)
	{
		if ($module !== 'CustomPosts' || empty($optionalType)) {
			return $module;
		}

		$remapped_types = array(
			'EDD_DOWNLOADS', 'EDD_ORDERS', 'EDD_CUSTOMERS', 'EDD_DISCOUNTS',
			'PROFILEPRESS', 'PPRESS_MEMBERSHIP_PLAN', 'PPRESS_ORDER',
			'SURECART_PRODUCTS', 'SURECART_ORDERS', 'SURECART_CUSTOMERS',
			'SURECART_SUBSCRIPTIONS', 'SURECART_COUPONS',
			'FLUENTCART_PRODUCTS', 'FLUENTCART_COUPONS', 'FLUENTCART_CUSTOMERS', 'FLUENTCART_ORDERS',
		);

		if (in_array($optionalType, $remapped_types, true)) {
			return $optionalType;
		}

		return $module;
	}

	protected function recordModuleSuccess(array &$state, array $module_entry, array $result)
	{
		$upload_dir = WP_CONTENT_DIR . '/uploads/smack_uci_uploads/exports/';
		$file_path  = $result['exported_path'] ?? ($upload_dir . $module_entry['file_slug'] . '.' . $state['export_type']);

		if (!empty($file_path) && file_exists($file_path)) {
			$state['completed_files'][] = $file_path;
		}

		$state['module_results'][] = array(
			'label'   => $module_entry['label'],
			'module'  => $module_entry['module'],
			'status'  => 'success',
			'file'    => basename($file_path),
			'records' => intval($result['total_row_count'] ?? 0),
		);
	}

	protected function recordModuleFailure(array &$state, array $module_entry, $message)
	{
		$safe_message = sanitize_text_field($message);

		$state['module_results'][] = array(
			'label'   => $module_entry['label'],
			'module'  => $module_entry['module'],
			'status'  => 'failed',
			'message' => $safe_message,
		);
	}

	/**
	 * Bundle successful module files into export-all-YYYY-MM-DD.zip.
	 */
	protected function finalizeExportAllZip(array $state)
	{
		$upload_dir = WP_CONTENT_DIR . '/uploads/smack_uci_uploads/exports/';
		if (!is_dir($upload_dir)) {
			wp_mkdir_p($upload_dir);
		}

		if (is_multisite()) {
			$upload_url = network_home_url() . '/wp-content/uploads/smack_uci_uploads/exports/';
		} else {
			$upload_url = trailingslashit(content_url('/uploads/smack_uci_uploads/exports', 'https'));
		}

		$zip_name = sanitize_file_name($state['zip_base']) . '.zip';
		$zip_path = $upload_dir . $zip_name;

		if (empty($state['completed_files'])) {
			return array(
				'zip_file'      => '',
				'exported_file' => '',
			);
		}

		$zip = new \ZipArchive();
		if ($zip->open($zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
			return array(
				'zip_file'      => '',
				'exported_file' => '',
			);
		}

		foreach ($state['completed_files'] as $file_path) {
			if (file_exists($file_path)) {
				$zip->addFile($file_path, basename($file_path));
			}
		}
		$zip->close();
		unset( $zip );

		foreach ($state['completed_files'] as $file_path) {
			if (file_exists($file_path)) {
				unlink($file_path);
			}
		}

		return array(
			'zip_file'      => $upload_url . $zip_name,
			'exported_file' => $upload_url . $zip_name,
			'zip_path'      => $zip_path,
		);
	}

	protected function buildProgressResponse(array $state, array $current_module, array $batch_result, $is_complete)
	{
		$overall = $this->calculateOverallProgress($state, $batch_result);

		return array(
			'success'              => $is_complete,
			'status'               => $is_complete ? 'completed' : 'in_progress',
			'export_all_session'   => $state['session_id'],
			'current_module'       => $current_module['label'],
			'current_module_index' => $state['module_index'] + 1,
			'total_modules'        => count($state['modules']),
			'module_progress'        => $this->calculateModuleProgress($batch_result),
			'overall_progress'     => $overall,
			'new_offset'           => intval($batch_result['new_offset'] ?? $state['offset']),
			'total_row_count'      => intval($batch_result['total_row_count'] ?? 0),
			'module_results'       => $state['module_results'],
		);
	}

	protected function buildCompletedResponse(array $state)
	{
		$has_success = !empty($state['completed_files']) || !empty($state['zip_file']);
		$has_failures = false;
		foreach ($state['module_results'] as $row) {
			if (($row['status'] ?? '') === 'failed') {
				$has_failures = true;
				break;
			}
		}

		return array(
			'success'            => $has_success,
			'status'             => 'completed',
			'export_all_session' => $state['session_id'],
			'overall_progress'   => 100,
			'exported_file'      => $state['exported_file'] ?? ($state['zip_file'] ?? ''),
			'zip_file'           => $state['zip_file'] ?? '',
			'module_results'     => $state['module_results'],
			'has_failures'       => $has_failures,
			'total_modules'      => count($state['modules']),
			'message'            => $has_success
				? __('Export All completed.', 'wp-ultimate-csv-importer')
				: __('Export All finished with no successful exports.', 'wp-ultimate-csv-importer'),
		);
	}

	protected function calculateModuleProgress(array $batch_result)
	{
		$new_offset = intval($batch_result['new_offset'] ?? 0);
		$total      = intval($batch_result['total_row_count'] ?? 0);
		if ($total <= 0) {
			return 100;
		}
		return min(100, (int) round(($new_offset / $total) * 100));
	}

	protected function calculateOverallProgress(array $state, array $batch_result)
	{
		$total_modules = max(1, count($state['modules']));
		$module_fraction = $state['module_index'] / $total_modules;
		$intra = $this->calculateModuleProgress($batch_result) / 100 / $total_modules;
		return min(99, (int) round(($module_fraction + $intra) * 100));
	}

	protected function resolveZipBaseName()
	{
		$requested = isset($_POST['fileName']) ? sanitize_file_name(wp_unslash($_POST['fileName'])) : '';
		if (!empty($requested)) {
			return $requested;
		}
		return 'export-all-' . gmdate('Y-m-d');
	}

	protected function resolveBatchLimit()
	{
		if (!empty($_POST['limit'])) {
			return max(50, intval($_POST['limit']));
		}
		return self::DEFAULT_BATCH_LIMIT;
	}

	protected function parseConditionsFromPost()
	{
		$raw = isset($_POST['conditions']) ? wp_unslash($_POST['conditions']) : '{}';
		$conditions = json_decode(str_replace('\\', '', $raw), true);
		if (!is_array($conditions)) {
			$conditions = array();
		}
		if (!empty($conditions['specific_period']['to'])) {
			$conditions['specific_period']['to'] = date('Y-m-d', strtotime($conditions['specific_period']['to']));
		}
		if (!empty($conditions['specific_period']['from'])) {
			$conditions['specific_period']['from'] = date('Y-m-d', strtotime($conditions['specific_period']['from']));
		}
		return $conditions;
	}

	protected function parseEventExclusionsFromPost()
	{
		$raw = isset($_POST['eventExclusions']) ? wp_unslash($_POST['eventExclusions']) : '{}';
		$event_exclusions = json_decode(str_replace('\\', '', $raw), true);
		return is_array($event_exclusions) ? $event_exclusions : array();
	}

	protected function parseFilterFieldsFromPost()
	{
		return array(
			'exportRoleChecked'          => isset($_POST['exportRoleChecked']) ? filter_var(wp_unslash($_POST['exportRoleChecked']), FILTER_VALIDATE_BOOLEAN) : false,
			'roleSelectedField'          => isset($_POST['roleSelectedField']) ? sanitize_text_field(wp_unslash($_POST['roleSelectedField'])) : '',
			'exportSelectedField'        => isset($_POST['exportSelectedField']) ? sanitize_text_field(wp_unslash($_POST['exportSelectedField'])) : '',
			'exportPaymentSelectedField' => isset($_POST['exportPaymentSelectedField']) ? sanitize_text_field(wp_unslash($_POST['exportPaymentSelectedField'])) : '',
			'exportUserProductChecked'   => isset($_POST['exportUserProductChecked']) ? filter_var(wp_unslash($_POST['exportUserProductChecked']), FILTER_VALIDATE_BOOLEAN) : false,
			'userProductSelectedField'   => isset($_POST['userProductSelectedField']) ? sanitize_text_field(wp_unslash($_POST['userProductSelectedField'])) : '',
		);
	}

	protected function resetExportInstanceData()
	{
		$this->export_extension->resetExportBatchState();
	}

	protected function transientKey($session_id)
	{
		return self::TRANSIENT_PREFIX . get_current_user_id() . '_' . sanitize_key($session_id);
	}

	protected function getJobState($session_id)
	{
		return get_transient($this->transientKey($session_id));
	}

	protected function saveJobState($session_id, array $state)
	{
		set_transient($this->transientKey($session_id), $state, self::TRANSIENT_TTL);
	}

	protected function verifyRequest()
	{
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Unauthorized', 'wp-ultimate-csv-importer')), 403);
		}
	}

	protected function sendJson(array $payload)
	{
		echo wp_json_encode($payload);
		wp_die();
	}
}
