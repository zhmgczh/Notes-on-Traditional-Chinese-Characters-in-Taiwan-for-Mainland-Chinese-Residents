<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (! defined('ABSPATH'))
	exit; // Exit if accessed directly

use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderItem;
use FluentCart\App\Models\OrderAddress;

/**
 * Class FluentCartExport
 * Handles all FluentCart export functionality
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */
class FluentCartExport
{
	protected static $instance = null, $export_instance;
	public $totalRowCount;
	public $plugin;

	public static function getInstance()
	{
		if (null == self::$instance) {
			self::$instance = new self;
			FluentCartExport::$export_instance = ExportExtension::getInstance();
		}
		return self::$instance;
	}

	/**
	 * FluentCartExport constructor.
	 */
	public function __construct()
	{
		$this->plugin = class_exists("Smackcoders\UCI\Core\UCICore") ? \Smackcoders\UCI\Core\UCICore::getInstance() : null;
	}

	/**
	 * Export FluentCart Products data
	 * 
	 * @param int $id Product ID
	 * @return void
	 */
	public function getFluentCartProductDataMaster($id)
	{
		global $wpdb;

		if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
				return;
		}


		$products_table = $wpdb->prefix . 'fct_product_details';
		$product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $products_table WHERE post_id = %d", $id));
			
		if (!$product) {
			return;
		}

		$post_id = $product->post_id ?? '';

		$fulfillment_type = $product->fulfillment_type ?? '';

		$min_price = $product->min_price ?? '';

		$max_price = $product->max_price ?? '';

		$default_variation_id = $product->default_variation_id ?? '';

		$default_media = $product->default_media?? '';

		$manage_stock = $product->manage_stock?? '';

		$stock_availability = $product->stock_availability?? '';

		$variation_type = $product->variation_type?? '';

		$manage_downloadable = $product->manage_downloadable?? '';

		$other_info = $product->other_info?? '';

		$created_at = $product->created_at?? '';

		$updated_at = $product->updated_at?? '';

		if($variation_type == 'simple_variations'){
			
			$products_variations_table = $wpdb->prefix . 'fct_product_variations';
			$product_variations = $wpdb->get_results($wpdb->prepare("SELECT * FROM $products_variations_table WHERE post_id = %d", $id));
		

			$variation_manage_stock = $variation_id = $media_id =$serial_index =$sold_individually =$variation_title =$variation_identifier =$manage_stock_variation =$payment_type =$stock_status =$total_stock =$on_hold =$committed =$available =$item_status =$manage_cost =$item_price =$item_cost =$compare_price =$shipping_class =$variation_other_info =$downloadable = $object_type = $meta_key = $meta_value = [];

			foreach($product_variations as $product_variation){
				if($product_variation != false){
					
					$variation_id[] = $product_variation->id;
					$media_id[] = $product_variation->media_id ?? '';
					$serial_index[] = $product_variation->serial_index ?? '';
					$sold_individually[] = $product_variation->sold_individually ?? '';
					$variation_title[] = $product_variation->variation_title ?? '';
					$variation_identifier[] = $product_variation->variation_identifier ?? '';
					$payment_type[] = $product_variation->payment_type ?? '';
					$stock_status[] = $product_variation->stock_status ?? '';
					$backorders[] = $product_variation->backorders ?? '';
					$total_stock[] = $product_variation->total_stock ?? '';
					$on_hold[] = $product_variation->on_hold ?? '';
					$committed[] = $product_variation->committed ?? '';
					$available[] = $product_variation->available ?? '';
					$item_status[] = $product_variation->item_status ?? '';
					$variation_manage_stock[] = $product_variation->manage_stock ?? '';
					$manage_cost[] = $product_variation->manage_cost ?? '';
					$item_price[] = $product_variation->item_price ?? '';
					$item_cost[] = $product_variation->item_cost ?? '';
					$compare_price[] = $product_variation->compare_price ?? '';
					$shipping_class[] = $product_variation->shipping_class ?? '';
					$variation_other_info[] = $product_variation->other_info ?? '';
					$downloadable[] = $product_variation->downloadable ?? '';
				}

				$product_variations_meta_table = $wpdb->prefix.'fct_product_meta';
				
				$product_meta = $wpdb->get_row($wpdb->prepare(
					"SELECT * FROM {$product_variations_meta_table} 
					WHERE object_id = %d",
					(int)$product_variation->id
					)
				);
					if( $product_meta != false ){

						$object_type[] = $product_meta->object_type;
			
						$meta_key[] = $product_meta->meta_key;
			
						$meta_value[] = $product_meta->meta_value;
					}
				
			}
		}

		$fct_product_downloads_table = $wpdb->prefix.'fct_product_downloads';
		$product_downloads = $wpdb->get_results($wpdb->prepare(
					"SELECT * FROM {$fct_product_downloads_table} 
					WHERE post_id = %d",
					(int)$id
					),
				);
		
		$product_variation_id = $download_updated_at = $download_created_at = $download_identifier = $title = $type = $driver = $file_name = $file_path = $file_url = $file_size = $settings = $serial = [];
		if ( !empty($product_downloads) ) {

			foreach ( $product_downloads as $product_download ) {

				$product_variation_id[] = $product_download->product_variation_id ?? '';
				$download_identifier[] = $product_download->download_identifier ?? '';
				$title[] = $product_download->title ?? '';
				$type[] = $product_download->type ?? '';
				$driver[] = $product_download->driver ?? '';
				$file_name[] = $product_download->file_name ?? '';
				$file_path[] = $product_download->file_path ?? '';
				$file_url[] = $product_download->file_url ?? '';
				$file_size[] = $product_download->file_size ?? '';
				$settings[] = $product_download->settings ?? '';
				$serial[] = $product_download->serial ?? '';
				$download_created_at[] = $product_download->created_at ?? '';
				$download_updated_at[] = $product_download->updated_at ?? '';

			}
		}

		
		
		







		$categories = wp_get_post_terms($id, 'product-categories', ['fields' => 'names']);
		$tags = wp_get_post_terms($id, 'product-brands', ['fields' => 'names']);
		
		FluentCartExport::$export_instance->data[$id]['max_price'] = $max_price ?: '';
		FluentCartExport::$export_instance->data[$id]['min_price'] = $min_price ?: '';
		FluentCartExport::$export_instance->data[$id]['fulfillment_type'] = $fulfillment_type ?: '';
		FluentCartExport::$export_instance->data[$id]['default_variation_id'] = $default_variation_id ?: '';
		FluentCartExport::$export_instance->data[$id]['default_media'] = $default_media ?: '';
		FluentCartExport::$export_instance->data[$id]['manage_stock'] = $manage_stock ?? '';
		FluentCartExport::$export_instance->data[$id]['stock_availability'] = $stock_availability ?? '';
		FluentCartExport::$export_instance->data[$id]['variation_type'] = $variation_type ?: '';
		FluentCartExport::$export_instance->data[$id]['manage_downloadable'] = $manage_downloadable ?? '';
		FluentCartExport::$export_instance->data[$id]['other_info'] = $other_info ?: '';

		if($variation_type == 'simple_variations'){
			FluentCartExport::$export_instance->data[$id]['variation_id'] = implode('|',$variation_id) ?? '';
			FluentCartExport::$export_instance->data[$id]['media_id'] = implode('|',$media_id) ?? '';
			FluentCartExport::$export_instance->data[$id]['serial_index'] = implode('|',$serial_index) ?? '';
			FluentCartExport::$export_instance->data[$id]['sold_individually'] = implode('|',$sold_individually )?? '';
			FluentCartExport::$export_instance->data[$id]['variation_title'] = implode('|',$variation_title) ?? '';
			FluentCartExport::$export_instance->data[$id]['variation_identifier'] = implode('|',$variation_identifier) ?? '';
			FluentCartExport::$export_instance->data[$id]['variation_manage_stock'] = implode('|',$variation_manage_stock) ?? '';
			FluentCartExport::$export_instance->data[$id]['payment_type'] = implode('|',$payment_type) ?? '';
			FluentCartExport::$export_instance->data[$id]['stock_status'] = implode('|',$stock_status) ?? '';
			FluentCartExport::$export_instance->data[$id]['backorders'] = implode('|',$backorders) ?? '';
			FluentCartExport::$export_instance->data[$id]['total_stock'] = implode('|',$total_stock) ?: '';
			FluentCartExport::$export_instance->data[$id]['on_hold'] = implode('|',$on_hold) ?? '';
			FluentCartExport::$export_instance->data[$id]['committed'] = implode('|',$committed) ?? '';
			FluentCartExport::$export_instance->data[$id]['available'] = implode('|',$available) ?? '';
			FluentCartExport::$export_instance->data[$id]['item_status'] = implode('|',$item_status) ?: '';
			FluentCartExport::$export_instance->data[$id]['manage_cost'] = implode('|',$manage_cost) ?: '';
			FluentCartExport::$export_instance->data[$id]['item_price'] = implode('|',$item_price) ?: '';
			FluentCartExport::$export_instance->data[$id]['item_cost'] = implode('|',$item_cost) ?? '';
			FluentCartExport::$export_instance->data[$id]['compare_price'] = implode('|',$compare_price) ?: '';
			FluentCartExport::$export_instance->data[$id]['shipping_class'] = implode('|',$shipping_class) ?: '';
			FluentCartExport::$export_instance->data[$id]['variation_other_info'] = implode('|',$variation_other_info) ?: '';
			FluentCartExport::$export_instance->data[$id]['variation_downloadable'] = implode('|',$downloadable);
		}

		// product meta table
		if($product_meta != false){
			FluentCartExport::$export_instance->data[$id]['object_type'] = implode('|',$object_type) ?: '';
			FluentCartExport::$export_instance->data[$id]['meta_key'] = implode('|',$meta_key) ?: '';
			FluentCartExport::$export_instance->data[$id]['meta_value'] = implode('|',$meta_value) ?: '';
		}

		// products download table
		FluentCartExport::$export_instance->data[$id]['download_product_variation_id'] =
			!empty($product_variation_id) ? (is_array($product_variation_id) ? implode('|', $product_variation_id) : $product_variation_id) : '';

		FluentCartExport::$export_instance->data[$id]['download_identifier'] =
			!empty($download_identifier) ? (is_array($download_identifier) ? implode('|', $download_identifier) : $download_identifier) : '';

		FluentCartExport::$export_instance->data[$id]['download_title'] =
			!empty($title) ? (is_array($title) ? implode('|', $title) : $title) : '';

		FluentCartExport::$export_instance->data[$id]['download_type'] =
			!empty($type) ? (is_array($type) ? implode('|', $type) : $type) : '';

		FluentCartExport::$export_instance->data[$id]['download_driver'] =
			!empty($driver) ? (is_array($driver) ? implode('|', $driver) : $driver) : '';

		FluentCartExport::$export_instance->data[$id]['download_file_name'] =
			!empty($file_name) ? (is_array($file_name) ? implode('|', $file_name) : $file_name) : '';

		FluentCartExport::$export_instance->data[$id]['download_file_path'] =
			!empty($file_path) ? (is_array($file_path) ? implode('|', $file_path) : $file_path) : '';

		FluentCartExport::$export_instance->data[$id]['download_file_url'] =
			!empty($file_url) ? (is_array($file_url) ? implode('|', $file_url) : $file_url) : '';

		FluentCartExport::$export_instance->data[$id]['download_file_size'] =
			!empty($file_size) ? (is_array($file_size) ? implode('|', $file_size) : $file_size) : '';

		FluentCartExport::$export_instance->data[$id]['download_settings'] =
			!empty($settings) ? (is_array($settings) ? implode('|', $settings) : $settings) : '';

		FluentCartExport::$export_instance->data[$id]['download_serial'] =
			!empty($serial) ? (is_array($serial) ? implode('|', $serial) : $serial) : '';

		FluentCartExport::$export_instance->data[$id]['download_created_at'] =
			!empty($created_at) ? (is_array($created_at) ? implode('|', $download_created_at) : $download_created_at) : '';

		FluentCartExport::$export_instance->data[$id]['download_updated_at'] =
			!empty($updated_at) ? (is_array($updated_at) ? implode('|', $download_updated_at) : $download_updated_at) : '';


		// common data
		FluentCartExport::$export_instance->data[$id]['created_at'] = $created_at ?: '';
		FluentCartExport::$export_instance->data[$id]['updated_at'] = $updated_at ?: '';
		FluentCartExport::$export_instance->data[$id]['product_categories'] = !empty($categories) ? implode('|', $categories) : '';
		FluentCartExport::$export_instance->data[$id]['product_tags'] = !empty($tags) ? implode('|', $tags) : '';
	}

	/**
	 * Export FluentCart Orders data
	 * 
	 * @param int $id Order ID
	 * @return void
	 */
	public function getFluentCartOrderDataMaster($id)
	{
		if (!is_plugin_active('fluent-cart/fluent-cart.php')) return;

		$order = \FluentCart\App\Models\Order::with([
			'order_items',
			'orderMeta',
			'billing_address',
			'shipping_address',
			'transactions'
		])->find($id);

		if (!$order) return;

		$E = &FluentCartExport::$export_instance->data[$id];

		/* ========= ITEMS → JSON STRING ========= */

		$itemsArr = [];

		foreach ($order->order_items as $item) {
			// $this->custom_log($item);
			$item_data = [
				'post_id'=>(string)$item->post_id,
				'object_id'=>(string)$item->object_id,
				'cart_index'=>(string)$item->cart_index,
				'quantity'=>(string)$item->quantity,
				'unit_price'=>(string)$item->unit_price,
				'subtotal'=>(string)$item->subtotal,
				'discount_total'=>(string)$item->discount_total,
				'tax_amount'=>(string)$item->tax_amount,
				'payment_type'=>$item->payment_type,
				'shipping_charge'=>(string)$item->shipping_charge,
				'line_total'=>(string)$item->line_total,
				'rate'=>(string)$item->rate,
				'other_info'=>json_encode($item->other_info),
				'line_meta'=>json_encode($item->line_meta)
			];
			$formatted = [];

			foreach ($item_data as $key => $value) {
				$formatted[] = $key . '->' . $value;
			}

			$itemsArr[] = implode(';', $formatted);
		}


		$metaArr = [];

		foreach ($order->orderMeta as $m) {
			$metaArr[] = $m->meta_key . ':' . json_encode($m->meta_value);
		}


		$txnArr = [];

		foreach ($order->transactions as $txn) {
			$txnArr[] = [
				'payment_method'=>(string)$txn->payment_method,
				'status'=>(string)$txn->status,
				'currency'=>(string)$txn->currency,
				'total'=>(string)$txn->total
			];
		}

		$billing = $order->billing_address ? $order->billing_address->toArray() : [];
		$shipping = $order->shipping_address ? $order->shipping_address->toArray() : [];

		/* ========= CORE EXPORT ========= */

		$E['order_id']=(string)$order->id;
		$E['uuid']=(string)$order->uuid;
		$E['receipt_number']=(string)$order->receipt_number;
		$E['invoice_no']=(string)$order->invoice_no;
		$E['created_at']=(string)$order->created_at;
		$E['updated_at']=(string)$order->updated_at;

		$E['customer_id']=(string)$order->customer_id;
		$E['order_status']=(string)$order->status;
		$E['payment_status']=(string)$order->payment_status;
		$E['payment_method']=(string)$order->payment_method;
		$E['payment_method_title']=(string)$order->payment_method_title;
		$E['currency']=(string)$order->currency;

		$E['subtotal']=(string)$order->subtotal;
		$E['manual_discount_total']=(string)$order->manual_discount_total;
		$E['coupon_discount_total']=(string)$order->coupon_discount_total;
		$E['shipping_tax']=(string)$order->shipping_tax;
		$E['shipping_total']=(string)$order->shipping_total;
		$E['tax_total']=(string)$order->tax_total;
		$E['total_amount']=(string)$order->total_amount;
		$E['total_paid']=(string)$order->total_paid;

		$E['order_type']=(string)$order->type;
		$E['order_mode']=(string)$order->mode;
		$E['order_fulfillment_type']=(string)$order->fulfillment_type;

		/* ========= JSON STRING FIELDS ========= */

		$E['ordered_items']=implode('|',$itemsArr);
		$E['order_meta']=implode('|',$metaArr);
		$E['transactions']=json_encode($txnArr);

		/* ========= ADDRESS ========= */

		$E['billing_name']=(string)($billing['name'] ?? '');
		$E['billing_address_1']=(string)($billing['address_1'] ?? '');
		$E['billing_address_2']=(string)($billing['address_2'] ?? '');
		$E['billing_city']=(string)($billing['city'] ?? '');
		$E['billing_state']=(string)($billing['state'] ?? '');
		$E['billing_postcode']=(string)($billing['postcode'] ?? '');
		$E['billing_country']=(string)($billing['country'] ?? '');

		$E['shipping_name']=(string)($shipping['name'] ?? '');
		$E['shipping_address_1']=(string)($shipping['address_1'] ?? '');
		$E['shipping_address_2']=(string)($shipping['address_2'] ?? '');
		$E['shipping_city']=(string)($shipping['city'] ?? '');
		$E['shipping_state']=(string)($shipping['state'] ?? '');
		$E['shipping_postcode']=(string)($shipping['postcode'] ?? '');
		$E['shipping_country']=(string)($shipping['country'] ?? '');
	}

	/**
	 * Export FluentCart Customers data
	 * 
	 * @param int $id Customer ID
	 * @return void
	 */
	public function getFluentCartCustomerDataMaster($id)
	{
		global $wpdb;

		if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
			return;
		}

		// $this->custom_log('inside the FluentCart_Customer_Exort');
		// $this->custom_log('ID : '.$id);

		$fct_customer_table = $wpdb->prefix.'fct_customers';

		$fct_cutomer_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$fct_customer_table}
				WHERE id = %d",
				$id
			),
			ARRAY_A
		);
		
		if(empty($fct_cutomer_data)) return;

		// $this->custom_log(['customer_data:',$fct_cutomer_data]);

		$wp_user_id 		= $fct_cutomer_data['user_id'];
		$contact_id 		= $fct_cutomer_data['contact_id'];
		$login_email 		= $fct_cutomer_data['email'];
		$first_name 		= $fct_cutomer_data['first_name'];
		$last_name 			= $fct_cutomer_data['last_name'];
		$status 			= $fct_cutomer_data['status'];
		$purchase_value 	= $fct_cutomer_data['purchase_value'];
		$purchase_count 	= $fct_cutomer_data['purchase_count'];
		$ltv 				= $fct_cutomer_data['ltv'];
		$first_purchase_date= $fct_cutomer_data['first_purchase_date'];
		$last_purchase_date = $fct_cutomer_data['last_purchase_date'];
		$aov 				= $fct_cutomer_data['aov'];
		$notes 				= $fct_cutomer_data['notes'];
		$uuid 				= $fct_cutomer_data['uuid'];
		$country 			= $fct_cutomer_data['country'];
		$city 				= $fct_cutomer_data['city'];
		$state 				= $fct_cutomer_data['state'];
		$postcode 			= $fct_cutomer_data['postcode'];
		$created_at 		= $fct_cutomer_data['created_at'];
		$updated_at 		= $fct_cutomer_data['updated_at'];

		$fct_customer_addresses_table = $wpdb->prefix.'fct_customer_addresses';

		$fct_cutomer_addresses_datas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$fct_customer_addresses_table}
				WHERE customer_id = %d",
				$id
			),
			ARRAY_A
		);
		// $this->custom_log(['fct_cutomer_addresses_datas:',$fct_cutomer_addresses_datas]);

		
		$customer_id = $address_is_primary = $address_type = $address_status = $address_label = $address_name = $address_1 = $address_2 = $address_city = $address_state = $address_phone = $address_email = $address_postcode = $address_country = $address_meta = $address_created_at = $address_updated_at = []; 
		foreach($fct_cutomer_addresses_datas as $key => $fct_cutomer_addresses_data){
			
			$customer_id[] 		= $fct_cutomer_addresses_data['custom_id'];
			$address_is_primary[] 		= $fct_cutomer_addresses_data['is_primary'];
			$address_type[] 			= $fct_cutomer_addresses_data['type'];
			$address_status[] 			= $fct_cutomer_addresses_data['status'];
			$address_label[] 			= $fct_cutomer_addresses_data['label'];
			$address_name[] 			= $fct_cutomer_addresses_data['name'];
			$address_1[] 		= $fct_cutomer_addresses_data['address_1'];
			$address_2[] 		= $fct_cutomer_addresses_data['address_2'];
			$address_city[] 			= $fct_cutomer_addresses_data['city'];
			$address_state[] 			= $fct_cutomer_addresses_data['state'];
			$address_phone[] 			= $fct_cutomer_addresses_data['phone'];
			$address_email[] 			= $fct_cutomer_addresses_data['email'];
			$address_postcode[] 		= $fct_cutomer_addresses_data['postcode'];
			$address_country[] 			= $fct_cutomer_addresses_data['country'];
			$address_meta[] 			= $fct_cutomer_addresses_data['meta'];
			$address_created_at[] = $fct_cutomer_addresses_data['created_at'];
			$address_updated_at[] = $fct_cutomer_addresses_data['updated_at'];

		}
		$address_is_primary = implode('|',$address_is_primary);
		$address_type = implode('|',$address_type);
		$address_status = implode('|',$address_status);
		$address_label = implode('|',$address_label);
		$address_name = implode('|',$address_name);
		$address_1 = implode('|',$address_1);
		$address_2 = implode('|',$address_2);
		$address_city = implode('|',$address_city);
		$address_state = implode('|',$address_state);
		$address_phone = implode('|',$address_phone);
		$address_email = implode('|',$address_email);
		$address_postcode = implode('|',$address_postcode);
		$address_country = implode('|',$address_country);
		$address_meta = implode('|',$address_meta);
		$address_created_at = implode('|',$address_created_at);
		$address_updated_at = implode('|',$address_updated_at);

		$fct_customer_meta_table = $wpdb->prefix.'fct_customer_addresses';

		$fct_customer_meta_table_datas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$fct_customer_meta_table}
				WHERE customer_id = %d",
				$id
			),
			ARRAY_A
		);

		$meta_key = $meta_value = $meta_created_at = $meta_updated_at = [];
		foreach($fct_customer_meta_table_datas as $fct_customer_meta_table_data){

			$meta_key[] 		= $fct_customer_meta_table_data['meta_key'];
			$meta_value[] 		= $fct_customer_meta_table_data['meta_value'];
			$meta_created_at[] 	= $fct_customer_meta_table_data['created_at'];
			$meta_updated_at[] 	= $fct_customer_meta_table_data['updated_at'];

		}
		$meta_key = implode('|',$meta_key);
		$meta_value = implode('|',$meta_value);
		$meta_created_at = implode('|',$meta_created_at);
		$meta_updated_at = implode('|',$meta_updated_at);

		$wp_users_table = $wpdb->prefix.'users';

		$wp_core_customer_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wp_users_table}
				WHERE ID = %d",
				$wp_user_id
			),
			ARRAY_A
		);
		$wp_core_user_data = '';
		if($wp_core_customer_data != false){
			
			$wp_core_user_data  = 'user_login:'.trim($wp_core_customer_data['user_login']) . '|';
			$wp_core_user_data .= 'user_pass:'.trim($wp_core_customer_data['user_pass']) . '|';
			$wp_core_user_data .= 'user_nicename:'.trim($wp_core_customer_data['user_nicename']) . '|';
			$wp_core_user_data .= 'user_email:'.trim($wp_core_customer_data['user_email']) . '|';
			$wp_core_user_data .= 'user_url:'.trim($wp_core_customer_data['user_url']) . '|';
			$wp_core_user_data .= 'user_registered:'.trim($wp_core_customer_data['user_registered']) . '|';
			$wp_core_user_data .= 'user_activation_key:'.trim($wp_core_customer_data['user_activation_key']) . '|';
			$wp_core_user_data .= 'user_status:'.trim($wp_core_customer_data['user_status']) . '|';
			$wp_core_user_data .= 'display_name:'.trim($wp_core_customer_data['display_name']);
		}

		
		


		// Set export data
		//`wp_fct_customers` data
		FluentCartExport::$export_instance->data[$id]['id'] = $id;
		FluentCartExport::$export_instance->data[$id]['user_id'] = !empty($wp_user_id) ? $wp_user_id : 0;
		FluentCartExport::$export_instance->data[$id]['contact_id'] = !empty($contact_id) ? $contact_id : 0;
		FluentCartExport::$export_instance->data[$id]['login_email'] = !empty($login_email) ? $login_email : "";
		FluentCartExport::$export_instance->data[$id]['first_name'] = !empty($first_name) ? $first_name : "";
		FluentCartExport::$export_instance->data[$id]['last_name'] = !empty($last_name) ? $last_name : "";
		FluentCartExport::$export_instance->data[$id]['status'] = !empty($status) ? $status : "";
		FluentCartExport::$export_instance->data[$id]['purchase_value'] = !empty($purchase_value) ? $purchase_value : "";
		FluentCartExport::$export_instance->data[$id]['purchase_count'] = !empty($purchase_count) ? $purchase_count : "";
		FluentCartExport::$export_instance->data[$id]['ltv'] = !empty($ltv) ? $ltv : "";
		FluentCartExport::$export_instance->data[$id]['first_purchase_date'] = !empty($first_purchase_date) ? $first_purchase_date : "";
		FluentCartExport::$export_instance->data[$id]['last_purchase_date'] = !empty($last_purchase_date) ? $last_purchase_date : "";
		FluentCartExport::$export_instance->data[$id]['aov'] = !empty($aov) ? $aov : "";
		FluentCartExport::$export_instance->data[$id]['notes'] = !empty($notes) ? $notes : "";
		FluentCartExport::$export_instance->data[$id]['uuid'] = !empty($uuid) ? $uuid : "";
		FluentCartExport::$export_instance->data[$id]['country'] = !empty($country) ? $country : "";
		FluentCartExport::$export_instance->data[$id]['city'] = !empty($city) ? $city : "";
		FluentCartExport::$export_instance->data[$id]['state'] = !empty($state) ? $state : "";
		FluentCartExport::$export_instance->data[$id]['postcode'] = !empty($postcode) ? $postcode : "";
		FluentCartExport::$export_instance->data[$id]['created_at'] = !empty($created_at) ? $created_at : "";
		FluentCartExport::$export_instance->data[$id]['updated_at'] = !empty($updated_at) ? $updated_at : "";
		
		//`wp_fct_customer_addresses` data
		FluentCartExport::$export_instance->data[$id]['address_is_primary'] = !empty($address_is_primary) ? $address_is_primary : "";
		FluentCartExport::$export_instance->data[$id]['address_type'] = !empty($address_type) ? $address_type : "";
		FluentCartExport::$export_instance->data[$id]['address_status'] = !empty($address_status) ? $address_status : "";
		FluentCartExport::$export_instance->data[$id]['address_label'] = !empty($address_label) ? $address_label : "";
		FluentCartExport::$export_instance->data[$id]['address_name'] = !empty($address_name) ? $address_name : "";
		FluentCartExport::$export_instance->data[$id]['address_1'] = !empty($address_1) ? $address_1 : "";
		FluentCartExport::$export_instance->data[$id]['address_2'] = !empty($address_2) ? $address_2 : "";
		FluentCartExport::$export_instance->data[$id]['address_city'] = !empty($address_city) ? $address_city : "";
		FluentCartExport::$export_instance->data[$id]['address_state'] = !empty($address_state) ? $address_state : "";
		FluentCartExport::$export_instance->data[$id]['address_phone'] = !empty($address_phone) ? $address_phone : "";
		FluentCartExport::$export_instance->data[$id]['address_email'] = !empty($address_email) ? $address_email : "";
		FluentCartExport::$export_instance->data[$id]['address_postcode'] = !empty($address_postcode) ? $address_postcode : "";
		FluentCartExport::$export_instance->data[$id]['address_country'] = !empty($address_country) ? $address_country : "";
		FluentCartExport::$export_instance->data[$id]['address_meta'] = !empty($address_meta) ? $address_meta : "";
		FluentCartExport::$export_instance->data[$id]['address_created_at'] = !empty($address_created_at) ? $address_created_at : "";
		FluentCartExport::$export_instance->data[$id]['address_updated_at'] = !empty($address_updated_at) ? $address_updated_at : "";
		
		//`wp_fct_customer_meta` data
		FluentCartExport::$export_instance->data[$id]['meta_key'] = !empty($meta_key) ? $meta_key : "";
		FluentCartExport::$export_instance->data[$id]['meta_value'] = !empty($meta_value) ? $meta_value : "";
		FluentCartExport::$export_instance->data[$id]['meta_created_at'] = !empty($meta_created_at) ? $meta_created_at : "";
		FluentCartExport::$export_instance->data[$id]['meta_updated_at'] = !empty($meta_updated_at) ? $meta_updated_at : "";

		////`wp_users` data
		FluentCartExport::$export_instance->data[$id]['wp_core_user_data'] = !empty($wp_core_user_data) ? $wp_core_user_data : "";
		
		//`wp_usermeta data`
		
		
	}

	/**
	 * Export FluentCart Subscriptions data
	 * 
	 * @param int $id Subscription ID
	 * @return void
	 */
	public function getFluentCartSubscriptionDataMaster($id)
	{
		global $wpdb;

		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return;
		}

		$post_type = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_type FROM {$wpdb->posts} WHERE ID = %d",
				$id
			)
		);

		if ($post_type !== 'fct_subscription') {
			return;
		}

		// Get subscription meta
		$customer_id = get_post_meta($id, 'fct_customer_id', true);
		$customer_email = get_post_meta($id, 'fct_customer_email', true);
		$product_id = get_post_meta($id, 'fct_product_id', true);
		$order_id = get_post_meta($id, 'fct_order_id', true);
		$subscription_status = get_post_meta($id, 'fct_subscription_status', true);
		$interval = get_post_meta($id, 'fct_interval', true);
		$period = get_post_meta($id, 'fct_period', true);
		$price = get_post_meta($id, 'fct_price', true);
		$start_date = get_post_meta($id, 'fct_start_date', true);
		$end_date = get_post_meta($id, 'fct_end_date', true);
		$next_payment_date = get_post_meta($id, 'fct_next_payment_date', true);
		$trial_end_date = get_post_meta($id, 'fct_trial_end_date', true);
		$cancel_date = get_post_meta($id, 'fct_cancel_date', true);
		$cancel_reason = get_post_meta($id, 'fct_cancel_reason', true);
		$billing_cycle_count = get_post_meta($id, 'fct_billing_cycle_count', true);
		$total_payments = get_post_meta($id, 'fct_total_payments', true);

		// Get product name
		$product_name = '';
		if ($product_id) {
			$product_name = get_the_title($product_id);
		}

		// Get all custom subscription meta
		$all_meta = get_post_meta($id);
		$custom_meta = [];
		foreach ($all_meta as $key => $values) {
			if (strpos($key, 'fct_') === 0 && !in_array($key, [
				'fct_customer_id',
				'fct_customer_email',
				'fct_product_id',
				'fct_order_id',
				'fct_subscription_status',
				'fct_interval',
				'fct_period',
				'fct_price',
				'fct_start_date',
				'fct_end_date',
				'fct_next_payment_date',
				'fct_trial_end_date',
				'fct_cancel_date',
				'fct_cancel_reason',
				'fct_billing_cycle_count',
				'fct_total_payments'
			])) {
				$custom_meta[$key] = is_array($values) ? $values[0] : $values;
			}
		}

		$subscription_meta_output = '';
		if (!empty($custom_meta)) {
			foreach ($custom_meta as $key => $value) {
				$subscription_meta_output .= str_replace('fct_', '', $key) . ':' . (is_array($value) ? json_encode($value) : $value) . '|';
			}
			$subscription_meta_output = rtrim($subscription_meta_output, '|');
		}

		// Set export data
		FluentCartExport::$export_instance->data[$id]['subscription_id'] = $id;
		FluentCartExport::$export_instance->data[$id]['customer_id'] = $customer_id ?: '';
		FluentCartExport::$export_instance->data[$id]['customer_email'] = $customer_email ?: '';
		FluentCartExport::$export_instance->data[$id]['product_id'] = $product_id ?: '';
		FluentCartExport::$export_instance->data[$id]['product_name'] = $product_name;
		FluentCartExport::$export_instance->data[$id]['order_id'] = $order_id ?: '';
		FluentCartExport::$export_instance->data[$id]['subscription_status'] = $subscription_status ?: 'active';
		FluentCartExport::$export_instance->data[$id]['interval'] = $interval ?: 1;
		FluentCartExport::$export_instance->data[$id]['period'] = $period ?: 'month';
		FluentCartExport::$export_instance->data[$id]['price'] = $price ?: 0;
		FluentCartExport::$export_instance->data[$id]['start_date'] = $start_date ?: get_post_field('post_date', $id);
		FluentCartExport::$export_instance->data[$id]['end_date'] = $end_date ?: '';
		FluentCartExport::$export_instance->data[$id]['next_payment_date'] = $next_payment_date ?: '';
		FluentCartExport::$export_instance->data[$id]['trial_end_date'] = $trial_end_date ?: '';
		FluentCartExport::$export_instance->data[$id]['cancel_date'] = $cancel_date ?: '';
		FluentCartExport::$export_instance->data[$id]['cancel_reason'] = $cancel_reason ?: '';
		FluentCartExport::$export_instance->data[$id]['billing_cycle_count'] = $billing_cycle_count ?: 0;
		FluentCartExport::$export_instance->data[$id]['total_payments'] = $total_payments ?: 0;
		FluentCartExport::$export_instance->data[$id]['subscription_meta'] = $subscription_meta_output;
	}

	/**
	 * Export FluentCart Coupons data
	 * 
	 * @param int $id Coupon ID
	 * @return void
	 */
	public function getFluentCartCouponDataMaster($id)
	{
		global $wpdb;

		if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
			return;
		}

		$fct_coupon_table = $wpdb->prefix.'fct_coupons';
		$coupon_datas = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$fct_coupon_table} WHERE ID = %d",
				$id
				)
		);

		$id 				= $coupon_datas->id;
		$coupon_title 		= $coupon_datas->title;
		$coupon_code		= $coupon_datas->code;
		$coupon_priority 	= $coupon_datas->priority;
		$discount_type 		= $coupon_datas->type;

		$conditions 		= json_decode($coupon_datas->conditions,true);

		$max_uses_limit 		= $conditions['max_uses'];
		$buy_quantity 			= $conditions['buy_quantity'];
		$get_quantity 			= $conditions['get_quantity'];
		$is_recurring 			= $conditions['is_recurring'];
		$usage_limit_per_user 	= $conditions['max_per_customer'];
		$apply_to_quantity 		= $conditions['apply_to_quantity'];
		$excluded_products 		= $conditions['excluded_products'];
		$included_products 		= $conditions['included_products'];
		$email_restrictions 	= $conditions['email_restrictions'];
		$apply_to_whole_cart 	= $conditions['apply_to_whole_cart'];
		$excluded_categories 	= $conditions['excluded_categories'];
		$included_categories 	= $conditions['included_categories'];
		$max_discount_amount 	= $conditions['max_discount_amount'];
		$maximum_amount 		= $conditions['max_purchase_amount'];
		$minimum_amount 		= $conditions['min_purchase_amount'];
	

		$discount_amount 			= $coupon_datas->amount;
		$usage_count 				= $coupon_datas->use_count;
		$status 					= $coupon_datas->status;
		$coupon_notes 				= $coupon_datas->notes;
		$coupon_stackable 			= $coupon_datas->stackable;
		$coupon_show_on_checkout 	= $coupon_datas->show_on_checkout;
		$start_date		 			= $coupon_datas->start_date;
		$end_date		 			= $coupon_datas->end_date;
		$created_at		 			= $coupon_datas->created_at;
		$updated_at		 			= $coupon_datas->updated_at;

		// Set export data
		FluentCartExport::$export_instance->data[$id]['ID'] = $id;
		FluentCartExport::$export_instance->data[$id]['coupon_title'] = $coupon_title ?: '';
		FluentCartExport::$export_instance->data[$id]['coupon_code'] = $coupon_code ?: '';
		FluentCartExport::$export_instance->data[$id]['coupon_priority'] = $coupon_priority ?: '';
		FluentCartExport::$export_instance->data[$id]['discount_type'] = $discount_type ?: 'percentage';

		FluentCartExport::$export_instance->data[$id]['max_uses_limit'] = $max_uses_limit ?: '';
		FluentCartExport::$export_instance->data[$id]['buy_quantity'] = $buy_quantity ?: '';
		FluentCartExport::$export_instance->data[$id]['get_quantity'] = $get_quantity ?: '';
		FluentCartExport::$export_instance->data[$id]['is_recurring'] = $is_recurring ?: '';
		FluentCartExport::$export_instance->data[$id]['usage_limit_per_user'] = $usage_limit_per_user ?: 0;
		FluentCartExport::$export_instance->data[$id]['apply_to_quantity'] = $apply_to_quantity ?: '';
		FluentCartExport::$export_instance->data[$id]['excluded_products'] = (count($excluded_products)>0) ? implode('|',$excluded_products) : '';
		FluentCartExport::$export_instance->data[$id]['included_products'] = (count($included_products)>0) ? implode('|',$included_products) : '';
		FluentCartExport::$export_instance->data[$id]['email_restrictions'] = $email_restrictions ?: '';
		FluentCartExport::$export_instance->data[$id]['apply_to_whole_cart'] = $apply_to_whole_cart ?: '';
		FluentCartExport::$export_instance->data[$id]['excluded_categories'] = (count($excluded_categories)>0) ? implode('|',$excluded_categories) : '';
		FluentCartExport::$export_instance->data[$id]['included_categories'] = (count($included_categories)>0) ? implode('|',$included_categories) : '';
		FluentCartExport::$export_instance->data[$id]['max_discount_amount'] = $max_discount_amount ?: '';
		FluentCartExport::$export_instance->data[$id]['maximum_amount'] = $maximum_amount ?: '';
		FluentCartExport::$export_instance->data[$id]['minimum_amount'] = $minimum_amount ?: '';


		FluentCartExport::$export_instance->data[$id]['discount_amount'] = $discount_amount ?: 0;
		FluentCartExport::$export_instance->data[$id]['status'] = $status ?: 'active';
		FluentCartExport::$export_instance->data[$id]['coupon_notes'] = $coupon_notes ?: '';
		FluentCartExport::$export_instance->data[$id]['coupon_stackable'] = $coupon_stackable ?: '';
		FluentCartExport::$export_instance->data[$id]['coupon_show_on_checkout'] = $coupon_show_on_checkout ?: '';
		FluentCartExport::$export_instance->data[$id]['start_date'] = $start_date ?: '';
		FluentCartExport::$export_instance->data[$id]['end_date'] = $end_date ?: '';
		FluentCartExport::$export_instance->data[$id]['created_at'] = $created_at;
		FluentCartExport::$export_instance->data[$id]['updated_at'] = $updated_at;
	}
	/**
	 * Export FluentCart Reports (Sales / Earnings / Tax / Fees)
	 * 
	 * @param string $report_type Type of report (sales, earnings, tax, fees, gateway_wise, product_wise)
	 * @param string $start_date Start date for report
	 * @param string $end_date End date for report
	 * @return void
	 */
	public function getFluentCartReportsDataMaster($report_type = 'sales', $start_date = '', $end_date = '')
	{
		global $wpdb;

		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return;
		}

		$orders_table = $wpdb->prefix . 'posts';
		$postmeta_table = $wpdb->prefix . 'postmeta';

		// Set default date range if not provided
		if (empty($start_date)) {
			$start_date = date('Y-m-d', strtotime('-30 days'));
		}
		if (empty($end_date)) {
			$end_date = current_time('mysql');
		}

		$date_condition = $wpdb->prepare(
			"AND p.post_date >= %s AND p.post_date <= %s",
			$start_date,
			$end_date
		);

		$reports_data = array();
		$index = 0;

		switch ($report_type) {
			case 'sales':
			case 'earnings':
				// Get sales/earnings by date
				$query = "
					SELECT 
						DATE(p.post_date) as date,
						COUNT(DISTINCT p.ID) as order_count,
						SUM(CAST(pm_total.meta_value AS DECIMAL(10,2))) as total_earnings,
						SUM(CAST(pm_tax.meta_value AS DECIMAL(10,2))) as total_tax,
						SUM(CAST(pm_shipping.meta_value AS DECIMAL(10,2))) as total_shipping
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'fct_total'
					LEFT JOIN $postmeta_table pm_tax ON p.ID = pm_tax.post_id AND pm_tax.meta_key = 'fct_tax_amount'
					LEFT JOIN $postmeta_table pm_shipping ON p.ID = pm_shipping.post_id AND pm_shipping.meta_key = 'fct_shipping_amount'
					WHERE p.post_type = 'fct_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY DATE(p.post_date)
					ORDER BY date DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					FluentCartExport::$export_instance->data[$index]['report_date'] = $row->date;
					FluentCartExport::$export_instance->data[$index]['order_count'] = $row->order_count;
					FluentCartExport::$export_instance->data[$index]['total_earnings'] = $row->total_earnings;
					FluentCartExport::$export_instance->data[$index]['total_tax'] = $row->total_tax ?: 0;
					FluentCartExport::$export_instance->data[$index]['total_shipping'] = $row->total_shipping ?: 0;
					$index++;
				}
				break;

			case 'gateway_wise':
				// Get sales by payment gateway
				$query = "
					SELECT 
						pm_gateway.meta_value as gateway,
						COUNT(DISTINCT p.ID) as order_count,
						SUM(CAST(pm_total.meta_value AS DECIMAL(10,2))) as total_earnings
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'fct_total'
					LEFT JOIN $postmeta_table pm_gateway ON p.ID = pm_gateway.post_id AND pm_gateway.meta_key = 'fct_payment_method'
					WHERE p.post_type = 'fct_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY pm_gateway.meta_value
					ORDER BY total_earnings DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					FluentCartExport::$export_instance->data[$index]['gateway'] = $row->gateway ?: 'manual';
					FluentCartExport::$export_instance->data[$index]['order_count'] = $row->order_count;
					FluentCartExport::$export_instance->data[$index]['total_earnings'] = $row->total_earnings;
					$index++;
				}
				break;

			case 'product_wise':
				// Get sales by product
				$payments = $wpdb->get_results($wpdb->prepare(
					"SELECT p.ID, pm_total.meta_value as total, pm_items.meta_value as line_items
					 FROM $orders_table p
					 LEFT JOIN $postmeta_table pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = 'fct_total'
					 LEFT JOIN $postmeta_table pm_items ON p.ID = pm_items.post_id AND pm_items.meta_key = 'fct_line_items'
					 WHERE p.post_type = 'fct_order' AND p.post_status = 'publish' $date_condition
					 LIMIT 1000"
				));

				$product_stats = array();
				foreach ($payments as $payment) {
					$line_items = maybe_unserialize($payment->line_items);
					if (!empty($line_items) && is_array($line_items)) {
						foreach ($line_items as $item) {
							$product_id = isset($item['product_id']) ? intval($item['product_id']) : 0;
							if ($product_id > 0) {
								if (!isset($product_stats[$product_id])) {
									$product_stats[$product_id] = array(
										'product_id' => $product_id,
										'product_name' => get_the_title($product_id),
										'order_count' => 0,
										'total_earnings' => 0
									);
								}
								$product_stats[$product_id]['order_count']++;
								$item_total = isset($item['total']) ? floatval($item['total']) : floatval($payment->total);
								$product_stats[$product_id]['total_earnings'] += $item_total;
							}
						}
					}
				}

				foreach ($product_stats as $stat) {
					FluentCartExport::$export_instance->data[$index]['product_id'] = $stat['product_id'];
					FluentCartExport::$export_instance->data[$index]['product_name'] = $stat['product_name'];
					FluentCartExport::$export_instance->data[$index]['order_count'] = $stat['order_count'];
					FluentCartExport::$export_instance->data[$index]['total_earnings'] = $stat['total_earnings'];
					$index++;
				}
				break;

			case 'tax':
			case 'fees':
				// Get tax/fee breakdown
				$query = "
					SELECT 
						DATE(p.post_date) as date,
						SUM(CAST(pm_tax.meta_value AS DECIMAL(10,2))) as total_tax,
						SUM(CAST(pm_shipping.meta_value AS DECIMAL(10,2))) as total_shipping
					FROM $orders_table p
					LEFT JOIN $postmeta_table pm_tax ON p.ID = pm_tax.post_id AND pm_tax.meta_key = 'fct_tax_amount'
					LEFT JOIN $postmeta_table pm_shipping ON p.ID = pm_shipping.post_id AND pm_shipping.meta_key = 'fct_shipping_amount'
					WHERE p.post_type = 'fct_order'
					AND p.post_status = 'publish'
					$date_condition
					GROUP BY DATE(p.post_date)
					ORDER BY date DESC
				";
				$results = $wpdb->get_results($query);
				foreach ($results as $row) {
					FluentCartExport::$export_instance->data[$index]['report_date'] = $row->date;
					FluentCartExport::$export_instance->data[$index]['total_tax'] = $row->total_tax ?: 0;
					FluentCartExport::$export_instance->data[$index]['total_shipping'] = $row->total_shipping ?: 0;
					$index++;
				}
				break;
		}
	}


	/**
	 * Export FluentCart Downloads/Licenses data
	 * 
	 * @param int $id Download ID
	 * @return void
	 */
	public function getFluentCartDownloadDataMaster($id)
	{
		global $wpdb;

		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return;
		}

		// FluentCart uses custom tables
		$downloads_table = $wpdb->prefix . 'fct_downloads';
		$download = $wpdb->get_row($wpdb->prepare("SELECT * FROM $downloads_table WHERE id = %d", $id));

		if (!$download) {
			return;
		}

		// Get product name
		$product_name = '';
		if ($download->product_id) {
			$products_table = $wpdb->prefix . 'fct_products';
			$product = $wpdb->get_row($wpdb->prepare("SELECT name FROM $products_table WHERE id = %d", $download->product_id));
			if ($product) {
				$product_name = $product->name;
			}
		}

		// Get customer email
		$customer_email = '';
		if ($download->customer_id) {
			$customers_table = $wpdb->prefix . 'fct_customers';
			$customer = $wpdb->get_row($wpdb->prepare("SELECT email FROM $customers_table WHERE id = %d", $download->customer_id));
			if ($customer) {
				$customer_email = $customer->email;
			}
		}

		FluentCartExport::$export_instance->data[$id]['download_id'] = $download->id;
		FluentCartExport::$export_instance->data[$id]['product_id'] = $download->product_id;
		FluentCartExport::$export_instance->data[$id]['product_name'] = $product_name;
		FluentCartExport::$export_instance->data[$id]['file_name'] = $download->file_name ?? '';
		FluentCartExport::$export_instance->data[$id]['file_url'] = $download->file_url ?? '';
		FluentCartExport::$export_instance->data[$id]['download_limit'] = $download->download_limit ?? 0;
		FluentCartExport::$export_instance->data[$id]['download_expiry'] = $download->download_expiry ?? '';
		FluentCartExport::$export_instance->data[$id]['license_key'] = $download->license_key ?? '';
		FluentCartExport::$export_instance->data[$id]['activation_limit'] = $download->activation_limit ?? 0;
		FluentCartExport::$export_instance->data[$id]['license_status'] = $download->license_status ?? '';
		FluentCartExport::$export_instance->data[$id]['customer_id'] = $download->customer_id ?? '';
		FluentCartExport::$export_instance->data[$id]['customer_email'] = $customer_email;
		FluentCartExport::$export_instance->data[$id]['order_id'] = $download->order_id ?? '';
		FluentCartExport::$export_instance->data[$id]['date_created'] = $download->created_at ?? '';
		FluentCartExport::$export_instance->data[$id]['date_expires'] = $download->date_expires ?? '';
		FluentCartExport::$export_instance->data[$id]['download_count'] = $download->download_count ?? 0;
		FluentCartExport::$export_instance->data[$id]['download_meta'] = $download->meta ?? '';
	}



	/**
	 * Fetch FluentCart data based on module type
	 *
	 * @param string $module Module name
	 * @param string $optionalType Optional type
	 * @param array $conditions Conditions
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param bool $is_filter Is filter
	 * @param array $headers Headers
	 * @param string $mode Mode
	 * @param array $eventExclusions Event exclusions
	 * @return array
	 */
	public function FetchFluentCartData($module, $optionalType, $conditions, $offset, $limit, $is_filter, $headers, $mode, $eventExclusions) {
		switch($module) {
			case 'FLUENTCART_PRODUCTS':
				return $this->fetchProducts($offset, $limit, $conditions);
			case 'FLUENTCART_ORDERS':
				return $this->fetchOrders($offset, $limit, $conditions);
			case 'FLUENTCART_CUSTOMERS':
				return $this->fetchCustomers($offset, $limit, $conditions);
			case 'FLUENTCART_SUBSCRIPTIONS':
				return $this->fetchSubscriptions($offset, $limit, $conditions);
			case 'FLUENTCART_COUPONS':
				return $this->fetchCoupons($offset, $limit, $conditions);
			case 'FLUENTCART_DOWNLOADS':
				return $this->fetchDownloads($offset, $limit, $conditions);
			case 'FLUENTCART_REPORTS':
				return $this->getFluentCartReportsDataMaster('sales', '', '');
		}
		return array();
	}



	/**
	 * Fetch FluentCart Products data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchProducts($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}



	/**
	 * Fetch FluentCart Orders data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchOrders($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}



	/**
	 * Fetch FluentCart Customers data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchCustomers($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}



	/**
	 * Fetch FluentCart Subscriptions data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchSubscriptions($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}



	/**
	 * Fetch FluentCart Coupons data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchCoupons($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}



	/**
	 * Fetch FluentCart Downloads data
	 *
	 * @param int $offset Offset
	 * @param int $limit Limit
	 * @param array $conditions Conditions
	 * @return array
	 */
	private function fetchDownloads($offset, $limit, $conditions) {
		global $wpdb;
		
		if (!is_plugin_active('fluentcart/fluentcart.php')) {
			return array();
		}
		
		// TODO: Implement based on FluentCart custom tables
		// This should query fct_* tables and populate FluentCartExport::$export_instance->data
		return array();
	}


}