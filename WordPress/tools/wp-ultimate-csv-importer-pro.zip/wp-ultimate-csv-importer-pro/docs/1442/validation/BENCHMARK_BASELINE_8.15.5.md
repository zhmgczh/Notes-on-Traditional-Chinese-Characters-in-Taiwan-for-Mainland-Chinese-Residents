# Benchmark Baseline — 8.15.5

**Status:** Import baseline complete (BL-02) · Other BL tests pending  
**Git commit:** `39438adf7`  
**Plugin version:** 8.15.5  
**Date:** 2026-08-03  
**Tester:** Antony S  

---

## Environment

| Item | Value |
|------|-------|
| WordPress | 7.0.2 |
| PHP | 8.4.23 (CLI) |
| WooCommerce | _(fill if needed)_ |
| Free plugin version | _(fill if needed)_ |
| Server | beta local (`/var/www/html/beta`) |
| OPcache | _(fill on run)_ |
| WP-Cron / real cron | _(fill on run)_ |

---

## Scope note (import benchmark)

Per #1442 planning, **BL-02 import** was run with **1,000 WooCommerce products** (not 10K D1) using:

- **CSV:** `csv_importer_products_benchmark_1000rows.csv`
- **Module:** WooCommerce Product
- **ACF mapped:** `first_name`, `email`, `phone`, `gallery` (gallery column empty in CSV)
- **Excluded from mapping:** `featured_image`, `product_image_gallery`, `downloadable_files` (avoid remote download skew)
- **Batch size:** 5 (200 AJAX pages)
- **Hash key:** `27284350ba8f0fb33505c74aaaeab420`

Machine-readable summary: `BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv`

---

## Import results (primary — **DONE**)

| ID | Metric | Run 1 | Notes |
|----|--------|-------|-------|
| BL-02 | Import 1K WC products wall (s) | **3840** | ~1 hr 4 min (UI wall time) |
| BL-02 | Import rec/s | **0.260** | 1000 / 3840 |
| BL-02 | sec/row | **3.84** | |
| BL-02 | Peak memory (MB) | **20** | max across logged batches |
| BL-02 | DB created | **1000** | failed=0, skipped=0, status=Completed |
| BL-02 | Products in `wp_posts` | **1000** | SKU pattern verified |

### Observations

- Import **100% complete** — DB and plugin log agree.
- Benchmark logging (`antony.log`) captured **101 batch entries (rows 1–505)** before COMPLETE; total duration still reflects full 1000-row run. Batch detail logging fix tracked for implementation branch.
- UI summary log (`log_value`) may not render during very long batches — `Insert_log_details` commented in `SaveMapping.php` on 8.15.5.

---

## Export results (later — see EXPORT_BENCHMARK_PLAN.md)

| ID | Metric | Run 1 | Run 2 | Run 3 | Median | Notes |
|----|--------|-------|-------|-------|--------|-------|
| BL-03 | Export wall (s) | | | | | scenario A/B/C |
| BL-03 | Export peak memory (MB) | | | | | |
| BL-03 | Stuck at offset? | | | | | e.g. 500/1000 |

---

## Other (optional — pending)

| ID | Metric | Run 1 | Run 2 | Run 3 | Median | Notes |
|----|--------|-------|-------|-------|--------|-------|
| BL-01 | Admin TTFB (ms) | | | | | |
| BL-01 | Included files count | | | | | |
| BL-04 | mappingfields (ms) | | | | | |
| BL-05 | saveMappedFields (ms) | | | | | |
| BL-06 | Schedule 1K | pass/fail | | | | |
| BL-07 | GSheet upload | pass/fail | | | | |
| BL-08 | WC blank tags behaviour | | | | | _describe actual_ |
| BL-09 | Advanced Mode 10 min | stable/freeze | | | | |
| BL-10 | Formula save HTTP | | | | | |

---

## Comparison target (`master` after optimization)

| Scenario | Pass criteria |
|----------|---------------|
| **Toggles ON** | All features work — **no regressions** |
| **Toggles OFF** | Import **faster** than 8.15.5 reference (64 min / 1000 products) |
| Reference | 8.15.5 is context only — **better is the goal**, not exact parity |

---

## Sign-off

- [x] BL-02 import 1K WC products completed and recorded
- [ ] BL-01, BL-03–BL-10 (optional / post-Phase-3 for export)
- [x] Ready for implementation branch work on `master`
- [ ] Ready for final comparison after toggles OFF benchmark on 8.16.x
