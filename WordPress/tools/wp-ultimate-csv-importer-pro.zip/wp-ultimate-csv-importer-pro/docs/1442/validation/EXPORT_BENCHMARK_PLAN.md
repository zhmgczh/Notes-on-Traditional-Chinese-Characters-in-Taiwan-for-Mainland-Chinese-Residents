# Export Benchmark Plan — #1442

**When to run:** After Phase 3 export fixes (Issue #3 — #26846, #26819), or at final release sign-off.  
**Not required for:** Initial 8.15.5 import-only baseline (import benchmark first).  
**Compare:** Same settings on 8.15.5 vs implementation branch (all toggles OFF, then ON).

---

## 1. Objective

Measure and verify:

| Goal | Ticket ref |
|------|------------|
| Export completes without freeze after first batch | #26846 |
| Memory does not grow linearly across batches | #26819 |
| Meta Box cloneable groups export full row count | #26846 |
| ACF repeater/group fields export completely | #26846 |
| WooCommerce product export stable (optional) | General regression |

---

## 2. Prerequisites

| Requirement | Detail |
|-------------|--------|
| Data in DB | Import test dataset **before** export benchmark (same records you imported) |
| Plugins active | ACF and/or Meta Box if testing those scenarios |
| WooCommerce | Active for product export scenario |
| Tools | Query Monitor (memory), browser Network tab (`parse_data` timing) |
| Export path | Admin → **Export** tab → filter → select fields → Export |

**Backend:** Batched via AJAX `parse_data` with `offset` + `limit` (`exportExtensions/ExportExtension.php` → `parseData()`).  
Default batch `limit` = **50** if not set; set **Record limit per iteration** explicitly in UI.

---

## 3. Export Settings (all scenarios)

Use **identical** settings on 8.15.5 and target branch:

| Setting | Recommended value | Why |
|---------|-------------------|-----|
| Export type | CSV | Standard; comparable file size |
| Record limit per iteration | **500** | Exposes batch-boundary bugs without tiny batches |
| Offset | Auto (UI progress) | Let UI advance `offset` until complete |
| Date filter | **Off** | Export all records in dataset |
| Delimiter | Comma (default) | — |
| Save export template | **Yes** | Reuse exact field list on re-run |

Record in results: module, optionalType, field count, limit, total rows.

---

## 4. Scenarios — Which post type & fields

Run **at least Scenario B** (CPT + ACF) for Issue #3. Add A or C based on time.

---

### Scenario A — WooCommerce Products (pairs with import benchmark)

**Use when:** You already imported 1000 simple products for import benchmark.

| Setting | Value |
|---------|-------|
| **Module** | `WooCommerce` (or WooCommerce Products) |
| **Post type** | `product` |
| **Record count** | 1000 (or same as import dataset) |
| **Product type filter** | Simple products only |

**Fields to select (minimum):**

| Group | Fields |
|-------|--------|
| Core | `post_title`, `post_content`, `post_status`, `post_date` |
| WooCommerce | `sku`, `regular_price`, `sale_price`, `stock_status`, `stock_quantity` |
| Taxonomy | `product_cat`, `product_tag` |
| Images | `featured_image`, `product_gallery` (if exported) |
| Meta (optional) | `_weight`, `_length` |

**Verify after export:**

| Check | How |
|-------|-----|
| Row count | CSV lines − 1 header = **1000** |
| SKU column | No empty SKUs (if all had SKU in DB) |
| Price column | Values match 5 random DB products |
| Categories | Pipe/comma-separated; spot-check 3 rows |
| No freeze | Progress reaches 1000/1000; file downloads |
| Memory | Peak memory stable across batches (Query Monitor) |

---

### Scenario B — Custom Post Type + ACF (primary for Issue #3) ⭐ Recommended

**Use when:** Validating export freeze on CPT/ACF (#26846).

| Setting | Value |
|---------|-------|
| **Module** | `CustomPosts` |
| **Optional type / CPT** | Your ACF-attached CPT (e.g. `portfolio`, `resource`, `property`) |
| **Record count** | **1000** posts with ACF data |
| **ACF** | Field group assigned to this CPT |

**Prepare data (import first if needed):**

- 1000 CPT posts via import benchmark CSV, **or** existing staging data
- Each post should have:
  - 1× text field
  - 1× image/URL field
  - 1× **repeater** with **3 sub-rows** (important — heavy export path)

**Fields to select (minimum):**

| Group | Fields |
|-------|--------|
| WordPress core | `post_title`, `post_name`, `post_status`, `post_date`, `featured_image` |
| ACF | All fields from assigned field group |
| ACF repeater | Parent repeater + **all sub-fields** (e.g. `repeater_title`, `repeater_body`) |
| Taxonomy | Category/taxonomy if CPT has custom tax |

**Verify after export:**

| Check | How |
|-------|-----|
| Row count | **1000** data rows |
| ACF text | Open CSV; 10 random `post_title` → ACF text column matches DB (`get_field`) |
| Repeater | Repeater serializes with delimiter (usually `\|` or `->`); **3 sub-values per post** present |
| No truncation at batch 500 | Rows 501–1000 have same columns filled as rows 1–500 |
| No UI freeze | Progress bar advances past first batch (500/1000) without hang |
| Memory | Note peak memory at batch 1, 2, final — should not double each batch |
| File size | Note MB; compare 8.15.5 vs target (±20% OK if data same) |

---

### Scenario C — Custom Post Type + Meta Box cloneable groups (Issue #3 edge case)

**Use when:** Meta Box plugin active; cloneable group truncation reported.

| Setting | Value |
|---------|-------|
| **Module** | `CustomPosts` |
| **CPT** | CPT with Meta Box field group (cloneable group enabled) |
| **Record count** | **500** (enough; cloneable is heavy) |

**Prepare data:**

- Each post: 1 cloneable group with **5 clones** (same group name, 5 rows of sub-fields)

**Fields to select:**

| Group | Fields |
|-------|--------|
| Core | `post_title`, `post_status` |
| Meta Box | All fields in cloneable group + sub-fields |
| Meta Box group | `MetaBoxGroupExtension` fields if shown separately in UI |

**Verify after export:**

| Check | How |
|-------|-----|
| Clone count | Pick 5 posts in CSV → cloneable group has **5 serialized entries**, not 1 |
| Row count | 500 rows |
| No freeze after batch 1 | Export passes 250/500 and 500/500 |

---

## 5. Step-by-step — How to run export benchmark

### Step 1 — Prepare

1. Note plugin version + git commit in results file.
2. Confirm record count in WP admin (Posts → CPT or Products).
3. Clear old export files: `wp-content/uploads/smack_uci_uploads/exports/` (optional, for clean test).

### Step 2 — Configure export (UI)

1. Open **WP Ultimate CSV Importer PRO** → **Export**.
2. Select **Module** + **Post type** (per scenario above).
3. Click **Get fields** / load export fields (`get_export_fields` AJAX).
4. Select fields per tables in Section 4.
5. Set **Record limit** = `500`.
6. Set filename e.g. `benchmark-acf-cpt-8.15.5.csv`.
7. **Save as export template** → name: `BENCHMARK_ACF_CPT_v1`.

### Step 3 — Run & measure

1. Start export; note **start time**.
2. Watch progress: `offset / total` in UI (from `exportFilter.js` → `parse_data` loop).
3. If freeze: note **last offset** reached (e.g. stuck at 500/1000 = batch boundary bug).
4. On complete: note **end time**, download file.
5. Record **peak memory** (Query Monitor or `debug.log` if instrumented).

### Step 4 — Verify CSV

1. Row count (see Section 4 checks).
2. Spot-check 10 random records against database.
3. Repeater/cloneable: manual inspect 5 rows.
4. Log pass/fail per check.

### Step 5 — Repeat

- Run **3 times**; record median wall time.
- Re-run on target branch with **same export template**.

---

## 6. Metrics to record

Save to `docs/1442/validation/BENCHMARK_EXPORT_RESULTS.md`:

| Metric | Scenario A | Scenario B | Scenario C |
|--------|------------|------------|------------|
| Plugin version | | | |
| Git commit | | | |
| Module / CPT | | | |
| Total records | | | |
| Batch limit | | | |
| Field count selected | | | |
| Wall time (s) — median of 3 runs | | | |
| Completed? (Y/N) | | | |
| Stuck at offset | | | |
| Peak memory batch 1 (MB) | | | |
| Peak memory final (MB) | | | |
| CSV row count | | | |
| ACF/repeater verify | pass/fail | pass/fail | — |
| Cloneable verify | — | — | pass/fail |
| Rows/sec | total/wall | | |

---

## 7. Pass / fail criteria

| Criterion | Pass |
|-----------|------|
| Completion | 100% progress; file downloads |
| Row count | Matches DB post count |
| Batch boundary | No freeze at offset = limit (e.g. 500/1000) |
| Memory | Final peak ≤ 1.5× batch-1 peak (no linear growth) |
| ACF repeater | All sub-rows present in export |
| Meta Box cloneable | Full clone count per post |
| 8.15.5 vs target (OFF) | Wall time within **±10%**; same row/field integrity |
| 8.15.5 vs target (ON) | No new failures; may be slower |

---

## 8. Quick decision — what should YOU run?

| Your situation | Run this |
|----------------|----------|
| Import benchmark = 1000 WC products | **Scenario A** only (+ B later) |
| Issue #3 export freeze priority | **Scenario B** (CPT + ACF repeater) ⭐ |
| Meta Box cloneable bug reported | **Scenario C** |
| Minimal time | **Scenario B** with 1000 CPT + ACF, limit 500 |

---

## 9. Relationship to import benchmark

| Import benchmark | Export benchmark |
|------------------|------------------|
| 1000 WC products import | → use **Scenario A** export same products |
| 1000 ACF CPT import | → use **Scenario B** export same CPT |
| Can skip export now | ✅ Yes — add when Phase 3 done or before release |

**Best practice:** Use the **same CSV/import template** that created the data, then export with saved template so field mapping is symmetric.

---

## 10. Results template

Create `BENCHMARK_EXPORT_RESULTS.md` when you run export tests:

```markdown
# Export Benchmark Results

## Environment
- Date:
- Version: 8.15.5 / 8.16.x
- Commit:
- WP / PHP / WC:

## Scenario B — CPT + ACF (example)

| Run | Wall (s) | Peak mem (MB) | Rows in CSV | Stuck? | Pass |
|-----|----------|---------------|-------------|--------|------|
| 1   |          |               |             |        |      |
| 2   |          |               |             |        |      |
| 3   |          |               |             |        |      |
| Median |      |               |             |        |      |

### Field list used
- Core: post_title, post_status, ...
- ACF: field_x, repeater_*, ...

### Spot-check notes
- 

### Compare vs 8.15.5 baseline
- Delta wall time: %
- Regression: Y/N
```

---

## 11. Troubleshooting

| Symptom | Likely cause | Note for report |
|---------|--------------|-----------------|
| Stuck at 500/1000 | Batch memory not released | Issue #3 |
| CSV 500 rows only | Export stopped mid-run | Record offset |
| Empty ACF columns | Fields not selected in template | Re-select fields |
| Cloneable = 1 row only | Meta Box group truncation | Issue #3 |
| 403 on parse_data | Nonce/session | Re-login admin |

---

**Next:** Import benchmark first → when ready, run **Scenario B** (or A if WC-only) per this plan.
