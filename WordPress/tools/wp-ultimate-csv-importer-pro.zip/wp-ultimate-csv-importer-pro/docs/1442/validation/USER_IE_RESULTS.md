# User import/export validation (#1442 Phase 4 Tasks 4.8–4.9)

**Date:** 2026-08-04  
**Scope:** Regression posture for Issue 6 / #26455 — no code changes required unless a regression is found.

## Automated / static checks

| ID | Check | Result |
|----|-------|--------|
| PH4-20–24 | User import paths still call HooksHandler filters/actions via stub-compatible API | PASS (stub mirrors API) |
| PH4-24 | User export remains in core `ExportExtension` (not feature-gated) | PASS |
| PH4-25 | Multisite export — requires staging multisite; **manual** before Phase 5 | PENDING MANUAL |

## Manual matrix (operator)

Run with **all Feature Modules ON**, then repeat with **all OFF** (core user I/E must still work):

1. Import users CSV → login with imported password/email
2. Map custom user meta → re-open template → mapping persists
3. Role column → correct `wp_capabilities`
4. Export Users on single site → row count matches WP Users
5. Multisite subsite export → count > 0 (#26455)

Document timings/outcomes here when executed on staging.

## Conclusion

No user I/E regression found in Phase 4 code review. Multisite export confirmation remains a Phase 5 manual checklist item.
