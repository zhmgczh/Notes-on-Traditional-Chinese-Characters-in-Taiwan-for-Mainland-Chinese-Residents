#!/usr/bin/env python3
"""Parse antony.log uci_import_benchmark entries for quick comparison."""

from __future__ import annotations

import re
import sys
from datetime import datetime
from pathlib import Path


def parse_log(path: Path) -> dict:
    text = path.read_text()
    completes = []
    for block in re.findall(
        r"\[event\] => COMPLETE\n(.*?)\n\s*\)", text, flags=re.DOTALL
    ):
        page = re.search(r"\[page\] => (\d+)", block)
        dur = re.search(r"\[duration_sec\] => ([\d.]+)", block)
        mem = re.search(r"\[memory_peak_mb\] => (\d+)", block)
        status = re.search(r"\[status\] => (\w+)", block)
        ended = re.search(r"\[ended_at\] => ([^\n]+)", block)
        if page and dur:
            completes.append(
                {
                    "page": int(page.group(1)),
                    "duration_sec": float(dur.group(1)),
                    "memory_peak_mb": int(mem.group(1)) if mem else None,
                    "status": status.group(1) if status else None,
                    "ended_at": ended.group(1).strip() if ended else None,
                }
            )

    if not completes:
        return {"error": "No COMPLETE benchmark entries found."}

    durations = [c["duration_sec"] for c in completes]
    memories = [c["memory_peak_mb"] for c in completes if c["memory_peak_mb"]]
    total = sum(durations)

    first_start = re.search(r"\[started_at\] => ([^\n]+)", text)
    wall = None
    if first_start and completes[-1]["ended_at"]:
        t0 = datetime.strptime(first_start.group(1).strip(), "%Y-%m-%d %H:%M:%S")
        t1 = datetime.strptime(completes[-1]["ended_at"], "%Y-%m-%d %H:%M:%S")
        wall = (t1 - t0).total_seconds()

    records = len(completes) * 5  # default batch size

    return {
        "batches": len(completes),
        "pages": f"{completes[0]['page']}-{completes[-1]['page']}",
        "status": completes[-1]["status"],
        "total_batch_sec": round(total, 3),
        "avg_batch_sec": round(total / len(durations), 3),
        "min_batch_sec": round(min(durations), 3),
        "max_batch_sec": round(max(durations), 3),
        "wall_sec": round(wall, 1) if wall else None,
        "wall_min": round(wall / 60, 2) if wall else None,
        "peak_memory_mb": max(memories) if memories else None,
        "est_records": records,
        "rec_per_sec": round(records / wall, 3) if wall else None,
    }


def main() -> int:
    path = Path(sys.argv[1] if len(sys.argv) > 1 else "/var/www/html/antony.log")
    if not path.exists():
        print(f"Log not found: {path}")
        return 1

    result = parse_log(path)
    if "error" in result:
        print(result["error"])
        return 1

    label = sys.argv[2] if len(sys.argv) > 2 else "import"
    print(f"=== {label} ===")
    for key, value in result.items():
        print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
