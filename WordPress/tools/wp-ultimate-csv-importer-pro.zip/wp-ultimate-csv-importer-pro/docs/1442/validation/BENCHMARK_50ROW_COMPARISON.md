# Import Benchmark Comparison

**Date:** 2026-08-04  
**Template:** `csv_importer_products_benchmark_1000rows`  
**Batch size:** 5  

---

## 50-row runs (before fix)

| Metric | 8.15.5 | 8.16.x (before) | Delta |
|--------|--------|-----------------|-------|
| UI wall | **192 s** (3:12) | **237 s** (3:57) | +45 s |
| Avg batch | **18.32 s** | **22.60 s** | +23% |
| Peak memory | 20 MB | 20 MB | — |

---

## Root cause (profiled)

`woocommerce_product_import_new` spent ~2.9s/row in the post-meta switch:

1. **`downloadable_files`** always called `media_handling()` even when `download_type=external` (remote ZIP sideload per file).
2. **Empty `stock`** still did `$product->save()` + `wc_get_product()` every row.
3. **`PRODUCTSKU` helper** called an extra `$product->save()` mid-loop.
4. **`get_header_values`** re-queried `smackcsv_file_events` for every mapped field (ECOMMETA has 56 keys).

---

## Fixes

- Skip media sideload when `download_type` is `external` (keep remote URL).
- Skip empty `stock` path (no mid-loop save).
- `PRODUCTSKU`: set on product object only; defer to final save.
- Hoist file-extension lookup in `ImportHelpers::get_header_values`.
- Cache `FeatureRegistry` option states per request.

---

## 20-row CLI run (after fix) ✅

**CSV:** `/home/antony/Downloads/20_products_Csv-importer.csv`  
**Command:** `wp eval-file docs/1442/validation/run_20_product_benchmark.php --allow-root`

| Metric | Value |
|--------|-------|
| Batches | 4/4 Completed |
| **Avg batch** | **13.527 s** |
| Min / Max batch | 12.90 / 15.12 s |
| Wall | 54.1 s (0.90 min) |
| Throughput | **0.37 rec/s** |
| Goal `avg ≤ 18s` | **PASS** |

vs 8.15.5 50-row avg **18.32 s** → **faster**.
