# Toggle profiling results (#1442 Phase 4 Task 4.11)

**Date:** 2026-08-04  
**Environment:** Staging WP + Ultimate CSV Importer Pro (master)  
**Method:** Static include gate verification + FeatureRegistry OFF/ON smoke (`tests/phase4/test-phase4.php`)

## Loader gates verified

| Feature ID | OFF behavior | ON behavior |
|------------|--------------|-------------|
| `hook_system` | `HooksHandlerStub` loaded; no `hooks/Import/*` / `hooks/Export/*` | Real hook classes + WP meta listeners |
| `spreadsheet_editor` | Service/controller not required; UI skips to preview/config | Service + AJAX controller registered |
| `import_preview` | Service/controller not required; `import_preview_enabled=false` | Preview AJAX + UI |
| `import_retry` | Retry service/controller absent; retry UI hidden | Retry AJAX + summary UI |
| `import_resume` | Resume service/controller absent; banner not mounted | Resume AJAX + banner |
| `media_queue` | `MediaBootstrap` not init | Queue cron + settings AJAX |
| `ai_import` | AI bootstrap skipped; AI tabs/settings gated | AIBootstrap + NL import |
| `google_sheets` | `GsheetUpload` skipped; settings gated | Upload + OAuth |
| `automation_api` | AutomationBootstrap skipped | REST/webhooks |
| `db_migration` | DB migration bootstrap skipped | Upload tab + bootstrap |
| `woo_native_csv` | Native CSV bridge skipped | Bootstrap + auto-map |
| `wpbakery` / `bricks_builder` / `oxygen_builder` | Extension/import/export files skipped | Mapping fields present |
| `woo_surecart_migration` | Migration modules + controller skipped | Migration available when plugins active |

## Smoke metrics

- Phase 4 smoke: **all PASS** (`php tests/phase4/test-phase4.php`)
- Phase 3 smoke: **all PASS** (regression)

## Manual profiler note (pre–Phase 5)

Full Query Monitor `get_included_files()` / peak memory comparison vs 8.15.5 is deferred to Phase 5 benchmark on the same staging host with a clean theme. Gate wiring above is the Phase 4 exit requirement for zero-overhead when OFF.
