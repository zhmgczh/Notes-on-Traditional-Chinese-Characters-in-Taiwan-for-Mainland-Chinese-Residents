<?php
/**
 * CLI benchmark: import 20-product CSV using template csv_importer_products_benchmark_1000rows.
 *
 * Usage: wp eval-file docs/1442/validation/run_20_product_benchmark.php --allow-root
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Smackcoders\UCI\Proaddons\UltimatePro\SaveMapping;
use Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro;

$csv_src      = '/home/antony/Downloads/20_products_Csv-importer.csv';
$template_name = 'csv_importer_products_benchmark_1000rows';
$log_file      = '/var/www/html/antony.log';
$batch_size    = 5;

if ( ! file_exists( $csv_src ) ) {
	fwrite( STDERR, "CSV not found: {$csv_src}\n" );
	exit( 1 );
}

global $wpdb;

// Fresh log.
file_put_contents( $log_file, '' );

$upload_dir = UltimatePro::getInstance()->create_upload_dir();
$hash_key   = md5( 'bench20_' . microtime( true ) );
$dest_dir   = $upload_dir . $hash_key . '/';
if ( ! is_dir( $dest_dir ) ) {
	wp_mkdir_p( $dest_dir );
}
$dest_file = $dest_dir . $hash_key;
copy( $csv_src, $dest_file );

$rows = 0;
if ( ( $fh = fopen( $dest_file, 'r' ) ) !== false ) {
	fgetcsv( $fh, 0, ',', '"', '\\' ); // header
	while ( fgetcsv( $fh, 0, ',', '"', '\\' ) !== false ) {
		$rows++;
	}
	fclose( $fh );
}

$file_table     = $wpdb->prefix . 'smackcsv_file_events';
$template_table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
$log_table      = $wpdb->prefix . 'import_detail_log';

$wpdb->insert(
	$file_table,
	array(
		'file_name'  => basename( $csv_src ),
		'hash_key'   => $hash_key,
		'total_rows' => (string) $rows,
		'mode'       => 'Insert',
		'status'     => 'Processing',
	)
);

$template = $wpdb->get_row(
	$wpdb->prepare(
		"SELECT mapping, mapping_filter, module FROM {$template_table} WHERE templatename = %s ORDER BY id DESC LIMIT 1",
		$template_name
	)
);

if ( ! $template ) {
	fwrite( STDERR, "Template not found: {$template_name}\n" );
	exit( 1 );
}

$wpdb->insert(
	$template_table,
	array(
		'eventKey'       => $hash_key,
		'templatename'   => $template_name . '_cli20',
		'mapping'        => $template->mapping,
		'mapping_filter' => $template->mapping_filter,
		'module'         => $template->module,
		'createdtime'    => current_time( 'mysql' ),
	)
);

update_option( 'sm_bulk_import_iteration_limit', $batch_size );

// Remove prior products with the same SKUs so Insert mode creates fresh rows.
if ( ( $fh = fopen( $csv_src, 'r' ) ) !== false ) {
	$hdr = fgetcsv( $fh, 0, ',', '"', '\\' );
	$sku_idx = array_search( 'PRODUCTSKU', $hdr, true );
	if ( false !== $sku_idx ) {
		while ( ( $r = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) {
			$sku = isset( $r[ $sku_idx ] ) ? trim( (string) $r[ $sku_idx ] ) : '';
			if ( $sku === '' || ! function_exists( 'wc_get_product_id_by_sku' ) ) {
				continue;
			}
			// Delete all products that share this base SKU or -IMP* remaps.
			$like = $wpdb->esc_like( $sku ) . '%';
			$ids  = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value LIKE %s",
					$like
				)
			);
			foreach ( $ids as $pid ) {
				wp_delete_post( (int) $pid, true );
			}
		}
	}
	fclose( $fh );
}

$user = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
if ( empty( $user ) ) {
	fwrite( STDERR, "No administrator user found.\n" );
	exit( 1 );
}
wp_set_current_user( $user[0]->ID );
$nonce = wp_create_nonce( 'smack-ultimate-csv-importer-pro' );
$sm    = SaveMapping::getInstance();

$total_pages = (int) ceil( $rows / $batch_size );
echo "hash={$hash_key} rows={$rows} pages={$total_pages} batch={$batch_size}\n";

add_filter(
	'wp_die_handler',
	static function () {
		return static function ( $message = '', $title = '', $args = array() ) {
			throw new \RuntimeException( is_string( $message ) ? $message : 'wp_die' );
		};
	}
);

$wall_start = microtime( true );

for ( $page = 1; $page <= $total_pages; $page++ ) {
	$_POST = array(
		'securekey'          => $nonce,
		'HashKey'            => $hash_key,
		'Check'              => '',
		'PageNumber'         => (string) $page,
		'RollBack'           => 'false',
		'UpdateUsing'        => 'normal',
		'mappingFilterCheck' => 'false',
		'iscategories'       => 'false',
		'Categories'         => '[]',
		'cleanWithAI'        => 'false',
	);
	$_REQUEST = $_POST;

	ob_start();
	try {
		$sm->bulk_import();
	} catch ( \RuntimeException $e ) {
		// Expected from wp_die() at end of bulk_import.
	}
	$out = ob_get_clean();
	echo "page {$page} done bytes=" . strlen( (string) $out ) . "\n";
}

$wall = microtime( true ) - $wall_start;
echo sprintf( "WALL_SEC=%.3f WALL_MIN=%.2f\n", $wall, $wall / 60 );

// Parse antony.log summary.
$text      = file_get_contents( $log_file );
$completes = array();
if ( preg_match_all( '/\[event\] => COMPLETE\n(.*?)\)\n/s', $text, $matches ) ) {
	foreach ( $matches[1] as $block ) {
		if ( ! preg_match( '/\[duration_sec\] => ([\d.]+)/', $block, $d ) ) {
			continue;
		}
		$completes[] = (float) $d[1];
	}
}

if ( $completes ) {
	$avg = array_sum( $completes ) / count( $completes );
	echo sprintf(
		"batches=%d avg_batch_sec=%.3f min=%.3f max=%.3f sum=%.3f\n",
		count( $completes ),
		$avg,
		min( $completes ),
		max( $completes ),
		array_sum( $completes )
	);
	echo ( $avg <= 18.0 ) ? "PASS avg_batch <= 18s\n" : "FAIL avg_batch > 18s\n";
} else {
	echo "No COMPLETE entries in antony.log\n";
}
