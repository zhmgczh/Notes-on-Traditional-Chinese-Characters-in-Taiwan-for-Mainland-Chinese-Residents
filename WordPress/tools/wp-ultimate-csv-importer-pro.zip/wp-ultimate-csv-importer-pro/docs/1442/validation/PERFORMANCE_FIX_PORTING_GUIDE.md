# Performance Fix Porting Guide — #1442

**Source plugin:** `wp-ultimate-csv-importer-pro` (8.16.7)  
**Target addons:** `wpml-import`, `custom-field-pro`  
**Purpose:** Share this file with Cursor in each addon repo to apply the same import performance fixes.

---

## Results (why these fixes matter)

| Version | 1K products | Avg batch | Improvement |
|---------|-------------|-----------|-------------|
| 8.15.5 | 64 min | 19.2 s | baseline |
| 8.16.7 | 40 min | 12 s | **37.5% faster** |

20-row UI test after fix: **11.57 s** avg batch (goal ≤ 18 s).

Machine-readable: `BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv`

---

## Fix matrix — which plugin gets what

| # | Fix | Main Pro | wpml-import | custom-field-pro |
|---|-----|:--------:|:-----------:|:----------------:|
| 1 | `get_header_values()` — file extension query once | ✅ `ImportHelpers.php` | ⚠️ if duplicate exists | ⚠️ if duplicate exists |
| 2 | `FeatureRegistry` — in-request `get_option` cache | ✅ `includes/FeatureRegistry.php` | ❌ N/A (main plugin) | ❌ N/A (main plugin) |
| 3 | `CoreFieldsImport` — hoist ExtensionHandler + file query per row | ✅ | ❌ N/A | ❌ N/A |
| 4 | `CoreFieldsImport` — Jet Engine CCT slug cache | ✅ | ❌ N/A | ❌ N/A |
| 5 | `WooCommerceCoreImport` — SKU no mid-save | ✅ | ❌ N/A | ❌ N/A |
| 6 | `WooCommerceCoreImport` — empty stock skip save | ✅ | ❌ N/A | ❌ N/A |
| 7 | `WooCommerceCoreImport` — external download skip sideload | ✅ | ❌ N/A | ❌ N/A |
| 8 | `WordpressCustomImport` — `get_post_custom_keys` once per post | ✅ | ⚠️ check equivalent | ✅ **likely** |
| 9 | Per-field DB queries in import loops | ✅ | ✅ **check** | ✅ **check** |
| 10 | `get_header_values()` inside loops — hoist to once per row | ✅ | ✅ **check** | ✅ **check** |

**Legend:** ✅ = already fixed in main pro · ⚠️ = search addon for same pattern · ❌ = not applicable

---

## How to use this guide in Cursor

1. Open the **target addon repo** (`wpml-import` or `custom-field-pro`).
2. Paste this entire MD file into Cursor chat **or** `@`-reference it.
3. Use the prompt at the bottom of this file.
4. Run `php -l` on every changed file.
5. Re-import 20 rows and compare `antony.log` avg batch time.

---

## Fix 1 — `get_header_values()` file extension query (SHARED)

### Problem
Inside `get_header_values()`, for **every mapped field** the code ran:

```sql
SELECT file_name FROM wp_smackcsv_file_events WHERE hash_key = '...'
```

With 56 ECOMMETA fields → **56 identical DB queries per row**.

### File (main pro)
`importExtensions/ImportHelpers.php` — method `get_header_values()`

### Search in addons
```bash
rg "smackcsv_file_events" --glob "*.php"
rg "function get_header_values" --glob "*.php"
rg "pathinfo.*file_name.*PATHINFO_EXTENSION" --glob "*.php"
```

### Before (inside `foreach ($map as $key => $value)`)
```php
$file_table_name = $wpdb->prefix . "smackcsv_file_events";
$get_id = $wpdb->get_results("SELECT file_name FROM $file_table_name WHERE `hash_key` = '$hash_key'");
$file_name = !empty($get_id[0]->file_name) ? $get_id[0]->file_name : '';
if (!empty($file_name) && isset($file_name)) {
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
}
```

### After (once at start of `if ( is_array( $map ) )` block, before the foreach)
```php
$file_extension = '';
if ( ! empty( $hash_key ) ) {
    $file_table_name = $wpdb->prefix . 'smackcsv_file_events';
    $file_name       = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT file_name FROM {$file_table_name} WHERE hash_key = %s LIMIT 1",
            $hash_key
        )
    );
    if ( ! empty( $file_name ) ) {
        $file_extension = pathinfo( $file_name, PATHINFO_EXTENSION );
    }
}
```

Then **remove** the duplicate query from inside the foreach loop.

### Applies to
- **Main pro:** ✅ done
- **wpml-import:** only if addon has its own `get_header_values()` copy (unlikely — usually calls main `ImportHelpers`)
- **custom-field-pro:** only if addon duplicates `ImportHelpers` or has per-field file-extension lookup in import loops

---

## Fix 2 — `FeatureRegistry` in-request cache (MAIN PRO ONLY)

### Problem
`FeatureRegistry::is_enabled()` called `get_option()` on **every** check. Import path calls it dozens of times per row.

### File (main pro)
`includes/FeatureRegistry.php`

### Search
```bash
rg "function is_enabled|function is_feature_enabled" includes/ --glob "*.php"
rg "get_option.*OPTION_KEY" includes/ --glob "*.php"
```

### Change
Add static cache property:

```php
/** @var array<string, bool>|null In-request cache of option states. */
private static $states_cache = null;
```

In `is_feature_enabled()` replace direct `get_option` with:

```php
if ( null === self::$states_cache ) {
    $stored = get_option( self::OPTION_KEY, array() );
    self::$states_cache = is_array( $stored ) ? $stored : array();
}

if ( ! array_key_exists( $id, self::$states_cache ) ) {
    return true;
}

return (bool) self::$states_cache[ $id ];
```

In `set_states()` (or wherever option is updated), also set:

```php
self::$states_cache = $current;
```

### Applies to
- **Main pro:** ✅ done
- **Addons:** N/A unless addon has its own feature registry

---

## Fix 3 — `CoreFieldsImport` hoist per-row lookups (MAIN PRO — CPT/post/page)

### Problem
CPT import path (`else` branch in `set_core_values`) ran **inside `foreach ($map as $key => $value)`** on every mapped field:

1. `new ExtensionHandler()` + `import_type_as()` + `import_post_types()`
2. `SELECT file_name FROM smackcsv_file_events WHERE hash_key = ...`

### File (main pro)
`importExtensions/CoreFieldsImport.php` — around line 735 (CPT `else` branch)

### Search in addons
```bash
rg "new ExtensionHandler" --glob "*.php"
rg "import_type_as\(" --glob "*.php"
rg "smackcsv_file_events.*hash_key" --glob "*.php"
```

### Before (inside foreach — BAD)
```php
foreach ($map as $key => $value) {
    $extension_object = new ExtensionHandler;
    $import_type = $extension_object->import_type_as($type);
    $import_as = $extension_object->import_post_types($import_type);

    $file_table_name = $wpdb->prefix . "smackcsv_file_events";
    $get_id = $wpdb->get_results("SELECT file_name FROM $file_table_name WHERE `hash_key` = '$hash_key'");
    $file_name = $get_id[0]->file_name;
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
    // ...
}
```

### After (before foreach — GOOD)
```php
// Resolve once per row (was inside foreach — N queries per mapped field).
$extension_object = new ExtensionHandler();
$import_type        = $extension_object->import_type_as( $type );
$import_as          = $extension_object->import_post_types( $import_type );
$file_extension     = '';
if ( ! empty( $hash_key ) ) {
    $file_table_name = $wpdb->prefix . 'smackcsv_file_events';
    $file_name       = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT file_name FROM {$file_table_name} WHERE hash_key = %s LIMIT 1",
            $hash_key
        )
    );
    if ( ! empty( $file_name ) ) {
        $file_extension = pathinfo( $file_name, PATHINFO_EXTENSION );
    }
}
$pattern1 = '/{([^}]*)}/';
$pattern2 = '/\[([^\]]*)\]/';

foreach ($map as $key => $value) {
    // use $import_as, $file_extension, $pattern1, $pattern2 — no re-query
}
```

Also replace duplicate ExtensionHandler after the loop:

```php
// Before:
$extension_object = new ExtensionHandler;
$import_as_fallback = $extension_object->import_post_types(...);

// After:
$import_as_fallback = $import_as;
```

### Applies to
- **Main pro:** ✅ done
- **wpml-import / custom-field-pro:** search for same anti-pattern in any import class that manually loops `$map` instead of calling `get_header_values()`

---

## Fix 4 — Jet Engine CCT slug cache (MAIN PRO)

### Problem
Every import row queried `wp_jet_post_types` to detect Jet Engine CCT type.

### File (main pro)
`importExtensions/CoreFieldsImport.php`

### Search
```bash
rg "jet_post_types WHERE status = 'content-type'" --glob "*.php"
```

### Change
Add class property:

```php
/** @var array<string,bool>|null Jet Engine CCT slug cache for the current request. */
private static $jet_cct_slug_cache = null;
```

Replace per-row query loop with:

```php
if ( is_plugin_active( 'jet-engine/jet-engine.php' ) ) {
    if ( null === self::$jet_cct_slug_cache ) {
        self::$jet_cct_slug_cache = array();
        $get_slug_name = $wpdb->get_results(
            "SELECT slug FROM {$wpdb->prefix}jet_post_types WHERE status = 'content-type'"
        );
        foreach ( $get_slug_name as $get_slug ) {
            self::$jet_cct_slug_cache[ $get_slug->slug ] = true;
        }
    }
    if ( isset( self::$jet_cct_slug_cache[ $type ] ) ) {
        $optional_type = $type;
    }
}
```

### Applies to
- **Main pro:** ✅ done
- **Addons:** only if addon has duplicate Jet CCT detection

---

## Fix 5 — WooCommerce SKU — remove mid-save (MAIN PRO — WC only)

### Problem
`update_product_sku_with_debug()` called `$product->save()` mid-import. Caller already does a final save → **double save per row**.

### File (main pro)
`importExtensions/WooCommerceCoreImport.php` — method `update_product_sku_with_debug()`

### Search
```bash
rg "set_sku.*save\(\)|update_product_sku" --glob "*.php"
```

### Before
```php
if (is_object($product) && method_exists($product, 'set_sku') && method_exists($product, 'save')) {
    $product->set_sku($normalized_sku);
    $product->save();
}
```

### After
```php
// Set on the in-memory product only — caller does a single final save.
if (is_object($product) && method_exists($product, 'set_sku')) {
    $product->set_sku($normalized_sku);
}
```

### Applies to
- **Main pro:** ✅ done
- **Addons:** N/A (WooCommerce core import lives in main pro)

---

## Fix 6 — WooCommerce empty stock — skip save+reload (MAIN PRO — WC only)

### Problem
`case 'stock':` always called `$product->save()` + `wc_get_product()` even when stock value was empty → ~0.4–0.8 s wasted per row.

### File (main pro)
`importExtensions/WooCommerceCoreImport.php` — `woocommerce_product_import_new()` switch case `'stock'`

### Search
```bash
rg "case 'stock':" importExtensions/ --glob "*.php"
```

### Before
```php
case 'stock':
    if(!empty($post_values[$post_key])){
        // set stock status...
    }
    $product->set_stock_quantity($post_values[$post_key]);
    $product_id = $product->save();
    $product = wc_get_product($product_id);
    break;
```

### After
```php
case 'stock':
    // Skip empty stock to avoid an extra WC save+reload per row (~0.4–0.8s).
    if ( $post_values[ $post_key ] === '' || $post_values[ $post_key ] === null ) {
        break;
    }
    if ( ! empty( $post_values[ $post_key ] ) || (string) $post_values[ $post_key ] === '0' ) {
        $stock_status = 'instock';
        if ( ! $product->is_type( 'external' ) && method_exists( $product, 'set_stock_status' ) ) {
            $product->set_manage_stock( true );
            $product->set_stock_status( $stock_status );
        }
        $product->set_stock_quantity( $post_values[ $post_key ] );
    }
    break;
```

**Important:** Do NOT call `$product->save()` here — let the final save at end of row handle it.

### Applies to
- **Main pro:** ✅ done
- **Addons:** N/A

---

## Fix 7 — WooCommerce external downloads — skip sideload (MAIN PRO — WC only)

### Problem
`downloadable_files` always called `media_handling()` (remote download/sideload) even when `download_type=external`. Remote ZIP sideload added **~2.9 s per row** in benchmark.

### File (main pro)
`importExtensions/WooCommerceCoreImport.php` — case `'downloadable_files'`

### Search
```bash
rg "downloadable_files|download_type" importExtensions/ --glob "*.php"
```

### After (key logic)
```php
$download_types = array();
if ( ! empty( $post_values['download_type'] ) ) {
    $download_types = array_map( 'trim', explode( '|', (string) $post_values['download_type'] ) );
}
foreach ( $exploded_file_data as $file_index => $file_datas ) {
    $exploded_separate = explode( ',', $file_datas );
    $file_name_dl      = isset( $exploded_separate[0] ) ? trim( $exploded_separate[0] ) : '';
    $file_url_raw      = isset( $exploded_separate[1] ) ? trim( $exploded_separate[1] ) : '';
    if ( $file_url_raw === '' ) {
        continue;
    }
    $download = new \WC_Product_Download();
    $download->set_name( $file_name_dl );
    $file_type = isset( $download_types[ $file_index ] ) ? strtolower( $download_types[ $file_index ] ) : '';

    // External downloadable files must keep the remote URL — do not sideload.
    if ( 'external' === $file_type ) {
        $download->set_id( md5( $file_url_raw ) );
        $download->set_file( $file_url_raw );
        $downloads[] = $download;
        continue;
    }

    // Standard / file type — sideload via media_handling
    $attachment_id = $media_instance->media_handling( $file_url_raw, $product_id, ... );
    // ...
}
```

### Applies to
- **Main pro:** ✅ done
- **Addons:** N/A

---

## Fix 8 — `get_post_custom_keys()` once per post (CUSTOM FIELDS)

### Problem
`get_post_custom_keys($pID)` ran **inside foreach** for every custom field → expensive DB/meta cache hit per field.

### File (main pro)
`importExtensions/WordpressCustomImport.php` — `wordpress_custom_user_import_function()`

### Search in custom-field-pro
```bash
rg "get_post_custom_keys" --glob "*.php"
rg "apply_custom_field_filter" --glob "*.php"
rg "update_post_meta" importExtensions/ --glob "*.php"
```

### Before (inside foreach)
```php
foreach ($data_array as $custom_key => $custom_value) {
    // ...
    $existing_meta_keys = get_post_custom_keys($pID) ?: [];
    $custom_value = HooksHandler::...->apply_custom_field_filter(..., $existing_meta_keys, ...);
    update_post_meta($pID, $custom_key, $custom_value);
}
```

### After (before foreach)
```php
$existing_meta_keys = ( $importType !== 'Users' )
    ? ( get_post_custom_keys( $pID ) ?: array() )
    : array();

foreach ($data_array as $custom_key => $custom_value) {
    // reuse $existing_meta_keys — do NOT call get_post_custom_keys again
}
```

### Follow-up in main pro (not yet fixed — apply in addons too)
Same pattern exists in `wordpress_custom_import_function()` ~line 205:

```php
// Still inside loop — should hoist to function start:
$existing_meta_keys = get_post_custom_keys($pID) ?: [];
```

**custom-field-pro:** search ALL import functions for this pattern and hoist once per post/row.

### Applies to
- **Main pro:** ✅ partial (`wordpress_custom_user_import_function` done)
- **custom-field-pro:** ✅ **high priority** — likely has ACF/MetaBox/Pods import loops with same issue
- **wpml-import:** check if term/post meta loops repeat `get_post_custom_keys` or `get_term_meta`

---

## Fix 9 — `get_header_values()` called multiple times per row (ADDONS)

### Problem
Import row handler may call `get_header_values()` separately for each field group (WPML, poly, meta, etc.) — each call re-processes the full map.

### File (main pro) — example hot path
`importExtensions/CoreFieldsImport.php` — `set_core_values()` WooCommerce branch:

```php
$post_values = $helpers_instance->get_header_values($map, ...);
$wpml_values = $helpers_instance->get_header_values($wpml_array, ...);
$poly_values = $helpers_instance->get_header_values($poly_array, ...);
```

This is **acceptable** when maps are different groups. Fix only if the **same map** is passed repeatedly, or if addon duplicates file-extension query inside its own loop.

### Search in wpml-import
```bash
rg "get_header_values" --glob "*.php"
rg "set_wpml_values|wpml_import_function" --glob "*.php"
```

### wpml-import likely files
| Expected file | What to check |
|---------------|---------------|
| `importExtensions/WPMLImport.php` | `set_wpml_values()` — uses `get_header_values()` once ✅ |
| `wpml_import_function()` | Per-row `$wpdb->get_var` on `icl_languages` — consider caching active language codes per request |
| Any manual `$map` foreach | Apply Fix 3 pattern |

### wpml-import extra optimization (recommended)
In `WPMLImport::wpml_import_function()` these run per row:

```php
$is_active = $wpdb->get_var("select active from {$wpdb->prefix}icl_languages where code = '$lang_code'");
```

**Cache pattern:**
```php
private static $icl_language_cache = null;

// In method:
if ( null === self::$icl_language_cache ) {
    self::$icl_language_cache = array(); // populate from icl_languages once
}
```

Use `$wpdb->prepare()` instead of string interpolation for SQL.

### Search in custom-field-pro
```bash
rg "get_header_values|get_meta_values" importExtensions/ --glob "*.php"
rg "foreach.*meta|update_post_meta|update_field" importExtensions/ --glob "*.php"
```

### custom-field-pro likely files
| Expected file | What to check |
|---------------|---------------|
| `importExtensions/ACFProImport.php` | Per-field DB queries, repeated `get_field_object()` |
| `importExtensions/MetaBoxImport.php` | Same |
| `importExtensions/PodsImport.php` | Same |
| `importExtensions/ToolsetImport.php` | Same |
| Any `*Import.php` | `get_post_custom_keys` inside loops (Fix 8) |

---

## Fix 10 — General rules for addon import loops

When reviewing **any** `foreach` in import extensions, flag:

| Anti-pattern | Fix |
|--------------|-----|
| DB query inside `foreach ($map ...)` | Hoist before loop |
| `new SomeClass()` inside loop | Hoist or use singleton `::getInstance()` |
| `$product->save()` / `wc_get_product()` mid-switch | Single save at end of row |
| `media_handling()` for external URLs | Check type flag first; skip sideload |
| `get_option()` / `get_post_custom_keys()` in loop | Cache per request or per post |
| Unprepared SQL with variables | Use `$wpdb->prepare()` |

---

## Files changed in main pro (git diff summary)

| File | Fix # | Description |
|------|-------|-------------|
| `importExtensions/ImportHelpers.php` | 1 | File extension query once in `get_header_values()` |
| `includes/FeatureRegistry.php` | 2 | `$states_cache` for `is_enabled()` |
| `importExtensions/CoreFieldsImport.php` | 3, 4 | Hoist per-row queries; Jet CCT cache |
| `importExtensions/WooCommerceCoreImport.php` | 5, 6, 7 | SKU, stock, downloadable_files |
| `importExtensions/WordpressCustomImport.php` | 8 | `get_post_custom_keys` once per post |

---

## Verification after porting

### 1. Syntax check
```bash
find importExtensions includes -name "*.php" -print0 | xargs -0 -n1 php -l
```

### 2. Import benchmark (20 products, batch=5)
```bash
php docs/1442/validation/run_20_product_benchmark.php
# Target: avg_batch_sec <= 18 (ideally ~12)
```

### 3. Parse log
```bash
python3 docs/1442/validation/parse_benchmark_log.py /var/www/html/antony.log "addon test"
```

### 4. CPT smoke test
Import 20 rows of a CPT with 10+ custom fields mapped. Compare batch time before/after.

### 5. WPML smoke test (wpml-import)
Import 20 posts with `language_code` + `translated_post_title` mapped. No functional regression.

### 6. Custom fields smoke test (custom-field-pro)
Import 20 posts with ACF/MetaBox fields. Verify values saved; batch time improved.

---

## Cursor prompt — copy/paste per addon

### For `wpml-import`

```
Read docs/1442/validation/PERFORMANCE_FIX_PORTING_GUIDE.md (or paste its contents).

Apply all applicable performance fixes to this wpml-import addon repo:

1. Search for per-field / per-loop DB queries (especially smackcsv_file_events, icl_languages).
2. Apply Fix 3 pattern: hoist ExtensionHandler and file_extension lookup outside foreach loops.
3. Apply Fix 8 if get_post_custom_keys is inside loops.
4. Cache icl_languages lookups per request (see Fix 9 wpml-import section).
5. Use $wpdb->prepare() for any raw SQL with variables.
6. Do NOT change import behavior — performance only.
7. Run php -l on all changed files.
8. List every file changed and which fix # was applied.
```

### For `custom-field-pro`

```
Read docs/1442/validation/PERFORMANCE_FIX_PORTING_GUIDE.md (or paste its contents).

Apply all applicable performance fixes to this custom-field-pro addon repo:

1. Search ALL importExtensions/*Import.php files for:
   - get_post_custom_keys() inside foreach loops → hoist once per post (Fix 8)
   - get_header_values() duplicate file_extension queries (Fix 1)
   - DB queries inside foreach ($map) or foreach ($data_array) (Fix 10)
2. For ACF/MetaBox/Pods/Toolset import classes: cache field definitions per request where same field is looked up every row.
3. Do NOT call save/update mid-loop if a final save exists at row end.
4. Do NOT change field mapping behavior — performance only.
5. Run php -l on all changed files.
6. List every file changed and which fix # was applied.
```

---

## Related docs

| File | Purpose |
|------|---------|
| `BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv` | 8.15.5 vs 8.16.7 numbers |
| `BENCHMARK_50ROW_COMPARISON.md` | 50-row before/after detail |
| `run_20_product_benchmark.php` | CLI 20-product benchmark |
| `parse_benchmark_log.py` | Parse antony.log batch stats |
| `BENCHMARK_BASELINE_8.15.5.md` | Full BL-02 baseline write-up |

---

**Last updated:** 2026-08-04  
**Author:** Antony S / Cursor implementation branch
