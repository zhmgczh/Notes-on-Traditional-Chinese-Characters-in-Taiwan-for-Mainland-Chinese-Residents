# 03 — Phase 3: Export, Media & Google Sheets

**Duration:** ~2 days  
**Depends on:** Phase 2 complete (ImportValueResolver pattern established; FeatureLoader operational)  
**Blocks:** Phase 5 benchmark (export and media metrics)  

**Pre-implementation audit:** ✅ Complete (2026-08-04)  
**Implementation:** ✅ Complete (2026-08-04) — Tasks 3.1–3.13 merged; PH3 smoke tests pass

### Audit findings (consolidated) — resolved

| Area | Key finding | Status |
|------|-------------|--------|
| **Export** | `ExportBatchContext` + batch lifecycle in `ExportExtension` | ✅ Tasks 3.1–3.5 |
| **Export All** | `resetExportBatchState()` between zip modules | ✅ Task 3.3 |
| **Media** | Settings enforced, exponential backoff, gallery isolation | ✅ Tasks 3.6–3.8 |
| **GSheet** | Transport retry/reason codes, session cache, preflight | ✅ Task 3.10 |
| **FeatureLoader** | `media_queue`, `google_sheets`, builders, `woo_native_csv` gated | ✅ Tasks 3.9–3.13 |
| **UI** | `enabledFeatures.js` gates for Phase 3 toggles | ✅ Tasks 3.9–3.13 |

---

## Objective

Resolve issue groups **3, 5, and 7** from #1442, and extend **FeatureLoader** to media queue, builder extensions, and Google Sheets modules.

| Issue | Priority | Refs |
|-------|----------|------|
| 3 — Export freezing (CPT / ACF / Meta Box) | High | #26846, #26819 |
| 5 — Media remote upload | Medium | #26819 |
| 7 — Google Sheets connection stability | Medium | #26814, #26387, #25676, #26409 |

---

## Scope

### In scope

- `ExportBatchContext` lifecycle for batched exports
- Memory cleanup after each export batch
- Meta Box cloneable group export fix
- Media download timeout, retry with backoff, partial failure recovery
- Google Sheets connection lifecycle improvements
- FeatureLoader gates: `media_queue`, `google_sheets`, `oxygen_builder`, `wpbakery` (optional perf), `woo_native_csv`

> **Note:** `media/MediaBootstrap.php` loads only when `media_queue` toggle is ON (Task 3.9). Inline `MediaHandling.php` remains in core for baseline imports.

### Task completion summary

| Task | Status | Key deliverable |
|------|--------|-----------------|
| 3.1 | ✅ | `includes/ExportBatchContext.php` |
| 3.2 | ✅ | Batch lifecycle in `ExportExtension` |
| 3.3 | ✅ | `ExportAll::resetExportBatchState()` |
| 3.4 | ✅ | Meta Box cloneable dedup + full aggregation |
| 3.5 | ✅ | ACF cache scoped to batch context |
| 3.6 | ✅ | `MediaHandling::get_download_settings()` |
| 3.7 | ✅ | Exponential backoff + file validation |
| 3.8 | ✅ | `MediaGalleryImporter::parse_urls()` per-URL |
| 3.9 | ✅ | `media_queue` FeatureLoader + settings UI |
| 3.10 | ✅ | `GoogleSheetsHttpTransport` + `GoogleSheetsSession` |
| 3.11 | ✅ | `google_sheets` loader + upload tab gate |
| 3.12 | ✅ | Builder extension conditional load |
| 3.13 | ✅ | `woo_native_csv` bootstrap + mapping gate |

### Automated verification

Run: `php tests/phase3/test-phase3.php` — covers PH3-01/02, 10–15, 20–24 (smoke-level).

### Out of scope

- HooksHandler stub (Phase 4)
- Rank Math (Phase 4)
- React bundle code-splitting
- Full benchmark (Phase 5)

---

## Related Source Files

### Issue 3 — Export

| File | Role |
|------|------|
| `exportExtensions/ExportExtension.php` | `parseData()`, `exportData()`, `FetchDataByPostTypes()` |
| `exportExtensions/ExportAll.php` | Multi-module zip export |
| `exportExtensions/PostExport.php` | ACF + Meta Box + Pods/Toolset meta export (no separate MetaBoxExport/ACFExport files) |
| `extensionModules/MetaBoxGroupExtension.php` | Meta Box cloneable group field discovery |
| `importExtensions/MetaBoxGroupImport.php` | Cloneable group reference |
| `includes/ExportBatchContext.php` | **New** per-batch state holder |

### Issue 5 — Media

| File | Role |
|------|------|
| `MediaHandling.php` | Inline download, gallery |
| `media/MediaBootstrap.php` | Queue bootstrap |
| `media/Services/MediaDownloadProcessor.php` | Batch processor |
| `media/Services/MediaRetryManager.php` | Retry logic |
| `media/Services/MediaQueueManager.php` | Cron queue |
| `media/Services/MediaDownloadSettings.php` | Settings option |
| `FailedImagesUpdate.php` | Failed image queue |
| `media/Controllers/MediaDownloadSettingsController.php` | Settings AJAX |

### Issue 7 — Google Sheets

| File | Role |
|------|------|
| `uploadModules/GoogleSheetsHttpTransport.php` | HTTP retry layer |
| `uploadModules/GsheetUpload.php` | Sheet import |
| `uploadModules/UrlUpload.php` | Published URL fallback |
| `controllers/GSheet.php` | OAuth |
| `uploadModules/GoogleDriveUpload.php` | Shared transport |

### FeatureLoader

| File | Role |
|------|------|
| `includes/FeatureLoader.php` | Extension group loading |
| `extensionModules/WPBakeryExtension.php` | WPBakery mapping |
| `extensionModules/BricksExtension.php` | Bricks mapping |
| `extensionModules/OxygenExtension.php` | Oxygen mapping |

---

## Dependencies

| Dependency | Reason |
|------------|--------|
| Phase 2 Task 2.1–2.3 | Scheduler stable for GSheet cron imports |
| Phase 1 Task 1.5 | `enabled_features` for UI hide |
| Meta Box + ACF on test site | Export freeze reproduction |
| Large dataset (5K+ posts) | Export batch testing |

---

## Implementation Order

---

### Task 3.1 — ExportBatchContext class

**Commit:** `[#1442] Add ExportBatchContext for isolated batch state`

**Work:**
- Create `includes/ExportBatchContext.php`.
- Holds: batch index, iterators, temp arrays, query offsets, module-specific caches.
- Methods: `reset()`, `destroy()`, `get_memory_usage()`.
- No integration yet — class only.

**Validation:** Instantiable in isolation; no production wiring.

**Exit:** Class merged.

---

### Task 3.2 — Integrate ExportBatchContext in ExportExtension

**Commit:** `[#1442] Reset export batch context after each parseData batch`

**Work:**
- Refactor `ExportExtension::parseData()` / `exportData()` to create context per batch.
- After each batch write: call `context->destroy()`, `unset()` large arrays, `wp_cache_flush()` if safe.
- Add memory guard: if peak > filterable threshold, force GC + context reset.
- Standardize batch lifecycle: `fetch_batch` → `format_batch` → `write_batch` → `cleanup_batch`.

**Depends on:** Task 3.1

**Risks:** Premature cache flush affecting other plugins — scope flush to plugin-owned keys only.

**Validation:** PH3-01, PH3-02.

**Exit:** Core export batched without memory growth.

---

### Task 3.3 — ExportAll zip batch cleanup

**Commit:** `[#1442] Fix ExportAll memory retention between zip modules`

**Work:**
- Apply same context pattern in `ExportAll.php`.
- Close file handles explicitly after each module export.
- Reset module iterators between zip entries.

**Depends on:** Task 3.2

**Validation:** PH3-03.

**Exit:** Export All completes for 10+ modules.

---

### Task 3.4 — Meta Box cloneable group export fix

**Commit:** `[#1442] Fix Meta Box cloneable group truncation in batched export`

**Work:**
- Audit `PostExport.php` Meta Box methods (`resolve_metabox_group_meta_value`, `metabox_groupclone`, etc.) for static/persistent state between batches.
- Ensure cloneable groups flush complete group count per post within single batch.
- Reset group iterators in `cleanup_batch`.

**Depends on:** Task 3.2

**Validation:** PH3-04.

**Exit:** Cloneable groups export full row count.

---

### Task 3.5 — ACF / CPT export batch consistency

**Commit:** `[#1442] Standardize batch lifecycle across ACF and CPT exporters`

**Work:**
- Audit CPT export paths in `ExportExtension::FetchDataByPostTypes()`.
- Apply `ExportBatchContext` to ACF paths in `PostExport.php` (`$acf_structure_cache`, repeater/flexible logic).
- Document batch interface in code comment (internal dev doc).

**Depends on:** Task 3.2

**Validation:** PH3-05, PH3-06.

**Exit:** CPT export 5K posts completes.

---

### Task 3.6 — Media download settings enforcement

**Commit:** `[#1442] Enforce media download timeout and retry settings in MediaHandling`

**Work:**
- Audit `MediaHandling.php` download paths — ensure `MediaDownloadSettings` values used:
  - Connection timeout
  - Download timeout
  - Max retry count
- When `media_queue` OFF: use inline download with same timeout/retry settings.

**Depends on:** None

**Validation:** PH3-10, PH3-11.

**Exit:** Settings respected on inline path.

---

### Task 3.7 — Media retry with exponential backoff

**Commit:** `[#1442] Add exponential backoff for failed media downloads`

**Work:**
- Enhance `MediaRetryManager` (or `MediaHandling`) with backoff: `min(120, 5 * 2^attempt)`.
- Validate downloaded file: size > 0, MIME check.
- On failure: log URL, add to `FailedImagesUpdate`, continue import (no batch abort).

**Depends on:** Task 3.6

**Validation:** PH3-12, PH3-13.

**Exit:** Single image failure does not stop import.

---

### Task 3.8 — Gallery partial failure recovery

**Commit:** `[#1442] Complete gallery mapping with per-URL failure isolation`

**Work:**
- Parse pipe/comma-separated gallery URLs independently.
- Each URL processed in isolation with retry from Task 3.7.
- Partial gallery attached when some URLs succeed.

**Depends on:** Task 3.7

**Validation:** PH3-14.

**Exit:** Gallery with 3/5 valid URLs imports 3 images.

---

### Task 3.9 — FeatureLoader: gate media queue bootstrap

**Commit:** `[#1442] Load media queue only when media_queue toggle enabled`

**Work:**
- Wrap `MediaBootstrap::init()` in FeatureLoader.
- When OFF: no `uci_pro_after_import_batch` queue hook; no media queue cron; inline `MediaHandling` only.
- Settings UI shows queue options disabled when toggle OFF.

**Depends on:** Phase 2 loader pattern

**Validation:** PH3-20.

**Exit:** Toggle OFF = no MediaQueueManager in included files.

---

### Task 3.10 — Google Sheets connection lifecycle

**Commit:** `[#1442] Improve Google Sheets connection stability and session handling`

**Work:**
- Pre-flight connectivity check before import start (scheduled + manual).
- Session reuse for repeated API calls within one import session.
- Structured error logging with retry reason codes in `GoogleSheetsHttpTransport`.
- Published URL handling in `UrlUpload.php`: validate redirects, handle `export?format=csv` variants.

**Depends on:** Phase 2 Task 2.2 (token refresh)

**Validation:** PH3-15, PH3-16, PH3-17.

**Exit:** Intermittent GSheet uploads succeed on retry.

---

### Task 3.11 — FeatureLoader: gate Google Sheets modules

**Commit:** `[#1442] Load Google Sheets upload only when google_sheets toggle enabled`

**Work:**
- Conditionally require `GsheetUpload.php`; keep `GoogleSheetsHttpTransport` if GDrive still needs it (document shared dependency).
- When OFF: hide GSheet upload tab; `GSheet` controller OAuth AJAX not registered.
- Option: sub-toggle `google_drive` in future; for now document GDrive uses shared transport.

**Depends on:** Task 3.10

**Risks:** GDrive breakage if transport removed — keep transport in core or shared loader group.

**Validation:** PH3-21.

**Exit:** GSheet tab hidden when OFF; GDrive documented.

---

### Task 3.12 — FeatureLoader: gate builder extensions

**Commit:** `[#1442] Load Bricks/Oxygen/WPBakery extensions only when toggled`

**Work:**
- In FeatureLoader, conditional require for:
  - `extensionModules/WPBakeryExtension.php` + import/export pairs
  - `extensionModules/BricksExtension.php` + import/export pairs
  - `extensionModules/OxygenExtension.php` + import/export pairs
- **Critical:** Load before `MappingExtension::getInstance()` OR refresh extension list lazily.
- Recommended: split `MappingExtension` discovery to call `FeatureLoader::get_extension_classes()`.

**Depends on:** Phase 1 Task 1.6

**Risks:** MappingExtension already instantiated — may need deferred discovery hook.

**Validation:** PH3-22, PH3-23.

**Exit:** Builder fields absent from mapping when toggle OFF.

---

### Task 3.13 — FeatureLoader: gate WooCommerce native CSV

**Commit:** `[#1442] Load WooCommerce native CSV bridge only when toggled`

**Work:**
- Wrap `WooCommerceNative\Bootstrap::init()`.
- When OFF: no auto-mapping in `mappingSection.js` for native format (gate via `enabled_features`).

**Depends on:** Phase 1 Task 1.5

**Validation:** PH3-24.

**Exit:** Native CSV detection disabled when OFF.

---

## Phase 3 Risks (Summary)

| Risk | Mitigation |
|------|------------|
| Export batch refactor breaks single-batch exports | Test single-batch and multi-batch paths |
| MappingExtension discovery timing | Deferred discovery task if builder toggle fails PH3-22 |
| GDrive/GSheet transport split | Keep transport in `load_core()` |
| Memory guard too aggressive | Make threshold filterable |

---

## Validation Steps (Phase Exit)

1. Export 5K CPT posts — memory plateau, not linear growth.
2. Meta Box cloneable export row count matches source.
3. Media import with 1 bad URL in 100 — 99 success, 1 in failed queue.
4. GSheet upload 3 consecutive times — all succeed.
5. Each new toggle OFF verified via profiler.
6. All PH3 tests pass.

---

## Test Cases

| ID | Test | Expected |
|----|------|----------|
| PH3-01 | Export 5K posts, 500/batch | Completes; memory stable |
| PH3-02 | Monitor `memory_get_peak_usage` across batches | No linear growth |
| PH3-03 | Export All 10 modules | Zip downloads |
| PH3-04 | Meta Box cloneable 5 groups/post | 5 groups per row in CSV |
| PH3-05 | ACF repeater export 2K posts | Completes |
| PH3-06 | CPT export terminates | Reaches 100% |
| PH3-10 | Set download timeout 10s, slow URL | Times out gracefully |
| PH3-11 | Settings save/load | Values applied |
| PH3-12 | Fail URL retry | Retries per max setting |
| PH3-13 | 1 bad URL in 100 images | Import completes |
| PH3-14 | Gallery 5 URLs, 2 invalid | 3 attachments |
| PH3-15 | Published GSheet URL import | Success |
| PH3-16 | Scheduled GSheet import | Completes |
| PH3-17 | GSheet after 1h idle | Still connects |
| PH3-20 | `media_queue` OFF | No queue cron |
| PH3-21 | `google_sheets` OFF | Tab hidden |
| PH3-22 | `bricks_builder` OFF | No Bricks fields (8.16.x perf toggle; in 8.15.5 baseline) |
| PH3-23 | `wpbakery` OFF | No WPBakery fields (8.16.x perf toggle) |
| PH3-24 | `woo_native_csv` OFF | No native auto-map |

---

## Exit Criteria

- [x] Tasks 3.1–3.13 merged.
- [x] Issues #26846, #26819, #26814 addressed (export batch cleanup, media settings/retry, GSheet transport).
- [x] PH3 smoke tests pass (`tests/phase3/test-phase3.php`).
- [x] Export batch lifecycle documented in code (ExportExtension + ExportBatchContext PHPDoc).
- [ ] Ready for Phase 4 (manual PH3-01–06, 15–17 site tests recommended before benchmark).

---

## Rollback Considerations

| Task | Rollback |
|------|----------|
| 3.1–3.5 | Revert export context; may restore freeze bug |
| 3.6–3.8 | Independent media revert |
| 3.9–3.13 | Set toggles ON; revert Loader commits |
| 3.10 | Independent GSheet revert |

**Partial rollback safe:** Media fixes (3.6–3.8) independent of export fixes (3.1–3.5).
