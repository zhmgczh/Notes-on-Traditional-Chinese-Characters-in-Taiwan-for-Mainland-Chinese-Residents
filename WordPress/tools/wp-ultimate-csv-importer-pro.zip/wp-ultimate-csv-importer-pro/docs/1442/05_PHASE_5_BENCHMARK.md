# 05 — Phase 5: Benchmark & Release

**Duration:** ~1 day  
**Depends on:** Phases 1–4 complete on **implementation branch**; **8.15.5 baseline already captured**  
**Blocks:** Production release tag 8.16.8 / 8.16.9  

---

## Prerequisite: 8.15.5 Baseline

**BL-02 import baseline is complete** (2026-08-03). Results:

| Metric | Value |
|--------|-------|
| Dataset | 1K WC products (`csv_importer_products_benchmark_1000rows.csv`) |
| Wall time | 3840 s (~64 min / 1 hr 4 min) |
| Throughput | 0.260 rec/s |
| Peak memory | 20 MB |
| DB result | 1000 created, 0 failed |

Artifacts:
- `docs/1442/validation/BENCHMARK_BASELINE_8.15.5.md`
- `docs/1442/validation/BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv`

**Still optional / later:** BL-01, BL-03–BL-10 (export after Phase 3 fixes).

Before implementation branch benchmarks:

1. Read `07_BASELINE_8.15.5_INVENTORY.md`
2. Complete Phase 1–4 on **`master`**
3. Re-run **same 1K WC import** with toggles OFF and ON
4. Save comparison to `docs/1442/validation/BENCHMARK_REPORT.md`

## Objective

Execute the complete **benchmark suite** mandated by #1442, produce a **benchmark report**, and obtain **release sign-off** for 8.16.8+ (CVE-2026-13353) or 8.16.9.

Prove:
- **Import faster** than current `master` and than 8.15.5 reference (64 min / 1K products).
- **All toggles ON** — full 8.16 feature set, zero regressions.
- **All toggles OFF** — maximum import speed; optional modules not loaded.
- All eight issue groups closed.

---

## Scope

### In scope

- Benchmark environment setup (documented, reproducible)
- Version comparison: 8.15.5, current branch, 8.16.8/8.16.9 when available
- Toggle matrix benchmarks
- Benchmark report markdown artifact
- Release checklist execution
- Known limitations documentation

### Out of scope

- Plugin code changes (benchmark phase is measurement only unless critical regression found)
- Production deployment

---

## Related Source Files

| File | Role |
|------|------|
| `docs/1442/validation/BENCHMARK_REPORT.md` | **Output artifact** |
| `docs/1442/validation/TOGGLE_PROFILING_RESULTS.md` | Phase 4 input |
| `docs/1442/validation/USER_IE_RESULTS.md` | Phase 4 input |
| `docs/1442/06_TEST_CHECKLIST.md` | Master checklist |
| `wp-ultimate-csv-importer.json` | Version changelog |
| `README.md` | Update version notes post-release |

### Do NOT benchmark (per #1442)

| Version | Reason |
|---------|--------|
| 8.16.0 – 8.16.7 | Feature churn, unreleased fixes — unsuitable reference |

---

## Dependencies

| Dependency | Reason |
|------------|--------|
| Git tag `8.15.5` | Baseline |
| Git tag `8.16.8` or `8.16.9` | Target (or feature branch HEAD if tag pending) |
| Staging server | Isolated benchmark environment |
| Standard datasets | Reproducible throughput |
| Query Monitor + Xdebug | Metrics |
| Action Scheduler or WP-Cron | Scheduler tests |
| Google OAuth | Cloud connector tests |

---

## Implementation Order

---

### Task 5.1 — Benchmark environment specification

**Commit:** `[#1442] Add benchmark environment specification document`

**Work:**
- Create `docs/1442/validation/BENCHMARK_ENV.md`.
- Document:
  - WordPress version
  - PHP version + OPcache settings
  - MySQL/MariaDB version
  - WooCommerce version
  - Active plugins list (minimal set)
  - Server specs (CPU, RAM)
  - Dataset file hashes and row counts
  - WP-Cron vs real cron configuration

**Validation:** Second developer can reproduce environment from doc.

**Exit:** BENCHMARK_ENV.md merged.

---

### Task 5.2 — Prepare standard datasets

**Commit:** `[#1442] Add benchmark dataset manifest`

**Work:**
- Create `docs/1442/validation/DATASETS.md` (manifest only — CSV files stored in test asset repo or staging, not necessarily in plugin repo).
- Datasets:
  - **D1:** 10,000 posts (standard post type)
  - **D2:** 5,000 WooCommerce products with variations
  - **D3:** 1,000 users with custom meta
  - **D4:** 2,000 posts with ACF repeater fields
  - **D5:** 500 posts with Meta Box cloneable groups
  - **D6:** GSheet source (published URL) for cloud test

**Exit:** Dataset manifest with hashes.

---

### Task 5.3 — Import throughput benchmark

**Commit:** `[#1442] Record import throughput benchmark results`

**Work:**
- Run D1 import on:
  - 8.15.5 tag
  - Release branch (all toggles ON)
  - Release branch (all toggles OFF)
- Record: wall time, records/sec, peak memory, CPU time (Xdebug).
- Repeat 3 runs; record median.

**Metrics table template:**

| Version | Toggles | Wall (s) | Rec/s | Peak mem (MB) |
|---------|---------|----------|-------|---------------|
| 8.15.5 | n/a | | | |
| 8.16.x | ALL ON | | | |
| 8.16.x | ALL OFF | | | |

**Exit:** D1 results in report draft.

---

### Task 5.4 — Export throughput benchmark

**Commit:** `[#1442] Record export throughput benchmark results`

**Work:**
- Export D1 post count (10K) batched, 500/batch.
- Same three version/toggle scenarios as Task 5.3.
- Record batch count, wall time, peak memory per batch.

**Exit:** Export section in report draft.

---

### Task 5.5 — Admin page load benchmark

**Commit:** `[#1442] Record admin TTFB benchmark for plugin page`

**Work:**
- Measure TTFB for `admin.php?page=com.smackcoders.csvimporternewpro.menu`.
- Scenarios: 8.15.5, 8.16.x ALL ON, 8.16.x ALL OFF.
- 10 requests each; median TTFB.
- Record `count(get_included_files())` per scenario.

**Exit:** Admin load section in report.

---

### Task 5.6 — AJAX response benchmark

**Commit:** `[#1442] Record AJAX benchmark for core mapping actions`

**Work:**
- Measure response time for:
  - `mappingfields` (standard post type)
  - `saveMappedFields` (small template)
  - `GetProgress` (mid-import)
- Same version/toggle scenarios.

**Exit:** AJAX section in report.

---

### Task 5.7 — Scheduler reliability benchmark

**Commit:** `[#1442] Record scheduler completion rate benchmark`

**Work:**
- Schedule 10 imports (D1 subset 1K rows each).
- Sources: desktop (5), GSheet (3), URL (2).
- Record: completion rate, avg time, Pending stuck count.
- Compare 8.15.5 vs 8.16.x.

**Exit:** Scheduler section; target 100% completion on branch.

---

### Task 5.8 — Cloud connector reliability benchmark

**Commit:** `[#1442] Record cloud connector reliability results`

**Work:**
- GDrive, Dropbox, OneDrive, GSheet: 5 imports each.
- Record success rate, token refresh events, retry count.
- Compare 8.15.5 vs 8.16.x.

**Exit:** Cloud section in report.

---

### Task 5.9 — Toggle matrix benchmark

**Commit:** `[#1442] Record per-feature toggle overhead benchmark`

**Work:**
- Baseline: ALL OFF.
- For each feature ID in registry: enable only that feature, measure admin TTFB + included file count delta.
- Confirm each individual feature adds measurable but isolated overhead.
- Confirm ALL OFF within ±5% of 8.15.5 on D1 import throughput.

**Exit:** Toggle matrix table in report.

---

### Task 5.10 — Error rate benchmark

**Commit:** `[#1442] Record import error rate benchmark`

**Work:**
- Import D2 (5K products) on branch all toggles ON.
- Record: success count, fail count, error rate per 1000 records.
- Compare to 8.15.5 historical log if available.

**Exit:** Error rate ≤ 8.15.5 baseline.

---

### Task 5.11 — Compile benchmark report

**Commit:** `[#1442] Add complete benchmark report for #1442`

**Work:**
- Create `docs/1442/validation/BENCHMARK_REPORT.md` with sections:
  1. Executive summary
  2. Environment (link BENCHMARK_ENV.md)
  3. Datasets (link DATASETS.md)
  4. Import / Export / Admin / AJAX results
  5. Scheduler / Cloud results
  6. Toggle matrix
  7. Error rate
  8. Regression validation summary (link USER_IE_RESULTS, TOGGLE_PROFILING)
  9. Root cause fix summary per issue group
  10. Known limitations (React bundle size, GDrive/shared transport)
  11. Sign-off checklist

**Exit:** Report merged; attached to GitLab #1442.

---

### Task 5.12 — Release sign-off

**Commit:** `[#1442] Update changelog and version for release`

**Work:**
- Update `wp-ultimate-csv-importer.json` changelog entries.
- Update `README.md` version section.
- Confirm CVE-2026-13353 fix in build.
- Tag `8.16.8` or `8.16.9` per release manager.
- Close #1442 with links to benchmark report and MRs.

**Note:** Version bump commit is release task — separate from benchmark doc commits.

**Exit:** Tag pushed; ticket closed.

---

## Phase 5 Risks (Summary)

| Risk | Mitigation |
|------|------------|
| 8.16.8 tag not ready | Benchmark on branch; re-run when tag ships |
| Environment variance | 3 runs median; document hardware |
| Dataset not representative | Use production-anonymized sample if available |
| OPcache cold start | Warm up run discarded |
| GSheet rate limits | Space cloud tests; use published CSV URL |

---

## Validation Steps (Phase Exit)

1. BENCHMARK_REPORT.md complete with all tables filled.
2. ALL OFF import throughput within ±5% of 8.15.5.
3. ALL ON passes full `06_TEST_CHECKLIST.md`.
4. All eight issue groups referenced as closed in report.
5. GitLab #1442 updated with report link.
6. Release tag created (or scheduled).

---

## Test Cases

| ID | Test | Pass criteria |
|----|------|---------------|
| PH5-01 | D1 import 8.15.5 | Baseline recorded |
| PH5-02 | D1 import ALL OFF | Within ±5% of PH5-01 |
| PH5-03 | D1 import ALL ON | Completes; error rate acceptable |
| PH5-04 | D1 export ALL OFF | Within ±5% of 8.15.5 export |
| PH5-05 | Admin TTFB ALL OFF | Within ±5% of 8.15.5 |
| PH5-06 | 10 scheduled imports | 100% completion |
| PH5-07 | Cloud 5×4 connectors | ≥ 95% success |
| PH5-08 | Per-feature toggle delta | Documented per feature |
| PH5-09 | D2 WooCommerce 5K | Error rate ≤ baseline |
| PH5-10 | Report peer review | Second team member approves |

---

## Exit Criteria

- [ ] Tasks 5.1–5.11 complete.
- [ ] BENCHMARK_REPORT.md approved.
- [ ] PH5-02, PH5-04, PH5-05 pass (±5% rule).
- [ ] `06_TEST_CHECKLIST.md` 100% pass on release branch.
- [ ] #1442 acceptance criteria confirmed in report.
- [ ] Release tag 8.16.8+ with CVE fix.

---

## Rollback Considerations

| Scenario | Action |
|----------|--------|
| Benchmark fails ±5% rule | Do not release; return to Phase 4 profiling |
| Critical regression in ALL ON | Hotfix in Phase 2/3 area; re-benchmark |
| Release tag issued with issue | Release previous tag; hotfix branch |

**Benchmark artifacts are documentation only** — rollback of Phase 5 does not affect plugin behavior.

---

## Acceptance Mapping (#1442 → Report Sections)

| #1442 Criterion | Report Section |
|-----------------|----------------|
| Root cause resolution | Section 9 |
| Feature toggle architecture | Section 8 + Toggle matrix |
| Regression validation | Section 8 |
| Benchmark validation | Sections 4–7 |
| Documentation | Full BENCHMARK_REPORT.md |
| Profiler verification | Link TOGGLE_PROFILING_RESULTS.md |

---

## Post-Release

- Monitor support tickets for 2 weeks post-release.
- If overhead reports: collect `sm_uci_pro_feature_toggles` export from affected sites.
- Plan Phase 6 (future): React code-split per feature toggle.
