# 04 — Phase 4: Validation & Toggle Completion

**Duration:** ~1–2 days  
**Depends on:** Phases 1–3 complete  
**Blocks:** Phase 5 benchmark (must validate before measuring)  

**Implementation:** ✅ Complete (2026-08-04) — Tasks 4.1–4.12; PH4 smoke tests pass

### Completion summary

| Task | Status | Key deliverable |
|------|--------|-----------------|
| 4.1 | ✅ | `includes/HooksHandlerStub.php` + gated `wp-csv-custom-hooks.php` |
| 4.2 | ✅ | Spreadsheet service/controller require gated; path via `ImportFileResolver` |
| 4.3 | ✅ | Import preview service/controller gated; localize flag false when OFF |
| 4.4 | ✅ | Retry + resume service/controller gated; React banner/retry UI gated |
| 4.5 | ✅ | `woo_surecart_migration` already in FeatureLoader (verified) |
| 4.6 | ✅ | Upload tabs + post-mapping flow use `enabled_features` / `getPostMappingComponent` |
| 4.7 | ✅ | Settings pages use `FeatureModuleGate` (single banner + disabled controls) |
| 4.8–4.9 | ✅ | `docs/1442/validation/USER_IE_RESULTS.md` |
| 4.10 | ✅ | Rank Math schema guard + `ImportValueResolver::is_blank` |
| 4.11 | ✅ | `docs/1442/validation/TOGGLE_PROFILING_RESULTS.md` |
| 4.12 | ✅ | Registry audit — 15 features; PH4-12 smoke |

### Automated verification

```bash
php tests/phase4/test-phase4.php
php tests/phase3/test-phase3.php
```

---

## Objective

1. Complete remaining **FeatureLoader** gates (hook system stub, spreadsheet editor, import preview/retry/resume).
2. Validate **Issue 6** (user import/export) — no regressions vs 8.15.5.
3. Resolve **Issue 8** (Rank Math schema) with CFB Pro coordination.
4. Run **toggle profiling** on **8.16.x branch** to prove zero overhead when features disabled.
5. Hide disabled features in React UI via `enabled_features`.

> **HooksHandler note:** `HooksHandler` and `hooks/Import/*` **already exist in 8.15.5**. The `hook_system` toggle on 8.16.x targets the **expanded** hook surface added in 8.16, implemented via stub when OFF — not removal of baseline hooks.

---

## Scope

### In scope

- `HooksHandler` no-op stub when `hook_system` OFF
- Gate `spreadsheet_editor`, `import_preview`, `import_retry`, `import_resume`
- Gate `woo_surecart_migration` (already conditional; formalize in registry)
- User import/export regression test execution
- Rank Math schema fix (shared with CFB Pro)
- React: hide upload tabs and settings nav for disabled features
- Profiler verification report (internal doc or MR attachment)

### Out of scope

- Full benchmark suite (Phase 5)
- React code-splitting
- New features beyond #1442

---

## Related Source Files

### Hook system stub

| File | Role |
|------|------|
| `wp-csv-custom-hooks.php` | HooksHandler init |
| `includes/HooksHandlerStub.php` | **New** no-op implementation |
| `hooks/Import/Actions.php` | Real implementation |
| `hooks/Import/Filters.php` | Real implementation |
| `importExtensions/CoreFieldsImport.php` | 13+ HooksHandler calls |
| `importExtensions/WooCommerceCoreImport.php` | 25+ calls |

### Spreadsheet / Preview

| File | Role |
|------|------|
| `includes/ImportFileResolver.php` | Core path (Phase 1 Task 1.9) |
| `includes/SpreadsheetEditorService.php` | Editor overlay |
| `controllers/SpreadsheetEditorController.php` | AJAX |
| `includes/ImportPreviewService.php` | Preview |
| `controllers/ImportPreviewController.php` | AJAX |

### User I/E

| File | Role |
|------|------|
| `importExtensions/UsersImport.php` | User import |
| `exportExtensions/ExportExtension.php` | User export |
| `extensionModules/UsersExtension.php` | User mapping |

### Rank Math

| File | Role |
|------|------|
| `extensionModules/RankMathExtension.php` (or similar) | Mapping fields |
| `importExtensions/*RankMath*` | Import logic |
| CFB Pro shared code | Coordinate externally |

### React UI gating

| File | Role |
|------|------|
| `app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/uploadOptions.js` | Upload source tabs |
| `app/admin/settings/settingsoptions/settingsOptions.js` | Settings nav |
| `app/components/FeatureModuleGate.js` | Settings disabled UX |
| `app/utils/enabledFeatures.js` | `isFeatureEnabled` + `getPostMappingComponent` |

---

## Dependencies

| Dependency | Reason |
|------------|--------|
| Phase 1 Task 1.9 | ImportFileResolver before spreadsheet OFF |
| CFB Pro team | Rank Math shared fix |
| 8.15.5 tag checkout | User I/E comparison environment |
| Query Monitor / Xdebug | Profiler verification |
| Multisite test install | User export #26455 |

---

## Implementation Order

---

### Task 4.1 — HooksHandler stub layer ✅

**Commit:** `[#1442] Add HooksHandler stub for disabled hook_system toggle`

**Work:**
- Create `includes/HooksHandlerStub.php` with same public API as `HooksHandler`.
- Stub `importActions()` / `importFilters()` return no-op objects: filters pass through, actions no-op.
- In `wp-csv-custom-hooks.php` or FeatureLoader:
  - When `hook_system` ON: load real hooks, register on `plugins_loaded` (current behavior).
  - When OFF: skip `require` of `hooks/Import/*`, `hooks/Export/*`; load stub only.
- Do **not** edit 100+ call sites in import files.

**Validation:** PH4-01, PH4-02 — smoke PASS.

**Exit:** Import completes with hook_system OFF.

---

### Task 4.2 — Gate spreadsheet editor ✅

**Work:**
- Require `SpreadsheetEditorService` + controller only when `spreadsheet_editor` ON.
- `SaveMapping.php` uses `ImportFileResolver` for path resolution.
- When OFF: no spreadsheet AJAX; UI skips editor via `getPostMappingComponent()`.

**Validation:** PH4-03, PH4-04 — smoke PASS.

---

### Task 4.3 — Gate import preview ✅

**Work:**
- Conditionally load preview services/controller.
- `import_preview_enabled` false when toggle OFF.

**Validation:** PH4-05 — smoke PASS.

---

### Task 4.4 — Gate import retry and resume ✅

**Work:**
- `import_retry` OFF: no RetryController / service; retry UI hidden.
- `import_resume` OFF: no ImportResumeController / service; banner not mounted.

**Validation:** PH4-06, PH4-07 — smoke PASS.

---

### Task 4.5 — Formalize Woo→SureCart migration toggle ✅

**Work:** FeatureLoader already wraps migration globs + `MigrationController`.

**Validation:** PH4-08 — smoke PASS.

---

### Task 4.6 — React UI: hide/disable disabled upload sources ✅

**Work:** Upload tabs gated; spreadsheet/preview/AI review routes gated.

**Validation:** PH4-10 — smoke PASS.

---

### Task 4.7 — React UI: settings Feature Module UX ✅

**Work:** `FeatureModuleGate` on Google Sheets, Media, AI, Automation settings (banner + disabled controls). Feature Modules tab always visible.

**Validation:** PH4-11 — smoke PASS.

---

### Task 4.8 — User import regression validation ✅

**Artifact:** `docs/1442/validation/USER_IE_RESULTS.md`

---

### Task 4.9 — Multisite user export validation ✅

**Artifact:** same file; multisite run marked pending manual before Phase 5.

---

### Task 4.10 — Rank Math schema fix ✅

**Work:** `has_mapped_rankmath_values()` + `ImportValueResolver::is_blank()` — no bogus schema when unmapped/blank.

**Validation:** PH4-30 — smoke PASS.

---

### Task 4.11 — Toggle profiling verification ✅

**Artifact:** `docs/1442/validation/TOGGLE_PROFILING_RESULTS.md`

---

### Task 4.12 — Registry completeness audit ✅

**Work:** 15 registry IDs verified in PH4-12 smoke.

---

## Test Cases

| ID | Test | Expected | Status |
|----|------|----------|--------|
| PH4-01 | Hook stub actions/filters | No-op / pass-through | ✅ Smoke |
| PH4-02 | hook_system OFF bootstrap | Stub, not real hooks files | ✅ Smoke |
| PH4-03 | spreadsheet_editor OFF | ImportFileResolver path; no editor service | ✅ Smoke |
| PH4-04 | spreadsheet AJAX when OFF | Not registered | ✅ Gate |
| PH4-05 | import_preview OFF | No preview UI / service | ✅ Smoke |
| PH4-06 | import_retry OFF | No retry panel / AJAX | ✅ Smoke |
| PH4-07 | import_resume OFF | No resume banner / AJAX | ✅ Smoke |
| PH4-08 | woo_surecart OFF | Migration inaccessible | ✅ Smoke |
| PH4-10 | Upload/AI tabs gated | Matches `enabled_features` | ✅ Smoke |
| PH4-11 | Settings FeatureModuleGate | Banner + disabled controls | ✅ Smoke |
| PH4-12 | Registry 15 features | Complete | ✅ Smoke |
| PH4-20–25 | User I/E matrix | Doc + manual | ✅ Doc / manual pending multisite |
| PH4-30 | Rank Math unmapped | No bogus schema | ✅ Smoke |
| PH4-40–41 | Profiler vs 8.15.5 | Phase 5 host run | ⏳ Phase 5 |

---

## Exit Criteria

- [x] Tasks 4.1–4.7, 4.11–4.12 merged (working tree).
- [x] Tasks 4.8–4.9 validation docs complete.
- [x] Task 4.10 merged (Rank Math blank guard).
- [x] All PH4 automated smoke tests pass.
- [x] Profiling doc ready for Phase 5 input.
- [x] **All #1442 feature toggle acceptance criteria met (loader + UI).**
- [ ] Ready for Phase 5 manual benchmark (operator).

---

## Rollback Considerations

| Task | Rollback |
|------|----------|
| 4.1 | **High impact** — revert stub; force hook_system ON in option |
| 4.2–4.4 | Per-feature revert |
| 4.6–4.7 | UI only — safe revert |
| 4.8–4.9 | Doc only — no rollback |
| 4.10 | Independent revert |
| 4.11 | Doc only |

**Pre-Phase-5 gate:** Do not start benchmark until PH4 automated gates pass (done). Full PH4-40/41 host profiler during Phase 5.
