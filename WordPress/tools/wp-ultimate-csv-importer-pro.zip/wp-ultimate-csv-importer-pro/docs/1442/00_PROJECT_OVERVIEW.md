# 00 — Project Overview

**Ticket:** [#1442 — Ultimate CSV Importer Pro: Benchmark, Optimize & Fix Repeated Issues](https://gitlab.com/smackcoders/wordpress/wp-ultimate-csv-importer/ultimate-pro/-/work_items/1442)  
**Baseline:** 8.15.5  
**Target:** 8.16.8+ (minimum), 8.16.9 (preferred)  
**Implementation target:** 8.16.8+ (branch work)  
**Baseline verified:** 8.15.5 (`39438adf7`) — see `07_BASELINE_8.15.5_INVENTORY.md`  
**Documentation version:** 1.2  
**Last updated:** 2026-08-03  
**Current branch:** `master` (implementation starts here)  
**Baseline import:** ✅ BL-02 complete — see `validation/BENCHMARK_BASELINE_8.15.5.md` + `validation/BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv`  

---

## Primary goal (team priority)

| Priority | Goal |
|----------|------|
| **#1** | **Import speed optimize** — faster bulk import on `master` (8.16.x) |
| **#2** | **Zero feature break** — every existing feature works when toggles ON |
| **#3** | **Optional toggles OFF** — unused features add no runtime cost during import |
| Reference | 8.15.5 benchmark (64 min / 1000 products) is a **reference only**, not a strict match target — **better than baseline is the win** |

---

## Objective

Deliver a stable, performant 8.16.x release that:

1. **Optimizes import throughput** without breaking any feature (main #1442 goal).
2. Eliminates eight recurring root-cause issue groups through architectural fixes (not symptom patches).
3. Introduces a modular **Feature Toggle** architecture so optional post-8.15 modules can be disabled with zero runtime overhead when OFF.
4. Uses benchmarks to prove import is **faster than today** and **no slower than needed** — 8.15.5 numbers are comparison context, not a hard ±5% gate.

This documentation set guides implementation across five phases. **No plugin code is included here** — only actionable development guidance.

---

## Scope

### In scope

| Area | Description |
|------|-------------|
| Feature Registry & Loader | Conditional bootstrap for post-8.15 modules |
| Issue Group 1 | Header manipulation / mapping save (freeze, 403) |
| Issue Group 2 | Scheduled imports stuck (state machine, OAuth refresh) |
| Issue Group 3 | Export freezing (CPT / ACF / Meta Box batch lifecycle) |
| Issue Group 4 | WooCommerce import consistency (blank = preserve) |
| Issue Group 5 | Media remote upload (timeout, retry, partial failure) |
| Issue Group 6 | User import/export regression validation |
| Issue Group 7 | Google Sheets connection stability |
| Issue Group 8 | Rank Math schema auto-generation (coordinate with CFB Pro) |
| Benchmark suite | 8.15.5 vs 8.16.8/8.16.9 with toggle matrix |
| Settings UI | Feature Modules toggle panel |

### Out of scope

- Rewriting the monolithic React bundle (code-splitting deferred to future work)
- Individual toggles for all 63 third-party extension modules (initial pass groups by feature area)
- Free plugin (`wp-ultimate-csv-importer`) changes unless required for Pro security layer
- WordPress 7.0 compatibility modules (track separately if not yet in codebase)

---

## Documentation Index

| File | Phase | Focus |
|------|-------|-------|
| `00_PROJECT_OVERVIEW.md` | — | This document |
| `01_PHASE_1_FOUNDATION.md` | Phase 1 | FeatureRegistry, FeatureLoader, settings UI, DB prep |
| `02_PHASE_2_CRITICAL_FIXES.md` | Phase 2 | Mapping, scheduler, WooCommerce blank rule |
| `03_PHASE_3_EXPORT_MEDIA.md` | Phase 3 | Export batch lifecycle, media, Google Sheets |
| `04_PHASE_4_VALIDATION.md` | Phase 4 | User I/E, Rank Math, toggle profiling |
| `05_PHASE_5_BENCHMARK.md` | Phase 5 | Full benchmark suite and report |
| `06_TEST_CHECKLIST.md` | All | Master regression and acceptance checklist |
| `07_BASELINE_8.15.5_INVENTORY.md` | — | Verified 8.15.5 inventory (git-audited 2026-08-03) |
| `validation/BENCHMARK_BASELINE_8.15.5.md` | — | Import baseline results (**BL-02 done**) |
| `validation/BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv` | — | Machine-readable BL-02 metrics (8.15.5 vs 8.16.7) |
| `validation/EXPORT_BENCHMARK_PLAN.md` | — | **Export benchmark:** post type, fields, verify steps |

---

## Related Source Files (Global Reference)

> **Important:** 8.15.5 has **no `includes/` directory**. Paths under `includes/` apply to the **8.16 implementation branch** only. See `07_BASELINE_8.15.5_INVENTORY.md`.

### Bootstrap & core (both 8.15.5 and 8.16.x)

| File | Role |
|------|------|
| `wp-ultimate-csv-importer-pro.php` | Main entry, glob loading, `UltimatePro::getInstance()` |
| `wp-csv-custom-hooks.php` | HooksHandler — **present in 8.15.5 baseline** |
| `SaveMapping.php` | Import orchestration, mapping save, AI mapping |
| `extensionModules/MappingExtension.php` | Field discovery via `ExtensionHandler` |
| `importExtensions/CoreFieldsImport.php` | Row dispatch |
| `exportExtensions/ExportExtension.php` | Export orchestration |
| `MediaHandling.php` | Inline media download (baseline) |
| `controllers/Security.php` | Per-handler AJAX nonce (8.15.5) |

### 8.16.x only (implementation branch)

| File | Feature |
|------|---------|
| `includes/importer-dependency-bootstrap.php` | Free plugin dependency manager |
| `includes/ProAjaxAuthorization.php` | Centralized AJAX whitelist |
| `includes/ProFreeAjaxDedup.php` | Free/Pro handler deduplication |
| `includes/VendorAutoload.php` | Lazy Composer autoload |
| `includes/ProAssetLoader.php` | Asset URL resolution |
| `AI/AIBootstrap.php` | AI import filters + governance |
| `databaseMigration/DatabaseMigrationBootstrap.php` | External DB import |
| `automation/AutomationBootstrap.php` | REST API `uci-pro/v1` / webhooks |
| `media/MediaBootstrap.php` | Media download queue |
| `compatibility/WooCommerceNative/Bootstrap.php` | Woo native CSV |
| `includes/ScheduleStateService.php` | Scheduler heartbeat (#1442) |
| `includes/FeatureRegistry.php` | **New** — Phase 1 deliverable |
| `includes/FeatureLoader.php` | **New** — Phase 1 deliverable |

### Settings UI (existing)

| File | Role |
|------|------|
| `app/admin/settings/settingsoptions/settingsOptions.js` | Settings nav layout |
| `app/admin/settings/settingsoptions/aiSettings.js` | AI sub-settings |
| `app/admin/settings/settingsoptions/automationApiSettings.js` | Automation API |
| `app/admin/settings/settingsoptions/mediaDownloadSettings.js` | Media queue settings |
| `app/admin/settings/settingsoptions/GSheet.js` | Google OAuth |

### Prior analysis

| File | Role |
|------|------|
| `docs/IMPLEMENTATION_PLAN_1442.md` | High-level plan from initial ticket analysis |
| Architecture analysis (chat) | Bootstrap flow, feature inventory, coupling assessment |

---

## Dependencies

### External

| Dependency | Required for |
|------------|--------------|
| Free plugin `wp-ultimate-csv-importer` | AJAX auth, core import pipeline |
| WooCommerce | Issue groups 4, 6, Woo native CSV |
| Google OAuth credentials | Issue group 7 |
| Custom Fields Basic Pro | Issue group 8 (Rank Math shared code) |
| Git tags `8.15.5`, `8.16.8` | Benchmark baseline and target |
| Staging WordPress 6.x + PHP 8.1+ | All validation |

### Internal (phase order)

```
Phase 1 (Foundation)
    ↓
Phase 2 (Critical Fixes) ── can start Issue 1 in parallel with Phase 1 Task 3+
    ↓
Phase 3 (Export / Media / GSheet)
    ↓
Phase 4 (Validation / Rank Math / Profiling)
    ↓
Phase 5 (Benchmark / Release)
```

Phase 1 **must complete Task 1 (Registry defaults-all-ON)** before any toggle-gated loading changes ship.

---

## Implementation Order (High Level)

| Order | Phase | Duration (est.) | Deliverable |
|-------|-------|-----------------|-------------|
| 1 | Phase 1 — Foundation | 2 days | Registry, Loader scaffold, settings UI, DB migration for scheduler |
| 2 | Phase 2 — Critical Fixes | 2–3 days | Mapping, scheduler, WooCommerce resolver |
| 3 | Phase 3 — Export / Media | 2 days | Batch context, media retry, GSheet stability |
| 4 | Phase 4 — Validation | 1–2 days | User I/E tests, Rank Math, toggle profiling |
| 5 | Phase 5 — Benchmark | 1 day | Benchmark report, release sign-off |

**Total estimated:** 8–10 working days (milestone Week-32-2026, due 2026-08-07).

---

## Risks

| Risk | Impact | Mitigation |
|------|--------|------------|
| Glob refactor breaks extension discovery | Import/export mapping fails | Keep core glob unchanged in Phase 1; migrate one feature group per commit |
| HooksHandler disable breaks import | Fatal or silent data loss | Ship stub layer before allowing hook_system OFF |
| SpreadsheetEditor path coupling | Import fails when editor toggled OFF | Extract `ImportFileResolver` before gating editor (Phase 1 Task 8 or Phase 2 prerequisite) |
| Benchmark environment differs from production | False confidence | Document exact WP/WC/PHP versions and dataset hashes |
| Rank Math fix blocked on CFB Pro | Issue 8 incomplete | Parallel track; do not block Phases 1–3 release |
| 8.16.8 tag unavailable at benchmark time | Cannot compare target | Benchmark on feature branch; re-run when tag ships |
| Monolithic React bundle | Toggle OFF still loads JS bytes | Document as known limitation; PHP hides UI only |

---

## Validation Steps (Project-Level)

1. Fresh install on 8.16.x branch with all toggles ON — full import/export smoke test.
2. Upgrade from 8.15.5 — all toggles default ON, no behavior change.
3. All toggles OFF — core import/export/schedule still functional.
4. Each issue group reference ticket verified closed.
5. Benchmark report attached with toggle matrix results.
6. Profiler confirms disabled modules absent from call stack / included files.

---

## Test Cases (Project-Level)

See `06_TEST_CHECKLIST.md` for the full matrix. Minimum smoke set:

| ID | Test | Pass criteria |
|----|------|---------------|
| P-01 | Plugin activation (fresh) | No fatal, tables created |
| P-02 | Plugin upgrade 8.15.5 → branch | Migration succeeds, toggles all ON |
| P-03 | Desktop CSV import 100 posts | 100 success, no errors in log |
| P-04 | WooCommerce product import update | SKU, tags, gallery preserved on blank columns |
| P-05 | Scheduled import completion | Job reaches Completed, not Pending |
| P-06 | Export 5K posts batched | All batches complete, no memory runaway |
| P-07 | All feature toggles OFF | Admin loads, import works, profiler shows reduced includes |
| P-08 | Mapping formula save | HTTP 200, formula persisted |
| P-09 | Advanced Mode attribute dropdown | No freeze, responsive UI |
| P-10 | Google Sheet upload | File imported successfully |

---

## Exit Criteria (Project)

- [ ] All eight issue groups resolved with architectural fixes documented in commit messages / MR description.
- [ ] Every post-8.15 feature has independent Enable/Disable toggle in settings.
- [ ] Toggle OFF: no class load, no hook registration, no AJAX/REST registration for that feature (verified by profiler).
- [ ] Toggle ON: feature operates identically to pre-toggle behavior.
- [ ] **Import speed improved** vs current `master` on same 1K WC benchmark CSV (target: clearly faster than 64 min; 8.15.5 is reference only).
- [ ] No regressions on core flows (activation, mapping, SQL escaping, Advanced Mode, formula save, categories).
- [ ] All features work with toggles ON — nothing broken by optimization work.
- [ ] Benchmark report: toggles OFF shows measurable import speed gain; document before/after in `BENCHMARK_REPORT.md`.
- [ ] `06_TEST_CHECKLIST.md` 100% pass on staging.
- [ ] CVE-2026-13353 fix present in release build (8.16.8+).
- [ ] Documentation updated: toggle architecture overview in settings help or `docs/`.

---

## Rollback Considerations

### Baseline benchmark status

| Item | Status |
|------|--------|
| 8.15.5 checkout (`39438adf7`) | ✅ Used for BL-02 import |
| BL-02 — 1K WC product import | ✅ **3840 s / 0.260 rec/s / 20 MB peak** |
| BL-01, BL-03–BL-10 | ⏳ Optional / deferred (export after Phase 3) |
| Implementation on `master` | ⏳ Phase 1 not started |

Toggle/matrix tests run on **`master`** after Phase 1+ code lands.

### Per-commit rollback

Each phase task is designed as an **independent commit**. Rollback = `git revert <commit>` for that task only.

| Phase | Safe to revert individually? | Notes |
|-------|-------------------------------|-------|
| Phase 1 Registry (defaults ON) | Yes | No behavior change until Loader gates loading |
| Phase 1 Loader gates | Partial | Revert Loader commit; Registry can remain |
| Phase 2 fixes | Per issue | Revert mapping fix without reverting scheduler fix |
| Phase 3 | Per module | Export batch context independent of media |
| Phase 4 | Yes | Validation-only commits |
| Phase 5 | N/A | Documentation / benchmark artifacts only |

### Production rollback

1. Re-release previous stable tag (8.15.5 or last known good 8.16.x).
2. Option `sm_uci_pro_feature_toggles` — if new, uninstall hook should not delete (forward-compatible); document manual reset if needed.
3. DB migration for scheduler heartbeat columns — **forward-only**; rollback tag does not drop columns (harmless if unused).

### Feature toggle emergency

If a toggle causes production issue: set all toggles ON via WP-CLI or direct option update:

```
Option key: sm_uci_pro_feature_toggles
Value: all keys => true
```

Document WP-CLI command in Phase 1 settings controller task.

---

## Commit Strategy

- Branch: **`master`** (direct commits; no feature branch per team workflow)
- One logical task = one commit (see per-phase task lists).
- Commit message prefix: `[#1442]`
- No force-push to `main`/`master`.
- MR targets `8.16.x` release branch per team convention.

---

## Team & Coordination

| Role | Responsibility |
|------|----------------|
| Antony S (assignee) | Primary implementation |
| CFB Pro team | Rank Math shared fix (Issue 8) |
| QA | Execute `06_TEST_CHECKLIST.md` on staging |
| Release manager | Tag 8.16.8/8.16.9 after benchmark sign-off |

---

## Next Step

1. Stay on **`master`** — begin **`01_PHASE_1_FOUNDATION.md`** Task 1.1 (FeatureRegistry scaffold).
2. After Phase 1–4: re-run same 1K WC import — **must be faster** than baseline CSV (64 min); no feature regressions.
