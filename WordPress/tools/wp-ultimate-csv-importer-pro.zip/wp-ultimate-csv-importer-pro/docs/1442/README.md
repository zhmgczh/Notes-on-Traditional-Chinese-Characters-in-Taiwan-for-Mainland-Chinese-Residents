# GitLab #1442 — Implementation Documentation

**Ticket:** [Benchmark, Optimize & Fix Repeated Issues](https://gitlab.com/smackcoders/wordpress/wp-ultimate-csv-importer/ultimate-pro/-/work_items/1442)  
**Branch:** `master` only — all #1442 work commits directly to `master` (no feature branch)  
**Baseline:** 8.15.5 (`39438adf7`) · **Target:** 8.16.8+  

---

## Current status (2026-08-04)

| Milestone | Status |
|-----------|--------|
| **Main goal** | Import speed ↑ · features intact |
| Plan documentation | ✅ Ready on `master` |
| 8.15.5 reference benchmark | ✅ 1000 products — **64 min** (1 hr 4 min; not a hard target) |
| **Phase 1 — Foundation** | ✅ Complete (FeatureRegistry, Loader, settings UI, DB columns) |
| **Phase 2 — Critical fixes** | ✅ Complete (scheduler, OAuth, resolver, mapping, FeatureLoader gates, AI module gating) |
| **Phase 3 — Implementation** | ✅ Complete (Tasks 3.1–3.13; PH3 smoke tests pass) |
| **Phase 4 — Validation** | ✅ Complete (Tasks 4.1–4.12; PH4 smoke tests pass; toggle gates verified) |
| **Phase 5 — Benchmark** | ⏳ Next (manual benchmark report) |

---

## Start here

1. **`00_PROJECT_OVERVIEW.md`** — scope, phases, exit criteria  
2. **`IMPLEMENTATION_PLAN_1442.md`** (parent `docs/`) — high-level architecture + issue groups  
3. **`01_PHASE_1_FOUNDATION.md`** — first coding task (FeatureRegistry)  

---

## Phase files

| File | When |
|------|------|
| `01_PHASE_1_FOUNDATION.md` | FeatureRegistry, Loader, settings UI |
| `02_PHASE_2_CRITICAL_FIXES.md` | Mapping, scheduler, WooCommerce |
| `03_PHASE_3_EXPORT_MEDIA.md` | Export batch, media, GSheet |
| `04_PHASE_4_VALIDATION.md` | User I/E, Rank Math, profiling |
| `05_PHASE_5_BENCHMARK.md` | Final benchmark report + release |
| `06_TEST_CHECKLIST.md` | Master regression checklist |
| `07_BASELINE_8.15.5_INVENTORY.md` | Git-verified 8.15.5 file inventory |

---

## Validation artifacts

| File | Content |
|------|---------|
| `validation/BENCHMARK_BASELINE_8.15.5.md` | Human-readable BL-02 results |
| `validation/BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv` | Machine-readable metrics |
| `validation/EXPORT_BENCHMARK_PLAN.md` | Export benchmark (post Phase 3) |
| `validation/BENCHMARK_REPORT.md` | _Create after toggles OFF run_ |

---

## Workflow

```
8.15.5 checkout → BL-02 import baseline ✅
       ↓
master → Phase 1–5 commits on `master`
       ↓
Phase 1 → 2 → 3 → 4
       ↓
Same 1K WC CSV · toggles OFF → **faster than 64 min** · toggles ON → no feature break
       ↓
Phase 5 report → release 8.16.8+
```
