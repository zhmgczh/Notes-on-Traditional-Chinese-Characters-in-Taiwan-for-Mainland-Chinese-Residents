# 07 — 8.15.5 Baseline Inventory (Verified)

**Git commit:** `39438adf7` — *Fixed Prevent default category loss… #26361*  
**Plugin version string:** `8.15.5`  
**Verified on:** 2026-08-03  
**Purpose:** Accurate reference for manual benchmark and doc corrections.  
**Method:** `git ls-tree HEAD` + `wp-ultimate-csv-importer-pro.php` bootstrap trace.

---

## Bootstrap Summary (8.15.5)

```
wp-ultimate-csv-importer-pro.php
├── Constants (WCSVPLUGINDIR, SM_UCI_PRO)
├── Core requires (ErrorHandling, SmackCSVInstall, Tables, languages, parsers…)
├── wp-csv-hooks.php + wp-csv-custom-hooks.php  ← HooksHandler EXISTS
├── glob: extensionUploader/, uploadModules/, extensionModules/,
│         exportExtensions/, managerExtensions/, importExtensions/
├── glob: migrationModules/WooToSureCart/  (unconditional, no SureCart check)
├── glob: ai/*.php + ai/DuplicateDetector/
├── MigrationController::getInstance() if class exists
├── SaveMapping, MediaHandling, schedules, controllers…
└── plugins_loaded → UltimatePro::getInstance()
```

### NOT present in 8.15.5 bootstrap

| Path / call | Notes |
|-------------|-------|
| `includes/importer-dependency-bootstrap.php` | Added in 8.16 |
| `includes/ProAjaxAuthorization.php` | Added in 8.16 — AJAX secured per-handler via `check_ajax_referer` |
| `includes/ProFreeAjaxDedup.php` | 8.16 |
| `includes/VendorAutoload.php` | 8.16 |
| `includes/ProAssetLoader.php` | 8.16 |
| `AI/AIBootstrap::init()` | 8.16 — AI loaded via `ai/*.php` glob only |
| `databaseMigration/` | Entire module — 8.16 |
| `automation/` | 8.16 — replaces/extends `uploadModules/RestApiImport.php` pattern |
| `media/MediaBootstrap.php` | 8.16 — media via `MediaHandling.php` only |
| `compatibility/WooCommerceNative/` | 8.16 |
| `includes/ScheduleStateService.php` | 8.16 |
| `includes/RetryQueueService.php` | 8.16 |
| `includes/ImportResumeService.php` | 8.16 |
| `includes/SpreadsheetEditorService.php` | 8.16 |
| `includes/ImportPreviewService.php` | 8.16 |
| `controllers/RetryController.php` etc. | 8.16 |
| `admin/class-deactivation-feedback.php` | 8.16 |
| `is_woo_to_sure_available()` guard on migration glob | 8.16 — 8.15.5 always globs Woo→SureCart |

### No `includes/` directory

8.15.5 has **zero** files under `includes/`. All `includes/*` paths in phase docs refer to **8.16 implementation branch only**.

---

## Module Counts (8.15.5 HEAD)

| Directory | Files |
|-----------|-------|
| `extensionModules/` | 62 |
| `importExtensions/` | 68 |
| `exportExtensions/` | 19 |
| `uploadModules/` | 17 |

---

## Features Present in 8.15.5 (part of baseline — NOT post-8.15 toggles)

| Feature | Evidence |
|---------|----------|
| **HooksHandler** | `wp-csv-custom-hooks.php`, `hooks/Import/*`, `hooks/Export/*` |
| **WPBakery I/E** | `WPBakeryExtension.php`, `WPBakeryImport.php`, `WPBakeryExport.php` |
| **Bricks Builder I/E** | `BricksExtension.php`, `BricksImport.php`, `BricksExport.php` |
| **AI Natural Language** | `ai/ai_natural_language_imports.php`, `uploadFromAiNaturalLanguage.js` |
| **AI field mapping** | `wp_ajax_wp_ai_field_mapping` in `SaveMapping.php` |
| **AI helpers** | `ai/ai_data_cleanig.php`, `ai_error_detection.php`, `ai_media_seo.php` |
| **Google Sheets HTTP transport** | `uploadModules/GoogleSheetsHttpTransport.php` |
| **Google Sheets upload** | `GsheetUpload.php`, `controllers/GSheet.php`, `uploadFromGsheet.js` |
| **REST API import (legacy)** | `uploadModules/RestApiImport.php`, `uploadFromRestApi.js` |
| **Woo → SureCart migration** | `migrationModules/WooToSureCart/` (unconditional load) |
| **Japanese locale class** | `languages/LangJA.php` (8.16 enhanced UI i18n, class exists in 8.15.5) |
| **Standard upload sources** | Desktop, Server, URL, FTP/SFTP, Dropbox, External |

---

## Features NOT in 8.15.5 (true post-8.15 — toggle candidates)

| Feature | First appears |
|---------|---------------|
| **Oxygen Builder I/E** | 8.16 |
| **External Database Migration** | 8.16 (`databaseMigration/`) |
| **Automation REST API** (`uci-pro/v1`) | 8.16 (`automation/`) |
| **Media download queue** | 8.16 (`media/MediaBootstrap.php`) |
| **WooCommerce Native CSV bridge** | 8.16 (`compatibility/WooCommerceNative/`) |
| **AIBootstrap / AI Governance** | 8.16 (`AI/AIBootstrap.php`, `AI/Governance/`) |
| **Spreadsheet Live Editor** | 8.16 |
| **Import Preview** | 8.16 |
| **Import Retry queue** | 8.16 |
| **Import Resume / recovery** | 8.16 |
| **ScheduleStateService (heartbeat)** | 8.16 (to be added in #1442 Phase 1.8) |
| **ProAjaxAuthorization central whitelist** | 8.16 |
| **Free plugin dependency manager UI** | 8.16 |
| **Deactivation feedback** | 8.16 |
| **Settings: AI / Automation / Media Download tabs** | 8.16 |

---

## Settings UI (8.15.5)

| Tab | File | Present |
|-----|------|---------|
| General | `generalSettings.js` | Yes |
| Database Optimization | `databaseOptimization.js` | Yes |
| Security & Performance | `securityAndPerformance.js` | Yes |
| Documentation | `documentation.js` | Yes |
| Google Sheet | `GSheet.js` | Yes |
| AI Settings | `aiSettings.js` | **No** |
| Automation API | `automationApiSettings.js` | **No** |
| Media Download | `mediaDownloadSettings.js` | **No** |
| Feature Modules | `featureModules.js` | **No** (Phase 1 deliverable) |

---

## Upload UI (8.15.5)

| Source | React component | Present |
|--------|---------------|---------|
| Desktop | `uploadFromDesktop.js` | Yes |
| Server | `uploadFromServer.js` | Yes |
| URL | `uploadFromUrl.js` | Yes |
| FTP/SFTP | `uploadFromFtpSftp.js` | Yes |
| Dropbox | `uploadFromDropbox.js` | Yes |
| Google Sheets | `uploadFromGsheet.js` | Yes |
| External (GDrive etc.) | `uploadFromExternal.js` | Yes |
| AI Natural Language | `uploadFromAiNaturalLanguage.js` | Yes |
| REST API | `uploadFromRestApi.js` | Yes |
| Database Migration | `uploadFromDatabase.js` | **No** |

---

## AJAX Security (8.15.5)

- Nonce action: `smack-ultimate-csv-importer-pro`
- POST key: `securekey`
- Validated per-handler via `check_ajax_referer()` in each class
- **No** centralized `ProAjaxAuthorization` whitelist

---

## UltimatePro Singletons (8.15.5)

Instantiated in `getInstance()` — **does not include:**

- `RetryController`
- `ImportResumeController`
- `SpreadsheetEditorController`
- `ImportPreviewController`

Ends with `AI_Natural_Language_Imports::getInstance()` only.

---

## Stable Areas in 8.15.5 (per #1442)

These are the benchmark reference behaviours:

- Plugin activation
- Mapping engine (`MappingExtension.php`)
- SQL escaping (8.15.1 fix)
- Advanced Mode (8.15.3 attribute dropdown fix)
- Formula save (8.15.4 403 fix)
- Category handling (8.15.5 name ≠ slug fix)

---

## Manual Benchmark: What to Run on 8.15.5 NOW

### Run these (baseline metrics)

| ID | Test | Metric |
|----|------|--------|
| BL-01 | Admin page load | TTFB, `count(get_included_files())` |
| BL-02 | Import 1K WC products (benchmark CSV) | Wall time, rec/s, peak memory | **Done** — see `validation/BENCHMARK_BASELINE_8.15.5.md` |
| BL-03 | Export 10K posts batched | Wall time, peak memory per batch |
| BL-04 | `mappingfields` AJAX | Response time |
| BL-05 | `saveMappedFields` | Response time |
| BL-06 | Scheduled import 1K posts | Completion rate |
| BL-07 | GSheet upload | Success/fail |
| BL-08 | WooCommerce update import (blank tags) | Record baseline behaviour |
| BL-09 | Advanced Mode 10 min | Subjective stability |
| BL-10 | Formula save | HTTP status + persist |

### Skip on 8.15.5 (N/A — feature does not exist)

| Test IDs from 06_TEST_CHECKLIST | Reason |
|--------------------------------|--------|
| PH1-* (Feature toggles) | No FeatureRegistry |
| PH2-20–23 (Loader gates) | No FeatureLoader |
| PH3-20–24 (Media queue, etc.) | No MediaBootstrap |
| PH4-01–11 (Toggle UI) | No toggle UI |
| PH4-05–07 (Preview/Retry/Resume) | No controllers |
| REG-19 (DB Migration) | No module |
| TM-* (Toggle matrix) | Run on 8.16.x only |

### Record results in

`docs/1442/validation/BENCHMARK_BASELINE_8.15.5.md` (create during manual run)

---

## Doc Corrections Applied

Previous docs incorrectly stated:

| Incorrect | Corrected |
|-----------|-----------|
| HooksHandler is 8.16 only | **Exists in 8.15.5** |
| Bricks Builder is 8.16 | **Exists in 8.15.5** |
| `includes/ProAjaxAuthorization.php` in baseline | **8.16 only** |
| 63 extension modules | **62 in 8.15.5** |
| 23 export extensions | **19 in 8.15.5** |
| Current codebase 8.16.7 for benchmark | **Baseline run on 8.15.5 checkout** |

---

## Next Step

1. ~~Run BL-02 import on 8.15.5 checkout~~ ✅ Done — see `docs/1442/validation/BENCHMARK_BASELINE_8.15.5.md`
2. **Work on `master`** — no feature branch; Phase 1+ commits go directly to `master`.
3. **Start Phase 1** — FeatureRegistry + FeatureLoader (non-breaking, all defaults ON).
4. **Parallel:** Deep-dive Issue 1 mapping render loop with React DevTools profiler.
5. After Phase 4: re-run 1K WC import with **all toggles OFF**; target ±5% of baseline (0.260 rec/s).
