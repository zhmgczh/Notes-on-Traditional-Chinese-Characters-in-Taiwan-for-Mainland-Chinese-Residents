# 01 — Phase 1: Foundation

**Status:** ✅ **Complete** (2026-08-04)  
**Duration:** ~2 days  
**Depends on:** None (first implementation phase) — **run on `master` (current 8.16.x codebase), not 8.15.5 checkout**  
**Blocks:** Phase 2 Loader gate tasks, Phase 4 toggle profiling  

> **Baseline note:** 8.15.5 has no `includes/` directory. All new files in this phase live under `includes/` or `controllers/` on the implementation branch. See `07_BASELINE_8.15.5_INVENTORY.md`.

---

## Completion summary (2026-08-04)

| Task | Status | Notes |
|------|--------|-------|
| 1.1 FeatureRegistry | ✅ Done | `includes/FeatureRegistry.php` — 15 features, `sm_uci_pro_feature_toggles` |
| 1.2 Bootstrap require | ✅ Done | Early `require_once` in `wp-ultimate-csv-importer-pro.php` |
| 1.3 FeatureSettingsController AJAX | ✅ Done | `uci_pro_get_feature_toggles` / `uci_pro_save_feature_toggles` |
| 1.4 React Feature Modules UI | ✅ Done | `featureModules.js` + nav in `settingsOptions.js`; pill toggles match AI Import tab |
| 1.5 Localize `enabled_features` | ✅ Done | In `smack_nonce_object_pro` |
| 1.6 FeatureLoader pass-through | ✅ Done | `FeatureLoader::load_all()` — identical glob behavior |
| 1.7 Upgrade migration defaults | ✅ Done | `FeatureRegistry::ensure_defaults()` + `SmackCSVInstall.php` |
| 1.8 Scheduler DB columns | ✅ Done | `last_heartbeat_at`, `retry_count`, `max_retries` in `Tables.php` |
| 1.9 ImportFileResolver | ✅ Done | `includes/ImportFileResolver.php`; delegated from `SpreadsheetEditorService` |

**UI polish (post-1.4):** Version badges (`since 8.15` / `since 8.16`) removed from settings UI; standard `wpucsv-toggle` pill switch aligned with AI Import tab.

**Validation:** PHP syntax OK; scheduler columns verified in DB; React build required (`cd app && npm run build`).

**Next:** → `02_PHASE_2_CRITICAL_FIXES.md` (scheduler state machine, mapping fixes, FeatureLoader gates).

---

## Objective

Establish the **Feature Toggle infrastructure** without changing runtime behavior. After Phase 1:

- `FeatureRegistry` exists and reads/writes `sm_uci_pro_feature_toggles`.
- All features default **ON** (identical to current 8.16.7 behavior).
- Settings UI exposes toggles (no functional gating yet, except read-only display).
- Scheduler DB columns added for Phase 2.
- `ImportFileResolver` extraction planned or completed (prerequisite for Spreadsheet Editor toggle).

---

## Scope

### In scope

- `FeatureRegistry` class and option schema
- `FeatureLoader` scaffold (pass-through: loads everything like today)
- `FeatureSettingsController` AJAX get/save
- React settings tab: Feature Modules
- Pass `enabled_features` to `enqueue_ultimate_pro_assets` localize (display only initially)
- DB migration: scheduler heartbeat columns
- Documentation of feature IDs in registry

### Out of scope

- Actually skipping glob loads (Phase 1 Task 7+ or Phase 2)
- HooksHandler stub
- Any of the eight bug fixes
- Benchmark execution

---

## Related Source Files

| File | Action |
|------|--------|
| `wp-ultimate-csv-importer-pro.php` | Insert Registry require; later wire FeatureLoader |
| `includes/FeatureRegistry.php` | **New** |
| `includes/FeatureLoader.php` | **New** |
| `controllers/FeatureSettingsController.php` | **New** |
| `includes/ProAjaxAuthorization.php` | Add `uci_pro_get_feature_toggles`, `uci_pro_save_feature_toggles` to whitelist |
| `SmackCSVInstall.php` | DB version bump for scheduler columns |
| `includes/ScheduleStateService.php` | Use new columns (read paths only in Phase 1) |
| `app/admin/settings/settingsoptions/settingsOptions.js` | Add Feature Modules nav item |
| `app/admin/settings/settingsoptions/featureModules.js` | **New** React settings panel |
| `includes/SpreadsheetEditorService.php` | Source for path resolver extraction (Task 8) |
| `SaveMapping.php` | Consumer of path resolver (Task 8) |

---

## Dependencies

| Dependency | Reason |
|------------|--------|
| Architecture analysis complete | Feature inventory and insertion points defined |
| Free plugin active on dev site | AJAX auth for settings save |
| `06_TEST_CHECKLIST.md` Phase 1 section | Validation reference |

---

## Implementation Order

Tasks are **independent commits** unless noted.

---

### Task 1.1 — FeatureRegistry scaffold

**Commit:** `[#1442] Add FeatureRegistry with default-all-enabled schema`

**Work:**
- Create `includes/FeatureRegistry.php`.
- Define feature IDs matching architecture inventory (see table below).
- Method: `is_enabled( string $id ): bool` — returns `true` if option missing.
- Method: `get_all(): array` — merged defaults + stored option.
- Method: `get_enabled_ids(): array`.
- Option key: `sm_uci_pro_feature_toggles`.
- No calls from bootstrap yet except optional debug logging behind `WP_DEBUG`.

**Feature IDs (initial registry):**

| ID | Label | Since | In 8.15.5 baseline? |
|----|-------|-------|---------------------|
| `ai_import` | AI Import Features (AIBootstrap + governance) | 8.16 | Partial — `ai/` glob only, no AIBootstrap |
| `wpbakery` | WPBakery Page Builder | 8.15 | **Yes** — optional toggle for perf only |
| `bricks_builder` | Bricks Builder | 8.15 | **Yes** — optional toggle for perf only |
| `oxygen_builder` | Oxygen Builder | 8.16 | No |
| `db_migration` | External Database Migration | 8.16 | No |
| `google_sheets` | Google Sheets Upload | 8.15 | **Yes** — transport + upload exist |
| `automation_api` | REST API & Webhooks (`uci-pro/v1`) | 8.16 | Partial — `RestApiImport.php` exists in 8.15.5 |
| `hook_system` | Extended import/export hooks | 8.16 | Partial — HooksHandler exists in 8.15.5 |
| `media_queue` | Media Download Queue | 8.16 | No — `MediaHandling.php` only in baseline |
| `woo_native_csv` | WooCommerce Native CSV | 8.16 | No |
| `spreadsheet_editor` | Spreadsheet Live Editor | 8.16 | No |
| `import_preview` | Import Preview | 8.16 | No |
| `import_retry` | Failed Record Retry | 8.16 | No |
| `import_resume` | Import Resume / Recovery | 8.16 | No |
| `woo_surecart_migration` | Woo → SureCart Migration | 8.15 | **Yes** — unconditional glob in 8.15.5 |

**Risks:** ID naming churn — document IDs in registry as canonical; UI uses labels only.

**Validation:** Unit-style manual test: `FeatureRegistry::is_enabled('ai_import')` returns true on fresh install.

**Exit:** Registry file exists; no bootstrap wiring.

---

### Task 1.2 — Require FeatureRegistry in bootstrap

**Commit:** `[#1442] Load FeatureRegistry early in plugin bootstrap`

**Work:**
- Add `require_once` after constants (~line 33) in `wp-ultimate-csv-importer-pro.php`.
- No other bootstrap changes.

**Depends on:** Task 1.1

**Validation:** Plugin activates without fatal.

**Exit:** Registry available before dependency manager.

---

### Task 1.3 — FeatureSettingsController AJAX

**Commit:** `[#1442] Add AJAX endpoints for feature toggle settings`

**Work:**
- Create `controllers/FeatureSettingsController.php`.
- Actions: `uci_pro_get_feature_toggles`, `uci_pro_save_feature_toggles`.
- Nonce: `smack-ultimate-csv-importer-pro`.
- Capability: `manage_options`.
- Return registry metadata (id, label, description, enabled) on get.
- Validate saved keys against registry known IDs only.
- Register in `ProAjaxAuthorization::extend_admin_actions()`.
- Instantiate controller from `UltimatePro::getInstance()` or static bootstrap.

**Depends on:** Task 1.1, 1.2

**Validation:** POST get/save via browser devtools or curl; option persists in `wp_options`.

**Exit:** AJAX round-trip works.

---

### Task 1.4 — React Feature Modules settings tab

**Commit:** `[#1442] Add Feature Modules settings UI`

**Work:**
- Create `app/admin/settings/settingsoptions/featureModules.js`.
- Add nav item under **Features** group in `settingsOptions.js`.
- Toggle rows: label, description, switch per feature ID.
- Load on mount via `uci_pro_get_feature_toggles`; save button calls `uci_pro_save_feature_toggles`.
- Show disclaimer: "Disabling features takes effect after page reload" (until Loader gates in Phase 2).

**Depends on:** Task 1.3

**Validation:** All 15 toggles render; save/reload preserves state.

**Exit:** Settings UI complete.

---

### Task 1.5 — Localize enabled features to admin script

**Commit:** `[#1442] Pass enabled feature IDs to admin localize script`

**Work:**
- In `enqueue_ultimate_pro_assets()`, add `enabled_features` => `FeatureRegistry::get_enabled_ids()` to `smack_nonce_object_pro` payload.
- No React consumption required in this task (optional: hide disabled upload tabs in follow-up).

**Depends on:** Task 1.1

**Validation:** View page source / console: `smack_nonce_object_pro.enabled_features` is array.

**Exit:** Frontend can read toggle state.

---

### Task 1.6 — FeatureLoader pass-through scaffold

**Commit:** `[#1442] Add FeatureLoader pass-through matching current glob behavior`

**Work:**
- Create `includes/FeatureLoader.php`.
- Methods: `load_core()`, `load_features()`.
- Phase 1 implementation: `load_core()` + `load_features()` replicate exact current glob + bootstrap init sequence (copy from `wp-ultimate-csv-importer-pro.php` lines 139–206).
- Replace inline glob block with `FeatureLoader::load_all()` single call — **behavior must be identical**.

**Depends on:** Task 1.2

**Risks:** Missed file in glob migration — compare `get_included_files()` count before/after.

**Validation:** Diff included files list before/after on admin page load; run P-03 smoke import.

**Exit:** Bootstrap delegated to FeatureLoader; zero behavior change.

---

### Task 1.7 — Upgrade migration: default all toggles ON

**Commit:** `[#1442] Migration sets feature toggles ON for existing installs`

**Work:**
- In `SmackCSVInstall.php` `$db_updates` or dedicated upgrade hook: if `sm_uci_pro_feature_toggles` not set, write all-true array.
- Bump internal DB version constant.

**Depends on:** Task 1.1

**Validation:** Upgrade from DB without option → all toggles ON in settings UI.

**Exit:** Existing users unaffected.

---

### Task 1.8 — Scheduler DB columns (Phase 2 prep)

**Commit:** `[#1442] Add scheduler heartbeat columns for job state tracking`

**Work:**
- Add columns to `sm_uci_addon_pro_scheduled_import` via `Tables.php` / upgrade script:
  - `last_heartbeat_at` (DATETIME NULL)
  - `retry_count` (INT DEFAULT 0)
  - `max_retries` (INT DEFAULT 3)
- Extend `ScheduleStateService` with column constants; read-only accessors (write logic in Phase 2).

**Depends on:** None (can parallel Task 1.1)

**Validation:** Column exists after upgrade; existing schedules still list in UI.

**Exit:** Schema ready for Phase 2 Task 2.1.

---

### Task 1.9 — ImportFileResolver extraction (prerequisite)

**Commit:** `[#1442] Extract ImportFileResolver from SpreadsheetEditorService`

**Work:**
- Create `includes/ImportFileResolver.php`.
- Move `resolve_import_file_path()` logic from `SpreadsheetEditorService` (delegate from service for BC).
- Update `SaveMapping.php` to call `ImportFileResolver` (can keep service wrapper).
- No toggle gating yet.

**Depends on:** Task 1.6 recommended (cleaner bootstrap)

**Risks:** Import path regression — high test priority.

**Validation:** Import CSV with and without spreadsheet edits; paths resolve correctly.

**Exit:** Spreadsheet editor can become optional in Phase 2+.

---

## Phase 1 Risks (Summary)

| Risk | Mitigation |
|------|------------|
| FeatureLoader glob miss | Automated included-files comparison |
| Settings save 403 | Whitelist actions in Task 1.3 |
| Import path regression (Task 1.9) | Dedicated import smoke before merge |

---

## Validation Steps (Phase Exit)

1. Fresh install: activate plugin, open Feature Modules settings, all toggles ON.
2. Toggle one feature OFF, save, reload — UI reflects change; **import still works** (pass-through loader).
3. `get_included_files()` count equals pre-Phase-1 baseline (±FeatureRegistry files only).
4. Scheduler table has new columns; no PHP notices on schedule list page.
5. Run Phase 1 tests from `06_TEST_CHECKLIST.md` section **PH1**.

---

## Test Cases

| ID | Test | Expected |
|----|------|----------|
| PH1-01 | Activate plugin fresh | Success, no fatal |
| PH1-02 | Open Feature Modules settings | 15 toggles visible, all ON |
| PH1-03 | Disable `ai_import`, save, reload | Toggle OFF in UI; import still works |
| PH1-04 | AJAX save without nonce | 403 |
| PH1-05 | AJAX save as subscriber | Permission denied |
| PH1-06 | Upgrade from 8.15.5 DB dump | Toggles default ON |
| PH1-07 | Import 50 posts post-Task-1.9 | 50 success |
| PH1-08 | `enabled_features` in localize | Present in page source |

---

## Exit Criteria

- [x] Tasks 1.1–1.8 merged (1.9 strongly recommended).
- [x] All PH1 tests pass (manual / syntax / DB schema verified).
- [x] No change in import/export behavior vs pre-Phase-1 branch (FeatureLoader pass-through).
- [x] Feature toggle option documented in registry docblock.
- [x] Ready for Phase 2 Loader gating.

---

## Rollback Considerations

| Task | Rollback impact |
|------|-----------------|
| 1.1–1.2 | Remove registry; harmless if unused |
| 1.3–1.4 | Remove settings UI; option orphaned |
| 1.6 | **Revert to inline glob** — primary rollback if loader breaks |
| 1.8 | Columns remain; old code ignores them |
| 1.9 | **Revert only if import broken** — high priority fix forward |

**Safe rollback point after Phase 1:** All tasks merged with Loader in pass-through mode (Task 1.6) — production-safe, toggles cosmetic only.
