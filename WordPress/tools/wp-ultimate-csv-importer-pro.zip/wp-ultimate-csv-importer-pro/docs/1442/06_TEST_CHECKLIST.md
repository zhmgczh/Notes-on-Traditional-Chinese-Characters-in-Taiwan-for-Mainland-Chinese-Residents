# 06 — Master Test Checklist

**Ticket:** #1442  
**Use:** Execute on staging before each phase merge and before release  
**Versions to test:** **8.15.5 baseline** (BL-02 done on `39438adf7`), then implementation branch (8.16.8+)  

> **Current:** On `master`. BL-02 import baseline recorded. All Phase 1–5 work and commits stay on **`master`**.

**Legend:**
- `[ ]` Not tested
- `[x]` Pass
- `[!]` Fail — link issue/MR
- `[~]` N/A (environment limitation)
- `[S]` Skip — waived with ticket comment

---

## How to Use

1. Run **Smoke** section on every commit to **`master`** (#1442 work).
2. Run **Phase section** when that phase is marked complete.
3. Run **Full Regression** before release tag.
4. Run **Toggle Matrix** after Phase 4.
5. Record results in MR description or `docs/1442/validation/TEST_RUN_<date>.md`.

---

## Test Environment Requirements

| Requirement | Value |
|-------------|-------|
| WordPress | 6.x latest patch |
| PHP | 8.1+ with OPcache enabled |
| WooCommerce | Latest stable |
| Free plugin | `wp-ultimate-csv-importer` active |
| Pro plugin | Branch under test |
| User role | Administrator (`manage_options`) |
| Debug | `WP_DEBUG_LOG` true during test runs |

---

# BASELINE-8.15.5 — Import done; other tests optional

Run on **git checkout 8.15.5** (`39438adf7`). BL-02 completed 2026-08-03.

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| BL-01 | Admin load | Open Pro admin page 10× | Record median TTFB + `count(get_included_files())` | [ ] |
| BL-02 | Import 1K WC | `csv_importer_products_benchmark_1000rows.csv` | 1000 created; record wall time, rec/s, peak memory | [x] **3840s / 0.260 rec/s / 20 MB** |
| BL-03 | Export 10K | Export 500/batch | Completes; memory plateau | [ ] |
| BL-04 | AJAX mapping | `mappingfields` Posts | Record response ms | [ ] |
| BL-05 | AJAX save | `saveMappedFields` small template | Record response ms | [ ] |
| BL-06 | Scheduler | Schedule 1K post import | Status Completed | [ ] |
| BL-07 | GSheet | Upload from Google Sheet | Success | [ ] |
| BL-08 | WC blank tags | Update product; blank tags column | **Record actual behaviour** (baseline reference) | [ ] |
| BL-09 | Advanced Mode | Edit WC attributes 10 min | No freeze | [ ] |
| BL-10 | Formula save | Save custom formula | HTTP 200; persisted | [ ] |

**Save results to:** `docs/1442/validation/BENCHMARK_BASELINE_8.15.5.md`

### Not applicable on 8.15.5 (skip)

| Section | Reason |
|---------|--------|
| PH1 (Feature toggles) | No FeatureRegistry |
| PH2-20–23 (Loader gates) | No FeatureLoader |
| PH3-20–24 | No MediaBootstrap / toggle UI |
| PH4-01–11 | No toggle UI / preview / retry controllers |
| TM (Toggle matrix) | Implementation branch only |
| REG-19 (DB Migration) | Module does not exist |

---

# SMOKE — Run Every Commit

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| SM-01 | Activation | Deactivate + activate Pro | No fatal, no PHP notices | [ ] |
| SM-02 | Admin load | Open Pro admin page | React app loads, no console errors | [ ] |
| SM-03 | Settings | Open General Settings | Page renders | [ ] |
| SM-04 | Desktop upload | Upload 10-row CSV | Headers detected | [ ] |
| SM-05 | Mapping | Load mapping fields (Posts) | Field groups returned | [ ] |
| SM-06 | Import | Import 10 posts | 10 success in log | [ ] |
| SM-07 | Export | Export 10 posts | CSV downloads | [ ] |

---

# PHASE 1 — Foundation (PH1)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH1-01 | Activation | Fresh install activate | Success | [ ] |
| PH1-02 | Feature settings | Open Feature Modules | 15 toggles, all ON | [ ] |
| PH1-03 | Toggle persist | Disable `ai_import`, save, reload | OFF in UI; import still works | [ ] |
| PH1-04 | AJAX security | Save toggles without nonce | 403 | [ ] |
| PH1-05 | AJAX capability | Save as subscriber | Denied | [ ] |
| PH1-06 | Upgrade | Upgrade DB from 8.15.5 dump | Toggles default ON | [ ] |
| PH1-07 | Import path | Import 50 posts post-ImportFileResolver | 50 success | [ ] |
| PH1-08 | Localize | Check `smack_nonce_object_pro.enabled_features` | Array present | [ ] |
| PH1-09 | Scheduler schema | Check DB columns | `last_heartbeat_at`, `retry_count`, `max_retries` exist | [ ] |
| PH1-10 | Included files | Compare count vs pre-Phase-1 | ±Registry files only | [ ] |

---

# PHASE 2 — Critical Fixes (PH2)

## Issue 1 — Mapping

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH2-01 | Advanced Mode | Edit WC attributes 10 minutes | No freeze, dropdown responsive | [ ] |
| PH2-15 | Template switch | Switch mapping template with ATTRMETA | No render loop, UI stable | [ ] |
| PH2-16 | Formula save | Save custom header formula | HTTP 200 | [ ] |
| PH2-17 | Formula persist | Reload template | Formula intact | [ ] |
| PH2-18 | Formula security | Save formula without nonce | 403 | [ ] |

## Issue 2 — Scheduler

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH2-02 | Schedule import | Schedule 1K post import | Status Completed | [ ] |
| PH2-03 | Stale recovery | Kill PHP mid-schedule | Recovered ≤ 10 min | [ ] |
| PH2-04 | GSheet schedule | Schedule GSheet import | Completes; token refreshed | [ ] |
| PH2-05 | Max retry | Force repeated failure | Stops at max_retries | [ ] |
| PH2-06 | Heartbeat | Monitor `last_heartbeat_at` during run | Updates each batch | [ ] |
| PH2-07 | Pending fix | No orphan Pending jobs after 30 min | 0 stuck | [ ] |

## Issue 4 — WooCommerce

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH2-10 | Tags preserve | Update product; blank tags column | Tags unchanged | [ ] |
| PH2-11 | Brand preserve | Update product; blank brand column | Brand unchanged | [ ] |
| PH2-12 | Gallery preserve | Update product; blank gallery column | Gallery unchanged | [ ] |
| PH2-13 | SKU update | Update product; mapped non-blank SKU | SKU updated | [ ] |
| PH2-14 | Variation | Update variation; blank attribute | Attribute preserved | [ ] |
| PH2-19 | Categories | Update product; blank categories | Categories preserved | [ ] |

## FeatureLoader gates (Phase 2)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH2-20 | AI OFF | `ai_import` OFF; import 50 posts | Success; no AI AJAX registered | [ ] |
| PH2-21 | Automation OFF | `automation_api` OFF | REST `uci-pro/v1` 404 | [ ] |
| PH2-22 | DB migration OFF | `db_migration` OFF | No DB migration upload tab | [ ] |
| PH2-23 | All optional OFF | All Phase 2 optional toggles OFF | Core import/export works | [ ] |

---

# PHASE 3 — Export, Media, GSheet (PH3)

## Issue 3 — Export

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH3-01 | Export 5K | Export 5K posts, 500/batch | Completes 100% | [ ] |
| PH3-02 | Memory | Monitor peak memory across batches | Plateau, not linear growth | [ ] |
| PH3-03 | Export All | Export All 10 modules | Zip downloads | [ ] |
| PH3-04 | Meta Box | Export posts with 5 cloneable groups | 5 groups per row in CSV | [ ] |
| PH3-05 | ACF | Export 2K posts with ACF repeater | Completes | [ ] |
| PH3-06 | CPT | Export custom post type 3K | Reaches 100% | [ ] |

## Issue 5 — Media

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH3-10 | Timeout | Set 10s timeout; slow URL | Graceful timeout | [ ] |
| PH3-11 | Settings | Save/load media settings | Applied to download | [ ] |
| PH3-12 | Retry | URL fails once then succeeds | Retried per settings | [ ] |
| PH3-13 | Partial | 1 bad URL in 100 images | 99 success; import completes | [ ] |
| PH3-14 | Gallery | 5 URLs, 2 invalid | 3 attachments set | [ ] |

## Issue 7 — Google Sheets

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH3-15 | Published URL | Import via published GSheet URL | Success | [ ] |
| PH3-16 | Scheduled GSheet | Scheduled GSheet import | Completes | [ ] |
| PH3-17 | Idle session | GSheet import after 1h idle | Still connects | [ ] |

## FeatureLoader gates (Phase 3)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH3-20 | Media queue OFF | `media_queue` OFF | No queue cron event | [ ] |
| PH3-21 | GSheet OFF | `google_sheets` OFF | Tab hidden; no GSheet AJAX | [ ] |
| PH3-22 | Bricks OFF | `bricks_builder` OFF | No Bricks mapping fields | [ ] |
| PH3-23 | WPBakery OFF | `wpbakery` OFF | No WPBakery mapping fields | [ ] |
| PH3-24 | Woo native OFF | `woo_native_csv` OFF | No native CSV auto-map | [ ] |

---

# PHASE 4 — Validation (PH4)

## Hook system & remaining toggles

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH4-01 | Hooks OFF import | `hook_system` OFF; import 100 posts | 100 success | [ ] |
| PH4-02 | Hooks OFF profiler | `hook_system` OFF | No real hook classes in includes | [ ] |
| PH4-03 | Spreadsheet OFF | `spreadsheet_editor` OFF; import CSV | Success | [ ] |
| PH4-04 | Spreadsheet AJAX | Editor AJAX when OFF | Not registered / 403 | [ ] |
| PH4-05 | Preview OFF | `import_preview` OFF | No preview UI | [ ] |
| PH4-06 | Retry OFF | `import_retry` OFF | No retry panel | [ ] |
| PH4-07 | Resume OFF | `import_resume` OFF | No resume prompt | [ ] |
| PH4-08 | SureCart OFF | `woo_surecart_migration` OFF | Migration inaccessible | [ ] |
| PH4-10 | Upload UI | Disable features; check upload tabs | Hidden in DOM | [ ] |
| PH4-11 | Settings UI | Disable features; check settings nav | Hidden items | [ ] |

## Issue 6 — User I/E

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH4-20 | User login | Import user; `wp_login` | Login succeeds | [ ] |
| PH4-21 | Custom fields | Import user with custom meta mapping | Meta persists | [ ] |
| PH4-22 | User role | Import user with role column | Correct role | [ ] |
| PH4-23 | 8.15.5 compare | Same dataset on 8.15.5 vs branch | Identical behavior | [ ] |
| PH4-24 | User export | Export users single site | Correct count | [ ] |
| PH4-25 | Multisite export | Export users on subsite | > 0 users | [ ] |

## Issue 8 — Rank Math

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH4-30 | Unmapped schema | Import post; Rank Math unmapped | No bogus schema generated | [ ] |
| PH4-31 | Mapped schema | Import with mapped Rank Math fields | Schema correct | [ ] |

## Profiling

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH4-40 | Included files | ALL OFF vs 8.15.5 | ≤ +5% file count | [ ] |
| PH4-41 | Peak memory | ALL OFF admin page vs 8.15.5 | ≤ +5% memory | [ ] |

---

# PHASE 5 — Benchmark (PH5)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| PH5-01 | Baseline import | D1 10K posts on 8.15.5 | Recorded | [ ] |
| PH5-02 | ALL OFF import | D1 on branch ALL OFF | Within ±5% of PH5-01 | [ ] |
| PH5-03 | ALL ON import | D1 on branch ALL ON | Completes; acceptable error rate | [ ] |
| PH5-04 | ALL OFF export | D1 export ALL OFF | Within ±5% of 8.15.5 | [ ] |
| PH5-05 | Admin TTFB | Plugin admin page ALL OFF | Within ±5% of 8.15.5 | [ ] |
| PH5-06 | Scheduler | 10 scheduled imports | 100% completion | [ ] |
| PH5-07 | Cloud | 5 imports × 4 connectors | ≥ 95% success | [ ] |
| PH5-08 | Toggle matrix | Per-feature overhead | Documented | [ ] |
| PH5-09 | Woo 5K | D2 products import | Error rate ≤ baseline | [ ] |
| PH5-10 | Report review | Peer review BENCHMARK_REPORT.md | Approved | [ ] |

---

# FULL REGRESSION — Pre-Release

## Core (8.15.5 baseline flows)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| REG-01 | Plugin activation | Fresh + upgrade paths | No fatal | [ ] |
| REG-02 | Mapping engine | Map Posts, Pages, CPT, WC | All field groups load | [ ] |
| REG-03 | SQL escaping | Import data with `'`, `"`, `\`, Unicode | Correct storage | [ ] |
| REG-04 | Advanced Mode | Full WC product mapping flow | No freeze | [ ] |
| REG-05 | Formula save | Custom formula on header | Saved, no 403 | [ ] |
| REG-06 | Categories | Import category name ≠ slug | Default category retained | [ ] |
| REG-07 | Duplicate handling | Update by title/SKU | Correct update mode | [ ] |
| REG-08 | Template save/load | Save + reload mapping template | Identical mapping | [ ] |

## Import sources

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| REG-10 | Desktop | CSV upload | Success | [ ] |
| REG-11 | Server | Server file pick | Success | [ ] |
| REG-12 | URL | Remote CSV URL | Success | [ ] |
| REG-13 | FTP/SFTP | FTP upload | Success | [ ] |
| REG-14 | Google Drive | GDrive file pick | Success | [ ] |
| REG-15 | Dropbox | Dropbox file pick | Success | [ ] |
| REG-16 | OneDrive | OneDrive file pick | Success | [ ] |
| REG-17 | Google Sheets | GSheet picker | Success | [ ] |
| REG-18 | AI NL | Natural language import (if ON) | Success | [ ] |
| REG-19 | DB Migration | DB import (if ON) | Success | [ ] |
| REG-20 | REST API | API trigger (if ON) | Job completes | [ ] |

## Export

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| REG-30 | Post export | Filtered post export | CSV correct | [ ] |
| REG-31 | WC export | Product export | All fields present | [ ] |
| REG-32 | User export | User export | Correct rows | [ ] |
| REG-33 | Export template | Save + reuse export template | Works | [ ] |
| REG-34 | GSheet export | Export to Google Sheet | Data in sheet | [ ] |

## Scheduling

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| REG-40 | Schedule create | Create scheduled import | Saved | [ ] |
| REG-41 | Schedule run | Wait for cron / trigger | Completes | [ ] |
| REG-42 | Schedule export | Scheduled export | File generated | [ ] |
| REG-43 | Schedule email | Email log on completion | Email received | [ ] |

## Third-party extensions (sample)

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| REG-50 | ACF | Import ACF fields | Meta correct | [ ] |
| REG-51 | Yoast SEO | Import SEO fields | Meta correct | [ ] |
| REG-52 | Elementor | Import Elementor data | Renders | [ ] |
| REG-53 | WPML | Import translated post (if WPML active) | Language correct | [ ] |

---

# TOGGLE MATRIX — All Features

Run after Phase 4. For each feature: **only that toggle ON**, all others OFF.

| Feature ID | Toggle ON test | AJAX/hooks present | Core import OK | Result |
|------------|----------------|-------------------|----------------|--------|
| `ai_import` | AI NL upload + mapping | Yes | Yes | [ ] |
| `wpbakery` | WPBakery mapping (if VC active) | N/A | Yes | [ ] |
| `bricks_builder` | Bricks mapping (if Bricks active) | N/A | Yes | [ ] |
| `oxygen_builder` | Oxygen mapping (8.16+ only) | N/A | Yes | [ ] |
| `db_migration` | DB upload tab | Yes | Yes | [ ] |
| `google_sheets` | GSheet upload | Yes | Yes | [ ] |
| `automation_api` | REST trigger | Yes | Yes | [ ] |
| `hook_system` | Import with hooks | Yes | Yes | [ ] |
| `media_queue` | Queue processing | Yes | Yes | [ ] |
| `woo_native_csv` | Native CSV detect | N/A | Yes | [ ] |
| `spreadsheet_editor` | Editor UI | Yes | Yes | [ ] |
| `import_preview` | Preview button | Yes | Yes | [ ] |
| `import_retry` | Retry panel | Yes | Yes | [ ] |
| `import_resume` | Resume prompt | Yes | Yes | [ ] |
| `woo_surecart_migration` | Migration page | Yes | Yes | [ ] |

### All OFF scenario

| ID | Test | Expected | Result |
|----|------|----------|--------|
| TM-00 | ALL toggles OFF | Core import + export + schedule work | [ ] |
| TM-01 | ALL OFF included files | ≤ 8.15.5 + 5% | [ ] |
| TM-02 | ALL OFF import 1K posts | Success | [ ] |
| TM-03 | ALL OFF admin load | No console errors | [ ] |

### All ON scenario

| ID | Test | Expected | Result |
|----|------|----------|--------|
| TM-10 | ALL toggles ON | Full feature set works | [ ] |
| TM-11 | ALL ON vs pre-#1442 branch | No new regressions | [ ] |

---

# SECURITY CHECKS

| ID | Area | Steps | Expected | Result |
|----|------|-------|----------|--------|
| SEC-01 | Nonce required | Core AJAX without nonce | 403 | [ ] |
| SEC-02 | Capability | AJAX as editor role | Denied for admin actions | [ ] |
| SEC-03 | Automation API | REST without API key | 401/403 | [ ] |
| SEC-04 | Path traversal | Import with malicious filename | Sanitized/rejected | [ ] |
| SEC-05 | SQL injection | Import `'; DROP TABLE` in field | Escaped (8.15.1 fix) | [ ] |

---

# ISSUE GROUP SIGN-OFF

| Issue | Refs | Validating tests | Closed | Result |
|-------|------|------------------|--------|--------|
| 1 Mapping | #26432, #26393, #26831 | PH2-01, 15–18 | [ ] | [ ] |
| 2 Scheduler | #26409, #26407, #26831 | PH2-02–07 | [ ] | [ ] |
| 3 Export freeze | #26846, #26819 | PH3-01–06 | [ ] | [ ] |
| 4 WooCommerce | #26853, #26817, #26753 | PH2-10–14, 19 | [ ] | [ ] |
| 5 Media | #26819 | PH3-10–14 | [ ] | [ ] |
| 6 User I/E | #26455 | PH4-20–25 | [ ] | [ ] |
| 7 GSheet | #26814, #26387, #25676 | PH3-15–17 | [ ] | [ ] |
| 8 Rank Math | #26877 | PH4-30–31 | [ ] | [ ] |

---

# RELEASE SIGN-OFF

| Criterion | Verified by | Date | Sign-off |
|-----------|-------------|------|----------|
| All SM tests pass | | | [ ] |
| All REG tests pass | | | [ ] |
| Toggle matrix complete | | | [ ] |
| Benchmark ±5% rule (PH5-02, 04, 05) | | | [ ] |
| BENCHMARK_REPORT.md approved | | | [ ] |
| CVE-2026-13353 present in build | | | [ ] |
| Changelog updated | | | [ ] |
| GitLab #1442 closed | | | [ ] |

---

## Rollback Verification

After any production rollback to previous tag, run minimum:

- [ ] SM-01 through SM-07
- [ ] REG-01, REG-05, REG-06
- [ ] PH2-16 (formula save)

---

## Test Data References

See `docs/1442/validation/DATASETS.md` (created in Phase 5 Task 5.2).

---

## Defect Reporting Template

```
**Test ID:** PHx-xx
**Environment:** WP x.x / PHP x.x / WC x.x
**Branch/Tag:**
**Steps:**
**Expected:**
**Actual:**
**Screenshot/log:**
**MR fix link:**
```
