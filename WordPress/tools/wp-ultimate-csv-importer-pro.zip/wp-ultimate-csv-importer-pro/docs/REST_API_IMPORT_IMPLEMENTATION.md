# REST API Import — Implementation Plan

**Feature:** Authenticated REST API import (JSON/XML) aligned with WP All Import–style integrations.  
**Stack:** WordPress HTTP API (`wp_remote_request`), existing Ultimate CSV Importer Pro pipeline (`smackcsv_file_events`, mapping table, `SaveMapping::bulk_import`, `main_import_process`).

This document splits work into **Backend**, **UI**, and **Testing**. **Section 2** locks **v1 TL/product decisions** (pagination mode, credential handling, concurrency).

---

## 1. Current import architecture (reuse points)

| Layer | Responsibility |
|--------|----------------|
| Upload / ingest | Writes file to `uploads/smack_uci_uploads/imports/{hash}/{hash}`; inserts row into `{prefix}smackcsv_file_events` (`hash_key`, `mode`, `file_name`, `total_rows`). |
| Mapping | `{prefix}ultimate_csv_importer_mappingtemplate` keyed by `eventKey` = `hash_key`; serialized `$map`, filters, target `module`. |
| Chunked run | `SaveMapping::bulk_import()` (`wp_ajax_bulk_import`): paging via `PageNumber` + `sm_bulk_import_iteration_limit`. |
| Row engine | `main_import_process()` — expects **header list + one row of values** matching CSV-style mapping keys. |

**Design rule:** REST import must **normalize** API data into tabular `{ headers, rows }` or **materialize a temp CSV** under the same path convention so chunked import stays unchanged unless strictly necessary.

Reference modules: [`uploadModules/UrlUpload.php`](../uploadModules/UrlUpload.php) (remote fetch + file pipeline), [`SaveMapping.php`](../SaveMapping.php) (`bulk_import`, `background_starts_function`), [`managerExtensions/ScheduleManager.php`](../managerExtensions/ScheduleManager.php).

---

## 2. Shared contracts & v1 TL decisions (locked)

### TL summary (discussion-ready)

| Topic | v1 recommendation |
|--------|-------------------|
| **Pagination execution** | Default **browser session** for small/medium feeds; **background / Cron / Action Scheduler** for large paginated pulls |
| **Credential storage** | **Mandatory** secure handling: encrypted or salted crypto preferred; **minimum** masking + never log/show raw secrets |
| **Same `hash_key` concurrency** | **Disallow** parallel REST/file prep + import on the same session hash — **one active pipeline per hash** |

**Why this fits the plugin:** Existing architecture is already **chunk-based**, **hash/session-based**, and **background-capable** with CSV reuse — minimal regression while scaling for ERP-sized feeds.

---

### 2.1 Pagination strategy

| Mode | When | UX / tech notes |
|------|------|------------------|
| **Browser session** (default v1) | Small/medium feeds | Faster UX, immediate preview → map → chunked `bulk_import`; simpler implementation |
| **Background processing** | Large paginated feeds | Avoids browser timeout, AJAX failures, PHP memory spikes during multi-page fetch + normalize |

**Typical browser-session scale:** roughly **100–5,000 rows** (approximate — tune per hosting).

**Suggested automatic fallback** (implement as configurable constants/filters later):

```text
IF estimated_total_pages > 20 OR estimated_rows > 10000
  THEN run API pagination fetch + CSV materialization in background (Cron / queue)
  ELSE run pagination during admin session (progress UI optional)
```

**Rationale:** Giant feeds (e.g. **100k rows**, **500 API pages**) cannot reliably complete inside interactive PHP/browser cycles; preparation belongs off-request.

Technical placeholders unchanged: `{page}`, `{page_size}`, `{cursor}`, `{offset}`, `{limit}` in URL/body; cursor from JSON path or response headers.

---

### 2.2 Credential encryption & masking (v1 mandatory)

| Surface | Rule |
|---------|------|
| **UI** | Never display raw Bearer/API keys after save — show **`********`** or empty placeholder until user re-enters |
| **Logs / exports** | `Authorization: [REDACTED]`; strip known sensitive headers |
| **Database / options** | Prefer **`openssl_encrypt()`** or **WP salts–derived key** helper — **not** plaintext for tokens |

Full enterprise vault **not** required for v1; **encrypted or strongly obfuscated storage + zero leakage in logs/UI** **is** required for credibility with ERP/Woo merchants.

---

### 2.3 One active process per `hash_key` (mandatory)

**Disallow concurrent REST prep or import sharing the same `hash_key`.**

Same hash ties together **mapping**, **`smackcsv_file_events`**, **`import_detail_log`**, progress — parallel runs risk chunk overlap, duplicate inserts, corrupted progress, schedule conflicts.

**Allowed patterns:**

- User **stops** current import → then rerun; or  
- **New session** → new `hash_key` (recommended for clean logs).

Implement **guard**: reject second start / second prep job if hash already **processing** (mirror or extend existing pause/stop semantics).

---

### 2.4 Other technical contracts

1. **Auth v1:** Bearer token, fixed API-key header(s), arbitrary custom headers, optional full `Authorization` override.  
2. **Capabilities:** Enforce importer admin caps (`manage_options` or plugin-specific cap) on all REST-import AJAX.  
3. **Normalizer output:** Stable column headers (`dot.notation` or documented bracket syntax); repeatable root for array-of-objects APIs (`data.products[]`).  
4. **SSR / abuse:** Optional allowed-host list; timeouts; max response size guard.

---

## 3. Backend implementation

### 3.1 HTTP client service

| Task | Detail |
|------|--------|
| New class | e.g. `ApiImportClient` under `uploadModules/` or `importExtensions/`. |
| Request | Build args: method, headers, body, timeout, `sslverify`, redirects. |
| Filter | `apply_filters('uci_api_request_args', $args, $context)` before request. |
| Execute | `wp_remote_request()`; normalize `WP_Error` and HTTP failures to structured `[ 'success' => false, 'message', 'status' ]`. |
| Retry | Optional: safe retries for **GET** only with backoff & max attempts (setting-driven). |

### 3.2 Response parsing & normalization

| Task | Detail |
|------|--------|
| Detect format | Prefer `Content-Type`; fallback sniff JSON vs XML. |
| Decode | JSON (`json_decode` + large-payload strategy); XML (`SimpleXML`/`DOMDocument`, `libxml_use_internal_errors`). |
| Nested data | Flatten or pick **record root** (configurable path, e.g. `data.products[]`). |
| Filter | `apply_filters('uci_api_response_data', $data, $context)` on decoded payload. |
| Materialize | Write **CSV** (e.g. `League\Csv\Writer`, already used in URL upload) to `{upload_dir}/{hash}/{hash}`; set/update `total_rows` in `smackcsv_file_events`. |
| Hooks | `do_action('uci_before_api_import', $safe_context, $hash_key)` — no raw secrets in context. |

### 3.3 Pagination orchestration

| Task | Detail |
|------|--------|
| Page-based | Substitute `{page}`, `{offset}`, `{limit}` into URL/body template. |
| Cursor-based | Read next token from header map or JSON path; substitute `{cursor}` until empty / repeat flag. |
| Merge | Append rows to single temp CSV **or** run multi-fetch then single file — keep row order deterministic for repeatable imports. |
| **Execution split (v1)** | After estimating pages/rows (probe first page or API meta): **≤ thresholds → browser-driven** pagination + progressive CSV/materialize UX; **> thresholds → background job** full fetch + single CSV then notify admin / auto-start import (see §2.1). |
| Filters | Optional `apply_filters('uci_rest_import_background_thresholds', ['pages' => 20, 'rows' => 10000])` for hosts that need tuning. |

### 3.4 Registration & persistence

| Task | Detail |
|------|--------|
| New source type | “REST API” branch when creating import session — same nonce as existing AJAX (`smack-ultimate-csv-importer-pro`). |
| Persist config | REST profile keyed by `hash_key`: URL, method, headers (**encrypted storage**, redacted/masked on read-for-display), auth type, pagination template, JSON root path. |
| File row | Insert/update `smackcsv_file_events` with synthetic `file_name` (e.g. `rest-import-{hash}.csv`) after normalization succeeds. |
| **Concurrency guard** | Before prep/import start: if `hash_key` already has active processing flag → **reject** with clear message (“stop existing import or use new session”). See §2.3. |

### 3.5 Engine integration

| Task | Detail |
|------|--------|
| Reuse importer | Call existing save-mapping flow → `bulk_import()` as today. |
| Preparation job | Heavy fetch/normalize moves to WP-Cron **or** Action Scheduler if present; AJAX returns progress. |
| Hook parity | Align `HooksHandler::importActions()` **before/after** import with chunked API runs (mirror first-page `fire_before_import` + completion `fire_after_import`). |
| Completion | `do_action('uci_after_api_import', $hash_key)` when `import_detail_log` marks Completed. |

### 3.6 Scheduling & automation

| Task | Detail |
|------|--------|
| Extend scheduler | Mirror `ScheduleManager` + external URL schedules (`sm_uci_addon_pro_external_file_schedules`): add REST profile ID / serialized config pointer. |
| Cron flow | Fetch → normalize → optionally auto-start mapped import using stored template. |

### 3.7 Logging & errors

| Task | Detail |
|------|--------|
| API log | HTTP status, duration, row count parsed, truncation of body (secrets stripped). |
| Import log | Reuse `LogManager` / `import_detail_log`; distinguish “prep failed” vs “row failed”. |
| Retry UX | Persist last failure reason on schedule row for admin display. |

---

## 4. UI implementation

### 4.1 Wizard / source selection

| Task | Detail |
|------|--------|
| Entry | Add “Import from REST API” next to Desktop / URL / FTP. |
| Guard | Same capability checks as existing importer screens. |

### 4.2 Connection configuration screen

| Task | Detail |
|------|--------|
| Fields | Endpoint URL; method selector (GET/POST); optional raw body textarea (POST); header table (key/value pairs, masked values on edit); auth subsection (Bearer, API Key name+value, custom Authorization). |
| Validation | Client-side basics; server-side authoritative validation on save/test. |

### 4.3 Pagination UI

| Task | Detail |
|------|--------|
| Mode | Toggle: none / page / cursor. |
| Inputs | Parameter names or body JSON template placeholders; cursor JSON path helper text. |

### 4.4 Test & preview

| Task | Detail |
|------|--------|
| Test API | AJAX runs **single request** via backend `ApiImportClient`; show status, timing, downloadable nothing — **preview panel only**. |
| Preview table | First *N* rows (and derived column headers) for mapper discovery. |
| Errors | Readable messages for 401/403/404/429/5xx and JSON parse failures. |

### 4.5 Mapping continuity

| Task | Detail |
|------|--------|
| Headers feed | Columns from normalization must populate the same mapping UI as CSV uploads. |

### 4.6 Schedule UI (if in scope)

| Task | Detail |
|------|--------|
| Reuse patterns | Extend existing schedule screens: pick REST profile, frequency, timezone, notifications. |

---

## 5. Testing plan

### 5.1 Backend unit / integration checks

| # | Scenario | Expected |
|---|----------|----------|
| B1 | GET with Bearer | 200, body decoded, rows written, `total_rows` correct |
| B2 | POST with JSON body | Same as B1 |
| B3 | Invalid JSON | Controlled error, no partial file corrupting next run |
| B4 | Malformed XML | `libxml` errors captured, user-facing message |
| B5 | Flatten nested object | Stable header names, no collisions (document merge rule) |
| B6 | Array root `items[]` | One row per element |
| B7 | Page pagination `{page}` | Multiple requests concatenate correctly |
| B8 | Cursor pagination | Stops when cursor empty |
| B9 | 401 response | Prep fails clearly; importer not started |
| B10 | `uci_api_request_args` filter | Test plugin can mutate headers/query |
| B11 | `uci_api_response_data` filter | Test plugin can remap payload |

### 5.2 Security & privacy

| # | Scenario | Expected |
|---|----------|----------|
| S1 | Log output | No Authorization / API keys in plaintext (`[REDACTED]`) |
| S2 | DB inspection | Tokens not plaintext when encryption enabled |
| S3 | User without cap | AJAX rejected |
| S4 | Nonce failure | Standard WP failure |
| S5 | `wp_remote_request` SSRF optional allowlist | Reject disallowed hosts if feature enabled |

### 5.3 Concurrency & pagination modes

| # | Scenario | Expected |
|---|----------|----------|
| C1 | Second prep/start while same `hash_key` busy | Rejected with user-visible reason |
| C2 | Feed ~21 pages or ~10k+ rows | Background path engaged (or explicit UI choice); no browser hang |
| C3 | Small feed under thresholds | Completes in browser session without unnecessary Cron |

### 5.4 UI tests (manual / E2E as available)

| # | Scenario | Expected |
|---|----------|----------|
| U1 | Save REST profile → refresh | Headers masked or empty value for secrets |
| U2 | Test connection success | Preview shows columns |
| U3 | Test connection failure | Inline error + no crash |
| U4 | Map fields → chunked import | Progress bar behaves like CSV |
| U5 | Pause / resume REST-backed import | Same as file import pause semantics |

### 5.5 Engine regression (critical paths)

| # | Scenario | Expected |
|---|----------|----------|
| E1 | Simple post import | CPT create/update works |
| E2 | WooCommerce simple product | SKU, price, stock |
| E3 | Product with images | Existing media logic unchanged |
| E4 | Update mode duplicate key | Same behavior as CSV update |
| E5 | XML-style mapping not used | Confirmed CSV path only for Phase 1 JSON→CSV |

### 5.6 Performance & resilience

| # | Scenario | Expected |
|---|----------|----------|
| P1 | Large JSON response | Streaming/temp-file path does not exhaust memory (`memory_limit` documented) |
| P2 | Slow API | Timeouts surfaced; schedules can retry |

---

## 6. Deliverable milestones (suggested order)

1. **M1 Backend (done — May 2026):** `ApiImportClient` + `ApiImportNormalizer` + `RestApiImport` AJAX (`uci_rest_api_m1_test`, `uci_rest_api_m1_prepare`). Verification notes: [`docs/M1_VERIFICATION.md`](M1_VERIFICATION.md).  
2. **M2 UI (source complete — May 2026):** Upload dashboard tab **Import from REST API** → [`uploadFromRestApi.js`](app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/uploadFromRestApi.js). Checklist: [`docs/M2_VERIFICATION.md`](M2_VERIFICATION.md). **Webpack build** still required to refresh `assets/js/` bundles before production QA.  
3. **M3 Integration (done):** Interactive mapping → `bulk_file_import`; **`uci_after_api_import`** on Completed via `sm_uci_pro_after_import` + **`rest-import-*`** filename guard. Notes: [`docs/M3_VERIFICATION.md`](M3_VERIFICATION.md).  
4. **M4 — Pagination v1 (done):** **`{page}` / `{limit}` / `{offset}`** merge on **`uci_rest_api_m1_prepare`**. [`docs/M4_PAGINATION.md`](M4_PAGINATION.md). **Not in this slice:** cursor tokens, background/Cron merge thresholds, **scheduled REST** → still **open** (toward `ScheduleManager` / M6). See [`docs/M5_TESTING.md`](M5_TESTING.md) scope table.  
5. **M5 — Hardening & testing (in progress):** Automated smoke: [`tests/test-rest-api-import-m5.php`](tests/test-rest-api-import-m5.php) + [`docs/M5_TESTING.md`](M5_TESTING.md). Remaining: credential encryption, SSRF option, log redaction, full §5 regression in staging.

---

## 7. Developer hooks (target signatures)

Implement and document exactly:

```php
apply_filters( 'uci_api_request_args', array $args, array $context );
apply_filters( 'uci_api_response_data', mixed $data, array $context );
apply_filters( 'uci_rest_import_max_fetch_pages', int $max_pages, array $context );
apply_filters( 'uci_rest_import_max_total_records', int $row_cap, array $context );
apply_filters( 'uci_rest_import_page_size_hard_ceiling', int $ceiling, array $context );
apply_filters( 'uci_rest_api_preview_row_limit', int $preview_rows, array $context );
apply_filters( 'uci_rest_import_persist_form_prefs', array $snapshot );
do_action( 'uci_before_api_import', array $context, string $hash_key );
do_action( 'uci_after_api_import', string $hash_key );
```

`$context` should include identifiable but non-sensitive keys: import hash, schedule id (if any), endpoint host, method — **never** raw tokens.

**REST form persistence:** After a successful **Continue** (`uci_rest_api_m1_prepare`), the importer saves URL/method/records path/page size/auth/header fields to the option **`sm_uci_pro_rest_api_import_form_v1`** (serialized array). The REST tab loads them via AJAX **`uci_rest_api_load_form_prefs`** on mount (tokens live in `wp_options` — restrict DB/backups accordingly).

---

## 8. Resolved decisions log

The former open questions are **resolved** in **§2** (pagination dual-mode + thresholds, credential encryption/masking mandatory, disallow concurrent operations per `hash_key`). Future scope changes should update §2 and append dated notes here.

---

*Document generated for WP Ultimate CSV Importer Pro REST API Import initiative. Maintain this file alongside feature branches and update milestones as scope changes.*
