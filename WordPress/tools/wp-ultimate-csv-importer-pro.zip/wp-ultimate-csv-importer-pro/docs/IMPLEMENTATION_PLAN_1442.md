# Implementation Plan — GitLab #1442

**Ticket:** [Ultimate CSV Importer Pro: Benchmark, Optimize & Fix Repeated Issues](https://gitlab.com/smackcoders/wordpress/wp-ultimate-csv-importer/ultimate-pro/-/work_items/1442)  
**Assignee:** Antony S  
**Milestone:** Week-32-2026 (due 2026-08-07)  
**Current codebase version:** 8.16.7  
**Benchmark baseline:** 8.15.5  
**Production target:** 8.16.8+ (CVE-2026-13353), preferred 8.16.9  

---

## 1. Executive Summary

**Main goal:** Optimize **import speed** on 8.16.x without breaking any feature.  
**8.15.5:** Reference benchmark only (1000 products = 64 min / 1 hr 4 min) — beating it is good; strict parity is not required.

Version **8.15.5** is the last known stable release before the 8.16 feature expansion. The 8.16 cycle introduced significant new capabilities but also measurable performance overhead from eager-loading optional features on every request.

This plan covers:

1. **Import performance optimization** — lazy load, toggle gates, reduce per-request and per-batch overhead.
2. **Root-cause fixes** for 8 recurring issue groups (mapping, scheduler, export, WooCommerce, media, users, Google Sheets, Rank Math).
3. **Feature toggle architecture** — optional features OFF = zero runtime cost; all ON = full behavior preserved.
4. **Benchmark validation** — same 1K WC CSV before/after; prove faster import + zero feature break.

---

## 2. Version Strategy

| Role | Version | Notes |
|------|---------|-------|
| Benchmark baseline | **8.15.5** | Last stable: activation, mapping, SQL escaping, Advanced Mode, formula save, category handling |
| Do NOT benchmark | 8.16.0 – 8.16.7 | Feature churn + ~15 unreleased fixes; unsuitable reference |
| Minimum production | **8.16.8** | Required for CVE-2026-13353 |
| Preferred production | **8.16.9** | After remaining July fixes ship |

### 8.15 Release Line (Deep Analysis)

| Version | Focus |
|---------|-------|
| **8.15** | AI token estimation, WooCommerce AI mapping rules, WPBakery I/E, media manifest, DB schema migration, Google Sheets HTTP transport |
| **8.15.1** | SQL escaping / `wpdb->prepare` for special characters (#26505) |
| **8.15.2** | Kadence theme UI conflict fix (#26505) |
| **8.15.3** | Advanced Mode attribute dropdown re-render loop (#26432) |
| **8.15.4** | Formula save HTTP 403 (#26393) |
| **8.15.5** | Default category loss when name ≠ slug (#26361) — **benchmark baseline** |

### 8.16 New Features (Post-8.15 — Require Toggles)

| Feature | Introduced | Key Files |
|---------|------------|-----------|
| Bricks Builder I/E | 8.16 | `importExtensions/BricksImport.php`, `exportExtensions/BricksExport.php`, `extensionModules/BricksExtension.php` |
| Oxygen Builder I/E | 8.16 | `importExtensions/OxygenImport.php`, `exportExtensions/OxygenExport.php`, `extensionModules/OxygenExtension.php` |
| Centralized Hook System | 8.16 | `wp-csv-custom-hooks.php`, `hooks/Import/*`, `hooks/Export/*`, `HooksHandler` singleton |
| REST API Import | 8.16 | `automation/`, `docs/REST_API_IMPORT_IMPLEMENTATION.md` |
| Module-based template grouping | 8.16 | `SaveMapping.php`, template pagination |
| Free plugin dependency notice | 8.16 / 8.15 | `includes/class-importer-dependency-manager.php` |
| Japanese localization | 8.16 | `languages/LangJA.php`, `includes/I18nBootstrap.php` |
| WPML product title+language matching | 8.16.4 | WooCommerce import extensions |

### 8.15 Features (Also Post-Baseline — Require Toggles if Loaded Eagerly)

| Feature | Key Bootstrap | Current Load Pattern |
|---------|---------------|---------------------|
| AI Natural Language Import | `ai/ai_natural_language_imports.php`, `AI/AIBootstrap.php` | **Eager** — glob + `AIBootstrap::init()` in main file |
| AI Governance / Field Mapping | `AI/Governance/AIGovernanceBootstrap.php` | **Eager** — via `AIBootstrap::init()` |
| WPBakery I/E | `extensionModules/WPBakeryExtension.php`, glob-loaded | **Eager** — glob all extension/import modules |
| Database Migration | `databaseMigration/DatabaseMigrationBootstrap.php` | **Eager** — `::init()` in main file |
| Google Sheets HTTP Transport | `uploadModules/GoogleSheetsHttpTransport.php` | **Eager** — glob upload modules |
| Automation / REST API | `automation/AutomationBootstrap.php` | **Eager** — `::init()` in main file |
| Media Queue Pipeline | `media/MediaBootstrap.php` | **Eager** — `::init()` in main file |
| WooCommerce Native CSV | `compatibility/WooCommerceNative/Bootstrap.php` | **Eager** — `::init()` in main file |
| Woo → SureCart Migration | `migrationModules/WooToSureCart/` | **Conditional** — only if SureCart available |

---

## 3. Plugin Architecture & Workflow Analysis

### 3.1 Bootstrap Flow

```
wp-ultimate-csv-importer-pro.php
  ├── Dependency bootstrap (free plugin requirement)
  ├── ProAjaxAuthorization::bootstrap()
  ├── Core requires (Tables, SaveMapping, parsers, etc.)
  ├── glob() load ALL:
  │     extensionUploader/, uploadModules/, extensionModules/,
  │     exportExtensions/, managerExtensions/, importExtensions/, ai/
  ├── Bootstrap::init() for:
  │     AI, DatabaseMigration, Automation, Media, WooCommerceNative
  ├── plugins_loaded → UltimatePro::getInstance()
  │     └── Instantiates ~30+ singletons (upload, mapping, export, schedule, etc.)
  └── admin_enqueue_scripts → React app (react-app.js)
```

**Problem:** ~150+ PHP files loaded via glob on every request regardless of feature usage. Hooks registered in constructors of all singletons.

### 3.2 Import Workflow

```
┌─────────────┐    ┌──────────────┐    ┌─────────────────┐    ┌──────────────┐
│ Upload      │───▶│ csvInfo      │───▶│ mappingfields   │───▶│ saveMapped   │
│ (Desktop/   │    │ (headers)    │    │ (field groups)  │    │ Fields       │
│  URL/GSheet │    └──────────────┘    └─────────────────┘    └──────┬───────┘
│  /AI/etc.)  │                                                       │
└─────────────┘                                                       ▼
                                                              ┌──────────────┐
                                                              │ importConfig │
                                                              │ (dup/update) │
                                                              └──────┬───────┘
                                                                     ▼
┌─────────────┐    ┌──────────────┐    ┌─────────────────┐    ┌──────────────┐
│ Complete    │◀───│ GetProgress  │◀───│ CoreFieldsImport│◀───│ StartImport  │
│ (log/stats) │    │ (polling)    │    │ + *Import ext.  │    │ (batch loop) │
└─────────────┘    └──────────────┘    └─────────────────┘    └──────────────┘
```

| Step | Frontend (React) | Backend (PHP) | AJAX Action |
|------|------------------|---------------|-------------|
| Upload | `uploadFrom*.js` | `uploadModules/*Upload.php` | `get_desktop`, `get_url`, etc. |
| Headers | `csvInfo.js` | `MappingExtension.php` | `mappingfields` |
| Mapping | `mappingSection.js` | `SaveMapping.php` | `saveMappedFields` |
| AI mapping | `mappingSection.js` | `SaveMapping.php` | `wp_ai_field_mapping` |
| Config | `importConfiguration.js` | `ImportConfiguration.php` | import config actions |
| Execute | `progressDisplay.js` | `SaveMapping::background_starts_function()` | `StartImport`, `GetProgress` |
| Row dispatch | — | `CoreFieldsImport::set_core_values()` | — |
| Schedule | — | `ScheduleImport.php` → cron | `smack_uci_cron_scheduler` |

### 3.3 Export Workflow

```
exportFilter.js → getfields / get_export_fields → parse_data / parse_data_export_all
                                                        │
                                                        ▼
                                              ExportExtension::parseData()
                                                        │
                                                        ▼
                                              ExportExtension::exportData()
                                              + plugin-specific exporters
                                                        │
                                                        ▼
                                              CSV/XLSX in smack_uci_uploads/exports/
```

Scheduled export: `ScheduleExport.php` on `smack_uci_cron_scheduled_export`.

### 3.4 Extension / Module System

```
ExtensionHandler (base)
  ├── extensionModules/*.php   → mapping UI field definitions (63 modules)
  ├── importExtensions/*.php   → row-level import logic (68 modules)
  └── exportExtensions/*.php   → export data extraction (23 modules)

Discovery: MappingExtension scans declared ExtensionHandler subclasses
Dispatch:  CoreFieldsImport routes by import type + mapped field groups
```

### 3.5 AJAX Security

- Central: `includes/ProAjaxAuthorization.php` — whitelist + nonce (`smack-ultimate-csv-importer-pro`)
- Dedup: `includes/ProFreeAjaxDedup.php` — removes duplicate free handlers
- Each module self-registers `wp_ajax_*` in constructor/`doHooks()`

### 3.6 Settings UI (Existing)

`app/admin/settings/settingsoptions/settingsOptions.js` groups:

- **General** — drop table, scheduled mails, passwords, Woo custom attributes
- **Performance** — security/performance, database optimization
- **Connectors** — Google Sheet OAuth
- **Features** — AI settings, Automation API, Media download settings

**Gap:** No unified "Feature Modules" toggle panel for post-8.15 features.

---

## 4. Root Cause Analysis by Issue Group

### Issue 1 — Header Manipulation / Mapping Save (Highest Priority)

**Refs:** #26432, #26393, #26831

| Symptom | Root Cause (Code) |
|---------|-------------------|
| Advanced Mode freeze | `mappingSection.js` `componentDidUpdate` triggers `syncWooCommerceFromAttrMeta()` → `autoMapProductAttributes()` on ATTRMETA/context changes, causing render loops |
| Attribute dropdown unresponsive | WooCommerce attribute state synced bidirectionally with ATTRMETA without stable memoization guards |
| Formula save 403 | `ProAjaxAuthorization` whitelist or nonce mismatch for formula/header manipulation save actions |

**8.15.3 partial fix:** Re-render loop patch in attribute dropdown — symptom-level, not architectural.

**Files to change:**

- `app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/mappingSection.js` — state management refactor
- `app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/dragAndDropSection.js` — formula save flow
- `includes/ProAjaxAuthorization.php` — verify formula save actions whitelisted
- `SaveMapping.php` — mapping save permission validation

**Fix approach:**

1. Introduce unidirectional data flow: ATTRMETA is source of truth; WooCommerce UI reads via memoized selector, writes via explicit save action only.
2. Add `shouldSyncAttrMeta()` guard — skip sync when change originated from sync itself.
3. Debounce `autoMapProductAttributes()` — run once per csvFields load, not on every `componentDidUpdate`.
4. Audit all formula-related AJAX actions against `extend_admin_actions()` whitelist; add missing actions.
5. Add integration test: save custom formula → verify 200 response + persisted mapping.

---

### Issue 2 — Scheduled Imports Stuck (High Priority)

**Refs:** #26409, #26407, #26831

| Symptom | Root Cause |
|---------|------------|
| Jobs stay Pending | No reliable state machine; `isrun` lock without heartbeat/timeout |
| Imports stop midway | OAuth token expiry during long cloud downloads |
| Retry loops | `GoogleSheetsHttpTransport` retries without backoff cap; stale jobs not recovered |

**Existing infrastructure:**

- `includes/ScheduleStateService.php` — atomic locks, status constants (added in 8.16.x)
- `uploadModules/GoogleSheetsHttpTransport.php` — 3 retries, 2s sleep (8.15)
- `scheduleExtensions/ScheduleExtension.php`, `ScheduleImport.php`

**Fix approach:**

1. Extend `ScheduleStateService` with:
   - `heartbeat($schedule_id)` — update `last_heartbeat_at` column
   - `detect_stale_jobs($timeout_seconds)` — reset `isrun=0`, set status `waiting for retry`
   - `transition($id, $from_status, $to_status)` — atomic status transitions
2. Add cron hook `smack_uci_schedule_heartbeat` (every 5 min) for stale detection.
3. OAuth token refresh:
   - `controllers/GSheet.php`, `uploadModules/GoogleDriveUpload.php`, Dropbox/OneDrive modules
   - Refresh token before each batch if `expires_at - now < 300s`
4. Replace infinite retry with exponential backoff + max attempts (configurable in settings).
5. Log state transitions to `import_detail_log` for debugging.

**DB migration:** Add `last_heartbeat_at`, `retry_count`, `max_retries` columns to `sm_uci_addon_pro_scheduled_import`.

---

### Issue 3 — Export Freezing (CPT / ACF / Meta Box) (High Priority)

**Refs:** #26846, #26819

| Symptom | Root Cause |
|---------|------------|
| Freezes after first batch | Export routines retain iterators, caches, temp objects between batches |
| Meta Box cloneable groups truncated | Batch context not reset; partial group state carried over |
| Memory grows | No cleanup after `parse_data` batch completion |

**Files to change:**

- `exportExtensions/ExportExtension.php` — `parseData()`, `exportData()`, `FetchDataByPostTypes()`
- `exportExtensions/ExportAll.php` — multi-module zip export
- Meta Box / ACF specific: `exportExtensions/MetaBoxExport.php`, ACF exporters
- `importExtensions/MetaBoxGroupImport.php` — cloneable group handling (import side may share patterns)

**Fix approach:**

1. Introduce `ExportBatchContext` class — holds per-batch state; destroyed after each batch.
2. After every batch write:
   - `unset()` large arrays
   - Reset WP_Query / `$wpdb` result caches
   - Clear static caches in export extensions
3. Split oversized `exportData()` into stages: `fetch_batch()` → `format_batch()` → `write_batch()` → `cleanup_batch()`.
4. Add memory guard: if `memory_get_usage() > threshold`, force garbage collection + context reset.
5. Standardize batch lifecycle interface across all 23 export extensions.

---

### Issue 4 — WooCommerce Import Consistency (High Priority)

**Refs:** #26853, #26817, #26753

| Symptom | Root Cause |
|---------|------------|
| Brands not updating | Inconsistent blank-value handling per handler |
| Tags removed | Blank CSV column treated as "clear field" |
| Gallery inconsistent | Different rules in `WooCommerceMetaImport` vs `WooCommerceCoreImport` |
| Attributes differ | No shared preserve-blank rule |

**Fix approach:**

1. Create `ImportValueResolver` service:

```php
// Rule: unmapped or blank column = preserve existing value
public function resolve( $csv_value, $existing_value, $is_mapped ) {
    if ( ! $is_mapped ) return $existing_value;
    if ( $csv_value === '' || $csv_value === null ) return $existing_value;
    return $csv_value;
}
```

2. Apply in:
   - `importExtensions/WooCommerceCoreImport.php`
   - `importExtensions/WooCommerceMetaImport.php`
   - `importExtensions/ProductAttrImport.php`
   - `importExtensions/TaxonomiesImport.php` (brands, tags, categories)
   - `MediaHandling.php` (gallery)
3. Document rule in `hooks/Custom-Hooks.md` and developer docs.
4. Add filter `sm_uci_pro_resolve_import_value` for extensibility.

---

### Issue 5 — Media Remote Upload (Medium Priority)

**Refs:** #26819

**Existing:** `media/MediaBootstrap.php`, `app/admin/settings/settingsoptions/mediaDownloadSettings.js` — timeout, retry, batch settings already exist.

**Fix approach:**

1. Verify settings are respected in `MediaHandling.php` download paths.
2. Implement retry with exponential backoff (reuse pattern from `GoogleSheetsHttpTransport`).
3. Validate downloaded file (size > 0, valid MIME) before attaching.
4. Partial failure recovery: log failed URL, continue import, populate `FailedImagesUpdate` queue.
5. Gallery mapping: ensure all pipe/comma-separated URLs processed independently.

---

### Issue 6 — User Import / Export Verification (Medium Priority)

**Refs:** #26455

**Previous fixes (8.14.x – 8.15):** Login regression, multisite zero-user export.

**Approach:** Validation only — no code changes unless regression found.

| Test | 8.15.5 | 8.16.8 | 8.16.9 |
|------|--------|--------|--------|
| User import + login | ✓ | ✓ | ✓ |
| Multisite user export | ✓ | ✓ | ✓ |
| Custom field mapping persist | ✓ | ✓ | ✓ |

**Files:** `importExtensions/UsersImport.php`, user export in `ExportExtension.php`.

---

### Issue 7 — Google Sheets Connection Stability (Medium Priority)

**Refs:** #26814, #26387, #25676, #26409

**Existing:** `uploadModules/GoogleSheetsHttpTransport.php`, `uploadModules/GsheetUpload.php`, `controllers/GSheet.php`

**Fix approach:**

1. Connection pooling / session reuse for repeated API calls within one import.
2. Pre-flight connectivity check before scheduled import starts.
3. Published URL path in `UrlUpload.php` — validate redirect chain, handle `export?format=csv` variants.
4. Token refresh integration (shared with Issue 2).
5. Structured error logging with retry reason codes.

---

### Issue 8 — Rank Math Schema Auto-Generation (Medium Priority)

**Refs:** #26877

**Approach:**

1. Identify shared code with Custom Fields Basic Pro plugin.
2. Trace Rank Math schema hooks during import in `importExtensions/` (search `rank_math`, `RankMath`).
3. Coordinate fix across both plugins.
4. Ensure import does not trigger auto-generation when schema fields are unmapped.

---

## 5. Feature Toggle Architecture

### 5.1 Design Goals

| Toggle OFF | Toggle ON |
|------------|-----------|
| No class autoload | Classes loaded |
| No object instantiation | Services instantiated |
| No hook registration | Hooks registered |
| No background init | Normal execution |
| Zero measurable overhead | Full feature available |

**Performance target:** All toggles OFF → runtime ≈ 8.15.5 baseline.

### 5.2 Proposed Architecture

```
includes/FeatureRegistry.php        ← defines all toggleable features
includes/FeatureLoader.php         ← lazy-loads enabled features only
includes/FeatureSettingsController.php  ← AJAX get/save toggles
app/admin/settings/.../featureModules.js  ← UI toggles panel
```

**FeatureRegistry entry structure:**

```php
[
    'id'          => 'ai_import',
    'label'       => 'AI Import Features',
    'description' => 'Natural language import, AI field mapping, governance',
    'since'       => '8.15',
    'bootstrap'   => 'AI/AIBootstrap.php',
    'init_method' => 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\AI\\AIBootstrap::init',
    'modules'     => ['ai/', 'AI/'],
    'default'     => true,
]
```

### 5.3 Feature Toggle Inventory

| Toggle ID | Feature | Since | Bootstrap / Modules |
|-----------|---------|-------|---------------------|
| `ai_import` | AI Natural Language + Field Mapping + Governance | 8.15 | `AI/AIBootstrap.php`, `ai/` |
| `wpbakery` | WPBakery Page Builder I/E | 8.15 | `WPBakeryExtension`, `WPBakeryImport`, `WPBakeryExport` |
| `db_migration` | External Database Migration | 8.15 | `databaseMigration/DatabaseMigrationBootstrap.php` |
| `automation_api` | REST API Import + Webhooks | 8.16 | `automation/AutomationBootstrap.php` |
| `media_queue` | Media Download Queue Pipeline | 8.15 | `media/MediaBootstrap.php` |
| `woo_native_csv` | WooCommerce Native CSV Format | 8.15 | `compatibility/WooCommerceNative/Bootstrap.php` |
| `woo_surecart_migration` | Woo → SureCart Migration | 8.15 | `migrationModules/WooToSureCart/` |
| `bricks_builder` | Bricks Builder I/E | 8.16 | `BricksExtension`, `BricksImport`, `BricksExport` |
| `oxygen_builder` | Oxygen Builder I/E | 8.16 | `OxygenExtension`, `OxygenImport`, `OxygenExport` |
| `hook_system` | Centralized Import/Export Hooks | 8.16 | `wp-csv-custom-hooks.php`, `hooks/` |
| `rest_api_import` | REST API Paginated Import | 8.16 | Part of automation module |
| `google_sheets_transport` | Google Sheets HTTP Transport + OAuth | 8.15 | `GoogleSheetsHttpTransport`, `GsheetUpload` |
| `spreadsheet_editor` | In-browser Spreadsheet Editor | 8.16 | `SpreadsheetEditorController.php` |
| `import_preview` | Import Preview Service | 8.16 | `ImportPreviewController.php` |
| `retry_resume` | Import Retry / Resume Queue | 8.16 | `RetryController`, `ImportResumeController` |

### 5.4 Bootstrap Refactor Plan

**Phase A — Stop eager glob loading:**

Replace in `wp-ultimate-csv-importer-pro.php`:

```php
// BEFORE (eager)
$extension_modules = glob(__DIR__ . '/extensionModules/*.php');
foreach ($extension_modules as $f) { require_once $f; }

// AFTER (lazy via FeatureLoader)
FeatureLoader::load_core_modules();  // always: CoreFields, Mapping, SaveMapping, etc.
FeatureLoader::load_enabled_features();  // only toggled-on features
```

**Phase B — Conditional singleton instantiation:**

In `UltimatePro::getInstance()`, wrap post-8.15 singletons:

```php
if ( FeatureRegistry::is_enabled('ai_import') ) {
    self::$ai_natural_language_import_instance = AI_Natural_Language_Imports::getInstance();
}
```

**Phase C — Frontend conditional loading:**

React upload options panel hides disabled upload sources (AI, DB Migration, REST API, GSheet if transport disabled).

**Phase D — Settings persistence:**

Option key: `sm_uci_pro_feature_toggles` (array of `feature_id => bool`).

Migration on upgrade: all features default `true` for existing installs (no behavior change until user disables).

### 5.5 Verification

1. **Profiler:** Compare `get_included_files()` count with all toggles OFF vs ON.
2. **Hook count:** `count($GLOBALS['wp_filter'])` with toggles OFF vs 8.15.5 tag.
3. **Memory:** `memory_get_peak_usage()` on admin page load.
4. **Query Monitor / Xdebug:** Confirm disabled feature classes never appear in call stack.

---

## 6. Phased Implementation Timeline

### Phase 1 — Foundation (Days 1–2)

- [ ] Create `FeatureRegistry`, `FeatureLoader`, settings controller
- [ ] Add Feature Modules settings UI tab
- [ ] Refactor main bootstrap to use FeatureLoader (keep all defaults ON)
- [ ] Add DB migration for schedule heartbeat columns

### Phase 2 — Critical Fixes (Days 2–4)

- [ ] **Issue 1:** Mapping render loop + formula 403 fix
- [ ] **Issue 2:** Schedule state machine + OAuth refresh
- [ ] **Issue 4:** `ImportValueResolver` for WooCommerce

### Phase 3 — Export & Media (Days 4–5)

- [ ] **Issue 3:** Export batch context + memory cleanup
- [ ] **Issue 5:** Media retry/backoff validation
- [ ] **Issue 7:** Google Sheets connection stability

### Phase 4 — Validation & Secondary (Days 5–6)

- [ ] **Issue 6:** User I/E regression tests
- [ ] **Issue 8:** Rank Math schema (coordinate with CFB Pro)
- [ ] Enable feature toggles default-OFF test mode for profiling

### Phase 5 — Benchmark & Release (Day 7)

- [ ] Run full benchmark suite (see Section 7)
- [ ] Generate benchmark report
- [ ] Tag 8.16.8 / prepare 8.16.9

---

## 7. Benchmark Validation Plan

### 7.1 Test Environment

- WordPress 6.x, PHP 8.1+, WooCommerce active
- Standard dataset: 10K posts, 5K products, 1K users
- Query Monitor + Xdebug profiler enabled
- WP-Cron or Action Scheduler for scheduled tests

### 7.2 Versions to Compare

| Version | Purpose |
|---------|---------|
| 8.15.5 (git tag) | Baseline |
| 8.16.8 (this branch) | Target |
| 8.16.9 (if available) | Preferred |

### 7.3 Metrics

| Metric | Method |
|--------|--------|
| Import throughput (records/sec) | 10K post import, measure wall time |
| Export throughput | 10K post export, batched |
| Peak memory | `memory_get_peak_usage()` during import |
| CPU time | Xdebug profiler |
| Admin page load time | TTFB for plugin admin page |
| AJAX response time | `mappingfields`, `saveMappedFields`, `StartImport` |
| Scheduler reliability | 10 scheduled imports, measure completion rate |
| Cloud connector reliability | GSheet/GDrive/Dropbox/OneDrive success rate |
| Feature toggle overhead | All OFF vs all ON vs individual |
| Error rate | Failed imports/exports per 1000 records |

### 7.4 Toggle Matrix

| Scenario | Expected |
|----------|----------|
| All toggles OFF | ≈ 8.15.5 baseline (±5%) |
| All toggles ON | Full 8.16 feature set |
| Individual toggle ON | Only that feature's overhead measurable |

### 7.5 Regression Checklist

- [ ] Plugin activation (fresh + upgrade from 8.15.5)
- [ ] Mapping engine (all import types)
- [ ] SQL escaping (special characters in data)
- [ ] Advanced Mode (no freeze, attribute dropdown works)
- [ ] Formula save (no 403)
- [ ] Category handling (name ≠ slug)
- [ ] Scheduled imports (completion, retry, OAuth refresh)
- [ ] WooCommerce imports (brands, tags, gallery, attributes, blank preserve)
- [ ] Media imports (remote URL, gallery, partial failure)
- [ ] Export engine (CPT, ACF, Meta Box, batched)
- [ ] Google Sheets integration
- [ ] User import/export (single + multisite)

---

## 8. Key File Reference

| Area | Primary Files |
|------|---------------|
| Bootstrap | `wp-ultimate-csv-importer-pro.php` |
| Mapping UI | `app/admin/uploader/.../mappingSection.js` |
| Mapping save | `SaveMapping.php` |
| AJAX auth | `includes/ProAjaxAuthorization.php` |
| Import dispatch | `importExtensions/CoreFieldsImport.php` |
| WooCommerce | `importExtensions/WooCommerceCoreImport.php`, `WooCommerceMetaImport.php` |
| Export | `exportExtensions/ExportExtension.php` |
| Scheduler | `scheduleExtensions/ScheduleImport.php`, `includes/ScheduleStateService.php` |
| Google Sheets | `uploadModules/GoogleSheetsHttpTransport.php`, `GsheetUpload.php` |
| Media | `MediaHandling.php`, `media/MediaBootstrap.php` |
| Hooks (8.16) | `wp-csv-custom-hooks.php`, `hooks/` |
| Settings UI | `app/admin/settings/settingsoptions/` |
| Version history | `wp-ultimate-csv-importer.json` |
| DB schema | `Tables.php`, `SmackCSVInstall.php` |

---

## 9. Acceptance Criteria (from #1442)

### Root Cause Resolution
- [ ] All 8 issue groups fixed architecturally (no symptom patches)
- [ ] Fixes verified against referenced ticket numbers

### Feature Toggle Architecture
- [ ] Every post-8.15 feature has independent Enable/Disable toggle
- [ ] Toggle OFF = no class load, no instantiation, no hooks, no execution
- [ ] Toggle ON = normal feature operation
- [ ] Profiler confirms zero overhead for disabled modules

### Regression Validation
- [ ] All baseline features work on 8.16.8+ with no regression vs 8.15.5

### Benchmark Validation
- [ ] Complete benchmark on 8.15.5, 8.16.8, 8.16.9
- [ ] All toggles OFF performance ≈ 8.15.5 baseline
- [ ] Benchmark report delivered

### Documentation
- [ ] Root cause analysis documented
- [ ] Feature toggle architecture documented
- [ ] Benchmark comparison report
- [ ] Test datasets and known limitations listed

---

## 10. Risks & Dependencies

| Risk | Mitigation |
|------|------------|
| Glob refactor breaks extension discovery | Keep core modules always loaded; feature modules loaded via registry map |
| Toggle OFF breaks import templates using that feature | Validate template on import start; warn if required feature disabled |
| Rank Math fix requires CFB Pro coordination | Parallel track; do not block other issues |
| 8.16.8 tag not yet available | Implement on current 8.16.7 branch; benchmark against tag when released |
| Free plugin interaction | Test with ProFreeAjaxDedup; verify free+pro coexistence |

---

## 11. Next Steps

1. ~~**8.15.5 baseline import**~~ ✅ BL-02 complete (`3840s`, `0.260 rec/s`, 1000 WC products). Artifacts in `docs/1442/validation/`.
2. **Work on `master`** — no separate feature branch; commit Phase 1+ directly to `master`.
3. **Start Phase 1** — FeatureRegistry + FeatureLoader (non-breaking, all defaults ON).
4. **Parallel:** Deep-dive Issue 1 mapping render loop with React DevTools profiler.
5. **After Phase 4:** Same 1K WC CSV — import must be **faster than 64 min**; all features still work with toggles ON.

### Documentation index

| Path | Purpose |
|------|---------|
| `docs/IMPLEMENTATION_PLAN_1442.md` | High-level plan (this file) |
| `docs/1442/00_PROJECT_OVERVIEW.md` | Phase index, risks, exit criteria |
| `docs/1442/01`–`05_PHASE_*.md` | Per-phase tasks |
| `docs/1442/06_TEST_CHECKLIST.md` | Master test matrix |
| `docs/1442/07_BASELINE_8.15.5_INVENTORY.md` | Git-verified 8.15.5 inventory |
| `docs/1442/validation/BENCHMARK_BASELINE_8.15.5.md` | Baseline run results |
| `docs/1442/validation/BENCHMARK_1K_PRODUCT_COMPARISON_SUMMARY.csv` | BL-02 metrics (CSV) |
