#!/bin/bash
# Phase 5 verification: Search plugin for removed/deprecated PHP functions
# Run from plugin root: bash docs/verify-phase5-php-functions.sh
# Note: "each" matches "foreach" - we exclude those; search for " each(" instead

REMOVED=(
  "create_function"
  "mysql_"
  "session_register"
  "ereg("
  "eregi("
  "ereg_replace"
  "eregi_replace"
)

echo "=== Phase 5: Removed PHP Functions Audit ==="
echo "Plugin: $(basename "$(dirname "$(dirname "$0")")")"
echo ""

FOUND=0
for fn in "${REMOVED[@]}"; do
  MATCHES=$(grep -rn --include="*.php" "$fn" . 2>/dev/null | grep -v vendor | grep -v "docs/")
  if [ -n "$MATCHES" ]; then
    echo "⚠️  FOUND: $fn"
    echo "$MATCHES"
    echo ""
    FOUND=1
  fi
done

# PHP split() - deprecated, use explode/preg_split; avoid matching ->split() or Preg::split
SPLIT_MATCHES=$(grep -rn --include="*.php" -E '\bsplit\s*\(' . 2>/dev/null | grep -v vendor | grep -v "docs/" | grep -v -- '->split' | grep -v 'Preg::split' | grep -v '::split' || true)
if [ -n "$SPLIT_MATCHES" ]; then
  echo "⚠️  FOUND: split() (deprecated PHP function)"
  echo "$SPLIT_MATCHES"
  echo ""
  FOUND=1
fi

# each() - removed in PHP 8.0; match " each(" to avoid "foreach"
EACH_MATCHES=$(grep -rn --include="*.php" ' each(' . 2>/dev/null | grep -v vendor | grep -v "docs/" || true)
if [ -n "$EACH_MATCHES" ]; then
  echo "⚠️  FOUND: each() (removed in PHP 8.0)"
  echo "$EACH_MATCHES"
  echo ""
  FOUND=1
fi

if [ $FOUND -eq 0 ]; then
  echo "✅ No removed PHP functions found (create_function, each, mysql_*, ereg*, split, session_register)."
  exit 0
else
  echo "❌ Removed/deprecated PHP functions detected. Replace with modern alternatives."
  exit 1
fi
