#!/bin/bash
# Phase 2 verification: Search plugin for deprecated WordPress core functions
# Run from plugin root: bash docs/verify-deprecated-functions.sh

DEPRECATED=(
  "activate_sitewide_plugin"
  "deactivate_sitewide_plugin"
  "wp_setcookie"
  "wp_clearcookie"
  "get_userdatabylogin"
  "get_user_by_email"
  "get_paged_template"
  "wp_get_sites"
  "get_settings("
  "user_can_edit_post("
  "user_can_create_post("
  "get_linksbyname("
  "list_cats("
  "dropdown_cats("
  "get_archives("
  "get_author_link("
  "link_pages("
  "permalink_link("
)

echo "=== WP 7.0 Deprecated Functions Audit ==="
echo "Plugin: $(basename "$(dirname "$(dirname "$0")")")"
echo ""

FOUND=0
for fn in "${DEPRECATED[@]}"; do
  MATCHES=$(grep -rn --include="*.php" "$fn" . 2>/dev/null | grep -v vendor | grep -v "docs/")
  if [ -n "$MATCHES" ]; then
    echo "⚠️  FOUND: $fn"
    echo "$MATCHES"
    echo ""
    FOUND=1
  fi
done

if [ $FOUND -eq 0 ]; then
  echo "✅ No deprecated WordPress core functions found."
  exit 0
else
  echo "❌ Deprecated functions detected. Update to modern alternatives."
  exit 1
fi
