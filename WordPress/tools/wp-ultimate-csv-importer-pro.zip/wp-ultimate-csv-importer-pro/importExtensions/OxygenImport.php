<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class OxygenImport {
	private static $oxygen_instance = null;

	public static function getInstance() {
		if (OxygenImport::$oxygen_instance == null) {
			OxygenImport::$oxygen_instance = new OxygenImport;
		}
		return OxygenImport::$oxygen_instance;
	}

	/**
	 * Validate Oxygen Builder fields before saving to DB.
	 *
	 * @param array $post_values  Mapped field values.
	 * @param int   $post_id      The target post ID.
	 * @return array {
	 *     bool   $valid   True when no errors found.
	 *     array  $errors  Map of field_name => human-readable error reason.
	 * }
	 */
	private function validate_oxygen_fields( $post_values, $post_id ) {
		$errors = [];

		// --- _ct_builder_json must be valid JSON ---
		if ( ! empty( $post_values['_ct_builder_json'] ) ) {
			$json = $post_values['_ct_builder_json'];
			json_decode( $json );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				$errors['_ct_builder_json'] = sprintf(
					'Invalid JSON (error: %s). Length: %d. Last 200 chars: %s',
					json_last_error_msg(),
					strlen( $json ),
					substr( $json, -200 )
				);
			}
		}

		// --- _ct_builder_shortcodes must start with '[' (shortcode syntax) ---
		// A JSON overflow fragment (spilled from _ct_builder_json) will NOT start with '['.
		if ( ! empty( $post_values['_ct_builder_shortcodes'] ) ) {
			$shortcodes = $post_values['_ct_builder_shortcodes'];
			$trimmed    = ltrim( $shortcodes );
			if ( strlen( $trimmed ) > 0 && $trimmed[0] !== '[' ) {
				$errors['_ct_builder_shortcodes'] = sprintf(
					'Corrupt value — does not start with "[ct_". Looks like a JSON overflow fragment. Length: %d. Value: %s',
					strlen( $shortcodes ),
					substr( $shortcodes, 0, 300 )
				);
			}
		}

		// --- _ct_custom_css should look like CSS, not a JSON fragment ---
		// A spilled JSON tail would match patterns like `"key"":value` or start with `depth"":3`.
		if ( ! empty( $post_values['_ct_custom_css'] ) ) {
			$css = $post_values['_ct_custom_css'];
			// JSON overflow fragments typically start with a key fragment followed by "": or ":
			if ( preg_match( '/^[\w\s"]*""\s*:/', ltrim( $css ) ) ) {
				$errors['_ct_custom_css'] = sprintf(
					'Corrupt value — looks like a JSON overflow fragment, not CSS. Length: %d. Value: %s',
					strlen( $css ),
					substr( $css, 0, 300 )
				);
			}
		}

		return [
			'valid'  => empty( $errors ),
			'errors' => $errors,
		];
	}

	public function set_oxygen_values( $header_array, $value_array, $map, $post_id, $type, $hash_key, $gmode, $templatekey ) {
		$helpers_instance = ImportHelpers::getInstance();
		$post_values      = $helpers_instance->get_header_values( $map, $header_array, $value_array );
		$media_instance   = MediaHandling::getInstance();

		// Log all raw Oxygen field values as read from the CSV (before any processing)
		$oxygen_fields = [ '_ct_builder_json', '_ct_builder_shortcodes', '_ct_custom_css', 'oxygen_media' ];
		foreach ( $oxygen_fields as $field ) {
			$raw_val = isset( $post_values[ $field ] ) ? $post_values[ $field ] : '(not set)';
			error_log( sprintf(
				'[WP CSV Importer] OxygenImport RAW field "%s" for post_id=%d | length=%d | value_snippet=%s',
				$field,
				$post_id,
				strlen( (string) $raw_val ),
				substr( (string) $raw_val, 0, 300 )
			) );
		}

		$json_data    = isset( $post_values['_ct_builder_json'] ) ? $post_values['_ct_builder_json'] : '';
		$oxygen_media = isset( $post_values['oxygen_media'] )     ? $post_values['oxygen_media']     : '';

		// Replace media URLs inside the JSON before validation
		if ( ! empty( $oxygen_media ) && ! empty( $json_data ) ) {
			$media_urls = explode( '|', $oxygen_media );
			foreach ( $media_urls as $old_url ) {
				$old_url = trim( $old_url );
				if ( empty( $old_url ) ) {
					continue;
				}

				$attach_id = $media_instance->image_function(
					$old_url, $post_id, null, null, false,
					$header_array, $value_array,
					null, null, null, null, 'Oxygen', $type
				);

				if ( $attach_id ) {
					$new_url = wp_get_attachment_url( $attach_id );
					if ( $new_url ) {
						$json_data = str_replace( $old_url, $new_url, $json_data );

						$escaped_old_url = str_replace( '/', '\/', $old_url );
						$escaped_new_url = str_replace( '/', '\/', $new_url );
						$json_data = str_replace( $escaped_old_url, $escaped_new_url, $json_data );
					}
				}
			}
		}

		// Sync post_values with the media-replaced JSON so validation uses final data
		if ( ! empty( $json_data ) ) {
			$post_values['_ct_builder_json'] = $json_data;
		}

		// Validate all Oxygen fields before saving to DB
		$validation = $this->validate_oxygen_fields( $post_values, $post_id );

		if ( ! $validation['valid'] ) {
			foreach ( $validation['errors'] as $field => $reason ) {
				error_log( sprintf(
					'[WP CSV Importer] OxygenImport SKIPPED corrupt field "%s" for post_id=%d. Reason: %s',
					$field,
					$post_id,
					$reason
				) );
			}
		}

		foreach ( $post_values as $custom_key => $custom_value ) {
			// Never save the helper column
			if ( $custom_key === 'oxygen_media' ) {
				continue;
			}

			// Skip any field that failed validation
			if ( isset( $validation['errors'][ $custom_key ] ) ) {
				continue;
			}

			if ( $custom_key === '_ct_builder_json' ) {
				// Use the media-URL-replaced JSON
				$custom_value = wp_slash( $json_data );
			}

			update_post_meta( $post_id, $custom_key, $custom_value );
		}
	}
}
