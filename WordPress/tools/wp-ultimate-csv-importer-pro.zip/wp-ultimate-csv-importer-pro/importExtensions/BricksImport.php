<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class BricksImport {
	private static $instance = null;
	private $current_post_id;

	public static function getInstance() {
		if (BricksImport::$instance == null) {
			BricksImport::$instance = new BricksImport;
		}
		return BricksImport::$instance;
	}

	public function set_bricks_value($header_array, $value_array, $map, $post_id, $type) {
		$this->current_post_id = $post_id;
		$post_values = [];
		$helpers_instance = ImportHelpers::getInstance();
		$post_values = $helpers_instance->get_header_values($map, $header_array, $value_array);
		
		foreach ($post_values as $custom_key => $custom_value) {
			if ($custom_key == '_bricks_page_content_2') {
				// Bricks layout is JSON. If it was base64 encoded during export, decode it.
				// Checking if it looks like base64 or if it's already JSON
				$decoded_value = base64_decode($custom_value, true);
				if ($decoded_value !== false && (strpos($decoded_value, '[') === 0 || strpos($decoded_value, '{') === 0)) {
					$custom_value = $decoded_value;
				}

				// Replace placeholder with current site URL for portability
				$custom_value = str_replace('{{SITE_URL}}', get_site_url(), $custom_value);
				
				// Handle Media Sideloading and URL replacement within JSON
				$custom_value = $this->process_bricks_media($custom_value);
				
				update_post_meta($post_id, $custom_key, $custom_value);
				update_post_meta($post_id, '_bricks_editor_mode', 'bricks');
			} elseif (in_array($custom_key, ['bricks_components', 'bricks_global_classes'])) {
				if (empty($custom_value)) continue;

				$decoded_value = base64_decode($custom_value, true);
				if ($decoded_value !== false && (strpos($decoded_value, '[') === 0 || strpos($decoded_value, '{') === 0)) {
					$custom_value = $decoded_value;
				}

				$custom_value = str_replace('{{SITE_URL}}', get_site_url(), $custom_value);
				$imported_data = json_decode($custom_value, true);

				if (!is_array($imported_data)) continue;

				if ($custom_key === 'bricks_components') {
					$this->import_bricks_components($imported_data);
				} elseif ($custom_key === 'bricks_global_classes') {
					$this->import_bricks_global_classes($imported_data);
				}
			} else {
				update_post_meta($post_id, $custom_key, $custom_value);
			}
		}

		// Trigger cache regeneration
		do_action('bricks/frontend/after_render_data', $post_id);
	}

	private function process_bricks_media($json_data) {
		$data = is_string($json_data) ? json_decode($json_data, true) : $json_data;
		
		if (!is_array($data)) {
			return $json_data;
		}

		// Extract and import components if they are bundled
		if (isset($data['smack_bricks_layout']) && isset($data['smack_bricks_components'])) {
			$this->import_bricks_components($data['smack_bricks_components']);
			$data = $data['smack_bricks_layout'];
		}

		$processed_data = $this->recursive_media_sideload($data);
		
		return $processed_data;
	}

	private function import_bricks_components($imported_components) {
		$existing_components = get_option('bricks_components', []);
		if (!is_array($existing_components)) $existing_components = [];
		
		$updated = false;
		foreach ($imported_components as $comp) {
			if (!isset($comp['id'])) continue;
			
			$found_key = false;
			foreach ($existing_components as $key => $existing) {
				if (isset($existing['id']) && $existing['id'] === $comp['id']) {
					$found_key = $key;
					break;
				}
			}

			// Process media/links for the incoming component
			if (isset($comp['elements']) && is_array($comp['elements'])) {
				$comp['elements'] = $this->recursive_media_sideload($comp['elements']);
			}
			if (isset($comp['settings']) && is_array($comp['settings'])) {
				$comp['settings'] = $this->recursive_media_sideload($comp['settings']);
			}

			if ($found_key !== false) {
				// Compare deeply. We use JSON comparison for simplicity and reliability.
				if (wp_json_encode($existing_components[$found_key]) !== wp_json_encode($comp)) {
					$existing_components[$found_key] = $comp;
					$updated = true;
				}
			} else {
				$existing_components[] = $comp;
				$updated = true;
			}
		}

		if ($updated) {
			update_option('bricks_components', $existing_components);
		}
	}

	private function import_bricks_global_classes($imported_data) {
		$existing_data = get_option('bricks_global_classes', []);
		if (!is_array($existing_data)) $existing_data = [];
		
		$updated = false;
		foreach ($imported_data as $item) {
			if (!isset($item['id'])) continue;

			$found_key = false;
			foreach ($existing_data as $key => $existing) {
				if (isset($existing['id']) && $existing['id'] === $item['id']) {
					$found_key = $key;
					break;
				}
			}

			// Process media/links for the incoming class
			if (isset($item['settings']) && is_array($item['settings'])) {
				$item['settings'] = $this->recursive_media_sideload($item['settings']);
			}

			if ($found_key !== false) {
				if (wp_json_encode($existing_data[$found_key]) !== wp_json_encode($item)) {
					$existing_data[$found_key] = $item;
					$updated = true;
				}
			} else {
				$existing_data[] = $item;
				$updated = true;
			}
		}

		if ($updated) {
			update_option('bricks_global_classes', $existing_data);
		}
	}

	private function recursive_media_sideload($data) {
		if (is_array($data)) {
			// Handle internal links by post title
			if (isset($data['type']) && $data['type'] === 'internal' && isset($data['smack_post_title'])) {
				$p = get_page_by_title($data['smack_post_title'], OBJECT, get_post_types());
				if ($p) {
					$data['id'] = $p->ID;
				}
				unset($data['smack_post_title']);
			}

			// Handle query loop include/exclude titles
			if (isset($data['query']) && is_array($data['query'])) {
				if (isset($data['query']['smack_include_titles']) && is_array($data['query']['smack_include_titles'])) {
					$ids = [];
					foreach ($data['query']['smack_include_titles'] as $title) {
						$p = get_page_by_title($title, OBJECT, get_post_types());
						if ($p) $ids[] = $p->ID;
					}
					if (!empty($ids)) {
						$data['query']['include'] = $ids;
					}
					unset($data['query']['smack_include_titles']);
				}
				if (isset($data['query']['smack_exclude_titles']) && is_array($data['query']['smack_exclude_titles'])) {
					$ids = [];
					foreach ($data['query']['smack_exclude_titles'] as $title) {
						$p = get_page_by_title($title, OBJECT, get_post_types());
						if ($p) $ids[] = $p->ID;
					}
					if (!empty($ids)) {
						$data['query']['exclude'] = $ids;
					}
					unset($data['query']['smack_exclude_titles']);
				}
			}

			// Check if this looks like a Bricks image object
			if (isset($data['url']) && is_string($data['url']) && (strpos($data['url'], 'http') === 0) && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $data['url'])) {
				$new_image = $this->sideload_image_with_id($data['url']);
				if ($new_image) {
					$data['id'] = $new_image['id'];
					$data['url'] = $new_image['url'];
					if (isset($data['full'])) $data['full'] = $new_image['url'];
					if (isset($data['filename'])) $data['filename'] = basename($new_image['url']);
					return $data;
				}
			}

			foreach ($data as $key => $value) {
				if (is_array($value)) {
					$data[$key] = $this->recursive_media_sideload($value);
				} elseif (is_string($value) && (strpos($value, 'http') === 0) && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $value)) {
					// It's a plain image URL string, sideload it
					$new_url = $this->sideload_image($value);
					if ($new_url) {
						$data[$key] = $new_url;
					}
				}
			}
		}
		return $data;
	}

	private function sideload_image_with_id($url) {
		$media_instance = MediaHandling::getInstance();
		$attach_id = $media_instance->image_function($url, $this->current_post_id);
		
		if (!$attach_id || is_wp_error($attach_id)) {
			return false;
		}

		return [
			'id'  => $attach_id,
			'url' => wp_get_attachment_url($attach_id)
		];
	}

	private function sideload_image($url) {
		$media_instance = MediaHandling::getInstance();
		$attach_id = $media_instance->image_function($url, $this->current_post_id);
		
		if (!$attach_id || is_wp_error($attach_id)) {
			return false;
		}

		return wp_get_attachment_url($attach_id);
	}
}
