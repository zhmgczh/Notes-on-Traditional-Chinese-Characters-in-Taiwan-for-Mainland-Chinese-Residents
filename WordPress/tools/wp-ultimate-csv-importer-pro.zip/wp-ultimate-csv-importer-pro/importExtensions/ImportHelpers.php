<?php
/*********************************
        'FLUENTCART_PRODUCTS' => 'fct_product',
        'FLUENTCART_ORDERS' => 'fct_order',
        'FLUENTCART_CUSTOMERS' => 'fct_customer',
        'FLUENTCART_SUBSCRIPTIONS' => 'fct_subscription',
        'FLUENTCART_COUPONS' => 'fct_coupon',
        'FLUENTCART_DOWNLOADS' => 'fct_download',
        'FLUENTCART_REPORTS' => 'fct_report',
*********************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

use PhpParser\Error;
use PhpParser\ParserFactory;
use NXP\MathExecutor;

if ( file_exists( __DIR__ . '/../media/Services/MediaGalleryImporter.php' ) ) {
	require_once __DIR__ . '/../media/Services/MediaGalleryImporter.php';
}
if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

class ImportHelpers
{
	private static $helpers_instance = null;

	public static function getInstance()
	{

		if (ImportHelpers::$helpers_instance == null) {
			ImportHelpers::$helpers_instance = new ImportHelpers;
			return ImportHelpers::$helpers_instance;
		}
		return ImportHelpers::$helpers_instance;
	}

	public function get_requested_term_details($post_id, $term, $taxonomy)
	{
		if (is_array($term)) {
			foreach ($term as $terms) {
				$termLen = strlen($terms);
				$checktermid = intval($terms);
				$verifiedTermLen = strlen($checktermid);
				if ($termLen == $verifiedTermLen) {
					return $terms;
				}

			}
			$reg_term_id = wp_set_object_terms($post_id, $term, $taxonomy);

			$terms = get_term_by('name', "$terms", "$taxonomy");
			if (isset($terms->term_id)) {
				$term_id = $terms->term_id;

				//incase if term id and term taxonomy id are not same
				// global $wpdb;
				// $term_taxonomy_id = $reg_term_id[0];
				// $term_id = $wpdb->get_var("SELECT term_id FROM {$wpdb->prefix}term_taxonomy WHERE term_taxonomy_id = $term_taxonomy_id");
			}
			return $term_id;
		} else {
			$termLen = strlen($term);
			$checktermid = intval($term);
			$verifiedTermLen = strlen($checktermid);
			if ($termLen == $verifiedTermLen) {
				return $term;
			} else {
				$reg_term_id = wp_set_object_terms($post_id, $term, $taxonomy);

				if (isset($reg_term_id[0])) {
					$term_id = $reg_term_id[0];
				}
				return $term_id;
			}
		}
	}

	public function get_from_user_details($request_user)
	{
		global $wpdb;
		$authorLen = strlen($request_user);
		$checkpostuserid = intval($request_user);
		$postAuthorLen = strlen($checkpostuserid);

		if ($authorLen == $postAuthorLen) {
			$postauthor = $wpdb->get_results($wpdb->prepare("select ID,user_login from {$wpdb->prefix}users where ID = %s", $request_user));
			if (empty($postauthor) || !$postauthor[0]->ID) { // If user name are numeric Ex: 1300001
				$postauthor = $wpdb->get_results($wpdb->prepare("select ID,user_login from {$wpdb->prefix}users where user_login = \"{%s}\"", $request_user));
			}
		} else {
			$postauthor = $wpdb->get_results($wpdb->prepare("select ID,user_login from {$wpdb->prefix}users where user_login = %s", $request_user));
		}
		if (empty($postauthor) || !$postauthor[0]->ID) {
			$request_user = 1;
			$admindet = $wpdb->get_results($wpdb->prepare("select ID,user_login from {$wpdb->prefix}users where ID = %d", 1));
			$message = " <b>Author :- </b> not found (assigned to <b>" . $admindet[0]->user_login . "</b>)";
		} else {
			$request_user = $postauthor[0]->ID;
			$admindet = $wpdb->get_results($wpdb->prepare("select ID,user_login from {$wpdb->prefix}users where ID = %s", $request_user));
			$message = " <b>Author :- </b>" . $admindet[0]->user_login;
		}
		$userDetails['user_id'] = $request_user;
		$userDetails['user_login'] = $admindet[0]->user_login;
		$userDetails['message'] = $message;
		return $userDetails;
	}

	public function assign_post_status($data_array)
	{
		global $wpdb;
		if (isset($data_array['is_post_status']) && $data_array['is_post_status'] != 'on') {
			$data_array['post_status'] = $data_array['is_post_status'];
			unset($data_array['is_post_status']);
		}
		if (isset($data_array['post_status']) && $data_array['post_status'] == 'trash') {
			$title = $data_array['post_title'];
			$wpdb->update(
				$wpdb->prefix . 'posts',
				array( 'post_status' => 'trash' ),
				array( 'post_title' => $title ),
				array( '%s' ),
				array( '%s' )
			);
		} elseif (isset($data_array['post_status']) && $data_array['post_status'] == 'delete') {
			$post_title = $data_array['post_title'];
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->prefix}posts WHERE post_status = 'trash' AND post_title = %s",
					$post_title
				)
			);
			$wpdb->query("DELETE FROM {$wpdb->prefix}posts WHERE post_status = 'delete' ");
		} else {
			if (isset($data_array['post_status']) || isset($data_array['coupon_status'])) {
				if (isset($data_array['post_status'])) {
					$data_array['post_status'] = strtolower($data_array['post_status']);
				} else {
					$data_array['post_status'] = strtolower($data_array['coupon_status']);
				}
				$data_array['post_status'] = trim($data_array['post_status']);

				if($data_array['post_status'] == 'no select') {
					$data_array['post_status'] = '';
				}

				if (!empty($data_array['post_status']) && $data_array['post_status'] != 'publish' && $data_array['post_status'] != 'private' && $data_array['post_status'] != 'draft' && $data_array['post_status'] != 'pending' && $data_array['post_status'] != 'sticky' && $data_array['post_status'] != 'scheduled' && $data_array['post_status'] != 'future') {
					$stripPSF = strpos($data_array['post_status'], '{');
					if ($stripPSF === 0) {
						$poststatus = substr($data_array['post_status'], 1);
						$stripPSL = substr($poststatus, -1);
						if ($stripPSL == '}') {
							$postpwd = substr($poststatus, 0, -1);
							$data_array['post_status'] = 'publish';
							$data_array['post_password'] = $postpwd;
						} else {
							$data_array['post_status'] = 'publish';
							$data_array['post_password'] = $poststatus;
						}
					} else {
						$data_array['post_status'] = 'publish';
					}
				}
				if ($data_array['post_status'] == 'scheduled') {
					$data_array['post_status'] = 'future';
				}
				if ($data_array['post_status'] == 'sticky') {
					$data_array['post_status'] = 'publish';
					$sticky = true;

				}

			} else {
				$data_array['post_status'] = 'publish';
			}
		}
		return $data_array;
	}

	public function import_post_types($import_type, $importAs = null)
	{
		$import_type = trim($import_type);

		$module = array('Posts' => 'post', 'Pages' => 'page', 'Users' => 'user', 'Comments' => 'comments', 'Taxonomies' => $importAs, 'CustomerReviews' => 'wpcr3_review', 'Categories' => 'categories', 'Tags' => 'tags', 'WooCommerce' => 'product', 'WPeCommerce' => 'wpsc-product', 'WPeCommerceCoupons' => 'wpsc-product', 'WooCommerceVariations' => 'product', 'WooCommerceOrders' => 'product', 'WooCommerceCoupons' => 'product', 'WooCommerceRefunds' => 'product', 'CustomPosts' => $importAs, 'WooCommerceReviews' => 'reviews', 'JetReviews' => 'jetreviews', 'GFEntries' => 'gfentries', 'SURECART_PRODUCTS' => 'sc_product', 'SURECART_ORDERS' => 'sc_order', 'SURECART_CUSTOMERS' => 'sc_customer', 'SURECART_SUBSCRIPTIONS' => 'sc_subscription', 'SURECART_COUPONS' => 'sc_coupon');
		foreach (get_taxonomies() as $key => $taxonomy) {
			$module[$taxonomy] = $taxonomy;
		}
		if (array_key_exists($import_type, $module)) {
			return $module[$import_type];
		} else {
			return $import_type;
		}
	}

	/**
	 * Convert CSV specs HTML (<ul><li><strong>Label:</strong> Value</li>) to plain lines for cg_accordion.
	 *
	 * @param string $content Inner accordion body.
	 * @return string
	 */
	public function format_specs_html_to_plain_lines( $content ) {
		$content = html_entity_decode( (string) $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$content = trim( $content );
		if ( $content === '' ) {
			return '';
		}
		if ( stripos( $content, '<li' ) !== false ) {
			$lines = array();
			if ( preg_match_all( '/<li[^>]*>(.*?)<\/li>/is', $content, $matches ) ) {
				foreach ( $matches[1] as $li ) {
					$li = preg_replace( '/<strong[^>]*>(.*?)<\/strong>/is', '$1', $li );
					$li = wp_strip_all_tags( str_replace( array( '<br />', '<br/>', '<br>' ), "\n", $li ) );
					$li = trim( preg_replace( '/[ \t]+/u', ' ', $li ) );
					$li = trim( preg_replace( "/\n+/u", "\n", $li ) );
					if ( $li !== '' ) {
						$lines[] = $li;
					}
				}
			}
			if ( ! empty( $lines ) ) {
				return implode( "\n", $lines );
			}
		}
		$content = wp_strip_all_tags( $content );
		$content = preg_replace( "/\r\n?|\n/", "\n", $content );
		return trim( $content );
	}

	/**
	 * Normalize WooCommerce short description built from Header Manipulation accordions.
	 * Specs block: plain "Label: value" lines (not <ul><li> HTML). Removes empty accordion wrappers.
	 *
	 * @param string $excerpt post_excerpt value after placeholder replacement.
	 * @return string
	 */
	public function normalize_product_short_description( $excerpt ) {
		if ( ! is_string( $excerpt ) || $excerpt === '' ) {
			return $excerpt;
		}
		$excerpt = html_entity_decode( $excerpt, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		$self    = $this;
		$excerpt = preg_replace_callback(
			'/\[cg_accordion\s+title=(["\'])Specificaties\1[^\]]*\](.*?)\[\/cg_accordion\]/is',
			function ( $m ) use ( $self ) {
				$inner = $self->format_specs_html_to_plain_lines( $m[2] );
				if ( $inner === '' ) {
					return '';
				}
				return '[cg_accordion title="Specificaties"]' . "\n\n" . $inner . "\n\n[/cg_accordion]";
			},
			$excerpt
		);

		$excerpt = preg_replace( '/\[cg_accordion[^\]]*\]\s*\[\/cg_accordion\]/is', '', $excerpt );
		$excerpt = trim( preg_replace( "/\n{3,}/", "\n\n", $excerpt ) );
		return $excerpt;
	}

	/**
	 * UI stores "Header Manipulation" on the base key; the real formula may live under field->cus1
	 * (first manipulation textarea) or field->cus2 (second / snippet). Only ->cus2 was merged
	 * historically, so formulas saved only in ->cus1 stayed as the literal "Header Manipulation"
	 * and were written to posts/meta unchanged.
	 *
	 * @param array $map Flat field map for one section (e.g. CORE or ECOMMETA). Modified by reference.
	 */
	/**
	 * True when a cus2 snippet is a PHP function body to load into customFunction.php,
	 * not a bracket formula to evaluate per row.
	 *
	 * @param mixed $value Mapping cell value.
	 * @return bool
	 */
	public function is_custom_function_definition_snippet( $value ) {
		return (bool) preg_match(
			'/^\s*function\s+[A-Za-z_][A-Za-z0-9_]*\s*\(/',
			trim( (string) $value )
		);
	}

	/**
	 * Quote a resolved CSV cell for safe insertion into evalPhp() expressions.
	 *
	 * @param mixed $value Scalar cell value.
	 * @return string
	 */
	public function quote_value_for_php_eval( $value ) {
		if ( is_bool( $value ) || is_null( $value ) || is_int( $value ) || is_float( $value ) ) {
			return var_export( $value, true );
		}
		return var_export( (string) $value, true );
	}

	/**
	 * Replace {headers} inside the first [...] pair with PHP-literal values for evalPhp().
	 *
	 * @param string              $csv_value    Full mapping formula.
	 * @param array<int, string>  $header_array CSV headers.
	 * @param array<int, string>  $value_array  CSV row values.
	 * @return string|null Inner bracket expression, or null when not a bracket formula.
	 */
	public function build_bracket_expression_for_eval( $csv_value, $header_array, $value_array ) {
		$pattern1 = '/{([^}]*)}/';
		$pattern2 = '/\[([^\]]*)\]/';
		if ( ! preg_match_all( $pattern1, $csv_value, $matches, PREG_PATTERN_ORDER ) ) {
			return null;
		}
		if ( ! preg_match_all( $pattern2, $csv_value, $matches2 ) ) {
			return null;
		}
		$matched_element = $matches2[1][0];
		$missing_headers = array();
		$resolved_map    = array();
		foreach ( $matches[1] as $hdr_token ) {
			$idx       = $this->find_header_index( $hdr_token, $header_array );
			$get_value = $this->replace_header_with_values( $hdr_token, $header_array, $value_array );
			// Detect legacy bug: unresolved placeholder returned the token name itself.
			if ( false === $idx || $this->headers_match( (string) $get_value, $hdr_token ) ) {
				$missing_headers[] = $hdr_token;
				if ( $this->headers_match( (string) $get_value, $hdr_token ) ) {
					$get_value = '';
				}
			}
			$resolved_map[ $hdr_token ] = $get_value;
			$matched_element = str_replace(
				'{' . $hdr_token . '}',
				$this->quote_value_for_php_eval( $get_value ),
				$matched_element
			);
		}
		return $matched_element;
	}

	/**
	 * Pick the row-evaluation formula for a Header Manipulation field.
	 * cus1 holds bracket calls; cus2 often holds the PHP function definition only.
	 *
	 * @param array  $map      Field map (modified by reference).
	 * @param string $base_key Base field key.
	 * @return string
	 */
	private function pick_header_manipulation_formula( array &$map, $base_key ) {
		$candidate_keys = array(
			$base_key . '->cus1',
			$base_key . '->static',
			$base_key . '->math',
			$base_key . '->openAI',
			$base_key . '->code',
			$base_key . '->cus2',
		);
		$candidates = array();
		foreach ( $candidate_keys as $map_key ) {
			if ( ! isset( $map[ $map_key ] ) || trim( (string) $map[ $map_key ] ) === '' ) {
				continue;
			}
			$val = (string) $map[ $map_key ];
			if ( substr( $map_key, -6 ) === '->cus2' && $this->is_custom_function_definition_snippet( $val ) ) {
				continue;
			}
			if ( substr( $map_key, -6 ) === '->code' ) {
				if ( ! preg_match( '/\[([^\]]*)\]/', $val ) && ! preg_match( '/\{([^}]*)\}/', $val ) ) {
					continue;
				}
			}
			$candidates[] = array(
				'key'   => $map_key,
				'value' => $map[ $map_key ],
			);
		}
		foreach ( $candidates as $candidate ) {
			if ( preg_match( '/\[([^\]]*)\]/', (string) $candidate['value'] ) ) {
				unset( $map[ $candidate['key'] ] );
				return (string) $candidate['value'];
			}
		}
		if ( ! empty( $candidates ) ) {
			unset( $map[ $candidates[0]['key'] ] );
			return (string) $candidates[0]['value'];
		}
		return '';
	}

	public function merge_header_manipulation_into_base( array &$map ) {
		$base_keys = array();
		foreach ( array_keys( $map ) as $key ) {
			if ( strpos( $key, '->' ) !== false ) {
				continue;
			}
			if ( ! array_key_exists( $key, $map ) ) {
				continue;
			}
			$base_keys[] = $key;
		}
		foreach ( $base_keys as $base_key ) {
			if ( is_array( $map[ $base_key ] ) ) {
				continue;
			}
			if ( trim( (string) $map[ $base_key ] ) !== 'Header Manipulation' ) {
				continue;
			}
			$formula = $this->pick_header_manipulation_formula( $map, $base_key );
			if ( $formula !== '' ) {
				$map[ $base_key ] = $formula;
			} else {
				// No formula sibling — drop label so import never writes literal "Header Manipulation".
				unset( $map[ $base_key ] );
			}
		}
	}

	/**
	 * @deprecated Use merge_header_manipulation_into_base(); kept for callers.
	 * @param array $map Modified by reference.
	 */
	public function merge_cus2_header_manipulation_into_base( array &$map ) {
		$this->merge_header_manipulation_into_base( $map );
	}

	public function get_header_values( $map, $header_array, $value_array, $hash_key = null, $line_number = 0 ) {
        MediaHandling::$global_header_array = $header_array;
        MediaHandling::$global_value_array = $value_array;
		$post_values = [];
		global $wpdb;
		$file_extension = '';
		if ( is_array( $map ) ) {
			// Resolve file extension once per call (was queried for every mapped field).
			if ( ! empty( $hash_key ) ) {
				$file_table_name = $wpdb->prefix . 'smackcsv_file_events';
				$file_name       = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT file_name FROM {$file_table_name} WHERE hash_key = %s LIMIT 1",
						$hash_key
					)
				);
				if ( ! empty( $file_name ) ) {
					$file_extension = pathinfo( $file_name, PATHINFO_EXTENSION );
				}
			}
			$this->merge_header_manipulation_into_base( $map );
			$trim_content = array(
				'->static' => '',
				'->math' => '',
				'->cus1' => '',
				'->num' => '',
				'->code' => ''
			);

			$code_overrides = [];
			foreach ($map as $header_keys => $value) {
				if (strpos($header_keys, '->code') !== false) {
					if (!empty($value)) {
						$code_overrides[str_replace('->code', '', $header_keys)] = $this->execute_custom_code($value, $header_array, $value_array);
					}
					unset($map[$header_keys]);
				} elseif (strpos($header_keys, '->cus2') !== false) {
					if (!empty($value)) {
						$this->write_to_customfile($value, $header_array, $value_array);
						unset($map[$header_keys]);
					}
				} else {
					$header_trim = strtr($header_keys, $trim_content);
					if ($header_trim != $header_keys) {
						unset($map[$header_keys]);
					}
					$new_val  = trim( (string) $value );
					$existing = isset( $map[ $header_trim ] ) ? trim( (string) $map[ $header_trim ] ) : '';
					// Do not let the dropdown label overwrite a formula already promoted to the base key.
					if ( $new_val === 'Header Manipulation' && $existing !== '' && $existing !== 'Header Manipulation' ) {
						continue;
					}
					$map[$header_trim] = $value;
				}
			}

			foreach ($map as $key => $value) {
				if (is_array($map[$key])) {
					continue;
				}
				if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter' )
					&& \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::is_extra_gallery_column_key( $key ) ) {
					continue;
				}
				$csv_value = trim($map[$key]);
				if ( $csv_value === 'Header Manipulation' ) {
					continue;
				}
				if (isset($csv_value) && $csv_value !== '') {
					//$pattern = "/({([a-z A-Z 0-9 | , _ -]+)(.*?)(}))/";
					$pattern1 = '/{([^}]*)}/';
					$pattern2 = '/\[([^\]]*)\]/';
					if (preg_match_all($pattern1, $csv_value, $matches, PREG_PATTERN_ORDER) && $file_extension != 'xml' && strpos($key, '->serialize') === false) {

						//check for inbuilt or custom function call -> enclosed in []
						if (preg_match_all($pattern2, $csv_value, $matches2)) {
							// Mixed {placeholders} and [...]: evaluate PHP inside the first bracket pair after
							// replacing braces with literal values (same as CoreFieldsImport / get_meta_values).
							$matched_element = $this->build_bracket_expression_for_eval( $csv_value, $header_array, $value_array );
							if ( $matched_element === null ) {
								$csv_element = null;
							} elseif ( $this->is_plausible_php_bracket_expression( $matched_element ) ) {
								$csv_element = $this->evalPhp( $matched_element );
								if ( $csv_element === null ) {
									$csv_element = null;
								}
							} else {
								$csv_element = null;
							}
							// Shortcodes (first [...] is not PHP) or failed eval: still replace {Headers} in the full template.
							if ( $csv_element === null ) {
$csv_element = $csv_value;
								foreach ( $matches[1] as $value ) {
									$get_key = $this->find_header_index( $value, $header_array );
									if ( false !== $get_key && isset( $value_array[ $get_key ] ) ) {
										$csv_value_element = $value_array[ $get_key ];
										$value            = '{' . $value . '}';
										$csv_element      = str_replace( $value, $csv_value_element, $csv_element );
									}
								}
								$math = 'MATH';
								if ( strpos( $csv_element, $math ) !== false ) {
									$equation    = str_replace( 'MATH', '', $csv_element );
									$csv_element = $this->evalMath( $equation );
								}
							}
						} else {
							$csv_element = $csv_value;

							//foreach($matches[2] as $value){
							foreach ($matches[1] as $value) {
								$get_key = $this->find_header_index( $value, $header_array );
								if ( false !== $get_key && isset( $value_array[ $get_key ] ) ) {
									$csv_value_element = $value_array[ $get_key ];
									$value = '{' . $value . '}';
									$csv_element = str_replace($value, $csv_value_element, $csv_element);
								}
							}
							$math = 'MATH';
							if (strpos($csv_element, $math) !== false) {

								$equation = str_replace('MATH', '', $csv_element);
								$csv_element = $this->evalMath($equation);
							}
						}
						$wp_element = trim($key);
						if ( $this->is_woocommerce_price_field( $wp_element ) && ( is_string( $csv_element ) || is_numeric( $csv_element ) ) ) {
							$csv_element = $this->normalize_woocommerce_price_value( $csv_element );
						}
						// Keep numeric zero / "0,00" / "0.00" — empty() would drop them.
						if ( ( $csv_element !== null && $csv_element !== '' ) && !empty($wp_element)) {
							$post_values[$wp_element] = $csv_element;
						}
					}

					// for custom function without headers in it
					elseif (preg_match_all($pattern2, $csv_value, $matches2) && $file_extension != 'xml') {
						$matched_element = $matches2[1][0];
						$wp_element = trim($key);
						if ( $this->is_plausible_php_bracket_expression( $matched_element ) ) {
							$csv_element1 = $this->evalPhp( $matched_element );
							if ( $csv_element1 === null ) {
								$csv_element1 = $csv_value;
							}
						} else {
							$csv_element1 = $csv_value;
						}
						if ( $this->is_woocommerce_price_field( $wp_element ) && ( is_string( $csv_element1 ) || is_numeric( $csv_element1 ) ) ) {
							$csv_element1 = $this->normalize_woocommerce_price_value( $csv_element1 );
						}
$post_values[$wp_element] = $csv_element1;
					} else {
						if ( $csv_value === 'Header Manipulation' ) {
							continue;
						}
						$wp_element = trim( $key );
						$resolved   = $this->resolve_mapped_column_value( $csv_value, $wp_element, $header_array, $value_array );
						if ( null !== $resolved && '' !== $resolved && '' !== $wp_element ) {
							$post_values[ $wp_element ] = $resolved;
						}
					}
				}
			}

			// Apply the custom code values directly to post_values, bypassing the regex formula parser above
			foreach ($code_overrides as $key => $val) {
				if ( ImportValueResolver::is_blank( $val ) ) {
					continue;
				}
				$post_values[$key] = $val;
			}
			if ( isset( $post_values['post_excerpt'] ) && is_string( $post_values['post_excerpt'] ) ) {
				$post_values['post_excerpt'] = $this->normalize_product_short_description( $post_values['post_excerpt'] );
			}
			$post_values = $this->finalize_product_image_gallery_value( $map, $header_array, $value_array, $post_values );
		}

		return $post_values;
	}

	public function get_meta_values($map, $header_array, $value_array)
	{

		$post_values = [];
		if (is_array($map)) {
			$this->merge_header_manipulation_into_base( $map );
			$trim_content = array(
				'->static' => '',
				'->math' => '',
				'->cus1' => '',
				'->num' => '',
				'->code' => ''
			);

			$code_overrides = [];
			foreach ($map as $header_keys => $value) {
				if (strpos($header_keys, '->code') !== false) {
					if (!empty($value)) {
						$code_overrides[str_replace('->code', '', $header_keys)] = $this->execute_custom_code($value, $header_array, $value_array);
					}
					unset($map[$header_keys]);
				} elseif (strpos($header_keys, '->cus2') !== false) {
					if (!empty($value)) {
						$this->write_to_customfile($value, $header_array, $value_array);
						unset($map[$header_keys]);
					}
				} else {
					$header_trim = strtr($header_keys, $trim_content);
					if ($header_trim != $header_keys) {
						unset($map[$header_keys]);
					}
					$new_val  = trim( (string) $value );
					$existing = isset( $map[ $header_trim ] ) ? trim( (string) $map[ $header_trim ] ) : '';
					if ( $new_val === 'Header Manipulation' && $existing !== '' && $existing !== 'Header Manipulation' ) {
						continue;
					}
					$map[$header_trim] = $value;
				}
			}

			foreach ($map as $key => $value) {
				$csv_value = trim($map[$key]);
				if ( $csv_value === 'Header Manipulation' ) {
					continue;
				}
				$value_assoc = $this->combine_header_row_values( $header_array, $value_array );
				if (!empty($csv_value)) {
					//$pattern = "/({([a-z A-Z 0-9 | , _ -]+)(.*?)(}))/";
					$pattern1 = '/{([^}]*)}/';
					$pattern2 = '/\[([^\]]*)\]/';

					if (preg_match_all($pattern1, $csv_value, $matches, PREG_PATTERN_ORDER)) {
						//check for inbuilt or custom function call -> enclosed in []
						if (preg_match_all($pattern2, $csv_value, $matches2)) {
							$matched_element = $this->build_bracket_expression_for_eval( $csv_value, $header_array, $value_array );

							$bracket_is_php = ( $matched_element !== null ) && $this->is_plausible_php_bracket_expression( $matched_element );
							$csv_element     = null;
							if ( $bracket_is_php ) {
								$csv_element = $this->evalPhp( $matched_element );
							}
							if ( ! $bracket_is_php || $csv_element === null ) {
								$csv_element = $csv_value;
								foreach ( $matches[1] as $value ) {
									$get_key = array_search( $value, $header_array );
									if ( isset( $value_array[ $get_key ] ) ) {
										$csv_value_element = $value_array[ $get_key ];
										$value             = '{' . $value . '}';
										$csv_element       = str_replace( $value, $csv_value_element, $csv_element );
									}
								}
								$math = 'MATH';
								if ( strpos( $csv_element, $math ) !== false ) {
									$equation    = str_replace( 'MATH', '', $csv_element );
									$csv_element = $this->evalMath( $equation );
								}
							}
							$wp_element = trim($key);
							if ( $this->is_woocommerce_price_field( $wp_element ) && ( is_string( $csv_element ) || is_numeric( $csv_element ) ) ) {
								$csv_element = $this->normalize_woocommerce_price_value( $csv_element );
							}
							if ( ( $csv_element !== null && $csv_element !== '' ) && !empty($wp_element)) {
								$post_values[$wp_element] = $csv_element;
							}
						} else {
							$csv_element = $csv_value;

							//foreach($matches[2] as $value){
							foreach ($matches[1] as $value) {
								$get_key = array_search($value, $header_array);
								if (isset($value_array[$get_key])) {
									$csv_value_element = $value_array[$get_key];

									$value = '{' . $value . '}';
									$csv_element = str_replace($value, $csv_value_element, $csv_element);
								}
							}
							$math = 'MATH';
							if (strpos($csv_element, $math) !== false) {
								$equation = str_replace('MATH', '', $csv_element);
								$csv_element = $this->evalMath($equation);
							}

							$wp_element = trim($key);
							if (!empty($csv_element) && !empty($wp_element)) {
								$csv_ele1 = explode('|', $csv_element);
								$post_values[$wp_element] = $csv_ele1;
							}
						}
					} elseif (preg_match_all($pattern2, $csv_value, $matches2)) {

						$matched_element = $matches2[1][0];
						$wp_element = trim($key);
						$csv_element1 = '';

						if ($matched_element === 'fields' && strpos($wp_element, '_wpbdp[fields][') === 0) {
							if (isset($value_assoc[$wp_element])) {
								$csv_element1 = $value_assoc[$wp_element];
							}

							if (!empty($csv_element1)) {
								$csv_element1 = explode('|', $csv_element1);
							}
						} else {
							$dangerous_tokens = '/\b(exec|system|passthru|shell_exec|proc_open|popen|`|curl_exec|curl_multi_exec|file_put_contents|fopen|fread|fwrite|fgets|eval|base64_decode)\b/i';
							if (preg_match($dangerous_tokens, $matched_element)) {
								$csv_element1 = $matched_element;
							} else {
								$looks_like_expr = preg_match('/[A-Za-z_][A-Za-z0-9_]*\s*\(|->|::|\$[A-Za-z_]/', $matched_element);
								if ($looks_like_expr) {
									$csv_element1 = $this->evalPhp( $matched_element );
								} else {
									$csv_element1 = $matched_element;
								}
							}
						}

						if (!empty($csv_element1) && !empty($wp_element)) {
							$post_values[$wp_element] = $csv_element1;
						}

					} else {
						$wp_element = trim( $key );
						$resolved   = $this->resolve_mapped_column_value( $csv_value, $wp_element, $header_array, $value_array );
						if ( null !== $resolved && '' !== $resolved && '' !== $wp_element ) {
							if ( false !== strpos( $resolved, '|' ) ) {
								$post_values[ $wp_element ] = explode( '|', $resolved );
							} else {
								$post_values[ $wp_element ] = $resolved;
							}
						}
					}
				}
			}

			// Apply the custom code values directly to post_values, bypassing the regex formula parser above
			foreach ($code_overrides as $key => $val) {
				if ( ImportValueResolver::is_blank( $val ) ) {
					continue;
				}
				$post_values[$key] = $val;
			}
}

		return $post_values;
	}

	public function evalMath($equation)
	{
		load_vendor_autoload();
		$result = 0;

		// sanitize imput
		$equation = preg_replace("/[^0-9+\-.*\/()%]/", "", $equation);

		// convert percentages to decimal
		$equation = preg_replace("/([+-])([0-9]{1})(%)/", "*(1\$1.0\$2)", $equation);
		$equation = preg_replace("/([+-])([0-9]+)(%)/", "*(1\$1.\$2)", $equation);
		//$equation = preg_replace("/([0-9]+)(%)/",".\$1",$equation);


		try {
			$executor = new MathExecutor();

			return $executor->execute($equation);
		} catch (Exception $e) {
			$return("Unable to calculate equation");
		}

	}

	public function get_post_ids($post_id, $eventKey, $templatekey = null)
	{
		$smack_instance = UltimatePro::getInstance();
		$recordId = array($post_id);
		if ($templatekey != null) {
			$upload_dir = $smack_instance->create_upload_dir('CLI');
			$eventInfoFile = $upload_dir . $eventKey . '/' . $templatekey . '/' . $templatekey . '.txt';
		} else {
			$upload_dir = $smack_instance->create_upload_dir();
			$eventInfoFile = $upload_dir . $eventKey . '/' . $eventKey . '.txt';
		}
		if (file_exists($eventInfoFile)) {
			$handle = fopen($eventInfoFile, 'r');
			if ( $handle ) {
				$contents = json_decode( fread( $handle, filesize( $eventInfoFile ) ) );
				fclose( $handle );
			}
		}
		$dir = dirname( $eventInfoFile );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$fp = fopen( $eventInfoFile, 'w+' );
		if ( ! $fp ) {
			return;
		}
		if (!empty($contents) && $contents != null) {
			$contents = array_merge($contents, $recordId);
			$contents = json_encode($contents);
		} else {
			$contents = json_encode($recordId);
		}
		fwrite($fp, $contents);
		fclose($fp);
	}

	public function formatSizeUnits($bytes)
	{
		if ($bytes >= 1073741824) {
			$bytes = number_format($bytes / 1073741824, 2) . ' GB';
		} elseif ($bytes >= 1048576) {
			$bytes = number_format($bytes / 1048576, 2) . ' MB';
		} elseif ($bytes >= 1024) {
			$bytes = number_format($bytes / 1024, 2) . ' KB';
		} elseif ($bytes > 1) {
			$bytes = $bytes . ' bytes';
		} elseif ($bytes == 1) {
			$bytes = $bytes . ' byte';
		} else {
			$bytes = '0 bytes';
		}

		return $bytes;
	}

	public function update_count($unikey_value, $unikey)
	{
		$response = [];
		global $wpdb;

		$log_table_name = $wpdb->prefix . "import_detail_log";
		$allowed_keys   = array( 'hash_key', 'templatekey' );
		if ( ! in_array( $unikey, $allowed_keys, true ) ) {
			return array(
				'skipped' => 0,
				'created' => 0,
				'updated' => 0,
				'failed'  => 0,
			);
		}
		$get_data = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT skipped, created, updated, failed FROM {$log_table_name} WHERE {$unikey} = %s ORDER BY id DESC LIMIT 1",
				$unikey_value
			)
		);

		$skipped = isset($get_data[0]->skipped) ? $get_data[0]->skipped : 0;
		$response['skipped'] = $skipped + 1;
		$created = isset($get_data[0]->created) ? $get_data[0]->created : 0;
		$response['created'] = $created + 1;
		$updated = isset($get_data[0]->updated) ? $get_data[0]->updated : 0;
		$response['updated'] = $updated + 1;
		$failed = isset($get_data[0]->failed) ? $get_data[0]->failed : 0;
		$response['failed'] = $failed + 1;

		return $response;
	}

	public function validate_datefield($date, $field, $dateformat, $line_number)
	{
		if (empty($date)) {
			return $date;
		}
		$core_instance = CoreFieldsImport::getInstance();
		$index = "</br><b>Info about " . $field . "</b>";
		//Validate the date
		if (strtotime($date)) {
			$date = date($dateformat, strtotime($date));
		} else {
			//check the date format as mm-dd-yyyy (valid)
			$date = str_replace(array('.', '-'), '/', $date);
			if (!strtotime($date)) {
				//Invalid date
				//check the date format as 18/05/2022 (valid)
				$date = str_replace('/', '-', $date);
				if (strtotime($date)) {
					//valid
					$date = date($dateformat, strtotime($date));
				} else {
					//Invalid							
					$core_instance->detailed_log[$line_number][$index] = __( 'Date format provided is wrong. Correct date format is Y-m-d', 'wp-ultimate-csv-importer' );
					$date = '';
				}
			} else {
				//Valid date
				$date = date($dateformat, strtotime($date));
			}
		}
		return $date;

	}

	public function write_to_customfile($csv_value, $header_array = null, $value_array = null)
	{
		$csv_value = trim( (string) $csv_value );
		if ( $csv_value === '' ) {
			return;
		}

		// Only complete PHP function definitions belong in customFunction.php.
		// Bracket formulas, static templates, and bare expressions must not be appended.
		if ( ! $this->is_custom_function_definition_snippet( $csv_value ) ) {
			return;
		}

		$upload              = wp_upload_dir();
		$customfn_file_path  = $upload['basedir'] . '/smack_uci_uploads/customFunction.php';
		$customfn_dir        = dirname( $customfn_file_path );
		if ( ! is_dir( $customfn_dir ) ) {
			wp_mkdir_p( $customfn_dir );
		}

		if ( ! file_exists( $customfn_file_path ) ) {
			file_put_contents( $customfn_file_path, "<?php\n" );
			@chmod( $customfn_file_path, 0644 );
		}

		$get_custom_content = (string) file_get_contents( $customfn_file_path );
		$function_name      = '';
		if ( preg_match( '/function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/', $csv_value, $fn_match ) ) {
			$function_name = $fn_match[1];
		}
		if ( $function_name !== '' && preg_match( '/function\s+' . preg_quote( $function_name, '/' ) . '\s*\(/', $get_custom_content ) ) {
			$this->load_custom_function_definitions_file();
			return;
		}

		file_put_contents( $customfn_file_path, $get_custom_content . "\n" . $csv_value . "\n", LOCK_EX );
		@chmod( $customfn_file_path, 0644 );
		if ( $function_name !== '' && ! function_exists( $function_name ) ) {
			$this->load_custom_function_definitions_file();
		}
	}

	/**
	 * Strip UTF-8 BOM from CSV headers / mapping tokens (common on first column).
	 *
	 * @param string $text Raw string.
	 * @return string
	 */
	public function strip_utf8_bom( $text ) {
		$text = (string) $text;
		if ( '' !== $text && 0 === strpos( $text, "\xEF\xBB\xBF" ) ) {
			$text = substr( $text, 3 );
		}
		// Unicode BOM character U+FEFF sometimes stored literally.
		$text = preg_replace( '/^\x{FEFF}/u', '', $text );
		return trim( $text );
	}

	/**
	 * Normalize CSV header row (trim + strip BOM on every column).
	 *
	 * @param array<int, string> $headers Raw headers.
	 * @return array<int, string>
	 */
	public function normalize_header_array( $headers ) {
		if ( ! is_array( $headers ) ) {
			return array();
		}
		$out = array();
		foreach ( $headers as $header ) {
			$out[] = $this->strip_utf8_bom( $header );
		}
		return $out;
	}

	/**
	 * Build associative row from header/value arrays; tolerates count mismatch (PHP 8+).
	 *
	 * @param array $header_array Raw CSV headers.
	 * @param array $value_array  Raw CSV values for one row.
	 * @return array<string, mixed>
	 */
	public function combine_header_row_values( $header_array, $value_array ) {
		if ( ! is_array( $header_array ) || ! is_array( $value_array ) || empty( $header_array ) ) {
			return array();
		}
		$headers = $this->normalize_header_array( array_values( $header_array ) );
		$values  = array_values( $value_array );
		$h_count = count( $headers );
		if ( $h_count === 0 ) {
			return array();
		}
		$v_count = count( $values );
		if ( $v_count < $h_count ) {
			$values = array_pad( $values, $h_count, '' );
		} elseif ( $v_count > $h_count ) {
			$values = array_slice( $values, 0, $h_count );
		}
		return array_combine( $headers, $values );
	}

	/**
	 * Resolve source column index (case-insensitive, trimmed, BOM-safe).
	 *
	 * @param string              $csv_header   Mapped source column name.
	 * @param array<int,string>   $header_array Import headers.
	 * @return int|false
	 */
	public function find_header_index( $csv_header, $header_array ) {
		$csv_header = $this->strip_utf8_bom( trim( (string) $csv_header ) );
		if ( $csv_header === '' || ! is_array( $header_array ) ) {
			return false;
		}

		$header_array = array_values( $header_array );

		// Exact / case-insensitive / BOM-safe.
		foreach ( $header_array as $idx => $label ) {
			if ( $csv_header === $this->strip_utf8_bom( (string) $label ) ) {
				return $idx;
			}
		}
		$lower = strtolower( $csv_header );
		foreach ( $header_array as $idx => $label ) {
			if ( strtolower( $this->strip_utf8_bom( (string) $label ) ) === $lower ) {
				return $idx;
			}
		}

		// Normalized (spaces/underscores/hyphens).
		$norm_token = $this->normalize_header_token( $csv_header );
		foreach ( $header_array as $idx => $label ) {
			if ( $this->normalize_header_token( (string) $label ) === $norm_token ) {
				return $idx;
			}
		}

		// Alias list (AWIN search_price ↔ price, etc.).
		foreach ( $this->get_placeholder_header_aliases( $csv_header ) as $alias ) {
			$alias_norm = $this->normalize_header_token( $alias );
			if ( $alias_norm === $norm_token ) {
				continue;
			}
			foreach ( $header_array as $idx => $label ) {
				if ( $this->normalize_header_token( (string) $label ) === $alias_norm ) {
					return $idx;
				}
			}
		}

		return false;
	}

	/**
	 * True when a mapping cell holds a WP field key/label instead of a CSV column name.
	 *
	 * @param string $csv_value  Value from mapping template.
	 * @param string $wp_element Target field key (e.g. post_title).
	 * @return bool
	 */
	public function is_internal_field_token( $csv_value, $wp_element, $header_array = null ) {
		$csv_value  = strtolower( trim( $this->strip_utf8_bom( (string) $csv_value ) ) );
		$wp_element = strtolower( trim( (string) $wp_element ) );
		if ( '' === $csv_value || '--select--' === $csv_value || 'header manipulation' === $csv_value ) {
			return true;
		}
		// Mapping value matches a real CSV column (e.g. post_tag column mapped to post_tag field).
		if ( is_array( $header_array ) && false !== $this->find_header_index( $csv_value, $header_array ) ) {
			return false;
		}
		if ( '' !== $wp_element && $csv_value === $wp_element ) {
			return true;
		}
		if ( '' !== $wp_element && $csv_value === str_replace( '_', ' ', $wp_element ) ) {
			return true;
		}
		static $ui_labels = array(
			'title'           => 'post_title',
			'post title'      => 'post_title',
			'content'         => 'post_content',
			'post content'    => 'post_content',
			'excerpt'         => 'post_excerpt',
			'post excerpt'    => 'post_excerpt',
			'slug'            => 'post_name',
			'post slug'       => 'post_name',
			'featured image'  => 'featured_image',
		);
		if ( '' !== $wp_element && isset( $ui_labels[ $csv_value ] ) && $ui_labels[ $csv_value ] === $wp_element ) {
			return true;
		}
		return false;
	}

	/**
	 * Common CSV header aliases when mapping was saved as the field key by mistake.
	 *
	 * @param string $wp_element Field key.
	 * @return array<int, string>
	 */
	public function get_field_column_aliases( $wp_element ) {
		$map = array(
			'post_title'   => array( 'title', 'post title', 'name', 'product_title', 'product title', 'product_name', 'product name', 'headline', 'subject' ),
			'post_content' => array( 'content', 'post content', 'body', 'description', 'post body', 'html', 'text' ),
			'post_excerpt' => array( 'excerpt', 'post excerpt', 'short_description', 'short description', 'summary' ),
			'post_name'    => array( 'slug', 'post slug', 'permalink', 'url', 'post_name' ),
		);
		return isset( $map[ $wp_element ] ) ? $map[ $wp_element ] : array();
	}

	/**
	 * Collect ordered Product Gallery mapping keys from a flat map section.
	 *
	 * @param array<string, mixed> $map Flat mapping section (e.g. ECOMMETA).
	 * @return array<string, string> map_key => csv column / formula.
	 */
	public function collect_product_gallery_map_entries( array $map ) {
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter' ) ) {
			return array();
		}

		$entries = array();
		foreach ( $map as $map_key => $csv_value ) {
			if ( is_array( $csv_value ) ) {
				continue;
			}
			$map_key = (string) $map_key;
			if ( 'product_image_gallery' === $map_key || \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::is_extra_gallery_column_key( $map_key ) ) {
				$trimmed = trim( (string) $csv_value );
				if ( '' !== $trimmed && 'Header Manipulation' !== $trimmed ) {
					$entries[ $map_key ] = $trimmed;
				}
			}
		}
		if ( empty( $entries ) ) {
			return array();
		}
		uksort(
			$entries,
			function ( $a, $b ) {
				$order_a = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::gallery_column_sort_order( $a );
				$order_b = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::gallery_column_sort_order( $b );
				if ( $order_a === $order_b ) {
					return 0;
				}
				return ( $order_a < $order_b ) ? -1 : 1;
			}
		);
		return $entries;
	}

	/**
	 * Merge multiple mapped gallery CSV columns into one pipe-separated product_image_gallery value.
	 *
	 * @param array<string, mixed> $map          Flat mapping section.
	 * @param array<int, string>   $header_array CSV headers.
	 * @param array<int, string>   $value_array  CSV row values.
	 * @param array<string, mixed> $post_values  Row values built so far.
	 * @return array<string, mixed>
	 */
	public function finalize_product_image_gallery_value( array $map, array $header_array, array $value_array, array $post_values ) {
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter' ) ) {
			return $post_values;
		}

		$gallery_entries = $this->collect_product_gallery_map_entries( $map );
		if ( empty( $gallery_entries ) ) {
			return $post_values;
		}

		$sources = array();
		foreach ( $gallery_entries as $map_key => $csv_mapping ) {
			$resolved = $this->resolve_gallery_mapping_value( $map_key, $csv_mapping, $map, $header_array, $value_array );
			if ( null !== $resolved && '' !== $resolved ) {
				$sources[] = $resolved;
			}
		}

		$combined = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::combine_sources( $sources );
		if ( '' !== $combined ) {
			$post_values['product_image_gallery'] = $combined;
		} else {
			unset( $post_values['product_image_gallery'] );
		}

		foreach ( array_keys( $gallery_entries ) as $gallery_key ) {
			if ( \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::is_extra_gallery_column_key( $gallery_key ) ) {
				unset( $post_values[ $gallery_key ] );
			}
		}

		return $post_values;
	}

	/**
	 * Resolve one gallery mapping entry (direct column or header manipulation formula).
	 *
	 * @param string               $map_key      Gallery mapping key.
	 * @param string               $csv_mapping  Mapped CSV header or formula.
	 * @param array<string, mixed> $map          Full flat map (for manipulation keys).
	 * @param array<int, string>   $header_array CSV headers.
	 * @param array<int, string>   $value_array  CSV row values.
	 * @return string|null
	 */
	private function resolve_gallery_mapping_value( $map_key, $csv_mapping, array $map, array $header_array, array $value_array ) {
		$base_key = 'product_image_gallery';
		$trim_content = array(
			'->static' => '',
			'->math'   => '',
			'->cus1'   => '',
			'->num'    => '',
			'->code'   => '',
		);

		$manipulation_keys = array();
		foreach ( $map as $header_key => $manipulation_value ) {
			if ( ! is_string( $header_key ) ) {
				continue;
			}
			$trimmed_key = strtr( $header_key, $trim_content );
			if ( $trimmed_key === $base_key && $header_key !== $base_key && false !== strpos( $header_key, '->' ) ) {
				$manipulation_keys[ $header_key ] = $manipulation_value;
			}
		}

		if ( ! empty( $manipulation_keys ) && $map_key === $base_key ) {
			$temp_map = array_merge( array( $base_key => $csv_mapping ), $manipulation_keys );
			$temp_values = $this->get_header_values( $temp_map, $header_array, $value_array );
			if ( isset( $temp_values[ $base_key ] ) && '' !== trim( (string) $temp_values[ $base_key ] ) ) {
				return trim( (string) $temp_values[ $base_key ] );
			}
		}

		$resolved = $this->resolve_mapped_column_value( $csv_mapping, $base_key, $header_array, $value_array );
		return ( null !== $resolved && '' !== $resolved ) ? trim( (string) $resolved ) : null;
	}

	/**
	 * Resolve a mapped column to a row value; never returns a bare field key as post data.
	 *
	 * @param string              $csv_value    Mapping cell value.
	 * @param string              $wp_element   Target field key.
	 * @param array<int, string>  $header_array CSV headers.
	 * @param array<int, string>  $value_array  CSV row values.
	 * @return string|null Value to assign, or null to skip the field.
	 */
	public function resolve_mapped_column_value( $csv_value, $wp_element, $header_array, $value_array ) {
		$raw_mapped = (string) $csv_value;
		$csv_value  = $this->strip_utf8_bom( trim( $raw_mapped ) );
		$wp_element = trim( (string) $wp_element );
		$get_key    = $this->find_header_index( $csv_value, $header_array );
		// Field mapped to itself but mapping cell has BOM prefix on first CSV column.
		if ( false === $get_key && $csv_value === $wp_element ) {
			$get_key = $this->find_header_index( $wp_element, $header_array );
		}
		if ( false !== $get_key && isset( $value_array[ $get_key ] ) ) {
			$resolved = trim( (string) $value_array[ $get_key ] );
			if ( '' !== $resolved ) {
				return $resolved;
			}
			return null;
		}
		if ( $this->is_internal_field_token( $csv_value, $wp_element, $header_array ) ) {
			foreach ( $this->get_field_column_aliases( $wp_element ) as $alias ) {
				$idx = $this->find_header_index( $alias, $header_array );
				if ( false !== $idx && isset( $value_array[ $idx ] ) ) {
					$resolved = trim( (string) $value_array[ $idx ] );
					if ( '' !== $resolved ) {
						return $resolved;
					}
				}
			}
			return null;
		}
		return $csv_value;
	}

	/**
	 * Resolve a CSV header token to the cell value for the current row.
	 * Never returns the header name itself when lookup fails (that produced
	 * bereken_awin_100g('search_price', ...) → 0,00 on schedule imports).
	 *
	 * @param string             $csv_header   Placeholder token (e.g. search_price).
	 * @param array<int,string>  $header_array CSV headers.
	 * @param array              $value_array  CSV row (numeric or associative).
	 * @return string Cell value, or '' when not found.
	 */
	public function replace_header_with_values( $csv_header, $header_array, $value_array ) {
		$token = $this->strip_utf8_bom( trim( (string) $csv_header ) );
		if ( $token === '' || ! is_array( $header_array ) || ! is_array( $value_array ) ) {
			return '';
		}

		// Prefer numeric alignment (fgetcsv rows).
		$values_numeric = array_values( $value_array );
		$headers_numeric = array_values( $header_array );

		$get_key = $this->find_header_index( $token, $headers_numeric );
		if ( false !== $get_key && array_key_exists( $get_key, $values_numeric ) ) {
			return (string) $values_numeric[ $get_key ];
		}

		// Associative rows keyed by header label.
		if ( array_key_exists( $token, $value_array ) ) {
			return (string) $value_array[ $token ];
		}
		foreach ( $value_array as $k => $v ) {
			if ( ! is_string( $k ) && ! is_int( $k ) ) {
				continue;
			}
			if ( $this->headers_match( $token, (string) $k ) ) {
				return (string) $v;
			}
		}

		return '';
	}

	/**
	 * Loose header equality: BOM/case/space/underscore/hyphen insensitive.
	 *
	 * @param string $a Header a.
	 * @param string $b Header b.
	 * @return bool
	 */
	public function headers_match( $a, $b ) {
		return $this->normalize_header_token( $a ) === $this->normalize_header_token( $b );
	}

	/**
	 * @param string $header Raw header / placeholder.
	 * @return string
	 */
	public function normalize_header_token( $header ) {
		$header = $this->strip_utf8_bom( (string) $header );
		$header = strtolower( trim( $header ) );
		$header = preg_replace( '/[\s\-]+/', '_', $header );
		return is_string( $header ) ? $header : '';
	}

	/**
	 * Common aliases when CSV column naming differs from the mapping placeholder.
	 *
	 * @param string $token Placeholder e.g. search_price.
	 * @return string[]
	 */
	public function get_placeholder_header_aliases( $token ) {
		$norm = $this->normalize_header_token( $token );
		$map  = array(
			'search_price'  => array( 'search_price', 'search price', 'searchprice', 'price', 'product_price', 'prijs', 'regular_price' ),
			'product_name'  => array( 'product_name', 'product name', 'productname', 'name', 'title', 'product_title', 'product title' ),
			'product_title' => array( 'product_title', 'product title', 'product_name', 'product name', 'name', 'title' ),
		);
		$aliases = isset( $map[ $norm ] ) ? $map[ $norm ] : array( $token );
		/**
		 * Allow sites to extend placeholder → CSV header aliases.
		 *
		 * @param string[] $aliases Candidate header names.
		 * @param string   $token   Original {placeholder} token.
		 */
		return apply_filters( 'sm_uci_pro_header_placeholder_aliases', $aliases, $token );
	}

	/**
	 * Load user-defined helpers from uploads (same path as write_to_customfile).
	 * Required before evalPhp() because merge_cus2_header_manipulation_into_base() may run
	 * before write_to_customfile(), so functions would otherwise stay undefined.
	 */
	/**
	 * Load user-defined helpers from uploads (same path as write_to_customfile).
	 * Uses CustomFunctionService so uploads PHP is validated before require (CVE-2026-13353).
	 * Required before evalPhp() because merge may run before write_to_customfile().
	 */
	private function load_custom_function_definitions_file() {
		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\CustomFunctionService' ) ) {
			\Smackcoders\UCI\Proaddons\UltimatePro\CustomFunctionService::load_definitions();
		}
	}

	/**
	 * Bracket content is only sent to evalPhp() when it looks like a PHP expression.
	 * WordPress shortcodes use the same [..] syntax and would otherwise throw parse errors.
	 *
	 * @param string $inner Text inside the first pair of square brackets.
	 * @return bool
	 */
	public function is_plausible_php_bracket_expression( $inner ) {
		$inner = trim( (string) $inner );
		if ( $inner === '' ) {
			return false;
		}
		if ( $inner[0] === '/' ) {
			return false;
		}
		if ( preg_match( '/=\s*["\']/', $inner ) ) {
			return false;
		}
		return (bool) preg_match(
			'/^(true|false|null)\b|[A-Za-z_][A-Za-z0-9_]*\s*\(|->|::|\$[A-Za-z_]|\d/',
			$inner
		);
	}

	/**
	 * Normalize a price string for WooCommerce storage.
	 * Custom functions (e.g. bereken_awin_100g) often return European "0,50";
	 * WC with decimal_sep="." mis-parses that as thousand separator → wrong/zero prices.
	 *
	 * @param mixed $value Raw price from mapping / custom function.
	 * @return string|mixed Normalized decimal string when it looks like a price; otherwise original.
	 */
	public function normalize_woocommerce_price_value( $value ) {
		if ( is_int( $value ) || is_float( $value ) ) {
			if ( function_exists( 'wc_format_decimal' ) ) {
				return wc_format_decimal( $value );
			}
			return (string) $value;
		}
		if ( ! is_string( $value ) ) {
			return $value;
		}
		$raw = trim( $value );
		if ( $raw === '' ) {
			return $raw;
		}
		// Leave non-numeric / formula leftovers alone.
		if ( ! preg_match( '/^[\d\s.,\-]+$/', $raw ) ) {
			return $value;
		}

		$normalized = $raw;
		$has_comma  = strpos( $normalized, ',' ) !== false;
		$has_dot    = strpos( $normalized, '.' ) !== false;

		if ( $has_comma && $has_dot ) {
			// 1.234,56 (EU) vs 1,234.56 (US): last separator is decimal.
			$last_comma = strrpos( $normalized, ',' );
			$last_dot   = strrpos( $normalized, '.' );
			if ( $last_comma > $last_dot ) {
				$normalized = str_replace( '.', '', $normalized );
				$normalized = str_replace( ',', '.', $normalized );
			} else {
				$normalized = str_replace( ',', '', $normalized );
			}
		} elseif ( $has_comma ) {
			// 39,99 or 1,234 — treat ,XX as decimal when 1–2 digits after comma.
			if ( preg_match( '/,\d{1,2}$/', $normalized ) ) {
				$normalized = str_replace( ',', '.', $normalized );
			} else {
				$normalized = str_replace( ',', '', $normalized );
			}
		}

		$normalized = preg_replace( '/\s+/', '', $normalized );
		if ( function_exists( 'wc_format_decimal' ) ) {
			return wc_format_decimal( $normalized );
		}
		return $normalized;
	}

	/**
	 * True when a mapped WP field key should be treated as a WooCommerce price.
	 *
	 * @param string $wp_element Field key.
	 * @return bool
	 */
	public function is_woocommerce_price_field( $wp_element ) {
		$key = strtolower( trim( (string) $wp_element ) );
		if ( $key === '' ) {
			return false;
		}
		$exact = array(
			'regular_price',
			'sale_price',
			'price',
			'_regular_price',
			'_sale_price',
			'_price',
			'pb_regular_price',
			'pb_sale_price',
		);
		if ( in_array( $key, $exact, true ) ) {
			return true;
		}
		// Custom / ACF keys commonly used for "price per 100g".
		if ( false !== strpos( $key, 'price' ) || false !== strpos( $key, '100g' ) || false !== strpos( $key, 'prijs' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Evaluate PHP expressions for Header Manipulation brackets.
	 * Tries SafeExpressionEvaluator first (builtins only), then CustomFunctionService
	 * for registered functions from uploads/customFunction.php (no raw eval of uploads).
	 *
	 * @param string $expression Expression after placeholder substitution.
	 * @return mixed|null Null when evaluation fails.
	 */
	public function evalPhp( $expression ) {
		$expression = (string) $expression;
		if ( class_exists( '\Smackcoders\UCI\Core\SafeExpressionEvaluator' ) ) {
			$result = \Smackcoders\UCI\Core\SafeExpressionEvaluator::evaluate_return( $expression );
			if ( null !== $result ) {
				return $result;
			}
		}
		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\CustomFunctionService' ) ) {
			return \Smackcoders\UCI\Proaddons\UltimatePro\CustomFunctionService::evaluate_call( $expression );
		}
		return null;
	}

	/**
	 * Function to evaluate custom PHP code — disabled for security (CVE-2026-13353).
	 */
	public function execute_custom_code( $code, $header_array, $value_array ) {
		unset( $header_array, $value_array );
		if ( ! current_user_can( 'manage_options' ) ) {
			return null;
		}
		$code = trim( (string) $code );
		if ( $code === '' || ! class_exists( '\Smackcoders\UCI\Core\SafeExpressionEvaluator' ) ) {
			return null;
		}
		return \Smackcoders\UCI\Core\SafeExpressionEvaluator::evaluate_return( $code );
	}

	/**
	 * Resolve import row update mode (replace | skip | append).
	 *
	 * @param string $hash_key
	 * @param string $provided
	 * @return string
	 */
	public static function resolve_import_update_mode( $hash_key = '', $provided = '' ) {
		$mode = strtolower( trim( (string) $provided ) );
		if ( $mode === '' ) {
			$mode = strtolower( trim( (string) ( $_POST['UpdateMode'] ?? $_POST['update_mode'] ?? '' ) ) );
		}
		if ( $mode === '' && $hash_key !== '' ) {
			$mode = strtolower( trim( (string) get_option( 'smack_update_mode_' . sanitize_key( $hash_key ) ) ) );
		}
		if ( ! in_array( $mode, [ 'replace', 'skip', 'append' ], true ) ) {
			$mode = 'replace';
		}
		return $mode;
	}

	/**
	 * Apply update mode for scalar user meta.
	 *
	 * @param int    $user_id
	 * @param string $meta_key
	 * @param mixed  $new_value
	 * @param string $mode
	 * @return array{action:string,previous:mixed}
	 */
	public static function apply_import_user_meta( $user_id, $meta_key, $new_value, $mode ) {
		$user_id  = intval( $user_id );
		$meta_key = (string) $meta_key;
		$mode     = (string) $mode;
		$prev     = get_user_meta( $user_id, $meta_key, true );

		if ( $mode === 'skip' ) {
			return [ 'action' => 'skipped', 'previous' => $prev ];
		}
		if ( $mode === 'append' ) {
			$empty_prev = $prev === '' || $prev === null || ( is_array( $prev ) && empty( $prev ) );
			if ( ! $empty_prev ) {
				return [ 'action' => 'kept', 'previous' => $prev ];
			}
		}
		update_user_meta( $user_id, $meta_key, $new_value );
		return [ 'action' => ( $mode === 'replace' ? 'replaced' : 'set' ), 'previous' => $prev ];
	}

	/**
	 * Apply update mode for array user meta (merge on append).
	 *
	 * @param int    $user_id
	 * @param string $meta_key
	 * @param array  $incoming
	 * @param string $mode
	 * @return array{action:string,previous:mixed,new:array}
	 */
	public static function apply_import_user_meta_array( $user_id, $meta_key, $incoming, $mode ) {
		$user_id  = intval( $user_id );
		$meta_key = (string) $meta_key;
		$mode     = (string) $mode;
		$incoming = is_array( $incoming ) ? $incoming : [];
		$prev     = get_user_meta( $user_id, $meta_key, true );
		$prev_arr = is_array( $prev ) ? $prev : ( $prev ? (array) $prev : [] );

		if ( $mode === 'skip' ) {
			return [ 'action' => 'skipped', 'previous' => $prev, 'new' => $prev_arr ];
		}
		if ( $mode === 'append' ) {
			$new = array_merge( $prev_arr, $incoming );
			$new = self::normalize_import_meta_array_merge( $new );
			update_user_meta( $user_id, $meta_key, $new );
			return [ 'action' => 'merged', 'previous' => $prev, 'new' => $new ];
		}
		$incoming = self::normalize_import_meta_array_merge( $incoming );
		update_user_meta( $user_id, $meta_key, $incoming );
		return [ 'action' => 'replaced', 'previous' => $prev, 'new' => $incoming ];
	}

	/**
	 * @param array $arr
	 * @return array
	 */
	private static function normalize_import_meta_array_merge( $arr ) {
		$arr = is_array( $arr ) ? $arr : [];
		if ( empty( $arr ) ) {
			return $arr;
		}
		$is_assoc = array_keys( $arr ) !== range( 0, count( $arr ) - 1 );
		if ( $is_assoc ) {
			return $arr;
		}
		$out = [];
		foreach ( $arr as $v ) {
			if ( is_string( $v ) ) {
				$v = trim( $v );
			}
			$out[] = $v;
		}
		$seen = [];
		$uniq = [];
		foreach ( $out as $v ) {
			$k = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
			if ( isset( $seen[ $k ] ) ) {
				continue;
			}
			$seen[ $k ] = true;
			$uniq[]     = $v;
		}
		return $uniq;
	}

	/**
	 * Decode MappedFields from admin-ajax (plain JSON or base64 to avoid WAF blocks on formulas).
	 *
	 * @param string $map_fields Raw POST value.
	 * @param string|null $encoding Optional encoding hint; defaults to $_POST['MappedFieldsEncoding'].
	 * @return array|null
	 */
	public static function decode_mapping_payload($map_fields, $encoding = null)
	{
		if (!is_string($map_fields)) {
			return null;
		}

		$payload = wp_unslash($map_fields);

		if ($encoding === null && isset($_POST['MappedFieldsEncoding'])) {
			$encoding = sanitize_text_field(wp_unslash($_POST['MappedFieldsEncoding']));
		}

		if ($encoding === 'base64') {
			$decoded_raw = base64_decode($payload, true);
			if ($decoded_raw !== false) {
				$payload = $decoded_raw;
			}
		}

		$decoded = json_decode($payload, true);
		if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
			return $decoded;
		}

		$fallback_payload = stripslashes($payload);
		if ($fallback_payload !== $payload) {
			$decoded = json_decode($fallback_payload, true);
			if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
				return $decoded;
			}
		}

		return null;
	}

	/**
	 * Meta key used by YIKES Custom Product Tabs for WooCommerce.
	 */
	public static function yikes_woo_products_tabs_meta_key() {
		return 'yikes_woo_products_tabs';
	}

	/**
	 * Whether YIKES Custom Product Tabs for WooCommerce is active.
	 *
	 * @return bool
	 */
	public static function is_yikes_woo_products_tabs_active() {
		return is_plugin_active( 'yikes-inc-easy-custom-woocommerce-product-tabs/yikes-inc-easy-custom-woocommerce-product-tabs.php' );
	}

	/**
	 * Normalize YIKES product tab rows to the structure expected by the plugin.
	 *
	 * @param mixed $tabs
	 * @return array
	 */
	public static function normalize_yikes_woo_products_tabs( $tabs ) {
		if ( ! is_array( $tabs ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $tabs as $tab ) {
			if ( ! is_array( $tab ) ) {
				continue;
			}

			$title   = isset( $tab['title'] ) ? (string) $tab['title'] : '';
			$content = isset( $tab['content'] ) ? (string) $tab['content'] : '';

			if ( $title === '' && $content === '' ) {
				continue;
			}

			$id = isset( $tab['id'] ) && $tab['id'] !== '' ? (string) $tab['id'] : urldecode( sanitize_title( $title ) );
			$entry = array(
				'title'   => $title,
				'id'      => $id,
				'content' => $content,
			);

			if ( isset( $tab['name'] ) ) {
				$entry['name'] = (string) $tab['name'];
			}

			$normalized[] = $entry;
		}

		return array_values( $normalized );
	}

	/**
	 * Parse imported YIKES product tabs from human-readable, JSON, or PHP-serialized values.
	 *
	 * @param mixed $value
	 * @return array|null Null when the value cannot be parsed.
	 */
	public static function parse_yikes_woo_products_tabs_for_import( $value ) {
		if ( $value === null ) {
			return array();
		}

		if ( is_array( $value ) ) {
			return self::normalize_yikes_woo_products_tabs( $value );
		}

		if ( ! is_string( $value ) ) {
			return null;
		}

		$value = trim( $value );
		if ( $value === '' ) {
			return array();
		}

		$human_tabs = self::parse_yikes_woo_products_tabs_human_format( $value );
		if ( $human_tabs !== null ) {
			return $human_tabs;
		}

		if ( $value[0] === '[' || $value[0] === '{' ) {
			$decoded = json_decode( $value, true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
				return self::normalize_yikes_woo_products_tabs( $decoded );
			}
		}

		if ( is_serialized( $value ) ) {
			$unserialized = maybe_unserialize( $value );
			if ( is_array( $unserialized ) ) {
				return self::normalize_yikes_woo_products_tabs( $unserialized );
			}
		}

		return null;
	}

	/**
	 * Format YIKES product tabs for export in a human-readable block format.
	 *
	 * Example:
	 * [TAB title="Specifications" id="specifications"]
	 * <h2>HTML content</h2>
	 * [/TAB]
	 *
	 * @param mixed $tabs
	 * @return string
	 */
	public static function format_yikes_woo_products_tabs_for_export( $tabs ) {
		if ( is_string( $tabs ) && is_serialized( $tabs ) ) {
			$tabs = maybe_unserialize( $tabs );
		}

		$tabs = self::normalize_yikes_woo_products_tabs( $tabs );
		if ( empty( $tabs ) ) {
			return '';
		}

		$blocks = array();
		foreach ( $tabs as $tab ) {
			$attributes = array(
				'title="' . self::escape_yikes_tab_attribute( $tab['title'] ) . '"',
			);

			if ( ! empty( $tab['id'] ) ) {
				$attributes[] = 'id="' . self::escape_yikes_tab_attribute( $tab['id'] ) . '"';
			}

			if ( ! empty( $tab['name'] ) ) {
				$attributes[] = 'name="' . self::escape_yikes_tab_attribute( $tab['name'] ) . '"';
			}

			$blocks[] = '[TAB ' . implode( ' ', $attributes ) . ']' . "\n" . $tab['content'] . "\n[/TAB]";
		}

		return implode( "\n\n", $blocks );
	}

	/**
	 * Parse the human-readable YIKES tab export format.
	 *
	 * @param string $value
	 * @return array|null
	 */
	public static function parse_yikes_woo_products_tabs_human_format( $value ) {
		if ( strpos( $value, '[TAB' ) === false ) {
			return null;
		}

		$pattern = '/\[TAB\s+([^\]]+)\]\s*(.*?)\s*\[\/TAB\]/si';
		if ( ! preg_match_all( $pattern, $value, $matches, PREG_SET_ORDER ) ) {
			return null;
		}

		$tabs = array();
		foreach ( $matches as $match ) {
			$attributes = array();
			if ( preg_match_all( '/(\w+)="([^"]*)"/', $match[1], $attribute_matches, PREG_SET_ORDER ) ) {
				foreach ( $attribute_matches as $attribute_match ) {
					$attributes[ $attribute_match[1] ] = self::unescape_yikes_tab_attribute( $attribute_match[2] );
				}
			}

			$title   = isset( $attributes['title'] ) ? $attributes['title'] : '';
			$content = $match[2];

			if ( $title === '' && trim( $content ) === '' ) {
				continue;
			}

			$tab = array(
				'title'   => $title,
				'id'      => ! empty( $attributes['id'] ) ? $attributes['id'] : urldecode( sanitize_title( $title ) ),
				'content' => $content,
			);

			if ( ! empty( $attributes['name'] ) ) {
				$tab['name'] = $attributes['name'];
			}

			$tabs[] = $tab;
		}

		if ( empty( $tabs ) ) {
			return null;
		}

		return self::normalize_yikes_woo_products_tabs( $tabs );
	}

	/**
	 * Escape attribute values used in the human-readable export format.
	 *
	 * @param string $value
	 * @return string
	 */
	private static function escape_yikes_tab_attribute( $value ) {
		return str_replace(
			array( '"', "\r\n", "\r", "\n" ),
			array( '&quot;', ' ', ' ', ' ' ),
			(string) $value
		);
	}

	/**
	 * Unescape attribute values from the human-readable export format.
	 *
	 * @param string $value
	 * @return string
	 */
	private static function unescape_yikes_tab_attribute( $value ) {
		return str_replace( '&quot;', '"', (string) $value );
	}

	/**
	 * Persist YIKES product tabs on a product.
	 *
	 * @param int   $product_id
	 * @param mixed $value
	 * @return bool
	 */
	public static function update_yikes_woo_products_tabs_meta( $product_id, $value ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return false;
		}

		$tabs = self::parse_yikes_woo_products_tabs_for_import( $value );
		if ( $tabs === null ) {
			return false;
		}

		if ( empty( $tabs ) ) {
			delete_post_meta( $product_id, self::yikes_woo_products_tabs_meta_key() );
			return true;
		}

		update_post_meta( $product_id, self::yikes_woo_products_tabs_meta_key(), $tabs );
		return true;
	}

}

/**
 * Best-effort per-row undo stack (reverse callables on rollback).
 */
class ImportRowUndoStack {
	/** @var array<int, callable> */
	private $undo = [];

	/** @var int */
	private $line_number = 0;

	public function __construct( $line_number = 0 ) {
		$this->line_number = intval( $line_number );
	}

	public function pushUndo( $callable, $label = '' ) {
		if ( is_callable( $callable ) ) {
			$this->undo[] = $callable;
		}
	}

	public function rollback( $reason = '' ) {
		for ( $i = count( $this->undo ) - 1; $i >= 0; $i-- ) {
			try {
				call_user_func( $this->undo[ $i ] );
			} catch ( \Throwable $e ) {
				// ignore
			}
		}
		$this->undo = [];
	}
}
