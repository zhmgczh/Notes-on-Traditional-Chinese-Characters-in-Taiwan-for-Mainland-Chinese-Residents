<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPBakeryImport {

	private static $instance = null;

	/** @var array<string, string> */
	private static $sideloaded_url_map = array();

	/** @var array<string, int> */
	private static $cache_attachment_by_sha1 = array();

	/** @var array<string, int> */
	private static $cache_attachment_by_filename = array();

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new WPBakeryImport();
		}
		return self::$instance;
	}

	/**
	 * Mapped meta + optional post_content for WPBakery field group (Posts/Pages/etc.).
	 *
	 * @param array<int, string> $header_array
	 * @param array<int, string> $value_array
	 * @param array<string, mixed> $map
	 */
	public function set_wpbakery_value( $header_array, $value_array, $map, $post_id, $type, $hash_key, $gmode, $templatekey ) {
		$helpers_instance = ImportHelpers::getInstance();
		$post_values      = $helpers_instance->get_header_values( $map, $header_array, $value_array );

		$media_manifest = isset( $post_values['media_files'] ) ? (string) $post_values['media_files'] : '';
		foreach ( $post_values as $custom_key => $custom_value ) {
			if ( 'media_files' === $custom_key ) {
				continue;
			}
			if ( is_serialized( $custom_value ) && $custom_key !== '_wpb_post_custom_js_header' ) {
				$custom_value = unserialize( $custom_value );
			} elseif ( in_array( $custom_key, array( '_wpb_post_custom_css', '_wpb_shortcodes_custom_css', '_wpb_shortcodes_default_css' ), true ) ) {
				$custom_value = $this->maybe_decode_base64_css( $custom_value );
				// CSS metas can contain background-image URLs that reference old
				// attachment IDs/URLs. Remap them the same way we do for post_content.
				if ( $media_manifest !== '' ) {
					$custom_value = $this->remap_shortcode_media_from_manifest( $custom_value, $media_manifest, $post_id );
				}
			}
			if ( '_wpb_vc_js_status' === $custom_key ) {
				if ( '' === $custom_value || '1' === $custom_value ) {
					$custom_value = 'true';
				}
				if ( in_array( strtolower( (string) $custom_value ), array( 'yes', 'on', 'enabled' ), true ) ) {
					$custom_value = 'true';
				}
			}
			update_post_meta( $post_id, $custom_key, $custom_value );
		}

		$saved_post_content = (string) get_post_field( 'post_content', $post_id );
		if ( $saved_post_content !== '' ) {
			$remapped_content = $this->maybe_decode_base64_string( $saved_post_content );
			if ( $media_manifest !== '' ) {
				$remapped_content = $this->remap_shortcode_media_from_manifest( $remapped_content, $media_manifest, $post_id );
			}
			error_log( "remapped content: " . $remapped_content ,3,WP_CONTENT_DIR.'/error.log' );
			if ( $remapped_content !== $saved_post_content ) {
				wp_update_post(
					array(
						'ID'           => $post_id,
						'post_content' => $remapped_content,
					)
				);
			}
		}

		$this->remap_shortcode_media_urls( $post_id );
		if ( ! array_key_exists( '_wpb_vc_js_status', $post_values ) ) {
			update_post_meta( $post_id, '_wpb_vc_js_status', 'true' );
		}
	}

	/**
	 * Bulk import rows for vc_templates (CSV column layout matches Elementor template export).
	 *
	 * @param array<int, string> $header_array
	 * @param array<int, string> $value_array
	 * @param array<string, mixed> $map
	 */
	function set_wpbakery_template_values( $header_array, $value_array, $map, $post_id, $type, $mode, $line_number, $hash_key ) {
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WPBakeryExtension' ) || ! WPBakeryExtension::is_wpbakery_active() ) {
			return $post_id;
		}
		$core_instance     = CoreFieldsImport::getInstance();
		$helpers_instance = ImportHelpers::getInstance();
		$row_map = ( is_array( $map ) && ! empty( $map ) ) ? $map : array();
		if ( empty( $row_map ) ) {
			foreach ( $header_array as $header_name ) {
				$key = trim( (string) $header_name );
				if ( $key === '' ) {
					continue;
				}
				$row_map[ $key ] = $key;
			}
		}
		$row_data = $helpers_instance->get_header_values( $row_map, $header_array, $value_array );

		$get_from_row = static function ( $keys ) use ( $row_data ) {
			foreach ( $keys as $key ) {
				if ( isset( $row_data[ $key ] ) && $row_data[ $key ] !== '' ) {
					return (string) $row_data[ $key ];
				}
			}
			return '';
		};

		$style_cell    = $get_from_row( array( 'Style', '_wpb_bundle_style' ) );
		$style_payload = base64_decode( (string) $style_cell, true );
		$decoded       = is_string( $style_payload ) ? json_decode( $style_payload, true ) : null;

		$custom_css    = ( is_array( $decoded ) && isset( $decoded['custom_css'] ) ) ? (string) $decoded['custom_css'] : $get_from_row( array( '_wpb_post_custom_css' ) );
		$short_css     = ( is_array( $decoded ) && isset( $decoded['shortcodes_css'] ) ) ? (string) $decoded['shortcodes_css'] : $get_from_row( array( '_wpb_shortcodes_custom_css' ) );
		$page_tpl      = ( is_array( $decoded ) && isset( $decoded['page_template'] ) ) ? (string) $decoded['page_template'] : $get_from_row( array( '_wp_page_template' ) );
		$editor_type   = ( is_array( $decoded ) && isset( $decoded['vc_editor_type'] ) ) ? (string) $decoded['vc_editor_type'] : $get_from_row( array( '_wpb_vc_editor_type' ) );
		$custom_layout = ( is_array( $decoded ) && isset( $decoded['post_custom_layout'] ) ) ? (string) $decoded['post_custom_layout'] : $get_from_row( array( '_wpb_post_custom_layout' ) );
		$default_css_u = ( is_array( $decoded ) && isset( $decoded['shortcodes_default_css_updated'] ) ) ? (string) $decoded['shortcodes_default_css_updated'] : $get_from_row( array( '_wpb_shortcodes_default_css_updated' ) );
		$short_css_u   = ( is_array( $decoded ) && isset( $decoded['shortcodes_custom_css_updated'] ) ) ? (string) $decoded['shortcodes_custom_css_updated'] : $get_from_row( array( '_wpb_shortcodes_custom_css_updated' ) );
		$default_css   = ( is_array( $decoded ) && isset( $decoded['shortcodes_default_css'] ) ) ? (string) $decoded['shortcodes_default_css'] : $get_from_row( array( '_wpb_shortcodes_default_css' ) );
		$custom_js_h   = ( is_array( $decoded ) && isset( $decoded['post_custom_js_header'] ) ) ? (string) $decoded['post_custom_js_header'] : $get_from_row( array( '_wpb_post_custom_js_header' ) );

		$media_manifest = $get_from_row( array( 'media_files', 'Media Files' ) );
		$post_content   = $get_from_row( array( 'Template content', 'post_content' ) );
		if ( $media_manifest !== '' ) {
			$post_content = $this->remap_shortcode_media_from_manifest( $post_content, $media_manifest, $post_id );
		}

		$template_data = array(
			'post_title'   => $get_from_row( array( 'Template title', 'post_title' ) ),
			'post_content' => $post_content,
			'post_type'    => 'vc_templates',
			'post_status'  => $get_from_row( array( 'Template status', 'post_status' ) ) ?: 'publish',
			'post_date'    => $get_from_row( array( 'Created time', 'post_date' ) ) ?: current_time( 'mysql' ),
			'post_author'  => get_current_user_id() ?: 1,
		);

		$target_id = intval( $post_id );
		if ( $target_id > 0 && get_post( $target_id ) ) {
			$template_data['ID'] = $target_id;
			$target_id = wp_update_post( $template_data );
			$state     = 'Updated';
		} else {
			$target_id = wp_insert_post( $template_data );
			$state     = 'Inserted';
		}

		if ( ! $target_id || is_wp_error( $target_id ) ) {
			return $post_id;
		}

		update_post_meta( $target_id, '_wpb_post_custom_css', $custom_css );
		update_post_meta( $target_id, '_wpb_shortcodes_custom_css', $short_css );
		update_post_meta( $target_id, '_wpb_vc_js_status', 'true' );
		if ( $page_tpl !== '' ) {
			update_post_meta( $target_id, '_wp_page_template', $page_tpl );
		}
		if ( $editor_type !== '' ) {
			update_post_meta( $target_id, '_wpb_vc_editor_type', $editor_type );
		}
		if ( $custom_layout !== '' ) {
			update_post_meta( $target_id, '_wpb_post_custom_layout', $custom_layout );
		}
		if ( $default_css_u !== '' ) {
			update_post_meta( $target_id, '_wpb_shortcodes_default_css_updated', $default_css_u );
		}
		if ( $short_css_u !== '' ) {
			update_post_meta( $target_id, '_wpb_shortcodes_custom_css_updated', $short_css_u );
		}
		if ( $default_css !== '' ) {
			update_post_meta( $target_id, '_wpb_shortcodes_default_css', $default_css );
		}
		if ( $custom_js_h !== '' ) {
			update_post_meta( $target_id, '_wpb_post_custom_js_header', $custom_js_h );
		}

		$this->remap_shortcode_media_urls( $target_id );

		$core_instance->detailed_log[ $line_number ]['state']     = $state;
		$core_instance->detailed_log[ $line_number ]['webLink']   = get_permalink( $target_id );
		$core_instance->detailed_log[ $line_number ]['adminLink'] = get_edit_post_link( $target_id, true );
		$core_instance->detailed_log[ $line_number ]['id']        = $target_id;

		return $target_id;
	}

	/**
	 * media_files format: oldId:url|oldId:url
	 * Replaces IDs inside VC shortcode attributes and updates content.
	 */
	private function remap_shortcode_media_from_manifest( $content, $manifest, $parent_post_id ) {
		$content  = (string) $content;
		$manifest = trim( (string) $manifest );
		if ( $content === '' || $manifest === '' ) {
			return $content;
		}

		$pairs = array_filter( array_map( 'trim', explode( '|', $manifest ) ) );
		if ( empty( $pairs ) ) {
			return $content;
		}

		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
		}
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$id_map  = array();
		$url_map = array(); // old_url => new_url
		foreach ( $pairs as $pair ) {
			$parts = explode( ':', $pair, 2 );
			if ( count( $parts ) !== 2 ) {
				continue;
			}
			$old_id = (int) trim( (string) $parts[0] );
			$url    = trim( (string) $parts[1] );
			if ( $old_id <= 0 || $url === '' ) {
				continue;
			}
			$new_id = $this->sideloadAnyFileByUrlDedup( $url, (int) $parent_post_id );
			if ( $new_id && ! $this->attachment_file_exists( $new_id ) ) {
				// Attachment record exists but file is missing (common after migrations). Force re-download.
				$new_id = $this->sideloadAnyFileByUrlDedup( $url, (int) $parent_post_id, true );
			}
			if ( $new_id ) {
				$id_map[ $old_id ] = (int) $new_id;
				$new_url = wp_get_attachment_url( (int) $new_id );
				if ( $new_url ) {
					$url_map[ $url ] = $new_url;
				}
			}
		}

		if ( empty( $id_map ) ) {
			return $content;
		}

		// Replace old attachment URLs with new local URLs FIRST — before any regex
		// touches the content. This ensures full URLs like "old.jpeg?id=14772" are
		// substituted as a unit; if we ran the ?id= regex first it would mutate the
		// query-string and strtr would then fail to match the original key.
		if ( ! empty( $url_map ) ) {
			$content = strtr( $content, $url_map );
		}

		// Replace common VC media attributes that carry ids lists.
		$content = preg_replace_callback(
			'/\\b(image|images|include|ids)=\"([0-9,]+)\"/i',
			function ( $m ) use ( $id_map ) {
				$attr = $m[1];
				$list = $m[2];
				$out  = array();
				foreach ( preg_split( '/\\s*,\\s*/', (string) $list ) as $id ) {
					$old = (int) $id;
					$out[] = isset( $id_map[ $old ] ) ? (string) $id_map[ $old ] : (string) $old;
				}
				return $attr . '="' . implode( ',', $out ) . '"';
			},
			$content
		);

		// Replace remaining occurrences of ?id=OLD that were not covered by a full
		// URL substitution above (e.g. bare id= params with no surrounding URL context).
		$content = preg_replace_callback(
			'/(\\bid=)(\\d+)/i',
			function ( $m ) use ( $id_map ) {
				$old = (int) $m[2];
				if ( isset( $id_map[ $old ] ) ) {
					return $m[1] . (string) $id_map[ $old ];
				}
				return $m[0];
			},
			$content
		);

		// Replace wp-image-OLD classes.
		$content = preg_replace_callback(
			'/\\bwp-image-(\\d+)\\b/i',
			function ( $m ) use ( $id_map ) {
				$old = (int) $m[1];
				if ( isset( $id_map[ $old ] ) ) {
					return 'wp-image-' . (string) $id_map[ $old ];
				}
				return $m[0];
			},
			$content
		);

		return $content;
	}

	/**
	 * Download a URL as an attachment with dedup checks.
	 *
	 * Dedup chain:
	 * - attachment_url_to_postid
	 * - SHA1 meta (_smack_uci_file_sha1)
	 * - filename post_name match
	 * - guid LIKE %filename%
	 *
	 * @param string $url
	 * @param int $parent_post_id
	 * @return int Attachment ID or 0
	 */
	private function sideloadAnyFileByUrlDedup( $url, $parent_post_id = 0, $force_download = false ) {
		global $wpdb;

		$url = trim( (string) $url );
		if ( $url === '' || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return 0;
		}

		if ( ! $force_download ) {
			// Fast path: if this URL already belongs to an attachment.
			$existing_id = (int) attachment_url_to_postid( $url );
			if ( $existing_id > 0 && $this->attachment_file_exists( $existing_id ) ) {
				return $existing_id;
			}

			// If this URL was previously imported, reuse by stored source URL.
			$existing_by_source = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s ORDER BY post_id DESC LIMIT 1",
					'_smack_uci_source_url',
					$url
				)
			);
			if ( $existing_by_source > 0 && $this->attachment_file_exists( $existing_by_source ) ) {
				return $existing_by_source;
			}

			// Some sites store external URL directly in guid for attachments. Reuse if present.
			$existing_by_guid_exact = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND guid = %s ORDER BY ID DESC LIMIT 1",
					$url
				)
			);
			if ( $existing_by_guid_exact > 0 && $this->attachment_file_exists( $existing_by_guid_exact ) ) {
				return $existing_by_guid_exact;
			}
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			return 0;
		}

		// Validate we downloaded a real image (avoid importing HTML/login pages as "images").
		$filesize = @filesize( $tmp );
		$filesize = is_int( $filesize ) ? $filesize : 0;
		if ( $filesize <= 0 ) {
			@unlink( $tmp );
			return 0;
		}

		$sha1 = @sha1_file( $tmp );
		$sha1 = is_string( $sha1 ) ? $sha1 : '';

		if ( ! $force_download && $sha1 !== '' ) {
			if ( isset( self::$cache_attachment_by_sha1[ $sha1 ] ) ) {
				@unlink( $tmp );
				return (int) self::$cache_attachment_by_sha1[ $sha1 ];
			}
			$existing_sha1 = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
					'_smack_uci_file_sha1',
					$sha1
				)
			);
			if ( $existing_sha1 > 0 ) {
				self::$cache_attachment_by_sha1[ $sha1 ] = $existing_sha1;
				@unlink( $tmp );
				return $existing_sha1;
			}
		}

		$filename = basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		$filename = $filename ? $filename : ( 'download-' . time() . '.jpg' );
		$filename = sanitize_file_name( $filename );
		$filename_key = strtolower( $filename );

		if ( ! $force_download && isset( self::$cache_attachment_by_filename[ $filename_key ] ) ) {
			@unlink( $tmp );
			return (int) self::$cache_attachment_by_filename[ $filename_key ];
		}

		$post_name = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
		if ( ! $force_download && $post_name !== '' ) {
			$existing_by_name = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_name = %s ORDER BY ID DESC LIMIT 1",
					$post_name
				)
			);
			if ( $existing_by_name > 0 && $this->attachment_file_exists( $existing_by_name ) ) {
				self::$cache_attachment_by_filename[ $filename_key ] = $existing_by_name;
				@unlink( $tmp );
				return $existing_by_name;
			}
		}

		$like = '%' . $wpdb->esc_like( $filename ) . '%';
		if ( ! $force_download ) {
			$existing_by_guid = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND guid LIKE %s ORDER BY ID DESC LIMIT 1",
					$like
				)
			);
			if ( $existing_by_guid > 0 && $this->attachment_file_exists( $existing_by_guid ) ) {
				self::$cache_attachment_by_filename[ $filename_key ] = $existing_by_guid;
				@unlink( $tmp );
				return $existing_by_guid;
			}
		}

		// Move into uploads using WP APIs, then create attachment.
		$file_array = array(
			'name'     => $filename,
			'tmp_name' => $tmp,
		);
		
		$attachment_id = media_handle_sideload( $file_array, (int) $parent_post_id );
		
		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp );
			return 0;
		}

		$attachment_id = (int) $attachment_id;
		if ( $sha1 !== '' ) {
			update_post_meta( $attachment_id, '_smack_uci_file_sha1', $sha1 );
			self::$cache_attachment_by_sha1[ $sha1 ] = $attachment_id;
		}
		update_post_meta( $attachment_id, '_smack_uci_source_url', $url );
		self::$cache_attachment_by_filename[ $filename_key ] = $attachment_id;

		return $attachment_id;
	}

	/**
	 * @param int $attachment_id
	 * @return bool
	 */
	private function attachment_file_exists( $attachment_id ) {
		$attachment_id = (int) $attachment_id;
		if ( $attachment_id <= 0 ) {
			return false;
		}
		$file = get_attached_file( $attachment_id );
		return is_string( $file ) && $file !== '' && file_exists( $file );
	}

	/**
	 * @param string $value Raw cell.
	 */
	private function maybe_decode_base64_string( $value ) {
		$value = (string) $value;
		$decoded = base64_decode( $value, true );
		if ( $decoded !== false && $decoded !== '' && preg_match( '/^\[vc_/s', trim( $decoded ) ) ) {
			return $decoded;
		}
		return $value;
	}

	/**
	 * @param string $value Raw cell for CSS meta.
	 */
	private function maybe_decode_base64_css( $value ) {
		$value   = trim( (string) $value );
		$decoded = base64_decode( $value, true );
		if ( $decoded !== false && $decoded !== '' && preg_match( '/^[\x20-\x7E\s]*\{/', $decoded ) ) {
			return $decoded;
		}
		if ( $decoded !== false && strlen( $decoded ) > 20 && ctype_print( substr( $decoded, 0, min( 200, strlen( $decoded ) ) ) ) ) {
			return $decoded;
		}
		return $value;
	}

	/**
	 * Sideload image URLs found inside shortcode attributes / content and substitute local URLs.
	 */
	private function remap_shortcode_media_urls( $post_id ) {
		self::$sideloaded_url_map = array();
		$content = get_post_field( 'post_content', $post_id );
		if ( $content === '' || strpos( $content, 'http' ) === false ) {
			return;
		}

		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
		}
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$new_content = preg_replace_callback(
			'#https?://[^\s\]\'"\)]+#i',
			function ( $m ) use ( $post_id ) {
				$url = $m[0];
				if ( ! preg_match( '#\.(?:jpe?g|png|gif|webp|svg)(\?[^\s]*)?$#i', $url )
					&& ! preg_match( '#(wp-content/uploads|sites/\d+/files)#', $url ) ) {
					return $url;
				}
				$replacement = self::maybe_sideload_to_local_url( $url, $post_id );
				return $replacement ? $replacement : $url;
			},
			$content
		);

		if ( $new_content !== $content ) {
			wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => $new_content,
				)
			);
		}
	}

	private static function maybe_sideload_to_local_url( $url, $parent_post_id ) {
		if ( isset( self::$sideloaded_url_map[ $url ] ) ) {
			return self::$sideloaded_url_map[ $url ];
		}
		$existing_id = attachment_url_to_postid( esc_url_raw( $url ) );
		if ( $existing_id ) {
			$local = wp_get_attachment_url( $existing_id );
			if ( $local ) {
				self::$sideloaded_url_map[ $url ] = $local;
				return $local;
			}
		}
		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return '';
		}
		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$url_host  = wp_parse_url( $url, PHP_URL_HOST );
		if ( $home_host && $url_host && strcasecmp( (string) $home_host, (string) $url_host ) === 0 ) {
			return '';
		}
		$file_array = array();
		$file_array['name']     = sanitize_file_name( basename( wp_parse_url( $url, PHP_URL_PATH ) ) );
		if ( $file_array['name'] === '' ) {
			$file_array['name'] = 'import-' . time() . '.jpg';
		}
		$file_array['tmp_name'] = download_url( esc_url_raw( $url ), 60 );
		if ( is_wp_error( $file_array['tmp_name'] ) ) {
			return '';
		}
		$attach_id = media_handle_sideload( $file_array, $parent_post_id );
		if ( is_wp_error( $attach_id ) ) {
			@unlink( $file_array['tmp_name'] );
			return '';
		}
		$local = wp_get_attachment_url( $attach_id );
		if ( $local ) {
			self::$sideloaded_url_map[ $url ] = $local;
		}
		return $local;
	}
}
