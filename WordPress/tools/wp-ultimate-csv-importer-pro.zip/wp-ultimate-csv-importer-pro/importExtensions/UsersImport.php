<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class UsersImport {
    private static $users_instance = null,$send_user_password;

    public static function getInstance() {
		
		if (UsersImport::$users_instance == null) {
			UsersImport::$users_instance = new UsersImport;
			UsersImport::$send_user_password = SendPassword::getInstance();
			return UsersImport::$users_instance;
		}
		return UsersImport::$users_instance;
    }

	/**
	 * Detect values that are already stored in wp_users.user_pass (export round-trip), including
	 * phpass ($P$/$H$), bcrypt ($2y$…), WordPress 6.8+ ($wp$…), and argon2.
	 */
	private function uci_is_stored_password_hash( $password ) {
		if ( ! is_string( $password ) || strlen( $password ) < 20 ) {
			return false;
		}
		if ( '$' !== $password[0] ) {
			return false;
		}
		return (bool) preg_match( '/^\$(P\$|H\$|2[aby]\$|wp\$|argon2id\$|argon2i\$)/', $password );
	}

	/**
	 * wp_update_user() always runs wp_hash_password() when user_pass is non-empty and !== DB value,
	 * which breaks round-trip imports of hashed passwords. Skip field when appropriate.
	 */
	private function uci_normalize_password_before_wp_update_user( array &$data_array, $user_id ) {
		if ( ! isset( $data_array['user_pass'] ) ) {
			return;
		}
		$incoming = trim( (string) $data_array['user_pass'] );
		if ( '' === $incoming ) {
			unset( $data_array['user_pass'] );
			return;
		}
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return;
		}
		$incoming = wp_unslash( $incoming );
		$stored   = wp_unslash( (string) $user->user_pass );
		if ( hash_equals( $stored, $incoming ) ) {
			unset( $data_array['user_pass'] );
			return;
		}
		if ( $this->uci_is_stored_password_hash( $incoming ) ) {
			unset( $data_array['user_pass'] );
		}
	}

	/**
	 * Prepare password for wp_insert_user() on **create**: core always hashes the provided string once.
	 * Exported hashes must not be passed through that path; use a placeholder and restore hash after insert.
	 *
	 * @return string|null Hash to write with $wpdb->update after insert, or null when core hash is already correct.
	 */
	private function uci_prepare_password_for_new_user_insert( array &$data_array ) {
		$raw = isset( $data_array['user_pass'] ) ? trim( (string) $data_array['user_pass'] ) : '';
		if ( '' === $raw ) {
			$data_array['user_pass'] = wp_generate_password( 12, false );
			return null;
		}
		if ( $this->uci_is_stored_password_hash( $raw ) ) {
			$data_array['user_pass'] = wp_generate_password( 16, false );
			return $raw;
		}
		return null;
	}

	private function uci_restore_user_pass_after_insert( $user_id, $hash ) {
		global $wpdb;
		if ( empty( $user_id ) || ! is_string( $hash ) || '' === $hash ) {
			return;
		}
		$wpdb->update(
			$wpdb->users,
			array( 'user_pass' => $hash ),
			array( 'ID' => (int) $user_id ),
			array( '%s' ),
			array( '%d' )
		);
		clean_user_cache( (int) $user_id );
	}

	/**
	 * wp_update_user() merges with existing data; empty strings overwrite nice names / URLs.
	 * Drop optional keys that are blank so the previous DB value is kept.
	 */
	private function uci_unset_blank_optional_user_fields_on_update( array &$data_array ) {
		$optional = array(
			'display_name',
			'user_nicename',
			'user_url',
			'first_name',
			'last_name',
			'nickname',
			'description',
		);
		foreach ( $optional as $key ) {
			if ( ! array_key_exists( $key, $data_array ) ) {
				continue;
			}
			$val = $data_array[ $key ];
			if ( is_string( $val ) && trim( $val ) === '' ) {
				unset( $data_array[ $key ] );
			}
		}
	}

	/**
	 * WooCommerce "Hello …" uses display_name. Exports often duplicate user_login there.
	 * If the row has first + last name, prefer a human-readable display_name.
	 */
	private function uci_maybe_set_display_name_from_first_last( array &$data_array ) {
		$login = isset( $data_array['user_login'] ) ? trim( (string) $data_array['user_login'] ) : '';
		$disp  = isset( $data_array['display_name'] ) ? trim( (string) $data_array['display_name'] ) : '';
		if ( $login === '' ) {
			return;
		}
		$fn = isset( $data_array['first_name'] ) ? trim( (string) $data_array['first_name'] ) : '';
		$ln = isset( $data_array['last_name'] ) ? trim( (string) $data_array['last_name'] ) : '';
		$composed = trim( $fn . ' ' . $ln );
		if ( $composed === '' ) {
			return;
		}
		if ( $disp === '' || strcasecmp( $disp, $login ) === 0 ) {
			$data_array['display_name'] = $composed;
		}
	}

	/**
	 * Run all non-password tweaks before wp_update_user().
	 */
	private function uci_prepare_data_array_for_wp_update_user( array &$data_array, $user_id ) {
		$this->uci_unset_blank_optional_user_fields_on_update( $data_array );
		$this->uci_maybe_set_display_name_from_first_last( $data_array );
		$this->uci_normalize_password_before_wp_update_user( $data_array, (int) $user_id );
	}

    public function users_import_function ($data_array, $mode , $unikey_value , $unikey_name, $line_number,$update_based_on,$check,$type) {
		global $wpdb;
		$core_instance = CoreFieldsImport::getInstance();
		$helpers_instance = ImportHelpers::getInstance();
		global $core_instance;
		
		$returnArr = array();
		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($unikey_value,$unikey_name);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];
		$failed_count  = $updated_row_counts['failed'];
		// Ensure role and user_pass exist (ProfilePress/CORE merge may omit these)
		$data_array['role']      = isset( $data_array['role'] ) ? trim( (string) $data_array['role'] ) : '';
		$data_array['user_pass'] = isset( $data_array['user_pass'] ) ? trim( (string) $data_array['user_pass'] ) : '';

		if ($type == 'WooCommerce Customer' && $data_array['role'] !== 'customer') {
			$core_instance->detailed_log[$line_number]['Message'] = "Skipped, Role not allowed. Only 'customer' role is permitted.";
			$core_instance->detailed_log[$line_number]['state'] = 'Skipped';
			$wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'");
			return array('MODE' => $mode);
		}
		$user_role = $data_array['role'];
		if ( isset( $data_array['role'] ) && $data_array['role'] != '') {
			$user_capability = '';
			if ( !is_numeric( $data_array['role'] ) ) {	
				$roles = $this->getRoles();	
				if(array_key_exists($data_array['role'], $roles)) {
					$user_capability = $data_array['role'];
				}
			} else {
				for ( $i = 0; $i <= $data_array['role']; $i ++ ) {
					$user_capability .= $i . ",";
				}
				$roles = $this->getRoles('cap');
				if(in_array( $user_capability, $roles )) {
					foreach ( $roles as $rkey => $rval ) {
						if ( $rval == $user_capability ) {
							$user_capability = $rkey;
						}
					}
				} else {
					$user_capability = ''; 
				}
			}
			if($user_capability != ''){
				if($type == 'WooCommerce Customer'){
					$data_array['role'] = 'customer';
				}
				else{
					$data_array['role'] = $user_capability;
				}
			}
			else
				$data_array['role'] = 'subscriber'; 
		} else {
			$data_array['role'] = 'subscriber'; 
		}
		$user_email = isset($data_array['user_email']) ? $data_array['user_email'] : '';
		$user_login = isset($data_array['user_login']) ? $data_array['user_login'] : '';
		$id = isset($data_array['ID']) ? $data_array['ID'] : '';

		// Resolve existing user for update/duplicate prevention.
		$resolve_existing_user_id = function() use ($data_array, $update_based_on) {
			$uid = 0;
			$by  = strtolower((string)$update_based_on);
			$by  = $by ?: 'email';

			$candidates = [];
			if ($by === 'user_id' || $by === 'id') {
				$candidates = ['id', 'email', 'login'];
			} elseif ($by === 'user_login' || $by === 'login' || $by === 'username') {
				$candidates = ['login', 'email', 'id'];
			} else {
				$candidates = ['email', 'id', 'login'];
			}

			foreach ($candidates as $c) {
				if ($c === 'id') {
					if (!empty($data_array['ID']) && is_numeric($data_array['ID'])) {
						$user = get_user_by('id', intval($data_array['ID']));
						if ($user) return intval($user->ID);
					}
				}
				if ($c === 'email') {
					$email = isset($data_array['user_email']) ? trim((string)$data_array['user_email']) : '';
					if ($email !== '' && is_email($email)) {
						$user = get_user_by('email', $email);
						if ($user) return intval($user->ID);
					}
				}
				if ($c === 'login') {
					$login = isset($data_array['user_login']) ? trim((string)$data_array['user_login']) : '';
					if ($login !== '') {
						$user = get_user_by('login', $login);
						if ($user) return intval($user->ID);
					}
				}
			}
			return 0;
		};

		$uci_update_mode = ImportHelpers::resolve_import_update_mode( $unikey_value, $data_array['_uci_update_mode'] ?? '' );
		$existing_for_mode = $resolve_existing_user_id();
		if ( $existing_for_mode > 0 && $uci_update_mode === 'skip' ) {
			$core_instance->detailed_log[$line_number]['Message'] = 'Skipped: User already exists (SKIP mode)';
			$core_instance->detailed_log[$line_number]['state'] = 'Skipped';
			$core_instance->detailed_log[$line_number]['id'] = $existing_for_mode;
			$wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'");
			return array('ID' => $existing_for_mode, 'MODE' => 'Skipped');
		}
		

		$data_array = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_user_data_filter($data_array, $unikey_value);

		$continue = true;
		$continue = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_is_user_to_create_filter($continue, $data_array, $unikey_value);
		if (!$continue) {
			$core_instance->detailed_log[$line_number]['Message'] = "Skipped, User creation/update skipped via sm_uci_pro_is_user_to_create filter.";
			$core_instance->detailed_log[$line_number]['state'] = 'Skipped';
			$wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'");
			return array('MODE' => $mode);
		}

		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_before_user_import($data_array, $mode);
		
		if ( $mode == 'Insert' ) {
			$send_password = $data_array['user_pass'];
			unset($data_array['ID']);
			// Atomic duplicate prevention (right-before-write).
			// If user exists by email/login, switch to update to avoid last-moment duplicates.
			$pre_existing_id = $resolve_existing_user_id();
			if ( $pre_existing_id > 0 ) {
				$data_array['ID'] = $pre_existing_id;
				$this->uci_prepare_data_array_for_wp_update_user( $data_array, $pre_existing_id );
				$updated = wp_update_user( $data_array );
				if ( is_wp_error( $updated ) ) {
					$core_instance->detailed_log[$line_number]['Message'] = "Update Failed: " . $updated->get_error_message();
					$core_instance->detailed_log[$line_number]['state'] = 'Failed';
					$wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'");
					return array('MODE' => $mode);
				}
				$core_instance->detailed_log[$line_number]['Message'] = 'Updated User ID: ' . $pre_existing_id;
				$core_instance->detailed_log[$line_number]['state'] = 'Updated';
				$core_instance->detailed_log[$line_number]['id'] = $pre_existing_id;
				$wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE $unikey_name = '$unikey_value'");
				$returnArr['ID'] = $pre_existing_id;
				$returnArr['MODE'] = 'Updated';
				return $returnArr;
			}
			$uci_pass_restore = $this->uci_prepare_password_for_new_user_insert( $data_array );
			$additional_meta_info = array(
				'user_login' => $data_array['user_login'],
				'user_pass'  => $uci_pass_restore ? '' : ( $data_array['user_pass'] ?? '' ),
				'user_email' => $data_array['user_email'],
				'role'       => $data_array['role'],
			);
			$data_array['smack_uci_import'] = $additional_meta_info;

			$retID = wp_insert_user( $data_array );
			if ( ! is_wp_error( $retID ) && $uci_pass_restore ) {
				$this->uci_restore_user_pass_after_insert( $retID, $uci_pass_restore );
			}
			if ( ! is_wp_error( $retID ) ) {
				update_user_meta( $retID, 'sendPassword', $this->uci_is_stored_password_hash( (string) $send_password ) ? '' : $send_password );
			}

			$mode_of_affect = 'Inserted';
			
			if ( is_wp_error( $retID ) ) {
				$error_code = $retID->get_error_code();
				if ($error_code === 'existing_user_email' || $error_code === 'existing_user_login') {
					// Duplicate found - attempt Update instead of skipping (Mission Step 2.2)
					$existing_user = null;
					if ($error_code === 'existing_user_email') {
						$existing_user = get_user_by('email', $data_array['user_email']);
					} else {
						$existing_user = get_user_by('login', $data_array['user_login']);
					}

					if ($existing_user) {
						$data_array['ID'] = $existing_user->ID;
						$this->uci_prepare_data_array_for_wp_update_user( $data_array, (int) $existing_user->ID );
						$retID = wp_update_user($data_array);
						$mode_of_affect = 'Updated';
						if (is_wp_error($retID)) {
							// Still failed
							$core_instance = CoreFieldsImport::getInstance();
							if (!is_array($core_instance->detailed_log)) { $core_instance->detailed_log = []; }
							$core_instance->detailed_log[$line_number]['Message'] = "Update Failed: " . $retID->get_error_message();
							$core_instance->detailed_log[$line_number]['state'] = 'Failed';
							return array('MODE' => $mode);
						}
					}
				} else {
					$core_instance = CoreFieldsImport::getInstance();
					if (!is_array($core_instance->detailed_log)) { $core_instance->detailed_log = []; }
					$core_instance->detailed_log[$line_number]['Message'] = "Failed: " . $retID->get_error_message();
					$core_instance->detailed_log[$line_number]['state'] = 'Failed';
					$wpdb->get_results("UPDATE $log_table_name SET failed = $failed_count WHERE $unikey_name = '$unikey_value'");
					return array('MODE' => $mode);
				}
			}
			$core_instance = CoreFieldsImport::getInstance();
			if (!is_array($core_instance->detailed_log)) { $core_instance->detailed_log = []; }
			$core_instance->detailed_log[$line_number]['Message'] = ($mode_of_affect === 'Inserted' ? 'Inserted User ID: ' : 'Updated User ID: ') . $retID;
			$core_instance->detailed_log[$line_number]['state'] = $mode_of_affect;
			$core_instance->detailed_log[$line_number]['id'] = $retID;
			$wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE $unikey_name = '$unikey_value'");

		} else {
			if ( $mode == 'Update') {

				$existing_user_id = $resolve_existing_user_id();
				$ID_result = [];
				if ($existing_user_id > 0) {
					$object = (object)['ID' => $existing_user_id];
					$ID_result = [$object];
				}

				if(empty($user_role)){
					$id = !empty($ID_result[0]->ID) ? $ID_result[0]->ID : 0;
					
					if ($id) {
						$get_meta_value = $wpdb->prepare(
							"SELECT meta_value FROM {$wpdb->prefix}usermeta WHERE meta_key = %s AND user_id = %d",
							$wpdb->prefix . 'capabilities',
							$id
						);
						$get_meta_val   = $wpdb->get_results( $get_meta_value );
						$get_metavalue = isset($get_meta_val[0]->meta_value) ? $get_meta_val[0]->meta_value : '';
						$meta_unserialize = @unserialize($get_metavalue);
						if(!empty($meta_unserialize) && is_array($meta_unserialize)){
							$meta_unser=array_keys($meta_unserialize,1);
							if (!empty($meta_unser[0])) {
								$data_array['role'] =$meta_unser[0];
							}
						}
					}
					
				}
				if ( is_array( $ID_result ) && ! empty( $ID_result ) ) {
					$retID = $ID_result[0]->ID;
					$data_array['ID'] = $retID;
					$this->uci_prepare_data_array_for_wp_update_user( $data_array, (int) $retID );
					$updated_user = wp_update_user( $data_array );
					if (is_wp_error($updated_user)) {
						$core_instance->detailed_log[$line_number]['Message'] = "Update Failed: " . $updated_user->get_error_message();
						$core_instance->detailed_log[$line_number]['state'] = 'Failed';
						$wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'");
						return array('MODE' => $mode);
					}
					$mode_of_affect = 'Updated';

					$core_instance->detailed_log[$line_number]['Message'] = 'Updated User ID: ' . $retID;
					$core_instance->detailed_log[$line_number]['state'] = 'Updated';
					$core_instance->detailed_log[$line_number]['id'] = $retID;
					$wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE $unikey_name = '$unikey_value'");

				}else{
					// If Update mode but no ID match yet: update by email/login when possible, otherwise insert.
					$existing_user_id = $resolve_existing_user_id();
					if ( $existing_user_id > 0 ) {
						$data_array['ID'] = $existing_user_id;
						$this->uci_prepare_data_array_for_wp_update_user( $data_array, (int) $existing_user_id );
						$updated_user = wp_update_user( $data_array );
						if ( ! is_wp_error( $updated_user ) ) {
							$retID            = $existing_user_id;
							$mode_of_affect   = 'Updated';
							$core_instance->detailed_log[ $line_number ]['Message'] = 'Updated User ID: ' . $retID;
							$core_instance->detailed_log[ $line_number ]['state']    = 'Updated';
							$core_instance->detailed_log[ $line_number ]['id']       = $retID;
							$wpdb->get_results( "UPDATE $log_table_name SET updated = $updated_count WHERE $unikey_name = '$unikey_value'" );
						} else {
							$core_instance->detailed_log[ $line_number ]['Message'] = 'Update Failed: ' . $updated_user->get_error_message();
							$core_instance->detailed_log[ $line_number ]['state']  = 'Failed';
							$wpdb->get_results( "UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'" );
							return array( 'MODE' => $mode );
						}
					} else {
						$uci_pass_restore_upd = $this->uci_prepare_password_for_new_user_insert( $data_array );
						$data_array['smack_uci_import'] = array(
							'user_login' => $data_array['user_login'],
							'user_pass'  => $uci_pass_restore_upd ? '' : ( $data_array['user_pass'] ?? '' ),
							'user_email' => $data_array['user_email'],
							'role'       => $data_array['role'],
						);
						$retID = wp_insert_user( $data_array );
						if ( ! is_wp_error( $retID ) && $uci_pass_restore_upd ) {
							$this->uci_restore_user_pass_after_insert( $retID, $uci_pass_restore_upd );
						}
						$mode_of_affect = 'Inserted';
						if ( is_wp_error( $retID ) ) {
							$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: ' . $retID->get_error_message();
							$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
							$wpdb->get_results( "UPDATE $log_table_name SET skipped = $skipped_count WHERE $unikey_name = '$unikey_value'" );
							return array( 'MODE' => $mode );
						}
						$core_instance->detailed_log[ $line_number ]['Message'] = 'Inserted User ID: ' . $retID;
						$core_instance->detailed_log[ $line_number ]['state']   = 'Inserted';
						$core_instance->detailed_log[ $line_number ]['id']     = $retID;
						$wpdb->get_results( "UPDATE $log_table_name SET created = $created_count WHERE $unikey_name = '$unikey_value'" );
					}
				}
			}
		}
		$metaData = array();
		foreach ( $data_array as $daKey => $daVal ) {
			
			switch ( $daKey ) {
				case 'biographical_info' :
					$metaData['description'] = $data_array[ $daKey ];
					break;

				case 'disable_visual_editor' :
					$metaData['rich_editing'] = $data_array[ $daKey ];
					break;

				case 'enable_keyboard_shortcuts':
					$metaData['comment_shortcuts'] = $data_array[ $daKey ];
					break;

				case 'admin_color':
					$metaData['admin_color'] = $data_array[ $daKey ];
					break;

				case 'show_toolbar':
					$metaData['show_admin_bar_front'] = $data_array[ $daKey ];
					break;

				case 'syntax_highlighting':
					$metaData['syntax_highlighting'] = $data_array[ $daKey ];
					break;

				case 'language':
					$metaData['locale'] = $data_array[ $daKey ];
					break;

				case 'smack_uci_import':
					$metaData['smack_uci_import'] = $data_array[ $daKey ];
			}
		}
		
		if ( ! empty ( $metaData ) ) {
			foreach ( $metaData as $meta_key => $meta_value ) {
				update_user_meta( $retID, $meta_key, $meta_value );
			}
		}
		$user_data = get_userdata($retID);
		$user_title = isset($user_data) ? $user_data->display_name : '';
		$core_instance->detailed_log[$line_number]['user_title'] = $user_title;
		$core_instance->detailed_log[$line_number]['Email'] = $data_array['user_email'];
		$core_instance->detailed_log[$line_number]['Role'] = $data_array['role'];
		$ucisettings = get_option('sm_uci_pro_settings');
		// Do NOT send password emails during import - suppression is active (ImportEmailSuppression)
		$allow_send = apply_filters( 'smack_uci_send_password_during_import', true );
		if ( $allow_send && isset( $ucisettings['send_user_password'] ) && $ucisettings['send_user_password'] == 'true' ) {
			UsersImport::$send_user_password->send_login_credentials_to_users();
		}
		
		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_after_user_import($retID, $data_array, $mode_of_affect);
		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_after_user_import_complete($retID, $mode_of_affect, 'user');

		$returnArr['ID'] = $retID;
		$returnArr['MODE'] = $mode_of_affect;
		return $returnArr;
	}
	
	public function getRoles($capability = null) {
		global $wp_roles;
		$roles = array();
		if($capability != null) {
			foreach ( $wp_roles->roles as $rkey => $rval ) {
				$roles[ $rkey ] = '';
				for ( $cnt = 0; $cnt < count( $rval['capabilities'] ); $cnt ++ ) {
					$findval = "level_" . $cnt;
					if ( array_key_exists( $findval, $rval['capabilities'] ) ) {
						$roles[ $rkey ] = $roles[ $rkey ] . $cnt . ',';
					}
				}
			}
		} else {
			if ( ! isset( $wp_roles ) )
				$wp_roles = new \WP_Roles();
		
			$roles = $wp_roles->get_names();
		}
		return $roles;
	}
}