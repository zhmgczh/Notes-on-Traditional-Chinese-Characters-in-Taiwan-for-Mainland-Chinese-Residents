<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ProfilePressImport {
	protected static $instance = null;

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * Entry point called by SaveMapping.php.
	 *
	 * @param array  $header_array   CSV column headers
	 * @param array  $value_array    CSV row values
	 * @param array  $map            Mapping: csv_header => meta_key
	 * @param int    $post_id        WordPress user ID
	 * @param string $type
	 * @param string $hash_key
	 * @param string $gmode
	 * @param string $templatekey
	 * @param int    $line_number
	 */
	public function set_profilepress_values(
		$header_array,
		$value_array,
		$map,
		$post_id,
		$type,
		$hash_key,
		$gmode,
		$templatekey,
		$line_number
	) {

		if ( empty( $map ) || ! is_array( $map ) ) {
			$this->log_debug( 'PP IMPORT: Empty mapping', $line_number );
			return;
		}

		// Build a full row array so we can persist ALL CSV columns (even if unmapped).
		$row_all = [];
		if ( is_array( $header_array ) && is_array( $value_array ) ) {
			foreach ( $header_array as $i => $h ) {
				$h = (string) $h;
				$row_all[ $h ] = isset( $value_array[ $i ] ) ? (string) $value_array[ $i ] : '';
			}
		}

		// Mapping direction varies depending on how the UI saved it.
		// We support BOTH:
		// 1) csv_header => field_key
		// 2) field_key  => csv_header
		$data_array = [];
		foreach ( $map as $left => $right ) {
			$left  = trim( (string) $left );
			$right = trim( (string) $right );

			if ( $left === '' || $right === '' ) {
				continue;
			}

			$left_is_csv  = array_search( $left, $header_array, true ) !== false;
			$right_is_csv = array_search( $right, $header_array, true ) !== false;

			// Decide which side is the CSV header.
			$csv_header = null;
			$field_key  = null;

			if ( $left_is_csv && ! $right_is_csv ) {
				$csv_header = $left;
				$field_key  = $right;
			} elseif ( ! $left_is_csv && $right_is_csv ) {
				$csv_header = $right;
				$field_key  = $left;
			} else {
				// Fallback:
				// If both look like CSV headers (or neither), assume original direction (left is csv, right is field).
				$csv_header = $left;
				$field_key  = $right;
			}

			$index = array_search( $csv_header, $header_array, true );
			if ( $index === false ) {
				$data_array[ $field_key ] = '';
			} else {
				$data_array[ $field_key ] = isset( $value_array[ $index ] ) ? (string) $value_array[ $index ] : '';
			}
		}

		// STEP 8: Handle ALL extra fields.
		// Loop all CSV columns and add them as normalized meta keys (do not overwrite mapped keys).
		foreach ( $row_all as $csv_key => $csv_val ) {
			$normalized = $this->normalize_key( $csv_key );
			if ( $normalized === '' ) {
				continue;
			}
			if ( ! array_key_exists( $normalized, $data_array ) ) {
				$data_array[ $normalized ] = (string) $csv_val;
			}
		}

		// ------------------------------------------------------------------
		// Address fix (Option A): combine street + house number into address.
		// Expected normalized keys from CSV headers: straat, huisnr, huisnraanv.
		// ------------------------------------------------------------------
		$street = trim( (string) ( $data_array['straat'] ?? '' ) );
		$hnr    = trim( (string) ( $data_array['huisnr'] ?? '' ) );
		$hnr2   = trim( (string) ( $data_array['huisnraanv'] ?? '' ) );

		// If billing address is mapped but contains only street name, append house number.
		if ( isset( $data_array['ppress_billing_address'] ) ) {
			$current = trim( (string) $data_array['ppress_billing_address'] );
			if ( $current === '' && $street !== '' ) {
				$current = $street;
			}
			$parts = [];
			if ( $current !== '' ) {
				$parts[] = $current;
			}
			if ( $hnr !== '' ) {
				$parts[] = $hnr;
			}
			if ( $hnr2 !== '' ) {
				$parts[] = $hnr2;
			}
			if ( ! empty( $parts ) ) {
				$data_array['ppress_billing_address'] = trim( implode( ' ', $parts ) );
			}
		}

		// Fallback: Create/lookup user when post_id empty (e.g. when CORE mapping lacked user fields)
		if ( empty( $post_id ) || $post_id == 0 ) {
			$email = $data_array['user_email'] ?? $data_array['email'] ?? '';
			if ( empty( $email ) ) {
				$this->log_debug( 'PP IMPORT: Missing email', $line_number );
				return;
			}
			if ( ! is_email( $email ) ) {
				$this->log_debug( 'PP IMPORT: Invalid email', $line_number );
				return;
			}
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				$post_id = $user->ID;
			} else {
				$post_id = wp_insert_user( [
					'user_login' => sanitize_user( $email ),
					'user_email' => $email,
					'user_pass'  => wp_generate_password( 12, false ),
					'role'       => $data_array['role'] ?? 'subscriber',
				] );
				if ( is_wp_error( $post_id ) ) {
					$this->log_debug( 'PP IMPORT: User creation failed - ' . $post_id->get_error_message(), $line_number );
					return;
				}
				$this->log_debug( 'PP IMPORT: User created via fallback', $line_number );
			}
		}

		if ( empty( $post_id ) ) {
			$this->log_debug( 'PP IMPORT: Invalid user ID, skipping', $line_number );
			return;
		}

		$extension = ProfilePressExtension::getInstance();
		$this->log_debug( 'PP IMPORT: Dispatching to ProfilePressExtension', $line_number );
		$data_array['_uci_line_number'] = intval( $line_number );
		$extension->processProfilePressImport( $data_array, $post_id );

		// Subscriptions/customers are synced inside `processProfilePressImport()` to avoid duplicates.
	}

	/**
	 * Thin wrapper kept for backward compatibility (called by older code paths).
	 *
	 * @param array $data_array  meta_key => value
	 * @param int   $user_id
	 */
	public function profilepress_import_function( $data_array, $user_id ) {
		$extension = ProfilePressExtension::getInstance();
		$extension->processProfilePressImport( $data_array, $user_id );
	}

	private function log_debug( $msg, $line_number = 0 ) {
	}

	/**
	 * Normalize a CSV header / key into a safe meta key.
	 *
	 * @param string $key
	 * @return string
	 */
	private function normalize_key( $key ) {
		$key = strtolower( (string) $key );
		$key = str_replace( [ ' ', '/', '-' ], '_', $key );
		$key = trim( $key );
		$key = preg_replace( '/[^a-z0-9_\-]/', '', $key );
		return (string) $key;
	}

	/**
	 * Import / update ProfilePress membership plans (wp_ppress_plans).
	 *
	 * @param array $map Full template map or PPRESS_MEMBERSHIP_PLAN group only
	 * @return array{ID:int}
	 */
	public function import_membership_plans(
		$header_array,
		$value_array,
		$map,
		$hash_key,
		$gmode,
		$templatekey,
		$line_number
	) {
		return $this->import_ppress_table(
			'ppress_plans',
			$header_array,
			$value_array,
			$map,
			'PPRESS_MEMBERSHIP_PLAN',
			$hash_key,
			$gmode,
			$templatekey,
			$line_number
		);
	}

	/**
	 * Import / update ProfilePress orders (wp_ppress_orders).
	 *
	 * @param array $map Full template map or PPRESS_ORDER group only
	 * @return array{ID:int}
	 */
	public function import_ppress_orders(
		$header_array,
		$value_array,
		$map,
		$hash_key,
		$gmode,
		$templatekey,
		$line_number
	) {
		return $this->import_ppress_table(
			'ppress_orders',
			$header_array,
			$value_array,
			$map,
			'PPRESS_ORDER',
			$hash_key,
			$gmode,
			$templatekey,
			$line_number
		);
	}

	/**
	 * @param string $table_suffix ppress_plans|ppress_orders
	 * @param array  $map
	 * @param string $group_key    PPRESS_MEMBERSHIP_PLAN|PPRESS_ORDER
	 * @return array{ID:int}
	 */
	private function import_ppress_table(
		$table_suffix,
		$header_array,
		$value_array,
		$map,
		$group_key,
		$hash_key,
		$gmode,
		$templatekey,
		$line_number
	) {
		global $wpdb;

		$core_instance   = CoreFieldsImport::getInstance();
		$helpers_instance = ImportHelpers::getInstance();
		$log_table_name   = $wpdb->prefix . 'import_detail_log';

		$table = $wpdb->prefix . preg_replace( '/[^a-z0-9_]/', '', $table_suffix );
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: ProfilePress table not found: ' . $table_suffix;
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}

		$meta_map = isset( $map[ $group_key ] ) ? $map[ $group_key ] : $map;
		if ( empty( $meta_map ) || ! is_array( $meta_map ) ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: Invalid or empty mapping for ' . $group_key;
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}

		$row = $helpers_instance->get_header_values( $meta_map, $header_array, $value_array, $hash_key );
		if ( ! is_array( $row ) ) {
			$row = [];
		}

		$row_all = [];
		if ( is_array( $header_array ) && is_array( $value_array ) ) {
			foreach ( $header_array as $i => $h ) {
				$h                  = (string) $h;
				$row_all[ $h ] = isset( $value_array[ $i ] ) ? (string) $value_array[ $i ] : '';
			}
		}
		foreach ( $row_all as $csv_key => $csv_val ) {
			$nk = $this->normalize_key( $csv_key );
			if ( $nk === '' ) {
				continue;
			}
			if ( ! array_key_exists( $nk, $row ) ) {
				$row[ $nk ] = (string) $csv_val;
			}
		}

		if ( isset( $row['plan_id'] ) && trim( (string) $row['plan_id'] ) !== ''
			&& ( ! isset( $row['id'] ) || trim( (string) $row['id'] ) === '' ) ) {
			$row['id'] = $row['plan_id'];
		}
		if ( isset( $row['order_id'] ) && trim( (string) $row['order_id'] ) !== ''
			&& ( ! isset( $row['id'] ) || trim( (string) $row['id'] ) === '' ) ) {
			$row['id'] = $row['order_id'];
		}

		$column_info = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}`" );
		if ( empty( $column_info ) ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: Could not read table schema';
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}

		$db_cols = [];
		foreach ( $column_info as $c ) {
			if ( isset( $c->Field ) ) {
				$db_cols[ $c->Field ] = $c;
			}
		}

		$insert_data = [];
		foreach ( $row as $key => $val ) {
			if ( ! is_string( $key ) || $key === '' ) {
				continue;
			}
			if ( $key === 'plan_id' || $key === 'order_id' ) {
				continue;
			}
			if ( ! isset( $db_cols[ $key ] ) ) {
				continue;
			}
			$insert_data[ $key ] = $val;
		}

		if ( empty( $insert_data ) ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: No matching columns for import';
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}

		$pk     = 'id';
		$pk_val = isset( $insert_data['id'] ) ? (int) $insert_data['id'] : 0;

		if ( $pk_val > 0 && $wpdb->get_var( $wpdb->prepare( "SELECT `{$pk}` FROM `{$table}` WHERE `{$pk}` = %d", $pk_val ) ) ) {
			$formats = [];
			$update  = $insert_data;
			unset( $update['id'] );
			foreach ( array_keys( $update ) as $col ) {
				$formats[] = $this->ppress_column_format( $db_cols[ $col ]->Type ?? '' );
			}
			$this->ppress_coerce_row_types( $update, $db_cols );
			if ( empty( $update ) ) {
				$core_instance->detailed_log[ $line_number ]['Message'] = 'Updated ProfilePress ' . $table_suffix . ' ID: ' . $pk_val;
				$core_instance->detailed_log[ $line_number ]['state'] = 'Updated';
				$core_instance->detailed_log[ $line_number ]['id']     = $pk_val;
				return [ 'ID' => $pk_val ];
			}
			$res = $wpdb->update( $table, $update, [ $pk => $pk_val ], $formats, [ '%d' ] );
			if ( $res === false ) {
				$core_instance->detailed_log[ $line_number ]['Message'] = 'Failed to update ' . $table_suffix . ': ' . $wpdb->last_error;
				$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
				$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
				$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
				return [ 'ID' => 0 ];
			}
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Updated ProfilePress ' . $table_suffix . ' ID: ' . $pk_val;
			$core_instance->detailed_log[ $line_number ]['state']   = 'Updated';
			$core_instance->detailed_log[ $line_number ]['id']       = $pk_val;
			return [ 'ID' => $pk_val ];
		}

		unset( $insert_data['id'] );
		if ( empty( $insert_data ) ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Skipped: No columns to insert (id-only row without existing record)';
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}
		$formats = [];
		foreach ( array_keys( $insert_data ) as $col ) {
			$formats[] = $this->ppress_column_format( $db_cols[ $col ]->Type ?? '' );
		}
		$this->ppress_coerce_row_types( $insert_data, $db_cols );
		$res = $wpdb->insert( $table, $insert_data, $formats );
		if ( ! $res ) {
			$core_instance->detailed_log[ $line_number ]['Message'] = 'Failed to insert ' . $table_suffix . ': ' . $wpdb->last_error;
			$core_instance->detailed_log[ $line_number ]['state']   = 'Skipped';
			$skipped_count = $helpers_instance->update_count( $hash_key, 'hash_key' )['skipped'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$log_table_name} SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key ) );
			return [ 'ID' => 0 ];
		}
		$new_id = (int) $wpdb->insert_id;
		$core_instance->detailed_log[ $line_number ]['Message'] = 'Created ProfilePress ' . $table_suffix . ' ID: ' . $new_id;
		$core_instance->detailed_log[ $line_number ]['state']   = 'Created';
		$core_instance->detailed_log[ $line_number ]['id']      = $new_id;
		return [ 'ID' => $new_id ];
	}

	/**
	 * @param array<string,mixed> $data
	 * @param array<string,object> $db_cols
	 */
	private function ppress_coerce_row_types( array &$data, array $db_cols ) {
		foreach ( $data as $col => $val ) {
			if ( ! isset( $db_cols[ $col ] ) ) {
				continue;
			}
			$fmt = $this->ppress_column_format( $db_cols[ $col ]->Type ?? '' );
			if ( $fmt === '%d' ) {
				$data[ $col ] = ( $val === '' || $val === null ) ? 0 : (int) $val;
			} elseif ( $fmt === '%f' ) {
				$data[ $col ] = ( $val === '' || $val === null ) ? 0.0 : (float) $val;
			} else {
				$data[ $col ] = (string) $val;
			}
		}
	}

	/**
	 * @param string $mysql_type
	 * @return string
	 */
	private function ppress_column_format( $mysql_type ) {
		$t = strtolower( (string) $mysql_type );
		if ( strpos( $t, 'int' ) !== false || $t === 'bit' ) {
			return '%d';
		}
		if ( strpos( $t, 'decimal' ) !== false || strpos( $t, 'float' ) !== false || strpos( $t, 'double' ) !== false ) {
			return '%f';
		}
		return '%s';
	}
}
