<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI content generation helper.
 *
 * Relies entirely on WordPress 7.0 Global AI Settings (Settings → Connectors).
 * No plugin-level API key storage or fallback.
 *
 * @since 8.14.0
 */
class OpenAIHelper {

	/**
	 * Generate text content from a prompt.
	 *
	 * Uses WordPress 7.0 wp_ai_client_prompt() when Connectors are configured.
	 *
	 * @param string $prompt        The prompt text.
	 * @param string $max_characters Max tokens (optional).
	 * @return string|int|false Generated text, HTTP error code, or false on failure.
	 */
	public function generateContent( $prompt, $max_characters = '' ) {
		if ( ! FeatureRegistry::is_enabled( 'ai_import' ) ) {
			return false;
		}
		$prompt = is_string( $prompt ) ? trim( $prompt ) : '';
		if ( $prompt === '' ) {
			return false;
		}

		$wp_ai_available = function_exists( 'wp_ai_client_prompt' );
		$has_connector   = ConnectorsHelper::has_any_connector();

		if ( ! $wp_ai_available || ! $has_connector ) {
			return false;
		}

		return $this->generate_content_via_wp_ai( $prompt, $max_characters );
	}

	/**
	 * Generate text using WordPress AI Client.
	 *
	 * @param string $prompt        The prompt text.
	 * @param string $max_characters Max tokens (optional).
	 * @return string|int|false Generated text, HTTP error code, or false.
	 */
	private function generate_content_via_wp_ai( $prompt, $max_characters ) {

		$builder = wp_ai_client_prompt( $prompt );
		if ( $max_characters !== '' && is_numeric( $max_characters ) ) {
			$builder = $builder->using_max_tokens( (int) $max_characters );
		}
		$result = $builder->generate_text();

		if ( is_wp_error( $result ) ) {
			$code    = $result->get_error_code();
			$message = $result->get_error_message();
			return is_numeric( $code ) ? (int) $code : false;
		}

		$success = is_string( $result ) && $result !== '';
		$result_preview = is_string( $result ) ? ( strlen( $result ) > 200 ? substr( $result, 0, 200 ) . '...' : $result ) : '';
		return is_string( $result ) ? $result : false;
	}

	/**
	 * Generate image from a prompt.
	 *
	 * @param string $prompt The image prompt.
	 * @return string|int|false Image URL or data URI, HTTP error code, or false on failure.
	 */
	public function generateImage( $prompt ) {
		if ( ! FeatureRegistry::is_enabled( 'ai_import' ) ) {
			return false;
		}
		$prompt = is_string( $prompt ) ? trim( $prompt ) : '';
		if ( $prompt === '' ) {
			return false;
		}

		$wp_ai_available = function_exists( 'wp_ai_client_prompt' );
		$has_connector   = ConnectorsHelper::has_any_connector();

		if ( ! $wp_ai_available || ! $has_connector ) {
			return false;
		}

		// Check for gallery request: "gallery 3 images about..." or "3 gallery images about..."
		$image_count = 1;
		if ( preg_match( '/(?:gallery\s+(\d+)\s+images|(\d+)\s+gallery\s+images)/i', $prompt, $matches ) ) {
			$image_count = ! empty( $matches[1] ) ? (int) $matches[1] : (int) $matches[2];
			if ( $image_count < 1 ) {
				$image_count = 1;
			}
			if ( $image_count > 10 ) {
				$image_count = 10; // Cap at 10 for safety
			}
		}

		if ( $image_count > 1 ) {
			$urls = array();
			for ( $i = 0; $i < $image_count; $i++ ) {
				// We can add a slight variation to the prompt for uniqueness if needed, 
				// but usually AI seeds/variations handle this.
				$result = $this->generate_image_via_wp_ai( $prompt );
				if ( is_string( $result ) && $result !== '' ) {
					$urls[] = $result;
				}
			}
			return ! empty( $urls ) ? implode( '|', $urls ) : false;
		}

		return $this->generate_image_via_wp_ai( $prompt );
	}

	/**
	 * Generate image using WordPress AI Client.
	 *
	 * @param string $prompt The image prompt.
	 * @return string|int|false Image URL or data URI, HTTP error code, or false.
	 */
	private function generate_image_via_wp_ai( $prompt ) {
		$builder = wp_ai_client_prompt( $prompt );

		if ( ConnectorsHelper::is_configured( 'openai' ) && method_exists( $builder, 'using_provider' ) ) {
			$builder = $builder->using_provider( 'openai' );
		}

		$supported = method_exists( $builder, 'is_supported_for_image_generation' ) && $builder->is_supported_for_image_generation();

		if ( ! $supported && ! ConnectorsHelper::is_configured( 'openai' ) ) {
			return false;
		}

		$result = $builder->generate_image();

		if ( is_wp_error( $result ) ) {
			$code    = $result->get_error_code();
			$message = $result->get_error_message();
			return is_numeric( $code ) ? (int) $code : false;
		}

		$url = null;
		$data_uri = null;
		if ( is_object( $result ) && method_exists( $result, 'getUrl' ) ) {
			$url = $result->getUrl();
		}
		if ( is_object( $result ) && method_exists( $result, 'getDataUri' ) ) {
			$data_uri = $result->getDataUri();
		}

		$success = ( $url !== null && $url !== '' ) || ( $data_uri !== null && $data_uri !== '' );
		$result_preview = ( $url !== null && $url !== '' ) ? substr( $url, 0, 80 ) . '...' : ( ( $data_uri !== null && $data_uri !== '' ) ? substr( $data_uri, 0, 50 ) . '...' : '' );

		if ( $url !== null && $url !== '' ) {
			// Download the external URL and save it locally
			$file_url = $this->download_url_to_upload( $url );
			return $file_url !== null ? $file_url : $url;
		}
		if ( $data_uri !== null && $data_uri !== '' ) {
			$file_url = $this->save_data_uri_to_upload( $data_uri );
			return $file_url !== null ? $file_url : $data_uri;
		}
		return false;
	}

	/**
	 * Downloads an external URL and saves it to the WordPress uploads directory.
	 *
	 * @param string $url The image URL.
	 * @return string|null The local file URL or null on failure.
	 */
	private function download_url_to_upload( $url ) {
		$upload_dir = wp_upload_dir();
		$filename   = 'ai-' . uniqid() . '.jpg';
		$filepath   = $upload_dir['path'] . '/' . $filename;

		$response = wp_remote_get( $url, array( 'timeout' => 30 ) );
		if ( is_wp_error( $response ) ) {
			return null;
		}

		$image_contents = wp_remote_retrieve_body( $response );
		if ( empty( $image_contents ) ) {
			return null;
		}

		$fp = @fopen( $filepath, 'w' );
		if ( $fp ) {
			fwrite( $fp, $image_contents );
			fclose( $fp );
			return $upload_dir['url'] . '/' . $filename;
		}

		return null;
	}

	/**
	 * Save data URI (base64 image) to WordPress uploads and return the URL.
	 *
	 * MediaHandling expects http/https URLs; data URIs are not supported.
	 *
	 * @param string $data_uri Data URI like data:image/png;base64,iVBORw0...
	 * @return string|null File URL or null on failure.
	 */
	private function save_data_uri_to_upload( $data_uri ) {
		if ( ! is_string( $data_uri ) || strpos( $data_uri, 'data:image' ) !== 0 ) {
			return null;
		}
		if ( ! preg_match( '/^data:image\/(\w+);base64,(.+)$/', $data_uri, $m ) ) {
			return null;
		}
		$ext    = strtolower( $m[1] );
		$ext    = ( $ext === 'jpeg' ) ? 'jpg' : $ext;
		$binary = base64_decode( $m[2], true );
		if ( $binary === false || strlen( $binary ) < 100 ) {
			return null;
		}
		$upload = wp_upload_dir();
		if ( ! empty( $upload['error'] ) ) {
			return null;
		}
		$subdir = $upload['subdir'];
		$basedir = $upload['basedir'];
		$baseurl = $upload['baseurl'];
		$dir = $basedir . $subdir;
		if ( ! wp_mkdir_p( $dir ) ) {
			return null;
		}
		$filename = 'ai-' . uniqid() . '.' . $ext;
		$filepath = $dir . '/' . $filename;
		if ( file_put_contents( $filepath, $binary ) === false ) {
			return null;
		}
		return $baseurl . $subdir . '/' . $filename;
	}
}
