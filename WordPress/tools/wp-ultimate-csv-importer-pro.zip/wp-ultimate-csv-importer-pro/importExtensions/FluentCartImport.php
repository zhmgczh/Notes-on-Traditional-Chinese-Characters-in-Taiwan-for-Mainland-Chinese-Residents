<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
    exit;

use FluentCart\App\Models\Customer;
use FluentCart\App\Models\CustomerAddresses;
use FluentCart\App\Models\CustomerMeta;
use FluentCart\App\Services\Helpers;
use Illuminate\Support\Str;
class FluentCartImport {

    private static $fluentcart_instance = null;

    public static function getInstance() {
        if (FluentCartImport::$fluentcart_instance === null) {
            FluentCartImport::$fluentcart_instance = new FluentCartImport;
        }
        return FluentCartImport::$fluentcart_instance;
    }

    /**
     * Set FluentCart values and process import
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param int $post_id Post ID
     * @param string $type Import type
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function set_fluentcart_values(
        $header_array,
        $value_array,
        $map,
        $post_id,
        $type,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        $helpers_instance = ImportHelpers::getInstance();

        $post_values = $helpers_instance->get_header_values(
            $map,
            $header_array,
            $value_array
        );

        $this->fluentcart_import_function(
            $post_values,
            $type,
            $post_id,
            $header_array,
            $value_array,
            $hash_key,
            $gmode,
            $templatekey,
            $line_number
        );
    }

    /**
     * Main FluentCart import function
     *
     * @param array $data_array Mapped data
     * @param string $importas Import type
     * @param int $pID Post ID
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return array Created fields
     */
    public function fluentcart_import_function(
        $data_array,
        $importas,
        $pID,
        $header_array,
        $value_array,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb;
        if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
            return [];
        }

        $createdFields = array_keys($data_array);
        $fluentcart = [];

        // Map common fields
        $mapping = [
            'product_id' => ['product_id'],
            'product_name' => ['product_name', 'post_title'],
            'post_title' => ['post_title', 'product_name'],
            'post_content' => ['post_content', 'product_description', 'description'],
            'post_excerpt' => ['post_excerpt', 'short_description'],
            'post_status' => ['post_status', 'status'],
            'sku' => ['sku'],
            'price' => ['price'],
            'sale_price' => ['sale_price'],
            'stock_enabled' => ['stock_enabled'],
            'stock_quantity' => ['stock_quantity'],
            'allow_purchase_out_of_stock' => ['allow_purchase_out_of_stock', 'allow_backorders'],
            'tax_enabled' => ['tax_enabled'],
            'tax_status' => ['tax_status'],
            'featured_image' => ['featured_image', 'thumbnail_id'],
            'gallery_images' => ['gallery_images'],
            'product_type' => ['product_type'],
            'recurring_interval' => ['recurring_interval'],
            'recurring_period' => ['recurring_period'],
            'recurring_price' => ['recurring_price'],
            'variants' => ['variants'],
            'product_categories' => ['product_categories'],
            'product_tags' => ['product_tags'],
            'download_files' => ['download_files'],
            'product_meta' => ['product_meta']
        ];

        foreach ($mapping as $key => $aliases) {
            foreach ($aliases as $alias) {
                if (isset($data_array[$alias]) && !empty($data_array[$alias])) {
                    $fluentcart[$key] = $data_array[$alias];
                    break;
                }
            }
        }

        // Handle product creation/update
        if ($importas === 'FLUENTCART_PRODUCTS') {
            $this->import_product($fluentcart, $pID, $hash_key, $line_number,$data_array);
        }

        return $createdFields;
    }

   
    /**
     * Import FluentCart Product
     *
     * @param array $data Product data
     * @param int $pID Post ID
     * @param string $hash_key Import hash key
     * @param int $line_number Line number
     * @return void
     */
    private function import_product($data, $pID, $hash_key, $line_number, $data_array) {

        global $wpdb;
        $download_id_arr = [];
        $fulfillment_type       = $data_array['fulfillment_type'];
        $min_price              = $data_array['min_price'];
        $max_price              = $data_array['max_price'];
        $default_variation_id   = $data_array['default_variation_id'];
        $default_media          = $data_array['default_media'];
        $manage_stock           = $data_array['manage_stock'];
        $stock_availability     = $data_array['stock_availability'];
        $variation_type         = $data_array['variation_type'];
        $manage_downloadable    = $data_array['manage_downloadable'];
        $other_info             = $data_array['other_info'];
        $created_at             = $data_array['created_at'];
        $updated_at             = $data_array['updated_at'];

        if( empty($fulfillment_type)) return;

        $product_details_table_data = [
            'post_id'               => (int)$pID,
            'fulfillment_type'      =>  $fulfillment_type,
            'min_price'             =>  $min_price,
            'max_price'             =>  $max_price,
            'default_variation_id'  =>  (int)$default_variation_id,
            'default_media'         =>  empty($default_media) ? null : $default_media,
            'manage_stock'          =>  $manage_stock,
            'stock_availability'    =>  $stock_availability,
            'variation_type'        =>  $variation_type,
            'manage_downloadable'   =>  $manage_downloadable,
            'other_info'            =>  empty($other_info) ? null : $other_info,
            'created_at'            =>  $created_at,
            'updated_at'            =>  $updated_at
        ];
        $product_details_table_format = ['%d','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s'];

        $fct_product_details_table = $wpdb->prefix.'fct_product_details';
        
        $exists = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$fct_product_details_table} WHERE post_id = %d",(int)$pID));

        $mode = $wpdb->get_var("SELECT mode FROM {$table_name} WHERE hash_key = '$hash_key'");

        if( $mode == 'Insert'){
            $wpdb->insert(
                $fct_product_details_table,
                $product_details_table_data,
                $product_details_table_format
            );
        }else{
            unset($product_details_table_data['post_id']);
            unset($product_details_table_format[0]);

            $wpdb->update(
                $fct_product_details_table,
                $product_details_table_data,
                ['post_id' => $pID],
                $product_details_table_format,
                ['%d']
            );
        }

        // fct_product_variations_table
        $fct_product_variations_table = $wpdb->prefix.'fct_product_variations';

        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM
                {$fct_product_variations_table}
                WHERE post_id = %s",
                $pID
            )
        );



        $variation_id = explode('|', $data_array['variation_id']);
        $media_id = explode('|', $data_array['media_id']);
        $serial_index = explode('|', $data_array['serial_index']);
        $sold_individually = explode('|', $data_array['sold_individually']);
        $variation_titles = explode('|', $data_array['variation_title']);
        $variation_identifier = explode('|', $data_array['variation_identifier']);
        $variation_manage_stock = explode('|', $data_array['variation_manage_stock']);
        $payment_type = explode('|', $data_array['payment_type']);
        $stock_status = explode('|', $data_array['stock_status']);
        $backorders = explode('|', $data_array['backorders']);
        $total_stock = explode('|', $data_array['total_stock']);
        $on_hold = explode('|', $data_array['on_hold']);
        $committed = explode('|', $data_array['committed']);
        $available = explode('|', $data_array['available']);
        $item_status = explode('|', $data_array['item_status']);
        $manage_cost = explode('|', $data_array['manage_cost']);
        $item_price = explode('|', $data_array['item_price']);
        $item_cost = explode('|', $data_array['item_cost']);
        $compare_price = explode('|', $data_array['compare_price']);
        $shipping_class = explode('|', $data_array['shipping_class']);
        $variation_other_info = explode('|', $data_array['variation_other_info']);
        $variation_downloadable = explode('|', $data_array['variation_downloadable']);

        $object_type = explode('|', $data_array['object_type']);
        $meta_key = explode('|', $data_array['meta_key']);
        $meta_value = explode('|', $data_array['meta_value']);

        
        foreach($variation_titles as $i => $variation_title){
            $fct_product_variations_data = [
                'post_id'               => $pID,
                'media_id'              => $media_id[$i],
                'serial_index'          => $serial_index[$i],
                'sold_individually'     => $sold_individually[$i],
                'variation_title'       => $variation_title,
                'variation_identifier'  => $variation_identifier[$i],
                'manage_stock'          => $variation_manage_stock[$i],
                'payment_type'          => $payment_type[$i],
                'stock_status'          => $stock_status[$i],
                'backorders'            => $backorders[$i],
                'total_stock'           => $total_stock[$i],
                'on_hold'               => $on_hold[$i],
                'committed'             => $committed[$i],
                'available'             => $available[$i],
                'fulfillment_type'      => $fulfillment_type,
                'item_status'           => $item_status[$i],
                'manage_cost'           => $manage_cost[$i],
                'item_price'            => $item_price[$i],
                'item_cost'             => $item_cost[$i],
                'compare_price'         => $compare_price[$i],
                'shipping_class'        => $shipping_class[$i],
                'other_info'            => $variation_other_info[$i],
                'downloadable'          => $variation_downloadable[$i],
                'created_at'            => $created_at,
                'updated_at'            => $updated_at
            ];
            $fct_product_variations_format = [
                '%d', //post_id
                '%d', //media_id
                '%d', //serial_index
                '%d', //sold_individually
                '%s', //variation_title
                '%s', //variation_identifier
                '%d', //manage_stock
                '%s', //payment_type
                '%s', //stock_status
                '%d', //backorders
                '%d', //total_stock
                '%d', //on_hold
                '%d', //committed
                '%d', //available
                '%s', //fulfillment_type
                '%s', //item_status
                '%s', //manage_cost
                '%d', //item_price
                '%d', //item_cost
                '%d', //compare_price
                '%s', //shipping_class
                '%s', //other_info
                '%s', //downloadable
                '%s', //created_at
                '%s'  //updated_at
            ]; 
            if( $mode == 'Insert' ){
                $wpdb->insert(
                    $fct_product_variations_table,
                    $fct_product_variations_data,
                    $fct_product_variations_format
                );

                $inserted_id = $wpdb->insert_id;
                $download_id_arr[$variation_id[$i]] = $inserted_id;

                $fct_product_meta_table = $wpdb->prefix.'fct_product_meta';
                $fct_product_meta_data = [
                    'object_id'     => $inserted_id,
                    'object_type'   => $object_type[$i],
                    'meta_key'      => $meta_key[$i],
                    'meta_value'    => $meta_value[$i],
                    'created_at'    => $created_at[$i],
                    'updated_at'    => $updated_at[$i]
                ];
                $fct_product_meta_format = [
                    '%d', // object_id
                    '%s', // object_type
                    '%s', // meta_key
                    '%s', // meta_value
                    '%s', // created_at
                    '%s' // updated_at

                ];

                $wpdb->insert(
                    $fct_product_meta_table,
                    $fct_product_meta_data,
                    $fct_product_meta_format
                );


            }else{

                $wpdb->update(
                    $fct_product_variations_table,
                    $fct_product_variations_data,
                    $fct_product_variations_format,
                    ['id' => $variation_id[$i]],
                    ['%d']

                );
                $download_id_arr[$variation_id[$i]] = $variation_id[$i];
                $fct_product_meta_table = $wpdb->prefix.'fct_product_meta';
                $fct_product_meta_data = [
                    'object_type'   => $object_type[$i],
                    'meta_key'      => $meta_key[$i],
                    'meta_value'    => $meta_value,
                    'created_at'    => $created_at[$i],
                    'updated_at'    => $update_at[$i]
                ];
                $fct_product_meta_format = [
                    '%s', // object_type
                    '%s', // meta_key
                    '%s', // meta_value
                    '%s', // created_at
                    '%s' // updated_at

                ];

                $wpdb->update(
                    $fct_product_meta_table,
                    $fct_product_meta_data,
                    ['object_id' => $variation_id[$i]],
                    $fct_product_meta_format,
                    ['%d']
                );
            }
        }
        //fct_product_downloads table
        $fct_product_downloads_table = $wpdb->prefix.'fct_product_downloads';
    
        $download_product_variation_id = $data_array['download_product_variation_id'];
        $download_identifier = $data_array['download_identifier'];
        $download_title = $data_array['download_title'];
        $download_type = $data_array['download_type'];
        $download_driver = $data_array['download_driver'];
        $download_file_name = $data_array['download_file_name'];
        $download_file_path = $data_array['download_file_path'];
        $download_file_url = $data_array['download_file_url'];
        $download_file_size = $data_array['download_file_size'];
        $download_settings = $data_array['download_settings'];
        $download_serial = $data_array['download_serial'];
        $download_created_at = $data_array['download_created_at'];
        $download_updated_at = $data_array['download_updated_at'];

        // Explode each variable if it contains pipe-separated values
        $download_product_variation_id = isset($download_product_variation_id) ? explode('|', $download_product_variation_id) : [];
        $download_identifiers = isset($download_identifier) ? explode('|', $download_identifier) : [];
        $download_title = isset($download_title) ? explode('|', $download_title) : [];
        $download_type = isset($download_type) ? explode('|', $download_type) : [];
        $download_driver = isset($download_driver) ? explode('|', $download_driver) : [];
        $download_file_name = isset($download_file_name) ? explode('|', $download_file_name) : [];
        $download_file_path = isset($download_file_path) ? explode('|', $download_file_path) : [];
        $download_file_url = isset($download_file_url) ? explode('|', $download_file_url) : [];
        $download_file_size = isset($download_file_size) ? explode('|', $download_file_size) : [];
        $download_settings = isset($download_settings) ? explode('|', $download_settings) : [];
        $download_serial = isset($download_serial) ? explode('|', $download_serial) : [];
        $download_created_at = isset($download_created_at) ? explode('|', $download_created_at) : [];
        $download_updated_at = isset($download_updated_at) ? explode('|', $download_updated_at) : [];

        if( $download_identifiers == []) return;

        $wpdb->query("DELETE FROM {$fct_product_downloads_table} WHERE post_id = {$pID}",);

        foreach($download_identifiers as $i => $download_identifier){

            if(empty($download_identifier))return;
            $key = trim($download_product_variation_id[$i], '[]');
            if (isset($download_id_arr[$key])) {
                $value = $download_id_arr[$key];
                $download_product_variation_id[$i] = '['.trim($value).']';
            }
            $fct_product_downloads_data =[
                'post_id'               => $pID,
                'product_variation_id'  => $download_product_variation_id[$i],
                'download_identifier'   => $download_identifier,
                'title'                 => $download_title[$i],
                'type'                  => $download_type[$i],
                'driver'                => $download_driver[$i],
                'file_name'             => $download_file_name[$i],
                'file_path'             => $download_file_path[$i],
                'file_url'              => $download_file_url[$i],
                'settings'              => $download_settings[$i],
                'serial'                => $download_serial[$i],
                'created_at'             => $download_created_at[$i],
                'updated_at'            => $download_updated_at[$i]
            ];
            $fct_product_downloads_format = [
                '%d', // post_id
                '%s', // product_variation_id
                '%d', // download_identifier
                '%s', // title
                '%s', // type
                '%s', // driver
                '%s', // file_name
                '%s', // file_path
                '%s', // file_url
                '%s', // settings
                '%d', // serial
                '%s', // crated_at
                '%s', // updated_at

            ];
            $wpdb->insert(
                $fct_product_downloads_table,
                $fct_product_downloads_data,
                $fct_product_downloads_format
            );
        }

        
    }

    /**
     * Import FluentCart Products
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param int $post_id Post ID
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_products(
        $header_array,
        $value_array,
        $map,
        $post_id,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        $this->set_fluentcart_values(
            $header_array,
            $value_array,
            $map,
            $post_id,
            'FLUENTCART_PRODUCTS',
            $hash_key,
            $gmode,
            $templatekey,
            $line_number
        );
    }

    /**
     * Import FluentCart Orders
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
   public function import_orders(
    $header_array,
    $value_array,
    $map,
    $check,
    $mode,
    $hash_key,
    $gmode,
    $templatekey,
    $line_number
    ){
        global $wpdb, $core_instance;

        if (!is_plugin_active('fluent-cart/fluent-cart.php')) return;
        $update_count = $helpers->update_count($hash_key,'hash_key');

        
        
        $helpers = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        $data = $helpers->get_header_values($map, $header_array, $value_array);

        $uuid=$data['uuid'] ?? null;

        if(isset($check)){
            if($check == 'uuid'){
                $id = \FluentCart\App\Models\Order::where('uuid', $uuid)->value('id');
                if(isset($id)){
                    $wpdb->query($wpdb->prepare(
                        "UPDATE $log_table_name SET skipped=%d WHERE hash_key=%s",
                        $update_count['skipped'],
                        $hash_key
                    ));
                    if (isset($core_instance)) {
                        $core_instance->detailed_log[$line_number] = [
                            'Message' => 'Skipped: Customer email or ID is required for SureCart orders',
                            'state' => 'Skipped'
                        ];
                    }            
                }
                    return;
            }
        }
        /* ===== ORDER ===== */

        if($mode=='Insert'){

            $order=\FluentCart\App\Models\Order::create([

                'receipt_number'=>$data['receipt_number'],
                'invoice_no'=>$data['invoice_no'],
                'customer_id'=>intval($data['customer_id']),

                'status'=>$data['order_status'],
                'payment_status'=>$data['payment_status'],
                'payment_method'=>$data['payment_method'],
                'payment_method_title'=>$data['payment_method_title'],
                'currency'=>$data['currency'],

                'type'=>$data['order_type'],
                'mode'=>$data['order_mode'],
                'fulfillment_type'=>$data['order_fulfillment_type'],

                'rate'=>1,
                'tax_behavior'=>0
            ]);

        }else{

            $order=\FluentCart\App\Models\Order::where('uuid',$uuid)->first();
            if(!$order) return;

            $order->update([
                'status'=>$data['order_status'],
                'payment_status'=>$data['payment_status']
            ]);
        }

        /* ===== ITEMS ===== */

        \FluentCart\App\Models\OrderItem::where('order_id',$order->id)->delete();

        $items=explode('|',$data['ordered_items']);
        // $items=json_decode($data['ordered_items'],true);
        // $this->custom_log($items);



        foreach($items as $itm){
            $temp = explode(';',$itm);
            $item = [];
            foreach ($temp as $pair) {
                $item_data = explode('->', $pair, 2);
                    $item[trim($item_data[0])] = trim($item_data[1]);
            }
            $post=get_post($item['post_id']);

            $other_info = $item['other_info'] ?? '{}';
            if (is_array($other_info) || is_object($other_info)) {
                $other_info = wp_json_encode($other_info);
            }

            // Ensure JSON string for line_meta
            $line_meta = $item['line_meta'] ?? [];
            if (is_array($line_meta) || is_object($line_meta)) {
                $line_meta = wp_json_encode($line_meta);
            }

            // safety fallback
            if ($line_meta === '' || $line_meta === null) {
                $line_meta = '[]';
            }
            $format = [
                '%d', // order_id
                '%d', // post_id
                '%d', // object_id
                '%d', // cart_index
                '%s', // post_title
                '%s', // title
                '%s', // fulfillment_type
                '%s', // payment_type
                '%d', // quantity
                '%d', // unit_price
                '%d', // cost
                '%d', // subtotal
                '%d', // tax_amount
                '%d', // shipping_charge
                '%d', // discount_total
                '%d', // line_total
                '%d', // refund_total
                '%d', // rate  <-- THIS WAS THE MISSING INTEGER BIND
                '%s', // other_info
                '%s', // line_meta
                '%d', // fulfilled_quantity
                '%s', // created_at
                '%s'  // updated_at
            ];
            $fct_data = [
                'order_id' => (int) $order->id,
                'post_id' => (int) $item['post_id'],
                'object_id' => (int) $item['object_id'],
                'cart_index' => abs(crc32($order->id . microtime(true))),

                'post_title' => $post->post_title,
                'title' => $post->post_title,

                'fulfillment_type' => $order->fulfillment_type,
                'payment_type' => $item['payment_type'],

                'quantity' => (int) $item['quantity'],
                'unit_price' => (int) $item['unit_price'],
                'cost' => 0,
                'subtotal' => (int) $item['subtotal'],
                'tax_amount' => (int) $item['tax_amount'],
                'shipping_charge' => (int) $item['shipping_charge'],
                'discount_total' => (int) $item['discount_total'],
                'line_total' => (int) $item['line_total'],
                'refund_total' => 0,
                'rate' => 1,

                // IMPORTANT: always strings
                'other_info' => $other_info,
                'line_meta' => $line_meta,

                'fulfilled_quantity' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ];
            $wpdb->insert(
                $wpdb->prefix . 'fct_order_items',
                $fct_data,
                $format
            );
        }


        /* ===== META ===== */

        if(!empty($data['order_meta'])){
            foreach(explode('|',$data['order_meta']) as $m){
                list($k,$v)=explode(':',$m,2);
                \FluentCart\App\Models\OrderMeta::updateOrCreate(
                    ['order_id'=>$order->id,'meta_key'=>$k],
                    ['meta_value'=>json_decode($v,true)]
                );
            }
        }

        /* ===== TRANSACTION ===== */

        \FluentCart\App\Models\OrderTransaction::where('order_id',$order->id)->delete();

        $txns=json_decode($data['transactions'],true) ?: [];

        foreach($txns as $txn){
            \FluentCart\App\Models\OrderTransaction::create([
                'order_id'=>$order->id,
                'order_type'=>$order->type,
                'transaction_type'=>'charge',
                'payment_method'=>$txn['payment_method'],
                'payment_mode'=>$order->mode,
                'status'=>$txn['status'],
                'currency'=>$txn['currency'],
                'total'=>$txn['total'],
                'rate'=>1,
                'uuid'=>md5(uniqid())
            ]);
        }

        $items_query = \FluentCart\App\Models\OrderItem::where('order_id', $order->id);
        $subtotal = $items_query->sum('subtotal');  // Sum of item subtotals
        $tax_total = $items_query->sum('tax_amount');  // Item tax
        $discount_total = $items_query->sum('discount_total');  // Item discounts (negative?)
        $tax_total = $items_query->sum('tax_amount');

        $shipping_total = \FluentCart\App\Models\OrderItem::where('order_id', $order->id)->sum('shipping_charge');
        $total_amount = $subtotal - $discount_total + $shipping_total + $tax_total + $shipping_tax;
        /* ===== UPDATE ORDER TOTAL ===== */
        $order->update([
            'subtotal' => $subtotal,
            'tax_total' => $tax_total,
            'shipping_total' => $shipping_total,
            'shipping_tax' => $shipping_tax,
            'total_amount' => $total_amount,
            'total_paid' => $data['total_paid'],  // If fully paid; use transactions for partial
        ]);        
        /* ===== ADDRESS ===== */

        \FluentCart\App\Models\OrderAddress::updateOrCreate(
            ['order_id'=>$order->id,'type'=>'billing'],
            [
                'name'=>$data['billing_name'],
                'address_1'=>$data['billing_address_1'],
                'address_2'=>$data['billing_address_2'],
                'city'=>$data['billing_city'],
                'state'=>$data['billing_state'],
                'postcode'=>$data['billing_postcode'],
                'country'=>$data['billing_country']
            ]
        );

        \FluentCart\App\Models\OrderAddress::updateOrCreate(
            ['order_id'=>$order->id,'type'=>'shipping'],
            [
                'name'=>$data['shipping_name'],
                'address_1'=>$data['shipping_address_1'],
                'address_2'=>$data['shipping_address_2'],
                'city'=>$data['shipping_city'],
                'state'=>$data['shipping_state'],
                'postcode'=>$data['shipping_postcode'],
                'country'=>$data['shipping_country']
            ]
        );

        /* ================= IMPORT LOG ================= */


        if($mode=='Insert'){
            $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET created=%d WHERE hash_key=%s",
                $update_count['created'],$hash_key
            ));
        }else{
            $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET updated=%d WHERE hash_key=%s",
                $update_count['updated'],$hash_key
            ));
        }
        if (isset($core_instance)) {
            $core_instance->detailed_log[$line_number] = [
                'Message' => 'Created SureCart Order ID: ' . $order_id . ' for customer: ' . $customer_email,
                'state' => 'Created',
                'id' => $order_id,
                'status' => 'publish',
                'adminLink' => get_edit_post_link($order_id, true)
            ];
        }
    }

    /**
     * Import FluentCart Customers
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $mode Import mode
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @param string $check Check type (default 'uuid')
     * @return void
     */
    public function import_customers(
        $header_array,
        $value_array,
        $map,
        $mode,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number,
        $check = 'uuid'
    ) {
        global $wpdb,$core_instance;

        if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";
        // Get mapped values
        $customer_data = $helpers_instance->get_header_values($map, $header_array, $value_array);
        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        // $this->custom_log($customer_data);
        $data = $customer_data;
        // Extract customer fields
        //`wp_fct_customers` data


        $wp_user_data = explode('|',$data['wp_core_user_data']);
        $insert_wp_user = [];
        foreach($wp_user_data as $key => $value){
            $userdata = explode(':', $value);
            $insert_wp_user[$userdata[0]] = $userdata[1]; 
        }
        $existing_user = get_user_by('login', $insert_wp_user['user_login']);
        $check = strtolower($check);

        if($mode == 'Insert')
        {
            if (!$existing_user) {

                // WP requires a password to create user
                $temp_password = wp_generate_password(32, true, true);

                $user_id = wp_create_user(
                    $insert_wp_user['user_login'],
                    $temp_password,
                    $insert_wp_user['user_email']
                );

                if (is_wp_error($user_id)) {
                    exit;
                }

                // update profile fields
                wp_update_user([
                    'ID' => $user_id,
                    'display_name' => $insert_wp_user['display_name'],
                    'user_nicename' => $insert_wp_user['user_nicename'],
                    'user_url' => $insert_wp_user['user_url']
                ]);

                // assign default role
                $wp_user = new \WP_User($user_id);
                $wp_user->set_role('subscriber');
            }else{
                 if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Skipped: WP User Already exists',
                        'state' => 'Skipped'
                    ];
                }
                return;
            }
            // ---------------------------------------------------
            // CHECK CUSTOMER USING UUID
            // ---------------------------------------------------
            
            $customer = Customer::where($check, $customer_data[$check])->first();

            // If already exists → STOP
            if($customer){
                if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Skipped: Customer Already exists',
                        'state' => 'Skipped'
                    ];
                }
                $wpdb->query($wpdb->prepare(
                    "UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s",
                    $update_count['skipped'],
                    $hash_key
                ));
                return;
            }

            // ---------------------------------------------------
            // CREATE NEW CUSTOMER
            // ---------------------------------------------------
            $customer = new Customer();
            $customer->timestamps = false;

            // generate new uuid (important)
            $customer->uuid        = \wp_generate_uuid4();

            $customer->user_id     = $user_id;
            $customer->email       = $customer_data['login_email'];
            $customer->first_name  = $customer_data['first_name'];
            $customer->last_name   = $customer_data['last_name'];
            $customer->country     = $customer_data['country'];
            $customer->state       = $customer_data['state'];
            $customer->city        = $customer_data['city'];
            $customer->postcode    = $customer_data['postcode'];

            $customer->created_at  = $customer_data['created_at'];
            $customer->updated_at  = $customer_data['updated_at'];

            $customer->save();

            $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
                $update_count['created'],
                $hash_key
            ));
            $customer_link = admin_url('admin.php?page=fluent-cart-admin#/customers/'.$customer->id);

            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message'   => 'Created FluentCart Customer ID: '.$customer->id.' ('.$customer->email.')',
                    'state'     => 'Created',
                    'id'        => $customer->id,
                    'status'    => 'active',
                    'adminLink' => $customer_link
                ];
            }
        }



        elseif($mode == 'Update')
        {

            if ($existing_user) {
                $user_id = $existing_user->ID;

                wp_update_user([
                    'ID' => $user_id,
                    'user_email' => $insert_wp_user['user_email'],
                    'display_name' => $insert_wp_user['display_name'],
                    'user_nicename' => $insert_wp_user['user_nicename'],
                    'user_url' => $insert_wp_user['user_url']
                ]);
            }else{
                if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Skipped: WP User Not Found',
                        'state' => 'Skipped'
                    ];
                }
                return;
            }
            // ---------------------------------------------------
            // FIND CUSTOMER USING UUID
            // ---------------------------------------------------
            $customer = Customer::where($check, $customer_data[$check])->first();

            // If not exists → STOP
            if(!$customer){
                if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Skipped: Customer Not Found',
                        'state' => 'Skipped'
                    ];
                }
                $wpdb->query($wpdb->prepare(
                    "UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s",
                    $update_count['skipped'],
                    $hash_key
                ));
                return;
            }

            $customer->timestamps = false;

            // ---------------------------------------------------
            // UPDATE CUSTOMER DETAILS
            // ---------------------------------------------------
            $customer->email       = $customer_data['login_email'];
            $customer->first_name  = $customer_data['first_name'];
            $customer->last_name   = $customer_data['last_name'];
            $customer->country     = $customer_data['country'];
            $customer->state       = $customer_data['state'];
            $customer->city        = $customer_data['city'];
            $customer->postcode    = $customer_data['postcode'];
            $customer->updated_at  = $customer_data['updated_at'];

            $customer->save();

            $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET updated = %d WHERE hash_key = %s",
                $update_count['updated'],
                $hash_key
            ));

            $customer_link = admin_url('admin.php?page=fluent-cart-admin#/customers/'.$customer->id);

            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message'   => 'Updated FluentCart Customer ID: '.$customer->id.' ('.$customer->email.')',
                    'state'     => 'Updated',
                    'id'        => $customer->id,
                    'status'    => 'active',
                    'adminLink' => $customer_link
                ];
            }

        }


        // =====================================================
        // COMMON PART (RUNS FOR BOTH INSERT & UPDATE)
        // ADDRESS + META
        // =====================================================

        if(!empty($customer))
        {

            // ---------------- ADDRESS SPLIT ----------------
            $types      = explode('|', $customer_data['address_type']);
            $names      = explode('|', $customer_data['address_name']);
            $line1      = explode('|', $customer_data['address_1']);
            $line2      = explode('|', $customer_data['address_2']);
            $city       = explode('|', $customer_data['address_city']);
            $state      = explode('|', $customer_data['address_state']);
            $status      = explode('|', $customer_data['address_status']);
            $country    = explode('|', $customer_data['address_country']);
            $postcode   = explode('|', $customer_data['address_postcode']);
            $phone      = explode('|', $customer_data['address_phone']);
            $email      = explode('|', $customer_data['address_email']);
            $addressMeta= explode('|', $customer_data['address_meta']);
            $created    = explode('|', $customer_data['address_created_at']);
            $updated    = explode('|', $customer_data['address_updated_at']);
            $is_primary = explode('|', $customer_data['address_is_primary']);
            $label      = explode('|', $customer_data['address_label']);


            // ---------------- ADDRESS INSERT/UPDATE ----------------
            foreach($types as $i => $type)
            {

                $address = CustomerAddresses::where('customer_id', $customer->id)->where('type', $type)->first();

                if(!$address){
                    $address = new CustomerAddresses();
                    $address->customer_id = $customer->id;
                    $address->type = $type;
                }


                $address->label         = $label[$i] ?? 'Home';
                $address->name          = $names[$i] ?? '';
                $address->address_1     = $line1[$i] ?? '';
                $address->address_2     = $line2[$i] ?? '';
                $address->city          = $city[$i] ?? '';
                $address->state         = $state[$i] ?? '';
                $address->country       = $country[$i] ?? '';
                $address->postcode      = $postcode[$i] ?? '';
                $address->email         = $email[$i] ?? '';
                $address->phone         = $phone[$i] ?? '';
                $address->status        = $status[$i] ?? 'active';
                $address->is_primary   = (int)($is_primary[$i] ?? 0);
                $address->meta         = json_decode($addressMeta[$i] ?? '{}',true);


                $address->save();
            }


            // ---------------- CUSTOMER META ----------------
            if(!empty($customer_data['meta_key']))
            {
                $meta_keys   = explode('|', $customer_data['meta_key']);
                $meta_values = explode('|', $customer_data['meta_value']);
                $meta_c      = explode('|', $customer_data['meta_created_at']);
                $meta_u      = explode('|', $customer_data['meta_updated_at']);

                foreach($meta_keys as $i => $key)
                {
                    if(!$key) continue;

                    $meta = CustomerMeta::where('customer_id', $customer->id)
                            ->where('meta_key', $key)
                            ->first();

                    if(!$meta){
                        $meta = new CustomerMeta();
                        $meta->customer_id = $customer->id;
                        $meta->meta_key = $key;
                    }

                    $meta->timestamps = false;
                    $meta->meta_value = $meta_values[$i] ?? '';
                    $meta->created_at = $meta_c[$i] ?? current_time('mysql');
                    $meta->updated_at = $meta_u[$i] ?? current_time('mysql');

                    $meta->save();
                }
            }

            // Clear FluentCart cache
            // Helpers::clearCustomerCache($customer->id);
            try {
                //code...
                wp_cache_delete('fc_customer_'.$customer->id, 'fluentcart');
                delete_transient('fc_customer_'.$customer->id);
                do_action('fluentcart_clear_cache');
            } catch (\Throwable $th) {
            }
        }

        
    }

    /**
     * Import FluentCart Subscriptions
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_subscriptions(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb;

        if (!is_plugin_active('fluentcart/fluentcart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values
        $subscription_data = $helpers_instance->get_header_values($map, $header_array, $value_array);

        // Extract subscription fields
        $customer_email = isset($subscription_data['customer_email']) ? sanitize_email($subscription_data['customer_email']) : '';
        $customer_id = isset($subscription_data['customer_id']) ? intval($subscription_data['customer_id']) : 0;
        $product_id = isset($subscription_data['product_id']) ? intval($subscription_data['product_id']) : 0;
        $order_id = isset($subscription_data['order_id']) ? intval($subscription_data['order_id']) : 0;
        $subscription_status = isset($subscription_data['subscription_status']) ? sanitize_text_field($subscription_data['subscription_status']) : 'active';
        $interval = isset($subscription_data['interval']) ? intval($subscription_data['interval']) : 1;
        $period = isset($subscription_data['period']) ? sanitize_text_field($subscription_data['period']) : 'month';
        $price = isset($subscription_data['price']) ? floatval($subscription_data['price']) : 0;
        $start_date = isset($subscription_data['start_date']) ? $subscription_data['start_date'] : current_time('mysql');
        $end_date = isset($subscription_data['end_date']) ? $subscription_data['end_date'] : '';
        $next_payment_date = isset($subscription_data['next_payment_date']) ? $subscription_data['next_payment_date'] : '';
        $trial_end_date = isset($subscription_data['trial_end_date']) ? $subscription_data['trial_end_date'] : '';
        $cancel_date = isset($subscription_data['cancel_date']) ? $subscription_data['cancel_date'] : '';
        $cancel_reason = isset($subscription_data['cancel_reason']) ? sanitize_text_field($subscription_data['cancel_reason']) : '';
        $billing_cycle_count = isset($subscription_data['billing_cycle_count']) ? intval($subscription_data['billing_cycle_count']) : 0;
        $total_payments = isset($subscription_data['total_payments']) ? intval($subscription_data['total_payments']) : 0;
        $subscription_meta = isset($subscription_data['subscription_meta']) ? $subscription_data['subscription_meta'] : '';

        if (empty($customer_email) && empty($customer_id)) {
            return;
        }

        // Get customer ID if only email provided
        if (empty($customer_id) && !empty($customer_email)) {
            $customer_id = $this->get_or_create_fluentcart_customer($customer_email, []);
        }

        // Create subscription post
        $subscription_post = [
            'post_type' => 'fct_subscription',
            'post_status' => 'publish',
            'post_date' => $start_date,
            'post_title' => 'Subscription - ' . (!empty($customer_email) ? $customer_email : 'Customer #' . $customer_id)
        ];

        $subscription_id = wp_insert_post($subscription_post);

        if (is_wp_error($subscription_id) || !$subscription_id) {
            return;
        }

        // Update subscription meta
        update_post_meta($subscription_id, 'fct_customer_id', $customer_id);
        update_post_meta($subscription_id, 'fct_customer_email', $customer_email);
        update_post_meta($subscription_id, 'fct_product_id', $product_id);
        update_post_meta($subscription_id, 'fct_order_id', $order_id);
        update_post_meta($subscription_id, 'fct_subscription_status', $subscription_status);
        update_post_meta($subscription_id, 'fct_interval', $interval);
        update_post_meta($subscription_id, 'fct_period', $period);
        update_post_meta($subscription_id, 'fct_price', $price);
        update_post_meta($subscription_id, 'fct_start_date', $start_date);
        update_post_meta($subscription_id, 'fct_end_date', $end_date);
        update_post_meta($subscription_id, 'fct_next_payment_date', $next_payment_date);
        update_post_meta($subscription_id, 'fct_trial_end_date', $trial_end_date);
        update_post_meta($subscription_id, 'fct_cancel_date', $cancel_date);
        update_post_meta($subscription_id, 'fct_cancel_reason', $cancel_reason);
        update_post_meta($subscription_id, 'fct_billing_cycle_count', $billing_cycle_count);
        update_post_meta($subscription_id, 'fct_total_payments', $total_payments);

        // Handle custom subscription meta
        if (!empty($subscription_meta)) {
            $meta_pairs = explode('|', $subscription_meta);
            foreach ($meta_pairs as $pair) {
                $parts = explode(':', $pair, 2);
                if (count($parts) === 2) {
                    $meta_key = 'fct_' . trim($parts[0]);
                    $meta_value = trim($parts[1]);
                    update_post_meta($subscription_id, $meta_key, $meta_value);
                }
            }
        }

        // Update import log
        $update_count = update_count($hash_key, 'hash_key');
        $wpdb->query($wpdb->prepare(
            "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
            $update_count,
            $hash_key
        ));
    }

    /**
     * Import FluentCart Coupons
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_coupons(
        $header_array,
        $value_array,
        $map,
        $check,
        $mode,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb,$core_instance;

        if (!is_plugin_active('fluent-cart/fluent-cart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";
        $table_name = $wpdb->prefix."smackcsv_file_events";

        // Get mapped values
        $coupon_data = $helpers_instance->get_header_values($map, $header_array, $value_array);
        return;

        // Extract coupon fields
        $coupon_id                  = !empty($coupon_data['ID']) ? $coupon_data['ID'] :"";
        $coupon_title               = !empty($coupon_data['coupon_title']) ? $coupon_data['coupon_title'] :"";
        $coupon_code                = !empty($coupon_data['coupon_code']) ? $coupon_data['coupon_code'] :"";
        $coupon_priority            = !empty($coupon_data['coupon_priority']) ? $coupon_data['coupon_priority'] : "";
        $discount_type              = !empty($coupon_data['discount_type']) ? $coupon_data['discount_type'] : "";

        $max_uses_limit             = !empty($coupon_data['max_uses_limit']) ? $coupon_data['max_uses_limit'] : "";
        $buy_quantity               = !empty($coupon_data['buy_quantity']) ? $coupon_data['buy_quantity'] : "";
        $get_quantity               = !empty($coupon_data['get_quantity']) ? $coupon_data['get_quantity'] : "";
        $is_recurring               = !empty($coupon_data['is_recurring']) ? $coupon_data['is_recurring'] : "";
        $usage_limit_per_user       = !empty($coupon_data['usage_limit_per_user']) ? $coupon_data['usage_limit_per_user'] : "";
        $apply_to_quantity          = !empty($coupon_data['apply_to_quantity']) ? $coupon_data['apply_to_quantity'] : "";
        $excluded_products          = isset($coupon_data['excluded_products']) ? explode('|',$coupon_data['excluded_products']) : [];
        $included_products          = isset($coupon_data['included_products']) ? explode('|',$coupon_data['included_products']) : [];
        $email_restrictions         = !empty($coupon_data['email_restrictions']) ? $coupon_data['email_restrictions'] : "";
        $apply_to_whole_cart        = !empty($coupon_data['apply_to_whole_cart']) ? $coupon_data['apply_to_whole_cart'] : "";
        $included_categories        = isset($coupon_data['included_categories']) ? explode('|',$coupon_data['included_categories']) : [];
        $excluded_categories        = isset($coupon_data['excluded_categories']) ? explode('|',$coupon_data['excluded_categories']) : [];
        $max_discount_amount        = !empty($coupon_data['max_discount_amount']) ? $coupon_data['max_discount_amount'] : 0 ;
        $maximum_amount             = !empty($coupon_data['maximum_amount']) ? $coupon_data['maximum_amount'] : 0 ;
        $minimum_amount             = !empty($coupon_data['minimum_amount']) ? $coupon_data['minimum_amount'] : 0 ;
        
        $coupon_conditions = [
            'max_uses' => $max_uses_limit,
            'buy_quantity'=> $buy_quantity,
            'get_quantity' => $get_quantity,
            'is_recurring' => $is_recurring,
            'max_per_customer' => $usage_limit_per_user,
            'apply_to_quantity' => $apply_to_quantity,
            'excluded_products' => $excluded_products,
            'included_products' => $included_products,
            'email_restrictions' => $email_restrictions,
            'apply_to_whole_cart' => $apply_to_whole_cart,
            'excluded_categories' => $excluded_categories,
            'included_categories' => $included_categories,
            'max_discount_amount' => $max_discount_amount,
            'max_purchase_amount' => $maximum_amount,
            'min_purchase_amount' => $minimum_amount
        ];
        $coupon_conditions = json_encode($coupon_conditions);

        $discount_amount          = !empty($coupon_data['discount_amount']) ? $coupon_data['discount_amount'] : "";
        $usage_count              = !empty($coupon_data['usage_count']) ? $coupon_data['usage_count'] : 0;
        $status                   = !empty($coupon_data['status']) ? $coupon_data['status'] :"active";
        $coupon_notes             = !empty($coupon_data['coupon_notes']) ? $coupon_data['coupon_notes'] : "";
        $coupon_stackable         = !empty($coupon_data['coupon_stackable']) ? $coupon_data['coupon_stackable'] :"";
        $coupon_show_on_checkout  = !empty($coupon_data['coupon_show_on_checkout']) ? $coupon_data['coupon_show_on_checkout'] : "no";
        $start_date = !empty($coupon_data['start_date']) ? date('Y-m-d H:i:s', strtotime($coupon_data['start_date'])): null;
        $end_date = !empty($coupon_data['end_date']) ? date('Y-m-d H:i:s', strtotime($coupon_data['end_date'])) : null;
        $created_at               = !empty($coupon_data['created_at']) ? $coupon_data['created_at'] : "";
        $updated_at               = !empty($coupon_data['updated_at']) ? $coupon_data['updated_at'] :"";


        $coupon_data = [
            'title'     => $coupon_title ,
            'code'      => $coupon_code,
            'priority' => $coupon_priority,
            'type'      => $discount_type,
            'conditions' => $coupon_conditions,
            'amount'    => $discount_amount,
            'use_count' => $usage_count,
            'status'    => $status,
            'notes' => $coupon_notes,
            'stackable' => $coupon_stackable,
            'show_on_checkout'  => $coupon_show_on_checkout,
            'start_date'    => $start_date,
            'end_date'      => $end_date,
            'created_at'    => $created_at,
            'updated_at'    => $updated_at
        ]; 
        $coupon_format = [
            '%s', //title
            '%s', //code
            '%d', //proiority
            '%s', //type
            '%s', //conditions
            '%d', //amount
            '%d', //use_count 
            '%s', //status
            '%s', //notes
            '%s', //stackable
            '%s', //show_on_checkout
            '%s', //start_date
            '%s', //end_date
            '%s', //created_at
            '%s' //updated_at
        ];

        $fct_coupons_table = $wpdb->prefix.'fct_coupons';



        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        
        if($mode == 'Insert'){
            $coupon_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$fct_coupons_table} WHERE code = %s",$coupon_code
            ));
            if(isset($coupon_id)){
                $mode = 'Skipped';
                $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s",
                $update_count['skipped'],
                $hash_key
            ));

            if (!$customer_post_id) {
                if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Failed: Could not create customer',
                        'state' => 'Failed'
                    ];
                }
                return;
            }
            }else{

                $wpdb->insert(
                    $fct_coupons_table,
                    $coupon_data,
                    $coupon_format
                ); 
    
                $wpdb->query($wpdb->prepare(
                    "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
                    $update_count['created'],
                    $hash_key
                ));
            }


        } elseif($mode == 'Update'){
            if(isset($check)){
                if($check=='coupon_code'){
                    $coupon_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$fct_coupons_table} WHERE code = %s",$coupon_code
                    ));
                }elseif($check=='ID'){
                    $coupon_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$fct_coupons_table} WHERE id = %d",$coupon_id
                    ));
                }
            }

            $wpdb->update(
                    $fct_coupons_table,
                    $coupon_data,
                    ['id' => $coupon_id],
                    $coupon_format,
                    ['%d']
            );
            $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET updated = %d WHERE hash_key = %s",
                $update_count['updated'],
                $hash_key
            ));
        } elseif($mode == 'Skipped'){

             $wpdb->query($wpdb->prepare(
                "UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s",
                $update_count['skipped'],
                $hash_key
            ));

            if (!$customer_post_id) {
                if (isset($core_instance)) {
                    $core_instance->detailed_log[$line_number] = [
                        'Message' => 'Failed: Could not create customer',
                        'state' => 'Failed'
                    ];
                }
                return;
            }

        }

    }

    /**
     * Get or create FluentCart customer
     *
     * @param string $email Customer email
     * @param array $customer_data Additional customer data
     * @return int Customer ID
     */
    private function get_or_create_fluentcart_customer($email, $customer_data = []) {
        global $wpdb;

        if (empty($email)) {
            return 0;
        }

        // Try to find existing customer by email
        $existing_customer = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'fct_customer' 
             AND ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'fct_customer_email' AND meta_value = %s)
             LIMIT 1",
            $email
        ));

        if ($existing_customer) {
            return intval($existing_customer);
        }

        // Create new customer
        $customer_name = isset($customer_data['customer_name']) ? sanitize_text_field($customer_data['customer_name']) : $email;
        
        $customer_post = [
            'post_type' => 'fct_customer',
            'post_status' => 'publish',
            'post_title' => $customer_name
        ];

        $customer_id = wp_insert_post($customer_post);

        if ($customer_id && !is_wp_error($customer_id)) {
            update_post_meta($customer_id, 'fct_customer_email', $email);
            update_post_meta($customer_id, 'fct_customer_name', $customer_name);
            
            // Add other customer data if provided
            if (!empty($customer_data['first_name'])) {
                update_post_meta($customer_id, 'fct_first_name', sanitize_text_field($customer_data['first_name']));
            }
            if (!empty($customer_data['last_name'])) {
                update_post_meta($customer_id, 'fct_last_name', sanitize_text_field($customer_data['last_name']));
            }
        }

        return $customer_id ? intval($customer_id) : 0;
    }

    /**
     * Import FluentCart Downloads/Licenses
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_downloads(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb;
        
        if (!is_plugin_active('fluentcart/fluentcart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $core_instance = CoreFieldsImport::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values
        $download_data = $helpers_instance->get_header_values($map, $header_array, $value_array);

        // Extract download fields
        $download_id = isset($download_data['download_id']) ? intval($download_data['download_id']) : 0;
        $product_id = isset($download_data['product_id']) ? intval($download_data['product_id']) : 0;
        $file_name = isset($download_data['file_name']) ? sanitize_text_field($download_data['file_name']) : '';
        $file_url = isset($download_data['file_url']) ? esc_url_raw($download_data['file_url']) : '';
        $download_limit = isset($download_data['download_limit']) ? intval($download_data['download_limit']) : 0;
        $download_expiry = isset($download_data['download_expiry']) ? sanitize_text_field($download_data['download_expiry']) : '';
        $license_key = isset($download_data['license_key']) ? sanitize_text_field($download_data['license_key']) : '';
        $activation_limit = isset($download_data['activation_limit']) ? intval($download_data['activation_limit']) : 0;
        $customer_id = isset($download_data['customer_id']) ? intval($download_data['customer_id']) : 0;
        $order_id = isset($download_data['order_id']) ? intval($download_data['order_id']) : 0;

        // Validate required fields
        if (empty($product_id) || empty($file_url)) {
            $core_instance->detailed_log[$line_number]['Message'] = "Skipped: Missing required fields (product_id or file_url)";
            $core_instance->detailed_log[$line_number]['state'] = 'Skipped';
            $skipped_count = $helpers_instance->update_count($hash_key, 'hash_key')['skipped'];
            $wpdb->query($wpdb->prepare("UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key));
            return;
        }

        // FluentCart uses custom tables - insert into fct_downloads
        $downloads_table = $wpdb->prefix . 'fct_downloads';
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$downloads_table'");
        if (!$table_exists) {
            $core_instance->detailed_log[$line_number]['Message'] = "Skipped: FluentCart downloads table not found";
            $core_instance->detailed_log[$line_number]['state'] = 'Skipped';
            $skipped_count = $helpers_instance->update_count($hash_key, 'hash_key')['skipped'];
            $wpdb->query($wpdb->prepare("UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key));
            return;
        }

        // Prepare download data
        $download_insert = array(
            'product_id' => $product_id,
            'file_name' => $file_name,
            'file_url' => $file_url,
            'download_limit' => $download_limit,
            'download_expiry' => $download_expiry ?: null,
            'license_key' => $license_key,
            'activation_limit' => $activation_limit,
            'customer_id' => $customer_id ?: null,
            'order_id' => $order_id ?: null,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );

        if ($download_id > 0) {
            // Update existing download
            $wpdb->update(
                $downloads_table,
                $download_insert,
                array('id' => $download_id),
                array('%d', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%d', '%s', '%s'),
                array('%d')
            );
            $new_download_id = $download_id;
        } else {
            // Insert new download
            $wpdb->insert(
                $downloads_table,
                $download_insert,
                array('%d', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%d', '%s', '%s')
            );
            $new_download_id = $wpdb->insert_id;
        }

        if ($new_download_id) {
            // Log success
            $created_count = $helpers_instance->update_count($hash_key, 'hash_key')['created'];
            $core_instance->detailed_log[$line_number]['Message'] = 'Inserted FluentCart Download ID: ' . $new_download_id;
            $core_instance->detailed_log[$line_number]['id'] = $new_download_id;
            $core_instance->detailed_log[$line_number]['state'] = 'Inserted';
            $wpdb->query($wpdb->prepare("UPDATE $log_table_name SET created = %d WHERE hash_key = %s", $created_count, $hash_key));
        } else {
            $core_instance->detailed_log[$line_number]['Message'] = "Failed to create download";
            $core_instance->detailed_log[$line_number]['state'] = 'Skipped';
            $skipped_count = $helpers_instance->update_count($hash_key, 'hash_key')['skipped'];
            $wpdb->query($wpdb->prepare("UPDATE $log_table_name SET skipped = %d WHERE hash_key = %s", $skipped_count, $hash_key));
        }
    }


}