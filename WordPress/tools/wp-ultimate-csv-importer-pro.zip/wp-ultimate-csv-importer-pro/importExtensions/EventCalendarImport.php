<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Import / update writer for The Events Calendar ecosystem.
 */
class EventCalendarImport {

	private static $events_instance = null;

	/** @var string|null Prevent double-processing within the same map-group foreach for one row. */
	private $current_row_token = null;

	public static function getInstance() {
		if ( EventCalendarImport::$events_instance == null ) {
			EventCalendarImport::$events_instance = new EventCalendarImport();
		}
		return EventCalendarImport::$events_instance;
	}

	/**
	 * Entry point used by SaveMapping for EventCalendar* map groups.
	 *
	 * @param array  $header_array CSV/XML headers.
	 * @param array  $value_array  Row values.
	 * @param array  $map          Merged EventCalendar field map.
	 * @param int    $post_id      Target post ID.
	 * @param string $type         Import type.
	 * @param string $mode         Insert|Update|… .
	 * @param mixed  $term_map     Optional TERMS map (legacy).
	 * @param string $gmode        GUI/CLI mode.
	 * @param string $hash_key     Import hash.
	 * @return void
	 */
	public function set_events_values( $header_array, $value_array, $map, $post_id, $type, $mode, $term_map = '', $gmode = '', $hash_key = '' ) {
		if ( empty( $post_id ) || ! EventCalendarExtension::is_tec_active() ) {
			return;
		}

		$post_id = (int) $post_id;
		$row_token = md5( $post_id . '|' . wp_json_encode( $value_array ) . '|' . (string) $hash_key );
		if ( $this->current_row_token === $row_token ) {
			return;
		}
		$this->current_row_token = $row_token;

		$helpers     = ImportHelpers::getInstance();
		$post_values = $helpers->get_header_values( $map, $header_array, $value_array );
		if ( ! is_array( $post_values ) ) {
			$post_values = array();
		}

		// Drop empty mapped values so updates never overwrite with blanks unless intentional.
		$post_values = array_filter(
			$post_values,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);

		$type = EventCalendarExtension::normalize_type( $type );

		switch ( $type ) {
			case 'tribe_venue':
				$this->import_standalone_venue( $post_id, $post_values, $mode );
				break;
			case 'tribe_organizer':
				$this->import_standalone_organizer( $post_id, $post_values, $mode );
				break;
			case 'tribe_event_series':
				$this->import_standalone_series( $post_id, $post_values, $mode );
				break;
			case 'tribe_events':
			default:
				$this->import_event( $post_id, $post_values, $mode, $term_map );
				break;
		}
	}

	/**
	 * Reset per-batch processed tracker.
	 *
	 * @return void
	 */
	public function reset_processed() {
		$this->current_row_token = null;
	}

	/**
	 * Import / update a tribe_events post using TEC APIs.
	 *
	 * @param int    $post_id     Event post ID (created by CoreFieldsImport).
	 * @param array  $data        Mapped values.
	 * @param string $mode        Import mode.
	 * @param mixed  $term_map    Legacy term map.
	 * @return void
	 */
	private function import_event( $post_id, array $data, $mode, $term_map ) {
		$needs_api_save = $this->has_any_keys(
			$data,
			array(
				'_EventStartDate',
				'event_start_time',
				'_EventEndDate',
				'event_end_time',
				'_EventAllDay',
				'_EventTimezone',
				'_EventStartDateUTC',
				'_EventEndDateUTC',
				'_EventShowMap',
				'_EventShowMapLink',
				'_EventHideFromUpcoming',
				'_EventVenueID',
				'_EventOrganizerID',
				'event_venue_id',
				'event_venue_name',
				'event_venue_address',
				'event_venue_city',
				'event_organizer_id',
				'event_organizer_name',
				'event_organizer_email',
			)
		);

		if ( $needs_api_save ) {
			$event_args = $this->build_event_api_args( $post_id, $data );

			$venue_mapped = $this->has_any_keys(
				$data,
				array(
					'event_venue_id',
					'event_venue_name',
					'event_venue_address',
					'event_venue_city',
					'_EventVenueID',
				)
			);
			$venue_id = $this->resolve_venue( $data, $mode );
			if ( $venue_id ) {
				$event_args['Venue']        = array( 'VenueID' => (int) $venue_id );
				$event_args['EventVenueID'] = (int) $venue_id;
			} elseif ( ! $venue_mapped ) {
				$existing_venue = (int) get_post_meta( $post_id, '_EventVenueID', true );
				if ( $existing_venue ) {
					$event_args['Venue']        = array( 'VenueID' => $existing_venue );
					$event_args['EventVenueID'] = $existing_venue;
				}
			}

			$organizer_mapped = $this->has_any_keys(
				$data,
				array(
					'event_organizer_id',
					'event_organizer_name',
					'event_organizer_email',
					'_EventOrganizerID',
				)
			);
			$organizer_ids = $this->resolve_organizers( $data, $mode );
			if ( ! empty( $organizer_ids ) ) {
				$event_args['Organizer']       = array( 'OrganizerID' => $organizer_ids );
				$event_args['EventOrganizerID'] = $organizer_ids;
			} elseif ( ! $organizer_mapped ) {
				$existing_orgs = array_filter( array_map( 'intval', (array) get_post_meta( $post_id, '_EventOrganizerID', false ) ) );
				if ( ! empty( $existing_orgs ) ) {
					$event_args['Organizer']        = array( 'OrganizerID' => array_values( $existing_orgs ) );
					$event_args['EventOrganizerID'] = array_values( $existing_orgs );
				}
			}

			// Preserve recurrence when not being updated in this row.
			if ( ! $this->has_any_keys( $data, array( 'recurrence_type', 'recurrence_ical', 'recurrence_additional_dates', 'recurrence_exclusions' ) ) ) {
				$existing_recurrence = get_post_meta( $post_id, '_EventRecurrence', true );
				if ( ! empty( $existing_recurrence ) ) {
					$event_args['recurrence'] = $existing_recurrence;
				}
			}

			if ( class_exists( 'Tribe__Events__API' ) ) {
				\Tribe__Events__API::saveEventMeta( $post_id, $event_args, get_post( $post_id ) );
			} else {
				$this->fallback_save_event_meta( $post_id, $event_args );
			}
		} else {
			// Lightweight updates for cost/url/currency etc. — never touch linked posts or recurrence.
			$this->save_simple_event_meta( $post_id, $data );
			// Still allow creating/linking venue/organizer if only those nested fields are present without dates —
			// handled above via $needs_api_save. Nested-only without dates already included in needs_api_save.
		}

		// Always apply simple mapped fields that saveEventMeta may not cover, when API path was used.
		if ( $needs_api_save ) {
			$this->save_simple_event_meta( $post_id, $data );
		}

		$this->save_featured_and_status( $post_id, $data );
		$this->save_virtual_meta( $post_id, $data );
		$this->save_pro_custom_fields( $post_id, $data );
		$this->save_tickets_meta( $post_id, $data );
		$this->save_recurrence( $post_id, $data );
		$this->save_series_relationship( $post_id, $data );
		$this->maybe_apply_legacy_terms( $post_id, $data, $term_map );

		/**
		 * Fires after a TEC event row has been imported/updated by Ultimate CSV Importer Pro.
		 *
		 * @param int    $post_id Event ID.
		 * @param array  $data    Mapped values.
		 * @param string $mode    Import mode.
		 */
		do_action( 'smackuci_tec_after_event_import', $post_id, $data, $mode );
	}

	/**
	 * Update simple event meta keys without invoking full TEC saveEventMeta.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_simple_event_meta( $post_id, array $data ) {
		$simple = array(
			'_EventCost',
			'_EventCurrencySymbol',
			'_EventCurrencyCode',
			'_EventCurrencyPosition',
			'_EventURL',
			'_EventOrigin',
			'_EventTimezoneAbbr',
		);
		foreach ( $simple as $key ) {
			if ( ! isset( $data[ $key ] ) ) {
				continue;
			}
			update_post_meta( $post_id, $key, sanitize_text_field( $data[ $key ] ) );
		}

		// Timezone alone (without dates) — safe direct write.
		if ( isset( $data['_EventTimezone'] ) && ! $this->has_any_keys( $data, array( '_EventStartDate', '_EventEndDate', 'event_start_time', 'event_end_time' ) ) ) {
			update_post_meta( $post_id, '_EventTimezone', sanitize_text_field( $data['_EventTimezone'] ) );
		}
	}

	/**
	 * Build args for Tribe__Events__API::saveEventMeta / updateEvent.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return array
	 */
	private function build_event_api_args( $post_id, array $data ) {
		$args = array();

		$start = $this->compose_datetime(
			isset( $data['_EventStartDate'] ) ? $data['_EventStartDate'] : '',
			isset( $data['event_start_time'] ) ? $data['event_start_time'] : ''
		);
		$end = $this->compose_datetime(
			isset( $data['_EventEndDate'] ) ? $data['_EventEndDate'] : '',
			isset( $data['event_end_time'] ) ? $data['event_end_time'] : ''
		);

		// Fall back to existing values on update when only one side is mapped.
		if ( empty( $start ) ) {
			$start = (string) get_post_meta( $post_id, '_EventStartDate', true );
		}
		if ( empty( $end ) ) {
			$end = (string) get_post_meta( $post_id, '_EventEndDate', true );
		}

		$all_day = false;
		if ( isset( $data['_EventAllDay'] ) ) {
			$all_day = $this->is_truthy( $data['_EventAllDay'] );
			$args['EventAllDay'] = $all_day ? 'yes' : '';
		} else {
			$all_day = $this->is_truthy( get_post_meta( $post_id, '_EventAllDay', true ) );
		}

		$start_parts = $this->split_wallclock_datetime( $start );
		if ( ! empty( $start_parts ) ) {
			$args['EventStartDate']     = $start_parts['date'];
			$args['EventStartHour']     = $start_parts['hour12'];
			$args['EventStartMinute']   = $start_parts['minute'];
			$args['EventStartMeridian'] = $start_parts['meridian'];
			$args['_EventStartDate']    = $start_parts['datetime'];
		}

		$end_parts = $this->split_wallclock_datetime( $end );
		if ( ! empty( $end_parts ) ) {
			$args['EventEndDate']       = $end_parts['date'];
			$args['EventEndHour']       = $end_parts['hour12'];
			$args['EventEndMinute']     = $end_parts['minute'];
			$args['EventEndMeridian']   = $end_parts['meridian'];
			$args['_EventEndDate']      = $end_parts['datetime'];
		}

		// If all-day and end missing, default end to start date.
		if ( $all_day && ! empty( $args['EventStartDate'] ) && empty( $args['EventEndDate'] ) ) {
			$args['EventEndDate'] = $args['EventStartDate'];
		}

		// Validate start <= end when both present.
		if ( ! empty( $args['_EventStartDate'] ) && ! empty( $args['_EventEndDate'] ) ) {
			if ( strtotime( $args['_EventEndDate'] ) < strtotime( $args['_EventStartDate'] ) ) {
				$args['_EventEndDate']  = $args['_EventStartDate'];
				$args['EventEndDate']   = $args['EventStartDate'];
				$args['EventEndHour']   = $args['EventStartHour'];
				$args['EventEndMinute'] = $args['EventStartMinute'];
				$args['EventEndMeridian'] = $args['EventStartMeridian'];
			}
		}

		$direct_map = array(
			'_EventURL'               => 'EventURL',
			'_EventCost'              => 'EventCost',
			'_EventCurrencySymbol'    => 'EventCurrencySymbol',
			'_EventCurrencyCode'      => 'EventCurrencyCode',
			'_EventCurrencyPosition'  => 'EventCurrencyPosition',
			'_EventTimezone'          => 'EventTimezone',
			'_EventTimezoneAbbr'      => 'EventTimezoneAbbr',
			'_EventShowMap'           => 'EventShowMap',
			'_EventShowMapLink'       => 'EventShowMapLink',
			'_EventHideFromUpcoming'  => 'EventHideFromUpcoming',
			'_EventOrigin'            => 'EventOrigin',
			'_EventStartDateUTC'      => 'EventStartDateUTC',
			'_EventEndDateUTC'        => 'EventEndDateUTC',
		);

		foreach ( $direct_map as $meta_key => $api_key ) {
			if ( isset( $data[ $meta_key ] ) && '' !== $data[ $meta_key ] ) {
				$args[ $api_key ] = sanitize_text_field( $data[ $meta_key ] );
			}
		}

		// When saving via API without an explicit timezone, keep the existing one (avoid site-TZ overwrite).
		if ( empty( $args['EventTimezone'] ) ) {
			$existing_tz = (string) get_post_meta( $post_id, '_EventTimezone', true );
			if ( '' !== $existing_tz ) {
				$args['EventTimezone'] = $existing_tz;
			}
		}

		if ( isset( $data['event_timezone_mode'] ) && '' !== $data['event_timezone_mode'] ) {
			$mode = strtolower( sanitize_text_field( $data['event_timezone_mode'] ) );
			if ( in_array( $mode, array( 'site', 'event' ), true ) && function_exists( 'tribe_update_option' ) ) {
				// Per-event mode is stored on the event timezone itself; site option is global — skip changing global.
				$args['EventTimezoneMode'] = $mode;
			}
		}

		if ( isset( $data['_EventVenueID'] ) && is_numeric( $data['_EventVenueID'] ) ) {
			$args['EventVenueID'] = (int) $data['_EventVenueID'];
		}
		if ( isset( $data['_EventOrganizerID'] ) && '' !== $data['_EventOrganizerID'] ) {
			$args['EventOrganizerID'] = $this->parse_id_list( $data['_EventOrganizerID'] );
		}

		// Boolean-ish map fields.
		foreach ( array( 'EventShowMap', 'EventShowMapLink', 'EventHideFromUpcoming' ) as $bool_key ) {
			if ( isset( $args[ $bool_key ] ) ) {
				$args[ $bool_key ] = $this->is_truthy( $args[ $bool_key ] ) ? ( 'EventHideFromUpcoming' === $bool_key ? 'yes' : '1' ) : '';
			}
		}

		return $args;
	}

	/**
	 * Resolve or create a venue and return its ID.
	 *
	 * @param array  $data Mapped values.
	 * @param string $mode Import mode.
	 * @return int
	 */
	private function resolve_venue( array $data, $mode ) {
		$venue_id = 0;

		if ( ! empty( $data['event_venue_id'] ) && is_numeric( $data['event_venue_id'] ) ) {
			$candidate = (int) $data['event_venue_id'];
			if ( $this->is_post_type( $candidate, 'tribe_venue' ) ) {
				return $candidate;
			}
		}

		if ( ! empty( $data['_EventVenueID'] ) && is_numeric( $data['_EventVenueID'] ) ) {
			$candidate = (int) $data['_EventVenueID'];
			if ( $this->is_post_type( $candidate, 'tribe_venue' ) ) {
				$venue_id = $candidate;
			}
		}

		$name = isset( $data['event_venue_name'] ) ? trim( (string) $data['event_venue_name'] ) : '';
		if ( ! $venue_id && $name !== '' ) {
			$existing = $this->find_post_by_title( $name, 'tribe_venue' );
			if ( $existing ) {
				$venue_id = $existing;
			}
		}

		$has_venue_payload = $name !== '' || $this->has_any_keys(
			$data,
			array(
				'event_venue_address',
				'event_venue_city',
				'event_venue_state',
				'event_venue_zip',
				'event_venue_country',
				'event_venue_phone',
				'event_venue_website',
				'event_venue_lat',
				'event_venue_lng',
			)
		);

		if ( ! $has_venue_payload && ! $venue_id ) {
			return 0;
		}

		$venue_data = array(
			'Venue'         => $name !== '' ? $name : ( $venue_id ? get_the_title( $venue_id ) : '' ),
			'Description'   => isset( $data['event_venue_description'] ) ? $data['event_venue_description'] : '',
			'Address'       => isset( $data['event_venue_address'] ) ? $data['event_venue_address'] : '',
			'City'          => isset( $data['event_venue_city'] ) ? $data['event_venue_city'] : '',
			'Country'       => isset( $data['event_venue_country'] ) ? $data['event_venue_country'] : '',
			'Province'      => isset( $data['event_venue_province'] ) ? $data['event_venue_province'] : '',
			'State'         => isset( $data['event_venue_state'] ) ? $data['event_venue_state'] : '',
			'Zip'           => isset( $data['event_venue_zip'] ) ? $data['event_venue_zip'] : '',
			'Phone'         => isset( $data['event_venue_phone'] ) ? $data['event_venue_phone'] : '',
			'URL'           => isset( $data['event_venue_website'] ) ? $data['event_venue_website'] : '',
			'ShowMap'       => isset( $data['event_venue_show_map'] ) ? $data['event_venue_show_map'] : '',
			'ShowMapLink'   => isset( $data['event_venue_show_map_link'] ) ? $data['event_venue_show_map_link'] : '',
		);

		if ( isset( $data['event_venue_state'] ) && ! isset( $data['event_venue_province'] ) ) {
			$venue_data['StateProvince'] = $data['event_venue_state'];
		} elseif ( isset( $data['event_venue_province'] ) ) {
			$venue_data['StateProvince'] = $data['event_venue_province'];
		}

		// Strip empties so updates don't blank existing venue fields.
		$venue_data = array_filter(
			$venue_data,
			static function ( $v ) {
				return null !== $v && '' !== $v;
			}
		);

		if ( $venue_id && class_exists( 'Tribe__Events__API' ) ) {
			\Tribe__Events__API::updateVenue( $venue_id, $venue_data );
			$this->maybe_save_venue_geo( $venue_id, $data );
			return $venue_id;
		}

		if ( class_exists( 'Tribe__Events__API' ) && ! empty( $venue_data['Venue'] ) ) {
			// Prefer Venue::create with avoid_duplicates when available.
			if ( class_exists( 'Tribe__Events__Venue' ) ) {
				$created = \Tribe__Events__Venue::instance()->create( $venue_data, 'publish', true );
			} else {
				$created = \Tribe__Events__API::createVenue( $venue_data, 'publish' );
			}
			if ( ! empty( $created ) && ! is_wp_error( $created ) ) {
				$venue_id = (int) $created;
				$this->maybe_save_venue_geo( $venue_id, $data );
			}
		}

		return (int) $venue_id;
	}

	/**
	 * Save Pro geo coordinates on a venue.
	 *
	 * @param int   $venue_id Venue ID.
	 * @param array $data     Mapped values.
	 * @return void
	 */
	private function maybe_save_venue_geo( $venue_id, array $data ) {
		if ( isset( $data['event_venue_lat'] ) && '' !== $data['event_venue_lat'] ) {
			update_post_meta( $venue_id, '_VenueLat', sanitize_text_field( $data['event_venue_lat'] ) );
		}
		if ( isset( $data['event_venue_lng'] ) && '' !== $data['event_venue_lng'] ) {
			update_post_meta( $venue_id, '_VenueLng', sanitize_text_field( $data['event_venue_lng'] ) );
		}
	}

	/**
	 * Resolve or create organizers; returns list of IDs.
	 *
	 * @param array  $data Mapped values.
	 * @param string $mode Import mode.
	 * @return int[]
	 */
	private function resolve_organizers( array $data, $mode ) {
		$ids = array();

		if ( ! empty( $data['event_organizer_id'] ) ) {
			$ids = array_merge( $ids, $this->parse_id_list( $data['event_organizer_id'] ) );
		}
		if ( ! empty( $data['_EventOrganizerID'] ) ) {
			$ids = array_merge( $ids, $this->parse_id_list( $data['_EventOrganizerID'] ) );
		}

		$ids = array_values(
			array_filter(
				array_map( 'intval', $ids ),
				function ( $id ) {
					return $this->is_post_type( $id, 'tribe_organizer' );
				}
			)
		);

		$names  = $this->parse_string_list( isset( $data['event_organizer_name'] ) ? $data['event_organizer_name'] : '' );
		$emails = $this->parse_string_list( isset( $data['event_organizer_email'] ) ? $data['event_organizer_email'] : '' );
		$phones = $this->parse_string_list( isset( $data['event_organizer_phone'] ) ? $data['event_organizer_phone'] : '' );
		$webs   = $this->parse_string_list( isset( $data['event_organizer_website'] ) ? $data['event_organizer_website'] : '' );
		$descs  = $this->parse_string_list( isset( $data['event_organizer_description'] ) ? $data['event_organizer_description'] : '', '|' );

		$max = max( count( $names ), count( $emails ), 1 );
		if ( empty( $names ) && empty( $emails ) && empty( $ids ) ) {
			return $ids;
		}

		for ( $i = 0; $i < $max; $i++ ) {
			$name  = isset( $names[ $i ] ) ? trim( $names[ $i ] ) : '';
			$email = isset( $emails[ $i ] ) ? trim( $emails[ $i ] ) : '';
			$phone = isset( $phones[ $i ] ) ? trim( $phones[ $i ] ) : '';
			$web   = isset( $webs[ $i ] ) ? trim( $webs[ $i ] ) : '';
			$desc  = isset( $descs[ $i ] ) ? $descs[ $i ] : '';

			if ( isset( $ids[ $i ] ) && $ids[ $i ] ) {
				$org_id = $ids[ $i ];
				$payload = array_filter(
					array(
						'Organizer'   => $name,
						'Description' => $desc,
						'Email'       => $email,
						'Phone'       => $phone,
						'Website'     => $web,
					)
				);
				if ( ! empty( $payload ) && class_exists( 'Tribe__Events__API' ) ) {
					\Tribe__Events__API::updateOrganizer( $org_id, $payload );
				}
				continue;
			}

			$found = 0;
			if ( $email !== '' ) {
				$found = $this->find_organizer_by_email( $email );
			}
			if ( ! $found && $name !== '' ) {
				$found = $this->find_post_by_title( $name, 'tribe_organizer' );
			}

			$payload = array(
				'Description' => $desc,
				'Email'       => $email,
				'Phone'       => $phone,
				'Website'     => $web,
			);
			// Never overwrite an existing organizer title with the email fallback.
			if ( $name !== '' ) {
				$payload['Organizer'] = $name;
			} elseif ( ! $found ) {
				$payload['Organizer'] = $email !== ''
					? $email
					: __( 'Unnamed Organizer', 'wp-ultimate-csv-importer-pro' );
			}

			$payload = array_filter(
				$payload,
				static function ( $v ) {
					return null !== $v && '' !== $v;
				}
			);

			if ( $found ) {
				if ( ! empty( $payload ) && class_exists( 'Tribe__Events__API' ) ) {
					\Tribe__Events__API::updateOrganizer( $found, $payload );
				}
				$ids[] = $found;
				continue;
			}

			if ( empty( $payload['Organizer'] ) ) {
				continue;
			}

			if ( class_exists( 'Tribe__Events__Organizer' ) ) {
				$created = \Tribe__Events__Organizer::instance()->create( $payload, 'publish', true );
			} elseif ( class_exists( 'Tribe__Events__API' ) ) {
				$created = \Tribe__Events__API::createOrganizer( $payload, 'publish' );
			} else {
				$created = 0;
			}

			if ( ! empty( $created ) && ! is_wp_error( $created ) ) {
				$ids[] = (int) $created;
			}
		}

		return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	}

	/**
	 * Featured flag + event status meta.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_featured_and_status( $post_id, array $data ) {
		if ( isset( $data['_tribe_featured'] ) ) {
			$featured = $this->is_truthy( $data['_tribe_featured'] );
			if ( $featured ) {
				update_post_meta( $post_id, '_tribe_featured', '1' );
				// Sticky-in-calendar convention used by TEC CSV importer.
				wp_update_post(
					array(
						'ID'         => $post_id,
						'menu_order' => -1,
					)
				);
			} else {
				delete_post_meta( $post_id, '_tribe_featured' );
				$post = get_post( $post_id );
				if ( $post && (int) $post->menu_order < 0 ) {
					wp_update_post(
						array(
							'ID'         => $post_id,
							'menu_order' => 0,
						)
					);
				}
			}
		}

		if ( isset( $data['_tribe_events_status'] ) && '' !== $data['_tribe_events_status'] ) {
			$status = sanitize_key( $data['_tribe_events_status'] );
			if ( in_array( $status, array( 'scheduled', 'canceled', 'cancelled', 'postponed' ), true ) ) {
				if ( 'cancelled' === $status ) {
					$status = 'canceled';
				}
				update_post_meta( $post_id, '_tribe_events_status', $status );
			}
		}
		if ( isset( $data['_tribe_events_status_reason'] ) ) {
			update_post_meta( $post_id, '_tribe_events_status_reason', sanitize_text_field( $data['_tribe_events_status_reason'] ) );
		}
	}

	/**
	 * Virtual / hybrid event meta (Pro).
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_virtual_meta( $post_id, array $data ) {
		if ( ! EventCalendarExtension::is_tec_pro_active() ) {
			return;
		}

		$virtual_keys = array(
			'_tribe_events_is_virtual',
			'_tribe_events_is_hybrid',
			'_tribe_virtual_events_type',
			'_tribe_events_virtual_url',
			'_tribe_events_virtual_video_source',
			'_tribe_events_virtual_embed_video',
			'_tribe_events_virtual_linked_button',
			'_tribe_events_virtual_linked_button_text',
			'_tribe_events_virtual_show_embed_at',
			'_tribe_events_virtual_show_on_event',
			'_tribe_events_virtual_show_on_views',
		);

		foreach ( $virtual_keys as $key ) {
			if ( ! isset( $data[ $key ] ) ) {
				continue;
			}
			$value = $data[ $key ];
			if ( in_array( $key, array( '_tribe_events_is_virtual', '_tribe_events_is_hybrid', '_tribe_events_virtual_embed_video', '_tribe_events_virtual_linked_button', '_tribe_events_virtual_show_on_event', '_tribe_events_virtual_show_on_views' ), true ) ) {
				$value = $this->is_truthy( $value ) ? '1' : '';
			} else {
				$value = sanitize_text_field( $value );
			}
			if ( '' === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}

		// Keep hybrid/virtual flags consistent with virtual event type when type is mapped.
		if ( isset( $data['_tribe_virtual_events_type'] ) && ! isset( $data['_tribe_events_is_hybrid'] ) ) {
			$type = strtolower( sanitize_text_field( $data['_tribe_virtual_events_type'] ) );
			if ( 'hybrid' === $type ) {
				update_post_meta( $post_id, '_tribe_events_is_hybrid', '1' );
				if ( ! isset( $data['_tribe_events_is_virtual'] ) ) {
					update_post_meta( $post_id, '_tribe_events_is_virtual', '1' );
				}
			} elseif ( 'virtual' === $type ) {
				delete_post_meta( $post_id, '_tribe_events_is_hybrid' );
				if ( ! isset( $data['_tribe_events_is_virtual'] ) ) {
					update_post_meta( $post_id, '_tribe_events_is_virtual', '1' );
				}
			}
		}
	}

	/**
	 * Save Events Calendar Pro additional fields when mapped.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_pro_custom_fields( $post_id, array $data ) {
		if ( ! EventCalendarExtension::is_tec_pro_active() || ! function_exists( 'tribe_get_option' ) ) {
			return;
		}

		$custom_fields = tribe_get_option( 'custom-fields', array() );
		if ( empty( $custom_fields ) || ! is_array( $custom_fields ) ) {
			return;
		}

		foreach ( $custom_fields as $field ) {
			if ( empty( $field['name'] ) || ! isset( $data[ $field['name'] ] ) ) {
				continue;
			}
			$value = $data[ $field['name'] ];
			$type  = isset( $field['type'] ) ? $field['type'] : 'text';

			if ( in_array( $type, array( 'checkbox' ), true ) || ( false !== strpos( (string) $value, '|' ) ) ) {
				$parts = array_map( 'trim', explode( '|', (string) $value ) );
				delete_post_meta( $post_id, $field['name'] );
				foreach ( $parts as $part ) {
					if ( '' !== $part ) {
						add_post_meta( $post_id, $field['name'], sanitize_text_field( $part ) );
					}
				}
				// Multichoice search companion key used by TEC Pro (double underscore).
				update_post_meta( $post_id, '_' . $field['name'], implode( '|', $parts ) );
			} else {
				update_post_meta( $post_id, $field['name'], sanitize_text_field( $value ) );
			}
		}
	}

	/**
	 * Event Tickets global stock meta (event-level only).
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_tickets_meta( $post_id, array $data ) {
		if ( ! EventCalendarExtension::is_event_tickets_active() ) {
			return;
		}
		if ( isset( $data['_tribe_ticket_use_global_stock'] ) ) {
			update_post_meta(
				$post_id,
				'_tribe_ticket_use_global_stock',
				$this->is_truthy( $data['_tribe_ticket_use_global_stock'] ) ? '1' : ''
			);
		}
		if ( isset( $data['_tribe_ticket_global_stock_level'] ) ) {
			update_post_meta(
				$post_id,
				'_tribe_ticket_global_stock_level',
				absint( $data['_tribe_ticket_global_stock_level'] )
			);
		}
	}

	/**
	 * Apply recurrence via Events Calendar Pro CT1 APIs — never fabricate child posts.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_recurrence( $post_id, array $data ) {
		if ( ! EventCalendarExtension::is_tec_pro_active() ) {
			return;
		}

		$has_recurrence_input = $this->has_any_keys(
			$data,
			array(
				'recurrence_type',
				'recurrence_ical',
				'recurrence_additional_dates',
				'recurrence_exclusions',
			)
		);
		if ( ! $has_recurrence_input ) {
			return;
		}

		$start = (string) get_post_meta( $post_id, '_EventStartDate', true );
		$end   = (string) get_post_meta( $post_id, '_EventEndDate', true );
		$tz    = (string) get_post_meta( $post_id, '_EventTimezone', true );
		if ( empty( $tz ) ) {
			$tz = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : 'UTC';
		}
		if ( empty( $start ) || empty( $end ) ) {
			return;
		}

		$recurrence = null;

		// Prefer iCal / RSET string when provided.
		if ( ! empty( $data['recurrence_ical'] ) && class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Events\Recurrence' ) ) {
			try {
				$recurrence = \TEC\Events_Pro\Custom_Tables\V1\Events\Recurrence::from_icalendar_string(
					$data['recurrence_ical'],
					$start,
					$end
				)->to_event_recurrence();
			} catch ( \Throwable $e ) {
				$recurrence = null;
			}
		}

		if ( null === $recurrence && ! empty( $data['recurrence_type'] ) && class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Events\Recurrence' ) ) {
			$type     = strtolower( sanitize_text_field( $data['recurrence_type'] ) );
			$interval = ! empty( $data['recurrence_interval'] ) ? max( 1, (int) $data['recurrence_interval'] ) : 1;

			try {
				$builder = ( new \TEC\Events_Pro\Custom_Tables\V1\Events\Recurrence() )
					->with_start_date( $start )
					->with_end_date( $end )
					->with_timezone( $tz );

				switch ( $type ) {
					case 'daily':
					case 'day':
						$builder->with_daily_recurrence( $interval );
						break;
					case 'weekly':
					case 'week':
						$days = $this->parse_weekdays( isset( $data['recurrence_weekdays'] ) ? $data['recurrence_weekdays'] : '' );
						$builder->with_weekly_recurrence( $interval, ! empty( $days ) ? $days : null );
						break;
					case 'monthly':
					case 'month':
						if ( method_exists( $builder, 'with_monthly_recurrence' ) ) {
							$same_day = empty( $data['recurrence_month_number'] ) && empty( $data['recurrence_month_day'] );
							$number   = ! empty( $data['recurrence_month_number'] ) ? $data['recurrence_month_number'] : 1;
							$day      = ! empty( $data['recurrence_month_day'] ) ? sanitize_text_field( $data['recurrence_month_day'] ) : 'mon';
							$builder->with_monthly_recurrence( $interval, $same_day, $number, $day );
						}
						break;
					case 'yearly':
					case 'year':
						if ( method_exists( $builder, 'with_yearly_recurrence' ) ) {
							$month = ! empty( $data['recurrence_year_month'] ) ? (int) $data['recurrence_year_month'] : null;
							$builder->with_yearly_recurrence( $interval, true, 1, 1, $month );
						}
						break;
					case 'date':
					case 'custom':
					case 'additional':
						// Handled via additional dates below.
						break;
					default:
						return;
				}

				$end_type = isset( $data['recurrence_end_type'] ) ? strtolower( sanitize_text_field( $data['recurrence_end_type'] ) ) : 'never';
				if ( in_array( $end_type, array( 'after', 'count' ), true ) && ! empty( $data['recurrence_end_count'] ) ) {
					$builder->with_end_after( (int) $data['recurrence_end_count'] );
				} elseif ( in_array( $end_type, array( 'on', 'date' ), true ) && ! empty( $data['recurrence_end_date'] ) ) {
					$builder->with_end_on( $data['recurrence_end_date'] );
				} else {
					$builder->with_end_never();
				}

				// Additional / custom dates MUST be applied before exclusions.
				// TEC's with_date_exclusion() sticky-switches the builder into exclusions mode,
				// so later with_date_recurrence() calls would incorrectly become exclusions.
				if ( ! empty( $data['recurrence_additional_dates'] ) && method_exists( $builder, 'with_date_recurrence' ) ) {
					$this->reset_recurrence_builder_to_rules( $builder );
					foreach ( $this->parse_string_list( $data['recurrence_additional_dates'] ) as $extra_date ) {
						$extra_date = trim( $extra_date );
						if ( $extra_date !== '' && $this->is_valid_datetime( $extra_date ) ) {
							$builder->with_date_recurrence( $extra_date );
						}
					}
				}

				// Exclusions (always last — leaves builder in exclusions mode).
				if ( ! empty( $data['recurrence_exclusions'] ) ) {
					foreach ( $this->parse_string_list( $data['recurrence_exclusions'] ) as $excl ) {
						$excl = trim( $excl );
						if ( $excl === '' ) {
							continue;
						}
						if ( method_exists( $builder, 'with_date_exclusion' ) ) {
							$builder->with_date_exclusion( $excl );
						} elseif ( method_exists( $builder, 'with_exclusion' ) ) {
							$builder->with_exclusion( $excl );
						}
					}
				}

				$recurrence = $builder->to_event_recurrence();
				if ( ! empty( $data['recurrence_description'] ) ) {
					$recurrence['description'] = sanitize_text_field( $data['recurrence_description'] );
				}
			} catch ( \Throwable $e ) {
				$recurrence = null;
			}
		}

		if ( empty( $recurrence ) || ! is_array( $recurrence ) ) {
			return;
		}

		// Official CT1 upsert path.
		if ( class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Repository\Events' ) ) {
			try {
				// Ensure the Event row exists in custom tables before upserting occurrences.
				if ( class_exists( '\TEC\Events\Custom_Tables\V1\Models\Event' ) ) {
					\TEC\Events\Custom_Tables\V1\Models\Event::upsert(
						array( 'post_id' ),
						\TEC\Events\Custom_Tables\V1\Models\Event::data_from_post( $post_id )
					);
				}

				$repo    = new \TEC\Events_Pro\Custom_Tables\V1\Repository\Events();
				$success = $repo->upsert_occurrences( $post_id, array( 'recurrence' => $recurrence ) );
				if ( $success ) {
					return;
				}
			} catch ( \Throwable $e ) {
				// Fall through to meta write.
			}
		}

		update_post_meta( $post_id, '_EventRecurrence', $recurrence );

		// Trigger TEC meta update hooks for legacy listeners.
		do_action( 'tribe_events_update_meta', $post_id, array( 'recurrence' => $recurrence ), get_post( $post_id ) );
	}

	/**
	 * Link event to a Series (create series by title if needed).
	 *
	 * @param int   $post_id Event ID.
	 * @param array $data    Mapped values.
	 * @return void
	 */
	private function save_series_relationship( $post_id, array $data ) {
		if ( ! EventCalendarExtension::is_tec_pro_active() ) {
			return;
		}

		$series_id    = ! empty( $data['event_series_id'] ) ? (int) $data['event_series_id'] : 0;
		$series_title = isset( $data['event_series_title'] ) ? trim( (string) $data['event_series_title'] ) : '';

		if ( ! $series_id && $series_title === '' ) {
			return;
		}

		if ( $series_id && ! $this->is_post_type( $series_id, 'tribe_event_series' ) ) {
			$series_id = 0;
		}

		if ( ! $series_id && $series_title !== '' ) {
			$series_id = $this->find_post_by_title( $series_title, 'tribe_event_series' );
			if ( ! $series_id ) {
				$series_id = wp_insert_post(
					array(
						'post_title'  => $series_title,
						'post_type'   => 'tribe_event_series',
						'post_status' => 'publish',
					),
					true
				);
				if ( is_wp_error( $series_id ) ) {
					return;
				}
				$series_id = (int) $series_id;
			}
		}

		if ( ! $series_id ) {
			return;
		}

		if ( class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Models\Event' )
			|| class_exists( '\TEC\Events\Custom_Tables\V1\Models\Event' ) ) {
			try {
				if ( class_exists( '\TEC\Events\Custom_Tables\V1\Models\Event' ) ) {
					\TEC\Events\Custom_Tables\V1\Models\Event::upsert(
						array( 'post_id' ),
						\TEC\Events\Custom_Tables\V1\Models\Event::data_from_post( $post_id )
					);
				}
				$event_model = \TEC\Events\Custom_Tables\V1\Models\Event::find( $post_id, 'post_id' );
				if ( $event_model && class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Series\Relationship' ) ) {
					$relationship = new \TEC\Events_Pro\Custom_Tables\V1\Series\Relationship();
					$relationship->with_event( $event_model, array( $series_id ) );
					return;
				}
			} catch ( \Throwable $e ) {
				// Fall through.
			}
		}

		// Soft fallback: store series ID meta for round-trip if relationship API unavailable.
		update_post_meta( $post_id, '_tec_relationship_event_to_series', array( $series_id ) );
	}

	/**
	 * Standalone venue CPT meta via TEC Venue API.
	 *
	 * @param int    $post_id Venue ID.
	 * @param array  $data    Mapped values.
	 * @param string $mode    Mode.
	 * @return void
	 */
	private function import_standalone_venue( $post_id, array $data, $mode ) {
		$payload = array();
		$map     = array(
			'_VenueAddress'       => 'Address',
			'_VenueCity'          => 'City',
			'_VenueCountry'       => 'Country',
			'_VenueProvince'      => 'Province',
			'_VenueState'         => 'State',
			'_VenueStateProvince' => 'StateProvince',
			'_VenueZip'           => 'Zip',
			'_VenuePhone'         => 'Phone',
			'_VenueURL'           => 'URL',
			'_VenueShowMap'       => 'ShowMap',
			'_VenueShowMapLink'   => 'ShowMapLink',
		);
		foreach ( $map as $meta => $api ) {
			if ( isset( $data[ $meta ] ) ) {
				$payload[ $api ] = $data[ $meta ];
			}
		}
		$payload['Venue'] = get_the_title( $post_id );

		if ( class_exists( 'Tribe__Events__API' ) ) {
			\Tribe__Events__API::updateVenue( $post_id, $payload );
		} else {
			foreach ( $data as $key => $value ) {
				if ( 0 === strpos( $key, '_Venue' ) ) {
					update_post_meta( $post_id, $key, sanitize_text_field( $value ) );
				}
			}
		}

		if ( isset( $data['_VenueLat'] ) ) {
			update_post_meta( $post_id, '_VenueLat', sanitize_text_field( $data['_VenueLat'] ) );
		}
		if ( isset( $data['_VenueLng'] ) ) {
			update_post_meta( $post_id, '_VenueLng', sanitize_text_field( $data['_VenueLng'] ) );
		}
	}

	/**
	 * Standalone organizer CPT meta.
	 *
	 * @param int    $post_id Organizer ID.
	 * @param array  $data    Mapped values.
	 * @param string $mode    Mode.
	 * @return void
	 */
	private function import_standalone_organizer( $post_id, array $data, $mode ) {
		$payload = array(
			'Organizer' => get_the_title( $post_id ),
		);
		if ( isset( $data['_OrganizerEmail'] ) ) {
			$payload['Email'] = sanitize_email( $data['_OrganizerEmail'] );
		}
		if ( isset( $data['_OrganizerPhone'] ) ) {
			$payload['Phone'] = sanitize_text_field( $data['_OrganizerPhone'] );
		}
		if ( isset( $data['_OrganizerWebsite'] ) ) {
			$payload['Website'] = esc_url_raw( $data['_OrganizerWebsite'] );
		}

		if ( class_exists( 'Tribe__Events__API' ) ) {
			\Tribe__Events__API::updateOrganizer( $post_id, $payload );
		} else {
			foreach ( $data as $key => $value ) {
				if ( 0 === strpos( $key, '_Organizer' ) ) {
					update_post_meta( $post_id, $key, sanitize_text_field( $value ) );
				}
			}
		}
	}

	/**
	 * Standalone series CPT — attach event IDs.
	 *
	 * @param int    $post_id Series ID.
	 * @param array  $data    Mapped values.
	 * @param string $mode    Mode.
	 * @return void
	 */
	private function import_standalone_series( $post_id, array $data, $mode ) {
		if ( empty( $data['series_event_ids'] ) ) {
			return;
		}
		$event_ids = $this->parse_id_list( $data['series_event_ids'] );
		$event_ids = array_values(
			array_filter(
				$event_ids,
				function ( $id ) {
					return $this->is_post_type( $id, 'tribe_events' );
				}
			)
		);
		if ( empty( $event_ids ) ) {
			return;
		}

		if ( class_exists( '\TEC\Events_Pro\Custom_Tables\V1\Series\Relationship' ) ) {
			try {
				$series_post = get_post( $post_id );
				if ( $series_post ) {
					$relationship = new \TEC\Events_Pro\Custom_Tables\V1\Series\Relationship();
					$relationship->with_series( $series_post, $event_ids, true );
				}
			} catch ( \Throwable $e ) {
				// Soft fail.
			}
		}
	}

	/**
	 * Legacy term_map support from older EVENTS map merges.
	 *
	 * @param int   $post_id  Event ID.
	 * @param array $data     Mapped values.
	 * @param mixed $term_map Term map.
	 * @return void
	 */
	private function maybe_apply_legacy_terms( $post_id, array $data, $term_map ) {
		if ( empty( $term_map ) || ! is_array( $term_map ) ) {
			return;
		}
		foreach ( $term_map as $taxonomy => $mapped_field ) {
			if ( empty( $data[ $mapped_field ] ) ) {
				continue;
			}
			$terms = $this->parse_string_list( $data[ $mapped_field ] );
			if ( ! empty( $terms ) ) {
				wp_set_object_terms( $post_id, $terms, $taxonomy, true );
			}
		}
	}

	/**
	 * Fallback when Tribe__Events__API is unavailable.
	 *
	 * @param int   $post_id Event ID.
	 * @param array $args    Event args.
	 * @return void
	 */
	private function fallback_save_event_meta( $post_id, array $args ) {
		foreach ( $args as $key => $value ) {
			if ( 0 === strpos( $key, 'Event' ) || 0 === strpos( $key, '_Event' ) ) {
				$meta_key = ( 0 === strpos( $key, '_' ) ) ? $key : '_' . $key;
				if ( is_array( $value ) ) {
					continue;
				}
				update_post_meta( $post_id, $meta_key, sanitize_text_field( (string) $value ) );
			}
		}
		if ( ! empty( $args['_EventStartDate'] ) && ! empty( $args['_EventEndDate'] ) ) {
			$start = strtotime( $args['_EventStartDate'] );
			$end   = strtotime( $args['_EventEndDate'] );
			if ( $start && $end && $end >= $start ) {
				update_post_meta( $post_id, '_EventDuration', $end - $start );
			}
		}
	}

	/* --------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Combine date + optional time into Y-m-d H:i:s.
	 *
	 * @param string $date Date or datetime.
	 * @param string $time Optional time.
	 * @return string
	 */
	private function compose_datetime( $date, $time = '' ) {
		$date = trim( (string) $date );
		$time = trim( (string) $time );
		if ( '' === $date ) {
			return '';
		}

		// Prefer wall-clock parsing so PHP/server timezone never skews local event times.
		if ( preg_match( '/^(\d{4}-\d{2}-\d{2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/', $date, $m ) ) {
			$ymd = $m[1];
			if ( ! empty( $m[2] ) ) {
				$h = str_pad( (string) (int) $m[2], 2, '0', STR_PAD_LEFT );
				$i = $m[3];
				$s = isset( $m[4] ) && '' !== $m[4] ? $m[4] : '00';
				return $ymd . ' ' . $h . ':' . $i . ':' . $s;
			}
			if ( '' !== $time && preg_match( '/^(\d{1,2}):(\d{2})(?::(\d{2}))?/', $time, $tm ) ) {
				$h = str_pad( (string) (int) $tm[1], 2, '0', STR_PAD_LEFT );
				$i = $tm[2];
				$s = isset( $tm[3] ) && '' !== $tm[3] ? $tm[3] : '00';
				return $ymd . ' ' . $h . ':' . $i . ':' . $s;
			}
			return $ymd . ' 00:00:00';
		}

		// Fallback for non-ISO date strings (e.g. "September 15, 2026 9:00am").
		$combined = '' !== $time ? ( $date . ' ' . $time ) : $date;
		try {
			$dt = date_create_immutable( $combined );
			return $dt ? $dt->format( 'Y-m-d H:i:s' ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}

	/**
	 * TEC Recurrence builder sticky-switches to exclusions after with_date_exclusion().
	 * Reset it to rules so additional RDATEs land in rules, not exclusions.
	 *
	 * @param object $builder Recurrence builder.
	 * @return void
	 */
	private function reset_recurrence_builder_to_rules( $builder ) {
		try {
			$ref = new \ReflectionClass( $builder );
			if ( $ref->hasProperty( 'rules_or_exclusion' ) ) {
				$prop = $ref->getProperty( 'rules_or_exclusion' );
				$prop->setAccessible( true );
				$prop->setValue( $builder, 'rules' );
			}
		} catch ( \Throwable $e ) {
			// Soft fail — caller still attempts with_date_recurrence.
		}
	}

	/**
	 * Split a local wall-clock datetime into TEC API date/time parts without TZ conversion.
	 *
	 * @param string $datetime Datetime string.
	 * @return array{date:string,hour12:string,minute:string,meridian:string,datetime:string}|array
	 */
	private function split_wallclock_datetime( $datetime ) {
		$datetime = $this->compose_datetime( $datetime, '' );
		if ( '' === $datetime || ! preg_match( '/^(\d{4}-\d{2}-\d{2}) (\d{2}):(\d{2}):(\d{2})$/', $datetime, $m ) ) {
			return array();
		}

		$hour24   = (int) $m[2];
		$meridian = $hour24 >= 12 ? 'pm' : 'am';
		$hour12   = $hour24 % 12;
		if ( 0 === $hour12 ) {
			$hour12 = 12;
		}

		return array(
			'date'     => $m[1],
			'hour12'   => str_pad( (string) $hour12, 2, '0', STR_PAD_LEFT ),
			'minute'   => $m[3],
			'meridian' => $meridian,
			'datetime' => $datetime,
		);
	}

	/**
	 * @param string $value Datetime candidate.
	 * @return bool
	 */
	private function is_valid_datetime( $value ) {
		if ( '' === $value || null === $value ) {
			return false;
		}
		return false !== strtotime( (string) $value );
	}

	/**
	 * @param mixed $value Value.
	 * @return bool
	 */
	private function is_truthy( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		$value = strtolower( trim( (string) $value ) );
		return in_array( $value, array( '1', 'yes', 'true', 'on', 'y' ), true );
	}

	/**
	 * @param int    $post_id  Post ID.
	 * @param string $post_type Expected type.
	 * @return bool
	 */
	private function is_post_type( $post_id, $post_type ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return false;
		}
		return get_post_type( $post_id ) === $post_type;
	}

	/**
	 * Find a published/draft post by title for a CPT.
	 *
	 * @param string $title     Title.
	 * @param string $post_type CPT.
	 * @return int
	 */
	private function find_post_by_title( $title, $post_type ) {
		$title = trim( (string) $title );
		if ( '' === $title ) {
			return 0;
		}

		// Numeric titles treated as IDs when valid.
		if ( is_numeric( $title ) && $this->is_post_type( (int) $title, $post_type ) ) {
			return (int) $title;
		}

		$posts = get_posts(
			array(
				'post_type'              => $post_type,
				'title'                  => $title,
				'post_status'            => array( 'publish', 'pending', 'draft', 'private', 'future' ),
				'numberposts'            => 1,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		if ( ! empty( $posts[0]->ID ) ) {
			return (int) $posts[0]->ID;
		}

		// Fallback LIKE search for older WP without title arg behaviour.
		global $wpdb;
		$id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = %s AND post_status != 'trash' ORDER BY ID ASC LIMIT 1",
				$title,
				$post_type
			)
		);
		return $id ? (int) $id : 0;
	}

	/**
	 * Find organizer by email meta.
	 *
	 * @param string $email Email.
	 * @return int
	 */
	private function find_organizer_by_email( $email ) {
		$email = sanitize_email( $email );
		if ( '' === $email ) {
			return 0;
		}
		$posts = get_posts(
			array(
				'post_type'      => 'tribe_organizer',
				'post_status'    => array( 'publish', 'pending', 'draft', 'private' ),
				'posts_per_page' => 1,
				'meta_key'       => '_OrganizerEmail',
				'meta_value'     => $email,
				'fields'         => 'ids',
			)
		);
		return ! empty( $posts[0] ) ? (int) $posts[0] : 0;
	}

	/**
	 * Parse comma/pipe/space separated IDs.
	 *
	 * @param mixed $value Raw value.
	 * @return int[]
	 */
	private function parse_id_list( $value ) {
		$parts = preg_split( '/[,|;\s]+/', (string) $value );
		$ids   = array();
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( is_numeric( $part ) ) {
				$ids[] = (int) $part;
			}
		}
		return $ids;
	}

	/**
	 * Parse delimited strings.
	 *
	 * @param string $value     Raw.
	 * @param string $delimiter Primary delimiter (also accepts comma).
	 * @return string[]
	 */
	private function parse_string_list( $value, $delimiter = ',' ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return array();
		}
		$pattern = '/[' . preg_quote( $delimiter, '/' ) . ';|]+/';
		$parts   = preg_split( $pattern, $value );
		return array_values(
			array_filter(
				array_map( 'trim', $parts ),
				static function ( $v ) {
					return '' !== $v;
				}
			)
		);
	}

	/**
	 * Convert weekday tokens to TEC day numbers / abbreviations.
	 *
	 * @param string $value Weekdays string.
	 * @return string[]
	 */
	private function parse_weekdays( $value ) {
		$map = array(
			'1' => 'mon',
			'2' => 'tue',
			'3' => 'wed',
			'4' => 'thu',
			'5' => 'fri',
			'6' => 'sat',
			'7' => 'sun',
			'mon' => 'mon',
			'monday' => 'mon',
			'tue' => 'tue',
			'tues' => 'tue',
			'tuesday' => 'tue',
			'wed' => 'wed',
			'wednesday' => 'wed',
			'thu' => 'thu',
			'thur' => 'thu',
			'thurs' => 'thu',
			'thursday' => 'thu',
			'fri' => 'fri',
			'friday' => 'fri',
			'sat' => 'sat',
			'saturday' => 'sat',
			'sun' => 'sun',
			'sunday' => 'sun',
		);
		$out = array();
		foreach ( $this->parse_string_list( $value ) as $day ) {
			$key = strtolower( $day );
			if ( isset( $map[ $key ] ) ) {
				$out[] = $map[ $key ];
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * @param array    $data Array.
	 * @param string[] $keys Keys.
	 * @return bool
	 */
	private function has_any_keys( array $data, array $keys ) {
		foreach ( $keys as $key ) {
			if ( isset( $data[ $key ] ) && '' !== $data[ $key ] ) {
				return true;
			}
		}
		return false;
	}
}
