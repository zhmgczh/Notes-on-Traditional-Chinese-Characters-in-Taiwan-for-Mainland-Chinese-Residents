<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH'))
    exit;

use Error;
use SureCart\Models\Product;
use SureCart\Models\Price;
use SureCart\Models\Order;
use SureCart\Models\Customer;
use SureCart\Models\Coupon;
use SureCart\Models\Subscription;

class SureCartImport
{

    private static $surecart_instance = null;
    private $variant_data_store = [];
    private static $parent_sku_map = [];

    public static function getInstance()
    {
        if (SureCartImport::$surecart_instance === null) {
            SureCartImport::$surecart_instance = new SureCartImport;
        }
        return SureCartImport::$surecart_instance;
    }


    /**
     * Set SureCart values and process import
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param int $post_id Post ID
     * @param string $type Import type
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function set_surecart_values(
        $header_array,
        $value_array,
        $map,
        $post_id,
        $type,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        $helpers_instance = ImportHelpers::getInstance();

        $post_values = $helpers_instance->get_header_values(
            $map,
            $header_array,
            $value_array
        );
        
        $this->surecart_import_function(
            $post_values,
            $type,
            $post_id,
            $header_array,
            $value_array,
            $hash_key,
            $gmode,
            $templatekey,
            $line_number
        );
    }

    /**
     * Main SureCart import function
     *
     * @param array $data_array Mapped data
     * @param string $importas Import type
     * @param int $pID Post ID
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return array Created fields
     */
    public function surecart_import_function(
        $data_array,
        $importas,
        $pID,
        $header_array,
        $value_array,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb;

        if (!is_plugin_active('surecart/surecart.php')) {
            return [];
        }

        $createdFields = array_keys($data_array);
        $surecart = [];

        // Map common fields
        $mapping = [
            'product_id' => ['product_id'],
            'product_name' => ['product_name', 'post_title'],
            'post_title' => ['post_title', 'product_name'],
            'post_content' => ['post_content', 'product_description', 'description'],
            'post_excerpt' => ['post_excerpt', 'short_description'],
            'post_status' => ['post_status', 'status'],
            'sku' => ['sku'],
            'price' => ['price'],
            'sale_price' => ['sale_price'],
            'stock_enabled' => ['stock_enabled'],
            'stock_quantity' => ['stock_quantity'],
            'allow_purchase_out_of_stock' => ['allow_purchase_out_of_stock', 'allow_backorders'],
            'tax_enabled' => ['tax_enabled'],
            'tax_status' => ['tax_status'],
            'featured_image' => ['featured_image', 'thumbnail_id'],
            'gallery_images' => ['gallery_images'],
            'product_type' => ['product_type'],
            'product_is_varient' => ['product_is_varient', 'product_is_variant', 'is_varient', 'is_variant'],
            'recurring_interval' => ['recurring_interval'],
            'recurring_period' => ['recurring_period'],
            'recurring_price' => ['recurring_price'],
            'variants' => ['variants'],
            'product_categories' => ['product_categories'],
            'product_tags' => ['product_tags'],
            'price_name' => ['price_name'],
            'purchase_link_text' => ['purchase_link_text'],
            'purchase_link_url' => ['purchase_link_url'],
            'download_files' => ['download_files'],
            'product_meta' => ['product_meta'],
            'compare_at_price' => ['compare_at_price'],
            'product_collections' => ['product_collections'],
            'tax_rate' => ['tax_rate'],
            'shipping_profile' => ['shipping_profile'],
            'seo_title' => ['seo_title', 'page_title'],
            'seo_description' => ['seo_description', 'meta_description'],
            'weight' => ['weight'],
            'length' => ['length'],
            'width' => ['width'],
            'height' => ['height'],
            'weight_unit' => ['weight_unit'],
            'variant_options' => ['variant_options'],
            'license' => ['license'],
            'license_count' => ['license_count'],
            'parent_sku' => ['parent_sku'],
            'custom_affiliate_commission' => ['custom_affiliate_commission'],
            'commission_type' => ['commission_type'],
            'percent_commission' => ['percent_commission'],
            'amount_commission' => ['amount_commission'],
            'subscription_commission_enabled' => ['subscription_commission_enabled'],
            'subscription_commission_days' => ['subscription_commission_days'],
            'lifetime_commission_enabled' => ['lifetime_commission_enabled'],
            'lifetime_commission_days' => ['lifetime_commission_days']
        ];

        $row_data = [];
        if (!empty($header_array) && !empty($value_array) && count($header_array) === count($value_array)) {
            $row_data = array_combine($header_array, $value_array);
        }

        $combined_data = array_merge($row_data, $data_array);

        foreach ($mapping as $key => $aliases) {
            foreach ($aliases as $alias) {
                if (isset($combined_data[$alias]) && $combined_data[$alias] !== '') {
                    $surecart[$key] = $combined_data[$alias];
                    break;
                }
            }
        }




        // Handle product creation/update
        if ($importas === 'SURECART_PRODUCTS') {
            $this->import_product($surecart, $pID, $hash_key, $line_number, $gmode);
        }

        return $createdFields;
    }

    private function handle_inventory(&$product_args, $data) {
        if (isset($data['stock_enabled'])) {
            $product_args['stock_enabled'] = in_array(strtolower($data['stock_enabled']), ['yes', '1', 'true', 'on']);
        }
        if (isset($data['stock_quantity']) && $data['stock_quantity'] !== '') {
            // SureCart uses stock_adjustment (not available_stock)
            $product_args['stock_adjustment'] = intval($data['stock_quantity']);
            $product_args['stock_enabled'] = true;
        }
        if (isset($data['allow_purchase_out_of_stock'])) {
            $product_args['allow_out_of_stock_purchases'] = in_array(strtolower($data['allow_purchase_out_of_stock']), ['yes', '1', 'true', 'on']);
        }
    }

    private function handle_tax(&$product_args, $data) {
        if (isset($data['tax_enabled'])) {
            $product_args['tax_enabled'] = in_array(strtolower($data['tax_enabled']), ['yes', '1', 'true', 'on']);
        }
        if (!empty($data['tax_status'])) {
            $product_args['tax_status'] = sanitize_text_field($data['tax_status']);
        }
        // Tax Registration dynamically
        if (!empty($data['tax_rate']) && class_exists('\SureCart\Models\TaxRegistration')) {
            try {
                $parts = array_map('trim', explode(':', $data['tax_rate']));
                if (count($parts) >= 2) {
                    \SureCart\Models\TaxRegistration::create([
                        'name' => $parts[0],
                        'rate' => floatval($parts[1]),
                        'country' => isset($parts[2]) ? $parts[2] : 'US',
                        'status' => 'active'
                    ]);
                }
            } catch (\Throwable $e) {
            }
        }
    }

    private function handle_variants(&$product_args, $data) {
        if (!empty($data['variant_options'])) {
            $variants = [];
            $variant_entries = explode('|', $data['variant_options']);
            foreach ($variant_entries as $entry) {
                $parts = explode(':', $entry, 2);
                if (count($parts) === 2) {
                    $variants[] = [
                        'name' => trim($parts[0]),
                        'values' => array_map('trim', explode(',', $parts[1]))
                    ];
                }
            }
            if (!empty($variants)) {
                $product_args['variant_options'] = $variants;
                $product_args['type'] = 'variable';
            }
        }
    }

    private function get_variant_permutations($variants) {
        $result = [[]];
        foreach ($variants as $property) {
            $append = [];
            foreach ($result as $product) {
                foreach ($property['values'] as $item) {
                    $append[] = array_merge($product, [$item]);
                }
            }
            $result = $append;
        }
        return $result;
    }

    /**
     * Build inline variant payload for product creation (used in product_args).
     * Returns the variants array and prices array to embed directly into the product.
     */
    private function build_inline_variants_and_prices($data, $pID = 0) {
        if (empty($data['variant_options'])) {
            return ['variants' => [], 'prices' => []];
        }

        // Ensure WP media functions are loaded once
        if (!function_exists('media_sideload_image')) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $variant_option_defs = [];
        $variant_entries = explode('|', $data['variant_options']);
        foreach ($variant_entries as $entry) {
            $parts = explode(':', $entry, 2);
            if (count($parts) === 2) {
                $variant_option_defs[] = [
                    'name'   => trim($parts[0]),
                    'values' => array_map('trim', explode(',', $parts[1]))
                ];
            }
        }

        $permutations = $this->get_variant_permutations($variant_option_defs);
        $currency = strtolower(function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'usd');

        $variants = [];
        $prices   = [];
        $position = 0;

        foreach ($permutations as $index => $permutation) {
            $opt1 = isset($permutation[0]) ? $permutation[0] : null;
            $opt2 = isset($permutation[1]) ? $permutation[1] : null;
            $opt3 = isset($permutation[2]) ? $permutation[2] : null;

            $variant = ['position' => $position++];
            if ($opt1) $variant['option_1'] = $opt1;
            if ($opt2) $variant['option_2'] = $opt2;
            if ($opt3) $variant['option_3'] = $opt3;

            // SKU
            if (!empty($data['sku'])) {
                $variant['sku'] = sanitize_text_field($data['sku']);
            }

            // Stock — use stock_adjustment (SureCart API field)
            if (isset($data['stock_quantity']) && $data['stock_quantity'] !== '') {
                $variant['stock_enabled']    = true;
                $variant['stock_adjustment'] = intval($data['stock_quantity']);
            } elseif (isset($data['stock_enabled'])) {
                $variant['stock_enabled']    = in_array(strtolower(trim($data['stock_enabled'])), ['yes', '1', 'true', 'on']);
            }

            // Weight
            if (isset($data['weight']) && $data['weight'] !== '') {
                $v_weight = floatval($data['weight']);
                if ($v_weight > 0) {
                    $variant['weight']      = $v_weight;
                    $variant['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
                }
            }

            // Dimensions
            if (!empty($data['length']) || !empty($data['width']) || !empty($data['height'])) {
                $dim_unit = 'in';
                if (!empty($data['dimension_unit'])) {
                    $dim_unit = sanitize_text_field($data['dimension_unit']);
                } elseif (!empty($data['weight_unit'])) {
                    $wu = strtolower(trim($data['weight_unit']));
                    if (in_array($wu, ['in', 'cm', 'mm', 'm', 'ft'])) {
                        $dim_unit = $wu;
                    }
                }
                $variant['dimensions'] = [
                    'length' => floatval($data['length'] ?? 0),
                    'width'  => floatval($data['width'] ?? 0),
                    'height' => floatval($data['height'] ?? 0),
                    'unit'   => $dim_unit,
                ];
            }

            // Backorders
            if (isset($data['allow_purchase_out_of_stock']) && $data['allow_purchase_out_of_stock'] !== '') {
                $bool_val = strtolower(trim($data['allow_purchase_out_of_stock']));
                $variant['allow_out_of_stock_purchases'] = ($bool_val === 'yes' || $bool_val === 'true' || $bool_val === '1' || $bool_val === 'on');
            }

            // Tax charge
            if (isset($data['tax_enabled']) && $data['tax_enabled'] !== '') {
                $bool_val = strtolower(trim($data['tax_enabled']));
                $variant['tax_enabled'] = ($bool_val === 'yes' || $bool_val === 'true' || $bool_val === '1' || $bool_val === 'on');
            }

            // Product type (physical / digital)
            if (!empty($data['product_type'])) {
                $type_val = strtolower(trim($data['product_type']));
                $variant['shipping_enabled']    = ($type_val === 'physical');
                $variant['auto_fulfill_enabled'] = ($type_val !== 'physical');
            }

            // Media
            $metadata = [];
            if (!empty($data['featured_image'])) {
                $media_url = trim($data['featured_image']);
                $media_instance = null;
                if (class_exists('\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling')) {
                    try {
                        $media_instance = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::getInstance();
                    } catch (\Throwable $t) {
                        $media_instance = null;
                    }
                }
                $attachment_id = $media_instance ? $media_instance->image_function($media_url, $pID) : 0;

                if ($attachment_id) {
                    $metadata['wp_media'] = $attachment_id;
                    $metadata['wp_image_id'] = $attachment_id;
                    $variant['image'] = ['url' => (function_exists('wp_get_attachment_url') ? wp_get_attachment_url($attachment_id) : '') ?: $media_url];
                } else {
                    $variant['image'] = ['url' => $media_url];
                }
            }

            // License
            if (!empty($data['license'])) {
                $metadata['license'] = trim($data['license']);
            }
            if (!empty($data['license_count'])) {
                $metadata['license_count'] = intval(trim($data['license_count']));
            }

            if (!empty($metadata)) {
                $variant['metadata'] = $metadata;
            }

            // Price directly on variant
            $price_val = isset($data['price']) && $data['price'] !== '' ? $data['price'] : (isset($data['sale_price']) && $data['sale_price'] !== '' ? $data['sale_price'] : null);
            if ($price_val !== null) {
                $variant['amount'] = intval(floatval($price_val) * 100);
                if (isset($data['compare_at_price']) && floatval($data['compare_at_price']) > 0) {
                    $variant['compare_at_amount'] = intval(floatval($data['compare_at_price']) * 100);
                }
            }

            $variants[] = $variant;

            // Inline price definition for this variant
            if ($price_val !== null) {
                $price_obj = [
                    'amount'   => intval(floatval($price_val) * 100),
                    'currency' => $currency,
                    'name'     => !empty($data['price_name']) ? sanitize_text_field($data['price_name']) : implode(' / ', array_filter([$opt1, $opt2, $opt3])),
                    'position' => $index,
                    'archived' => false,
                    'metadata' => ['variant_index' => $index],
                ];

                if (isset($data['compare_at_price']) && floatval($data['compare_at_price']) > 0) {
                    $price_obj['compare_at_amount'] = intval(floatval($data['compare_at_price']) * 100);
                }

                $prices[] = $price_obj;
            }
        }

        return ['variants' => $variants, 'prices' => $prices];
    }

    private function handle_variant_details($sc_id, $data, $pID = 0) {
        if (empty($data['variant_options'])) {
            return;
        }

        $variant_option_defs = [];
        $variant_entries = explode('|', $data['variant_options']);
        foreach ($variant_entries as $entry) {
            $parts = explode(':', $entry, 2);
            if (count($parts) === 2) {
                $variant_option_defs[] = [
                    'name'   => trim($parts[0]),
                    'values' => array_map('trim', explode(',', $parts[1]))
                ];
            }
        }

        $permutations = $this->get_variant_permutations($variant_option_defs);
        $media_instance = null;
        if (class_exists('\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling')) {
            try {
                $media_instance = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::getInstance();
            } catch (\Throwable $t) {
                $media_instance = null;
            }
        }

        // Fetch existing variants from SureCart after product creation
        $existing_variants = [];
        try {
            if (class_exists('\SureCart\Models\Variant')) {
                $variants_resp = \SureCart\Models\Variant::where(['product_ids' => [$sc_id], 'limit' => 100])->get();
                if ($variants_resp && isset($variants_resp->data)) {
                    foreach ($variants_resp->data as $v) {
                        $key = implode('_', array_filter([$v->option_1 ?? '', $v->option_2 ?? '', $v->option_3 ?? '']));
                        $existing_variants[$key] = $v;
                    }
                }
            }
        } catch (\Throwable $e) {
            // silently continue
        }

        foreach ($permutations as $index => $permutation) {
            $i = $index + 1;
            $opt1 = $permutation[0] ?? null;
            $opt2 = $permutation[1] ?? null;
            $opt3 = $permutation[2] ?? null;
            $key  = implode('_', array_filter([$opt1 ?? '', $opt2 ?? '', $opt3 ?? '']));

            $variant_id = isset($existing_variants[$key]) ? $existing_variants[$key]->id : null;
            if (!$variant_id) continue;

            $variant_update = [];

            // Stock
            if (isset($data['stock_quantity']) && $data['stock_quantity'] !== '') {
                $variant_update['stock_enabled']    = true;
                $variant_update['stock_adjustment'] = intval($data['stock_quantity']);
            } elseif (isset($data['stock_enabled'])) {
                $variant_update['stock_enabled']    = in_array(strtolower(trim($data['stock_enabled'])), ['yes', '1', 'true', 'on']);
            }

            // Price directly on variant
            $price_val = isset($data['price']) && $data['price'] !== '' ? $data['price'] : (isset($data['sale_price']) && $data['sale_price'] !== '' ? $data['sale_price'] : null);
            if ($price_val !== null) {
                $variant_update['amount'] = intval(floatval($price_val) * 100);
                if (isset($data['compare_at_price']) && floatval($data['compare_at_price']) > 0) {
                    $variant_update['compare_at_amount'] = intval(floatval($data['compare_at_price']) * 100);
                }
            }

            // SKU
            if (!empty($data['sku'])) {
                $variant_update['sku'] = sanitize_text_field($data['sku']);
            }

            // Weight
            if (isset($data['weight']) && $data['weight'] !== '') {
                $v_weight = floatval($data['weight']);
                if ($v_weight > 0) {
                    $variant_update['weight']      = $v_weight;
                    $variant_update['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
                }
            }

            // Dimensions
            if (!empty($data['length']) || !empty($data['width']) || !empty($data['height'])) {
                $unit = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'in';
                $variant_update['dimensions'] = [
                    'length' => floatval($data['length'] ?? 0),
                    'width'  => floatval($data['width'] ?? 0),
                    'height' => floatval($data['height'] ?? 0),
                    'unit'   => $unit,
                ];
            }

            // Backorders
            if (isset($data['allow_purchase_out_of_stock']) && $data['allow_purchase_out_of_stock'] !== '') {
                $bool_val = strtolower(trim($data['allow_purchase_out_of_stock']));
                $variant_update['allow_out_of_stock_purchases'] = ($bool_val === 'yes' || $bool_val === 'true' || $bool_val === '1' || $bool_val === 'on');
            }

            // Tax charge
            if (isset($data['tax_enabled']) && $data['tax_enabled'] !== '') {
                $bool_val = strtolower(trim($data['tax_enabled']));
                $variant_update['tax_enabled'] = ($bool_val === 'yes' || $bool_val === 'true' || $bool_val === '1' || $bool_val === 'on');
            }

            // Product type (physical / digital)
            if (!empty($data['product_type'])) {
                $type_val = strtolower(trim($data['product_type']));
                $variant_update['shipping_enabled']    = ($type_val === 'physical');
                $variant_update['auto_fulfill_enabled'] = ($type_val !== 'physical');
            }

            // Media using MediaHandling class
            if (!empty($data['featured_image'])) {
                $media_url = trim($data['featured_image']);
                $attach_id = $media_instance ? $media_instance->image_function($media_url, $pID) : 0;
                if ($attach_id) {
                    $uploaded_url = (function_exists('wp_get_attachment_url') ? wp_get_attachment_url($attach_id) : '');
                    $variant_update['metadata'] = [
                        'wp_media' => $attach_id,
                        'wp_image_id' => $attach_id
                    ];
                    if ($uploaded_url) {
                        $variant_update['image'] = ['url' => $uploaded_url];
                    }
                } else {
                    $variant_update['image'] = ['url' => $media_url];
                }
            }

            if (!empty($variant_update) && class_exists('\SureCart\Models\Variant')) {
                try {
                    \SureCart\Models\Variant::update($variant_id, $variant_update);
                } catch (\Throwable $e) {
                    // silently continue
                }
            }

            // Price creation
            if ($price_val !== null) {
                $var_price_amount = intval(floatval($price_val) * 100);
                $currency = strtolower(function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'usd');
                $price_name = !empty($data['price_name']) ? sanitize_text_field($data['price_name']) : implode(' / ', array_filter([$opt1, $opt2, $opt3]));

                $price_payload = [
                    'product'  => $sc_id,
                    'variant'  => $variant_id,
                    'amount'   => $var_price_amount,
                    'currency' => $currency,
                    'name'     => $price_name,
                ];

                if (isset($data['compare_at_price']) && floatval($data['compare_at_price']) > 0) {
                    $price_payload['compare_at_amount'] = intval(floatval($data['compare_at_price']) * 100);
                }

                if (class_exists('\SureCart\Models\Price')) {
                    try {
                        \SureCart\Models\Price::create($price_payload);
                    } catch (\Throwable $e) {
                        // silently continue
                    }
                }
            }

            // Handle downloads
            if (!empty($data['download_files'])) {
                $download_links = array_filter(array_map('trim', explode('|', $data['download_files'])));
                foreach ($download_links as $link) {
                    if (strpos($link, ',') !== false) {
                        list($dl_name, $dl_url) = array_map('trim', explode(',', $link, 2));
                    } else {
                        $dl_url  = $link;
                        $dl_name = basename($link);
                    }
                    if (class_exists('\SureCart\Models\Download')) {
                        try {
                            \SureCart\Models\Download::create([
                                'variant' => $variant_id,
                                'name'    => $dl_name ?: 'Download File',
                                'url'     => $dl_url
                            ]);
                        } catch (\Throwable $e) {
                            // continue
                        }
                    }
                }
            }
        }
    }

    private function handle_collections(&$product_args, $data) {
        if (!empty($data['product_collections'])) {
            $coll_names = array_map('trim', explode(',', $data['product_collections']));
            $coll_ids = [];
            foreach ($coll_names as $c_name) {
                if (empty($c_name)) continue;
                $found = false;
                if (class_exists('\SureCart\Models\ProductCollection')) {
                    try {
                        $existing_collections = \SureCart\Models\ProductCollection::where(['search' => $c_name])->get();
                        if ($existing_collections && isset($existing_collections->data) && is_array($existing_collections->data)) {
                            foreach ($existing_collections->data as $existing_coll) {
                                if (strtolower($existing_coll->name) === strtolower($c_name)) {
                                    $coll_ids[] = $existing_coll->id;
                                    $found = true;
                                    break;
                                }
                            }
                        }
                    } catch (\Exception $e) {
                    }
                }
                
                if (!$found && class_exists('\SureCart\Models\ProductCollection')) {
                    try {
                        $coll = \SureCart\Models\ProductCollection::create([
                            'name' => $c_name,
                            'slug' => sanitize_title($c_name)
                        ]);
                        if (!is_wp_error($coll) && isset($coll->id)) {
                            $coll_ids[] = $coll->id;
                        } else {
                        }
                    } catch (\Exception $e) {
                    }
                }
            }
            if (!empty($coll_ids)) {
                $product_args['product_collection_ids'] = $coll_ids;
                $product_args['product_collections'] = $coll_ids;
            }
        }
    }

    private function handle_categories_and_tags($data, $pID) {
        if (!$pID) return;

        // Categories
        if (!empty($data['product_categories'])) {
            $categories = array_filter(array_map('trim', explode(',', $data['product_categories'])));
            if (!empty($categories)) {
                $cat_taxonomy = (function_exists('taxonomy_exists') && taxonomy_exists('sc_category')) ? 'sc_category' : ((function_exists('taxonomy_exists') && taxonomy_exists('product_cat')) ? 'product_cat' : 'category');
                $term_ids = [];
                foreach ($categories as $cat_name) {
                    $term = function_exists('term_exists') ? term_exists($cat_name, $cat_taxonomy) : null;
                    if (!$term && function_exists('wp_insert_term')) {
                        $term = wp_insert_term($cat_name, $cat_taxonomy);
                    }
                    if ($term && !is_wp_error($term) && isset($term['term_id'])) {
                        $term_ids[] = intval($term['term_id']);
                    }
                }
                if (!empty($term_ids) && function_exists('wp_set_object_terms')) {
                    wp_set_object_terms($pID, $term_ids, $cat_taxonomy);
                }
            }
        }

        // Tags
        if (!empty($data['product_tags'])) {
            $tags = array_filter(array_map('trim', explode(',', $data['product_tags'])));
            if (!empty($tags) && function_exists('wp_set_object_terms')) {
                $tag_taxonomy = (function_exists('taxonomy_exists') && taxonomy_exists('sc_tag')) ? 'sc_tag' : ((function_exists('taxonomy_exists') && taxonomy_exists('product_tag')) ? 'product_tag' : 'post_tag');
                wp_set_object_terms($pID, $tags, $tag_taxonomy);
            }
        }
    }

    private function handle_media(&$product_args, $data, $pID, $hash_key, $line_number) {
        $medias = [];
        $media_instance = null;
        if (class_exists('\Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling')) {
            try {
                $media_instance = \Smackcoders\UCI\Proaddons\UltimatePro\MediaHandling::getInstance();
            } catch (\Throwable $t) {
                $media_instance = null;
            }
        }

        if (!empty($data['featured_image'])) {
            $featured_image_url = trim($data['featured_image']);
            $attachment_id = $media_instance ? $media_instance->image_function($featured_image_url, $pID) : 0;

            if ($attachment_id) {
                set_post_thumbnail($pID, $attachment_id);
                $gallery_ids[] = $attachment_id;
                $uploaded_url = wp_get_attachment_url($attachment_id);
                if ($uploaded_url) {
                    $medias[] = ['url' => $uploaded_url];
                }
            } else {
                $medias[] = ['url' => $featured_image_url];
            }
        }

        if (!empty($data['gallery_images'])) {
            $gallery_images = array_filter(array_map('trim', explode(',', $data['gallery_images'])));
            foreach ($gallery_images as $image_url) {
                $attachment_id = $media_instance ? $media_instance->image_function($image_url, $pID) : 0;
                if ($attachment_id) {
                    $gallery_ids[] = $attachment_id;
                    $url = wp_get_attachment_url($attachment_id);
                } else {
                    $url = $image_url;
                }
                if ($url) {
                    $medias[] = ['url' => $url];
                }
            }
        }

        if (!empty($gallery_ids)) {
            $meta = isset($product_args['metadata']) ? (array)$product_args['metadata'] : [];
            $meta['gallery_ids'] = array_values(array_unique($gallery_ids));
            $product_args['metadata'] = (object)$meta;
        }

        if (!empty($medias)) {
            $product_args['product_medias'] = $medias;
        }
    }

    private function handle_seo(&$product_args, $data, $pID = 0) {
        $meta = isset($product_args['metadata']) ? (array)$product_args['metadata'] : [];

        $seo_title_val = !empty($data['seo_title']) ? $data['seo_title'] : (!empty($data['page_title']) ? $data['page_title'] : '');
        if (!empty($seo_title_val)) {
            $title = sanitize_text_field($seo_title_val);
            $product_args['page_title'] = $title;
            $meta['page_title'] = $title;
            if ($pID) {
                update_post_meta($pID, 'page_title', $title);
                update_post_meta($pID, '_yoast_wpseo_title', $title);
                update_post_meta($pID, '_rank_math_title', $title);
            }
        }

        $seo_desc_val = !empty($data['seo_description']) ? $data['seo_description'] : (!empty($data['meta_description']) ? $data['meta_description'] : '');
        if (!empty($seo_desc_val)) {
            $desc = sanitize_text_field($seo_desc_val);
            $product_args['meta_description'] = $desc;
            $meta['meta_description'] = $desc;
            if ($pID) {
                update_post_meta($pID, 'meta_description', $desc);
                update_post_meta($pID, '_yoast_wpseo_metadesc', $desc);
                update_post_meta($pID, '_rank_math_description', $desc);
            }
        }

        if (!empty($meta)) {
            $product_args['metadata'] = (object) $meta;
        }
    }

    private function handle_shipping_profile($data) {
        if (!empty($data['shipping_profile']) && class_exists('\SureCart\Models\ShippingProfile')) {
            try {
                $profile = \SureCart\Models\ShippingProfile::create([
                    'name' => trim($data['shipping_profile']),
                ]);
                if (!is_wp_error($profile) && isset($profile->id)) {
                    return $profile->id;
                }
            } catch (\Exception $e) {
                // ignore
            }
        }
        return null;
    }

    private function handle_prices($sc_id, $product_model, $data) {
        $price_val = (isset($data['price']) && $data['price'] !== '') ? $data['price'] : null;

        if (!empty($sc_id) && $price_val !== null && $price_val !== '') {
            try {
                $amount = intval(floatval($price_val) * 100);
                $price_api_data = [
                    'product'  => $sc_id,
                    'amount'   => $amount,
                    'currency' => strtolower(function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'usd'),
                ];

                if (isset($data['compare_at_price']) && floatval($data['compare_at_price']) > 0) {
                    $price_api_data['compare_at_amount'] = intval(floatval($data['compare_at_price']) * 100);
                }
                
                if (!empty($data['price_name'])) {
                    $price_api_data['name'] = sanitize_text_field($data['price_name']);
                }

                if (!empty($data['recurring_interval']) && !empty($data['recurring_period'])) {
                    $price_api_data['interval'] = sanitize_text_field($data['recurring_period']);
                    $price_api_data['interval_count'] = intval($data['recurring_interval']);
                } else {
                    $price_api_data['interval'] = 'one_time';
                }

                $existing_prices = [];
                if ($product_model && isset($product_model->prices->data)) {
                    $existing_prices = $product_model->prices->data;
                }

                if (class_exists('\SureCart\Models\Price')) {
                    if (!empty($existing_prices)) {
                        $price_to_update = $existing_prices[0];
                        \SureCart\Models\Price::update($price_to_update->id, $price_api_data);
                    } else {
                        \SureCart\Models\Price::create($price_api_data);
                    }
                }
            } catch (\Throwable $e) {
                // ignore
            }
        }
    }

    private function handle_affiliate_commission(&$metadata_array, $data, $pID) {
        $aff_keys = [
            'custom_affiliate_commission',
            'commission_type',
            'percent_commission',
            'amount_commission',
            'subscription_commission_enabled',
            'subscription_commission_days',
            'lifetime_commission_enabled',
            'lifetime_commission_days'
        ];

        foreach ($aff_keys as $key) {
            if (isset($data[$key]) && $data[$key] !== '') {
                $val = trim($data[$key]);
                $metadata_array[$key] = $val;
                if ($pID) {
                    update_post_meta($pID, $key, $val);
                }
            }
        }
    }

    private function handle_child_variant_row($data, $pID, $line_number) {
        global $wpdb, $core_instance;

        if (empty($data['parent_sku'])) {
            return false;
        }

        $parent_sku = trim($data['parent_sku']);

        // First check the session-tracked parent SKU map (set during current import)
        $parent_post_id = null;
        if (isset(self::$parent_sku_map[$parent_sku])) {
            $parent_post_id = self::$parent_sku_map[$parent_sku];
        }

        // Fallback to database lookup
        if (!$parent_post_id) {
            $parent_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sku' AND meta_value = %s ORDER BY post_id DESC LIMIT 1",
                $parent_sku
            ));
        }

        if (!$parent_post_id) {
            $parent_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'sc_product' AND (post_title = %s OR post_name = %s) AND post_status != 'trash' ORDER BY ID DESC LIMIT 1",
                $parent_sku,
                sanitize_title($parent_sku)
            ));
        }

        if (!$parent_post_id && !empty($data['product_name'])) {
            $p_title = trim($data['product_name']);
            if (strpos($p_title, ':') !== false) {
                list($p_title, $opts) = explode(':', $p_title, 2);
            }
            $parent_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'sc_product' AND post_title = %s AND post_status != 'trash' ORDER BY ID DESC LIMIT 1",
                trim($p_title)
            ));
        }

        $parent_sc_id = $parent_post_id ? get_post_meta($parent_post_id, 'sc_id', true) : '';

        if (!empty($parent_sc_id) || !empty($parent_post_id)) {


            if ($pID && $pID != $parent_post_id) {
                wp_delete_post($pID, true);
            }

            $variant_sku = !empty($data['sku']) ? trim($data['sku']) : '';
            $price_val   = (isset($data['price']) && $data['price'] !== '') ? floatval($data['price']) : null;
            $stock_qty   = (isset($data['stock_quantity']) && $data['stock_quantity'] !== '') ? intval($data['stock_quantity']) : null;
            $weight_val  = !empty($data['weight']) ? floatval($data['weight']) : null;

            if (!empty($parent_sc_id) && class_exists('\SureCart\Models\Variant')) {
                try {
                    $variants = \SureCart\Models\Variant::where(['product_id' => $parent_sc_id])->get();
                    if ($variants && isset($variants->data) && is_array($variants->data)) {
                        $opt_values = [];
                        $title_str = !empty($data['product_name']) ? $data['product_name'] : (!empty($data['post_title']) ? $data['post_title'] : '');
                        if (strpos($title_str, ':') !== false) {
                            list($pname, $opts_str) = explode(':', $title_str, 2);
                            $opt_values = array_map('trim', explode(',', $opts_str));
                        }

                        foreach ($variants->data as $variant) {
                            $match = false;
                            if (!empty($opt_values)) {
                                $v_opts = array_filter(array_map('trim', [
                                    $variant->option_1 ?? '',
                                    $variant->option_2 ?? '',
                                    $variant->option_3 ?? ''
                                ]));
                                if (count(array_intersect($opt_values, $v_opts)) === count($opt_values)) {
                                    $match = true;
                                }
                            }
                            if (!$match && !empty($variant_sku) && isset($variant->sku) && $variant->sku === $variant_sku) {
                                $match = true;
                            }

                            if ($match) {
                                $update_args = [];
                                if (!empty($variant_sku)) $update_args['sku'] = $variant_sku;
                                if ($stock_qty !== null) {
                                    $update_args['stock_enabled'] = true;
                                    $update_args['stock_adjustment'] = $stock_qty;
                                }
                                if ($weight_val !== null) {
                                    $update_args['weight'] = $weight_val;
                                    $update_args['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
                                }
                                if ($price_val !== null) {
                                    $update_args['amount'] = intval($price_val * 100);
                                }
                                \SureCart\Models\Variant::update($variant->id, $update_args);
                                break;
                            }
                        }
                    }
                } catch (\Throwable $e) {
                }
            }

            // Also update local parent post meta for variants
            if ($parent_post_id) {
                $local_variants = get_post_meta($parent_post_id, 'variants', true);
                if (!is_array($local_variants)) {
                    $local_variants = [];
                }
                $opt_values = [];
                $title_str = !empty($data['product_name']) ? $data['product_name'] : (!empty($data['post_title']) ? $data['post_title'] : '');
                if (strpos($title_str, ':') !== false) {
                    list($pname, $opts_str) = explode(':', $title_str, 2);
                    $opt_values = array_map('trim', explode(',', $opts_str));
                }

                $found_idx = null;
                foreach ($local_variants as $idx => $v) {
                    $v_opts = array_filter(array_map('trim', [
                        $v['option_1'] ?? '',
                        $v['option_2'] ?? '',
                        $v['option_3'] ?? ''
                    ]));
                    if (!empty($opt_values) && count(array_intersect($opt_values, $v_opts)) === count($opt_values)) {
                        $found_idx = $idx;
                        break;
                    }
                    if (!empty($variant_sku) && isset($v['sku']) && $v['sku'] === $variant_sku) {
                        $found_idx = $idx;
                        break;
                    }
                }

                if ($found_idx !== null) {
                    if (!empty($variant_sku)) $local_variants[$found_idx]['sku'] = $variant_sku;
                    if ($stock_qty !== null) {
                        $local_variants[$found_idx]['stock_enabled'] = true;
                        $local_variants[$found_idx]['stock_adjustment'] = $stock_qty;
                        $local_variants[$found_idx]['available_stock'] = $stock_qty;
                    }
                    if ($weight_val !== null) {
                        $local_variants[$found_idx]['weight'] = $weight_val;
                        $local_variants[$found_idx]['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
                    }
                    if ($price_val !== null) {
                        $local_variants[$found_idx]['amount'] = intval($price_val * 100);
                    }
                    if (!empty($data['featured_image'])) {
                        $local_variants[$found_idx]['image'] = ['url' => trim($data['featured_image'])];
                    }
                } else {
                    $new_v = [
                        'id' => 'sc_var_' . uniqid(),
                        'sku' => $variant_sku,
                        'product_id' => $parent_sc_id ?: 'sc_prod_' . $parent_post_id,
                    ];
                    if (isset($opt_values[0])) $new_v['option_1'] = $opt_values[0];
                    if (isset($opt_values[1])) $new_v['option_2'] = $opt_values[1];
                    if (isset($opt_values[2])) $new_v['option_3'] = $opt_values[2];
                    if ($stock_qty !== null) {
                        $new_v['stock_enabled'] = true;
                        $new_v['stock_adjustment'] = $stock_qty;
                        $new_v['available_stock'] = $stock_qty;
                    }
                    if ($weight_val !== null) {
                        $new_v['weight'] = $weight_val;
                        $new_v['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
                    }
                    if ($price_val !== null) {
                        $new_v['amount'] = intval($price_val * 100);
                    }
                    if (!empty($data['featured_image'])) {
                        $new_v['image'] = ['url' => trim($data['featured_image'])];
                    }
                    $local_variants[] = $new_v;
                }

                update_post_meta($parent_post_id, 'variants', $local_variants);

                $parent_product_meta = get_post_meta($parent_post_id, 'product', true);
                if (!is_array($parent_product_meta)) {
                    $parent_product_meta = [];
                }
                $parent_product_meta['variants'] = ['data' => $local_variants];
                update_post_meta($parent_post_id, 'product', $parent_product_meta);

                if (class_exists('\SureCart') && !empty($parent_sc_id) && class_exists('\SureCart\Models\Product')) {
                    try {
                        $parent_sync_model = \SureCart\Models\Product::with(['variants', 'variant_options', 'prices'])->find($parent_sc_id);
                        if ($parent_sync_model && !is_wp_error($parent_sync_model)) {
                            \SureCart::sync()->product()->sync($parent_sync_model);
                        }
                    } catch (\Throwable $t) {}
                }
            }

            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number]['Message'] = 'Updated SureCart Variant SKU: ' . $variant_sku;
                $core_instance->detailed_log[$line_number]['state']   = 'Updated';
            }
            return true;
        } else {
        }

        return false;
    }

    private function import_product($data, $pID, $hash_key, $line_number, $gmode)
    {
        global $wpdb, $core_instance;

        // Check if this row is a child variant row with parent_sku
        if (!empty($data['parent_sku'])) {
            if ($this->handle_child_variant_row($data, $pID, $line_number)) {
                return;
            }
        }

        if (empty($pID)) {
            $post_title = !empty($data['post_title']) ? sanitize_text_field($data['post_title']) : (!empty($data['product_name']) ? sanitize_text_field($data['product_name']) : 'SureCart Product');
            $post_content = !empty($data['post_content']) ? wp_kses_post($data['post_content']) : (!empty($data['description']) ? wp_kses_post($data['description']) : '');
            $post_excerpt = !empty($data['post_excerpt']) ? wp_kses_post($data['post_excerpt']) : (!empty($data['short_description']) ? wp_kses_post($data['short_description']) : '');
            $post_status = !empty($data['post_status']) ? sanitize_text_field($data['post_status']) : 'publish';

            $pID = wp_insert_post([
                'post_title'   => $post_title,
                'post_content' => $post_content,
                'post_excerpt' => $post_excerpt,
                'post_status'  => $post_status,
                'post_type'    => 'sc_product'
            ]);

            if (is_wp_error($pID) || empty($pID)) {
                return;
            }
        }

        $sc_id = get_post_meta($pID, 'sc_id', true);

        // Handle Insert/Update Mode Check
        if ($gmode === 'Insert' && !empty($sc_id)) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Product name already exists, skipped for import mode.',
                    'state' => 'Skipped'
                ];
            }
            // Delete the WP Post and meta that was just created by the importer
            wp_delete_post($pID, true);
            return; // Skip import if mode is insert and it exists
        }
        // If mode is Update but $sc_id is empty, we will proceed to create it (Upsert)

        // Build product args for SureCart API via SDK
        $is_physical = (empty($data['product_type']) || strtolower(trim($data['product_type'])) === 'physical');

        $post_content = !empty($data['post_content']) ? wp_kses_post($data['post_content']) : '';
        $short_desc   = !empty($data['short_description']) ? wp_kses_post($data['short_description']) : (!empty($data['post_excerpt']) ? wp_kses_post($data['post_excerpt']) : '');

        // SureCart API uses 'description' as the main product description
        $surecart_description = !empty($post_content) ? $post_content : $short_desc;

        $product_args = [
            'name'                 => !empty($data['post_title']) ? sanitize_text_field($data['post_title']) : get_the_title($pID),
            'description'          => $surecart_description,
            'type'                 => 'simple', // Defaults to simple, will be upgraded to variable if variants exist
            'shipping_enabled'     => $is_physical,
            'auto_fulfill_enabled' => !$is_physical,
        ];

        // Product Weight
        $prod_weight = !empty($data['weight']) ? floatval($data['weight']) : 0;
        if ($prod_weight > 0) {
            $product_args['weight']      = $prod_weight;
            $product_args['weight_unit'] = !empty($data['weight_unit']) ? sanitize_text_field($data['weight_unit']) : 'lb';
        }

        // Product Dimensions
        $prod_l = !empty($data['length']) ? floatval($data['length']) : 0;
        $prod_w = !empty($data['width']) ? floatval($data['width']) : 0;
        $prod_h = !empty($data['height']) ? floatval($data['height']) : 0;
        if ($prod_l > 0 || $prod_w > 0 || $prod_h > 0) {
            $dim_unit = 'in';
            if (!empty($data['dimension_unit'])) {
                $dim_unit = sanitize_text_field($data['dimension_unit']);
            } elseif (!empty($data['weight_unit'])) {
                $wu = strtolower(trim($data['weight_unit']));
                if (in_array($wu, ['in', 'cm', 'mm', 'm', 'ft'])) {
                    $dim_unit = $wu;
                }
            }
            $product_args['dimensions'] = [
                'length' => $prod_l,
                'width'  => $prod_w,
                'height' => $prod_h,
                'unit'   => $dim_unit,
            ];
        }
        
        $metadata_array = [];
        if (isset($data['license']) && $data['license'] !== '') {
            $product_args['license'] = trim($data['license']);
            $metadata_array['license'] = trim($data['license']);
        }
        if (isset($data['license_count']) && $data['license_count'] !== '') {
            $product_args['license_count'] = intval(trim($data['license_count']));
            $metadata_array['license_count'] = intval(trim($data['license_count']));
        }
        if (!empty($data['purchase_link_url'])) {
            $metadata_array['purchase_link_url'] = trim($data['purchase_link_url']);
            $metadata_array['buy_button_url'] = trim($data['purchase_link_url']);
            if ($pID) {
                update_post_meta($pID, 'purchase_link_url', trim($data['purchase_link_url']));
            }
        }
        if (!empty($data['purchase_link_text'])) {
            $metadata_array['purchase_link_text'] = trim($data['purchase_link_text']);
            if ($pID) {
                update_post_meta($pID, 'purchase_link_text', trim($data['purchase_link_text']));
            }
        }
        
        $this->handle_affiliate_commission($metadata_array, $data, $pID);

        if (!empty($metadata_array)) {
            $product_args['metadata'] = $metadata_array;
        }

        // Status Mapping
        $raw_status = !empty($data['post_status']) ? strtolower(trim($data['post_status'])) : 'publish';
        if (in_array($raw_status, ['publish', 'published', 'active'])) {
            $product_args['status'] = 'published';
            $wp_target_status = 'publish';
        } elseif ($raw_status === 'draft') {
            $product_args['status'] = 'draft';
            $wp_target_status = 'draft';
        } elseif (in_array($raw_status, ['trash', 'archived'])) {
            $product_args['status'] = 'archived';
            $wp_target_status = 'sc_archived';
        } else {
            $product_args['status'] = 'published';
            $wp_target_status = 'publish';
        }

        // SKU
        if (!empty($data['sku'])) {
            $product_args['sku'] = sanitize_text_field($data['sku']);
        }

        // Apply modular handlers
        $this->handle_inventory($product_args, $data);
        $this->handle_tax($product_args, $data);
        $this->handle_collections($product_args, $data);
        $this->handle_categories_and_tags($data, $pID);
        $this->handle_media($product_args, $data, $pID, $hash_key, $line_number);
        $this->handle_seo($product_args, $data, $pID);

        // For variable products, build variants + per-variant prices inline in the payload
        $is_variable = !empty($data['variant_options']) || (!empty($data['product_is_varient']) && in_array(strtolower(trim($data['product_is_varient'])), ['1', 'yes', 'true', 'variant']));
        $inline = ['variants' => [], 'prices' => []];
        $variant_defs = [];

        if ($is_variable && !empty($data['variant_options'])) {
            $inline = $this->build_inline_variants_and_prices($data, $pID);
            $variant_defs = $this->parse_variant_option_defs($data['variant_options']);
            if (!empty($inline['variants'])) {
                $product_args['variants']        = $inline['variants'];
                $product_args['variant_options'] = $variant_defs;
                $product_args['type']             = 'variable';
                $product_args['stock_enabled']    = true;

                update_post_meta($pID, 'variants', $inline['variants']);
                update_post_meta($pID, 'variant_options', $variant_defs);
            }
            if (!empty($inline['prices'])) {
                $product_args['prices'] = $inline['prices'];
            }
        }

        $shipping_id = $this->handle_shipping_profile($data);
        $product_model = null;

        if (class_exists('\SureCart\Models\Product')) {
            try {
                if (!empty($sc_id)) {
                    // Update existing
                    $product_model = \SureCart\Models\Product::update($sc_id, $product_args);
                } else {
                    // Create new
                    $product_model = \SureCart\Models\Product::create($product_args);
                    if (is_wp_error($product_model)) {
                    } elseif (isset($product_model->id)) {
                        $sc_id = $product_model->id;
                    }
                }

                // Create inline SDK Variants for permutations if variable product
                if ($is_variable && !empty($variant_defs) && !empty($sc_id) && class_exists('\SureCart\Models\Variant')) {
                    $permutations = $this->get_variant_permutations($variant_defs);
                    $fresh_model  = \SureCart\Models\Product::with(['variants'])->find($sc_id);
                    $existing_v   = $fresh_model->variants->data ?? [];

                    foreach ($permutations as $idx => $permutation) {
                        $opt1 = $permutation[0] ?? null;
                        $opt2 = $permutation[1] ?? null;
                        $opt3 = $permutation[2] ?? null;

                        $found_v = false;
                        foreach ($existing_v as $ev) {
                            if (($opt1 === null || ($ev->option_1 ?? '') === $opt1) &&
                                ($opt2 === null || ($ev->option_2 ?? '') === $opt2) &&
                                ($opt3 === null || ($ev->option_3 ?? '') === $opt3)) {
                                $found_v = true;
                                break;
                            }
                        }

                        if (!$found_v) {
                            $v_args = [
                                'product'  => $sc_id,
                                'position' => $idx,
                            ];
                            if ($opt1) $v_args['option_1'] = $opt1;
                            if ($opt2) $v_args['option_2'] = $opt2;
                            if ($opt3) $v_args['option_3'] = $opt3;
                            if (!empty($data['sku'])) $v_args['sku'] = sanitize_text_field($data['sku']);
                            if (!empty($data['price'])) $v_args['amount'] = intval(floatval($data['price']) * 100);

                            $new_sdk_v = \SureCart\Models\Variant::create($v_args);
                        }
                    }
                }

                // If we created a shipping profile, link it
                if ($shipping_id && $product_model && !is_wp_error($product_model) && isset($product_model->id)) {
                    $product_model = \SureCart\Models\Product::update($product_model->id, [
                        'shipping_profile_id' => $shipping_id
                    ]);
                }

                // Trigger SureCart product sync to local WP Post
                if (class_exists('\SureCart') && !empty($sc_id)) {
                    $sync_model = \SureCart\Models\Product::with(['variants', 'variant_options', 'prices'])->find($sc_id);
                    if ($sync_model && !is_wp_error($sync_model)) {
                        \SureCart::sync()->product()->sync($sync_model);

                        // Find the post that SureCart sync created/updated (it uses sc_id meta)
                        $synced_post_id = $wpdb->get_var($wpdb->prepare(
                            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s ORDER BY post_id DESC LIMIT 1",
                            $sc_id
                        ));

                        if ($synced_post_id && (int)$synced_post_id !== (int)$pID) {
                            // Sync created a different post; delete the manually-created duplicate
                            wp_delete_post($pID, true);
                            $pID = (int)$synced_post_id;
                        }
                    }
                }
            } catch (\Throwable $e) {
            }
        }

        if (empty($sc_id)) {
            $sc_id = 'sc_prod_' . $pID;
        }

        // Always save sc_id and meta on the WP sc_product post
        update_post_meta($pID, 'sc_id', $sc_id);
        if (!empty($data['sku'])) {
            $sku_val = sanitize_text_field($data['sku']);
            update_post_meta($pID, 'sku', $sku_val);
            // Track this parent SKU -> post ID for child variant rows in the same import session
            self::$parent_sku_map[$sku_val] = $pID;
        }
        if (isset($product_args['stock_enabled'])) {
            update_post_meta($pID, 'stock_enabled', !empty($product_args['stock_enabled']) ? 1 : 0);
        }
        if (isset($product_args['stock_adjustment'])) {
            update_post_meta($pID, 'available_stock', intval($product_args['stock_adjustment']));
        }
        if (!empty($data['price'])) {
            $price_cents = intval(floatval($data['price']) * 100);
            update_post_meta($pID, 'min_price_amount', $price_cents);
            update_post_meta($pID, 'max_price_amount', $price_cents);
        }

        // Always update product meta array for SureCart frontend & sync
        $product_meta_val = get_post_meta($pID, 'product', true);
        if (!is_array($product_meta_val)) {
            $product_meta_val = [];
        }
        $product_meta_val['id']   = $sc_id;
        $product_meta_val['name'] = !empty($data['product_name']) ? $data['product_name'] : (!empty($data['post_title']) ? $data['post_title'] : '');
        $product_meta_val['sku']  = !empty($data['sku']) ? $data['sku'] : '';
        if ($is_variable) {
            $product_meta_val['type'] = 'variable';
            if (!empty($inline['variants'])) {
                $product_meta_val['variants'] = ['data' => $inline['variants']];
            }
            if (!empty($variant_defs)) {
                $product_meta_val['variant_options'] = ['data' => $variant_defs];
            }
        }
        update_post_meta($pID, 'product', $product_meta_val);

        if ($is_variable && !empty($variant_defs) && class_exists('\SureCart\Models\VariantOptionValue')) {
            try {
                \SureCart\Models\VariantOptionValue::where('product_id', $sc_id)->delete();
                foreach ($variant_defs as $opt) {
                    if (!empty($opt['values']) && is_array($opt['values'])) {
                        foreach ($opt['values'] as $val) {
                            \SureCart\Models\VariantOptionValue::create([
                                'name'       => $opt['name'],
                                'value'      => $val,
                                'post_id'    => $pID,
                                'product_id' => $sc_id,
                            ]);
                        }
                    }
                }
            } catch (\Throwable $t) {}
        }

        // Handle details (stock, sku, weight, dimensions, images, prices, downloads per variant)
        if (!empty($sc_id)) {
            $this->handle_variant_details($sc_id, $data, $pID);
            $this->handle_prices($sc_id, $product_model, $data);
        }
        
        // Handle normal product downloads
        if (!empty($sc_id) && isset($data['download_files']) && $data['download_files'] !== '') {
            if (!$product_model || empty($product_model->variants->data)) {
                $download_links = array_filter(array_map('trim', explode('|', $data['download_files'])));
                foreach ($download_links as $link) {
                    $dl_name = basename($link);
                    if (class_exists('\SureCart\Models\Download')) {
                        try {
                            \SureCart\Models\Download::create([
                                'product' => $sc_id,
                                'name' => $dl_name ? $dl_name : 'Download File',
                                'url' => $link
                            ]);
                        } catch (\Exception $e) {
                            // ignore
                        }
                    }
                }
            }
        }

        // Ensure WordPress post object has post_title, post_content, post_excerpt, post_status, post_type = sc_product
        $post_title_val = !empty($data['post_title']) ? sanitize_text_field($data['post_title']) : (!empty($data['product_name']) ? sanitize_text_field($data['product_name']) : get_the_title($pID));
        
        $wp_post_update = [
            'ID'           => $pID,
            'post_title'   => $post_title_val,
            'post_content' => $post_content,
            'post_excerpt' => $short_desc,
            'post_status'  => $wp_target_status,
            'post_type'    => 'sc_product'
        ];
        if (function_exists('wp_update_post')) {
            wp_update_post($wp_post_update);
        } else {
            $wpdb->update($wpdb->posts, ['post_title' => $post_title_val, 'post_content' => $post_content, 'post_excerpt' => $short_desc, 'post_status' => $wp_target_status, 'post_type' => 'sc_product'], ['ID' => $pID]);
        }

        // Sync via SureCart PostSyncService if available
        if ($product_model && !is_wp_error($product_model)) {
            if (class_exists('\SureCart\Sync\PostSyncService')) {
                try {
                    \SureCart\Sync\PostSyncService::sync($product_model);
                } catch (\Throwable $t) {
                    // ignore
                }
            } elseif (class_exists('\SureCart') && method_exists('\SureCart', 'sync')) {
                try {
                    \SureCart::sync()->product()->sync($product_model);
                } catch (\Throwable $t) {
                    // ignore
                }
            }
        }

        clean_post_cache($pID);

        if (isset($core_instance)) {
            $mode_title = ($gmode === 'Update') ? 'Updated' : 'Inserted';
            $core_instance->detailed_log[$line_number]['Message'] = $mode_title . ' SureCart Product ID: ' . $pID;
            $core_instance->detailed_log[$line_number]['status']  = $wp_target_status;
            $core_instance->detailed_log[$line_number]['id']      = $pID;
            $core_instance->detailed_log[$line_number]['webLink'] = function_exists('get_permalink') ? get_permalink($pID) : '';
            $core_instance->detailed_log[$line_number]['adminLink'] = function_exists('get_edit_post_link') ? get_edit_post_link($pID, true) : '';
            $core_instance->detailed_log[$line_number]['state']   = $mode_title;
        }
    }

    /**
     * Import SureCart Products
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param int $post_id Post ID
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_products(
        $header_array,
        $value_array,
        $map,
        $post_id,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        $this->set_surecart_values(
            $header_array,
            $value_array,
            $map,
            $post_id,
            'SURECART_PRODUCTS',
            $hash_key,
            $gmode,
            $templatekey,
            $line_number
        );
    }

    public function import_orders(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb, $core_instance;
        if (!is_plugin_active('surecart/surecart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values
        $order_data = $helpers_instance->get_header_values($map, $header_array, $value_array);
        $order_data = $this->normalize_order_map_keys($order_data);
        // Extract order fields
        $customer_email = isset($order_data['customer_email']) ? sanitize_email($order_data['customer_email']) : '';
        $customer_uuid = isset($order_data['customer_id']) ? sanitize_text_field($order_data['customer_id']) : '';

        if (empty($customer_email) && empty($customer_uuid)) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Skipped: Customer email or ID is required for SureCart orders',
                    'state' => 'Skipped'
                ];
            }
            return;
        }
        $order_status = isset($order_data['order_status']) ? sanitize_text_field($order_data['order_status']) : 'pending';
        $order_date = isset($order_data['order_date']) ? $order_data['order_date'] : current_time('mysql');

        // Ensure date is in MySQL format if it's a numeric timestamp
        if (is_numeric($order_date)) {
            $order_date = date('Y-m-d H:i:s', intval($order_date));
        }

        $order_number = isset($order_data['order_number']) ? sanitize_text_field($order_data['order_number']) : '';

        // Get or create customer
        $customer_post_id = 0;
        $sc_customer_id = '';

        if (!empty($customer_email)) {
            $customer_post_id = $this->get_or_create_surecart_customer($customer_email, $order_data);
            if ($customer_post_id) {
                $sc_customer_id = get_post_meta($customer_post_id, 'sc_id', true);
            }
        }
        // Fallback to customer_uuid if we still don't have a SureCart Cloud ID
        if (empty($sc_customer_id) && !empty($customer_uuid)) {
            $sc_customer_id = $customer_uuid;
            // Try to find local post ID for meta linking
            global $wpdb;
            $customer_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = 'sc_id' AND meta_value = %s LIMIT 1",
                $sc_customer_id
            ));
        }
        if (empty($sc_customer_id)) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Failed: Could not find/create SureCart customer',
                    'state' => 'Failed'
                ];
            }
            return;
        }

        // Prepare checkout data for SureCart Model
        // Prepare checkout data for SureCart Model
        // Prepare checkout data for SureCart Model
        $checkout_api_data = [
            'customer' => $sc_customer_id,
            'line_items' => [],
            'metadata' => ['imported_order_number' => $order_number]
        ];

        // Build shipping address from composite (JSON/serialized) or individual CSV fields
        $shipping_addr = [];
        if (!empty($order_data['shipping_address'])) {
            $shipping_addr = maybe_unserialize($order_data['shipping_address']);
            if (!is_array($shipping_addr)) {
                $shipping_addr = json_decode($order_data['shipping_address'], true) ?: [];
            }
        }
        if (empty($shipping_addr) && (!empty($order_data['shipping_address_line_1']) || !empty($order_data['shipping_city']))) {
            $shipping_addr = [
                'first_name' => $order_data['shipping_first_name'] ?? '',
                'last_name' => $order_data['shipping_last_name'] ?? '',
                'address_1' => $order_data['shipping_address_line_1'] ?? '',
                'address_2' => $order_data['shipping_address_line_2'] ?? '',
                'street' => $order_data['shipping_address_line_1'] ?? '',
                'city' => $order_data['shipping_city'] ?? '',
                'state' => $order_data['shipping_state'] ?? '',
                'postal_code' => $order_data['shipping_postal_code'] ?? '',
                'postcode' => $order_data['shipping_postal_code'] ?? '',
                'country' => $order_data['shipping_country'] ?? '',
            ];
        }

        // Fallback: If CSV address is empty, fetch from SureCart Customer
        if (empty($shipping_addr) || !is_array($shipping_addr)) {
            if (class_exists('\\SureCart\\Models\\Customer')) {
                $sc_customer = \SureCart\Models\Customer::find($sc_customer_id);
                if ($sc_customer && !is_wp_error($sc_customer)) {
                    // Check if customer has shipping address
                    if (!empty($sc_customer->shipping_address)) {
                        $shipping_addr = (array) $sc_customer->shipping_address;
                    }
                }
            }
        }

        if (is_array($shipping_addr) && !empty($shipping_addr)) {
            $ship_name = trim(($shipping_addr['first_name'] ?? '') . ' ' . ($shipping_addr['last_name'] ?? ''));
            if (empty($ship_name)) {
                $ship_name = $shipping_addr['name'] ?? 'Imported Customer';
            }
            $checkout_api_data['shipping_address'] = [
                'name' => $ship_name,
                'street' => $shipping_addr['address_1'] ?? ($shipping_addr['street'] ?? ''),
                'city' => $shipping_addr['city'] ?? '',
                'state' => $shipping_addr['state'] ?? '',
                'country' => $shipping_addr['country'] ?? '',
                'postal_code' => $shipping_addr['postcode'] ?? ($shipping_addr['postal_code'] ?? '')
            ];

            // Also use as billing if billing is missing
            if (empty($checkout_api_data['billing_address'])) {
                $checkout_api_data['billing_address'] = $checkout_api_data['shipping_address'];
            }
        } else {
            // LAST RESORT: Data is missing. Use valid US address format (required for manually_pay accuracy).
            if (defined('WP_DEBUG') && WP_DEBUG) {
            }
            $placeholder_address = [
                'name' => 'Imported Order',
                'street' => '123 Main Street',
                'city' => 'New York',
                'state' => 'NY',
                'country' => 'US',
                'postal_code' => '10001'
            ];
            $checkout_api_data['shipping_address'] = $placeholder_address;
            $checkout_api_data['billing_address'] = $placeholder_address;
        }

        // Build billing address from composite (JSON/serialized) or individual CSV fields
        $billing_addr = [];
        if (!empty($order_data['billing_address'])) {
            $billing_addr = maybe_unserialize($order_data['billing_address']);
            if (!is_array($billing_addr)) {
                $billing_addr = json_decode($order_data['billing_address'], true) ?: [];
            }
        }
        if (empty($billing_addr) && (!empty($order_data['billing_address_line_1']) || !empty($order_data['billing_city']))) {
            $billing_addr = [
                'first_name' => $order_data['billing_first_name'] ?? '',
                'last_name' => $order_data['billing_last_name'] ?? '',
                'address_1' => $order_data['billing_address_line_1'] ?? '',
                'address_2' => $order_data['billing_address_line_2'] ?? '',
                'street' => $order_data['billing_address_line_1'] ?? '',
                'city' => $order_data['billing_city'] ?? '',
                'state' => $order_data['billing_state'] ?? '',
                'postal_code' => $order_data['billing_postal_code'] ?? '',
                'postcode' => $order_data['billing_postal_code'] ?? '',
                'country' => $order_data['billing_country'] ?? '',
            ];
        }
        if (is_array($billing_addr) && !empty(array_filter($billing_addr))) {
            $checkout_api_data['billing_address'] = [
                'name' => trim(($billing_addr['first_name'] ?? '') . ' ' . ($billing_addr['last_name'] ?? '')) ?: ($billing_addr['name'] ?? 'Imported Customer'),
                'street' => $billing_addr['address_1'] ?? ($billing_addr['street'] ?? ''),
                'city' => $billing_addr['city'] ?? '',
                'state' => $billing_addr['state'] ?? '',
                'country' => $billing_addr['country'] ?? 'US',
                'postal_code' => $billing_addr['postcode'] ?? ($billing_addr['postal_code'] ?? '')
            ];
        }

        // Handle line items for Model
        $resolved_currency = '';
        if (!empty($order_data['line_items'])) {
            $items = maybe_unserialize($order_data['line_items']);
            if (!is_array($items)) {
                $items = json_decode($order_data['line_items'], true);
            }
            $json_err = json_last_error();

            if (is_array($items)) {
                foreach ($items as $item) {
                    $price_id = $item['price'] ?? ($item['price_id'] ?? '');
                    $sku = $item['sku'] ?? '';

                    // If price looks like a placeholder and we have no SKU, try using price as SKU
                    if ((empty($price_id) || strpos($price_id, 'price_') === 0) && empty($sku)) {
                        $sku = $price_id;
                    }

                    // If price looks like a placeholder or is empty, try to resolve via SKU
                    if ((empty($price_id) || strpos($price_id, 'price_') === 0) && !empty($sku)) {
                        // Pass reference to capture currency
                        $resolution = $this->get_price_id_and_currency_by_sku($sku);
                        if ($resolution) {
                            $price_id = $resolution['price_id'];
                            if (empty($resolved_currency)) {
                                $resolved_currency = $resolution['currency'];
                            }
                        } else {
                        }
                    }

                    if (!empty($price_id)) {
                        $checkout_api_data['line_items'][] = [
                            'price' => $price_id,
                            'quantity' => $item['quantity'] ?? 1,
                        ];
                    } else {
                    }
                }
            }
        }

        // Fallback: When no line items, use first available store price so order appears in SureCart UI (API-only)
        if (empty($checkout_api_data['line_items'])) {
            $fallback = $this->get_first_available_price_for_import();
            if ($fallback) {
                $order_total = isset($order_data['total']) ? floatval($order_data['total']) : 0;
                $quantity = 1;
                if ($order_total > 0 && !empty($fallback['amount'])) {
                    $price_amount = floatval($fallback['amount']) / 100;
                    if ($price_amount > 0) {
                        $quantity = max(1, (int) round($order_total / $price_amount));
                    }
                }
                $checkout_api_data['line_items'][] = [
                    'price' => $fallback['price_id'],
                    'quantity' => $quantity,
                ];
                if (!empty($fallback['currency'])) {
                    $resolved_currency = $fallback['currency'];
                }
            } else {
            }
        }

        // Set currency: mapped > resolved > default (usd for most SureCart stores)
        // Validate: currency must be 2-3 letter ISO code (usd, eur, gbp), not numeric (e.g. 10075 = total mistaken as currency)
        $raw_currency = isset($order_data['currency']) ? trim((string) $order_data['currency']) : '';
        if (!empty($raw_currency) && preg_match('/^[a-zA-Z]{2,3}$/', $raw_currency) && !is_numeric($raw_currency)) {
            $checkout_api_data['currency'] = strtolower($raw_currency);
        } elseif (!empty($resolved_currency)) {
            $checkout_api_data['currency'] = strtolower($resolved_currency);
        } else {
            $checkout_api_data['currency'] = 'usd';
        }


        $sc_order_id = null;
        $paid_checkout = null;
        try {
            if (!empty($sc_customer_id) && !empty($checkout_api_data['line_items'])) {
                // 1. Create Checkout (checkouts endpoint - works; draft-checkouts fails with generic error)
                $sc_checkout = \SureCart\Models\Checkout::create($checkout_api_data);

                if (is_wp_error($sc_checkout)) {
                } elseif (!empty($sc_checkout->id)) {

                    // 2. Manually pay via API (Checkout::manuallyPay is protected)
                    $checkout_attrs = json_decode(wp_json_encode($sc_checkout), true);
                    $paid_response = \SureCart::request("checkouts/{$sc_checkout->id}/manually_pay/", [
                        'method' => 'PATCH',
                        'query' => ['expand' => ['order']],
                        'body' => ['checkout' => $checkout_attrs],
                    ]);

                    if (is_wp_error($paid_response)) {
                    } else {
                        $paid_checkout = is_object($paid_response) ? $paid_response : (object) $paid_response;
                        $sc_order_id = $this->extract_order_id_from_manually_pay_response($paid_checkout, $sc_checkout->id);
                    }
                } else {
                }
            } else {
            }
        } catch (\Exception $e) {
        }

        // Create order post
        $order_post = [
            'post_type' => 'sc_order',
            'post_status' => 'publish',
            'post_date' => $order_date,
            'post_title' => !empty($order_number) ? $order_number : 'Order ' . current_time('Y-m-d H:i:s')
        ];

        $order_id = wp_insert_post($order_post);

        if (is_wp_error($order_id) || !$order_id) {
            $error_msg = is_wp_error($order_id) ? $order_id->get_error_message() : 'wp_insert_post returned 0 (invalid post type?)';
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Failed: Could not create order post. ' . $error_msg,
                    'state' => 'Failed'
                ];
            }
            return;
        }
        // Link to cloud order if created
        if ($sc_order_id) {
            update_post_meta($order_id, 'sc_id', $sc_order_id);
        } else {
            // If API failed, we still have the local post, but it won't be synced.
            // Consider adding a meta flag if needed, e.g., update_post_meta($order_id, 'sc_import_sync_failed', 1);
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
        }

        // Store IDs
        update_post_meta($order_id, 'sc_customer_id', $customer_post_id);

        // If we have the order object from payment, use it for details
        if (!empty($paid_checkout) && isset($paid_checkout->order)) {
            $order_obj = $paid_checkout->order;
            $sc_order_number = is_object($order_obj) ? ($order_obj->number ?? $order_number) : $order_number;
            update_post_meta($order_id, 'sc_number', $sc_order_number);
        }

        // Update other meta for compatibility
        $meta_fields = [
            'order_number' => 'sc_order_number',
            'customer_email' => 'sc_customer_email',
            'order_status' => 'sc_order_status',
            'total' => 'sc_total',
            'subtotal' => 'sc_subtotal',
            'tax_amount' => 'sc_tax_amount',
            'discount_amount' => 'sc_discount_amount',
            'shipping_amount' => 'sc_shipping_amount',
            'payment_method' => 'sc_payment_method',
            'payment_status' => 'sc_payment_status',
            'transaction_id' => 'sc_transaction_id',
            'subscription_id' => 'sc_subscription_id',
            'coupon_code' => 'sc_coupon_code'
        ];

        foreach ($meta_fields as $key => $meta_key) {
            if (isset($order_data[$key])) {
                update_post_meta($order_id, $meta_key, sanitize_text_field($order_data[$key]));
            }
        }

        // Addresses and other processing...
        foreach (['billing', 'shipping'] as $type) {
            foreach (['first_name', 'last_name', 'address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'country'] as $field) {
                $data_key = $type . '_' . $field;
                if (!empty($order_data[$data_key])) {
                    update_post_meta($order_id, 'sc_' . $data_key, sanitize_text_field($order_data[$data_key]));
                }
            }
        }

        // Update import log with detailed information
        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        if (!is_numeric($update_count)) {
            $update_count = 0;
        }
        $wpdb->query($wpdb->prepare(
            "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
            (int) $update_count,
            (string) $hash_key
        ));
        // Update detailed log for UI feedback
        if (isset($core_instance)) {
            $core_instance->detailed_log[$line_number] = [
                'Message' => 'Created SureCart Order ID: ' . $order_id . ' for customer: ' . $customer_email,
                'state' => 'Created',
                'id' => $order_id,
                'status' => 'publish',
                'adminLink' => get_edit_post_link($order_id, true)
            ];
        }

    }

    /**
     * Import SureCart Customers
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_customers(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb, $core_instance;

        if (!is_plugin_active('surecart/surecart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values (pass hash_key for proper column resolution)
        $customer_data = $helpers_instance->get_header_values($map, $header_array, $value_array, $hash_key);

        // Normalize: map may use 'customer_email' or 'Customer Email' as key
        $customer_data = $this->normalize_customer_map_keys($customer_data);

        $customer_email = isset($customer_data['customer_email']) ? sanitize_email($customer_data['customer_email']) : '';
        if (empty($customer_email)) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Skipped: Customer email is required',
                    'state' => 'Skipped'
                ];
            }
            return;
        }

        // Use our helper to get or create SureCart customer (Model-based)
        $customer_post_id = $this->get_or_create_surecart_customer($customer_email, $customer_data);

        if (!$customer_post_id) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Failed: Could not create customer',
                    'state' => 'Failed'
                ];
            }
            return;
        }

        // Update additional customer meta for CSV importer compatibility
        $meta_fields = [
            'first_name' => 'sc_first_name',
            'last_name' => 'sc_last_name',
            'phone_number' => 'sc_phone_number',
            'purchase_count' => 'sc_purchase_count',
            'lifetime_value' => 'sc_lifetime_value',
            'notes' => 'sc_notes'
        ];

        foreach ($meta_fields as $key => $meta_key) {
            if (isset($customer_data[$key])) {
                update_post_meta($customer_post_id, $meta_key, sanitize_text_field($customer_data[$key]));
            }
        }

        // Handle addresses
        foreach (['billing'] as $type) {
            foreach (['address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'country'] as $field) {
                $data_key = $type . '_' . $field;
                if (!empty($customer_data[$data_key])) {
                    update_post_meta($customer_post_id, 'sc_' . $data_key, sanitize_text_field($customer_data[$data_key]));
                }
            }
        }

        // Update import log
        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        $wpdb->query($wpdb->prepare(
            "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
            $update_count,
            $hash_key
        ));

        // Update detailed log for UI feedback
        if (isset($core_instance)) {
            $core_instance->detailed_log[$line_number] = [
                'Message' => 'Created SureCart Customer ID: ' . $customer_post_id . ' (' . $customer_email . ')',
                'state' => 'Created',
                'id' => $customer_post_id,
                'status' => 'publish',
                'adminLink' => get_edit_post_link($customer_post_id, true)
            ];
        }

    }

    /**
     * Import SureCart Subscriptions
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_subscriptions(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb;

        if (!is_plugin_active('surecart/surecart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values
        $subscription_data = $helpers_instance->get_header_values($map, $header_array, $value_array);

        $customer_email = isset($subscription_data['customer_email']) ? sanitize_email($subscription_data['customer_email']) : '';
        if (empty($customer_email)) {
            return;
        }

        // Get or create customer
        $customer_post_id = $this->get_or_create_surecart_customer($customer_email, $subscription_data);
        $sc_customer_id = get_post_meta($customer_post_id, 'sc_id', true);

        // Prepare data for SureCart Model
        $subscription_api_data = [
            'customer' => $sc_customer_id,
        ];

        // Link product if provided
        if (!empty($subscription_data['product_id'])) {
            // In SureCart, subscriptions are often linked via line items or plans, 
            // but for basic creation, we might just need the customer and status.
            $subscription_api_data['status'] = isset($subscription_data['subscription_status']) ? $subscription_data['subscription_status'] : 'active';
        }

        $sc_subscription = null;
        try {
            if (!empty($sc_customer_id)) {
                $sc_subscription = Subscription::create($subscription_api_data);
            }
        } catch (\Exception $e) {
        }

        $start_date = isset($subscription_data['start_date']) ? $subscription_data['start_date'] : current_time('mysql');
        if (is_numeric($start_date)) {
            $start_date = date('Y-m-d H:i:s', intval($start_date));
        }

        // Create subscription post
        $subscription_post = [
            'post_type' => 'sc_subscription',
            'post_status' => 'publish',
            'post_date' => $start_date,
            'post_title' => 'Subscription - ' . $customer_email
        ];

        $subscription_id = wp_insert_post($subscription_post);

        if (is_wp_error($subscription_id) || !$subscription_id) {
            return;
        }

        // Store IDs
        update_post_meta($subscription_id, 'sc_customer_id', $customer_post_id);
        if (!is_wp_error($sc_subscription) && isset($sc_subscription->id)) {
            update_post_meta($subscription_id, 'sc_id', $sc_subscription->id);
        }

        // Update other meta for compatibility
        $meta_fields = [
            'customer_email' => 'sc_customer_email',
            'product_id' => 'sc_product_id',
            'order_id' => 'sc_order_id',
            'subscription_status' => 'sc_subscription_status',
            'interval' => 'sc_interval',
            'period' => 'sc_period',
            'price' => 'sc_price',
            'start_date' => 'sc_start_date',
            'end_date' => 'sc_end_date',
            'next_payment_date' => 'sc_next_payment_date',
            'trial_end_date' => 'sc_trial_end_date',
            'cancel_date' => 'sc_cancel_date',
            'cancel_reason' => 'sc_cancel_reason',
            'billing_cycle_count' => 'sc_billing_cycle_count',
            'total_payments' => 'sc_total_payments'
        ];

        foreach ($meta_fields as $key => $meta_key) {
            if (isset($subscription_data[$key])) {
                update_post_meta($subscription_id, $meta_key, sanitize_text_field($subscription_data[$key]));
            }
        }

        // Update import log
        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        $wpdb->query($wpdb->prepare(
            "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
            $update_count,
            $hash_key
        ));
    }

    /**
     * Import SureCart Coupons
     *
     * @param array $header_array CSV headers
     * @param array $value_array CSV row values
     * @param array $map Field mapping
     * @param string $hash_key Import hash key
     * @param string $gmode Import mode
     * @param string $templatekey Template key
     * @param int $line_number Line number
     * @return void
     */
    public function import_coupons(
        $header_array,
        $value_array,
        $map,
        $hash_key,
        $gmode,
        $templatekey,
        $line_number
    ) {
        global $wpdb, $core_instance;

        if (!is_plugin_active('surecart/surecart.php')) {
            return;
        }

        $helpers_instance = ImportHelpers::getInstance();
        $log_table_name = $wpdb->prefix . "import_detail_log";

        // Get mapped values
        $coupon_data = $helpers_instance->get_header_values($map, $header_array, $value_array);

        $coupon_code = isset($coupon_data['coupon_code']) ? sanitize_text_field($coupon_data['coupon_code']) : '';

        // Fallback: If coupon_code is empty but promotion_codes is present, use it as the code.
        if (empty($coupon_code) && !empty($coupon_data['promotion_codes'])) {
            $coupon_code = sanitize_text_field($coupon_data['promotion_codes']);
        }

        if (empty($coupon_code)) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Skipped: Coupon code is required',
                    'state' => 'Skipped'
                ];
            }
            return;
        }


        // Prepare data for SureCart Model
        $coupon_api_data = [
            'name' => $coupon_code,
            // 'code' => $coupon_code,
        ];

        // if (!empty($coupon_data['promotion_codes'])) {
        //     $promo_code = sanitize_text_field($coupon_data['promotion_codes']);
        //     $coupon_api_data['promotion_code'] = $promo_code;
        //     // If promotion_codes is explicit, use it as the main code as well
        //     $coupon_api_data['code'] = $promo_code;
        // }


        // Map discount type
        $discount_type = isset($coupon_data['discount_type']) ? $coupon_data['discount_type'] : 'percentage';
        if ($discount_type === 'fixed') {
            $coupon_api_data['promotion_type'] = 'fixed_amount';
            $coupon_api_data['amount_off'] = isset($coupon_data['discount_amount']) ? intval(floatval($coupon_data['discount_amount']) * 100) : 0;
            $coupon_api_data['currency'] = strtolower(function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'usd');
        } else {
            $coupon_api_data['promotion_type'] = 'percent'; // NOTE: API might expect 'percent' not 'percentage' for type too? Let's check error log again.
            $coupon_api_data['percent_off'] = isset($coupon_data['discount_amount']) ? floatval($coupon_data['discount_amount']) : 0;
        }

        // Additional Model fields
        if (isset($coupon_data['usage_limit'])) {
            $coupon_api_data['max_redemptions'] = intval($coupon_data['usage_limit']);
        }
        if (!empty($coupon_data['end_date'])) {
            $coupon_api_data['redeem_by'] = strtotime($coupon_data['end_date']);
        }
        // if (!empty($coupon_data['promotion_codes'])) {
        //     $coupon_api_data['promotion_code'] = sanitize_text_field($coupon_data['promotion_codes']);
        // }
        if (isset($coupon_data['usage_limit_per_user'])) {
            $coupon_api_data['max_redemptions_per_customer'] = intval($coupon_data['usage_limit_per_user']);
        }
        if (!empty($coupon_data['minimum_amount'])) {
            $coupon_api_data['min_subtotal_amount'] = intval(floatval($coupon_data['minimum_amount']));
            $currency = $coupon_data['currency'] ?? 'USD';
            $coupon_api_data['min_subtotal_amount_currency'] = strtolower($currency);
        }
        if (!empty($coupon_data['maximum_amount'])) {
            $coupon_api_data['max_subtotal_amount'] = intval(floatval($coupon_data['maximum_amount']));
            $currency = $coupon_data['currency'] ?? 'USD';
            $coupon_api_data['max_subtotal_amount_currency'] = strtolower($currency);
        }

        $sc_coupon = null;
        try {
            $sc_coupon = Coupon::create($coupon_api_data);
            if (is_wp_error($sc_coupon)) {
            } else {
            }
        } catch (\Exception $e) {
        }
        // Create promotion codes if coupon was created successfully
        if (!is_wp_error($sc_coupon) && isset($sc_coupon->id) && !empty($coupon_data['promotion_codes'])) {
            $codes = explode(',', $coupon_data['promotion_codes']);

            foreach ($codes as $c) {
                $c = trim($c);
                if (empty($c)) continue;
                $response = \SureCart::request('promotions', [
                    'method' => 'POST',
                    'body' => [
                        'promotion' => [
                            'code' => $c,
                            'coupon_id' => $sc_coupon->id,
                        ],
                    ]
                ]);
                if (is_wp_error($response)) {
                } else {
                }
            }
        }

        // Create coupon post
        $coupon_post = [
            'post_type' => 'sc_coupon',
            'post_status' => 'publish',
            'post_title' => $coupon_code
        ];

        $coupon_id = wp_insert_post($coupon_post);

        if (is_wp_error($coupon_id) || !$coupon_id) {
            if (isset($core_instance)) {
                $core_instance->detailed_log[$line_number] = [
                    'Message' => 'Failed: Could not create coupon post',
                    'state' => 'Failed'
                ];
            }
            return;
        }

        // Store SureCart ID
        if (!is_wp_error($sc_coupon) && isset($sc_coupon->id)) {
            update_post_meta($coupon_id, 'sc_id', $sc_coupon->id);
        }

        // Update coupon meta for compatibility
        $meta_fields = [
            'coupon_code' => 'sc_coupon_code',
            'discount_type' => 'sc_discount_type',
            'discount_amount' => 'sc_discount_amount',
            'status' => 'sc_status',
            'usage_limit' => 'sc_usage_limit',
            'usage_count' => 'sc_usage_count',
            'usage_limit_per_user' => 'sc_usage_limit_per_user',
            'start_date' => 'sc_start_date',
            'end_date' => 'sc_end_date',
            'minimum_amount' => 'sc_minimum_amount',
            'maximum_amount' => 'sc_maximum_amount',
            'first_order_only' => 'sc_first_order_only',
            'promotion_codes' => 'sc_promotion_code'
        ];

        foreach ($meta_fields as $key => $meta_key) {
            if (isset($coupon_data[$key])) {
                update_post_meta($coupon_id, $meta_key, sanitize_text_field($coupon_data[$key]));
            }
        }

        // Update import log
        $update_count = $helpers_instance->update_count($hash_key, 'hash_key');
        $wpdb->query($wpdb->prepare(
            "UPDATE $log_table_name SET created = %d WHERE hash_key = %s",
            $update_count,
            $hash_key
        ));

        // Update detailed log for UI feedback
        if (isset($core_instance)) {
            $core_instance->detailed_log[$line_number] = [
                'Message' => 'Created SureCart Coupon ID: ' . $coupon_id . ' (' . $coupon_code . ')',
                'state' => 'Created',
                'id' => $coupon_id,
                'status' => 'publish',
                'adminLink' => get_edit_post_link($coupon_id, true)
            ];
        }

    }

    /**
     * Normalize order_data keys - map may use 'Customer Email' (label) or 'customer_email' (field key)
     *
     * @param array $data Raw data from get_header_values
     * @return array Normalized with field keys
     */
    private function normalize_order_map_keys($data)
    {
        if (!is_array($data)) {
            return [];
        }
        $label_to_key = [
            'SC ID' => 'sc_id',
            'Order ID' => 'order_id',
            'Order Number' => 'order_number',
            'Order Status' => 'order_status',
            'Order Date' => 'order_date',
            'Customer Email' => 'customer_email',
            'Customer ID' => 'customer_id',
            'Customer Name' => 'customer_name',
            'Billing First Name' => 'billing_first_name',
            'Billing Last Name' => 'billing_last_name',
            'Billing Address Line 1' => 'billing_address_line_1',
            'Billing Address Line 2' => 'billing_address_line_2',
            'Billing City' => 'billing_city',
            'Billing State' => 'billing_state',
            'Billing Postal Code' => 'billing_postal_code',
            'Billing Country' => 'billing_country',
            'Shipping First Name' => 'shipping_first_name',
            'Shipping Last Name' => 'shipping_last_name',
            'Shipping Address Line 1' => 'shipping_address_line_1',
            'Shipping Address Line 2' => 'shipping_address_line_2',
            'Shipping City' => 'shipping_city',
            'Shipping State' => 'shipping_state',
            'Shipping Postal Code' => 'shipping_postal_code',
            'Shipping Country' => 'shipping_country',
            'Order Total' => 'total',
            'Currency' => 'currency',
            'Subtotal' => 'subtotal',
            'Tax Amount' => 'tax_amount',
            'Discount Amount' => 'discount_amount',
            'Shipping Amount' => 'shipping_amount',
            'Payment Method' => 'payment_method',
            'Payment Status' => 'payment_status',
            'Transaction ID' => 'transaction_id',
            'Line Items' => 'line_items',
            'Order Meta' => 'order_meta',
            'Subscription ID' => 'subscription_id',
            'Coupon Code' => 'coupon_code',
        ];
        $normalized = [];
        foreach ($label_to_key as $label => $field_key) {
            $value = $data[$field_key] ?? $data[$label] ?? null;
            if ($value !== '' && $value !== null) {
                $normalized[$field_key] = $value;
            }
        }
        $known_keys = array_merge(array_keys($label_to_key), array_values($label_to_key));
        foreach ($data as $key => $value) {
            if (!in_array($key, $known_keys) && ($value !== '' && $value !== null)) {
                $normalized[$key] = $value;
            }
        }
        return $normalized;
    }

    /**
     * Normalize customer_data keys - map may use 'Customer Email' (label) or 'customer_email' (field key)
     *
     * @param array $data Raw data from get_header_values
     * @return array Normalized with lowercase field keys
     */
    private function normalize_customer_map_keys($data)
    {
        if (!is_array($data)) {
            return [];
        }
        $label_to_key = [
            'SC ID' => 'sc_id',
            'Customer ID' => 'customer_id',
            'Customer Email' => 'customer_email',
            'Customer Name' => 'customer_name',
            'First Name' => 'first_name',
            'Last Name' => 'last_name',
            'User ID' => 'user_id',
            'User Login' => 'user_login',
            'User Email' => 'user_email',
            'Billing Address Line 1' => 'billing_address_line_1',
            'Billing Address Line 2' => 'billing_address_line_2',
            'Billing City' => 'billing_city',
            'Billing State' => 'billing_state',
            'Billing Postal Code' => 'billing_postal_code',
            'Billing Country' => 'billing_country',
            'Address Line 1' => 'address_line_1',
            'Address Line 2' => 'address_line_2',
            'City' => 'city',
            'State' => 'state',
            'Postal Code' => 'postal_code',
            'Country' => 'country',
            'Shipping Address Line 1' => 'shipping_address_line_1',
            'Shipping Address Line 2' => 'shipping_address_line_2',
            'Shipping City' => 'shipping_city',
            'Shipping State' => 'shipping_state',
            'Shipping Postal Code' => 'shipping_postal_code',
            'Shipping Country' => 'shipping_country',
            'Phone Number' => 'phone_number',
            'Purchase Count' => 'purchase_count',
            'Lifetime Value' => 'lifetime_value',
            'Date Created' => 'date_created',
            'Customer Meta' => 'customer_meta',
            'Order IDs' => 'order_ids',
            'Notes' => 'notes',
        ];
        $normalized = [];
        foreach ($label_to_key as $label => $field_key) {
            $value = $data[$field_key] ?? $data[$label] ?? null;
            if ($value !== '' && $value !== null) {
                $normalized[$field_key] = $value;
            }
        }
        $known_keys = array_merge(array_keys($label_to_key), array_values($label_to_key));
        foreach ($data as $key => $value) {
            if (!in_array($key, $known_keys) && ($value !== '' && $value !== null)) {
                $normalized[$key] = $value;
            }
        }
        return $normalized;
    }

    /**
     * Get or create SureCart customer
     *
     * @param string $email Customer email
     * @param array $customer_data Additional customer data
     * @return int Customer ID
     */
    private function get_or_create_surecart_customer($email, $customer_data = [])
    {
        global $wpdb;

        if (empty($email)) {
            return 0;
        }

        $local_post_id = 0;
        // Try to find existing customer by UUID (sc_id) if provided in CSV
        if (!empty($customer_data['customer_id'])) {
            $local_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s LIMIT 1",
                sanitize_text_field($customer_data['customer_id'])
            ));
        }

        // Fallback to email lookup if ID lookup found nothing
        if (!$local_post_id) {
            $local_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_customer_email' AND meta_value = %s LIMIT 1",
                $email
            ));
        }

        if ($local_post_id) {
            $current_sc_id = get_post_meta($local_post_id, 'sc_id', true);
            // If we have sc_id locally, verify cloud customer still exists (SureCart UI fetches from API)
            if (!empty($current_sc_id)) {
                $cloud_customer = null;
                try {
                    $cloud_customer = Customer::find($current_sc_id);
                } catch (\Throwable $e) {
                    // Ignore - will create new
                }
                if ($cloud_customer && !is_wp_error($cloud_customer)) {
                    return intval($local_post_id);
                }
                // Cloud customer missing (deleted?) - fall through to create
            }
        }

        // Prepare data for SureCart Model
        $customer_api_data = [
            'email' => $email,
            'first_name' => !empty($customer_data['first_name']) ? sanitize_text_field($customer_data['first_name']) : '',
            'last_name' => !empty($customer_data['last_name']) ? sanitize_text_field($customer_data['last_name']) : '',
        ];

        if (!empty($customer_data['customer_name'])) {
            $customer_api_data['name'] = sanitize_text_field($customer_data['customer_name']);
            $names = explode(' ', $customer_data['customer_name'], 2);
            if (empty($customer_api_data['first_name']))
                $customer_api_data['first_name'] = $names[0];
            if (empty($customer_api_data['last_name']) && isset($names[1]))
                $customer_api_data['last_name'] = $names[1];
        }

        if (!empty($customer_data['phone_number'])) {
            $customer_api_data['phone'] = sanitize_text_field($customer_data['phone_number']);
        }

        // Fallback: If billing/shipping specific fields are empty, try generic fields
        foreach (['billing', 'shipping'] as $type) {
            foreach (['address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'country'] as $field) {
                if (empty($customer_data[$type . '_' . $field]) && !empty($customer_data[$field])) {
                    $customer_data[$type . '_' . $field] = $customer_data[$field];
                }
            }
        }
        // Fallback: If shipping is still empty, use billing
        foreach (['address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'country'] as $field) {
            if (empty($customer_data['shipping_' . $field]) && !empty($customer_data['billing_' . $field])) {
                $customer_data['shipping_' . $field] = $customer_data['billing_' . $field];
            }
        }

        // Add billing and shipping address to API data
        foreach (['billing', 'shipping'] as $type) {
            if (!empty($customer_data[$type . '_address_line_1'])) {
                $customer_api_data[$type . '_address'] = [
                    'name' => trim(($customer_data[$type . '_first_name'] ?? $customer_api_data['first_name'] ?? '') . ' ' . ($customer_data[$type . '_last_name'] ?? $customer_api_data['last_name'] ?? '')) ?: ($customer_api_data['name'] ?? ''),
                    'line_1' => sanitize_text_field($customer_data[$type . '_address_line_1']),
                    'line_2' => sanitize_text_field($customer_data[$type . '_address_line_2'] ?? ''),
                    'city' => sanitize_text_field($customer_data[$type . '_city'] ?? ''),
                    'state' => sanitize_text_field($customer_data[$type . '_state'] ?? ''),
                    'postal_code' => sanitize_text_field($customer_data[$type . '_postal_code'] ?? ''),
                    'country' => sanitize_text_field($customer_data[$type . '_country'] ?? 'US'),
                ];
            }
        }

        $sc_customer = null;
        try {
            $sc_customer = Customer::create($customer_api_data);
        } catch (\Exception $e) {
            $sc_customer = new \WP_Error('exception', $e->getMessage());
        }

        // Fallback: If creation fails, try to find existing customer in SureCart
        if (is_wp_error($sc_customer)) {
            try {
                $query_args = ['email' => $email, 'limit' => 50];
                $existing_customers = Customer::get($query_args);
                if (is_array($existing_customers)) {
                    foreach ($existing_customers as $cust) {
                        if (isset($cust->email) && strtolower($cust->email) === strtolower($email)) {
                            $sc_customer = $cust;
                            break;
                        }
                    }
                }
            } catch (\Exception $e) {
            }
        }

        // Handle WordPress Post (Create or Update)
        if ($local_post_id) {
            $customer_id = $local_post_id;
            // Optionally update title if current is email-based but name is available
            $post_data = ['ID' => $customer_id];
            if (!empty($customer_data['customer_name'])) {
                $post_data['post_title'] = $customer_data['customer_name'];
                wp_update_post($post_data);
            }
        } else {
            $customer_post = [
                'post_type' => 'sc_customer',
                'post_status' => 'publish',
                'post_title' => !empty($customer_data['customer_name']) ? $customer_data['customer_name'] : $email
            ];
            $customer_id = wp_insert_post($customer_post);
        }

        if ($customer_id && !is_wp_error($customer_id)) {
            update_post_meta($customer_id, 'sc_customer_email', $email);
            if (!empty($customer_data['customer_name'])) {
                update_post_meta($customer_id, 'sc_customer_name', $customer_data['customer_name']);
            }

            // Store SureCart ID if returned by API
            if (!is_wp_error($sc_customer) && isset($sc_customer->id)) {
                update_post_meta($customer_id, 'sc_id', $sc_customer->id);
            } elseif (!empty($customer_data['customer_id'])) {
                // Final fallback: Use the ID provided in the CSV
                update_post_meta($customer_id, 'sc_id', sanitize_text_field($customer_data['customer_id']));
            }

            // Set first and last names if available
            if (!empty($customer_api_data['first_name'])) {
                update_post_meta($customer_id, 'sc_first_name', $customer_api_data['first_name']);
            }
            if (!empty($customer_api_data['last_name'])) {
                update_post_meta($customer_id, 'sc_last_name', $customer_api_data['last_name']);
            }

            // Addresses
            foreach (['billing', 'shipping'] as $type) {
                if (!empty($customer_data[$type . '_address_line_1'])) {
                    $addr_data = [
                        'first_name' => $customer_data[$type . '_first_name'] ?? $customer_api_data['first_name'],
                        'last_name' => $customer_data[$type . '_last_name'] ?? $customer_api_data['last_name'],
                        'address_line_1' => $customer_data[$type . '_address_line_1'],
                        'address_line_2' => $customer_data[$type . '_address_line_2'] ?? '',
                        'city' => $customer_data[$type . '_city'] ?? '',
                        'state' => $customer_data[$type . '_state'] ?? '',
                        'postal_code' => $customer_data[$type . '_postal_code'] ?? '',
                        'country' => $customer_data[$type . '_country'] ?? 'US',
                    ];
                    update_post_meta($customer_id, 'sc_' . $type . '_address', $addr_data);

                    // Also update individual meta fields for compatibility
                    foreach ($addr_data as $field => $val) {
                        update_post_meta($customer_id, 'sc_' . $type . '_' . $field, $val);
                    }
                }
            }
        }

        return $customer_id ? intval($customer_id) : 0;
    }

    /**
     * Extract cloud order ID from manually_pay API response.
     * Orders appear in SureCart Orders UI only when they have a cloud order ID.
     *
     * @param object $response manually_pay API response (checkout with possible order relation)
     * @param string $checkout_id Fallback checkout ID if order not found
     * @return string|null Order ID or null
     */
    private function extract_order_id_from_manually_pay_response($response, $checkout_id = '')
    {
        if (empty($response)) {
            return null;
        }
        // Order can be nested: response->order->id or response->order (string id)
        if (!empty($response->order)) {
            $order = $response->order;
            if (is_object($order) && !empty($order->id)) {
                return $order->id;
            }
            if (is_string($order)) {
                return $order;
            }
        }
        if (!empty($response->order_id)) {
            return $response->order_id;
        }
        // Checkout ID is not the order ID - but if API returns checkout as paid with order embedded
        if (!empty($response->attributes['order'])) {
            $order = $response->attributes['order'];
            return is_object($order) ? ($order->id ?? null) : $order;
        }
        return null;
    }

    /**
     * Get Price ID by SKU
     * 
     * @param string $sku Product SKU
     * @return string|false Price ID or false if not found
     */
    public function get_price_id_by_sku($sku)
    {
        $result = $this->get_price_id_and_currency_by_sku($sku);
        return $result ? $result['price_id'] : false;
    }

    /**
     * Get Price ID and Currency by SKU
     * 
     * @param string $sku Product SKU
     * @return array|false Array with 'price_id' and 'currency', or false if not found
     */
    public function get_price_id_and_currency_by_sku($sku)
    {
        static $price_cache = [];
        if (isset($price_cache[$sku])) {
            return $price_cache[$sku];
        }

        global $wpdb;
        $product_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key IN ('sc_sku', 'sku') AND meta_value = %s LIMIT 1",
            $sku
        ));

        // Fallback: If SKU resolution fails and it looks like price_N, try to treat N as a Post ID
        if (!$product_id && strpos($sku, 'price_') === 0) {
            $numeric_id = substr($sku, 6);
            if (is_numeric($numeric_id)) {
                $product_id = intval($numeric_id);
                // Verify it is actually a product
                $post_type = get_post_type($product_id);
                if ($post_type !== 'sc_product') {
                    $product_id = 0;
                }
            }
        }

        if (!$product_id) {
            return false;
        }

        $sc_product_id = get_post_meta($product_id, 'sc_id', true);
        if (!$sc_product_id) {
            return false;
        }

        try {
            // Verify class exists before calling
            if (class_exists('\SureCart\Models\Product')) {
                $product = \SureCart\Models\Product::with(['prices'])->find($sc_product_id);
                if ($product && !is_wp_error($product) && !empty($product->prices->data)) {
                    $price_data = $product->prices->data[0];
                    $result = [
                        'price_id' => $price_data->id,
                        'currency' => $price_data->currency ?? ''
                    ];
                    $price_cache[$sku] = $result;
                    return $result;
                }
            }
        } catch (\Exception $e) {
        }

        return false;
    }

    /**
     * Get first available price from store (for order import fallback when no line items)
     * Ensures imported orders can be created via SureCart API and appear in Orders UI
     *
     * @return array|false Array with 'price_id', 'currency', 'amount' or false
     */
    private function get_first_available_price_for_import()
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        global $wpdb;

        // Prefer "Simple" products (no variants) - they are purchasable for manually_pay
        $product_post_id = $wpdb->get_var(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = 'sc_id'
             WHERE p.post_type = 'sc_product' AND p.post_status = 'publish'
             AND (p.post_title LIKE '%Simple Physical%' OR p.post_title LIKE '%Simple Installment%')
             LIMIT 1"
        );
        if (!$product_post_id) {
            $product_post_id = $wpdb->get_var(
                "SELECT p.ID FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = 'sc_id'
                 WHERE p.post_type = 'sc_product' AND p.post_status = 'publish'
                 LIMIT 1"
            );
        }

        if (!$product_post_id) {
            return false;
        }

        $sc_product_id = get_post_meta($product_post_id, 'sc_id', true);
        if (!$sc_product_id) {
            return false;
        }

        try {
            if (!class_exists('\SureCart\Models\Product')) {
                return false;
            }
            $product = \SureCart\Models\Product::with(['prices'])->find($sc_product_id);
            if (!$product || is_wp_error($product) || empty($product->prices->data)) {
                return false;
            }

            $price_data = $product->prices->data[0];
            $result = [
                'price_id' => $price_data->id,
                'currency' => $price_data->currency ?? 'usd',
                'amount' => $price_data->amount ?? 0,
            ];
            $cached = $result;
            return $result;
        } catch (\Exception $e) {
        }

        return false;
    }

    private function parse_variant_option_defs($variant_options_string) {
        $options = [];
        if (empty($variant_options_string)) {
            return $options;
        }

        $parts = explode('|', $variant_options_string);
        foreach ($parts as $part) {
            $split = explode(':', $part);
            if (count($split) >= 2) {
                $name = trim($split[0]);
                $values = array_map('trim', explode(',', $split[1]));
                $options[] = [
                    'name' => $name,
                    'values' => $values
                ];
            }
        }
        return $options;
    }
}

