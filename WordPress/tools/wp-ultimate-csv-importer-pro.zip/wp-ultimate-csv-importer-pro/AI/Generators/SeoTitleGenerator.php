<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\AIResponseParser;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\PromptBuilder;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SEO title suggestions for RankMath, Yoast, AIOSEO, or custom meta.
 */
class SeoTitleGenerator {

	/**
	 * @param string $title   Primary title.
	 * @param string $context Extra context.
	 * @return string
	 */
	public function generate( $title, $context = '' ) {
		$provider = new OpenAIProvider();
		if ( ! $provider->is_available() ) {
			return '';
		}
		$raw = $provider->complete( PromptBuilder::seo_title( $title, $context ) );
		return AIResponseParser::parse_single_line( is_string( $raw ) ? $raw : '' );
	}
}
