<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\AIResponseParser;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\PromptBuilder;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Suggests categories for import rows (never auto-applied).
 */
class CategoryGenerator {

	/**
	 * @param string $content  Row text.
	 * @param string $taxonomy Taxonomy slug.
	 * @return array<int, string>
	 */
	public function suggest( $content, $taxonomy = 'category' ) {
		$tax = get_taxonomy( $taxonomy );
		$label = $tax && ! is_wp_error( $tax ) ? $tax->labels->name : $taxonomy;
		$existing = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'number'     => 50,
				'fields'     => 'names',
			)
		);
		if ( is_wp_error( $existing ) ) {
			$existing = array();
		}
		$provider = new OpenAIProvider();
		if ( ! $provider->is_available() ) {
			return array();
		}
		$prompt = PromptBuilder::category_suggestions(
			$content,
			array( 'name' => $taxonomy, 'label' => $label ),
			is_array( $existing ) ? $existing : array()
		);
		$raw = $provider->complete( $prompt );
		return AIResponseParser::parse_string_list( is_string( $raw ) ? $raw : '' );
	}
}
