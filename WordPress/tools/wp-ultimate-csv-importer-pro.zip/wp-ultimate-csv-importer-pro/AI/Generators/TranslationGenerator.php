<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\AISettingsService;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Translates field values via WordPress AI Client (Connectors).
 */
class TranslationGenerator {

	/**
	 * @param string $text        Source text.
	 * @param string $target_lang Target language.
	 * @param string $source_lang Source language (optional, passed in prompt).
	 * @return string
	 */
	public function translate( $text, $target_lang = '', $source_lang = '' ) {
		if ( '' === trim( $text ) ) {
			return '';
		}
		$settings = AISettingsService::getInstance()->get_all();
		$target   = $target_lang ?: ( $settings['translation_target_lang'] ?? 'EN' );
		$o        = new OpenAIProvider();
		if ( ! $o->is_available() ) {
			return '';
		}
		$out = $o->translate( $text, $target, $source_lang );
		return is_string( $out ) ? $out : '';
	}
}
