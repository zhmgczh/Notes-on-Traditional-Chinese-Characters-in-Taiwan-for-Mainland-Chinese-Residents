<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\AIResponseParser;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\PromptBuilder;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\AISettingsService;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Meta description suggestions with character limit handling.
 */
class MetaDescriptionGenerator {

	/**
	 * @param string $content Source content.
	 * @return string
	 */
	public function generate( $content ) {
		$settings = AISettingsService::getInstance()->get_all();
		$limit    = (int) ( $settings['meta_description_limit'] ?? 160 );
		$provider = new OpenAIProvider();
		if ( ! $provider->is_available() ) {
			return '';
		}
		$raw = $provider->complete( PromptBuilder::meta_description( $content, $limit ) );
		$text = AIResponseParser::parse_single_line( is_string( $raw ) ? $raw : '' );
		return AIResponseParser::truncate_description( $text, $limit );
	}
}
