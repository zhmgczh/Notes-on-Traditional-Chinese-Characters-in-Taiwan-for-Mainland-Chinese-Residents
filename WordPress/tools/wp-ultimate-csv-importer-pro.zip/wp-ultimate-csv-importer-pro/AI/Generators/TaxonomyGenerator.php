<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\AIResponseParser;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\PromptBuilder;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates tag-style taxonomy term suggestions.
 */
class TaxonomyGenerator {

	/**
	 * @param string $content Source text.
	 * @return array<int, string>
	 */
	public function suggest_tags( $content ) {
		$provider = new OpenAIProvider();
		if ( ! $provider->is_available() ) {
			return array();
		}
		$raw = $provider->complete( PromptBuilder::taxonomy_tags( $content ) );
		return AIResponseParser::parse_string_list( is_string( $raw ) ? $raw : '' );
	}
}
