<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contract for AI / translation providers.
 */
abstract class AIProvider {

	/** @var AISettingsService */
	protected $settings;

	public function __construct() {
		$this->settings = AISettingsService::getInstance();
	}

	/**
	 * @param string $prompt User prompt.
	 * @param array  $args   Optional provider args (model, max_tokens, lang).
	 * @return string|false
	 */
	abstract public function complete( $prompt, $args = array() );

	/**
	 * @param string $text       Source text.
	 * @param string $target_lang Target language code.
	 * @param string $source_lang Source language code (optional).
	 * @return string|false
	 */
	abstract public function translate( $text, $target_lang, $source_lang = '' );

	/**
	 * @return bool
	 */
	abstract public function is_available();
}
