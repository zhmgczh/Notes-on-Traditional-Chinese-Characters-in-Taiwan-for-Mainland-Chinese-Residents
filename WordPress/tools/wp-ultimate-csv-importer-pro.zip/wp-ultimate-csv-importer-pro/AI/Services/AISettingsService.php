<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI feature toggles. API credentials come from WordPress Settings → Connectors only.
 */
class AISettingsService {

	const OPTION_KEY = 'sm_uci_pro_ai_settings';

	private static $instance = null;

	/** @var array<string, mixed> */
	private $defaults = array(
		'enabled'                      => false,
		'category_suggestions'         => false,
		'taxonomy_suggestions'         => false,
		'seo_title_suggestions'        => false,
		'meta_description_suggestions' => false,
		'translation'                  => false,
		'translation_target_lang'      => 'EN',
		'openai_model'                 => '',
		'rate_limit_per_minute'        => 60,
		'batch_size'                   => 25,
		'request_timeout'              => 120,
		'meta_description_limit'       => 160,
	);

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_all() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return array_merge( $this->defaults, $stored );
	}

	/**
	 * Settings for admin UI (no API key fields).
	 *
	 * @return array<string, mixed>
	 */
	public function get_public_settings() {
		$all     = $this->get_all();
		$status  = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper' )
			? \Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper::get_status()
			: array(
				'configured'   => false,
				'settings_url' => admin_url( 'options-general.php' ),
			);
		$models  = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper' )
			? \Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper::get_available_models()
			: array();

		$all['wp_ai_available']        = function_exists( 'wp_ai_client_prompt' );
		$all['connectors_configured']  = ! empty( $status['configured'] );
		$all['connectors_settings_url'] = $status['settings_url'] ?? admin_url( 'options-general.php' );
		$all['connectors_models']      = $models;
		$all['openai_ready']           = $this->is_openai_ready();
		$all['ai_source']              = 'wordpress_connectors';
		return $all;
	}

	/**
	 * @param array<string, mixed> $input Posted settings.
	 * @return array<string, mixed>
	 */
	public function save( $input ) {
		$current = $this->get_all();
		$bool_keys = array(
			'enabled',
			'category_suggestions',
			'taxonomy_suggestions',
			'seo_title_suggestions',
			'meta_description_suggestions',
			'translation',
		);
		foreach ( $bool_keys as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$current[ $key ] = filter_var( $input[ $key ], FILTER_VALIDATE_BOOLEAN );
			}
		}
		if ( isset( $input['translation_target_lang'] ) ) {
			$current['translation_target_lang'] = sanitize_text_field( $input['translation_target_lang'] );
		}
		if ( isset( $input['openai_model'] ) ) {
			$current['openai_model'] = sanitize_text_field( $input['openai_model'] );
		}
		foreach ( array( 'rate_limit_per_minute', 'batch_size', 'request_timeout', 'meta_description_limit' ) as $int_key ) {
			if ( isset( $input[ $int_key ] ) ) {
				$current[ $int_key ] = max( 1, (int) $input[ $int_key ] );
			}
		}
		// Remove legacy plugin API keys if present.
		unset( $current['openai_api_key'], $current['deepl_api_key'], $current['google_translate_api_key'], $current['translation_provider'] );
		update_option( self::OPTION_KEY, $current, false );
		return $this->get_public_settings();
	}

	/**
	 * @param string $key Settings flag name.
	 * @return bool
	 */
	public function is_flag_enabled( $key ) {
		$s   = $this->get_all();
		$val = $s[ $key ] ?? false;
		return filter_var( $val, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * @return array<string, bool>
	 */
	public function get_active_features() {
		$master = $this->is_flag_enabled( 'enabled' );
		$flags  = array(
			'category'         => 'category_suggestions',
			'taxonomy'         => 'taxonomy_suggestions',
			'seo_title'        => 'seo_title_suggestions',
			'meta_description' => 'meta_description_suggestions',
			'translation'      => 'translation',
		);
		$out = array();
		foreach ( $flags as $key => $option ) {
			$out[ $key ] = $master && $this->is_flag_enabled( $option );
		}
		if ( $master && ! in_array( true, $out, true ) ) {
			foreach ( array_keys( $out ) as $key ) {
				$out[ $key ] = true;
			}
		}
		return $out;
	}

	public function is_review_flow_enabled() {
		if ( ! $this->is_flag_enabled( 'enabled' ) ) {
			return false;
		}
		$active = $this->get_active_features();
		return in_array( true, $active, true );
	}

	/**
	 * WordPress Connectors must be configured.
	 *
	 * @return bool
	 */
	public function is_openai_ready() {
		return ( new OpenAIProvider() )->is_available();
	}

	/**
	 * Connectors admin URL for error messages.
	 *
	 * @return string
	 */
	public function get_connectors_settings_url() {
		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper' ) ) {
			$status = \Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper::get_status();
			if ( ! empty( $status['settings_url'] ) ) {
				return $status['settings_url'];
			}
		}
		return admin_url( 'options-general.php?page=connectors-wp-admin' );
	}
}
