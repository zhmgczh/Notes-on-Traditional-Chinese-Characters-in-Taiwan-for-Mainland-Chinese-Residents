<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text generation via WordPress AI Client (Settings → Connectors).
 */
class OpenAIProvider extends AIProvider {

	/**
	 * @inheritdoc
	 */
	public function is_available() {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return false;
		}
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper' ) ) {
			return false;
		}
		return \Smackcoders\UCI\Proaddons\UltimatePro\ConnectorsHelper::has_any_connector();
	}

	/**
	 * @inheritdoc
	 */
	public function complete( $prompt, $args = array() ) {
		if ( empty( $prompt ) || ! $this->is_available() ) {
			return false;
		}
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\AIMediaSEO' ) ) {
			return false;
		}
		$seo   = \Smackcoders\UCI\Proaddons\UltimatePro\AIMediaSEO::getInstance();
		$model = isset( $args['model'] ) ? $args['model'] : $this->settings->get_all()['openai_model'];
		$prov  = isset( $args['provider'] ) ? $args['provider'] : 'openai';
		$max   = isset( $args['max_tokens'] ) ? $args['max_tokens'] : '';
		$out   = $seo->generate_text( $prompt, $prov, $model, $max );
		return ( is_string( $out ) && '' !== $out ) ? $out : false;
	}

	/**
	 * @inheritdoc
	 */
	public function translate( $text, $target_lang, $source_lang = '' ) {
		$prompt = sprintf(
			"Translate the following text to %s. Return ONLY the translation.\n\n%s",
			$target_lang,
			$text
		);
		return $this->complete( $prompt );
	}
}
