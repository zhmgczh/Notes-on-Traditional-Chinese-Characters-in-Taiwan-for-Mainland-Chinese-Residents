<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\ImportHelpers;
use Smackcoders\UCI\Proaddons\UltimatePro\ImportFileResolver;
use Smackcoders\UCI\Proaddons\UltimatePro\SmackCSVParser;
use Smackcoders\UCI\Proaddons\UltimatePro\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads import file rows in chunks for AI batch processing.
 */
class AIImportRowReader {

	/**
	 * @param string $hash_key Import hash.
	 * @return string|false
	 */
	public function resolve_file_path( $hash_key ) {
		$hash_key = sanitize_key( $hash_key );
		$path = ImportFileResolver::getInstance()->resolve_import_file_path( $hash_key );
		if ( $path && file_exists( $path ) && filesize( $path ) > 0 ) {
			return $path;
		}
		$upload = UltimatePro::getInstance()->create_upload_dir();
		$candidates = array(
			$upload . $hash_key . '/' . $hash_key,
			$upload . $hash_key . '/' . $hash_key . '_edited',
		);
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT file_name FROM {$wpdb->prefix}smackcsv_file_events WHERE hash_key = %s LIMIT 1",
				$hash_key
			)
		);
		if ( $row && ! empty( $row->file_name ) ) {
			$candidates[] = $upload . $hash_key . '/' . $row->file_name;
		}
		foreach ( $candidates as $path ) {
			if ( $path && file_exists( $path ) && filesize( $path ) > 0 ) {
				return $path;
			}
		}
		return false;
	}

	/**
	 * @param string $hash_key   Import hash.
	 * @param int    $offset     Zero-based data row offset.
	 * @param int    $limit      Max rows.
	 * @return array{headers: array, rows: array<int, array{row_number: int, values: array}>}
	 */
	public function get_rows( $hash_key, $offset = 0, $limit = 25 ) {
		$hash_key = sanitize_key( (string) $hash_key );
		if (
			class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService' )
			&& class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\ExternalDbRowSource' )
			&& \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService::getInstance()->is_db_session( $hash_key )
		) {
			return $this->get_rows_from_database( $hash_key, $offset, $limit );
		}

		$path = $this->resolve_file_path( $hash_key );
		if ( ! $path ) {
			return array( 'headers' => array(), 'rows' => array() );
		}

		$offset_line = 1 + max( 0, (int) $offset );
		$parser      = new SmackCSVParser();
		$res         = $parser->parseCSV( $path, $offset_line, (int) $limit );
		if ( ! is_array( $res ) || empty( $res['values'] ) ) {
			return $this->get_rows_fgetcsv( $path, $offset, $limit );
		}
		$headers = ! empty( $res['headers'][0] ) ? $this->normalize_headers( (array) $res['headers'][0] ) : array();
		$data    = isset( $res['values'] ) && is_array( $res['values'] ) ? $res['values'] : array();
		$rows    = array();
		$line    = $offset_line;
		foreach ( $data as $parser_key => $values ) {
			if ( is_numeric( $parser_key ) ) {
				$line = (int) $parser_key;
			}
			$rows[] = array(
				'row_number' => $line,
				'values'     => array_values( (array) $values ),
			);
			++$line;
		}
		return array( 'headers' => $headers, 'rows' => $rows );
	}

	/**
	 * Read rows from an external database import session (header-only stub CSV on disk).
	 *
	 * @param string $hash_key Import hash.
	 * @param int    $offset Zero-based data row offset.
	 * @param int    $limit  Max rows.
	 * @return array{headers: array, rows: array, error?: string}
	 */
	private function get_rows_from_database( $hash_key, $offset, $limit ) {
		$line_start = 1 + max( 0, (int) $offset );
		$limit      = max( 1, (int) $limit );
		$batch      = \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\ExternalDbRowSource::fetch_page(
			$hash_key,
			$line_start,
			$limit
		);
		$headers = array();
		if ( ! empty( $batch['headers'] ) && is_array( $batch['headers'] ) ) {
			$headers = $this->normalize_headers( $batch['headers'] );
		}
		if ( ! empty( $batch['error'] ) ) {
			return array(
				'headers' => $headers,
				'rows'    => array(),
				'error'   => (string) $batch['error'],
			);
		}
		$rows = array();
		$data = isset( $batch['rows'] ) && is_array( $batch['rows'] ) ? $batch['rows'] : array();
		foreach ( $data as $i => $values ) {
			$rows[] = array(
				'row_number' => $line_start + (int) $i,
				'values'     => array_values( (array) $values ),
			);
		}
		return array( 'headers' => $headers, 'rows' => $rows );
	}

	/**
	 * Fallback CSV reader when SmackCSVParser fails.
	 *
	 * @param string $path   File path.
	 * @param int    $offset Zero-based data offset.
	 * @param int    $limit  Max rows.
	 * @return array{headers: array, rows: array}
	 */
	private function get_rows_fgetcsv( $path, $offset, $limit ) {
		$handle = fopen( $path, 'r' );
		if ( ! $handle ) {
			return array( 'headers' => array(), 'rows' => array() );
		}
		$delimiter = ',';
		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\ValidateFile' ) ) {
			$vf        = \Smackcoders\UCI\Proaddons\UltimatePro\ValidateFile::getInstance();
			$delimiter = $vf->getFileDelimiter( $path, 5 );
			if ( '\t' === $delimiter ) {
				$delimiter = "\t";
			}
		}
		$headers = fgetcsv( $handle, 0, $delimiter, '"', '\\' );
		if ( ! is_array( $headers ) ) {
			fclose( $handle );
			return array( 'headers' => array(), 'rows' => array() );
		}
		$headers = $this->normalize_headers( $headers );
		$data_idx = 0;
		$rows     = array();
		$line     = 1;
		while ( ( $data = fgetcsv( $handle, 0, $delimiter, '"', '\\' ) ) !== false ) {
			++$line;
			if ( empty( $data[0] ) && count( array_filter( $data ) ) === 0 ) {
				continue;
			}
			if ( $data_idx < $offset ) {
				++$data_idx;
				continue;
			}
			if ( count( $rows ) >= $limit ) {
				break;
			}
			$rows[] = array(
				'row_number' => $line,
				'values'     => array_map( 'trim', $data ),
			);
			++$data_idx;
		}
		fclose( $handle );
		return array( 'headers' => $headers, 'rows' => $rows );
	}

	/**
	 * Build text from mapped WP fields, else all non-empty CSV columns.
	 *
	 * @param array      $headers CSV headers.
	 * @param array      $values  Row values.
	 * @param array|null $mapping Saved mapping payload.
	 * @return string
	 */
	public function build_content( $headers, $values, $mapping = null ) {
		if ( is_array( $mapping ) && ! empty( $mapping ) ) {
			$from_map = $this->build_content_from_mapping( $headers, $values, $mapping );
			if ( '' !== trim( $from_map ) ) {
				return $from_map;
			}
		}
		$parts = array();
		foreach ( (array) $values as $v ) {
			$v = trim( (string) $v );
			if ( '' !== $v ) {
				$parts[] = $v;
			}
		}
		return implode( "\n", array_slice( $parts, 0, 8 ) );
	}

	/**
	 * @param array $headers Headers.
	 * @param array $values  Values.
	 * @param array $mapping Mapping sections.
	 * @return string
	 */
	public function build_content_from_mapping( $headers, $values, $mapping ) {
		$helpers = ImportHelpers::getInstance();
		$parts   = array();
		$fields  = array(
			'post_title',
			'post_content',
			'post_excerpt',
			'PRODUCTSKU',
			'name',
			'title',
		);
		$sections = array( 'CORE', 'ECOMMETA', 'CORECUSTFIELDS' );
		foreach ( $sections as $section ) {
			if ( empty( $mapping[ $section ] ) || ! is_array( $mapping[ $section ] ) ) {
				continue;
			}
			foreach ( $fields as $field ) {
				if ( empty( $mapping[ $section ][ $field ] ) ) {
					continue;
				}
				$csv_header = $mapping[ $section ][ $field ];
				if ( '--select--' === $csv_header || '' === $csv_header ) {
					continue;
				}
				$val = $helpers->replace_header_with_values( $csv_header, $headers, $values );
				$val = trim( (string) $val );
				if ( '' !== $val ) {
					$parts[] = $val;
				}
			}
		}
		return implode( "\n", array_unique( $parts ) );
	}

	/**
	 * Trim headers and strip UTF-8 BOM from the first column name.
	 *
	 * @param array<int, string> $headers Raw headers.
	 * @return array<int, string>
	 */
	private function normalize_headers( $headers ) {
		$out = array();
		foreach ( $headers as $h ) {
			$out[] = $this->normalize_header_name( $h );
		}
		return $out;
	}

	/**
	 * @param string $header Header cell.
	 * @return string
	 */
	public function normalize_header_name( $header ) {
		$header = trim( (string) $header );
		if ( '' !== $header && 0 === strpos( $header, "\xEF\xBB\xBF" ) ) {
			$header = substr( $header, 3 );
		}
		return trim( $header );
	}
}
