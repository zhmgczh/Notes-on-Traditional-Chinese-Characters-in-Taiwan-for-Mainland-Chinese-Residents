<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Google Cloud Translation API v2.
 */
class GoogleTranslateProvider extends AIProvider {

	/**
	 * @inheritdoc
	 */
	public function is_available() {
		return false;
	}

	/**
	 * @inheritdoc
	 */
	public function complete( $prompt, $args = array() ) {
		return false;
	}

	/**
	 * @inheritdoc
	 */
	public function translate( $text, $target_lang, $source_lang = '' ) {
		return false;
	}
}
