<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * DeepL translation API.
 */
class DeepLProvider extends AIProvider {

	/**
	 * @inheritdoc
	 */
	public function is_available() {
		return false;
	}

	/**
	 * @inheritdoc
	 */
	public function complete( $prompt, $args = array() ) {
		return false;
	}

	/**
	 * @inheritdoc
	 */
	public function translate( $text, $target_lang, $source_lang = '' ) {
		return false;
	}
}
