# AI Import Features (Pro)

Optional AI-powered category, taxonomy, SEO, and translation suggestions with a human review step before import.

## Database

Table: `{prefix}sm_uci_addon_pro_ai_reviews`

| Column | Description |
|--------|-------------|
| id | Primary key |
| import_id | Import hash (`HashKey`) |
| row_number | 1-based CSV row |
| field_name | Target field or meta key |
| feature_type | `category`, `taxonomy`, `seo_title`, `meta_description`, `translation` |
| original_value | Source text |
| suggested_value | AI output (editable) |
| status | `pending`, `approved`, `rejected`, `edited` |

Option: `sm_uci_pro_ai_settings` (feature toggles only; API keys live in WordPress **Settings → Connectors**).

## Import workflow

1. Upload → Mapping → Preview / Spreadsheet Editor  
2. **AI Generation** (batched AJAX, optional)  
3. **AI Review** (approve / reject / edit / bulk actions, skippable)  
4. Import configuration → Import  

When AI is disabled in settings, behavior matches the previous release.

## AJAX endpoints

All require `securekey` nonce (`smack-ultimate-csv-importer-pro`) and `manage_options`.

| Action | Purpose |
|--------|---------|
| `uci_ai_get_settings` | Load settings + Connectors status |
| `uci_ai_save_settings` | Save settings |
| `uci_ai_review_status` | Check if review flow is enabled |
| `uci_ai_generate_batch` | Generate suggestions (`offset`, `config`, optional `reset`) |
| `uci_ai_get_reviews` | List review rows |
| `uci_ai_update_review` | Approve / reject / edit single row |
| `uci_ai_bulk_review` | `approve_all`, `reject_all`, `approve_pending`, `reject_pending` |
| `uci_ai_clear_reviews` | Clear queue for import |

## Hooks

| Hook | Type | Args |
|------|------|------|
| `sm_uci_pro_import_row_data` | filter | `$row_data`, `$import_id`, `$line_number`, `$header_array` |
| `sm_uci_pro_ai_apply_field_value` | filter | `$value`, `$field_name`, `$line_number`, `$import_id`, `$header_array` |
| `sm_uci_pro_ai_batch_generated` | action | `$import_id`, `$offset`, `$created`, `$config` |
| `sm_uci_pro_after_import` | action | Clears AI apply cache |

## Providers

- **All text AI** (category, taxonomy, SEO, meta, translation): WordPress AI Client (`wp_ai_client_prompt`) via `ConnectorsHelper` / `AIMediaSEO` — same as media AI. No API keys in this plugin.

## Governance (provider manager, usage logs, cost)

- Namespace: `AI/Governance/`
- Central gateway: `AIProviderManager` (retries, fallback, usage logging)
- Options: `sm_uci_pro_ai_provider_settings`, `sm_uci_pro_ai_cost_settings`
- Tables: `sm_uci_addon_pro_ai_usage_log`, `sm_uci_addon_pro_ai_prompt_templates`

## Performance

- Configurable `batch_size` (default 25) and chunked `uci_ai_generate_batch` requests.
- Review data stored in MySQL to avoid PHP memory limits on 10k+ row imports.

## Import apply

Approved values are merged into each CSV row before `main_import_process`. Tags and Yoast SEO fields without CSV mapping are applied on the post after insert via `ReviewManager::apply_post_level_overrides()`.
