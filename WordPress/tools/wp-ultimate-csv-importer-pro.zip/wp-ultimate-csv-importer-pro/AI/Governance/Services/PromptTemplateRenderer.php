<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Substitutes {{placeholder}} tokens in prompt templates.
 */
class PromptTemplateRenderer {

	/** @var array<int, string> */
	private static $allowed_keys = array(
		'title',
		'content',
		'excerpt',
		'category',
		'taxonomy',
	);

	/**
	 * @param string               $template Template body.
	 * @param array<string, string> $context  Placeholder values.
	 * @return string
	 */
	public static function render( $template, $context = array() ) {
		$template = (string) $template;
		foreach ( self::$allowed_keys as $key ) {
			$value = isset( $context[ $key ] ) ? (string) $context[ $key ] : '';
			$template = str_replace( '{{' . $key . '}}', $value, $template );
		}
		return $template;
	}
}
