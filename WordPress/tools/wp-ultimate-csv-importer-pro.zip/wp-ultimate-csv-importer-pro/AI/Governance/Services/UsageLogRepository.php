<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persists AI token usage and cost estimates.
 */
class UsageLogRepository {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_ai_usage_log';
	}

	/**
	 * @param array<string, mixed> $row Log row.
	 * @return int|false
	 */
	public function log( $row ) {
		global $wpdb;
		$data = array(
			'import_id'       => sanitize_key( $row['import_id'] ?? '' ),
			'provider'        => sanitize_key( $row['provider'] ?? '' ),
			'model'           => sanitize_text_field( $row['model'] ?? '' ),
			'operation'       => sanitize_key( $row['operation'] ?? 'generate' ),
			'tokens_input'    => max( 0, (int) ( $row['tokens_input'] ?? 0 ) ),
			'tokens_output'   => max( 0, (int) ( $row['tokens_output'] ?? 0 ) ),
			'estimated_cost'  => (float) ( $row['estimated_cost'] ?? 0 ),
			'status'          => sanitize_key( $row['status'] ?? 'success' ),
			'error_message'   => isset( $row['error_message'] ) ? sanitize_text_field( (string) $row['error_message'] ) : '',
			'created_at'      => current_time( 'mysql', true ),
		);
		$ok = $wpdb->insert( self::table_name(), $data );
		return false === $ok ? false : (int) $wpdb->insert_id;
	}

	/**
	 * @param array<string, mixed> $args Filters: provider, status, search, date_from, date_to, offset, limit.
	 * @return array<int, object>
	 */
	public function get_logs( $args = array() ) {
		global $wpdb;
		$table  = self::table_name();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['provider'] ) ) {
			$where[]  = 'provider = %s';
			$params[] = sanitize_key( $args['provider'] );
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $args['status'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$where[]  = '(operation LIKE %s OR error_message LIKE %s OR model LIKE %s)';
			$like     = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = sanitize_text_field( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = sanitize_text_field( $args['date_to'] );
		}

		$limit  = isset( $args['limit'] ) ? max( 1, (int) $args['limit'] ) : 50;
		$offset = isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0;
		$sql    = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d';
		$params[] = $limit;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
	}

	/**
	 * @param array<string, mixed> $args Same filters as get_logs.
	 * @return string CSV content.
	 */
	public function export_csv( $args = array() ) {
		$args['limit']  = isset( $args['limit'] ) ? (int) $args['limit'] : 10000;
		$args['offset'] = 0;
		$rows           = $this->get_logs( $args );
		$lines          = array( 'id,import_id,provider,model,operation,tokens_input,tokens_output,estimated_cost,status,error_message,created_at' );
		foreach ( $rows as $row ) {
			$lines[] = implode(
				',',
				array(
					(int) $row->id,
					'"' . str_replace( '"', '""', (string) $row->import_id ) . '"',
					'"' . str_replace( '"', '""', (string) $row->provider ) . '"',
					'"' . str_replace( '"', '""', (string) $row->model ) . '"',
					'"' . str_replace( '"', '""', (string) $row->operation ) . '"',
					(int) $row->tokens_input,
					(int) $row->tokens_output,
					(float) $row->estimated_cost,
					'"' . str_replace( '"', '""', (string) $row->status ) . '"',
					'"' . str_replace( '"', '""', (string) $row->error_message ) . '"',
					'"' . str_replace( '"', '""', (string) $row->created_at ) . '"',
				)
			);
		}
		return implode( "\n", $lines );
	}

	/**
	 * Delete all rows (for tests).
	 */
	public function truncate() {
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . self::table_name() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}
}
