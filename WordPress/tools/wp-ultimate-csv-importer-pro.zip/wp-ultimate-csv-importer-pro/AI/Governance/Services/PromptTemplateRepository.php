<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CRUD for AI prompt templates.
 */
class PromptTemplateRepository {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_ai_prompt_templates';
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public function get_defaults() {
		return array(
			array(
				'slug'         => 'category-generation',
				'name'         => 'Category Generation',
				'feature_type' => 'category',
				'body'         => "Suggest categories for:\nTitle: {{title}}\nContent: {{content}}\nCategory hint: {{category}}",
			),
			array(
				'slug'         => 'taxonomy-suggestions',
				'name'         => 'Taxonomy Suggestions',
				'feature_type' => 'taxonomy',
				'body'         => "Suggest tags for:\n{{content}}\nTaxonomy: {{taxonomy}}",
			),
			array(
				'slug'         => 'seo-meta-description',
				'name'         => 'SEO Meta Description',
				'feature_type' => 'meta_description',
				'body'         => "Write meta description for:\n{{title}}\n{{excerpt}}",
			),
			array(
				'slug'         => 'seo-title',
				'name'         => 'SEO Title',
				'feature_type' => 'seo_title',
				'body'         => "Write SEO title for:\n{{title}}\n{{content}}",
			),
			array(
				'slug'         => 'translation',
				'name'         => 'Translation',
				'feature_type' => 'translation',
				'body'         => "Translate:\n{{content}}",
			),
			array(
				'slug'         => 'content-enhancement',
				'name'         => 'Content Enhancement',
				'feature_type' => 'enhancement',
				'body'         => "Enhance content:\n{{content}}",
			),
		);
	}

	/**
	 * Seed system templates when table is empty.
	 */
	public function seed_defaults_if_empty() {
		global $wpdb;
		$table = self::table_name();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( $count > 0 ) {
			return;
		}
		$now = current_time( 'mysql', true );
		foreach ( $this->get_defaults() as $row ) {
			$wpdb->insert(
				$table,
				array(
					'slug'         => sanitize_key( $row['slug'] ),
					'name'         => sanitize_text_field( $row['name'] ),
					'feature_type' => sanitize_key( $row['feature_type'] ),
					'body'         => $row['body'],
					'is_system'    => 1,
					'created_at'   => $now,
					'updated_at'   => $now,
				)
			);
		}
	}

	/**
	 * @param string $slug Template slug.
	 * @return object|null
	 */
	public function get_by_slug( $slug ) {
		global $wpdb;
		$this->seed_defaults_if_empty();
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table_name() . ' WHERE slug = %s LIMIT 1',
				sanitize_key( $slug )
			)
		);
	}

	/**
	 * @param array<string, mixed> $data Template fields.
	 * @return int|false
	 */
	public function save( $data ) {
		global $wpdb;
		$now  = current_time( 'mysql', true );
		$slug = sanitize_key( $data['slug'] ?? '' );
		if ( '' === $slug ) {
			return false;
		}
		$row = array(
			'name'         => sanitize_text_field( $data['name'] ?? $slug ),
			'feature_type' => sanitize_key( $data['feature_type'] ?? 'custom' ),
			'body'         => wp_kses_post( (string) ( $data['body'] ?? '' ) ),
			'updated_at'   => $now,
		);
		$existing = $this->get_by_slug( $slug );
		if ( $existing ) {
			$wpdb->update( self::table_name(), $row, array( 'id' => (int) $existing->id ) );
			return (int) $existing->id;
		}
		$row['slug']       = $slug;
		$row['is_system']  = ! empty( $data['is_system'] ) ? 1 : 0;
		$row['created_at'] = $now;
		$wpdb->insert( self::table_name(), $row );
		return $wpdb->insert_id ? (int) $wpdb->insert_id : false;
	}

	/**
	 * @param int $id Template id.
	 * @return bool
	 */
	public function delete( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT is_system FROM ' . self::table_name() . ' WHERE id = %d', (int) $id ) );
		if ( $row && (int) $row->is_system === 1 ) {
			return false;
		}
		return false !== $wpdb->delete( self::table_name(), array( 'id' => (int) $id ), array( '%d' ) );
	}

	/**
	 * @param int $id Source template id.
	 * @return int|false New id.
	 */
	public function clone_template( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table_name() . ' WHERE id = %d', (int) $id ) );
		if ( ! $row ) {
			return false;
		}
		$slug = sanitize_key( $row->slug . '-copy-' . wp_generate_password( 4, false ) );
		return $this->save(
			array(
				'slug'         => $slug,
				'name'         => $row->name . ' (Copy)',
				'feature_type' => $row->feature_type,
				'body'         => $row->body,
				'is_system'    => 0,
			)
		);
	}

	/**
	 * Re-seed system templates (non-destructive: updates bodies for system slugs).
	 */
	public function reset_defaults() {
		global $wpdb;
		$now = current_time( 'mysql', true );
		foreach ( $this->get_defaults() as $row ) {
			$existing = $this->get_by_slug( $row['slug'] );
			if ( $existing ) {
				$wpdb->update(
					self::table_name(),
					array(
						'name'         => sanitize_text_field( $row['name'] ),
						'feature_type' => sanitize_key( $row['feature_type'] ),
						'body'         => $row['body'],
						'is_system'    => 1,
						'updated_at'   => $now,
					),
					array( 'id' => (int) $existing->id )
				);
			} else {
				$this->save( array_merge( $row, array( 'is_system' => 1 ) ) );
			}
		}
	}
}
