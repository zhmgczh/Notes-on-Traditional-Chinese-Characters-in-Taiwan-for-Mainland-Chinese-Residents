<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\CredentialCipher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin-owned AI provider configuration (encrypted API key at rest).
 */
class AIProviderSettings {

	const OPTION_KEY = 'sm_uci_pro_ai_provider_settings';

	const MASKED_KEY = '********';

	private static $instance = null;

	/** @var array<string, mixed> */
	private $defaults = array(
		'provider_type'       => 'openai',
		'api_key_enc'         => '',
		'model'               => '',
		'endpoint_url'        => '',
		'temperature'         => 0.7,
		'max_tokens'          => 1024,
		'timeout'             => 120,
		'enable_logging'      => true,
		'enable_cost_tracking' => true,
		'fallback_order'      => array( 'openai', 'local', 'custom' ),
		'max_retries'         => 3,
	);

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_all() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$merged = array_merge( $this->defaults, $stored );
		if ( ! is_array( $merged['fallback_order'] ) ) {
			$merged['fallback_order'] = $this->defaults['fallback_order'];
		}
		return $merged;
	}

	/**
	 * Settings safe for admin UI (masked key).
	 *
	 * @return array<string, mixed>
	 */
	public function get_public() {
		$all = $this->get_all();
		$all['api_key']        = ! empty( $all['api_key_enc'] ) ? self::MASKED_KEY : '';
		$all['has_api_key']    = ! empty( $all['api_key_enc'] );
		unset( $all['api_key_enc'] );
		return $all;
	}

	/**
	 * @return string Plain API key or empty.
	 */
	public function get_decrypted_api_key() {
		$enc = (string) ( $this->get_all()['api_key_enc'] ?? '' );
		if ( '' === $enc ) {
			return '';
		}
		return CredentialCipher::decrypt( $enc );
	}

	/**
	 * @param array<string, mixed> $input Posted settings.
	 * @return array<string, mixed>
	 */
	public function save( $input ) {
		$current = $this->get_all();

		if ( isset( $input['provider_type'] ) ) {
			$type = sanitize_key( $input['provider_type'] );
			if ( in_array( $type, array( 'openai', 'local', 'custom' ), true ) ) {
				$current['provider_type'] = $type;
			}
		}

		if ( isset( $input['api_key'] ) ) {
			$key = (string) $input['api_key'];
			if ( self::MASKED_KEY !== $key && '' !== trim( $key ) ) {
				$current['api_key_enc'] = CredentialCipher::encrypt( sanitize_text_field( $key ) );
			}
		}

		if ( isset( $input['model'] ) ) {
			$current['model'] = sanitize_text_field( $input['model'] );
		}
		if ( isset( $input['endpoint_url'] ) ) {
			$current['endpoint_url'] = esc_url_raw( $input['endpoint_url'] );
		}
		if ( isset( $input['temperature'] ) ) {
			$current['temperature'] = min( 2.0, max( 0.0, (float) $input['temperature'] ) );
		}
		if ( isset( $input['max_tokens'] ) ) {
			$current['max_tokens'] = max( 1, (int) $input['max_tokens'] );
		}
		if ( isset( $input['timeout'] ) ) {
			$current['timeout'] = max( 5, (int) $input['timeout'] );
		}
		foreach ( array( 'enable_logging', 'enable_cost_tracking' ) as $bool_key ) {
			if ( isset( $input[ $bool_key ] ) ) {
				$current[ $bool_key ] = filter_var( $input[ $bool_key ], FILTER_VALIDATE_BOOLEAN );
			}
		}
		if ( isset( $input['max_retries'] ) ) {
			$current['max_retries'] = max( 0, min( 10, (int) $input['max_retries'] ) );
		}
		if ( isset( $input['fallback_order'] ) && is_array( $input['fallback_order'] ) ) {
			$order = array();
			foreach ( $input['fallback_order'] as $slug ) {
				$slug = sanitize_key( $slug );
				if ( in_array( $slug, array( 'openai', 'local', 'custom' ), true ) && ! in_array( $slug, $order, true ) ) {
					$order[] = $slug;
				}
			}
			if ( ! empty( $order ) ) {
				$current['fallback_order'] = $order;
			}
		}

		update_option( self::OPTION_KEY, $current, false );
		return $this->get_public();
	}
}
