<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Contracts\AIProviderInterface;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers\CustomEndpointProvider;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers\LocalModelProvider;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers\OpenAIConnectorProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central gateway for AI requests: validation, retries, fallback, logging.
 */
class AIProviderManager {

	private static $instance = null;

	/** @var array<string, AIProviderInterface>|null Test doubles keyed by slug. */
	private static $test_providers = null;

	/** @var AIProviderSettings */
	private $settings;

	/** @var UsageLogRepository */
	private $usage_log;

	/** @var CostEstimator */
	private $cost_estimator;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->settings       = AIProviderSettings::getInstance();
		$this->usage_log      = UsageLogRepository::getInstance();
		$this->cost_estimator = new CostEstimator();
	}

	/**
	 * Inject mock providers for automated tests (never calls external APIs).
	 *
	 * @param array<string, AIProviderInterface> $providers Slug => provider.
	 */
	public static function set_test_providers( array $providers ) {
		self::$test_providers = $providers;
	}

	/**
	 * Clear test provider injection.
	 */
	public static function reset_test_providers() {
		self::$test_providers = null;
	}

	/**
	 * @param string $slug Provider slug.
	 * @return AIProviderInterface|null
	 */
	public function get_provider( $slug ) {
		$slug = sanitize_key( $slug );
		if ( is_array( self::$test_providers ) && isset( self::$test_providers[ $slug ] ) ) {
			return self::$test_providers[ $slug ];
		}
		switch ( $slug ) {
			case 'openai':
				return new OpenAIConnectorProvider( $this->settings );
			case 'local':
				return new LocalModelProvider( $this->settings );
			case 'custom':
				return new CustomEndpointProvider( $this->settings );
			default:
				return null;
		}
	}

	/**
	 * @return array<int, string>
	 */
	public function get_fallback_chain() {
		$all   = $this->settings->get_all();
		$order = isset( $all['fallback_order'] ) && is_array( $all['fallback_order'] )
			? $all['fallback_order']
			: array( 'openai', 'local', 'custom' );
		$primary = sanitize_key( $all['provider_type'] ?? 'openai' );
		$chain   = array( $primary );
		foreach ( $order as $slug ) {
			$slug = sanitize_key( $slug );
			if ( ! in_array( $slug, $chain, true ) ) {
				$chain[] = $slug;
			}
		}
		return $chain;
	}

	/**
	 * @param string               $prompt    Prompt text.
	 * @param array<string, mixed> $args      Provider args.
	 * @param array<string, mixed> $meta      import_id, operation.
	 * @return array{success:bool, text:string, provider:string, tokens_input:int, tokens_output:int, message:string}
	 */
	public function generate( $prompt, $args = array(), $meta = array() ) {
		$chain      = $this->get_fallback_chain();
		$max_retries = max( 0, (int) ( $this->settings->get_all()['max_retries'] ?? 3 ) );
		$import_id  = sanitize_key( $meta['import_id'] ?? '' );
		$operation  = sanitize_key( $meta['operation'] ?? 'generate' );

		foreach ( $chain as $slug ) {
			$provider = $this->get_provider( $slug );
			if ( ! $provider ) {
				continue;
			}
			$attempts = 0;
			while ( $attempts <= $max_retries ) {
				$result = $provider->generate( $prompt, $args );
				$status = ! empty( $result['success'] ) ? 'success' : ( $attempts < $max_retries ? 'retry' : 'failed' );
				$this->maybe_log(
					array(
						'import_id'      => $import_id,
						'provider'       => $slug,
						'model'          => $args['model'] ?? $this->settings->get_all()['model'],
						'operation'      => $operation,
						'tokens_input'   => (int) ( $result['tokens_input'] ?? 0 ),
						'tokens_output'  => (int) ( $result['tokens_output'] ?? 0 ),
						'estimated_cost' => $provider->estimate_cost(
							(int) ( $result['tokens_input'] ?? 0 ),
							(int) ( $result['tokens_output'] ?? 0 )
						),
						'status'         => $status,
						'error_message'  => $result['message'] ?? '',
					)
				);
				if ( ! empty( $result['success'] ) && '' !== trim( (string) ( $result['text'] ?? '' ) ) ) {
					do_action( 'sm_uci_pro_ai_after_generate', $result, $meta );
					return array(
						'success'       => true,
						'text'          => (string) $result['text'],
						'provider'      => $slug,
						'tokens_input'  => (int) ( $result['tokens_input'] ?? 0 ),
						'tokens_output' => (int) ( $result['tokens_output'] ?? 0 ),
						'message'       => '',
					);
				}
				++$attempts;
			}
			do_action( 'sm_uci_pro_ai_provider_failed', $slug, $result['message'] ?? '', $meta );
		}

		$this->maybe_log(
			array(
				'import_id'      => $import_id,
				'provider'       => 'none',
				'model'          => '',
				'operation'      => $operation,
				'tokens_input'   => 0,
				'tokens_output'  => 0,
				'estimated_cost' => 0,
				'status'         => 'failed',
				'error_message'  => 'All providers failed.',
			)
		);

		return array(
			'success'       => false,
			'text'          => '',
			'provider'      => '',
			'tokens_input'  => 0,
			'tokens_output' => 0,
			'message'       => 'All AI providers failed; import continues without AI enhancement.',
		);
	}

	/**
	 * @param string $slug Provider slug (optional; uses primary).
	 * @return array{success:bool, message:string}
	 */
	public function health_check( $slug = '' ) {
		if ( '' === $slug ) {
			$slug = sanitize_key( $this->settings->get_all()['provider_type'] ?? 'openai' );
		}
		$provider = $this->get_provider( $slug );
		if ( ! $provider ) {
			return array( 'success' => false, 'message' => 'Unknown provider.' );
		}
		return $provider->health_check();
	}

	/**
	 * @param string $prompt Prompt.
	 * @param array  $args   Args.
	 * @return array{input_tokens:int, output_tokens:int, estimated_cost:float}
	 */
	public function estimate_request_cost( $prompt, $args = array() ) {
		$in  = $this->cost_estimator->estimate_tokens_from_text( $prompt );
		$ratio = (float) ( $this->cost_estimator->get_settings()['output_token_ratio'] ?? 0.5 );
		$out = (int) ceil( $in * $ratio );
		return array(
			'input_tokens'    => $in,
			'output_tokens'   => $out,
			'estimated_cost'  => $this->cost_estimator->calculate_cost( $in, $out ),
		);
	}

	/**
	 * @param array<string, mixed> $row Log row.
	 */
	private function maybe_log( $row ) {
		$all = $this->settings->get_all();
		if ( empty( $all['enable_logging'] ) ) {
			return;
		}
		$this->usage_log->log( $row );
	}
}
