<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Heuristic token and cost estimation before bulk AI runs.
 */
class CostEstimator {

	const OPTION_KEY = 'sm_uci_pro_ai_cost_settings';

	/** @var array<string, float> Default USD per 1K tokens (input, output). */
	private $default_pricing = array(
		'input_per_1k'  => 0.0005,
		'output_per_1k' => 0.0015,
	);

	/**
	 * @param string $text Text to estimate.
	 * @return int Estimated tokens.
	 */
	public function estimate_tokens_from_text( $text ) {
		$len = strlen( (string) $text );
		return max( 1, (int) ceil( $len / 4 ) );
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return array_merge(
			array(
				'input_per_1k'              => $this->default_pricing['input_per_1k'],
				'output_per_1k'             => $this->default_pricing['output_per_1k'],
				'confirm_row_threshold'     => 50,
				'output_token_ratio'        => 0.5,
			),
			$stored
		);
	}

	/**
	 * @param int $input_tokens  Input tokens.
	 * @param int $output_tokens Output tokens.
	 * @return float
	 */
	public function calculate_cost( $input_tokens, $output_tokens ) {
		$s     = $this->get_settings();
		$input = ( (int) $input_tokens / 1000 ) * (float) $s['input_per_1k'];
		$out   = ( (int) $output_tokens / 1000 ) * (float) $s['output_per_1k'];
		return round( $input + $out, 6 );
	}

	/**
	 * @param int                  $row_count      Rows selected.
	 * @param array<string, bool>  $active_features Feature flags.
	 * @param int                  $avg_chars      Avg chars per row content.
	 * @return array<string, mixed>
	 */
	public function estimate_bulk( $row_count, $active_features = array(), $avg_chars = 500 ) {
		$row_count = max( 0, (int) $row_count );
		$features  = array_filter( $active_features );
		$ops       = max( 1, count( $features ) );
		$per_row   = $this->estimate_tokens_from_text( str_repeat( 'x', $avg_chars ) );
		$input     = $per_row * $ops * $row_count;
		$ratio     = (float) ( $this->get_settings()['output_token_ratio'] ?? 0.5 );
		$output    = (int) ceil( $input * $ratio );
		$cost      = $this->calculate_cost( $input, $output );
		$s         = $this->get_settings();
		$needs     = $row_count >= (int) ( $s['confirm_row_threshold'] ?? 50 );

		return array(
			'rows_selected'           => $row_count,
			'estimated_input_tokens'  => $input,
			'estimated_output_tokens' => $output,
			'estimated_total_cost'    => $cost,
			'requires_confirmation'   => $needs,
		);
	}
}
