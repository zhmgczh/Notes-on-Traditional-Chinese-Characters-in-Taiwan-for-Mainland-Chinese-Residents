<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Contracts\AIProviderInterface;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services\AIProviderSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Local model HTTP endpoint provider.
 */
class LocalModelProvider implements AIProviderInterface {

	/** @var AIProviderSettings */
	protected $settings;

	public function __construct( ?AIProviderSettings $settings = null ) {
		$this->settings = $settings ?: AIProviderSettings::getInstance();
	}

	public function get_slug() {
		return 'local';
	}

	public function connect() {
		$check = $this->health_check();
		return array(
			'success' => $check['success'],
			'message' => $check['message'],
		);
	}

	public function generate( $prompt, $args = array() ) {
		$url = $this->endpoint();
		if ( '' === $url ) {
			return $this->fail( 'Local endpoint URL is not configured.' );
		}
		$response = $this->post_json(
			$url,
			array(
				'prompt'      => $prompt,
				'model'       => $args['model'] ?? $this->settings->get_all()['model'],
				'max_tokens'  => (int) ( $args['max_tokens'] ?? $this->settings->get_all()['max_tokens'] ),
				'temperature' => (float) ( $args['temperature'] ?? $this->settings->get_all()['temperature'] ),
			)
		);
		if ( ! $response['success'] ) {
			return $response;
		}
		$text = $this->extract_text( $response['body'] );
		if ( '' === $text ) {
			return $this->fail( 'Empty response from local model.' );
		}
		$in  = (int) ceil( strlen( (string) $prompt ) / 4 );
		$out = (int) ceil( strlen( $text ) / 4 );
		return array(
			'success'       => true,
			'text'          => $text,
			'tokens_input'  => $in,
			'tokens_output' => $out,
			'message'       => '',
		);
	}

	public function estimate_cost( $tokens_input, $tokens_output ) {
		return 0.0;
	}

	public function health_check() {
		$url = $this->endpoint();
		if ( '' === $url ) {
			return array( 'success' => false, 'message' => 'Endpoint URL required.' );
		}
		$health = trailingslashit( $url ) . 'health';
		$res    = wp_remote_get( $health, array( 'timeout' => $this->timeout() ) );
		if ( is_wp_error( $res ) ) {
			$res = wp_remote_get( $url, array( 'timeout' => $this->timeout() ) );
		}
		if ( is_wp_error( $res ) ) {
			return array( 'success' => false, 'message' => $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code >= 200 && $code < 500 ) {
			return array( 'success' => true, 'message' => 'Endpoint reachable.' );
		}
		return array( 'success' => false, 'message' => 'Endpoint returned HTTP ' . $code );
	}

	/**
	 * @return string
	 */
	private function endpoint() {
		return esc_url_raw( (string) ( $this->settings->get_all()['endpoint_url'] ?? '' ) );
	}

	/**
	 * @return int
	 */
	private function timeout() {
		return max( 5, (int) ( $this->settings->get_all()['timeout'] ?? 120 ) );
	}

	/**
	 * @param string               $url  URL.
	 * @param array<string, mixed> $body JSON body.
	 * @return array{success:bool, body:array<string, mixed>, message:string}
	 */
	private function post_json( $url, $body ) {
		$headers = array( 'Content-Type' => 'application/json' );
		$key     = $this->settings->get_decrypted_api_key();
		if ( '' !== $key ) {
			$headers['Authorization'] = 'Bearer ' . $key;
		}
		$res = wp_remote_post(
			$url,
			array(
				'timeout' => $this->timeout(),
				'headers' => $headers,
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return array( 'success' => false, 'body' => array(), 'message' => $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$raw  = wp_remote_retrieve_body( $res );
		$decoded = json_decode( $raw, true );
		if ( $code < 200 || $code >= 300 ) {
			return array( 'success' => false, 'body' => is_array( $decoded ) ? $decoded : array(), 'message' => 'HTTP ' . $code );
		}
		return array( 'success' => true, 'body' => is_array( $decoded ) ? $decoded : array(), 'message' => '' );
	}

	/**
	 * @param array<string, mixed> $body Response JSON.
	 * @return string
	 */
	private function extract_text( $body ) {
		if ( isset( $body['text'] ) && is_string( $body['text'] ) ) {
			return $body['text'];
		}
		if ( isset( $body['choices'][0]['message']['content'] ) ) {
			return (string) $body['choices'][0]['message']['content'];
		}
		if ( isset( $body['response'] ) && is_string( $body['response'] ) ) {
			return $body['response'];
		}
		return '';
	}

	/**
	 * @param string $message Error message.
	 * @return array{success:bool, text:string, tokens_input:int, tokens_output:int, message:string}
	 */
	private function fail( $message ) {
		return array(
			'success'       => false,
			'text'          => '',
			'tokens_input'  => 0,
			'tokens_output' => 0,
			'message'       => $message,
		);
	}
}
