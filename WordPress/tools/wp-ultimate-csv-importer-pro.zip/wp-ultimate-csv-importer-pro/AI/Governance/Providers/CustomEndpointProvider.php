<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Custom OpenAI-compatible HTTP endpoint.
 */
class CustomEndpointProvider extends LocalModelProvider {

	public function get_slug() {
		return 'custom';
	}

	public function health_check() {
		$url = esc_url_raw( (string) ( $this->settings->get_all()['endpoint_url'] ?? '' ) );
		if ( '' === $url ) {
			return array( 'success' => false, 'message' => 'Custom endpoint URL required.' );
		}
		$res = wp_remote_get( $url, array( 'timeout' => 10 ) );
		if ( is_wp_error( $res ) ) {
			return array( 'success' => false, 'message' => $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code >= 200 && $code < 500 ) {
			return array( 'success' => true, 'message' => 'Custom endpoint reachable.' );
		}
		return array( 'success' => false, 'message' => 'HTTP ' . $code );
	}
}
