<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Providers;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Contracts\AIProviderInterface;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services\AIProviderSettings;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider as LegacyOpenAIProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OpenAI via WordPress Connectors or plugin-stored key (delegates to legacy provider).
 */
class OpenAIConnectorProvider implements AIProviderInterface {

	/** @var AIProviderSettings */
	protected $settings;

	public function __construct( ?AIProviderSettings $settings = null ) {
		$this->settings = $settings ?: AIProviderSettings::getInstance();
	}

	public function get_slug() {
		return 'openai';
	}

	public function connect() {
		return $this->health_check();
	}

	public function generate( $prompt, $args = array() ) {
		$legacy = new LegacyOpenAIProvider();
		if ( ! $legacy->is_available() && '' === $this->settings->get_decrypted_api_key() ) {
			return $this->fail( 'OpenAI is not configured.' );
		}
		$all   = $this->settings->get_all();
		$model = $args['model'] ?? $all['model'];
		$raw   = $legacy->complete(
			$prompt,
			array(
				'model'      => $model,
				'max_tokens' => $args['max_tokens'] ?? $all['max_tokens'],
			)
		);
		if ( ! is_string( $raw ) || '' === $raw ) {
			return $this->fail( 'OpenAI returned empty response.' );
		}
		$in  = (int) ceil( strlen( (string) $prompt ) / 4 );
		$out = (int) ceil( strlen( $raw ) / 4 );
		return array(
			'success'       => true,
			'text'          => $raw,
			'tokens_input'  => $in,
			'tokens_output' => $out,
			'message'       => '',
		);
	}

	public function estimate_cost( $tokens_input, $tokens_output ) {
		$est = new \Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services\CostEstimator();
		return $est->calculate_cost( $tokens_input, $tokens_output );
	}

	public function health_check() {
		$legacy = new LegacyOpenAIProvider();
		if ( $legacy->is_available() ) {
			return array( 'success' => true, 'message' => 'WordPress AI Connectors configured.' );
		}
		if ( '' !== $this->settings->get_decrypted_api_key() ) {
			return array( 'success' => true, 'message' => 'Plugin API key stored.' );
		}
		return array( 'success' => false, 'message' => 'Configure Connectors or plugin API key.' );
	}

	/**
	 * @param string $message Error.
	 * @return array{success:bool, text:string, tokens_input:int, tokens_output:int, message:string}
	 */
	private function fail( $message ) {
		return array(
			'success'       => false,
			'text'          => '',
			'tokens_input'  => 0,
			'tokens_output' => 0,
			'message'       => $message,
		);
	}
}
