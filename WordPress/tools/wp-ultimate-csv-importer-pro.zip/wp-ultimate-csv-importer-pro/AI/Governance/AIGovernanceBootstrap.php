<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Services\PromptTemplateRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads AI governance services (provider manager, templates, usage logs).
 */
class AIGovernanceBootstrap {

	private static $booted = false;

	/**
	 * Register governance classes.
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		$base = __DIR__;
		$files = array(
			'/Contracts/AIProviderInterface.php',
			'/Services/AIProviderSettings.php',
			'/Services/UsageLogRepository.php',
			'/Services/CostEstimator.php',
			'/Services/PromptTemplateRenderer.php',
			'/Services/PromptTemplateRepository.php',
			'/Services/AIProviderManager.php',
			'/Providers/LocalModelProvider.php',
			'/Providers/CustomEndpointProvider.php',
			'/Providers/OpenAIConnectorProvider.php',
		);
		foreach ( $files as $file ) {
			require_once $base . $file;
		}

		add_action( 'admin_init', array( __CLASS__, 'maybe_seed_templates' ), 20 );
	}

	/**
	 * Seed default prompt templates once tables exist.
	 */
	public static function maybe_seed_templates() {
		PromptTemplateRepository::getInstance()->seed_defaults_if_empty();
	}
}
