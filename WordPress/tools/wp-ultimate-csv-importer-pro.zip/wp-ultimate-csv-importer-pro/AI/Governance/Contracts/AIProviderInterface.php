<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contract for AI governance providers (no direct external calls from features).
 */
interface AIProviderInterface {

	/**
	 * Provider slug: openai, local, custom.
	 *
	 * @return string
	 */
	public function get_slug();

	/**
	 * Validate credentials / endpoint.
	 *
	 * @return array{success:bool, message:string}
	 */
	public function connect();

	/**
	 * @param string               $prompt Prompt text.
	 * @param array<string, mixed> $args   model, max_tokens, temperature, etc.
	 * @return array{success:bool, text:string, tokens_input:int, tokens_output:int, message:string}
	 */
	public function generate( $prompt, $args = array() );

	/**
	 * @param int $tokens_input  Input tokens.
	 * @param int $tokens_output Output tokens.
	 * @return float
	 */
	public function estimate_cost( $tokens_input, $tokens_output );

	/**
	 * @return array{success:bool, message:string}
	 */
	public function health_check();
}
