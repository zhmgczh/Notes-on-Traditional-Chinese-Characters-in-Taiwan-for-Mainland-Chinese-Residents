<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Review;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators\CategoryGenerator;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators\MetaDescriptionGenerator;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators\SeoTitleGenerator;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators\TaxonomyGenerator;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Generators\TranslationGenerator;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\AIImportRowReader;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\AISettingsService;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers\AIImportApplyResolver;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\OpenAIProvider;
use Smackcoders\UCI\Proaddons\UltimatePro\ImportHelpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Orchestrates AI suggestion generation, review queue, and import-time application.
 */
class ReviewManager {

	private static $instance = null;

	/** @var array<int, array<string, string>>|null */
	private static $import_apply_cache = null;

	/** @var string */
	private static $current_import_id = '';

	/** @var array<string, array<string, mixed>> */
	private static $import_mapping_cache = array();

	/** @var array<string, array<int, array<string, bool>>> */
	private static $csv_applied_by_line = array();

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Generate suggestions for a batch of rows.
	 *
	 * @param string $import_id Import hash.
	 * @param int    $offset    Row offset.
	 * @param array  $config    Generation config from client.
	 * @return array<string, mixed>
	 */
	public function generate_batch( $import_id, $offset, $config = array() ) {
		$settings = AISettingsService::getInstance();
		if ( ! $settings->is_review_flow_enabled() ) {
			return array( 'success' => false, 'message' => __( 'AI features are disabled.', 'wp-ultimate-csv-importer' ) );
		}
		$features = $settings->get_active_features();
		$needs_ai = in_array( true, $features, true );
		if ( $needs_ai && ! $settings->is_openai_ready() ) {
			return array(
				'success'      => false,
				'message'      => __( 'WordPress AI is not configured. Go to Settings → Connectors and add your OpenAI (or other) API key.', 'wp-ultimate-csv-importer' ),
				'openai_ready' => false,
				'settings_url' => $settings->get_connectors_settings_url(),
			);
		}
		$batch_size = (int) ( $settings->get_all()['batch_size'] ?? 25 );
		$reader     = new AIImportRowReader();
		$mapping    = isset( $config['mapping'] ) && is_array( $config['mapping'] ) ? $config['mapping'] : array();
		if ( empty( $mapping ) && ! empty( $config['mapped_fields'] ) ) {
			$decoded = ImportHelpers::decode_mapping_payload( $config['mapped_fields'] );
			if ( is_array( $decoded ) ) {
				$mapping = $decoded;
			}
		}
		$payload    = $reader->get_rows( $import_id, $offset, $batch_size );
		$headers    = $payload['headers'];
		$created    = 0;
		$taxonomy   = sanitize_key( $config['taxonomy_slug'] ?? 'category' );
		$tag_tax    = sanitize_key( $config['tag_taxonomy'] ?? 'post_tag' );
		$target_lang = sanitize_text_field( $config['target_lang'] ?? $settings->get_all()['translation_target_lang'] );

		if ( empty( $payload['rows'] ) ) {
			$empty_message = __( 'No import rows could be read from the file. Re-upload the CSV or go back to the spreadsheet step.', 'wp-ultimate-csv-importer' );
			if ( ! empty( $payload['error'] ) ) {
				$empty_message = (string) $payload['error'];
			} elseif ( $this->is_external_db_import( $import_id ) ) {
				$empty_message = __( 'No rows could be read from the database table. Go back to Import from Database and prepare the table again.', 'wp-ultimate-csv-importer' );
			}
			return array(
				'success'      => true,
				'created'      => 0,
				'next_offset'  => $offset,
				'done'         => true,
				'total_rows'   => $this->estimate_total_rows( $import_id ),
				'rows_read'    => 0,
				'file_found'   => (bool) $reader->resolve_file_path( $import_id ),
				'message'      => $empty_message,
				'counts'       => ReviewStorage::getInstance()->count_by_status( $import_id ),
			);
		}

		foreach ( $payload['rows'] as $row ) {
			$content = $reader->build_content( $headers, $row['values'], $mapping );
			$rn      = (int) $row['row_number'];
			if ( '' === trim( $content ) ) {
				continue;
			}

			if ( $features['category'] ) {
				$gen   = new CategoryGenerator();
				$terms = $gen->suggest( $content, $taxonomy );
				$cat_field = $this->category_mapping_field( $taxonomy );
				if ( ! empty( $terms ) ) {
					$this->queue_suggestion( $import_id, $rn, $cat_field, 'category', $content, implode( ' > ', $terms ) );
					$created++;
				}
			}
			if ( $features['taxonomy'] ) {
				$gen  = new TaxonomyGenerator();
				$tags = $gen->suggest_tags( $content );
				if ( ! empty( $tags ) ) {
					$this->queue_suggestion( $import_id, $rn, $tag_tax, 'taxonomy', $content, implode( ', ', $tags ) );
					$created++;
				}
			}
			if ( $features['seo_title'] ) {
				$title = $this->extract_title( $headers, $row['values'], $mapping );
				$gen   = new SeoTitleGenerator();
				$seo   = $gen->generate( $title, $content );
				if ( '' !== $seo ) {
					$field = sanitize_text_field( $config['seo_title_field'] ?? 'seo_title' );
					$this->queue_suggestion( $import_id, $rn, $field, 'seo_title', $title, $seo );
					$created++;
				}
			}
			if ( $features['meta_description'] ) {
				$gen = new MetaDescriptionGenerator();
				$md  = $gen->generate( $content );
				if ( '' !== $md ) {
					$field = sanitize_text_field( $config['meta_desc_field'] ?? 'meta_desc' );
					$this->queue_suggestion( $import_id, $rn, $field, 'meta_description', $content, $md );
					$created++;
				}
			}
			if ( $features['translation'] ) {
				$fields = isset( $config['translate_fields'] ) && is_array( $config['translate_fields'] )
					? $config['translate_fields']
					: array( 'post_title', 'post_content', 'post_excerpt' );
				$tr = new TranslationGenerator();
				foreach ( $fields as $field_name ) {
					$idx = $this->header_index( $headers, $field_name );
					if ( false === $idx || ! isset( $row['values'][ $idx ] ) ) {
						continue;
					}
					$original = (string) $row['values'][ $idx ];
					if ( '' === trim( $original ) ) {
						continue;
					}
					$translated = $tr->translate( $original, $target_lang );
					if ( '' !== $translated ) {
						$this->queue_suggestion( $import_id, $rn, sanitize_text_field( $field_name ), 'translation', $original, $translated );
						$created++;
					}
				}
			}
		}

		$total_rows = $this->estimate_total_rows( $import_id );
		$next       = $offset + count( $payload['rows'] );
		$done       = $next >= $total_rows || empty( $payload['rows'] );

		do_action( 'sm_uci_pro_ai_batch_generated', $import_id, $offset, $created, $config );

		$response = array(
			'success'      => true,
			'created'      => $created,
			'next_offset'  => $next,
			'done'         => $done,
			'total_rows'   => $total_rows,
			'rows_read'    => count( $payload['rows'] ),
			'openai_ready' => $settings->is_openai_ready(),
			'counts'       => ReviewStorage::getInstance()->count_by_status( $import_id ),
		);
		if ( $done && 0 === $created && 0 === (int) ( $response['counts']['total'] ?? 0 ) ) {
			$response['message'] = __( 'No AI suggestions were generated. Check WordPress Connectors, ensure the CSV has data in mapped columns, and try Regenerate.', 'wp-ultimate-csv-importer' );
		}
		return $response;
	}

	/**
	 * Apply approved AI values to import row data.
	 *
	 * @param array  $row_data     Current row values (indexed).
	 * @param string $import_id    Import hash.
	 * @param int    $line_number  CSV line number.
	 * @param array  $header_array Header names.
	 * @return array
	 */
	public function apply_to_row( $row_data, $import_id, $line_number, $header_array = array() ) {
		if ( ! AISettingsService::getInstance()->is_review_flow_enabled() ) {
			return $row_data;
		}
		if ( self::$current_import_id !== $import_id || null === self::$import_apply_cache ) {
			self::$current_import_id  = $import_id;
			self::$import_apply_cache = ReviewStorage::getInstance()->get_applicable_values( $import_id );
		}
		if ( empty( $line_number ) || empty( self::$import_apply_cache[ $line_number ] ) ) {
			return $row_data;
		}
		if ( ! is_array( $header_array ) ) {
			$header_array = array();
		}
		$reader = new AIImportRowReader();
		foreach ( $header_array as $i => $h ) {
			$header_array[ $i ] = $reader->normalize_header_name( $h );
		}
		$map       = $this->get_import_mapping( $import_id );
		$resolver  = new AIImportApplyResolver( $map );
		$overrides = self::$import_apply_cache[ $line_number ];

		foreach ( $overrides as $field_name => $entry ) {
			$value         = is_array( $entry ) ? (string) ( $entry['value'] ?? '' ) : (string) $entry;
			$feature_type  = is_array( $entry ) ? (string) ( $entry['feature_type'] ?? '' ) : '';
			$csv_header    = $resolver->resolve_csv_header( $field_name, $feature_type );
			if ( '' === $csv_header ) {
				continue;
			}
			$idx = $this->header_index( $header_array, $csv_header );
			if ( false === $idx ) {
				continue;
			}
			$row_data[ $idx ] = apply_filters(
				'sm_uci_pro_ai_apply_field_value',
				$value,
				$field_name,
				$line_number,
				$import_id,
				$header_array
			);
			if ( '' !== $feature_type ) {
				if ( ! isset( self::$csv_applied_by_line[ $import_id ] ) ) {
					self::$csv_applied_by_line[ $import_id ] = array();
				}
				if ( ! isset( self::$csv_applied_by_line[ $import_id ][ $line_number ] ) ) {
					self::$csv_applied_by_line[ $import_id ][ $line_number ] = array();
				}
				self::$csv_applied_by_line[ $import_id ][ $line_number ][ $feature_type ] = true;
			}
		}
		return $row_data;
	}

	/**
	 * Reset static cache between imports.
	 */
	public static function reset_import_cache() {
		self::$import_apply_cache     = null;
		self::$current_import_id      = '';
		self::$import_mapping_cache   = array();
		self::$csv_applied_by_line    = array();
	}

	/**
	 * Apply approved AI values directly on the post (tags, Yoast meta) when not mapped to CSV columns.
	 *
	 * @param int    $post_id      Created/updated post ID.
	 * @param string $import_id    Import hash.
	 * @param int    $line_number  CSV line number.
	 * @param string $import_type  Import module (Posts, WooCommerce, …).
	 */
	public function apply_post_level_overrides( $post_id, $import_id, $line_number, $import_type = '' ) {
		if ( $post_id < 1 || ! AISettingsService::getInstance()->is_review_flow_enabled() ) {
			return;
		}
		if ( self::$current_import_id !== $import_id || null === self::$import_apply_cache ) {
			self::$current_import_id  = $import_id;
			self::$import_apply_cache = ReviewStorage::getInstance()->get_applicable_values( $import_id );
		}
		if ( empty( self::$import_apply_cache[ $line_number ] ) ) {
			return;
		}
		$overrides = self::$import_apply_cache[ $line_number ];

		foreach ( $overrides as $field_name => $entry ) {
			$value        = is_array( $entry ) ? (string) ( $entry['value'] ?? '' ) : (string) $entry;
			$feature_type = is_array( $entry ) ? (string) ( $entry['feature_type'] ?? '' ) : '';
			if ( '' === trim( $value ) || ! $this->uses_post_level_apply( $feature_type ) ) {
				continue;
			}
			if ( ! empty( self::$csv_applied_by_line[ $import_id ][ $line_number ][ $feature_type ] ) ) {
				continue;
			}
			$ok = false;
			switch ( $feature_type ) {
				case 'taxonomy':
					$ok = $this->apply_tags_to_post( $post_id, $value, $import_type );
					break;
				case 'seo_title':
					$ok = $this->apply_yoast_meta( $post_id, '_yoast_wpseo_title', $value );
					break;
				case 'meta_description':
					$ok = $this->apply_yoast_meta( $post_id, '_yoast_wpseo_metadesc', $value );
					break;
				case 'category':
					$ok = $this->apply_categories_to_post( $post_id, $value, $import_type );
					break;
			}
		}
	}

	/**
	 * Features that can be written via post APIs when CSV mapping is absent.
	 *
	 * @param string $feature_type Feature type.
	 * @return bool
	 */
	private function uses_post_level_apply( $feature_type ) {
		return in_array( $feature_type, array( 'taxonomy', 'seo_title', 'meta_description', 'category' ), true );
	}

	/**
	 * @param int    $post_id     Post ID.
	 * @param string $value       Comma-separated tag names.
	 * @param string $import_type Import module.
	 * @return bool
	 */
	private function apply_tags_to_post( $post_id, $value, $import_type = '' ) {
		$taxonomy = 'post_tag';
		if ( false !== stripos( (string) $import_type, 'woo' ) ) {
			$taxonomy = 'product_tag';
		}
		$names = $this->split_list_values( $value );
		if ( empty( $names ) ) {
			return false;
		}
		$result = wp_set_object_terms( $post_id, $names, $taxonomy, false );
		return ! is_wp_error( $result );
	}

	/**
	 * @param int    $post_id     Post ID.
	 * @param string $value       Category path (Parent > Child) or name.
	 * @param string $import_type Import module.
	 * @return bool
	 */
	private function apply_categories_to_post( $post_id, $value, $import_type = '' ) {
		$taxonomy = ( false !== stripos( (string) $import_type, 'woo' ) ) ? 'product_cat' : 'category';
		$paths    = preg_split( '/\s*,\s*/', $value );
		$term_ids = array();
		foreach ( $paths as $path ) {
			$parts = preg_split( '/\s*>\s*/', trim( $path ) );
			$parent = 0;
			foreach ( $parts as $part ) {
				$part = trim( $part );
				if ( '' === $part ) {
					continue;
				}
				$existing = term_exists( $part, $taxonomy, $parent );
				if ( $existing ) {
					$term_id = is_array( $existing ) ? (int) $existing['term_id'] : (int) $existing;
				} else {
					$inserted = wp_insert_term( $part, $taxonomy, array( 'parent' => $parent ) );
					if ( is_wp_error( $inserted ) ) {
						continue 2;
					}
					$term_id = (int) $inserted['term_id'];
				}
				$parent  = $term_id;
				$term_ids[] = $term_id;
			}
		}
		$term_ids = array_values( array_unique( array_filter( $term_ids ) ) );
		if ( empty( $term_ids ) ) {
			return false;
		}
		$result = wp_set_object_terms( $post_id, $term_ids, $taxonomy, false );
		return ! is_wp_error( $result );
	}

	/**
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key.
	 * @param string $value    Meta value.
	 * @return bool
	 */
	private function apply_yoast_meta( $post_id, $meta_key, $value ) {
		update_post_meta( $post_id, $meta_key, $value );
		return true;
	}

	/**
	 * @param string $value Comma-separated list.
	 * @return array<int, string>
	 */
	private function split_list_values( $value ) {
		$parts = preg_split( '/\s*,\s*/', (string) $value );
		$out   = array();
		foreach ( $parts as $p ) {
			$p = trim( $p );
			if ( '' !== $p ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * @param string $import_id Import hash.
	 * @return int
	 */
	private function estimate_total_rows( $import_id ) {
		if ( $this->is_external_db_import( $import_id ) ) {
			$svc = \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService::getInstance();
			$session = $svc->get_session( $import_id );
			if ( $session && ! empty( $session['row_count'] ) ) {
				return (int) $session['row_count'];
			}
		}
		global $wpdb;
		$table = $wpdb->prefix . 'smackcsv_file_events';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT total_rows FROM {$table} WHERE hash_key = %s LIMIT 1", sanitize_key( $import_id ) )
		);
		if ( $row && ! empty( $row->total_rows ) ) {
			return (int) $row->total_rows;
		}
		$reader = new AIImportRowReader();
		$all    = $reader->get_rows( $import_id, 0, 999999 );
		return count( $all['rows'] );
	}

	/**
	 * @param string $import_id Import hash.
	 * @return bool
	 */
	private function is_external_db_import( $import_id ) {
		return class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService' )
			&& \Smackcoders\UCI\Proaddons\UltimatePro\DatabaseMigration\Services\DbImportSessionService::getInstance()->is_db_session( $import_id );
	}

	/**
	 * @param string $import_id Import hash.
	 * @param int    $row_number Row.
	 * @param string $field_name Field key.
	 * @param string $feature_type Feature type.
	 * @param string $original Original.
	 * @param string $suggested Suggestion.
	 */
	private function queue_suggestion( $import_id, $row_number, $field_name, $feature_type, $original, $suggested ) {
		ReviewStorage::getInstance()->insert(
			array(
				'import_id'       => $import_id,
				'row_number'      => $row_number,
				'field_name'      => $field_name,
				'feature_type'    => $feature_type,
				'original_value'  => $original,
				'suggested_value' => $suggested,
				'status'          => 'pending',
			)
		);
	}

	/**
	 * @param array $headers Headers.
	 * @param array $values Values.
	 * @return string
	 */
	private function extract_title( $headers, $values, $mapping = array() ) {
		$reader = new AIImportRowReader();
		if ( ! empty( $mapping ) ) {
			$from = $reader->build_content_from_mapping( $headers, $values, $mapping );
			$lines = explode( "\n", $from );
			if ( ! empty( $lines[0] ) ) {
				return trim( $lines[0] );
			}
		}
		if ( ! empty( $values[0] ) ) {
			return trim( (string) $values[0] );
		}
		return $reader->build_content( $headers, $values );
	}

	/**
	 * @param array  $headers Header list.
	 * @param string $field   Field name.
	 * @return int|false
	 */
	/**
	 * @param string $taxonomy Taxonomy slug from config.
	 * @return string Mapping key used in TERMS section.
	 */
	private function category_mapping_field( $taxonomy ) {
		$taxonomy = sanitize_key( $taxonomy );
		if ( in_array( $taxonomy, array( 'product_cat', 'product_category' ), true ) ) {
			return 'product_category';
		}
		if ( 'category' === $taxonomy ) {
			return 'post_category';
		}
		return $taxonomy;
	}

	/**
	 * @param string $import_id Import hash.
	 * @return array<string, mixed>
	 */
	private function get_import_mapping( $import_id ) {
		$import_id = sanitize_key( $import_id );
		if ( isset( self::$import_mapping_cache[ $import_id ] ) ) {
			return self::$import_mapping_cache[ $import_id ];
		}
		global $wpdb;
		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$raw   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT mapping FROM {$table} WHERE eventKey = %s LIMIT 1",
				$import_id
			)
		);
		$map = array();
		if ( ! empty( $raw ) ) {
			$decoded = maybe_unserialize( $raw );
			if ( is_array( $decoded ) ) {
				$map = $decoded;
			}
		}
		self::$import_mapping_cache[ $import_id ] = $map;
		return $map;
	}

	/**
	 * @param array  $headers Header list.
	 * @param string $field   Field name.
	 * @return int|false
	 */
	private function header_index( $headers, $field ) {
		if ( ! is_array( $headers ) || '' === trim( (string) $field ) ) {
			return false;
		}
		$reader = new AIImportRowReader();
		$field  = $reader->normalize_header_name( $field );
		foreach ( $headers as $i => $h ) {
			$norm = $reader->normalize_header_name( $h );
			if ( $field === $norm || 0 === strcasecmp( $field, $norm ) ) {
				return (int) $i;
			}
		}
		return false;
	}
}
