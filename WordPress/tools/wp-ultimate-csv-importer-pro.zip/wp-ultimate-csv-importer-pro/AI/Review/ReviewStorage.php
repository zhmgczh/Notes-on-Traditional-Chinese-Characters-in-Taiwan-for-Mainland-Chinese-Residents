<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Review;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persistence for the AI review queue table.
 */
class ReviewStorage {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return string Full table name.
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sm_uci_addon_pro_ai_reviews';
	}

	/**
	 * @param string $import_id Import hash.
	 */
	public function clear_import( $import_id ) {
		global $wpdb;
		$wpdb->delete( self::table_name(), array( 'import_id' => sanitize_key( $import_id ) ), array( '%s' ) );
	}

	/**
	 * @param array<string, mixed> $row Row data.
	 * @return int|false Insert id.
	 */
	public function insert( $row ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$data = array(
			'import_id'       => sanitize_key( $row['import_id'] ?? '' ),
			'row_number'      => (int) ( $row['row_number'] ?? 0 ),
			'field_name'      => sanitize_text_field( $row['field_name'] ?? '' ),
			'feature_type'    => sanitize_key( $row['feature_type'] ?? '' ),
			'original_value'  => isset( $row['original_value'] ) ? wp_kses_post( (string) $row['original_value'] ) : '',
			'suggested_value' => isset( $row['suggested_value'] ) ? wp_kses_post( (string) $row['suggested_value'] ) : '',
			'status'          => sanitize_key( $row['status'] ?? 'pending' ),
			'created_at'      => $now,
			'updated_at'      => $now,
		);
		$result = $wpdb->insert( self::table_name(), $data );
		if ( false === $result ) {
			return false;
		}
		return $wpdb->insert_id ? (int) $wpdb->insert_id : false;
	}

	/**
	 * @param int    $id     Review id.
	 * @param array  $data   Fields to update.
	 * @return bool
	 */
	public function update( $id, $data ) {
		global $wpdb;
		$allowed = array( 'suggested_value', 'status' );
		$update  = array( 'updated_at' => current_time( 'mysql', true ) );
		foreach ( $allowed as $key ) {
			if ( isset( $data[ $key ] ) ) {
				if ( 'status' === $key ) {
					$update[ $key ] = sanitize_key( $data[ $key ] );
				} else {
					$update[ $key ] = wp_kses_post( (string) $data[ $key ] );
				}
			}
		}
		return false !== $wpdb->update( self::table_name(), $update, array( 'id' => (int) $id ), null, array( '%d' ) );
	}

	/**
	 * @param string $import_id Import hash.
	 * @param array  $args      Query args: status, offset, limit, feature_type.
	 * @return array<int, object>
	 */
	public function get_reviews( $import_id, $args = array() ) {
		global $wpdb;
		$table   = self::table_name();
		$where   = array( 'import_id = %s' );
		$params  = array( sanitize_key( $import_id ) );
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $args['status'] );
		}
		if ( ! empty( $args['feature_type'] ) ) {
			$where[]  = 'feature_type = %s';
			$params[] = sanitize_key( $args['feature_type'] );
		}
		$limit  = isset( $args['limit'] ) ? (int) $args['limit'] : 100;
		$offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;
		$sql    = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY `row_number` ASC, `id` ASC LIMIT %d OFFSET %d';
		$params[] = $limit;
		$params[] = $offset;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
	}

	/**
	 * @param string $import_id Import hash.
	 * @return array<string, int>
	 */
	public function count_by_status( $import_id ) {
		global $wpdb;
		$table = self::table_name();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) AS cnt FROM {$table} WHERE import_id = %s GROUP BY status",
				sanitize_key( $import_id )
			),
			ARRAY_A
		);
		$out = array( 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'edited' => 0, 'total' => 0 );
		foreach ( $rows as $row ) {
			$status = $row['status'] ?? 'pending';
			$cnt    = (int) ( $row['cnt'] ?? 0 );
			if ( isset( $out[ $status ] ) ) {
				$out[ $status ] = $cnt;
			}
			$out['total'] += $cnt;
		}
		return $out;
	}

	/**
	 * Bulk status update for an import.
	 *
	 * @param string $import_id Import hash.
	 * @param string $status    New status.
	 * @param string $only      Only update rows with this current status (optional).
	 * @return int Rows affected.
	 */
	public function bulk_update_status( $import_id, $status, $only = '' ) {
		global $wpdb;
		$table = self::table_name();
		$now   = current_time( 'mysql', true );
		if ( '' !== $only ) {
			return (int) $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET status = %s, updated_at = %s WHERE import_id = %s AND status = %s",
					sanitize_key( $status ),
					$now,
					sanitize_key( $import_id ),
					sanitize_key( $only )
				)
			);
		}
		return (int) $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, updated_at = %s WHERE import_id = %s",
				sanitize_key( $status ),
				$now,
				sanitize_key( $import_id )
			)
		);
	}

	/**
	 * Approved/edited values keyed by row_number and field_name for import application.
	 *
	 * @param string $import_id Import hash.
	 * @return array<int, array<string, string>>
	 */
	public function get_applicable_values( $import_id ) {
		global $wpdb;
		$table = self::table_name();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT `row_number`, field_name, feature_type, suggested_value FROM {$table}
				WHERE import_id = %s AND status IN ('approved','edited')",
				sanitize_key( $import_id )
			),
			ARRAY_A
		);
		$map = array();
		foreach ( $rows as $row ) {
			$rn = (int) $row['row_number'];
			if ( ! isset( $map[ $rn ] ) ) {
				$map[ $rn ] = array();
			}
			$map[ $rn ][ $row['field_name'] ] = array(
				'value'         => (string) $row['suggested_value'],
				'feature_type'  => (string) ( $row['feature_type'] ?? '' ),
			);
		}
		return $map;
	}
}
