<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds structured prompts for AI import features.
 */
class PromptBuilder {

	/**
	 * Category suggestion prompt.
	 *
	 * @param string $content   Source text (title, description, etc.).
	 * @param array  $taxonomy  Taxonomy slug and human label.
	 * @param array  $existing  Optional existing term names for context.
	 * @return string
	 */
	public static function category_suggestions( $content, $taxonomy, $existing = array() ) {
		$label = isset( $taxonomy['label'] ) ? $taxonomy['label'] : $taxonomy['name'];
		$terms = ! empty( $existing ) ? implode( ', ', array_slice( $existing, 0, 50 ) ) : 'none provided';
		return sprintf(
			"You are a WordPress content categorization assistant.\n" .
			"Given the content below, suggest up to 5 most appropriate %s terms.\n" .
			"Existing site terms (optional reference): %s\n\n" .
			"Content:\n%s\n\n" .
			"Return ONLY a JSON array of strings, e.g. [\"Electronics\",\"Smartphones\"]. No explanation.",
			$label,
			$terms,
			$content
		);
	}

	/**
	 * Taxonomy tag generation prompt.
	 *
	 * @param string $content Source text.
	 * @return string
	 */
	public static function taxonomy_tags( $content ) {
		return sprintf(
			"Generate 5-12 relevant lowercase tags for this content. Use single words or short hyphenated phrases.\n\n" .
			"Content:\n%s\n\n" .
			"Return ONLY a JSON array of tag strings. No explanation.",
			$content
		);
	}

	/**
	 * SEO title prompt.
	 *
	 * @param string $title   Primary title or product name.
	 * @param string $context Extra context (description excerpt).
	 * @return string
	 */
	public static function seo_title( $title, $context = '' ) {
		$extra = $context ? "\nContext:\n{$context}" : '';
		return sprintf(
			"Write one SEO-friendly page title (50-60 characters ideal) for:\n%s%s\n\n" .
			"Return ONLY the title text. No quotes or explanation.",
			$title,
			$extra
		);
	}

	/**
	 * Meta description prompt.
	 *
	 * @param string $content Source content.
	 * @param int    $limit   Character limit.
	 * @return string
	 */
	public static function meta_description( $content, $limit = 160 ) {
		return sprintf(
			"Write one SEO meta description (max %d characters) for:\n%s\n\n" .
			"Return ONLY the description. No quotes or explanation.",
			$limit,
			$content
		);
	}
}
