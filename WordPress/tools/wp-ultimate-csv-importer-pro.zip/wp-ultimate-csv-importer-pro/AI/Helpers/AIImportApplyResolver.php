<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves AI review field keys to mapped CSV column headers for import-time apply.
 */
class AIImportApplyResolver {

	/** @var array<string, mixed> */
	private $map;

	/**
	 * @param array<string, mixed> $map Serialized import mapping (CORE, TERMS, YOASTSEO, …).
	 */
	public function __construct( $map ) {
		$this->map = is_array( $map ) ? $map : array();
	}

	/**
	 * @param string $field_name   Stored review field (WP / mapping key).
	 * @param string $feature_type category, taxonomy, seo_title, meta_description, translation.
	 * @return string CSV header token, or empty if not mapped.
	 */
	public function resolve_csv_header( $field_name, $feature_type = '' ) {
		$candidates     = $this->field_candidates( $field_name, $feature_type );
		$sections_first = $this->sections_for_feature( $feature_type );

		foreach ( $sections_first as $section ) {
			$header = $this->lookup_in_section( $section, $candidates );
			if ( '' !== $header ) {
				return $header;
			}
		}

		foreach ( array_keys( $this->map ) as $section ) {
			if ( in_array( $section, $sections_first, true ) ) {
				continue;
			}
			$header = $this->lookup_in_section( $section, $candidates );
			if ( '' !== $header ) {
				return $header;
			}
		}

		return '';
	}

	/**
	 * @param string $field_name   Field key.
	 * @param string $feature_type Feature type.
	 * @return array<int, string>
	 */
	private function field_candidates( $field_name, $feature_type ) {
		$field_name = trim( (string) $field_name );
		$static     = array(
			'category'             => array( 'post_category', 'product_category' ),
			'product_cat'          => array( 'product_category' ),
			'_yoast_wpseo_title'   => array( 'seo_title' ),
			'_yoast_wpseo_metadesc' => array( 'meta_desc' ),
		);
		$out        = array( $field_name );
		if ( isset( $static[ $field_name ] ) ) {
			$out = array_merge( $out, $static[ $field_name ] );
		}
		switch ( $feature_type ) {
			case 'category':
				$out = array_merge( array( 'post_category', 'product_category' ), $out );
				break;
			case 'taxonomy':
				$out = array_merge( array( 'post_tag' ), $out );
				break;
			case 'seo_title':
				$out = array_merge( array( 'seo_title' ), $out );
				break;
			case 'meta_description':
				$out = array_merge( array( 'meta_desc' ), $out );
				break;
		}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	/**
	 * @param string $feature_type Feature type.
	 * @return array<int, string>
	 */
	private function sections_for_feature( $feature_type ) {
		switch ( $feature_type ) {
			case 'category':
			case 'taxonomy':
				return array( 'TERMS', 'CORE' );
			case 'seo_title':
			case 'meta_description':
				return array( 'YOASTSEO', 'CORE' );
			case 'translation':
				return array( 'CORE', 'ECOMMETA', 'CORECUSTFIELDS' );
			default:
				return array( 'CORE', 'TERMS', 'YOASTSEO', 'ECOMMETA', 'CORECUSTFIELDS' );
		}
	}

	/**
	 * @param string       $section    Mapping section.
	 * @param array<int,string> $candidates Field keys to try.
	 * @return string
	 */
	private function lookup_in_section( $section, $candidates ) {
		if ( empty( $this->map[ $section ] ) || ! is_array( $this->map[ $section ] ) ) {
			return '';
		}
		foreach ( $candidates as $key ) {
			if ( empty( $this->map[ $section ][ $key ] ) ) {
				continue;
			}
			$raw = trim( (string) $this->map[ $section ][ $key ] );
			if ( '' === $raw || '--select--' === $raw ) {
				continue;
			}
			$header = $this->extract_csv_header_token( $raw );
			if ( '' !== $header ) {
				return $header;
			}
		}
		return '';
	}

	/**
	 * @param string $mapping_value Mapping cell (column name or formula).
	 * @return string
	 */
	private function extract_csv_header_token( $mapping_value ) {
		$val = $this->strip_bom( trim( (string) $mapping_value ) );
		if ( '' === $val ) {
			return '';
		}
		if ( preg_match( '/^\{([^}]+)\}$/', $val, $m ) ) {
			return $this->strip_bom( trim( $m[1] ) );
		}
		if ( false === strpos( $val, '{' ) && false === strpos( $val, '(' ) ) {
			return $val;
		}
		if ( preg_match( '/\{([^}]+)\}/', $val, $m ) ) {
			return $this->strip_bom( trim( $m[1] ) );
		}
		return $val;
	}

	/**
	 * @param string $text Header or mapping token.
	 * @return string
	 */
	private function strip_bom( $text ) {
		$text = (string) $text;
		if ( '' !== $text && 0 === strpos( $text, "\xEF\xBB\xBF" ) ) {
			$text = substr( $text, 3 );
		}
		return trim( $text );
	}
}
