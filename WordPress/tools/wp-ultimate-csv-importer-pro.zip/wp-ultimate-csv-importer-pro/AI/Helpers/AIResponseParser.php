<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Normalizes AI provider responses into predictable structures.
 */
class AIResponseParser {

	/**
	 * Parse a JSON array from model output.
	 *
	 * @param string $raw Raw model text.
	 * @return array<int, string>
	 */
	public static function parse_string_list( $raw ) {
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return array();
		}
		$trimmed = trim( $raw );
		if ( preg_match( '/\[.*\]/s', $trimmed, $m ) ) {
			$decoded = json_decode( $m[0], true );
			if ( is_array( $decoded ) ) {
				return array_values(
					array_filter(
						array_map(
							static function ( $item ) {
								return is_string( $item ) ? sanitize_text_field( $item ) : '';
							},
							$decoded
						)
					)
				);
			}
		}
		$lines = preg_split( '/[\r\n,]+/', $trimmed );
		$out   = array();
		foreach ( $lines as $line ) {
			$line = trim( $line, " \t\"'-•*0123456789." );
			if ( '' !== $line ) {
				$out[] = sanitize_text_field( $line );
			}
		}
		return array_slice( array_unique( $out ), 0, 20 );
	}

	/**
	 * Single-line text cleanup.
	 *
	 * @param string $raw Raw output.
	 * @return string
	 */
	public static function parse_single_line( $raw ) {
		if ( ! is_string( $raw ) ) {
			return '';
		}
		$text = trim( $raw );
		$text = preg_replace( '/^["\'\x{201C}\x{2018}]|["\'\x{201D}\x{2019}]$/u', '', $text );
		if ( preg_match( '/^\d+\.\s*(.+)$/m', $text, $m ) ) {
			$text = trim( $m[1] );
		}
		return sanitize_text_field( $text );
	}

	/**
	 * Truncate meta description to limit.
	 *
	 * @param string $text  Description.
	 * @param int    $limit Max length.
	 * @return string
	 */
	public static function truncate_description( $text, $limit = 160 ) {
		$text = sanitize_text_field( $text );
		if ( strlen( $text ) <= $limit ) {
			return $text;
		}
		return substr( $text, 0, $limit - 3 ) . '...';
	}
}
