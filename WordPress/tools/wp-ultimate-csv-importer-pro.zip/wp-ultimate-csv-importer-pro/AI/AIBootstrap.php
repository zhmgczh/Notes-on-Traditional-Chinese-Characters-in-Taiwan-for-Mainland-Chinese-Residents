<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro\AI;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Review\ReviewManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads AI import modules and registers import-time filters.
 */
class AIBootstrap {

	private static $booted = false;

	/**
	 * Load PHP classes and wire hooks.
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		$base = dirname( __FILE__ );
		$files = array(
			'/Helpers/AIImportApplyResolver.php',
			'/Helpers/PromptBuilder.php',
			'/Helpers/AIResponseParser.php',
			'/Services/AISettingsService.php',
			'/Services/AIProvider.php',
			'/Services/OpenAIProvider.php',
			'/Services/DeepLProvider.php',
			'/Services/GoogleTranslateProvider.php',
			'/Services/AIImportRowReader.php',
			'/Generators/CategoryGenerator.php',
			'/Generators/TaxonomyGenerator.php',
			'/Generators/SeoTitleGenerator.php',
			'/Generators/MetaDescriptionGenerator.php',
			'/Generators/TranslationGenerator.php',
			'/Review/ReviewStorage.php',
			'/Review/ReviewManager.php',
		);
		foreach ( $files as $file ) {
			require_once $base . $file;
		}

		require_once $base . '/Governance/AIGovernanceBootstrap.php';
		\Smackcoders\UCI\Proaddons\UltimatePro\AI\Governance\AIGovernanceBootstrap::init();

		require_once $base . '/../controllers/AIReviewController.php';

		\Smackcoders\UCI\Proaddons\UltimatePro\AIReviewController::getInstance();

		add_filter( 'sm_uci_pro_import_row_data', array( __CLASS__, 'filter_import_row_data' ), 20, 4 );
		add_action( 'sm_uci_pro_after_import', array( __CLASS__, 'after_import' ), 10, 2 );
	}

	/**
	 * @param array  $row_data     Row values.
	 * @param string $import_id    Import hash (optional until SaveMapping passes it).
	 * @param int    $line_number  Line number.
	 * @param array  $header_array Headers.
	 * @return array
	 */
	public static function filter_import_row_data( $row_data, $import_id = '', $line_number = 0, $header_array = array() ) {
		if ( empty( $import_id ) || empty( $line_number ) ) {
			return $row_data;
		}
		return ReviewManager::getInstance()->apply_to_row( $row_data, $import_id, (int) $line_number, $header_array );
	}

	/**
	 * @param string $import_id Import hash.
	 */
	public static function after_import( $import_id ) {
		ReviewManager::reset_import_cache();
	}
}
