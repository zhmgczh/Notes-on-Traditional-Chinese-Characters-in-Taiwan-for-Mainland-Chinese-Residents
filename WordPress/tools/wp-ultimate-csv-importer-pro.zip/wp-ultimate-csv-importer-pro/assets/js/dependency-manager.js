/**
 * Dependency manager onboarding modal — interactions.
 */
(function ($) {
	'use strict';

	var configs = window.ImporterDependencyConfigs || {};

	function getConfig(configId) {
		if (configs[configId]) {
			return configs[configId];
		}
		return window.ImporterDependencyConfig || null;
	}

	function getModal(configId) {
		return document.getElementById('importer-dependency-modal-' + configId);
	}

	function openModal(configId) {
		var modal = getModal(configId);
		if (!modal) {
			return;
		}
		modal.removeAttribute('hidden');
		document.body.classList.add('importer-dependency-modal-open');
	}

	function closeModal(configId) {
		var modal = getModal(configId);
		if (!modal) {
			return;
		}
		modal.setAttribute('hidden', 'hidden');
		document.body.classList.remove('importer-dependency-modal-open');
	}

	function resetModalState($modal) {
		$modal.find('.importer-dependency-modal__progress').attr('hidden', 'hidden');
		$modal.find('.importer-dependency-modal__consent').attr('hidden', 'hidden');
		$modal.find('.importer-dependency-modal__message').attr('hidden', 'hidden').text('');
		$modal.find('.importer-dependency-modal__error').attr('hidden', 'hidden').html('');
		$modal.find('.importer-dependency-modal__manual').attr('hidden', 'hidden');
		$modal.find('.importer-dependency-modal__primary, .importer-dependency-modal__cancel').show();
		$modal.find('.importer-dependency-modal__steps li').removeClass('is-active is-done');
	}

	function setStep($modal, step) {
		var order = ['checking', 'downloading', 'installing', 'activating', 'completed'];
		var index = order.indexOf(step);

		$modal.find('.importer-dependency-modal__steps li').each(function () {
			var current = $(this).data('step');
			var currentIndex = order.indexOf(current);
			$(this).removeClass('is-active is-done');

			if (currentIndex < index) {
				$(this).addClass('is-done');
			} else if (currentIndex === index) {
				$(this).addClass('is-active');
			}
		});
	}

	function animateInstallProgress($modal) {
		$modal.find('.importer-dependency-modal__progress').removeAttr('hidden');
		var steps = ['checking', 'downloading', 'installing', 'activating', 'completed'];
		var delay = 0;

		steps.forEach(function (step) {
			setTimeout(function () {
				setStep($modal, step);
			}, delay);
			delay += 500;
		});

		return delay;
	}

	function showError($modal, config, payload) {
		var strings = config.strings || {};
		var message = payload.message || strings.installFailed;
		var detail = payload.detail ? '<br><small>' + payload.detail + '</small>' : '';
		var links = '';

		if (payload.manual_url) {
			links += '<br><a href="' + payload.manual_url + '" target="_blank" rel="noopener">' + strings.manualInstallGuide + '</a>';
		}
		if (payload.troubleshoot) {
			links += ' | <a href="' + payload.troubleshoot + '" target="_blank" rel="noopener">' + strings.troubleshooting + '</a>';
		}

		$modal.find('.importer-dependency-modal__error')
			.removeAttr('hidden')
			.html('<strong>' + message + '</strong>' + detail + links);

		$modal.find('.importer-dependency-modal__primary, .importer-dependency-modal__cancel').show();
		$modal.find('.importer-dependency-modal__primary').prop('disabled', false);
		if (payload.manual_url) {
			$modal.find('.importer-dependency-modal__manual')
				.attr('href', payload.manual_url)
				.removeAttr('hidden');
		}
	}

	function showSuccess($modal, message) {
		$modal.find('.importer-dependency-modal__message')
			.removeAttr('hidden')
			.text(message);
	}

	function runAjax($modal, config, actionKey) {
		var strings = config.strings || {};
		var action = config.actions && config.actions[actionKey] ? config.actions[actionKey] : '';

		$modal.find('.importer-dependency-modal__primary').prop('disabled', true);

		var progressDelay = 0;
		if (actionKey === 'install') {
			progressDelay = animateInstallProgress($modal);
		} else {
			setStep($modal, 'activating');
			$modal.find('.importer-dependency-modal__progress').removeAttr('hidden');
		}

		setTimeout(function () {
			$.ajax({
				url: config.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: action,
					nonce: config.nonce
				}
			}).done(function (response) {
				if (!response || !response.success) {
					showError($modal, config, (response && response.data) || { message: strings.installFailed });
					$modal.find('.importer-dependency-modal__primary').prop('disabled', false);
					return;
				}

				setStep($modal, 'completed');
				showSuccess($modal, response.data.message || strings.activateSuccess);

				if (response.data.reload) {
					setTimeout(function () {
						window.location.reload();
					}, 1200);
				}
			}).fail(function (xhr) {
				var payload = (xhr.responseJSON && xhr.responseJSON.data) || { message: strings.networkError };
				showError($modal, config, payload);
				$modal.find('.importer-dependency-modal__primary').prop('disabled', false);
			});
		}, progressDelay);
	}

	function handlePrimaryClick($modal, config) {
		var strings = config.strings || {};
		var scenario = $modal.data('scenario');
		var $consent = $modal.find('.importer-dependency-modal__consent');

		if (scenario === 'install' && $consent.length && $consent.is('[hidden]')) {
			$consent.removeAttr('hidden');
			$modal.find('.importer-dependency-modal__primary').text(strings.confirmInstall);
			$modal.data('consent-shown', true);
			return;
		}

		resetModalState($modal);
		$modal.find('.importer-dependency-modal__primary, .importer-dependency-modal__cancel').hide();

		if (scenario === 'install') {
			runAjax($modal, config, 'install');
		} else {
			runAjax($modal, config, 'activate');
		}
	}

	function bindModal($modal) {
		var configId = $modal.data('config-id');
		var config = getConfig(configId);

		if (!config) {
			return;
		}

		$modal.on('click', '.importer-dependency-modal__close, .importer-dependency-modal__cancel, .importer-dependency-modal__overlay', function () {
			closeModal(configId);
		});

		$modal.on('click', '.importer-dependency-modal__primary', function () {
			handlePrimaryClick($modal, config);
		});

		if ($modal.data('auto-open') === 1 || $modal.data('auto-open') === '1') {
			openModal(configId);
		}
	}

	window.ImporterDependencyManager = {
		openModal: openModal,
		closeModal: closeModal
	};

	$(function () {
		$('.importer-dependency-modal').each(function () {
			bindModal($(this));
		});

		$(document).on('click', '.importer-dependency-open-modal', function (event) {
			event.preventDefault();
			var configId = $(this).data('config-id');
			openModal(configId);
		});

		$(document).on('click', '.importer-dependency-notice .notice-dismiss', function () {
			var $notice = $(this).closest('.importer-dependency-notice');
			var configId = $notice.data('config-id');
			var config = getConfig(configId);

			if (!config) {
				return;
			}

			$.post(config.ajaxUrl, {
				action: config.actions.dismiss,
				nonce: $notice.data('nonce') || config.nonce
			});
		});
	});
})(jQuery);
