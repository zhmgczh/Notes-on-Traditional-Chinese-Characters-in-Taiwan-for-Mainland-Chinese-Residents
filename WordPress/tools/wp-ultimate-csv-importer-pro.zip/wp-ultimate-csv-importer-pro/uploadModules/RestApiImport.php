<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 ******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * REST API import bootstrap — AJAX test + prepare (CSV materialize + file_events row).
 * M4: `{page}`, `{limit}`, `{offset}` in URL or POST body; prepare loops pages until empty or caps.
 */
class RestApiImport {

	private static $instance = null;

	public static function getInstance() {
		if (self::$instance === null) {
			self::$instance = new RestApiImport();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action('wp_ajax_uci_rest_api_m1_test', array($this, 'ajax_m1_test'));
		add_action('wp_ajax_uci_rest_api_m1_prepare', array($this, 'ajax_m1_prepare'));
		add_action('wp_ajax_uci_rest_api_load_form_prefs', array($this, 'ajax_load_rest_form_prefs'));
		/** M3: parity hook after chunked import completes (fires with sm_uci_pro_after_import). */
		add_action('sm_uci_pro_after_import', array(__CLASS__, 'maybe_fire_uci_after_api_import'), 10, 2);
	}

	/**
	 * Synthetic REST CSV rows use file_name prefix rest-import-* (see ajax_m1_prepare).
	 * Fire uci_after_api_import once import_detail_log reaches Completed and core fires after-import.
	 *
	 * @param string            $hash_key      Session hash.
	 * @param object|array|null $import_object Optional stats row from chunked completion path.
	 */
	public static function maybe_fire_uci_after_api_import($hash_key, $import_object = null) {
		unset($import_object);

		if (! is_string($hash_key) || $hash_key === '') {
			return;
		}

		global $wpdb;
		$table     = $wpdb->prefix . 'smackcsv_file_events';
		$file_name = $wpdb->get_var($wpdb->prepare("SELECT file_name FROM {$table} WHERE hash_key = %s ORDER BY id DESC LIMIT 1", $hash_key));

		if (! is_string($file_name) || $file_name === '') {
			return;
		}

		if (strpos($file_name, 'rest-import-') !== 0) {
			return;
		}

		/**
		 * Fires after a REST API–prepared import session completes successfully.
		 *
		 * @param string $hash_key Import session hash_key.
		 */
		do_action('uci_after_api_import', $hash_key);
	}

	/**
	 * Capability required for REST import AJAX (M1).
	 *
	 * @return string
	 */
	private function required_capability() {
		/**
		 * Filter capability required for REST API import admin AJAX.
		 *
		 * @param string $cap Capability name.
		 */
		return apply_filters('uci_rest_import_capability', 'manage_options');
	}

	/**
	 * Fetch remote payload and return preview rows / headers only (no DB write).
	 */
	public function ajax_m1_test() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

		if (! current_user_can($this->required_capability())) {
			wp_send_json_error(array('message' => __('Unauthorized.', 'wp-ultimate-csv-importer')));
		}

		$url = isset($_POST['url']) ? wp_unslash($_POST['url']) : '';
		$url = is_string($url) ? trim($url) : '';

		if (! $this->is_valid_http_url($url)) {
			wp_send_json_error(array('message' => __('Invalid HTTP(S) URL.', 'wp-ultimate-csv-importer')));
		}

		$method       = isset($_POST['method']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['method']))) : 'GET';
		$records_path = isset($_POST['records_path']) ? sanitize_text_field(wp_unslash($_POST['records_path'])) : '';
		$body_in      = isset($_POST['body']) ? wp_unslash($_POST['body']) : '';
		$body_in      = is_string($body_in) ? $body_in : '';

		$headers = $this->collect_headers_from_post();

		$page_size = $this->sanitize_requested_page_size();
		list($resolved_url, $resolved_body) = $this->substitute_templates_for_page(
			$url,
			$body_in,
			$method,
			1,
			$page_size
		);

		if (! $this->is_valid_http_url($resolved_url)) {
			wp_send_json_error(array('message' => __('Resolved URL became invalid — check placeholders.', 'wp-ultimate-csv-importer')));
		}

		$result = ApiImportClient::request(
			$resolved_url,
			array(
				'method'  => $method === 'POST' ? 'POST' : 'GET',
				'headers' => $headers,
				'body'    => $method === 'POST' ? $resolved_body : null,
				'timeout' => 60,
			),
			array(
				'ajax' => 'uci_rest_api_m1_test',
			)
		);

		if (! $result['success']) {
			wp_send_json_error(
				array(
					'message'      => $result['error'] !== '' ? $result['error'] : __('Request failed.', 'wp-ultimate-csv-importer'),
					'status_code'  => $result['status_code'],
				)
			);
		}

		$body_raw = $result['body'];
		if (strlen($body_raw) > 5 * MB_IN_BYTES) {
			wp_send_json_error(array('message' => __('Response too large for preview.', 'wp-ultimate-csv-importer')));
		}

		$content_type = '';
		if (! empty($result['headers'])) {
			if (is_object($result['headers']) && method_exists($result['headers'], 'offsetGet')) {
				$content_type = (string) $result['headers']->offsetGet('content-type');
			} elseif (is_array($result['headers']) && isset($result['headers']['content-type'])) {
				$content_type = is_array($result['headers']['content-type'])
					? (string) reset($result['headers']['content-type'])
					: (string) $result['headers']['content-type'];
			}
		}

		$decoded = ApiImportNormalizer::decode_body(
			$body_raw,
			$content_type,
			array(
				'ajax' => 'uci_rest_api_m1_test',
				'host' => wp_parse_url($resolved_url, PHP_URL_HOST),
			)
		);

		if (is_wp_error($decoded)) {
			wp_send_json_error(array('message' => $decoded->get_error_message()));
		}

		$records = ApiImportNormalizer::extract_records($decoded, $records_path);
		$table   = ApiImportNormalizer::records_to_csv_tables($records);
		$headers = $table['headers'];
		$rows    = $table['rows'];
		/**
		 * How many CSV rows returned in AJAX preview UI (full count remains in records_count).
		 *
		 * @param int $default_rows Default preview cap (keep UI fast with wide sheets).
		 * @param array $context ajax, host fragment.
		 */
		$preview_limit = max( 1, min( 50, (int) apply_filters( 'uci_rest_api_preview_row_limit', 5, array(
			'ajax' => 'uci_rest_api_m1_test',
			'host' => wp_parse_url( $resolved_url, PHP_URL_HOST ),
		) ) ) );
		$preview = array_slice($rows, 0, $preview_limit);

		/** Flat payload matches legacy upload AJAX handlers (desktop/URL). */
		wp_send_json(
			array(
				'success'               => true,
				'status_code'           => $result['status_code'],
				'records_count'          => count($records),
				'headers'                => $headers,
				'preview_rows'          => $preview,
				/** Raw HTTP response body for JSON preview tab (same cap as decode — UTF-8 safe). */
				'preview_raw_body'       => wp_check_invalid_utf8($body_raw, true),
				'rest_placeholder_mode' => $this->pagination_template_enabled($url, $body_in, $method),
			)
		);
	}

	/**
	 * Fetch remote payload, normalize to CSV, register smackcsv_file_events row (M1).
	 */
	public function ajax_m1_prepare() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

		if (! current_user_can($this->required_capability())) {
			wp_send_json_error(array('message' => __('Unauthorized.', 'wp-ultimate-csv-importer')));
		}

		global $wpdb;

		$url = isset($_POST['url']) ? wp_unslash($_POST['url']) : '';
		$url = is_string($url) ? trim($url) : '';

		if (! $this->is_valid_http_url($url)) {
			wp_send_json_error(array('message' => __('Invalid HTTP(S) URL.', 'wp-ultimate-csv-importer')));
		}

		$method       = isset($_POST['method']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['method']))) : 'GET';
		$records_path = isset($_POST['records_path']) ? sanitize_text_field(wp_unslash($_POST['records_path'])) : '';
		$body_in      = isset($_POST['body']) ? wp_unslash($_POST['body']) : '';
		$body_in      = is_string($body_in) ? $body_in : '';

		$headers = $this->collect_headers_from_post();

		$page_size   = $this->sanitize_requested_page_size();
		$paged_fetch = $this->pagination_template_enabled($url, $body_in, $method);
		/**
		 * Max HTTP pages fetched during one prepare call (pagination templates only).
		 *
		 * @param int $max_pages Default ceiling.
		 * @param array $context   host, ajax context.
		 */
		$max_pages = max( 1, (int) apply_filters( 'uci_rest_import_max_fetch_pages', 50, array( 'host' => wp_parse_url( $url, PHP_URL_HOST ), 'ajax' => 'uci_rest_api_m1_prepare' ) ) );
		if ( ! $paged_fetch ) {
			$max_pages = 1;
		}

		/**
		 * Hard cap on total rows merged across all pages.
		 *
		 * @param int   $cap     Default max rows per prepare.
		 * @param array $context Filters context.
		 */
		$row_cap = max( 1, (int) apply_filters( 'uci_rest_import_max_total_records', 50000, array( 'host' => wp_parse_url( $url, PHP_URL_HOST ), 'ajax' => 'uci_rest_api_m1_prepare' ) ) );

		$records             = array();
		$pages_fetched_run   = 0;
		$row_cap_hit_stop    = false;

		for ($page_no = 1; $page_no <= $max_pages; $page_no++) {
			list( $resolved_url, $resolved_body ) = $this->substitute_templates_for_page(
				$url,
				$body_in,
				$method,
				$page_no,
				$page_size
			);

			if (! $this->is_valid_http_url($resolved_url)) {
				wp_send_json_error(array('message' => __('Resolved URL became invalid — check placeholders.', 'wp-ultimate-csv-importer')));
			}

			$result = ApiImportClient::request(
				$resolved_url,
				array(
					'method'  => $method === 'POST' ? 'POST' : 'GET',
					'headers' => $headers,
					'body'    => $method === 'POST' ? $resolved_body : null,
					'timeout' => 120,
				),
				array(
					'ajax'       => 'uci_rest_api_m1_prepare',
					'rest_page'  => $page_no,
				)
			);

			if (! $result['success']) {
				wp_send_json_error(
					array(
						'message'      => $result['error'] !== '' ? $result['error'] : __('Request failed.', 'wp-ultimate-csv-importer'),
						'status_code'  => $result['status_code'],
					)
				);
			}

			$body_raw = $result['body'];
			if (strlen($body_raw) > 20 * MB_IN_BYTES) {
				wp_send_json_error(array('message' => __('Response too large for import preparation.', 'wp-ultimate-csv-importer')));
			}

			$content_type = '';
			if (! empty($result['headers'])) {
				if (is_object($result['headers']) && method_exists($result['headers'], 'offsetGet')) {
					$content_type = (string) $result['headers']->offsetGet('content-type');
				} elseif (is_array($result['headers']) && isset($result['headers']['content-type'])) {
					$content_type = is_array($result['headers']['content-type'])
						? (string) reset($result['headers']['content-type'])
						: (string) $result['headers']['content-type'];
				}
			}

			$decoded = ApiImportNormalizer::decode_body(
				$body_raw,
				$content_type,
				array(
					'ajax' => 'uci_rest_api_m1_prepare',
					'host' => wp_parse_url($resolved_url, PHP_URL_HOST),
				)
			);

			if (is_wp_error($decoded)) {
				wp_send_json_error(array('message' => $decoded->get_error_message()));
			}

			$page_records = ApiImportNormalizer::extract_records($decoded, $records_path);

			if ($page_records === array()) {
				break;
			}

			foreach ($page_records as $row) {
				$records[] = $row;
				if (count($records) >= $row_cap) {
					$row_cap_hit_stop = true;
					break 2;
				}
			}

			$pages_fetched_run++;

			if (! $paged_fetch) {
				break;
			}
		}

		if ($records === array()) {
			wp_send_json_error(array('message' => __('No records found in response.', 'wp-ultimate-csv-importer')));
		}

		$table        = ApiImportNormalizer::records_to_csv_tables($records);
		$csv_headers  = $table['headers'];
		$csv_rows     = $table['rows'];

		$core          = UltimatePro::getInstance();
		$upload_base   = $core->create_upload_dir();
		if (! $upload_base) {
			wp_send_json_error(array('message' => __('Upload directory unavailable.', 'wp-ultimate-csv-importer')));
		}

		$hash_in = isset($_POST['HashKey']) ? sanitize_key(wp_unslash($_POST['HashKey'])) : '';
		$hash_key = $hash_in !== ''
			? $hash_in
			: $core->convert_string2hash_key('rest-api-import-' . $url . microtime(true));

		if ($hash_in !== '') {
			$busy = $this->hash_has_active_import($hash_key);
			if ($busy) {
				wp_send_json_error(
					array(
						'message' => __('This import session is busy. Stop the current run or use a new session.', 'wp-ultimate-csv-importer'),
					)
				);
			}
		}

		$file_table = $wpdb->prefix . 'smackcsv_file_events';
		$file_name  = 'rest-import-' . substr($hash_key, 0, 12) . '.csv';

		$upload_dir_path = $upload_base . $hash_key;
		if (! is_dir($upload_dir_path)) {
			wp_mkdir_p($upload_dir_path);
		}
		if (! is_dir($upload_dir_path)) {
			wp_send_json_error(array('message' => __('Could not create hash directory.', 'wp-ultimate-csv-importer')));
		}
		// Match chmod pattern used by Desktop / URL upload flows.
		chmod($upload_dir_path, 0777);

		$file_path = $upload_base . $hash_key . '/' . $hash_key;

		$write = ApiImportNormalizer::write_csv_file($file_path, $csv_headers, $csv_rows);
		if (is_wp_error($write)) {
			wp_send_json_error(array('message' => $write->get_error_message()));
		}

		// Replace existing row for same hash or insert fresh (idempotent prepare on same hash).
		$existing_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$file_table} WHERE hash_key = %s ORDER BY id DESC LIMIT 1", $hash_key));

		if ($existing_id > 0) {
			$wpdb->update(
				$file_table,
				array(
					'file_name' => $file_name,
					'status'    => 'Downloading',
					'lock'      => true,
				),
				array('id' => $existing_id),
				array('%s', '%s', '%d'),
				array('%d')
			);
			$lastid = $existing_id;
		} else {
			$ins = $wpdb->insert(
				$file_table,
				array(
					'file_name' => $file_name,
					'hash_key'  => $hash_key,
					'status'    => 'Downloading',
					'lock'      => true,
				),
				array('%s', '%s', '%s', '%d')
			);
			$lastid = (int) $wpdb->insert_id;
			if ($ins === false || $lastid <= 0) {
				@unlink($file_path);
				wp_send_json_error(array('message' => __('Could not create import event.', 'wp-ultimate-csv-importer')));
			}
		}

		$validate = ValidateFile::getInstance();
		$validate_result = $validate->file_validation($file_path, 'csv');

		if ($validate_result !== 'yes') {
			$wpdb->update($file_table, array('status' => 'Download_Failed', 'lock' => false), array('id' => $lastid));
			@unlink($file_path);
			wp_send_json_error(
				array(
					'message' => is_string($validate_result)
						? $validate_result
						: __('Prepared CSV failed validation.', 'wp-ultimate-csv-importer'),
				)
			);
		}

		$wpdb->update($file_table, array('status' => 'Downloaded', 'lock' => false), array('id' => $lastid));

		/** After CSV write + validation; before ExtensionHandler refreshes totals and delimiter detection. */
		do_action(
			'uci_before_api_import',
			array(
				'url_host'           => wp_parse_url($url, PHP_URL_HOST),
				'records_count'      => count($records),
				'rest_pages_fetched' => $pages_fetched_run,
				'route'              => $pages_fetched_run > 1 ? 'm1_prepare_paged' : 'm1_prepare',
			),
			$hash_key
		);

		$get_import_meta = ValidateFile::getInstance()->import_record_function($hash_key, $file_name);

		$delimiter = DesktopUpload::detect_csv_delimiter($file_path);
		update_option('smack_csv_delimiter_' . $hash_key, $delimiter);

		$total_rows_db    = $wpdb->get_var($wpdb->prepare("SELECT total_rows FROM {$file_table} WHERE hash_key = %s LIMIT 1", $hash_key));
		$file_size_bytes  = filesize($file_path);
		$filesize_human   = $validate->formatSizeUnits($file_size_bytes ? $file_size_bytes : 0);

		$this->persist_rest_import_form_prefs();

		wp_send_json(
			array(
				'success'       => true,
				'message'       => __('REST payload prepared as CSV.', 'wp-ultimate-csv-importer'),
				'hashkey'       => $hash_key,
				'filename'      => $file_name,
				'file_type'     => 'csv',
				'file_size'     => $filesize_human,
				'total_rows'    => $total_rows_db,
				'records'                => count($records),
				'rest_pages_fetched'      => $pages_fetched_run,
				'rest_row_cap_truncated'  => $row_cap_hit_stop,
				'columns'                 => $csv_headers,
				'selectedtype'  => $get_import_meta['selected type'],
				'posttype'         => $get_import_meta['Post Type'],
				'taxonomy'         => $get_import_meta['Taxonomy'],
				'posttype_labels'  => $get_import_meta['Post Type Labels'] ?? array(),
				'taxonomy_labels'  => $get_import_meta['Taxonomy Labels'] ?? array(),
			)
		);
	}

	/**
	 * Page size hint for `{limit}` / `{offset}` placeholders (pagination or single-shot).
	 */
	private function sanitize_requested_page_size() {
		$raw = isset($_POST['uci_rest_page_size']) ? (int) $_POST['uci_rest_page_size'] : 0;
		if ($raw < 1) {
			$raw = 100;
		}
		$default_top = 500;
		/**
		 * Filters max allowed REST import page-size placeholder value.
		 *
		 * @param int $hard_top Default ceiling (500).
		 */
		$hard_top = max(1, (int) apply_filters('uci_rest_import_page_size_hard_ceiling', $default_top, array()));

		return max(1, min($hard_top, $raw));
	}

	/**
	 * True when `{page}` appears where it can drive sequential fetches on prepare.
	 */
	private function pagination_template_enabled($url, $body, $method) {
		$url  = is_string($url) ? $url : '';
		$body = is_string($body) ? $body : '';
		$mu   = strtoupper((string) $method);
		return strpos($url, '{page}') !== false || ($mu === 'POST' && strpos($body, '{page}') !== false);
	}

	/**
	 * Replace `{page}`, `{limit}`, `{offset}` placeholders.
	 *
	 * @param string $template Original URL string or POST body snippet.
	 * @param int    $page     1-indexed page.
	 * @param int    $limit    Page-size hint.
	 */
	private function substitute_pagination_placeholders_string($template, $page, $limit) {
		if (! is_string($template)) {
			return '';
		}
		$page       = max(1, (int) $page);
		$limit      = max(1, (int) $limit);
		$page_index = max(1, $page);
		$offset     = ($page_index - 1) * $limit;

		return str_replace(
			array('{page}', '{limit}', '{offset}'),
			array((string) $page_index, (string) $limit, (string) $offset),
			$template
		);
	}

	/**
	 * Resolved URL and body for one HTTP hop.
	 *
	 * @return array{0:string,1:string}
	 */
	private function substitute_templates_for_page($url, $body, $method, $page, $page_size) {
		$mu           = strtoupper((string) $method);
		$resolved_url = $this->substitute_pagination_placeholders_string(is_string($url) ? $url : '', $page, $page_size);
		if ($mu === 'POST') {
			$resolved_body = $this->substitute_pagination_placeholders_string(is_string($body) ? $body : '', $page, $page_size);
		} else {
			$resolved_body = '';
		}
		return array($resolved_url, $resolved_body);
	}

	/**
	 * Basic concurrency guard: same hash currently importing / downloading with lock.
	 *
	 * @param string $hash_key Hash key.
	 */
	private function hash_has_active_import($hash_key) {
		global $wpdb;
		$file_table = $wpdb->prefix . 'smackcsv_file_events';
		$row        = $wpdb->get_row($wpdb->prepare("SELECT status, lock FROM {$file_table} WHERE hash_key = %s ORDER BY id DESC LIMIT 1", $hash_key));
		if (! $row) {
			return false;
		}
		return ! empty($row->lock);
	}

	/**
	 * @param string $url URL.
	 */
	private function is_valid_http_url($url) {
		if (! is_string($url) || $url === '') {
			return false;
		}
		$p = wp_parse_url($url);
		if ($p === false || empty($p['scheme']) || empty($p['host'])) {
			return false;
		}
		return in_array(strtolower($p['scheme']), array('http', 'https'), true);
	}

	/**
	 * WordPress option key for last REST import form (serialized array).
	 *
	 * @return string
	 */
	private function option_key_rest_import_form() {
		return 'sm_uci_pro_rest_api_import_form_v1';
	}

	/**
	 * Snapshot REST UI fields from POST (Continue / prepare — excludes preview-only fields).
	 *
	 * @return array<string,string>
	 */
	private function snapshot_rest_form_from_post() {
		$method = isset($_POST['method']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['method']))) : 'GET';
		if (! in_array($method, array('GET', 'POST'), true)) {
			$method = 'GET';
		}

		$url = isset($_POST['url']) ? trim(wp_unslash($_POST['url'])) : '';
		$url = is_string($url) ? $url : '';

		$records_path = isset($_POST['records_path']) ? sanitize_text_field(wp_unslash($_POST['records_path'])) : '';

		$page_raw = isset($_POST['uci_rest_page_size']) ? wp_unslash($_POST['uci_rest_page_size']) : '';
		$page_raw = is_string($page_raw) ? trim($page_raw) : '';

		$body_in = isset($_POST['body']) ? wp_unslash($_POST['body']) : '';
		$body_in = is_string($body_in) ? $body_in : '';

		$bearer = isset($_POST['bearer_token']) ? trim(wp_unslash($_POST['bearer_token'])) : '';
		$bearer = is_string($bearer) ? $bearer : '';

		$api_header = isset($_POST['api_key_header']) ? sanitize_text_field(wp_unslash($_POST['api_key_header'])) : '';

		$api_value = isset($_POST['api_key_value']) ? wp_unslash($_POST['api_key_value']) : '';
		$api_value = is_string($api_value) ? $api_value : '';

		$extra_headers = isset($_POST['uci_rest_headers']) ? wp_unslash($_POST['uci_rest_headers']) : '[]';
		$extra_headers = is_string($extra_headers) ? trim($extra_headers) : '[]';
		if ($extra_headers === '') {
			$extra_headers = '[]';
		}
		json_decode($extra_headers, true);
		if (JSON_ERROR_NONE !== json_last_error()) {
			$extra_headers = '[]';
		}

		return array(
			'url'                 => $url,
			'method'              => $method,
			'records_path'        => $records_path,
			'uci_rest_page_size'  => $page_raw,
			'body'                => 'POST' === $method ? $body_in : '',
			'bearer_token'        => $bearer,
			'api_key_header'      => $api_header,
			'api_key_value'       => $api_value,
			'uci_rest_headers'    => $extra_headers,
		);
	}

	/**
	 * Persist last-used REST form after a successful Continue (prepare).
	 */
	private function persist_rest_import_form_prefs() {
		$snapshot = $this->snapshot_rest_form_from_post();
		/**
		 * Filter REST form snapshot before saving to options (e.g. strip secrets).
		 *
		 * @param array<string,string> $snapshot Keys match POST fields above.
		 */
		$snapshot = apply_filters('uci_rest_import_persist_form_prefs', $snapshot);
		if (! is_array($snapshot)) {
			return;
		}
		update_option($this->option_key_rest_import_form(), $snapshot, false);
	}

	/**
	 * AJAX: load saved REST form for Import from REST API tab.
	 */
	public function ajax_load_rest_form_prefs() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

		if (! current_user_can($this->required_capability())) {
			wp_send_json_error(array('message' => __('Unauthorized.', 'wp-ultimate-csv-importer')));
		}

		$stored = get_option($this->option_key_rest_import_form(), array());
		if (! is_array($stored)) {
			$stored = array();
		}

		wp_send_json_success(array('prefs' => $stored));
	}

	/**
	 * Merge manual headers + Bearer / API key fields from POST (secrets never logged here).
	 *
	 * @return array<string,string>
	 */
	private function collect_headers_from_post() {
		$out = array();

		$raw = isset($_POST['uci_rest_headers']) ? wp_unslash($_POST['uci_rest_headers']) : '';
		if (is_string($raw) && $raw !== '') {
			$decoded = json_decode($raw, true);
			if (is_array($decoded)) {
				foreach ($decoded as $pair) {
					if (! is_array($pair)) {
						continue;
					}
					$name = isset($pair['name']) ? sanitize_text_field($pair['name']) : '';
					$val  = isset($pair['value']) ? $pair['value'] : '';
					if ($name === '') {
						continue;
					}
					if (! is_string($val)) {
						$val = '';
					}
					$out[ $name ] = $val;
				}
			}
		}

		$bearer = isset($_POST['bearer_token']) ? trim(wp_unslash($_POST['bearer_token'])) : '';
		if ($bearer !== '') {
			$out['Authorization'] = 'Bearer ' . $bearer;
		}

		$api_header = isset($_POST['api_key_header']) ? sanitize_text_field(wp_unslash($_POST['api_key_header'])) : '';
		$api_value  = isset($_POST['api_key_value']) ? wp_unslash($_POST['api_key_value']) : '';
		if ($api_header !== '') {
			$out[ $api_header ] = is_string($api_value) ? $api_value : '';
		}

		$auth_override = isset($_POST['authorization']) ? wp_unslash($_POST['authorization']) : '';
		if (is_string($auth_override) && $auth_override !== '') {
			$out['Authorization'] = trim($auth_override);
		}

		return $out;
	}
}

/*
 * Bootstrap AJAX handlers without modifying wp-ultimate-csv-importer-pro.php (UltimatePro).
 * If RestApiImport::getInstance() is added inside UltimatePro::getInstance(), remove this hook to avoid duplicate registrations.
 */
add_action(
	'plugins_loaded',
	static function () {
		RestApiImport::getInstance();
	},
	15
);
