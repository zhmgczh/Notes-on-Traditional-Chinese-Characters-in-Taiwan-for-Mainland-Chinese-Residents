<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 ******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * REST API import — outbound HTTP via WordPress HTTP API (M1).
 */
class ApiImportClient {

	/**
	 * Execute a remote request.
	 *
	 * @param string $url Full URL (http/https).
	 * @param array  $args {
	 *     @type string               $method    GET or POST.
	 *     @type array<string,string> $headers   Header name => value.
	 *     @type string|null          $body      Raw body for POST.
	 *     @type int                  $timeout   Seconds.
	 *     @type bool                 $sslverify Whether to verify SSL.
	 * }
	 * @param array $filter_context Passed to {@see apply_filters()} `uci_api_request_args` (no secrets).
	 * @return array{success:bool,status_code:int,body:string,headers:mixed,error:string,response?:mixed}
	 */
	public static function request($url, array $args = [], array $filter_context = []) {
		$url = is_string($url) ? trim($url) : '';
		if ($url === '') {
			return array(
				'success'      => false,
				'status_code'  => 0,
				'body'         => '',
				'headers'      => array(),
				'error'        => __('Missing URL.', 'wp-ultimate-csv-importer'),
			);
		}

		$defaults = array(
			'method'      => 'GET',
			'timeout'     => 60,
			'redirection' => 5,
			'sslverify'   => true,
			'headers'     => array(),
			'body'        => null,
		);
		$args = wp_parse_args($args, $defaults);

		$method = strtoupper((string) $args['method']);
		if (!in_array($method, array('GET', 'POST'), true)) {
			$method = 'GET';
		}

		$headers = is_array($args['headers']) ? $args['headers'] : array();

		$request = array(
			'method'      => $method,
			'timeout'     => max(5, min(300, (int) $args['timeout'])),
			'redirection' => max(0, min(10, (int) $args['redirection'])),
			'sslverify'   => (bool) $args['sslverify'],
			'headers'     => $headers,
		);

		if ($method === 'POST' && $args['body'] !== null && $args['body'] !== '') {
			$request['body'] = $args['body'];
		}

		$host = wp_parse_url($url, PHP_URL_HOST);
		if (!is_string($host)) {
			$host = '';
		}

		$filter_context = array_merge(
			array(
				'source' => 'uci_rest_import',
				'host'   => $host,
				'method' => $method,
			),
			$filter_context
		);

		/**
		 * Filter outbound REST import HTTP arguments before wp_remote_request().
		 *
		 * @param array $request Request args for wp_remote_request().
		 * @param array $filter_context Context without secrets.
		 */
		$request = apply_filters('uci_api_request_args', $request, $filter_context);

		$response = wp_remote_request($url, $request);

		if (is_wp_error($response)) {
			return array(
				'success'      => false,
				'status_code'  => 0,
				'body'         => '',
				'headers'      => array(),
				'error'        => $response->get_error_message(),
				'response'     => $response,
			);
		}

		$code = (int) wp_remote_retrieve_response_code($response);
		$body = (string) wp_remote_retrieve_body($response);
		$resp_headers = wp_remote_retrieve_headers($response);

		return array(
			'success'      => $code >= 200 && $code < 300,
			'status_code'  => $code,
			'body'         => $body,
			'headers'      => $resp_headers ? $resp_headers : array(),
			'error'        => ($code >= 200 && $code < 300) ? '' : sprintf(
				/* translators: %d HTTP status code */
				__('HTTP error (%d).', 'wp-ultimate-csv-importer'),
				$code
			),
			'response'     => $response,
		);
	}
}
