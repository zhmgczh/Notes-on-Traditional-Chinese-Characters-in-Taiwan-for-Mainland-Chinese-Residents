<?php
/**
 * Resilient HTTP layer for Google OAuth and Google Sheets API (wp_remote_* only).
 *
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

class GoogleSheetsHttpTransport {

	const MAX_ATTEMPTS = 3;
	const DEFAULT_TIMEOUT = 30;
	const CONNECTIVITY_TIMEOUT = 5;
	const CONNECTIVITY_URL = 'https://www.google.com';

	/**
	 * GET with connectivity check, retries, logging. Returns same types as wp_remote_get().
	 *
	 * @param string $url
	 * @param array  $args
	 * @return array|\WP_Error
	 */
	public static function remote_get($url, $args = array()) {
		$connectivity = self::assert_connectivity();
		if (is_wp_error($connectivity)) {
			return $connectivity;
		}
		return self::execute_with_retries('GET', $url, $args, function ($u, $a) {
			return wp_remote_get($u, $a);
		});
	}

	/**
	 * POST with connectivity check, retries, logging. Returns same types as wp_remote_post().
	 *
	 * @param string $url
	 * @param array  $args
	 * @return array|\WP_Error
	 */
	public static function remote_post($url, $args = array()) {
		$connectivity = self::assert_connectivity();
		if (is_wp_error($connectivity)) {
			return $connectivity;
		}
		return self::execute_with_retries('POST', $url, $args, function ($u, $a) {
			return wp_remote_post($u, $a);
		});
	}

	/**
	 * Pre-flight connectivity check for manual and scheduled imports.
	 *
	 * @return true|\WP_Error
	 */
	public static function preflight_connectivity() {
		return self::assert_connectivity();
	}

	/**
	 * @return true|\WP_Error
	 */
	private static function assert_connectivity() {
		$connectivity_check = wp_remote_get(self::CONNECTIVITY_URL, array('timeout' => self::CONNECTIVITY_TIMEOUT));
		if (is_wp_error($connectivity_check)) {
			return new \WP_Error('no_internet', 'No internet connection during Google Sheets request', array('reason_code' => 'connectivity_failed'));
		}
		return true;
	}

	/**
	 * @param int $status HTTP status code.
	 * @return bool
	 */
	private static function should_retry_status($status) {
		if ($status <= 0) {
			return true;
		}
		return in_array((int) $status, array(408, 429, 500, 502, 503, 504), true);
	}

	/**
	 * @param int $attempt 1-based attempt.
	 * @return int
	 */
	private static function backoff_seconds($attempt) {
		$attempt = max(1, (int) $attempt);
		return min(120, 5 * (2 ** ($attempt - 1)));
	}

	/**
	 * Host + path only (no query) for logs — avoids leaking tokens in URLs.
	 *
	 * @param string $url
	 * @return string
	 */
	private static function log_safe_url($url) {
		$parts = wp_parse_url($url);
		if (!is_array($parts)) {
			return '[url]';
		}
		$host = isset($parts['host']) ? $parts['host'] : '';
		$path = isset($parts['path']) ? $parts['path'] : '';
		return $host . $path;
	}

	/**
	 * @param array $args
	 * @return array
	 */
	private static function merge_default_timeout($args) {
		if (!isset($args['timeout'])) {
			$args['timeout'] = self::DEFAULT_TIMEOUT;
		}
		return $args;
	}

	/**
	 * @param string   $method GET|POST
	 * @param string   $url
	 * @param array    $args
	 * @param callable $callback function(string $url, array $args)
	 * @return array|\WP_Error
	 */
	private static function execute_with_retries($method, $url, $args, $callback) {
		$args = self::merge_default_timeout($args);
		$safe = self::log_safe_url($url);
		$attempt = 0;
		$response = null;
		$last_reason = 'transport_error';

		do {
			$start_time = microtime(true);
			$response = call_user_func($callback, $url, $args);
			$duration = round(microtime(true) - $start_time, 2);

			if (!is_wp_error($response)) {
				$status = (int) wp_remote_retrieve_response_code($response);
				if ($status >= 200 && $status < 400) {
					return $response;
				}
				if (!self::should_retry_status($status)) {
					return new \WP_Error(
						'api_http_error',
						'Google Sheets request failed with HTTP ' . $status,
						array(
							'reason_code' => 'http_' . $status,
							'duration'    => $duration,
							'url'         => $safe,
						)
					);
				}
				$last_reason = 'http_' . $status;
			} else {
				$last_reason = $response->get_error_code() ? (string) $response->get_error_code() : 'transport_error';
			}

			if ($attempt + 1 < self::MAX_ATTEMPTS) {
				sleep(self::backoff_seconds($attempt + 1));
			}
			$attempt++;
		} while ($attempt < self::MAX_ATTEMPTS);

		if (is_wp_error($response)) {
			return new \WP_Error(
				'api_failed',
				'Google Sheets request failed after retries',
				array(
					'reason_code'    => $last_reason,
					'original_error' => $response,
					'url'            => $safe,
				)
			);
		}

		$status = (int) wp_remote_retrieve_response_code($response);
		return new \WP_Error(
			'api_failed',
			'Google Sheets request failed after retries',
			array(
				'reason_code' => $last_reason ?: 'http_' . $status,
				'url'         => $safe,
			)
		);
	}
}
