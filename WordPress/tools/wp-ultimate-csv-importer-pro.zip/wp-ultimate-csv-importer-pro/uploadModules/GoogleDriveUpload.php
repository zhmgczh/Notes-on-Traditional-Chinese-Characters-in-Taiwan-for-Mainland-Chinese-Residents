<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

class GoogleDriveOAuthHandler extends AbstractRemoteSourceProvider {

	private static $instance = null;

	public static function getInstance() {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		RemoteSourceProviderRegistry::register($this);
		$this->doHooks();
	}

	public function get_provider_id() {
		return 'gdrive';
	}

	public function get_credential_option_key() {
		return 'gdrive_oauth_credentials';
	}

	protected function get_log_prefix() {
		return '[WCSV][GoogleDrive]';
	}

	protected function get_not_connected_message() {
		return 'Google account not connected.';
	}

	public function doHooks() {
		add_action('wp_ajax_gdrive_getauthorise', array($this, 'ajax_getauthorise'));
		add_action('wp_ajax_gdrive_getaccess_token', array($this, 'ajax_getaccess_token'));
		add_action('wp_ajax_gdrive_handle_auth', array($this, 'ajax_handle_auth'));
		add_action('wp_ajax_gdrive_refresh_access_token', array($this, 'ajax_refresh_access_token'));
		add_action('wp_ajax_gdrive_list_files', array($this, 'ajax_list_files'));
		add_action('wp_ajax_gdrive_search_files', array($this, 'ajax_search_files'));
		add_action('wp_ajax_delete_gdrive_credentials', array($this, 'ajax_delete_credentials'));
		add_action('admin_notices', array($this, 'render_admin_notice'));
	}

	public function ajax_getauthorise() {
		$this->assert_ajax_capability();

		$client_config = array(
			'client_id'     => sanitize_text_field(wp_unslash($_POST['client_id'] ?? '')),
			'client_secret' => sanitize_text_field(wp_unslash($_POST['client_secret'] ?? '')),
			'redirect_uri'  => esc_url_raw(wp_unslash($_POST['redirect_uri'] ?? '')),
		);

		if ($client_config['client_id'] === '' || $client_config['client_secret'] === '' || $client_config['redirect_uri'] === '') {
			wp_send_json_error(array('message' => 'Missing required parameters.'));
		}

		$credentials = $this->get_stored_credentials();
		$this->log('Authentication started', $this->summarize_credential_state($credentials));

		if (!empty($credentials['refresh_token'])) {
			$expiry_time = (int) ($credentials['expires_in'] ?? 0);
			if ($expiry_time <= time()) {
				$refreshed = $this->refresh_token(true, 'manual_authorize');
				if (empty($refreshed['success'])) {
					wp_send_json_error(array(
						'message' => 'Authentication expired.',
						'error'   => $refreshed['error'] ?? 'Token refresh failed',
					));
				}
			}
			$this->ajax_send_file_list('root');
			return;
		}

		$auth_url = $this->get_authorize_url($client_config);
		wp_send_json_success(array('auth_url' => $auth_url));
	}

	public function ajax_getaccess_token() {
		$this->assert_ajax_capability();

		$client_config = array(
			'client_id'     => sanitize_text_field(wp_unslash($_POST['client_id'] ?? '')),
			'client_secret' => sanitize_text_field(wp_unslash($_POST['client_secret'] ?? '')),
			'redirect_uri'  => esc_url_raw(wp_unslash($_POST['redirect_uri'] ?? ($_POST['redirect_url'] ?? ''))),
		);
		$code = sanitize_text_field(wp_unslash($_POST['code'] ?? ''));

		$result = $this->exchange_code($client_config, $code);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Authentication failure'));
		}

		$this->ajax_send_file_list('root');
	}

	public function ajax_handle_auth() {
		$this->assert_ajax_capability();
		$this->ajax_getaccess_token();
	}

	public function ajax_refresh_access_token() {
		$this->assert_ajax_capability();
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$this->refresh_token(false, 'ajax');
		$this->ajax_send_file_list('root');
	}

	public function ajax_list_files() {
		$this->assert_ajax_capability();
		$folder_id = sanitize_text_field(wp_unslash($_POST['folder_id'] ?? 'root'));
		$this->ajax_send_file_list($folder_id);
	}

	public function ajax_search_files() {
		$this->assert_ajax_capability();
		$search = sanitize_text_field(wp_unslash($_POST['search'] ?? ''));
		$result = $this->list_files('root', $search);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Search failed'));
		}
		wp_send_json_success(array('entries' => $result['entries']));
	}

	public function ajax_delete_credentials() {
		$this->assert_ajax_capability();
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$this->disconnect();
		wp_send_json_success(array('message' => 'Google Drive credentials deleted successfully'));
	}

	/**
	 * Refresh Google Drive token before scheduled cloud imports (#1442).
	 *
	 * @param int $buffer_seconds Seconds before expiry to refresh proactively.
	 * @return array{success: bool, message?: string}
	 */
	public function ensure_access_token_for_schedule( $buffer_seconds = 300 ) {
		$credentials = $this->get_stored_credentials();
		if ( empty( $credentials['access_token'] ) ) {
			return array( 'success' => true );
		}
		$expiry = isset( $credentials['expires_in'] ) ? (int) $credentials['expires_in'] : 0;
		$buffer = (int) apply_filters( 'sm_uci_pro_oauth_refresh_buffer', $buffer_seconds );
		if ( $expiry > time() + $buffer ) {
			return array( 'success' => true );
		}
		$refreshed = $this->refresh_token( true, 'schedule_cron' );
		if ( empty( $refreshed['success'] ) ) {
			return array(
				'success' => false,
				'message' => $refreshed['error'] ?? 'Google Drive token refresh failed.',
			);
		}
		return array( 'success' => true );
	}

	public function render_admin_notice() {
		if (!current_user_can('manage_options')) {
			return;
		}
		if (get_option($this->get_reauth_option_key()) !== '1') {
			return;
		}
		$message = get_option($this->get_last_error_option_key());
		if (empty($message)) {
			$message = 'Google Drive authentication expired. Reconnect your account.';
		}
		echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
	}

	private function ajax_send_file_list($folder_id) {
		$result = $this->list_files($folder_id);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Failed to fetch files'));
		}
		wp_send_json_success(array('entries' => $result['entries']));
	}

	protected function build_authorize_url() {
		$params = array(
			'client_id'     => $this->client_id,
			'redirect_uri'  => $this->redirect_uri,
			'response_type' => 'code',
			'scope'         => 'https://www.googleapis.com/auth/drive.readonly',
			'access_type'   => 'offline',
			'prompt'        => 'consent',
		);
		return 'https://accounts.google.com/o/oauth2/auth?' . http_build_query($params);
	}

	protected function request_tokens(array $body, array $client_config = array()) {
		$post_fields = $body;
		if (($body['grant_type'] ?? '') === 'authorization_code') {
			$post_fields['client_id']     = $client_config['client_id'] ?? '';
			$post_fields['client_secret'] = $client_config['client_secret'] ?? '';
		} elseif (($body['grant_type'] ?? '') === 'refresh_token') {
			$post_fields['client_id']     = $client_config['client_id'] ?? '';
			$post_fields['client_secret'] = $client_config['client_secret'] ?? '';
		}

		$response = GoogleSheetsHttpTransport::remote_post('https://oauth2.googleapis.com/token', array(
			'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
			'body'    => http_build_query($post_fields),
			'timeout' => 30,
		));

		if (is_wp_error($response)) {
			return array('success' => false, 'message' => 'Google API unavailable.');
		}

		$token_body = json_decode(wp_remote_retrieve_body($response), true);
		if (isset($token_body['error'])) {
			return array('success' => false, 'message' => 'Authentication failure', 'details' => $token_body);
		}

		$existing = $this->get_stored_credentials();
		$credentials = array(
			'access_token'  => sanitize_text_field($token_body['access_token']),
			'refresh_token' => sanitize_text_field($token_body['refresh_token'] ?? ($existing['refresh_token'] ?? '')),
			'expires_in'    => time() + (int) ($token_body['expires_in'] ?? 3600),
			'token_type'    => sanitize_text_field($token_body['token_type'] ?? 'Bearer'),
			'scope'         => sanitize_text_field($token_body['scope'] ?? ''),
			'client_id'     => sanitize_text_field($client_config['client_id'] ?? ($existing['client_id'] ?? '')),
			'client_secret' => sanitize_text_field($client_config['client_secret'] ?? ($existing['client_secret'] ?? '')),
			'redirect_uri'  => esc_url_raw($client_config['redirect_uri'] ?? ($existing['redirect_uri'] ?? '')),
		);

		$this->save_credentials($credentials);
		return array('success' => true, 'credentials' => $credentials);
	}

	protected function fetch_file_list($access_token, $folder_id, $search) {
		$entries = array();
		$page_token = '';

		do {
			$query_parts = array("trashed = false");
			if ($search !== '') {
				$query_parts[] = "name contains '" . str_replace("'", "\\'", $search) . "'";
				$query_parts[] = "mimeType != 'application/vnd.google-apps.folder'";
				$query_parts[] = "mimeType != 'application/vnd.google-apps.spreadsheet'";
			} else {
				$parent = $folder_id === 'root' ? 'root' : $folder_id;
				$query_parts[] = "'" . str_replace("'", "\\'", $parent) . "' in parents";
			}

			$params = array(
				'q'                         => implode(' and ', $query_parts),
				'fields'                    => 'nextPageToken,files(id,name,mimeType,size)',
				'pageSize'                  => 200,
				'supportsAllDrives'         => 'true',
				'includeItemsFromAllDrives' => 'true',
			);
			if ($page_token !== '') {
				$params['pageToken'] = $page_token;
			}

			$url = 'https://www.googleapis.com/drive/v3/files?' . http_build_query($params);
			$response = GoogleSheetsHttpTransport::remote_get($url, array(
				'headers' => array('Authorization' => 'Bearer ' . $access_token),
				'timeout' => 30,
			));

			if (is_wp_error($response)) {
				return array('error' => 'Google API unavailable.');
			}

			$status = wp_remote_retrieve_response_code($response);
			$body   = json_decode(wp_remote_retrieve_body($response), true);

			if ($status === 401 || $status === 403) {
				return array('error' => 'Permission denied.');
			}
			if ($status >= 500) {
				return array('error' => 'Google API unavailable.');
			}
			if (!is_array($body) || !isset($body['files'])) {
				return array('error' => 'Failed to fetch files.');
			}

			foreach ($body['files'] as $file) {
				$mime = $file['mimeType'] ?? '';
				$is_folder = ($mime === 'application/vnd.google-apps.folder');
				if (!$is_folder) {
					$ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
					if ($mime === 'application/vnd.google-apps.spreadsheet' || !in_array($ext, self::SUPPORTED_EXTENSIONS, true)) {
						continue;
					}
				}
				$entries[] = array(
					'id'        => $file['id'],
					'name'      => $file['name'],
					'mimeType'  => $mime,
					'size'      => isset($file['size']) ? (int) $file['size'] : 0,
					'is_folder' => $is_folder,
				);
			}

			$page_token = isset($body['nextPageToken']) ? $body['nextPageToken'] : '';
		} while ($page_token !== '');

		return $this->sanitize_api_entries($entries);
	}

	protected function fetch_file_metadata($access_token, $file_id) {
		$url = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($file_id) . '?' . http_build_query(array(
			'fields' => 'id,name,mimeType,size,trashed',
		));

		$response = GoogleSheetsHttpTransport::remote_get($url, array(
			'headers' => array('Authorization' => 'Bearer ' . $access_token),
			'timeout' => 30,
		));

		if (is_wp_error($response)) {
			return array('error' => 'Google API unavailable.');
		}

		$status = wp_remote_retrieve_response_code($response);
		$body   = json_decode(wp_remote_retrieve_body($response), true);

		if ($status === 404 || empty($body['id'])) {
			return array('error' => 'File not found.');
		}
		if ($status === 401 || $status === 403) {
			return array('error' => 'Permission denied.');
		}
		if (!empty($body['trashed'])) {
			return array('error' => 'File not found.');
		}

		return array(
			'id'   => $body['id'],
			'name' => $body['name'] ?? '',
			'size' => isset($body['size']) ? (int) $body['size'] : 0,
		);
	}

	protected function fetch_file_content($access_token, $file_id, $dest_path, $file_name) {
		$url = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($file_id) . '?alt=media';
		$response = GoogleSheetsHttpTransport::remote_get($url, array(
			'headers' => array('Authorization' => 'Bearer ' . $access_token),
			'timeout' => 300,
		));

		if (is_wp_error($response)) {
			return array('success' => false, 'message' => 'Download failed.');
		}

		$status = wp_remote_retrieve_response_code($response);
		if ($status === 404) {
			return array('success' => false, 'message' => 'File not found.');
		}
		if ($status === 401 || $status === 403) {
			return array('success' => false, 'message' => 'Permission denied.');
		}
		if ($status >= 500 || $status < 200) {
			return array('success' => false, 'message' => 'Google API unavailable.');
		}

		$content = wp_remote_retrieve_body($response);
		if ($content === '' || $content === null) {
			return array('success' => false, 'message' => 'Download failed.');
		}

		$dir = dirname($dest_path);
		if (!is_dir($dir)) {
			wp_mkdir_p($dir);
		}

		if (file_put_contents($dest_path, $content) === false) {
			return array('success' => false, 'message' => 'Download failed.');
		}
		chmod($dest_path, 0777);

		return array('success' => true);
	}

	public function parse_import_url($url) {
		$url = (string) $url;
		if (preg_match('#^gdrive://([^/]+)/(.+)$#i', $url, $matches)) {
			return array(
				'file_id'   => sanitize_text_field(rawurldecode($matches[1])),
				'file_name' => sanitize_file_name(rawurldecode($matches[2])),
			);
		}
		if (preg_match('#drive\.google\.com/file/d/([^/]+)#i', $url, $matches)) {
			return array(
				'file_id'   => sanitize_text_field($matches[1]),
				'file_name' => '',
			);
		}
		if (preg_match('#[?&]id=([^&]+)#i', $url, $matches) && stripos($url, 'drive.google.com') !== false) {
			return array(
				'file_id'   => sanitize_text_field($matches[1]),
				'file_name' => '',
			);
		}
		return false;
	}

	public function build_import_url($file_id, $file_name) {
		return 'gdrive://' . rawurlencode($file_id) . '/' . rawurlencode($file_name);
	}
}

GoogleDriveOAuthHandler::getInstance();
