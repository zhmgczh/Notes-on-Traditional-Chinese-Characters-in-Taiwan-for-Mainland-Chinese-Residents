<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

class OneDriveOAuthHandler extends AbstractRemoteSourceProvider {

	private static $instance = null;

	const AUTH_URL       = 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize';
	const TOKEN_URL      = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
	const GRAPH_URL      = 'https://graph.microsoft.com/v1.0';
	const CALLBACK_SLUG   = 'audie-onedrive-callback';
	const OAUTH_SCOPES    = 'offline_access Files.Read.All';
	const REWRITE_OPTION  = 'uci_onedrive_oauth_rewrite_version';
	const REWRITE_VERSION = '2';
	const STATE_TRANSIENT_PREFIX = 'uci_onedrive_oauth_state_';

	public static function getInstance() {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		RemoteSourceProviderRegistry::register($this);
		$this->doHooks();
	}

	public function get_provider_id() {
		return 'onedrive';
	}

	public function get_credential_option_key() {
		return 'onedrive_oauth_credentials';
	}

	protected function get_log_prefix() {
		return '[WCSV][OneDrive]';
	}

	protected function get_not_connected_message() {
		return 'OneDrive account not connected.';
	}

	/**
	 * Azure-friendly redirect URI (no admin query strings).
	 * Example: https://example.com/audie-onedrive-callback
	 *
	 * @return string
	 */
	public static function get_redirect_uri() {
		$slug = apply_filters('uci_onedrive_callback_slug', self::CALLBACK_SLUG);
		$slug = sanitize_title($slug);
		if ($slug === '') {
			$slug = self::CALLBACK_SLUG;
		}
		return untrailingslashit(home_url('/' . $slug));
	}

	/**
	 * @return string
	 */
	private function create_oauth_state() {
		$state = wp_generate_password(10, false, false);
		set_transient(
			self::STATE_TRANSIENT_PREFIX . md5($state),
			array(
				'state'   => $state,
				'user_id' => get_current_user_id(),
			),
			15 * MINUTE_IN_SECONDS
		);
		return $state;
	}

	/**
	 * @param string $state
	 * @return bool
	 */
	private function validate_oauth_state($state) {
		$state = sanitize_text_field($state);
		if ($state === '') {
			return false;
		}
		$key     = self::STATE_TRANSIENT_PREFIX . md5($state);
		$stored  = get_transient($key);
		$is_valid = is_array($stored)
			&& isset($stored['state'])
			&& hash_equals((string) $stored['state'], $state)
			&& (int) ($stored['user_id'] ?? 0) === get_current_user_id();
		if ($is_valid) {
			delete_transient($key);
		}
		return $is_valid;
	}

	public function doHooks() {
		add_action('init', array($this, 'register_oauth_rewrite'), 5);
		add_action('template_redirect', array($this, 'handle_oauth_callback'));
		add_action('wp_ajax_onedrive_getauthorise', array($this, 'ajax_getauthorise'));
		add_action('wp_ajax_onedrive_getaccess_token', array($this, 'ajax_getaccess_token'));
		add_action('wp_ajax_onedrive_handle_auth', array($this, 'ajax_handle_auth'));
		add_action('wp_ajax_onedrive_refresh_access_token', array($this, 'ajax_refresh_access_token'));
		add_action('wp_ajax_onedrive_list_files', array($this, 'ajax_list_files'));
		add_action('wp_ajax_onedrive_search_files', array($this, 'ajax_search_files'));
		add_action('wp_ajax_delete_onedrive_credentials', array($this, 'ajax_delete_credentials'));
		add_action('admin_notices', array($this, 'render_admin_notice'));
	}

	public function register_oauth_rewrite() {
		$slug = apply_filters('uci_onedrive_callback_slug', self::CALLBACK_SLUG);
		$slug = sanitize_title($slug);
		if ($slug === '') {
			$slug = self::CALLBACK_SLUG;
		}
		add_rewrite_rule(
			'^' . preg_quote($slug, '/') . '/?$',
			'index.php?uci_onedrive_oauth=1',
			'top'
		);
		add_rewrite_tag('%uci_onedrive_oauth%', '([0-9]+)');

		if (get_option(self::REWRITE_OPTION) !== self::REWRITE_VERSION) {
			flush_rewrite_rules(false);
			update_option(self::REWRITE_OPTION, self::REWRITE_VERSION);
		}
	}

	public function handle_oauth_callback() {
		if (!get_query_var('uci_onedrive_oauth')) {
			return;
		}

		$code  = isset($_GET['code']) ? sanitize_text_field(wp_unslash($_GET['code'])) : '';
		$error = isset($_GET['error']) ? sanitize_text_field(wp_unslash($_GET['error'])) : '';

		status_header(200);
		nocache_headers();
		header('Content-Type: text/html; charset=utf-8');

		if ($error !== '') {
			$message = isset($_GET['error_description'])
				? sanitize_text_field(wp_unslash($_GET['error_description']))
				: $error;
			echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>OneDrive Authentication</title></head><body>';
			echo '<p>' . esc_html($message) . '</p></body></html>';
			exit;
		}

		echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>OneDrive Connected</title></head><body>';
		echo '<p>' . esc_html__('Authentication complete. You can close this window.', 'wp-ultimate-csv-importer-pro') . '</p>';
		if ($code !== '') {
			echo '<script>setTimeout(function(){ window.close(); }, 1500);</script>';
		}
		echo '</body></html>';
		exit;
	}

	private function build_client_config_from_request() {
		return array(
			'client_id'     => sanitize_text_field(wp_unslash($_POST['client_id'] ?? '')),
			'client_secret' => sanitize_text_field(wp_unslash($_POST['client_secret'] ?? '')),
			'redirect_uri'  => self::get_redirect_uri(),
		);
	}

	public function ajax_getauthorise() {
		$this->assert_ajax_capability();

		$client_config = $this->build_client_config_from_request();

		if ($client_config['client_id'] === '' || $client_config['client_secret'] === '') {
			wp_send_json_error(array('message' => 'Missing required parameters.'));
		}

		$credentials = $this->get_stored_credentials();
		$this->log('Authentication started', $this->summarize_credential_state($credentials));

		if (!empty($credentials['refresh_token'])) {
			$expiry_time = (int) ($credentials['expires_in'] ?? 0);
			if ($expiry_time <= time()) {
				$refreshed = $this->refresh_token(true, 'manual_authorize');
				if (empty($refreshed['success'])) {
					wp_send_json_error(array(
						'message' => 'Authentication expired.',
						'error'   => $refreshed['error'] ?? 'Token refresh failed',
					));
				}
			}
			$this->ajax_send_file_list('root');
			return;
		}

		$auth_url = $this->get_authorize_url($client_config);
		wp_send_json_success(array(
			'auth_url'      => $auth_url,
			'redirect_uri'  => self::get_redirect_uri(),
		));
	}

	public function ajax_getaccess_token() {
		$this->assert_ajax_capability();

		$client_config = $this->build_client_config_from_request();
		$code  = sanitize_text_field(wp_unslash($_POST['code'] ?? ''));
		$state = sanitize_text_field(wp_unslash($_POST['state'] ?? ''));

		if ($state !== '' && !$this->validate_oauth_state($state)) {
			wp_send_json_error(array('message' => 'Authentication failed. Invalid OAuth state.'));
		}

		$result = $this->exchange_code($client_config, $code);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Authentication failure'));
		}

		$this->ajax_send_file_list('root');
	}

	public function ajax_handle_auth() {
		$this->assert_ajax_capability();
		$this->ajax_getaccess_token();
	}

	public function ajax_refresh_access_token() {
		$this->assert_ajax_capability();
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$this->refresh_token(false, 'ajax');
		$this->ajax_send_file_list('root');
	}

	public function ajax_list_files() {
		$this->assert_ajax_capability();
		$folder_id = sanitize_text_field(wp_unslash($_POST['folder_id'] ?? 'root'));
		$this->ajax_send_file_list($folder_id);
	}

	public function ajax_search_files() {
		$this->assert_ajax_capability();
		$search = sanitize_text_field(wp_unslash($_POST['search'] ?? ''));
		$result = $this->list_files('root', $search);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Search failed'));
		}
		wp_send_json_success(array('entries' => $result['entries']));
	}

	public function ajax_delete_credentials() {
		$this->assert_ajax_capability();
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$this->disconnect();
		wp_send_json_success(array('message' => 'OneDrive credentials deleted successfully'));
	}

	public function render_admin_notice() {
		if (!current_user_can('manage_options')) {
			return;
		}
		if (get_option($this->get_reauth_option_key()) !== '1') {
			return;
		}
		$message = get_option($this->get_last_error_option_key());
		if (empty($message)) {
			$message = 'OneDrive authentication expired. Reconnect your account.';
		}
		echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
	}

	private function ajax_send_file_list($folder_id) {
		$result = $this->list_files($folder_id);
		if (empty($result['success'])) {
			wp_send_json_error(array('message' => $result['message'] ?? 'Failed to fetch files'));
		}
		wp_send_json_success(array('entries' => $result['entries']));
	}

	protected function build_authorize_url() {
		$state = $this->create_oauth_state();
		$params = array(
			'client_id'     => $this->client_id,
			'response_type' => 'code',
			'redirect_uri'  => $this->redirect_uri,
			'response_mode' => 'query',
			'scope'         => self::OAUTH_SCOPES,
			'state'         => $state,
		);
		$auth_url = self::AUTH_URL . '?' . http_build_query($params);
		$this->log('Authorize URL generated', array(
			'redirect_uri' => $this->redirect_uri,
			'scope'        => self::OAUTH_SCOPES,
			'state'        => $state,
		));
		return $auth_url;
	}

	protected function request_tokens(array $body, array $client_config = array()) {
		$post_fields = $body;
		$post_fields['client_id'] = $client_config['client_id'] ?? '';
		if (($body['grant_type'] ?? '') !== 'refresh_token' || !empty($client_config['client_secret'])) {
			$post_fields['client_secret'] = $client_config['client_secret'] ?? '';
		}
		if (($body['grant_type'] ?? '') === 'authorization_code') {
			$post_fields['redirect_uri'] = $client_config['redirect_uri'] ?? self::get_redirect_uri();
		}

		$response = wp_remote_post(self::TOKEN_URL, array(
			'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
			'body'    => http_build_query($post_fields),
			'timeout' => 30,
		));

		if (is_wp_error($response)) {
			return array('success' => false, 'message' => 'Microsoft API unavailable.');
		}

		$token_body = json_decode(wp_remote_retrieve_body($response), true);
		if (isset($token_body['error'])) {
			return array('success' => false, 'message' => 'Authentication failure', 'details' => $token_body);
		}

		$existing = $this->get_stored_credentials();
		$credentials = array(
			'access_token'  => sanitize_text_field($token_body['access_token']),
			'refresh_token' => sanitize_text_field($token_body['refresh_token'] ?? ($existing['refresh_token'] ?? '')),
			'expires_in'    => time() + (int) ($token_body['expires_in'] ?? 3600),
			'token_type'    => sanitize_text_field($token_body['token_type'] ?? 'Bearer'),
			'scope'         => sanitize_text_field($token_body['scope'] ?? ''),
			'client_id'     => sanitize_text_field($client_config['client_id'] ?? ($existing['client_id'] ?? '')),
			'client_secret' => sanitize_text_field($client_config['client_secret'] ?? ($existing['client_secret'] ?? '')),
			'redirect_uri'  => esc_url_raw($client_config['redirect_uri'] ?? ($existing['redirect_uri'] ?? '')),
		);

		$this->save_credentials($credentials);
		return array('success' => true, 'credentials' => $credentials);
	}

	protected function graph_request($access_token, $endpoint, $args = array()) {
		$url = (strpos($endpoint, 'http') === 0) ? $endpoint : self::GRAPH_URL . $endpoint;
		$method = isset($args['method']) ? $args['method'] : 'GET';
		unset($args['method']);

		$defaults = array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Accept'        => 'application/json',
			),
			'timeout' => 30,
		);
		$request_args = array_merge($defaults, $args);

		if ($method === 'POST') {
			return wp_remote_post($url, $request_args);
		}
		return wp_remote_get($url, $request_args);
	}

	protected function fetch_file_list($access_token, $folder_id, $search) {
		$entries = array();

		if ($search !== '') {
			$safe_search = str_replace("'", "''", $search);
			$url = self::GRAPH_URL . '/me/drive/root/search(q=\'' . $safe_search . '\')?$select=id,name,size,folder,file';
			$response = $this->graph_request($access_token, $url);
		} else {
			$endpoint = ($folder_id === 'root')
				? '/me/drive/root/children?$select=id,name,size,folder,file'
				: '/me/drive/items/' . rawurlencode($folder_id) . '/children?$select=id,name,size,folder,file';
			$response = $this->graph_request($access_token, $endpoint);
		}

		if (is_wp_error($response)) {
			return array('error' => 'Microsoft API unavailable.');
		}

		$status = wp_remote_retrieve_response_code($response);
		$body   = json_decode(wp_remote_retrieve_body($response), true);

		if ($status === 401 || $status === 403) {
			return array('error' => 'Access denied.');
		}
		if ($status >= 500) {
			return array('error' => 'Microsoft API unavailable.');
		}
		if (!is_array($body) || !isset($body['value'])) {
			return array('error' => 'Failed to fetch files.');
		}

		foreach ($body['value'] as $item) {
			$is_folder = isset($item['folder']);
			if (!$is_folder) {
				$ext = strtolower(pathinfo($item['name'] ?? '', PATHINFO_EXTENSION));
				if (!in_array($ext, self::SUPPORTED_EXTENSIONS, true)) {
					continue;
				}
			}
			$entries[] = array(
				'id'        => $item['id'],
				'name'      => $item['name'],
				'mimeType'  => $is_folder ? 'folder' : 'file',
				'size'      => isset($item['size']) ? (int) $item['size'] : 0,
				'is_folder' => $is_folder,
			);
		}

		return $this->sanitize_api_entries($entries);
	}

	protected function fetch_file_metadata($access_token, $file_id) {
		$response = $this->graph_request($access_token, '/me/drive/items/' . rawurlencode($file_id) . '?$select=id,name,size,folder,deleted');

		if (is_wp_error($response)) {
			return array('error' => 'Microsoft API unavailable.');
		}

		$status = wp_remote_retrieve_response_code($response);
		$body   = json_decode(wp_remote_retrieve_body($response), true);

		if ($status === 404 || empty($body['id'])) {
			return array('error' => 'File unavailable.');
		}
		if ($status === 401 || $status === 403) {
			return array('error' => 'Access denied.');
		}
		if (!empty($body['deleted'])) {
			return array('error' => 'File unavailable.');
		}
		if (!empty($body['folder'])) {
			return array('error' => 'Unsupported file format.');
		}

		return array(
			'id'   => $body['id'],
			'name' => $body['name'] ?? '',
			'size' => isset($body['size']) ? (int) $body['size'] : 0,
		);
	}

	protected function fetch_file_content($access_token, $file_id, $dest_path, $file_name) {
		$response = $this->graph_request($access_token, '/me/drive/items/' . rawurlencode($file_id) . '/content');

		if (is_wp_error($response)) {
			return array('success' => false, 'message' => 'Download failed.');
		}

		$status = wp_remote_retrieve_response_code($response);
		if ($status === 404) {
			return array('success' => false, 'message' => 'File unavailable.');
		}
		if ($status === 401 || $status === 403) {
			return array('success' => false, 'message' => 'Access denied.');
		}
		if ($status >= 500 || $status < 200) {
			return array('success' => false, 'message' => 'Microsoft API unavailable.');
		}

		$content = wp_remote_retrieve_body($response);
		if ($content === '' || $content === null) {
			return array('success' => false, 'message' => 'Download failed.');
		}

		$dir = dirname($dest_path);
		if (!is_dir($dir)) {
			wp_mkdir_p($dir);
		}

		if (file_put_contents($dest_path, $content) === false) {
			return array('success' => false, 'message' => 'Download failed.');
		}
		chmod($dest_path, 0777);

		return array('success' => true);
	}

	public function parse_import_url($url) {
		$url = (string) $url;
		if (preg_match('#^onedrive://([^/]+)/(.+)$#i', $url, $matches)) {
			return array(
				'file_id'   => sanitize_text_field(rawurldecode($matches[1])),
				'file_name' => sanitize_file_name(rawurldecode($matches[2])),
			);
		}
		if (preg_match('#onedrive\.live\.com#i', $url) && preg_match('#[?&]resid=([^&]+)#i', $url, $matches)) {
			return array(
				'file_id'   => sanitize_text_field(rawurldecode($matches[1])),
				'file_name' => '',
			);
		}
		return false;
	}

	public function build_import_url($file_id, $file_name) {
		return 'onedrive://' . rawurlencode($file_id) . '/' . rawurlencode($file_name);
	}
}

OneDriveOAuthHandler::getInstance();
