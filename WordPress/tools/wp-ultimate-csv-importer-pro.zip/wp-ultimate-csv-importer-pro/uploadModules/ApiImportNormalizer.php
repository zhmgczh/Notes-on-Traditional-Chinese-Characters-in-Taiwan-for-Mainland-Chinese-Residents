<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 ******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Decode JSON/XML API payloads and flatten to CSV-ready rows (M1).
 */
class ApiImportNormalizer {

	/**
	 * Decode HTTP body using Content-Type hint or sniffing.
	 *
	 * @param string $body Raw response body.
	 * @param string $content_type Value of Content-Type header if known.
	 * @param array  $filter_context For {@see apply_filters()} `uci_api_response_data`.
	 * @return array|\WP_Error Decoded structure or error.
	 */
	public static function decode_body($body, $content_type = '', array $filter_context = array()) {
		$body = is_string($body) ? $body : '';
		if ($body === '') {
			return array();
		}
		$ct = is_string($content_type) ? strtolower($content_type) : '';

		$trim = ltrim($body);
		if (strpos($ct, 'xml') !== false || ($trim !== '' && isset($trim[0]) && $trim[0] === '<')) {
			$data = self::decode_xml($body);
			if (is_wp_error($data)) {
				return $data;
			}
		} else {
			$data = json_decode($body, true);
			if ($body !== '' && json_last_error() !== JSON_ERROR_NONE) {
				$data = self::decode_xml($body);
				if (is_wp_error($data)) {
					return new \WP_Error(
						'uci_json_decode',
						sprintf(
							/* translators: %s PHP/json error message */
							__('Invalid JSON: %s', 'wp-ultimate-csv-importer'),
							json_last_error_msg()
						)
					);
				}
			}
			if ($data === null && $body !== '') {
				$data = array();
			}
		}

		/**
		 * Filter decoded API payload before normalization.
		 *
		 * @param mixed $data Decoded array/tree or scalar.
		 * @param array $filter_context Context without secrets.
		 */
		$data = apply_filters('uci_api_response_data', $data, $filter_context);

		return $data;
	}

	/**
	 * @param string $body XML string.
	 * @return array|\WP_Error
	 */
	private static function decode_xml($body) {
		libxml_use_internal_errors(true);
		libxml_clear_errors();
		$xml = simplexml_load_string($body);
		if ($xml === false) {
			$msgs = array();
			foreach (libxml_get_errors() as $err) {
				$msgs[] = trim($err->message);
			}
			libxml_clear_errors();
			return new \WP_Error(
				'uci_xml_decode',
				$msgs ? implode(' ', $msgs) : __('Failed to parse XML.', 'wp-ultimate-csv-importer')
			);
		}
		$json = wp_json_encode($xml);
		$arr = json_decode($json, true);
		return is_array($arr) ? $arr : array();
	}

	/**
	 * Resolve records array from decoded payload using optional dotted path (e.g. data.products).
	 *
	 * @param mixed  $data         Decoded payload.
	 * @param string $records_path Empty = auto-detect list of records or single associative row.
	 * @return array<int,array<string,mixed>> List of flat associative rows (values scalar|string).
	 */
	public static function extract_records($data, $records_path = '') {
		$records_path = is_string($records_path) ? trim($records_path) : '';
		$node = $records_path !== '' ? self::get_by_path($data, $records_path) : $data;

		if ($node === null || $node === '') {
			return array();
		}

		if (!is_array($node)) {
			return array(array('_value' => $node));
		}

		if (self::is_list_of_arrays($node)) {
			$out = array();
			foreach ($node as $row) {
				$out[] = self::flatten_row(is_array($row) ? $row : array('_value' => $row));
			}
			return $out;
		}

		if (self::is_assoc_array($node)) {
			foreach (array('data', 'results', 'items', 'records', 'products') as $guess) {
				if (isset($node[$guess]) && is_array($node[$guess]) && self::is_list_of_arrays($node[$guess])) {
					return self::extract_records($node[$guess], '');
				}
			}
			return array(self::flatten_row($node));
		}

		return array(array('_value' => wp_json_encode($node)));
	}

	/**
	 * Build stable header list and aligned numeric rows for CSV writing.
	 *
	 * @param array<int,array<string,mixed>> $records From extract_records().
	 * @return array{headers:string[],rows:array<int,array<int,string>>}
	 */
	public static function records_to_csv_tables(array $records) {
		$key_set = array();
		foreach ($records as $rec) {
			foreach (array_keys($rec) as $k) {
				$key_set[$k] = true;
			}
		}
		$headers = array_keys($key_set);
		sort($headers, SORT_NATURAL);

		$rows = array();
		foreach ($records as $rec) {
			$row = array();
			foreach ($headers as $h) {
				$val = array_key_exists($h, $rec) ? $rec[$h] : '';
				if (is_array($val) || is_object($val)) {
					$val = wp_json_encode($val);
				}
				$row[] = $val === null ? '' : (string) $val;
			}
			$rows[] = $row;
		}

		return array(
			'headers' => $headers,
			'rows'    => $rows,
		);
	}

	/**
	 * Write UTF-8 CSV to path (header + rows).
	 *
	 * @param string               $path Absolute file path.
	 * @param array<string>        $headers Column names.
	 * @param array<int,array<int,string>> $rows Data aligned to headers.
	 * @return bool|\WP_Error
	 */
	public static function write_csv_file($path, array $headers, array $rows) {
		$dir = dirname($path);
		if (! wp_mkdir_p($dir)) {
			return new \WP_Error('uci_csv_dir', __('Could not create import directory.', 'wp-ultimate-csv-importer'));
		}

		$fh = fopen($path, 'wb');
		if ($fh === false) {
			return new \WP_Error('uci_csv_open', __('Could not open CSV file for writing.', 'wp-ultimate-csv-importer'));
		}

		if (! empty($headers)) {
			fputcsv($fh, $headers, ',', '"', '\\');
		}
		foreach ($rows as $row) {
			fputcsv($fh, $row, ',', '"', '\\');
		}
		fclose($fh);
		chmod($path, 0644);

		return true;
	}

	/**
	 * @param mixed $data Tree.
	 * @param string $path Dot-separated segment path.
	 * @return mixed|null
	 */
	private static function get_by_path($data, $path) {
		if ($path === '') {
			return $data;
		}
		$parts = explode('.', $path);
		$cur = $data;
		foreach ($parts as $segment) {
			$segment = trim($segment);
			if ($segment === '') {
				continue;
			}
			if (! is_array($cur) || ! array_key_exists($segment, $cur)) {
				return null;
			}
			$cur = $cur[ $segment ];
		}
		return $cur;
	}

	/**
	 * @param mixed $arr Value.
	 */
	private static function is_assoc_array($arr) {
		if (! is_array($arr)) {
			return false;
		}
		if ($arr === array()) {
			return false;
		}
		return array_keys($arr) !== range(0, count($arr) - 1);
	}

	/**
	 * List with sequential integer keys starting at 0.
	 *
	 * @param mixed $arr Value.
	 */
	private static function is_list_array($arr) {
		if (! is_array($arr)) {
			return false;
		}
		return array_keys($arr) === range(0, count($arr) - 1);
	}

	/**
	 * @param mixed $arr Value.
	 */
	private static function is_list_of_arrays($arr) {
		if (! self::is_list_array($arr)) {
			return false;
		}
		foreach ($arr as $item) {
			if (! is_array($item)) {
				return false;
			}
		}
		return count($arr) > 0;
	}

	/**
	 * Flatten nested associative array to dot keys; list leaves JSON-encoded.
	 *
	 * @param array<string,mixed> $row Row data.
	 * @return array<string,mixed>
	 */
	private static function flatten_row(array $row, $prefix = '') {
		$flat = array();
		foreach ($row as $key => $value) {
			$key = is_string($key) ? $key : (string) $key;
			$path = $prefix === '' ? $key : $prefix . '.' . $key;

			if (is_array($value)) {
				if (self::is_list_array($value)) {
					$flat[ $path ] = wp_json_encode($value);
				} else {
					$flat = array_merge($flat, self::flatten_row($value, $path));
				}
			} elseif (is_object($value)) {
				$flat[ $path ] = wp_json_encode($value);
			} else {
				$flat[ $path ] = $value;
			}
		}
		return $flat;
	}
}
