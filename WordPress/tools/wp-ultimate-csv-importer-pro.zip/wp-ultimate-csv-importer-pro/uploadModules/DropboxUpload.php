<?php

namespace Smackcoders\WCSV;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class DropboxOAuthHandler
{
    private $client_id;
    private $client_secret;
    private $redirect_uri;

    public function __construct()
    {
        $this->doHooks();
    }

    public function doHooks()
    {
        add_action('wp_ajax_handle_dropbox_oauth_request', [$this, 'handle_dropbox_oauth_request']);
        add_action('wp_ajax_nopriv_handle_dropbox_oauth_request', [$this, 'handle_dropbox_oauth_request']);
      
        add_action('wp_ajax_handle_dropbox_oauth_callback', [$this, 'handle_dropbox_oauth_callback']);
        add_action('wp_ajax_nopriv_handle_dropbox_oauth_callback', [$this, 'handle_dropbox_oauth_callback']);

        add_action('wp_ajax_refresh_dropbox_token', [$this, 'handle_refresh_token']);
        add_action('wp_ajax_nopriv_refresh_dropbox_token', [$this, 'handle_refresh_token']);
      
        add_action('wp_ajax_list_dropbox_files', [$this, 'handle_list_files']);
        add_action('wp_ajax_nopriv_list_dropbox_files', [$this, 'handle_list_files']);

        add_action('wp_ajax_get_sharedlink', [$this, 'getSharedLink']);
        add_action('wp_ajax_nopriv_get_sharedlink', [$this, 'getSharedLink']);
        
    }

    private function getAuthorizationUrl()
    {
        $scopes = "files.metadata.read files.content.read files.content.write sharing.write";
        $auth_url = "https://www.dropbox.com/oauth2/authorize?" . http_build_query([
            "response_type"    => "code",
            "client_id"        => $this->client_id,
            "redirect_uri"     => $this->redirect_uri,
            "token_access_type" => "offline",
            "scope"            => $scopes
        ]);
        return $auth_url;
    }

    private function getAccessToken($code)
    {

        $client_id     = get_option('dropbox_client_id');
        $client_secret = get_option('dropbox_client_secret');
        $redirect_uri  = get_option('dropbox_redirect_uri');
        $response = wp_remote_post("https://api.dropboxapi.com/oauth2/token", [
            'body' => [
                "code"         => $code,
                "grant_type"   => "authorization_code",
                "redirect_uri" => $redirect_uri,
            ],
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($client_id . ':' . $client_secret),
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ]
        ]);
        if (is_wp_error($response)) {
            return false;
        }
        return json_decode(wp_remote_retrieve_body($response), true);
    }

    private function refreshAccessToken($refresh_token)
    {
        $response = wp_remote_post("https://api.dropboxapi.com/oauth2/token", [
            'body' => [
                "grant_type"    => "refresh_token",
                "refresh_token" => $refresh_token,
            ],
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($this->client_id . ':' . $this->client_secret),
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ]
        ]);

        if (is_wp_error($response)) {
            return false;
        }
        return json_decode(wp_remote_retrieve_body($response), true);
    }
 
    public function handle_dropbox_oauth_request()
    {
        
        $this->client_id     = sanitize_text_field($_GET['client_id']);
        $this->client_secret = sanitize_text_field($_GET['client_secret']);
        $this->redirect_uri  = esc_url_raw($_GET['redirect_uri']);
        update_option('dropbox_client_id', $this->client_id);
        update_option('dropbox_client_secret', $this->client_secret);
        update_option('dropbox_redirect_uri', $this->redirect_uri);
        $url = $this->getAuthorizationUrl();
        wp_send_json_success(['oauthUrl' => $url]);
        wp_die();
    }

    public function handle_dropbox_oauth_callback()
    {

        if (isset($_GET['code']) && !empty($_GET['code'])) {
            $code = sanitize_text_field($_GET['code']);
            $tokenResponse = $this->getAccessToken($code);
            if (isset($tokenResponse['access_token'])) {
                $credentials = [
                    'access_token'  => $tokenResponse['access_token'],
                    'refresh_token' => $tokenResponse['refresh_token'],
                    'expires_in'    => $tokenResponse['expires_in'],
                    'expires_at'    => time() + $tokenResponse['expires_in']
                ];
                update_option('dropbox_credentials', maybe_serialize($credentials));
                wp_send_json_success([
                    'message'        => 'Dropbox authentication successful',
                    'credentials'    => $credentials
                ], 200);
            } else {
                wp_send_json_error([
                    'message' => 'Error: Failed to get Dropbox access token',
                    'response' => $tokenResponse
                ], 400);
            }
        } else {
            wp_send_json_error(['message' => 'No authorization code provided'], 400);
        }
    }
    public function handle_refresh_token()
    {
        $credentials = maybe_unserialize(get_option('dropbox_credentials'));

        if (!$credentials || !isset($credentials['refresh_token'])) {
            wp_send_json_error(['message' => 'No refresh token found']);
        }
        $newToken = $this->refreshAccessToken($credentials['refresh_token']);

        if (isset($newToken['access_token'])) {
            $credentials['access_token'] = $newToken['access_token'];
            $credentials['expires_in']   = $newToken['expires_in'];
            $credentials['expires_at']   = time() + $newToken['expires_in'];

            update_option('dropbox_credentials', maybe_serialize($credentials));
            $credentials = maybe_unserialize(get_option('dropbox_credentials'));

            wp_send_json_success($credentials);
        } else {
            wp_send_json_error(['message' => 'Failed to refresh token']);
        }
        wp_die();
    }

    public function handle_list_files()
    {
        $credentials = maybe_unserialize(get_option('dropbox_credentials'));

        if (!$credentials || !isset($credentials['access_token'])) {
            wp_send_json_error(['message' => 'No access token found']);
        }

        if (time() > $credentials['expires_at']) {
            $newToken = $this->refreshAccessToken($credentials['refresh_token']);
            if (isset($newToken['access_token'])) {
                $credentials['access_token'] = $newToken['access_token'];
                $credentials['expires_in']   = $newToken['expires_in'];
                $credentials['expires_at']   = time() + $newToken['expires_in'];
                update_option('dropbox_credentials', maybe_serialize($credentials));
            }
        }

        $credentials = maybe_unserialize(get_option('dropbox_credentials'));
        $files = $this->listFiles($credentials['access_token']);

        if (!$files || !isset($files['entries'])) {
            wp_send_json_error(['message' => 'Failed to fetch files']);
        }

        // Build nested tree structure
        $tree = $this->buildTree($files['entries']);

        // Wrap into "data" -> "entries"
        wp_send_json_success([
            'entries' => $tree
        ]);
        wp_die();
    }

    private function buildTree(array $items)
    {
        $tree = [];
        $refs = [];

        foreach ($items as $item) {
            $item['sub_entries'] = []; // Initialize
            $refs[$item['path_lower']] = $item;
        }

        foreach ($refs as $path => &$item) {
            $parentPath = dirname($path);
            if ($parentPath !== "." && isset($refs[$parentPath])) {
                $refs[$parentPath]['sub_entries'][] = &$item;
            } else {
                $tree[] = &$item;
            }
        }

        return $tree;
    }
    
    private function listFiles($access_token, $path = "")
    {
        $response = wp_remote_post("https://api.dropboxapi.com/2/files/list_folder", [
            'body' => json_encode([
                "path" => $path,
                "recursive" => true,   // Enable recursive listing
                "include_media_info" => false,
                "include_deleted" => false,
                "include_has_explicit_shared_members" => false
            ]),
            'headers' => [
                "Authorization" => "Bearer {$access_token}",
                "Content-Type"  => "application/json"
            ]
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        return json_decode(wp_remote_retrieve_body($response), true);
    }


    public function createSharedLink($access_token ,$path) {
       
        $response = wp_remote_post("https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings", [
            'headers' => [
                "Authorization" => "Bearer {$access_token}",
                "Content-Type"  => "application/json"
            ],
            'body' => json_encode([
                "path" => $path,
                "settings" => [
                    "requested_visibility" => "public"
                ]
            ])
        ]);

        if (is_wp_error($response)) {
            return false;
        }
        return json_decode(wp_remote_retrieve_body($response), true);
    }

    public function getSharedLink($filepath) {
       
        $credentials = maybe_unserialize(get_option('dropbox_credentials'));
        if (!$credentials || !isset($credentials['access_token'])) {
            wp_send_json_error(['message' => 'No access token found']);
        }

        if (time() > $credentials['expires_at']) {
            $newToken = $this->refreshAccessToken($credentials['refresh_token']);
            if (isset($newToken['access_token'])) {
                $credentials['access_token'] = $newToken['access_token'];
                $credentials['expires_in']   = $newToken['expires_in'];
                $credentials['expires_at']   = time() + $newToken['expires_in'];
                update_option('dropbox_credentials', maybe_serialize($credentials));
            }
        }

        $credentials = maybe_unserialize(get_option('dropbox_credentials'));
        $access_token = $credentials['access_token'];
        $filepath = $_GET['path'];
        $path = trim($filepath, '"\\');

        if ($path === '/' || empty($path)) {
            return wp_send_json_error("Cannot share the root folder.");
        }
        $linkResponse = $this->createSharedLink($access_token, $path);
        if (isset($linkResponse['url'])) {
            return wp_send_json_success([
                'file' => $path,
                'link' => $linkResponse['url']
            ]);
        } else {
            if (isset($linkResponse['error']['.tag']) && $linkResponse['error']['.tag'] === 'shared_link_already_exists') {
                $existing = $this->listSharedLinks($access_token, $path);
                return wp_send_json_success([
                    'file' => $path,
                    'link' => $existing['links'][0]['url'] ?? null
                ]);
            }

            return wp_send_json_error($linkResponse);
        }
    }

    public function listSharedLinks($access_token, $path) {
     
        $response = wp_remote_post("https://api.dropboxapi.com/2/sharing/list_shared_links", [
            'headers' => [
                "Authorization" => "Bearer {$access_token}",
                "Content-Type"  => "application/json"
            ],
            'body' => json_encode([
                "path" => $path,
                "direct_only" => true
            ])
        ]);

        if (is_wp_error($response)) {
            return [];
        }
        return json_decode(wp_remote_retrieve_body($response), true);
    }

}

new DropboxOAuthHandler();

