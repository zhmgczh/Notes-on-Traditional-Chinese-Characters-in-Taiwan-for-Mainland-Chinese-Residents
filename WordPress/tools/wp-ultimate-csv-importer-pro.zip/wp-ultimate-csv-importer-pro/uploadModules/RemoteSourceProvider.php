<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
	exit;
}

interface RemoteSourceProviderInterface {

	public function get_provider_id();

	public function get_credential_option_key();

	public function get_supported_extensions();

	public function get_authorize_url(array $client_config);

	public function exchange_code(array $client_config, $code);

	public function refresh_token($return_array = false, $source = 'ajax');

	public function list_files($folder_id = 'root', $search = '');

	public function download_file($file_id, $dest_path, $file_name = '');

	public function validate_file(array $file_meta);

	public function disconnect();

	public function parse_import_url($url);

	public function download_for_import($url, $dest_path);
}

abstract class AbstractRemoteSourceProvider implements RemoteSourceProviderInterface {

	const SUPPORTED_EXTENSIONS = array('csv', 'tsv', 'txt', 'xml', 'xls', 'xlsx', 'json', 'zip');

	protected $client_id = '';
	protected $client_secret = '';
	protected $redirect_uri = '';

	abstract protected function get_log_prefix();

	abstract protected function build_authorize_url();

	abstract protected function request_tokens(array $body, array $client_config = array());

	abstract protected function fetch_file_list($access_token, $folder_id, $search);

	abstract protected function fetch_file_content($access_token, $file_id, $dest_path, $file_name);

	abstract protected function fetch_file_metadata($access_token, $file_id);

	public function get_supported_extensions() {
		return self::SUPPORTED_EXTENSIONS;
	}

	protected function log($message, $context = array()) {
		if (!is_array($context)) {
			$context = array('context' => (string) $context);
		}
		$encoded = wp_json_encode($context);
		if ($encoded === false) {
			$encoded = '{}';
		}
		error_log($this->get_log_prefix() . ' ' . $message . ' | ' . $encoded);
	}

	protected function assert_ajax_capability() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'Permission denied.'));
		}
	}

	protected function get_stored_credentials() {
		$credentials = maybe_unserialize(get_option($this->get_credential_option_key()));
		return is_array($credentials) ? $credentials : array();
	}

	protected function save_credentials(array $credentials) {
		update_option($this->get_credential_option_key(), maybe_serialize($credentials));
	}

	protected function summarize_credential_state($credentials) {
		$now = time();
		$expiry = isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0;
		return array(
			'has_access_token'  => !empty($credentials['access_token']),
			'has_refresh_token' => !empty($credentials['refresh_token']),
			'expiry_time'       => $expiry,
			'is_expired'        => $expiry > 0 ? ($expiry <= $now) : true,
		);
	}

	public function disconnect() {
		delete_option($this->get_credential_option_key());
		delete_option($this->get_reauth_option_key());
		delete_option($this->get_last_error_option_key());
	}

	protected function get_reauth_option_key() {
		return 'smack_' . $this->get_provider_id() . '_reauth_required';
	}

	protected function get_last_error_option_key() {
		return 'smack_' . $this->get_provider_id() . '_last_error';
	}

	protected function mark_reauth_required($message) {
		update_option($this->get_reauth_option_key(), '1');
		update_option($this->get_last_error_option_key(), sanitize_text_field($message));
	}

	protected function clear_reauth_flags() {
		delete_option($this->get_reauth_option_key());
		delete_option($this->get_last_error_option_key());
	}

	public function get_authorize_url(array $client_config) {
		$this->client_id     = sanitize_text_field($client_config['client_id'] ?? '');
		$this->client_secret = sanitize_text_field($client_config['client_secret'] ?? '');
		$this->redirect_uri  = esc_url_raw($client_config['redirect_uri'] ?? ($client_config['redirect_url'] ?? ''));
		return $this->build_authorize_url();
	}

	public function exchange_code(array $client_config, $code) {
		$this->log('Authentication started', array('provider' => $this->get_provider_id()));
		$client_id     = sanitize_text_field($client_config['client_id'] ?? '');
		$client_secret = sanitize_text_field($client_config['client_secret'] ?? '');
		$redirect_uri  = esc_url_raw($client_config['redirect_uri'] ?? ($client_config['redirect_url'] ?? ''));
		$code          = sanitize_text_field($code);

		if ($client_id === '' || $client_secret === '' || $redirect_uri === '' || $code === '') {
			$this->log('Authentication failure', array('reason' => 'missing_parameters'));
			return array('success' => false, 'message' => 'Missing required parameters.');
		}

		$body = $this->request_tokens(array(
			'grant_type'   => 'authorization_code',
			'code'         => $code,
			'redirect_uri' => $redirect_uri,
		), array(
			'client_id'     => $client_id,
			'client_secret' => $client_secret,
			'redirect_uri'  => $redirect_uri,
		));

		if (empty($body['success'])) {
			$this->log('Authentication failure', array('details' => $body));
			return $body;
		}

		$this->clear_reauth_flags();
		$this->log('Authentication success', $this->summarize_credential_state($body['credentials']));
		return $body;
	}

	public function refresh_token($return_array = false, $source = 'ajax') {
		$credentials = $this->get_stored_credentials();
		$this->log('Token retrieval before refresh', array_merge(
			array('source' => $source),
			$this->summarize_credential_state($credentials)
		));

		if (empty($credentials['refresh_token'])) {
			$result = array('success' => false, 'error' => 'Refresh token not available.');
			if ($return_array) {
				return $result;
			}
			wp_send_json_error(array('message' => $result['error']));
		}

		$body = $this->request_tokens(array(
			'grant_type'    => 'refresh_token',
			'refresh_token' => $credentials['refresh_token'],
		), $credentials);

		if (empty($body['success'])) {
			$this->mark_reauth_required('Authentication expired. Reconnect your account.');
			if ($return_array) {
				return array('success' => false, 'error' => $body['message'] ?? 'Token refresh failed');
			}
			wp_send_json_error(array('message' => $body['message'] ?? 'Token refresh failed'));
		}

		$this->clear_reauth_flags();
		$credentials = $body['credentials'];
		if ($return_array) {
			return array(
				'success'      => true,
				'access_token' => $credentials['access_token'],
				'expires_in'   => $credentials['expires_in'],
			);
		}
		return $body;
	}

	protected function ensure_access_token($source = 'api') {
		$credentials = $this->get_stored_credentials();
		if (empty($credentials['access_token'])) {
			$this->log('Account not connected', array('source' => $source));
			return array('success' => false, 'message' => $this->get_not_connected_message());
		}

		$expiry = isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0;
		if ($expiry > 0 && $expiry > time() + 300) {
			return array('success' => true, 'access_token' => $credentials['access_token'], 'credentials' => $credentials);
		}
		if ($expiry > 0 && $expiry <= time() + 300) {
			$refreshed = $this->refresh_token(true, $source);
			if (empty($refreshed['success'])) {
				return array('success' => false, 'message' => 'Authentication expired.');
			}
			$credentials = $this->get_stored_credentials();
		}

		return array('success' => true, 'access_token' => $credentials['access_token'], 'credentials' => $credentials);
	}

	/**
	 * Proactive token refresh for scheduled imports (#1442).
	 *
	 * @param int $buffer_seconds Seconds before expiry to refresh.
	 * @return array{success: bool, message?: string}
	 */
	public function ensure_access_token_for_schedule( $buffer_seconds = 300 ) {
		$credentials = $this->get_stored_credentials();
		if ( empty( $credentials['access_token'] ) ) {
			return array( 'success' => true );
		}

		$expiry = isset( $credentials['expires_in'] ) ? (int) $credentials['expires_in'] : 0;
		$buffer = (int) apply_filters( 'sm_uci_pro_oauth_refresh_buffer', $buffer_seconds );
		if ( $expiry > time() + $buffer ) {
			return array( 'success' => true );
		}

		$refreshed = $this->refresh_token( true, 'schedule' );
		if ( empty( $refreshed['success'] ) ) {
			return array(
				'success' => false,
				'message' => $refreshed['error'] ?? 'Google Drive token refresh failed.',
			);
		}

		return array( 'success' => true );
	}

	abstract protected function get_not_connected_message();

	public function list_files($folder_id = 'root', $search = '') {
		$token_result = $this->ensure_access_token('list_files');
		if (empty($token_result['success'])) {
			return $token_result;
		}

		$folder_id = sanitize_text_field($folder_id);
		if ($folder_id === '') {
			$folder_id = 'root';
		}
		$search = sanitize_text_field($search);

		$entries = $this->fetch_file_list($token_result['access_token'], $folder_id, $search);
		if (isset($entries['error'])) {
			return array('success' => false, 'message' => $entries['error']);
		}

		return array('success' => true, 'entries' => $entries);
	}

	public function validate_file(array $file_meta) {
		if (empty($file_meta['id'])) {
			return array('valid' => false, 'message' => 'File not found.');
		}

		$name = isset($file_meta['name']) ? (string) $file_meta['name'] : '';
		$ext  = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
		if ($ext === '' || !in_array($ext, self::SUPPORTED_EXTENSIONS, true)) {
			return array('valid' => false, 'message' => 'Unsupported file format.');
		}

		if (!empty($file_meta['size']) && (int) $file_meta['size'] <= 0) {
			return array('valid' => false, 'message' => 'File is empty.');
		}

		return array('valid' => true, 'extension' => $ext, 'name' => $name);
	}

	public function download_file($file_id, $dest_path, $file_name = '') {
		$file_id = sanitize_text_field($file_id);
		if ($file_id === '') {
			return array('success' => false, 'message' => 'File not found.');
		}

		$token_result = $this->ensure_access_token('download');
		if (empty($token_result['success'])) {
			return $token_result;
		}

		$metadata = $this->fetch_file_metadata($token_result['access_token'], $file_id);
		if (isset($metadata['error'])) {
			$this->log('File download failed', array('file_id' => $file_id, 'error' => $metadata['error']));
			return array('success' => false, 'message' => $metadata['error']);
		}

		$validation = $this->validate_file($metadata);
		if (empty($validation['valid'])) {
			return array('success' => false, 'message' => $validation['message']);
		}

		$resolved_name = $file_name !== '' ? $file_name : $validation['name'];
		$this->log('File selected', array('file_id' => $file_id, 'name' => $resolved_name));

		$download = $this->fetch_file_content($token_result['access_token'], $file_id, $dest_path, $resolved_name);
		if (empty($download['success'])) {
			$this->log('Download failed', array('file_id' => $file_id, 'message' => $download['message'] ?? ''));
			return $download;
		}

		$this->log('File downloaded', array('file_id' => $file_id, 'path' => $dest_path));
		return array(
			'success'   => true,
			'file_name' => $resolved_name,
			'extension' => $validation['extension'],
		);
	}

	public function download_for_import($url, $dest_path) {
		$parsed = $this->parse_import_url($url);
		if ($parsed === false) {
			return array('used' => false);
		}

		$this->log('Import started', array('url' => $url, 'file_id' => $parsed['file_id']));
		$result = $this->download_file($parsed['file_id'], $dest_path, $parsed['file_name']);
		if (empty($result['success'])) {
			return array(
				'used'    => true,
				'success' => false,
				'message' => $result['message'] ?? 'Download failed',
			);
		}

		$this->log('Import completed', array('file_name' => $result['file_name']));
		return array(
			'used'      => true,
			'success'   => true,
			'file_name' => $result['file_name'],
		);
	}

	protected function sanitize_api_entries(array $entries) {
		$clean = array();
		foreach ($entries as $entry) {
			if (!is_array($entry)) {
				continue;
			}
			$clean[] = array(
				'id'        => sanitize_text_field($entry['id'] ?? ''),
				'name'      => sanitize_text_field($entry['name'] ?? ''),
				'mimeType'  => sanitize_text_field($entry['mimeType'] ?? ''),
				'size'      => isset($entry['size']) ? (int) $entry['size'] : 0,
				'is_folder' => !empty($entry['is_folder']),
			);
		}
		return $clean;
	}
}

class RemoteSourceProviderRegistry {

	/** @var RemoteSourceProviderInterface[] */
	private static $providers = array();

	public static function register(RemoteSourceProviderInterface $provider) {
		self::$providers[$provider->get_provider_id()] = $provider;
	}

	/** @return RemoteSourceProviderInterface|null */
	public static function get($provider_id) {
		return isset(self::$providers[$provider_id]) ? self::$providers[$provider_id] : null;
	}

	/** @return RemoteSourceProviderInterface[] */
	public static function all() {
		return self::$providers;
	}

	public static function download_for_import($url, $dest_path) {
		foreach (self::$providers as $provider) {
			$result = $provider->download_for_import($url, $dest_path);
			if (!empty($result['used'])) {
				return $result;
			}
		}
		return array('used' => false);
	}

	public static function parse_import_filename($url) {
		foreach (self::$providers as $provider) {
			$parsed = $provider->parse_import_url($url);
			if ($parsed !== false && !empty($parsed['file_name'])) {
				return $parsed['file_name'];
			}
		}
		return '';
	}

	public static function is_remote_provider_url($url) {
		foreach (self::$providers as $provider) {
			if ($provider->parse_import_url($url) !== false) {
				return true;
			}
		}
		return false;
	}
}
