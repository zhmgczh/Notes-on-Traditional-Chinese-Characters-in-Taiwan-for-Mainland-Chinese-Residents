<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;
use League\Csv\Writer;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

class UrlUpload implements Uploads
{

	private static $instance = null;
	private static $smack_csv_instance = null;
	private const DROPBOX_LOG_PREFIX = '[WCSV][Dropbox][Schedule]';

	/**
	 * `smackcsv_file_events.file_name` is VARCHAR(255).
	 * Some remote URLs produce very long inferred names; keep extension and add a short hash suffix when truncating.
	 */
	private function normalize_file_name_for_db($file_name, $default_ext = 'csv')
	{
		$original = (string) $file_name;
		$name = $original;
		if (function_exists('sanitize_file_name')) {
			$name = sanitize_file_name($name);
		}
		$ext = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
		if ($ext === '') {
			$ext = $default_ext;
			$name = rtrim($name, '.') . '.' . $ext;
		}

		$max = 255;
		if (strlen($name) <= $max) {
			return $name;
		}

		$suffix = '-' . substr(md5($original), 0, 8);
		$dot_ext = '.' . $ext;
		$base = pathinfo($name, PATHINFO_FILENAME);

		$keep = $max - strlen($suffix) - strlen($dot_ext);
		if ($keep < 1) {
			$base = 'upload';
		} else {
			$base = substr($base, 0, $keep);
		}

		return $base . $suffix . $dot_ext;
	}

	private function __construct()
	{
		add_action('wp_ajax_get_csv_url', array($this, 'upload_function'));
	}

	public static function getInstance()
	{
		if (UrlUpload::$instance == null) {
			UrlUpload::$instance = new UrlUpload;
			UrlUpload::$smack_csv_instance = UltimatePro::getInstance();
			return UrlUpload::$instance;
		}
		return UrlUpload::$instance;
	}
	/**
	 * Upload file from URL.
	 */
	public function externalfile_handling($url)
	{
		$file_url = $url;
		$this->log_dropbox_schedule('Cron execution started', array('input_url' => $file_url));
		$response = [];
		global $wpdb;
		$file_table_name = $wpdb->prefix . "smackcsv_file_events";
		if (strstr($file_url, 'https://bit.ly/')) {
			$file_url = $this->unshorten_bitly_url($file_url);
		}

		$pub = substr($file_url, strrpos($file_url, '/') + 1);
		/*Added support for google addon & dropbox*/
		if ($pub == 'pubhtml') {
			$spread_sheet = substr($file_url, 0, -7);
			$file_url = $spread_sheet . 'pub?gid=0&single=true&output=csv';
		} elseif ($pub == 'edit?usp=sharing') {
			$response['success'] = false;
			$response['message'] = 'Update your Google sheet as Public';
		}

		if (!strstr($file_url, 'https://www.dropbox.com/')) {
			$file_url = $this->get_original_url($file_url);
			$file_url = $file_url;
		}

		// Match upload_function(): scheduled URL imports store the spreadsheet "edit" link; convert to /export so curl fetches CSV (not HTML).
		if (strstr($file_url, 'https://docs.google.com/')) {
			if (strpos($file_url, '/export?') === false && strpos($file_url, '/pub?') === false
				&& preg_match('/docs\.google\.com\/spreadsheets\/d\/([^\/]+)/', $file_url, $sheet_match)) {
				$sheet_id = $sheet_match[1];
				$gid      = null;
				if (preg_match('/gid=([0-9]+)/', $file_url, $gid_match)) {
					$gid = $gid_match[1];
				}
				$detected_format = 'csv';
				$allowed_formats = ['csv', 'tsv', 'xlsx', 'zip'];
				foreach ($allowed_formats as $fmt) {
					if (stripos($file_url, ".$fmt") !== false) {
						$detected_format = $fmt;
						break;
					}
				}
				$file_url = "https://docs.google.com/spreadsheets/d/{$sheet_id}/export?format={$detected_format}";
				if ($gid) {
					$file_url .= "&gid={$gid}";
				}
			}
		}

		if (RemoteSourceProviderRegistry::is_remote_provider_url($file_url)) {
			$provider_name = RemoteSourceProviderRegistry::parse_import_filename($file_url);
			$url_file_name = $provider_name !== '' ? $provider_name : 'remote-import.csv';
		} elseif (strstr($file_url, 'https://docs.google.com/')) {
			$get_file_headers = get_headers($file_url, 1);
			if (isset($get_file_headers['Content-Disposition'])) {
				$url_file_name = $this->get_filename_from_headers($get_file_headers['Content-Disposition']);
			} else {
				$get_file_id = explode('/', $file_url);
				$external_file = 'google-sheet-' . $get_file_id[count($get_file_id) - 2];
				$file_extension = 'csv';
				$query = parse_url($file_url, PHP_URL_QUERY);
				if (is_string($query) && $query !== '') {
					parse_str($query, $query_params);
					if (!empty($query_params['format'])) {
						$file_extension = sanitize_key($query_params['format']);
					} elseif (!empty($query_params['output'])) {
						$file_extension = sanitize_key($query_params['output']);
					}
				}
				$url_file_name = $external_file . '.' . $file_extension;
			}
		} elseif (strstr($file_url, 'https://www.dropbox.com/')) {
			$file_url = $this->normalize_dropbox_url_for_download($file_url);
			$filename = basename($file_url);
			$get_local_filename = explode('?', $filename);
			$url_file_name = $get_local_filename[0];
		} else { # Other URL's except google spreadsheets	
			$supported_file = array('csv', 'xml', 'zip', 'txt', 'json', 'tsv');
			$has_extension = explode(".", basename($file_url));
			$has_file_extension = end($has_extension);
			if ($has_extension && in_array($has_file_extension, $supported_file)) {
				$url_file_name = basename($file_url);
			} else {

				$get_file_headers = get_headers($file_url, 1);
				$url_file_name = '';
				if (isset($get_file_headers['Content-Disposition'])) {
					$url_file_name = $this->get_filename_from_headers($get_file_headers['Content-Disposition']);
				}
				if (empty($url_file_name)) {
					$parsed_url = parse_url($file_url);
					$url_path = isset($parsed_url['path']) ? $parsed_url['path'] : '';
					$base_name = basename($url_path);
					if (empty($base_name)) {
						$base_name = 'upload';
					}

					$url_file_name = $base_name;

					// Check query params for format
					if (isset($parsed_url['query'])) {
						parse_str($parsed_url['query'], $query_params);
						if (isset($query_params['format']) && is_string($query_params['format']) && in_array(strtolower($query_params['format']), $supported_file)) {
							$url_file_name .= '.' . strtolower($query_params['format']);
						} elseif (isset($query_params['type']) && is_string($query_params['type']) && in_array(strtolower($query_params['type']), $supported_file)) {
							$url_file_name .= '.' . strtolower($query_params['type']);
						}
					}

					// If still no extension and format=rss or /rss, add .xml
					$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
					if (empty($file_extension)) {
						if ((strpos($file_url, 'format=rss') !== false) || (strpos($file_url, '/rss') !== false)) {
							$url_file_name .= '.xml';
						}
					}
				}
			}
		}

		$validate_instance = ValidateFile::getInstance();
		$zip_instance = ZipHandler::getInstance();
		$supported_file = ['csv', 'xml', 'zip', 'txt', 'json', 'tsv', 'xls', 'xlsx'];
		// Fallback: If no proper extension, try to detect from headers or content
		$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
		$is_remote_provider_url = RemoteSourceProviderRegistry::is_remote_provider_url($file_url);

		if (!$is_remote_provider_url && (empty($file_extension) || !in_array(strtolower($file_extension), $supported_file))) {
			$headers = get_headers($file_url, 1);
			$contentType = isset($headers['Content-Type']) ? (is_array($headers['Content-Type']) ? $headers['Content-Type'][0] : $headers['Content-Type']) : '';

			if (strpos($contentType, 'xml') !== false) {
				$url_file_name .= '.xml';
			} elseif (strpos($contentType, 'json') !== false) {
				$url_file_name .= '.json';
			} elseif (strpos($contentType, 'csv') !== false) {
				$url_file_name .= '.csv';
			} elseif (strpos($contentType, 'text/plain') !== false) {
				$url_file_name .= '.txt';
			} else {
				// Last resort: peek at body
				$body_check = wp_remote_retrieve_body(wp_remote_get($file_url));
				if (strpos($body_check, '<?xml') === 0) {
					$url_file_name .= '.xml';
				}
			}
		}

		$url_file_name = $this->apply_url_path_format_hint($file_url, $url_file_name);

		$validate_format = $validate_instance->validate_file_format($url_file_name);

		if ($validate_format == 'yes') {

			$upload_dir = UrlUpload::$smack_csv_instance->create_upload_dir();
			if ($upload_dir) {

				$url_file_name = str_replace('%20', ' ', $url_file_name);
				$url_file_name = $this->normalize_file_name_for_db($url_file_name, $file_extension ? $file_extension : 'csv');
				$event_key = UrlUpload::$smack_csv_instance->convert_string2hash_key($url_file_name);
				$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
				if (empty($file_extension)) {
					$file_extension = 'xml';
					$url_file_name .= '.xml';
				}

				if ($file_extension == 'zip') {
					$zip_response = [];

					$curlCh = curl_init();
					curl_setopt($curlCh, CURLOPT_URL, $file_url);
					curl_setopt($curlCh, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curlCh, CURLOPT_FOLLOWLOCATION, true);
					curl_setopt($curlCh, CURLOPT_FAILONERROR, true);
					curl_setopt($curlCh, CURLOPT_MAXREDIRS, 10);
					curl_setopt($curlCh, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
					curl_setopt($curlCh, CURLOPT_CUSTOMREQUEST, 'GET');
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYHOST, FALSE);

					$curlData = curl_exec($curlCh);

					if (curl_error($curlCh)) {

						$zip_response['success'] = false;
						$zip_response['message'] = curl_error($curlCh);

					} else {
						$path = $upload_dir . $event_key . '.zip';
						$extract_path = $upload_dir . $event_key;

						$file = fopen($path, "w+");
						fputs($file, $curlData);
						chmod($path, 0777);

						$zip_result = $zip_instance->zip_upload($path, $extract_path);
						if ($zip_result == 'UnSupported File Format') {
							$zip_response['success'] = false;
							$zip_response['message'] = "UnSupported File Format Inside Zip";
						} else {
							$zip_response['success'] = true;
							$zip_response['filename'] = $url_file_name;
							$zip_response['file_type'] = 'zip';
							$zip_response['info'] = $zip_result;
						}
					}
					wp_die();
				}

				$upload_dir_path = $upload_dir . $event_key;
				if (!is_dir($upload_dir_path)) {
					wp_mkdir_p($upload_dir_path);
				}
				chmod($upload_dir_path, 0777);


				$mode_of_action = $wpdb->get_var("SELECT mode FROM $file_table_name where file_name = '" . $url_file_name . "' order by id desc limit 1");

				$ins = $wpdb->insert($file_table_name, array('file_name' => $url_file_name, 'hash_key' => $event_key, 'status' => 'Downloading', 'lock' => true));
				$lastid = (int) $wpdb->insert_id;
				if ($ins === false || $lastid <= 0) {
					$response['success'] = false;
					$response['message'] = 'Could not create import event. Please try again.';
					return $response;
				}

				$path = $upload_dir . $event_key . '/' . $event_key;
				$remote_provider_download = $this->maybe_download_remote_provider_with_oauth($file_url, $path);
				if (!empty($remote_provider_download['used'])) {
					if (!empty($remote_provider_download['success'])) {
						if (!empty($remote_provider_download['file_name'])) {
							$url_file_name = $this->normalize_file_name_for_db($remote_provider_download['file_name'], pathinfo($remote_provider_download['file_name'], PATHINFO_EXTENSION) ?: 'csv');
							$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
							$wpdb->update($file_table_name, array('file_name' => $url_file_name), array('id' => $lastid));
						}
						if ($file_extension === 'xlsx' || $file_extension === 'xls') {
							$this->convertXlsxToCsv('', $upload_dir_path, $event_key);
							chmod($path, 0777);
							$file_extension = 'csv';
						}
						$validate_file = $validate_instance->file_validation($path, $file_extension);
						$file_size = filesize($path);
						$filesize = $validate_instance->formatSizeUnits($file_size);
						if ($validate_file == "yes") {
							$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
							$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
							$response['success'] = true;
							$response['filename'] = $url_file_name;
							$response['hashkey'] = $event_key;
							$response['posttype'] = $get_result['Post Type'];
							$response['taxonomy'] = $get_result['Taxonomy'];
							$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
							$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
							$response['selectedtype'] = $get_result['selected type'];
							$response['file_type'] = $file_extension;
							$response['file_size'] = $filesize;
							$response['message'] = 'success';
							return $response;
						}
						$response['success'] = false;
						$response['message'] = $validate_file;
						return $response;
					}
					$response['success'] = false;
					$response['message'] = $remote_provider_download['message'] ?? 'Remote provider download failed';
					$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					return $response;
				}
				if (strstr($file_url, 'https://www.dropbox.com/')) {
					$this->log_dropbox_schedule('Scheduled import started', array('url' => $file_url, 'event_key' => $event_key));
					$dropbox_download = $this->download_dropbox_file_for_schedule($file_url, $path);
					if (!empty($dropbox_download['success'])) {
						$validate_file = $validate_instance->file_validation($path, $file_extension);
						$file_size = filesize($path);
						$filesize = $validate_instance->formatSizeUnits($file_size);
						if ($validate_file == "yes") {
							$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
							$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
							$response['success'] = true;
							$response['filename'] = $url_file_name;
							$response['hashkey'] = $event_key;
							$response['posttype'] = $get_result['Post Type'];
							$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
							$response['selectedtype'] = $get_result['selected type'];
							$response['file_type'] = $file_extension;
							$response['file_size'] = $filesize;
							$response['message'] = 'success';
							$this->log_dropbox_schedule('Scheduled import completed', array('event_key' => $event_key, 'path' => $path));
							return $response;
						}
						$response['success'] = false;
						$response['message'] = $validate_file;
						$this->log_dropbox_schedule('Dropbox file fetch failed', array('reason' => $validate_file, 'event_key' => $event_key));
						return $response;
					}
					$this->log_dropbox_schedule('Dropbox file fetch failed', array('reason' => $dropbox_download['message'] ?? 'Unknown error', 'event_key' => $event_key));
					$response['success'] = false;
					$response['message'] = $dropbox_download['message'] ?? 'Dropbox file fetch failed';
					$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					return $response;
				}
				$oauth_sheet_download = $this->maybe_download_google_sheet_with_oauth($file_url, $path);
				if (!empty($oauth_sheet_download['used']) && !empty($oauth_sheet_download['success'])) {
					if (!empty($oauth_sheet_download['file_name'])) {
						$url_file_name = $this->normalize_file_name_for_db($oauth_sheet_download['file_name'], 'csv');
						$file_extension = 'csv';
						$wpdb->update($file_table_name, array('file_name' => $url_file_name), array('id' => $lastid));
					}
					$validate_file = $validate_instance->file_validation($path, $file_extension);
					$file_size = filesize($path);
					$filesize = $validate_instance->formatSizeUnits($file_size);
					if ($validate_file == "yes") {
						$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
						$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
						$template_name = substr($url_file_name, 0, strpos($url_file_name, "."));
						$response['success'] = true;
						$response['filename'] = $url_file_name;
						$response['hashkey'] = $event_key;
						$response['posttype'] = $get_result['Post Type'];
						$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
						$response['selectedtype'] = $get_result['selected type'];
						$response['file_type'] = $file_extension;
						$response['file_size'] = $filesize;
						$response['templatename'] = $template_name;
						$response['message'] = 'success';
						if ($file_extension === 'csv' || $file_extension === 'tsv') {
							$delimiter = DesktopUpload::detect_csv_delimiter($path);
							update_option("smack_csv_delimiter_{$event_key}", $delimiter);
						}
						return $response;
					}
					$response['success'] = false;
					$response['message'] = $validate_file;
					return $response;
				}
				if (!empty($oauth_sheet_download['used']) && empty($oauth_sheet_download['success'])) {
					$response['success'] = false;
					$response['message'] = isset($oauth_sheet_download['message']) ? $oauth_sheet_download['message'] : 'Google Sheet OAuth download failed';
					return $response;
				}
				$is_remote_url_import = $this->is_generic_remote_url_import($file_url);

				if ($is_remote_url_import) {
					$dl = $this->download_remote_to_file($file_url, $path);
					if (isset($dl['error'])) {
						$response['success'] = false;
						$response['message'] = is_wp_error($dl['error']) ? $dl['error']->get_error_message() : 'Download failed';
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} elseif (!$this->finalize_streamed_file($dl['part_path'], $path, $file_url, isset($dl['headers']) ? $dl['headers'] : null)) {
						@unlink($path);
						$response['success'] = false;
						$response['message'] = 'Download or decompression failed';
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} elseif (!file_exists($path) || !filesize($path)) {
						$response['success'] = false;
						$response['message'] = 'Empty download';
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} else {
						if ($file_extension == 'xlsx' || $file_extension == 'xls') {
							$this->convertXlsxToCsv('', $upload_dir_path, $event_key);
							$file_extension = 'csv';
						} else {
							chmod($path, 0777);
						}
						$validate_file = $validate_instance->file_validation($path, $file_extension);
						$file_size = filesize($path);
						$filesize = $validate_instance->formatSizeUnits($file_size);
						if ($validate_file == "yes") {
							$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
							$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
							$response['success'] = true;
							$response['filename'] = $url_file_name;
							$response['hashkey'] = $event_key;
							$response['posttype'] = $get_result['Post Type'];
							$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
							$response['selectedtype'] = $get_result['selected type'];
							$response['file_type'] = $file_extension;
							$response['file_size'] = $filesize;
							$response['message'] = 'success';
						} else {
							$response['success'] = false;
							$response['message'] = $validate_file;
							unlink($path);
							$wpdb->get_results("UPDATE $file_table_name SET status='Download Failed',`lock`=true WHERE id = '$lastid'");
						}
					}
				} else {
					$curlCh = curl_init();
					curl_setopt($curlCh, CURLOPT_URL, $file_url);
					curl_setopt($curlCh, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curlCh, CURLOPT_FOLLOWLOCATION, true);
					curl_setopt($curlCh, CURLOPT_FAILONERROR, true);
					curl_setopt($curlCh, CURLOPT_MAXREDIRS, 10);
					curl_setopt($curlCh, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
					curl_setopt($curlCh, CURLOPT_CUSTOMREQUEST, 'GET');
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYHOST, FALSE);

					$curlData = curl_exec($curlCh);

					if (curl_error($curlCh)) {

						$response['success'] = false;
						$response['message'] = curl_error($curlCh);
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} else {
						$file = fopen($path, "w+");
						fputs($file, $curlData);
						chmod($path, 0777);

						$validate_file = $validate_instance->file_validation($path, $file_extension);

						$file_size = filesize($path);
						$filesize = $validate_instance->formatSizeUnits($file_size);

						if ($validate_file == "yes") {
							$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
							fclose($file);
							$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
							$response['success'] = true;
							$response['filename'] = $url_file_name;
							$response['hashkey'] = $event_key;
							$response['posttype'] = $get_result['Post Type'];
							$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
							$response['selectedtype'] = $get_result['selected type'];
							$response['file_type'] = $file_extension;
							$response['file_size'] = $filesize;
							$response['message'] = 'success';
						} else {
							fclose($file);
							$response['success'] = false;
							$response['message'] = $validate_file;
							unlink($path);
							$wpdb->get_results("UPDATE $file_table_name SET status='Download Failed',`lock`=true WHERE id = '$lastid'");
						}
					}
					curl_close($curlCh);
				}
			} else {
				$response['success'] = false;
				$response['message'] = "Please create Upload folder with writable permission";
			}
		} else {
			$response['success'] = false;
			$response['message'] = $validate_format;
		}
		return $response;
	}

	private function log_dropbox_schedule($message, $context = array())
	{
		if (!is_array($context)) {
			$context = array('context' => (string) $context);
		}
		$encoded_context = wp_json_encode($context);
		if ($encoded_context === false) {
			$encoded_context = '{}';
		}
		return;
	}

	/**
	 * Published "File > Share > Publish to web" links use /d/e/2PACX-.../pub — not Sheets API spreadsheet IDs.
	 *
	 * @param string $file_url
	 * @return bool
	 */
	private function is_google_sheets_published_url($file_url)
	{
		$file_url = (string) $file_url;
		if ($file_url === '') {
			return false;
		}
		if (stripos($file_url, 'docs.google.com/spreadsheets') === false) {
			return false;
		}
		if (preg_match('#/spreadsheets/d/e/#i', $file_url)) {
			return true;
		}
		if (stripos($file_url, '2PACX-') !== false) {
			return true;
		}
		if (preg_match('#/(pub|pubhtml)(\?|$)#i', $file_url)) {
			return true;
		}
		return false;
	}

	private function normalize_dropbox_url_for_download($url)
	{
		$url = (string) $url;
		if ($url === '') {
			return $url;
		}
		$url = preg_replace('/([?&])st=[^&]*/', '$1', $url);
		$url = rtrim($url, '?&');
		if (strpos($url, 'dl=0') !== false) {
			$url = str_replace('dl=0', 'dl=1', $url);
		} elseif (strpos($url, 'dl=1') === false) {
			$url .= (strpos($url, '?') === false ? '?' : '&') . 'dl=1';
		}
		return $url;
	}

	private function get_dropbox_credentials()
	{
		$credentials = maybe_unserialize(get_option('dropbox_credentials'));
		return is_array($credentials) ? $credentials : array();
	}

	public function validate_dropbox_connection($context = 'cron')
	{
		$credentials = $this->get_dropbox_credentials();
		$expiry = isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0;
		$is_expired = ($expiry <= time());
		$this->log_dropbox_schedule('Dropbox connection validation', array(
			'context' => $context,
			'has_access_token' => !empty($credentials['access_token']),
			'has_refresh_token' => !empty($credentials['refresh_token']),
			'token_expiry_time' => $expiry,
			'is_expired' => $is_expired,
			'is_token_empty_during_cron' => ($context === 'cron' && empty($credentials['access_token'])),
		));
		if (empty($credentials['access_token'])) {
			update_option('smack_dropbox_reauth_required', '1');
			update_option('smack_dropbox_last_error', 'Token missing during cron. Re-authentication required.');
			return false;
		}
		if ($is_expired && empty($credentials['refresh_token'])) {
			update_option('smack_dropbox_reauth_required', '1');
			update_option('smack_dropbox_last_error', 'Dropbox token expired and refresh token is missing.');
			return false;
		}
		return true;
	}

	private function get_dropbox_access_token_for_schedule(&$credentials)
	{
		$this->log_dropbox_schedule('Token retrieval', array(
			'has_access_token' => !empty($credentials['access_token']),
			'has_refresh_token' => !empty($credentials['refresh_token']),
			'token_expiry_time' => isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0,
			'is_token_empty_during_cron' => empty($credentials['access_token']),
		));
		if (empty($credentials['access_token'])) {
			$this->log_dropbox_schedule('Dropbox token missing');
			return '';
		}
		$expiry = isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0;
		if ($expiry > 0 && $expiry > (time() + 30)) {
			$this->log_dropbox_schedule('Dropbox token available', array('expires_in' => $expiry));
			return (string) $credentials['access_token'];
		}
		$this->log_dropbox_schedule('Dropbox token expired', array('expires_in' => $expiry));
		if (empty($credentials['refresh_token']) || empty($credentials['client_id']) || empty($credentials['client_secret'])) {
			$this->log_dropbox_schedule('Dropbox file fetch failed', array('reason' => 'Refresh token unavailable'));
			update_option('smack_dropbox_reauth_required', '1');
			update_option('smack_dropbox_last_error', 'Dropbox token expired but not refreshed. Re-authentication required.');
			return '';
		}
		$refresh_response = wp_remote_post('https://api.dropboxapi.com/oauth2/token', array(
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode($credentials['client_id'] . ':' . $credentials['client_secret']),
				'Content-Type'  => 'application/x-www-form-urlencoded',
			),
			'body'    => http_build_query(array(
				'grant_type'    => 'refresh_token',
				'refresh_token' => $credentials['refresh_token'],
			)),
			'timeout' => 30,
		));
		if (is_wp_error($refresh_response)) {
			$this->log_dropbox_schedule('Dropbox file fetch failed', array('reason' => $refresh_response->get_error_message()));
			update_option('smack_dropbox_reauth_required', '1');
			update_option('smack_dropbox_last_error', 'Dropbox token refresh failed. Re-authentication required.');
			return '';
		}
		$refresh_body = json_decode(wp_remote_retrieve_body($refresh_response), true);
		$this->log_dropbox_schedule('Dropbox refresh response', array('has_access_token' => isset($refresh_body['access_token']), 'status' => wp_remote_retrieve_response_code($refresh_response)));
		if (empty($refresh_body['access_token'])) {
			$this->log_dropbox_schedule('Dropbox file fetch failed', array('reason' => 'Invalid refresh response'));
			update_option('smack_dropbox_reauth_required', '1');
			update_option('smack_dropbox_last_error', 'Dropbox token refresh returned invalid response.');
			return '';
		}
		$credentials['access_token'] = sanitize_text_field($refresh_body['access_token']);
		$credentials['expires_in'] = time() + intval($refresh_body['expires_in'] ?? 14400);
		update_option('dropbox_credentials', maybe_serialize($credentials));
		delete_option('smack_dropbox_reauth_required');
		delete_option('smack_dropbox_last_error');
		return (string) $credentials['access_token'];
	}

	private function download_dropbox_file_for_schedule($file_url, $path)
	{
		if (!$this->validate_dropbox_connection('cron')) {
			$this->log_dropbox_schedule('Credentials not saved in DB or invalid for cron');
			return array('success' => false, 'message' => 'Dropbox token invalid during cron');
		}
		$credentials = $this->get_dropbox_credentials();
		$token = $this->get_dropbox_access_token_for_schedule($credentials);
		if ($token === '') {
			$this->log_dropbox_schedule('Token missing during cron');
			return array('success' => false, 'message' => 'Dropbox token missing');
		}

		$normalized_url = $this->normalize_dropbox_url_for_download($file_url);
		$metadata_url = preg_replace('/([?&])dl=\d/', '$1', $normalized_url);
		$metadata_url = rtrim((string) $metadata_url, '?&');
		$this->log_dropbox_schedule('Before Dropbox file fetch', array('url' => $metadata_url));

		$metadata_response = wp_remote_post('https://api.dropboxapi.com/2/sharing/get_shared_link_metadata', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode(array('url' => $metadata_url)),
			'timeout' => 30,
		));
		if (is_wp_error($metadata_response)) {
			return array('success' => false, 'message' => $metadata_response->get_error_message());
		}
		$metadata_body = json_decode(wp_remote_retrieve_body($metadata_response), true);
		$this->log_dropbox_schedule('Dropbox API response', array('metadata_status' => wp_remote_retrieve_response_code($metadata_response)));
		if (!empty($metadata_body['error'])) {
			return array('success' => false, 'message' => 'Dropbox metadata request failed');
		}
		$file_response = wp_remote_post('https://content.dropboxapi.com/2/sharing/get_shared_link_file', array(
			'headers' => array(
				'Authorization'     => 'Bearer ' . $token,
				'Dropbox-API-Arg'   => wp_json_encode(array('url' => $metadata_url)),
				'Content-Type'      => 'text/plain',
			),
			'body' => '',
			'timeout' => 120,
		));
		if (is_wp_error($file_response)) {
			return array('success' => false, 'message' => $file_response->get_error_message());
		}
		$status_code = wp_remote_retrieve_response_code($file_response);
		$this->log_dropbox_schedule('Dropbox API response', array('download_status' => $status_code));
		if ($status_code < 200 || $status_code >= 300) {
			$error_body = wp_remote_retrieve_body($file_response);
			$this->log_dropbox_schedule('Dropbox file fetch failed', array('api_error' => $error_body));
			return array('success' => false, 'message' => 'Dropbox download failed');
		}
		$file_content = wp_remote_retrieve_body($file_response);
		if ($file_content === '') {
			return array('success' => false, 'message' => 'Dropbox returned empty file');
		}
		file_put_contents($path, $file_content);
		chmod($path, 0777);
		$this->log_dropbox_schedule('Dropbox file path returned', array('path' => $path));
		return array('success' => true);
	}


	function convertXlsxToCsv($curlData, $upload_dir_path, $event_key)
	{
		load_vendor_autoload();
		// Temporary file path for downloaded XLSX
		$csv_file_path = $upload_dir_path . '/' . $event_key;
		if ($curlData !== null && $curlData !== '') {
			file_put_contents($csv_file_path, $curlData);
		}
		try {
			$spreadsheet = IOFactory::load($csv_file_path);
		} catch (Exception $e) {
		}
		// Convert to CSV
		$csv_writer = new Csv($spreadsheet);
		$csv_writer->setDelimiter(','); // Set delimiter (change to "\t" for tab-separated)
		$csv_writer->setEnclosure('"'); // Set text enclosure character
		$csv_writer->setSheetIndex(0); // Convert only the first sheet

		// Save CSV file
		$csv_writer->save($csv_file_path);
	}

	/**
	 * Upload file from URL.
	 */
	public function upload_function()
	{
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$file_url = $this->sanitize_import_url($_POST['url'] ?? '');
		$response = [];
		global $wpdb;
		$file_table_name = $wpdb->prefix . "smackcsv_file_events";
		if ($file_url === '') {
			$response['success'] = false;
			$response['message'] = 'Invalid file URL';
			echo wp_json_encode($response);
			wp_die();
		}
		if (strstr($file_url, 'https://bit.ly/')) {
			$file_url = $this->unshorten_bitly_url($file_url);
		}

		$pub = substr($file_url, strrpos($file_url, '/') + 1);
		/*Added support for google addon & dropbox*/
		if ($pub == 'pubhtml') {
			$spread_sheet = substr($file_url, 0, -7);
			$file_url = $spread_sheet . 'pub?gid=0&single=true&output=csv';
		} elseif ($pub == 'edit?usp=sharing') {
			$response['success'] = false;
			$response['message'] = 'Update your Google sheet as Public';
			echo wp_json_encode($response);
		}

		// if(!strstr($file_url, 'https://www.dropbox.com/')) {	
		// 	$file_url   = $this->get_original_url($file_url);	
		// 	$file_url = $file_url;
		// }

		if (RemoteSourceProviderRegistry::is_remote_provider_url($file_url)) {
			$provider_name = RemoteSourceProviderRegistry::parse_import_filename($file_url);
			$url_file_name = $provider_name !== '' ? $provider_name : 'remote-import.csv';
		} elseif (strstr($file_url, 'https://docs.google.com/')) {

			if (strpos($file_url, '/export?') !== false) {
			} elseif (strpos($file_url, '/pub?') !== false) {
			} elseif (preg_match('/docs\.google\.com\/spreadsheets\/d\/([^\/]+)/', $file_url, $matches)) {
				$sheet_id = $matches[1];
				$gid = null;

				if (preg_match('/gid=([0-9]+)/', $file_url, $gid_match)) {
					$gid = $gid_match[1];
				}

				$detected_format = 'csv';
				$allowed_formats = ['csv', 'tsv', 'xlsx', 'zip'];

				foreach ($allowed_formats as $fmt) {
					if (stripos($file_url, ".$fmt") !== false) {
						$detected_format = $fmt;
						break;
					}
				}

				$export_url = "https://docs.google.com/spreadsheets/d/{$sheet_id}/export?format={$detected_format}";

				if ($gid) {
					$export_url .= "&gid={$gid}";
				}

				$file_url = $export_url;
			}


			$get_file_headers = get_headers($file_url, 1);

			if (isset($get_file_headers['Content-Disposition'])) {
				$url_file_name = $this->get_filename_from_headers($get_file_headers['Content-Disposition']);
			} else {
				$get_file_id = explode('/', $file_url);
				$external_file = 'google-sheet-' . $get_file_id[count($get_file_id) - 2];

				if (strpos($file_url, 'format=') !== false) {
					parse_str(parse_url($file_url, PHP_URL_QUERY), $query);
					$file_extension = $query['format'] ?? 'csv';
				} else {
					$file_extension = 'csv';
				}

				$url_file_name = $external_file . '.' . $file_extension;
			}
		}

		if (strstr($file_url, 'https://www.dropbox.com/')) {
			$this->validate_dropbox_connection('manual');
			$manual_credentials = $this->get_dropbox_credentials();
			$this->log_dropbox_schedule('Manual import token snapshot', array(
				'has_access_token' => !empty($manual_credentials['access_token']),
				'has_refresh_token' => !empty($manual_credentials['refresh_token']),
				'token_expiry_time' => isset($manual_credentials['expires_in']) ? (int) $manual_credentials['expires_in'] : 0,
			));
			if (strpos($file_url, 'dl=0') !== false) {
				$file_url = str_replace('dl=0', 'dl=1', $file_url);
			} elseif (strpos($file_url, 'dl=1') === false) {
				$file_url .= '&dl=1';
			}

			$filename = basename($file_url);
			$get_local_filename = explode('?', $filename);
			$url_file_name = $get_local_filename[0];
		}
		// elseif(strstr($file_url, 'https://www.dropbox.com/')) {
		// 	$filename = basename($file_url);
		// 	$get_local_filename = explode('?', $filename);
		// 	$url_file_name = $get_local_filename[0];	
		// }
		elseif (!RemoteSourceProviderRegistry::is_remote_provider_url($file_url)) { # Other URL's except google spreadsheets and cloud providers

			$supported_file = array('csv', 'xml', 'zip', 'txt', 'json', 'tsv');
			$has_extension = explode(".", basename($file_url));
			$has_file_extension = end($has_extension);
			if ($has_extension && in_array($has_file_extension, $supported_file)) {
				$url_file_name = basename($file_url);
			} else {
				$get_file_headers = get_headers($file_url, 1);
				$url_file_name = '';
				if (isset($get_file_headers['Content-Disposition'])) {
					$url_file_name = $this->get_filename_from_headers($get_file_headers['Content-Disposition']);
				}
				if (empty($url_file_name)) {
					$parsed_url = parse_url($file_url);
					$url_path = isset($parsed_url['path']) ? $parsed_url['path'] : '';
					$base_name = basename($url_path);
					if (empty($base_name)) {
						$base_name = 'upload';
					}

					$url_file_name = $base_name;

					// Check query params for format
					if (isset($parsed_url['query'])) {
						parse_str($parsed_url['query'], $query_params);
						if (isset($query_params['format']) && is_string($query_params['format']) && in_array(strtolower($query_params['format']), $supported_file)) {
							$url_file_name .= '.' . strtolower($query_params['format']);
						} elseif (isset($query_params['type']) && is_string($query_params['type']) && in_array(strtolower($query_params['type']), $supported_file)) {
							$url_file_name .= '.' . strtolower($query_params['type']);
						}
					}

					// If still no extension and format=rss or /rss, add .xml
					$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
					if (empty($file_extension)) {
						if ((strpos($file_url, 'format=rss') !== false) || (strpos($file_url, '/rss') !== false)) {
							$url_file_name .= '.xml';
						}
					}
				}
			}
		}
		$validate_instance = ValidateFile::getInstance();
		$zip_instance = ZipHandler::getInstance();

		$supported_file = ['csv', 'xml', 'zip', 'txt', 'json', 'tsv', 'xls', 'xlsx'];
		// Fallback: If no proper extension, try to detect from headers or content
		$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
		$is_remote_provider_url = RemoteSourceProviderRegistry::is_remote_provider_url($file_url);

		if (!$is_remote_provider_url && (empty($file_extension) || !in_array(strtolower($file_extension), $supported_file))) {
			$headers = get_headers($file_url, 1);
			$contentType = isset($headers['Content-Type']) ? (is_array($headers['Content-Type']) ? $headers['Content-Type'][0] : $headers['Content-Type']) : '';

			if (strpos($contentType, 'xml') !== false) {
				$url_file_name .= '.xml';
			} elseif (strpos($contentType, 'json') !== false) {
				$url_file_name .= '.json';
			} elseif (strpos($contentType, 'csv') !== false) {
				$url_file_name .= '.csv';
			} elseif (strpos($contentType, 'text/plain') !== false) {
				$url_file_name .= '.txt';
			} else {
				// Last resort: peek at body
				$response = wp_remote_get($file_url, [
					'timeout' => 30,
					'redirection' => 5,
					'sslverify' => false,
					'headers' => [
						'User-Agent' => 'Mozilla/5.0 (compatible; WordPress Importer)'
					],
				]);

				$body_check = wp_remote_retrieve_body($response);

				if (!empty($body_check)) {
					// Peek at the start of the file to determine type
					$peek = substr($body_check, 0, 200);

					if (strpos($peek, '<?xml') === 0) {
						$file_extension = 'xml';
						$url_file_name .= '.xml';
					} elseif (strpos($peek, '{') === 0 || strpos($peek, '[') === 0) {
						$file_extension = 'json';
						$url_file_name .= '.json';
					} elseif (strpos($peek, "\t") !== false) {
						$file_extension = 'tsv';
						$url_file_name .= '.tsv';
					} else {
						$file_extension = 'csv';
						$url_file_name .= '.csv';
					}

				}

				if (strpos($body_check, '<?xml') === 0) {
					$url_file_name .= '.xml';
				}
			}
		}

		$url_file_name = $this->apply_url_path_format_hint($file_url, $url_file_name);

		$validate_format = $validate_instance->validate_file_format($url_file_name);
		if ($validate_format == 'yes') {
			if (!extension_loaded('curl')) {
				$response['success'] = false;
				$response['message'] = 'The required PHP extension cURL is not installed. Please install it.';
				echo wp_json_encode($response);
				wp_die();
			}
			$upload_dir = UrlUpload::$smack_csv_instance->create_upload_dir();
			if ($upload_dir) {
				$url_file_name = str_replace('%20', ' ', $url_file_name);
				$url_file_name = $this->normalize_file_name_for_db($url_file_name, $file_extension ? $file_extension : 'csv');
				$event_key = UrlUpload::$smack_csv_instance->convert_string2hash_key($url_file_name);
				$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);

				// If the extension is missing, try to get it from Content-Type
				if (empty($file_extension)) {
					$headers = get_headers($file_url, 1);
					$contentType = isset($headers['Content-Type']) ? $headers['Content-Type'] : '';

					if (strpos($contentType, 'xml') !== false) {
						$file_extension = 'xml';
					} elseif (strpos($contentType, 'json') !== false) {
						$file_extension = 'json';
					} elseif (strpos($contentType, 'csv') !== false) {
						$file_extension = 'csv';
					} else {
						$file_extension = 'txt'; // Default fallback
					}
				}

				if ($file_extension == 'zip') {
					if (!function_exists('curl_version')) {
						$response['success'] = false;
						$response['message'] = 'Curl is not exists.Kindly install it.';
						echo wp_json_encode($response);
						wp_die();
					}
					$zip_response = [];

					$curlCh = curl_init();
					curl_setopt($curlCh, CURLOPT_URL, $file_url);
					curl_setopt($curlCh, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curlCh, CURLOPT_FOLLOWLOCATION, true);
					curl_setopt($curlCh, CURLOPT_FAILONERROR, true);
					curl_setopt($curlCh, CURLOPT_MAXREDIRS, 10);
					curl_setopt($curlCh, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
					curl_setopt($curlCh, CURLOPT_CUSTOMREQUEST, 'GET');
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYHOST, FALSE);
					$response = wp_remote_get($file_url, [
						'headers' => [
							'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
							'Accept' => 'application/xml,text/xml;q=0.9,*/*;q=0.8',
						],
						'timeout' => 60,
					]);

					if (is_wp_error($response)) {
						$response['success'] = false;
						$response['message'] = $response->get_error_message();
						echo wp_json_encode($response);
						wp_die();
					}

					$curlData = wp_remote_retrieve_body($response);

					if (curl_error($curlCh)) {

						$zip_response['success'] = false;
						$zip_response['message'] = curl_error($curlCh);

					} else {
						$path = $upload_dir . $event_key . '.zip';
						$extract_path = $upload_dir . $event_key;

						$file = fopen($path, "w+");
						fputs($file, $curlData);
						chmod($path, 0777);

						$zip_result = $zip_instance->zip_upload($path, $extract_path);
						if ($zip_result == 'UnSupported File Format') {
							$zip_response['success'] = false;
							$zip_response['message'] = "UnSupported File Format Inside Zip";
						} else {
							$zip_response['success'] = true;
							$zip_response['filename'] = $url_file_name;
							$zip_response['file_type'] = 'zip';
							$zip_response['info'] = $zip_result;
						}

					}
					echo wp_json_encode($zip_response);
					wp_die();
				}

				$upload_dir_path = $upload_dir . $event_key;
				if (!is_dir($upload_dir_path)) {
					wp_mkdir_p($upload_dir_path);
				}
				chmod($upload_dir_path, 0777);

				$ins = $wpdb->insert($file_table_name, array('file_name' => $url_file_name, 'hash_key' => $event_key, 'status' => 'Downloading', 'lock' => true));
				$lastid = (int) $wpdb->insert_id;
				if ($ins === false || $lastid <= 0) {
					$response['success'] = false;
					$response['message'] = 'Could not create import event. Please try again.';
					return $response;
				}

				$path = $upload_dir . $event_key . '/' . $event_key;
				$remote_provider_download = $this->maybe_download_remote_provider_with_oauth($file_url, $path);
				if (!empty($remote_provider_download['used'])) {
					$this->finalize_remote_provider_ajax_download(
						$remote_provider_download,
						$path,
						$upload_dir_path,
						$event_key,
						$url_file_name,
						$file_extension,
						$lastid,
						$file_table_name,
						$validate_instance
					);
				}
				$oauth_sheet_download = $this->maybe_download_google_sheet_with_oauth($file_url, $path);
				if (!empty($oauth_sheet_download['used']) && !empty($oauth_sheet_download['success'])) {
					if (!empty($oauth_sheet_download['file_name'])) {
						$url_file_name = $this->normalize_file_name_for_db($oauth_sheet_download['file_name'], 'csv');
						$file_extension = 'csv';
						$wpdb->update($file_table_name, array('file_name' => $url_file_name), array('id' => $lastid));
					}
					$validate_file = $validate_instance->file_validation($path, $file_extension);
					$file_size = filesize($path);
					$filesize = $validate_instance->formatSizeUnits($file_size);
					if ($validate_file == "yes") {
						$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
						$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
						$template_name = substr($url_file_name, 0, strpos($url_file_name, "."));
						$response['success'] = true;
						$response['filename'] = $url_file_name;
						$response['hashkey'] = $event_key;
						$response['posttype'] = $get_result['Post Type'];
						$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
						$response['selectedtype'] = $get_result['selected type'];
						$response['file_type'] = $file_extension;
						$response['file_size'] = $filesize;
						$response['templatename'] = $template_name;
						$response['message'] = 'success';
						if ($file_extension === 'csv' || $file_extension === 'tsv') {
							$delimiter = DesktopUpload::detect_csv_delimiter($path);
							update_option("smack_csv_delimiter_{$event_key}", $delimiter);
						}
						echo wp_json_encode($response);
						wp_die();
					}
					$response['success'] = false;
					$response['message'] = $validate_file;
					echo wp_json_encode($response);
					wp_die();
				}
				if (!empty($oauth_sheet_download['used']) && empty($oauth_sheet_download['success'])) {
					$response['success'] = false;
					$response['message'] = isset($oauth_sheet_download['message']) ? $oauth_sheet_download['message'] : 'Google Sheet OAuth download failed';
					echo wp_json_encode($response);
					wp_die();
				}
				$is_remote_url_import = $this->is_generic_remote_url_import($file_url);

				if ($is_remote_url_import) {
					$dl = $this->download_remote_to_file($file_url, $path);
					if (isset($dl['error'])) {
						$dl_err = $dl['error'];
						$err_msg = is_wp_error($dl_err) ? $dl_err->get_error_message() : 'Download failed';
						$ajax_out = array('success' => false, 'message' => $err_msg);
						echo wp_json_encode($ajax_out);
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} elseif (!$this->finalize_streamed_file($dl['part_path'], $path, $file_url, isset($dl['headers']) ? $dl['headers'] : null)) {
						@unlink($path);
						$ajax_out = array('success' => false, 'message' => 'Download or decompression failed');
						echo wp_json_encode($ajax_out);
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
					} else {
						if (!file_exists($path) || !filesize($path)) {
							@unlink($path);
							$ajax_out = array('success' => false, 'message' => 'Empty download');
							echo wp_json_encode($ajax_out);
							$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
						} else {
							if ($file_extension == 'xlsx' || $file_extension == 'xls') {
								$this->convertXlsxToCsv('', $upload_dir_path, $event_key);
								chmod($path, 0777);
								$file_extension = 'csv';
							} else {
								chmod($path, 0777);
							}
							$validate_file = $validate_instance->file_validation($path, $file_extension);
							$file_size = filesize($path);
							$filesize = $validate_instance->formatSizeUnits($file_size);
							if ($validate_file == "yes") {
								$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
								$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
								$template_name = substr($url_file_name, 0, strpos($url_file_name, "."));
								$response['success'] = true;
								$response['filename'] = $url_file_name;
								$response['hashkey'] = $event_key;
								$response['posttype'] = $get_result['Post Type'];
								$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
								$response['selectedtype'] = $get_result['selected type'];
								$response['file_type'] = $file_extension;
								$response['file_size'] = $filesize;
								$response['templatename'] = $template_name;
								$response['message'] = 'success';
								if ($file_extension === 'csv' || $file_extension === 'tsv') {
									$delimiter = DesktopUpload::detect_csv_delimiter($path);
									update_option("smack_csv_delimiter_{$event_key}", $delimiter);
								}
								echo wp_json_encode($response);
							} else {
								$response['success'] = false;
								$response['message'] = $validate_file;
								echo wp_json_encode($response);
								unlink($path);
								$wpdb->get_results("UPDATE $file_table_name SET status='Download Failed',`lock`=true WHERE id = '$lastid'");
							}
						}
					}
				} else {
					$curlCh = curl_init();
					curl_setopt($curlCh, CURLOPT_URL, $file_url);
					curl_setopt($curlCh, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curlCh, CURLOPT_FOLLOWLOCATION, true);
					curl_setopt($curlCh, CURLOPT_FAILONERROR, true);
					curl_setopt($curlCh, CURLOPT_MAXREDIRS, 10);
					curl_setopt($curlCh, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
					curl_setopt($curlCh, CURLOPT_CUSTOMREQUEST, 'GET');
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($curlCh, CURLOPT_SSL_VERIFYHOST, FALSE);

					$response = wp_remote_get($file_url, [
						'headers' => [
							'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
							'Accept' => 'application/xml,text/xml;q=0.9,*/*;q=0.8',
						],
						'timeout' => 60,
					]);

					if (is_wp_error($response)) {
						$ajax_out = array('success' => false, 'message' => $response->get_error_message());
						echo wp_json_encode($ajax_out);
						$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
						curl_close($curlCh);
					} else {
						$curlData = wp_remote_retrieve_body($response);

						if (curl_error($curlCh)) {
							$ajax_out = array('success' => false, 'message' => curl_error($curlCh));
							echo wp_json_encode($ajax_out);
							$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
						} else {
							if ($file_extension == 'xlsx' || $file_extension == 'xls') {
								$this->convertXlsxToCsv($curlData, $upload_dir_path, $event_key);
								chmod($path, 0777);
								$file_extension = 'csv';
							} else {
								$file = fopen($path, "w+");
								fputs($file, $curlData);
								chmod($path, 0777);
								fclose($file);
							}
							$validate_file = $validate_instance->file_validation($path, $file_extension);

							$file_size = filesize($path);
							$filesize = $validate_instance->formatSizeUnits($file_size);

							if ($validate_file == "yes") {
								$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
								$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
								$template_name = substr($url_file_name, 0, strpos($url_file_name, "."));
								$response['success'] = true;
								$response['filename'] = $url_file_name;
								$response['hashkey'] = $event_key;
								$response['posttype'] = $get_result['Post Type'];
								$response['taxonomy'] = $get_result['Taxonomy'];
						$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
						$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
								$response['selectedtype'] = $get_result['selected type'];
								$response['file_type'] = $file_extension;
								$response['file_size'] = $filesize;
								$response['templatename'] = $template_name;
								$response['message'] = 'success';
								if ($file_extension === 'csv' || $file_extension === 'tsv') {
									$delimiter = DesktopUpload::detect_csv_delimiter($path);
									update_option("smack_csv_delimiter_{$event_key}", $delimiter);
								}
								echo wp_json_encode($response);
							} else {
								$response['success'] = false;
								$response['message'] = $validate_file;
								echo wp_json_encode($response);
								unlink($path);
								$wpdb->get_results("UPDATE $file_table_name SET status='Download Failed',`lock`=true WHERE id = '$lastid'");
							}
						}
						curl_close($curlCh);
					}
				}
			} else {
				$response['success'] = false;
				$response['message'] = "Please create Upload folder with writable permission";
				echo wp_json_encode($response);
			}
		} else {
			$response['success'] = false;
			$response['message'] = $validate_format;
			echo wp_json_encode($response);
		}
		wp_die();
	}

	public static function get_original_url($url)
	{
		$url = str_replace(' ', '%20', $url);
		return $url;
	}

	// public function get_filename_from_headers($file_full_name){	
	// 	$arr = explode('filename=', $file_full_name);
	// 	$url_full_file_name = explode('.', $arr[1]);
	// 	$url_extension = substr($arr[1], strpos($arr[1], '.') + strlen('.'), 3);
	// 	$file_name = $url_full_file_name[0] . '.' . $url_extension;
	// 	$file_explode=explode('"',$file_name);
	// 	if(isset($file_explode[1])){
	// 		return $file_explode[1];
	// 	}
	// 	else{
	// 		return $file_explode[0];
	// 	}
	// }

	public function get_filename_from_headers($file_full_name)
	{
		// Extract the filename part
		preg_match('/filename\*?=([^;]+)/', $file_full_name, $matches);

		if (!empty($matches[1])) {
			$filename = trim($matches[1], " \"");
			// Handle cases with encoded filenames (filename*=UTF-8'')
			if (strpos($filename, "UTF-8''") === 0) {
				$filename = urldecode(substr($filename, 7)); // Decode URL-encoded filename
			}
		} else {
			return '';
		}
		return $filename;
	}


	public function unshorten_bitly_url($url)
	{
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
			CURLOPT_FOLLOWLOCATION => TRUE,
			CURLOPT_RETURNTRANSFER => TRUE,
			CURLOPT_SSL_VERIFYHOST => FALSE, // suppress certain SSL errors
			CURLOPT_SSL_VERIFYPEER => FALSE,
		));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_exec($ch);
		$url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		curl_close($ch);
		return $url;
	}

	/**
	 * Data feeds that encode format in the path (e.g. Awin .../format/csv/...) must win over
	 * fragile body sniffing (gzip/binary or API noise can look like JSON).
	 */
	private function apply_url_path_format_hint($file_url, $url_file_name)
	{
		$supported_file = array('csv', 'xml', 'zip', 'txt', 'json', 'tsv');
		if (!preg_match('#/format/(csv|tsv|xml|json|txt)(/|$|\?)#i', $file_url, $match)) {
			return $url_file_name;
		}
		$fmt = strtolower($match[1]);
		if (!in_array($fmt, $supported_file, true)) {
			return $url_file_name;
		}
		$base = pathinfo($url_file_name, PATHINFO_FILENAME);
		if ($base === '' || $base === '.') {
			$base = 'upload';
		}
		return $base . '.' . $fmt;
	}

	private function maybe_download_google_sheet_with_oauth($file_url, $path)
	{
		if (!strstr($file_url, 'https://docs.google.com/spreadsheets/d/')) {
			return array('used' => false, 'success' => false);
		}

		// Published /pub and /d/e/2PACX IDs are NOT valid Sheets API spreadsheetIds.
		// Fall through so HTTP download can fetch the public CSV directly.
		if ($this->is_google_sheets_published_url($file_url)) {
			return array('used' => false, 'success' => false);
		}

		if (!preg_match('/docs\.google\.com\/spreadsheets\/d\/([^\/\?]+)/', $file_url, $match)) {
			return array('used' => false, 'success' => false);
		}
		$sheet_id = $match[1];
		// Guard: published-path segment "e" or 2PACX publish ids must never hit the API.
		if ($sheet_id === 'e' || stripos($sheet_id, '2PACX-') === 0) {
			return array('used' => false, 'success' => false);
		}
		$gid = null;
		if (preg_match('/[?&]gid=([0-9]+)/', $file_url, $gid_match)) {
			$gid = $gid_match[1];
		}

		$access_token = $this->get_gsheet_oauth_access_token();
		if (empty($access_token)) {
			return array('used' => true, 'success' => false, 'message' => 'Google OAuth token unavailable. Reconnect Google Sheets.');
		}

		$meta_url = "https://sheets.googleapis.com/v4/spreadsheets/{$sheet_id}?fields=sheets.properties";
		$meta_res = GoogleSheetsHttpTransport::remote_get($meta_url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Accept' => 'application/json',
			),
			'timeout' => 30,
		));
		if (is_wp_error($meta_res)) {
			return array('used' => true, 'success' => false, 'message' => $meta_res->get_error_message());
		}
		$meta = json_decode(wp_remote_retrieve_body($meta_res), true);
		if (isset($meta['error'])) {
			return array('used' => true, 'success' => false, 'message' => 'Google Sheets metadata error');
		}
		$sheets = isset($meta['sheets']) && is_array($meta['sheets']) ? $meta['sheets'] : array();
		if (empty($sheets)) {
			return array('used' => true, 'success' => false, 'message' => 'No sheet tabs returned by Google API');
		}

		$sheet_title = $sheets[0]['properties']['title'];
		if (!empty($gid)) {
			foreach ($sheets as $sheet) {
				$props = isset($sheet['properties']) ? $sheet['properties'] : array();
				if (isset($props['sheetId']) && (string) $props['sheetId'] === (string) $gid) {
					$sheet_title = $props['title'];
					break;
				}
			}
		}

		$range = rawurlencode($sheet_title);
		$values_url = "https://sheets.googleapis.com/v4/spreadsheets/{$sheet_id}/values/{$range}?majorDimension=ROWS";
		$values_res = GoogleSheetsHttpTransport::remote_get($values_url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Accept' => 'application/json',
			),
			'timeout' => 60,
		));
		if (is_wp_error($values_res)) {
			return array('used' => true, 'success' => false, 'message' => $values_res->get_error_message());
		}
		$values_body = json_decode(wp_remote_retrieve_body($values_res), true);
		if (isset($values_body['error'])) {
			return array('used' => true, 'success' => false, 'message' => 'Google Sheets values error');
		}
		$values = isset($values_body['values']) && is_array($values_body['values']) ? $values_body['values'] : array();
		if (empty($values)) {
			return array('used' => true, 'success' => false, 'message' => 'Google Sheet has no data rows');
		}

		$fp = fopen('php://temp', 'r+');
		foreach ($values as $row) {
			fputcsv($fp, $row);
		}
		rewind($fp);
		$csv_data = stream_get_contents($fp);
		fclose($fp);

		file_put_contents($path, $csv_data);
		chmod($path, 0777);
		$sheet_filename = sanitize_file_name($sheet_title);
		if ($sheet_filename === '') {
			$sheet_filename = 'google-sheet-' . $sheet_id;
		}
		if (strtolower(pathinfo($sheet_filename, PATHINFO_EXTENSION)) !== 'csv') {
			$sheet_filename .= '.csv';
		}
		return array('used' => true, 'success' => true, 'file_name' => $sheet_filename);
	}

	private function get_gsheet_oauth_access_token()
	{
		$credentials = maybe_unserialize(get_option('gsheetlisting_oauth_credentials'));
		if (!is_array($credentials) || empty($credentials['access_token'])) {
			return '';
		}
		$expiry = isset($credentials['expires_in']) ? (int) $credentials['expires_in'] : 0;
		if ($expiry > 0 && $expiry > time() + 300) {
			return $credentials['access_token'];
		}
		if (empty($credentials['refresh_token']) || empty($credentials['client_id']) || empty($credentials['client_secret'])) {
			return $credentials['access_token'];
		}
		$refresh_res = GoogleSheetsHttpTransport::remote_post('https://oauth2.googleapis.com/token', array(
			'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
			'body' => http_build_query(array(
				'client_id' => $credentials['client_id'],
				'client_secret' => $credentials['client_secret'],
				'refresh_token' => $credentials['refresh_token'],
				'grant_type' => 'refresh_token',
			)),
			'timeout' => 30,
		));
		if (is_wp_error($refresh_res)) {
			return $credentials['access_token'];
		}
		$refresh_body = json_decode(wp_remote_retrieve_body($refresh_res), true);
		if (isset($refresh_body['access_token'])) {
			$credentials['access_token'] = sanitize_text_field($refresh_body['access_token']);
			$credentials['expires_in'] = time() + intval($refresh_body['expires_in']);
			update_option('gsheetlisting_oauth_credentials', maybe_serialize($credentials));
			return $credentials['access_token'];
		}
		return $credentials['access_token'];
	}

	/**
	 * Generic HTTPS feeds (not Google Sheets / Dropbox) use streaming + gzip handling.
	 */
	/**
	 * Preserve gdrive:// and onedrive:// pseudo-URLs (not in wp_allowed_protocols by default).
	 *
	 * @param string $url
	 * @return string
	 */
	private function sanitize_import_url($url)
	{
		$url = is_string($url) ? trim(wp_unslash($url)) : '';
		if ($url === '') {
			return '';
		}
		if (preg_match('#^(gdrive|onedrive)://#i', $url)) {
			return esc_url_raw($url, array('gdrive', 'onedrive', 'http', 'https'));
		}
		return esc_url_raw($url);
	}

	private function is_generic_remote_url_import($file_url)
	{
		if (RemoteSourceProviderRegistry::is_remote_provider_url($file_url)) {
			return false;
		}
		if (strstr($file_url, 'https://docs.google.com/')) {
			return false;
		}
		if (strstr($file_url, 'https://www.dropbox.com/')) {
			return false;
		}
		return true;
	}

	private function maybe_download_remote_provider_with_oauth($file_url, $path)
	{
		return RemoteSourceProviderRegistry::download_for_import($file_url, $path);
	}

	private function finalize_remote_provider_ajax_download($remote_provider_download, $path, $upload_dir_path, $event_key, $url_file_name, $file_extension, $lastid, $file_table_name, $validate_instance)
	{
		global $wpdb;
		$response = array();

		if (empty($remote_provider_download['success'])) {
			$response['success'] = false;
			$response['message'] = isset($remote_provider_download['message']) ? $remote_provider_download['message'] : 'Remote provider download failed';
			echo wp_json_encode($response);
			$wpdb->get_results("UPDATE $file_table_name SET status='Download_Failed' WHERE id = '$lastid'");
			wp_die();
		}

		if (!empty($remote_provider_download['file_name'])) {
			$url_file_name = $this->normalize_file_name_for_db(
				$remote_provider_download['file_name'],
				pathinfo($remote_provider_download['file_name'], PATHINFO_EXTENSION) ?: 'csv'
			);
			$file_extension = pathinfo($url_file_name, PATHINFO_EXTENSION);
			$wpdb->update($file_table_name, array('file_name' => $url_file_name), array('id' => $lastid));
		}

		if ($file_extension === 'xlsx' || $file_extension === 'xls') {
			$this->convertXlsxToCsv('', $upload_dir_path, $event_key);
			chmod($path, 0777);
			$file_extension = 'csv';
		}

		$validate_file = $validate_instance->file_validation($path, $file_extension);
		$file_size = filesize($path);
		$filesize = $validate_instance->formatSizeUnits($file_size);
		if ($validate_file == "yes") {
			$wpdb->get_results("UPDATE $file_table_name SET status='Downloaded',`lock`=false WHERE id = '$lastid'");
			$get_result = $validate_instance->import_record_function($event_key, $url_file_name);
			$template_name = substr($url_file_name, 0, strpos($url_file_name, "."));
			$response['success'] = true;
			$response['filename'] = $url_file_name;
			$response['hashkey'] = $event_key;
			$response['posttype'] = $get_result['Post Type'];
			$response['taxonomy'] = $get_result['Taxonomy'];
			$response['posttype_labels'] = $get_result['Post Type Labels'] ?? array();
			$response['taxonomy_labels'] = $get_result['Taxonomy Labels'] ?? array();
			$response['selectedtype'] = $get_result['selected type'];
			$response['file_type'] = $file_extension;
			$response['file_size'] = $filesize;
			$response['templatename'] = $template_name;
			$response['message'] = 'success';
			if ($file_extension === 'csv' || $file_extension === 'tsv') {
				$delimiter = DesktopUpload::detect_csv_delimiter($path);
				update_option("smack_csv_delimiter_{$event_key}", $delimiter);
			}
			echo wp_json_encode($response);
			wp_die();
		}

		$response['success'] = false;
		$response['message'] = $validate_file;
		echo wp_json_encode($response);
		wp_die();
	}

	/**
	 * Download to disk: WordPress stream with retries on 5xx / transport errors, then cURL stream.
	 *
	 * @return array{part_path?:string,headers?:mixed,code?:int,error?:\WP_Error}
	 */
	private function download_remote_to_file($file_url, $final_path)
	{
		$part_path = $final_path . '.part';
		$last_error = null;
		for ($attempt = 1; $attempt <= 3; $attempt++) {
			$permissive_accept = ($attempt > 1);
			$result = $this->download_via_stream($file_url, $final_path, $permissive_accept);
			if (!isset($result['error'])) {
				return $result;
			}
			$last_error = $result['error'];
			@unlink($part_path);
			$retry = false;
			if (is_wp_error($last_error)) {
				$msg = $last_error->get_error_message();
				$code = $last_error->get_error_code();
				if ($code === 'http_error' && preg_match('/HTTP\\s+5\\d\\d/', $msg)) {
					$retry = true;
				} elseif ($code === 'http_request_failed') {
					$retry = true;
				}
			}
			if ($retry && $attempt < 3) {
				sleep(2);
				continue;
			}
			break;
		}
		if (!function_exists('curl_init')) {
			return array('error' => $last_error ? $last_error : new \WP_Error('download', 'Download failed'));
		}
		return $this->download_via_curl_stream($file_url, $final_path);
	}

	/**
	 * Stream response body to disk via cURL (no full-body string; CURLOPT_FILE).
	 *
	 * @return array{part_path?:string,headers?:mixed,code?:int,error?:\WP_Error}
	 */
	private function download_via_curl_stream($file_url, $final_path)
	{
		$part_path = $final_path . '.part';
		if (file_exists($part_path)) {
			@unlink($part_path);
		}
		$fp = @fopen($part_path, 'wb');
		if (!$fp) {
			return array('error' => new \WP_Error('io', 'Cannot open temp file for download'));
		}
		$ch = curl_init($file_url);
		curl_setopt_array(
			$ch,
			array(
				CURLOPT_FILE => $fp,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 300,
				CURLOPT_CONNECTTIMEOUT => 30,
				CURLOPT_SSL_VERIFYPEER => false,
				CURLOPT_SSL_VERIFYHOST => false,
				CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
				CURLOPT_HTTPHEADER => array(
					'Accept: */*',
				),
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			)
		);
		$ok = curl_exec($ch);
		$http_code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
		$curl_err = curl_error($ch);
		curl_close($ch);
		fclose($fp);
		if (!$ok || $http_code < 200 || $http_code >= 300) {
			if (file_exists($part_path)) {
				$sz = filesize($part_path);
				if (false !== $sz && $sz > 0 && $sz <= 65536) {
					$snippet = (string) @file_get_contents($part_path, false, null, 0, 1500);
					$snippet = preg_replace('/\s+/', ' ', $snippet);
				}
			}
			@unlink($part_path);
			$msg = $curl_err !== '' ? $curl_err : 'HTTP ' . $http_code;
			return array('error' => new \WP_Error('curl_download', $msg));
		}
		if (!file_exists($part_path) || !filesize($part_path)) {
			@unlink($part_path);
			return array('error' => new \WP_Error('download', 'Empty file after cURL'));
		}
		$headers = array(
			'content-type' => $ctype ? (string) $ctype : '',
		);
		return array('part_path' => $part_path, 'headers' => $headers, 'code' => $http_code);
	}

	/**
	 * Stream response body to disk via wp_remote_get (does not load entire body into PHP memory).
	 *
	 * @param bool $permissive_accept If true, send broad Accept header (some CDNs misbehave otherwise).
	 * @return array{part_path?:string,headers?:mixed,code?:int,error?:\WP_Error}
	 */
	private function download_via_stream($file_url, $final_path, $permissive_accept = false)
	{
		$part_path = $final_path . '.part';
		if (file_exists($part_path)) {
			@unlink($part_path);
		}
		$accept = $permissive_accept
			? '*/*'
			: 'text/csv,text/plain,text/xml,application/xml,application/json,application/gzip,*/*;q=0.8';
		$response = wp_remote_get(
			$file_url,
			array(
				'timeout' => 300,
				'stream' => true,
				'filename' => $part_path,
				'redirection' => 10,
				'sslverify' => false,
				'headers' => array(
					'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
					'Accept' => $accept,
				),
			)
		);
		if (is_wp_error($response)) {
			@unlink($part_path);
			return array('error' => $response);
		}
		$code = wp_remote_retrieve_response_code($response);
		$headers = wp_remote_retrieve_headers($response);
		$ctype = '';
		$enc = '';
		if (is_object($headers)) {
			$ctype = isset($headers['content-type']) ? (string) $headers['content-type'] : '';
			$enc = isset($headers['content-encoding']) ? strtolower((string) $headers['content-encoding']) : '';
		} elseif (is_array($headers)) {
			$ctype = isset($headers['Content-Type']) ? (string) $headers['Content-Type'] : (isset($headers['content-type']) ? (string) $headers['content-type'] : '');
			$enc = isset($headers['Content-Encoding']) ? strtolower((string) $headers['Content-Encoding']) : '';
		}
		if ($code < 200 || $code >= 300) {
			if (file_exists($part_path)) {
				$sz = filesize($part_path);
				if (false !== $sz && $sz > 0 && $sz <= 65536) {
					$snippet = (string) @file_get_contents($part_path, false, null, 0, 1500);
					$snippet = preg_replace('/\s+/', ' ', $snippet);
				}
			}
			@unlink($part_path);
			return array('error' => new \WP_Error('http_error', 'HTTP ' . $code));
		}
		if (!file_exists($part_path)) {
			return array('error' => new \WP_Error('download', 'Temp file missing'));
		}
		return array('part_path' => $part_path, 'headers' => $headers, 'code' => $code);
	}

	/**
	 * Move part file to final path, or gunzip when body is gzip-compressed (not when already plain CSV).
	 */
	private function finalize_streamed_file($part_path, $final_path, $file_url, $headers)
	{
		if (!$part_path || !file_exists($part_path)) {
			return false;
		}
		$ctype = '';
		$enc = '';
		if ($headers) {
			if (is_object($headers)) {
				$ctype = isset($headers['content-type']) ? (string) $headers['content-type'] : '';
				$enc = isset($headers['content-encoding']) ? strtolower((string) $headers['content-encoding']) : '';
			} elseif (is_array($headers)) {
				$ctype = isset($headers['Content-Type']) ? (string) $headers['Content-Type'] : (isset($headers['content-type']) ? (string) $headers['content-type'] : '');
				$enc = isset($headers['Content-Encoding']) ? strtolower((string) $headers['Content-Encoding']) : '';
			}
		}
		$peek = @file_get_contents($part_path, false, null, 0, 4);
		$gzip_magic = ($peek !== false && strlen($peek) >= 2 && $peek[0] === "\x1f" && $peek[1] === "\x8b");
		$need_gunzip = $gzip_magic;
		if (!$need_gunzip && $ctype !== '' && (stripos($ctype, 'application/gzip') !== false || stripos($ctype, 'application/x-gzip') !== false)) {
			$need_gunzip = true;
		}

		if (!$need_gunzip) {
			@unlink($final_path);
			if (!@rename($part_path, $final_path)) {
				return false;
			}
			return true;
		}
		if (!function_exists('gzopen') || !function_exists('gzread')) {
			return false;
		}
		$out_tmp = $final_path . '.gunzip.tmp';
		if (file_exists($out_tmp)) {
			@unlink($out_tmp);
		}
		$gz = @gzopen($part_path, 'rb');
		if (!$gz) {
			return false;
		}
		$out = @fopen($out_tmp, 'wb');
		if (!$out) {
			gzclose($gz);
			return false;
		}
		while (!gzeof($gz)) {
			$buf = gzread($gz, 8192);
			if ($buf === false) {
				break;
			}
			fwrite($out, $buf);
		}
		fclose($out);
		gzclose($gz);
		@unlink($part_path);
		@unlink($final_path);
		if (!@rename($out_tmp, $final_path)) {
			return false;
		}
		return true;
	}

}