<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

/**
 * Registers custom WP-Cron intervals used by the Smart Schedule pollers.
 *
 * Import/export execution is driven exclusively by:
 * - smack_uci_cron_scheduler
 * - smack_uci_cron_scheduled_export
 *
 * Legacy per-row hooks (smack_cron_schedule_function_{id}) are cleared on init
 * because they previously pointed at onpluginsload and never ran imports.
 */
add_filter( 'cron_schedules', 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\cron_schedule_times' );
add_action( 'init', 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\cleanup_legacy_per_schedule_cron_hooks', 20 );

function cron_schedule_times( $schedules ) {
    if(!isset($schedules["smack_every_five_minutes"])){
        $schedules["smack_every_five_minutes"] = array(
            'interval'  => 300,
            'display'   => __( 'Smack Every Five Minutes' )
        );
    }

    if(!isset($schedules["wp_ultimate_csv_importer_scheduled_csv_data"])){
        $schedules["wp_ultimate_csv_importer_scheduled_csv_data"] = array(
            'interval' => 60, // seconds
            'display' => __('Check scheduled events every minute', 'wp-ultimate-csv-importer-pro')
        );
    }

    if(!isset($schedules["wp_ultimate_csv_importer_scheduled_export_data"])){
        $schedules["wp_ultimate_csv_importer_scheduled_export_data"] = array(
            'interval' => 60, // seconds
            'display' => __('Check scheduled export events every minute', 'wp-ultimate-csv-importer-pro')
        );
    }
    
    if(!isset($schedules["wp_ultimate_csv_importer_scheduled_emails"])){
        $schedules["wp_ultimate_csv_importer_scheduled_emails"] = array(
            'interval' => 60, // seconds
            'display' => __('Check scheduled email events every minute', 'wp-ultimate-csv-importer-pro')
        );
    }
    
    if(!isset($schedules["smack_every_ten_minutes"])){
        $schedules["smack_every_ten_minutes"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every Ten Minutes' )
        );
    }
    if(!isset($schedules["smack_every_fifteen_minutes"])){
        $schedules["smack_every_fifteen_minutes"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every Fifteen Minutes' )
        );
    }
    if(!isset($schedules["smack_every_thirty_minutes"])){
        $schedules["smack_every_thirty_minutes"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every Thirty Minutes' )
        );
    }
    if(!isset($schedules["smack_every_one_hour"])){
        $schedules["smack_every_one_hour"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every One hour' )
        );
    }
    if(!isset($schedules["smack_every_two_hrs"])){
        $schedules["smack_every_two_hrs"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every Two hours' )
        );
    }
    if(!isset($schedules["smack_every_four_hrs"])){
        $schedules["smack_every_four_hrs"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Every Four hours' )
        );
    }
    if(!isset($schedules["smack_daily"])){
        $schedules["smack_daily"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Daily' )
        );
    }
    if(!isset($schedules["smack_weekly"])){
        $schedules["smack_weekly"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Weekly' )
        );
    }
    if(!isset($schedules["smack_monthly"])){
        $schedules["smack_monthly"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Monthly' )
        );
    }
    if(!isset($schedules["smack_one_time"])){
        $schedules["smack_one_time"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack One Time' )
        );
    }
    if(!isset($schedules["smack_image_every_second"])){
        $schedules["smack_image_every_second"] = array(
            'interval'  => 60,
            'display'   => __( 'Smack Image Every Second' )
        );
    }
    return $schedules;
}

/**
 * Clear legacy per-schedule WP-Cron events that called onpluginsload instead of the import runner.
 * Execution is owned by smack_uci_cron_scheduler / smack_uci_cron_scheduled_export pollers.
 */
function cleanup_legacy_per_schedule_cron_hooks() {
    if ( ! function_exists( 'is_plugin_active' ) || ! is_plugin_active( 'wp-ultimate-csv-importer-pro/wp-ultimate-csv-importer-pro.php' ) ) {
        return;
    }

    // Run at most once per hour to avoid scanning cron on every request.
    $transient_key = 'sm_uci_pro_legacy_schedule_cron_cleaned';
    if ( get_transient( $transient_key ) ) {
        return;
    }

    $crons = _get_cron_array();
    if ( empty( $crons ) || ! is_array( $crons ) ) {
        set_transient( $transient_key, 1, HOUR_IN_SECONDS );
        return;
    }

    foreach ( $crons as $timestamp => $hooks ) {
        if ( ! is_array( $hooks ) ) {
            continue;
        }
        foreach ( array_keys( $hooks ) as $hook ) {
            if ( is_string( $hook ) && 0 === strpos( $hook, 'smack_cron_schedule_function_' ) ) {
                wp_clear_scheduled_hook( $hook );
            }
        }
    }

    set_transient( $transient_key, 1, HOUR_IN_SECONDS );
}
