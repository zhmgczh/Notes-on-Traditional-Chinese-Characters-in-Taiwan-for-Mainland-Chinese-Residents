<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class WooFetcher
{
    public static function get_products($offset = 0, $limit = 50)
    {
        global $wpdb;
        $query = $wpdb->prepare("
            SELECT ID, post_title, post_content, post_excerpt, post_status, post_type, post_parent 
            FROM {$wpdb->posts} 
            WHERE post_type = 'product' 
            AND post_status IN ('publish', 'private') 
            ORDER BY ID ASC 
            LIMIT %d OFFSET %d
        ", $limit, $offset);

        $posts = $wpdb->get_results($query);
        $products = [];
        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID);

            // Get categories & tags
            $cat_terms = wp_get_post_terms($post->ID, 'product_cat');
            $tag_terms = wp_get_post_terms($post->ID, 'product_tag');
            $categories = [];

            if (!is_wp_error($cat_terms) && !empty($cat_terms)) {
                foreach ($cat_terms as $term) {
                    $categories[] = [
                        'id'          => $term->term_id,
                        'name'        => $term->name,
                        'slug'        => $term->slug,
                        'description' => $term->description,
                        'taxonomy'    => 'product_cat',
                    ];
                }
            }

            if (!is_wp_error($tag_terms) && !empty($tag_terms)) {
                foreach ($tag_terms as $term) {
                    $categories[] = [
                        'id'          => $term->term_id,
                        'name'        => $term->name,
                        'slug'        => $term->slug,
                        'description' => $term->description,
                        'taxonomy'    => 'product_tag',
                    ];
                }
            }

            // Get product type
            $type_terms = wp_get_post_terms($post->ID, 'product_type');
            $product_type = 'simple';
            if (!is_wp_error($type_terms) && !empty($type_terms)) {
                $product_type = $type_terms[0]->slug;
            }

            // Prepare featured image URL
            $featured_image_url = '';
            $thumbnail_id = isset($meta['_thumbnail_id']) ? (int) $meta['_thumbnail_id'][0] : 0;
            if ($thumbnail_id) {
                $featured_image_url = wp_get_attachment_url($thumbnail_id);
            }

            // Prepare gallery image URLs
            $gallery_image_urls = [];
            $gallery_ids_str = isset($meta['_product_image_gallery']) ? $meta['_product_image_gallery'][0] : '';
            if (!empty($gallery_ids_str)) {
                $gallery_ids = explode(',', $gallery_ids_str);
                foreach ($gallery_ids as $gid) {
                    $url = wp_get_attachment_url($gid);
                    if ($url) {
                        $gallery_image_urls[] = [
                            'id' => (int) $gid,
                            'url' => $url
                        ];
                    }
                }
            }

            $product_data = [
                'ID' => $post->ID,
                'post_title' => $post->post_title,
                'post_content' => $post->post_content,
                'post_excerpt' => $post->post_excerpt,
                'post_status' => $post->post_status,
                'post_type' => $post->post_type,
                'post_parent' => $post->post_parent,
                '_price' => isset($meta['_price']) ? $meta['_price'][0] : '',
                '_regular_price' => isset($meta['_regular_price']) ? $meta['_regular_price'][0] : '',
                '_sale_price' => isset($meta['_sale_price']) ? $meta['_sale_price'][0] : '',
                '_sku' => isset($meta['_sku']) ? $meta['_sku'][0] : '',
                '_stock' => isset($meta['_stock']) ? $meta['_stock'][0] : '',
                '_manage_stock' => isset($meta['_manage_stock']) ? $meta['_manage_stock'][0] : 'no',
                '_backorders' => isset($meta['_backorders']) ? $meta['_backorders'][0] : 'no',
                '_virtual' => isset($meta['_virtual']) ? $meta['_virtual'][0] : 'no',
                '_thumbnail_id' => $thumbnail_id,
                'featured_image_url' => $featured_image_url,
                'gallery_images' => $gallery_image_urls,
                '_product_attributes' => isset($meta['_product_attributes']) ? maybe_unserialize($meta['_product_attributes'][0]) : [],
                '_weight' => isset($meta['_weight']) ? $meta['_weight'][0] : '',
                '_length' => isset($meta['_length']) ? $meta['_length'][0] : '',
                '_width' => isset($meta['_width']) ? $meta['_width'][0] : '',
                '_height' => isset($meta['_height']) ? $meta['_height'][0] : '',
                'categories' => $categories,
                'product_type' => $product_type,
                '_children' => isset($meta['_children']) ? maybe_unserialize($meta['_children'][0]) : [],
                '_downloadable' => isset($meta['_downloadable']) ? $meta['_downloadable'][0] : 'no',
                '_download_limit' => isset($meta['_download_limit']) ? $meta['_download_limit'][0] : '',
                '_download_expiry' => isset($meta['_download_expiry']) ? $meta['_download_expiry'][0] : '',
                '_downloadable_files' => isset($meta['_downloadable_files']) ? maybe_unserialize($meta['_downloadable_files'][0]) : [],
            ];
            $products[] = $product_data;
        }
        return $products;
    }

    public static function get_customers($offset = 0, $limit = 50)
    {
        global $wpdb;
        $capabilities_key = $wpdb->prefix . 'capabilities';
        $query = $wpdb->prepare("
            SELECT u.ID, u.user_email, u.user_registered 
            FROM {$wpdb->users} u
            INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id 
            WHERE um.meta_key = %s AND um.meta_value LIKE %s
            ORDER BY u.ID ASC 
            LIMIT %d OFFSET %d
        ", $capabilities_key, '%customer%', $limit, $offset);

        $users = $wpdb->get_results($query);
        $customers = [];
        foreach ($users as $user) {
            $meta = get_user_meta($user->ID);
            $customer_data = [
                'ID' => $user->ID,
                'user_email' => $user->user_email,
                'billing_first_name' => isset($meta['billing_first_name']) ? $meta['billing_first_name'][0] : '',
                'billing_last_name' => isset($meta['billing_last_name']) ? $meta['billing_last_name'][0] : '',
                'billing_phone' => isset($meta['billing_phone']) ? $meta['billing_phone'][0] : '',
                'billing_address_1' => isset($meta['billing_address_1']) ? $meta['billing_address_1'][0] : '',
                'billing_address_2' => isset($meta['billing_address_2']) ? $meta['billing_address_2'][0] : '',
                'billing_city' => isset($meta['billing_city']) ? $meta['billing_city'][0] : '',
                'billing_state' => isset($meta['billing_state']) ? $meta['billing_state'][0] : '',
                'billing_postcode' => isset($meta['billing_postcode']) ? $meta['billing_postcode'][0] : '',
                'billing_country' => isset($meta['billing_country']) ? $meta['billing_country'][0] : '',
                'billing_company' => isset($meta['billing_company']) ? $meta['billing_company'][0] : '',
                'shipping_first_name' => isset($meta['shipping_first_name']) ? $meta['shipping_first_name'][0] : '',
                'shipping_last_name' => isset($meta['shipping_last_name']) ? $meta['shipping_last_name'][0] : '',
                'shipping_company' => isset($meta['shipping_company']) ? $meta['shipping_company'][0] : '',
                'shipping_address_1' => isset($meta['shipping_address_1']) ? $meta['shipping_address_1'][0] : '',
                'shipping_address_2' => isset($meta['shipping_address_2']) ? $meta['shipping_address_2'][0] : '',
                'shipping_city' => isset($meta['shipping_city']) ? $meta['shipping_city'][0] : '',
                'shipping_state' => isset($meta['shipping_state']) ? $meta['shipping_state'][0] : '',
                'shipping_postcode' => isset($meta['shipping_postcode']) ? $meta['shipping_postcode'][0] : '',
                'shipping_country' => isset($meta['shipping_country']) ? $meta['shipping_country'][0] : '',
                'shipping_phone' => isset($meta['shipping_phone']) ? $meta['shipping_phone'][0] : '',
            ];
            $customers[] = $customer_data;
        }
        return $customers;
    }

    public static function get_orders($offset = 0, $limit = 50)
    {
        $args = array(
            'limit' => $limit,
            'offset' => $offset,
            'orderby' => 'id',
            'order' => 'ASC',
            'return' => 'objects',
            'status' => 'any'
        );
        $wc_orders = wc_get_orders($args);

        $orders = [];
        foreach ($wc_orders as $wc_order) {
            $line_items = [];
            foreach ($wc_order->get_items() as $item_id => $item) {
                $line_items[] = [
                    'name'         => $item->get_name(),
                    'product_id'   => $item->get_product_id(),
                    'variation_id' => $item->get_variation_id(),
                    'quantity'     => $item->get_quantity(),
                    'subtotal'     => $item->get_subtotal(),
                    'total'        => $item->get_total(),
                ];
            }

            $order_data = [
                'ID'                   => $wc_order->get_id(),
                'status'               => $wc_order->get_status(),
                'currency'             => $wc_order->get_currency(),
                'coupon_ids'           => array_map(function($code) {
                    $coupon_id = wc_get_coupon_id_by_code($code);
                    return $coupon_id ? $coupon_id : null;
                }, $wc_order->get_coupon_codes()),
                'date_created'         => $wc_order->get_date_created() ? $wc_order->get_date_created()->date('Y-m-d H:i:s') : '',
                'date_paid'            => $wc_order->get_date_paid() ? $wc_order->get_date_paid()->date('Y-m-d H:i:s') : '',
                '_customer_user'       => $wc_order->get_customer_id(),
                '_order_total'         => $wc_order->get_total(),
                '_payment_method'      => $wc_order->get_payment_method(),
                '_payment_method_title' => $wc_order->get_payment_method_title(),
                '_transaction_id'      => $wc_order->get_transaction_id(),
                'customer_note'        => $wc_order->get_customer_note(),
                'billing_email'        => $wc_order->get_billing_email(),
                'line_items'           => $line_items,
                'billing_address' => [
                    'name' => trim($wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name()),
                    'line_1' => $wc_order->get_billing_address_1(),
                    'line_2' => $wc_order->get_billing_address_2(),
                    'city' => $wc_order->get_billing_city(),
                    'state' => $wc_order->get_billing_state(),
                    'country' => $wc_order->get_billing_country(),
                    'postal_code' => $wc_order->get_billing_postcode(),
                ],
                'shipping_address' => [
                    'name' => trim($wc_order->get_shipping_first_name() . ' ' . $wc_order->get_shipping_last_name()),
                    'line_1' => $wc_order->get_shipping_address_1(),
                    'line_2' => $wc_order->get_shipping_address_2(),
                    'city' => $wc_order->get_shipping_city(),
                    'state' => $wc_order->get_shipping_state(),
                    'country' => $wc_order->get_shipping_country(),
                    'postal_code' => $wc_order->get_shipping_postcode(),
                ],
                'coupons' => $wc_order->get_coupon_codes(),
            ];
            $orders[] = $order_data;
        }
        return $orders;
    }

    public static function get_subscriptions($offset = 0, $limit = 50)
    {
        global $wpdb;
        $query = $wpdb->prepare("
            SELECT ID, post_status, post_date, post_parent 
            FROM {$wpdb->posts} 
            WHERE post_type = 'shop_subscription' 
            ORDER BY ID ASC 
            LIMIT %d OFFSET %d
        ", $limit, $offset);

        $posts = $wpdb->get_results($query);
        $subscriptions = [];
        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID);

            $subscriptions[] = [
                'ID' => $post->ID,
                'status' => str_replace('wc-', '', $post->post_status),
                'parent_order_id' => $post->post_parent,
                '_customer_user' => isset($meta['_customer_user']) ? $meta['_customer_user'][0] : 0,
                '_billing_period' => isset($meta['_billing_period']) ? $meta['_billing_period'][0] : '',
                '_billing_interval' => isset($meta['_billing_interval']) ? $meta['_billing_interval'][0] : 1,
                '_schedule_next_payment' => isset($meta['_schedule_next_payment']) ? $meta['_schedule_next_payment'][0] : '',
                '_payment_method' => isset($meta['_payment_method']) ? $meta['_payment_method'][0] : '',
                // Ensure array index 0 exists
                '_payment_method_title' => isset($meta['_payment_method_title']) ? (is_array($meta['_payment_method_title']) ? $meta['_payment_method_title'][0] : $meta['_payment_method_title']) : '',
                '_stripe_customer_id' => isset($meta['_stripe_customer_id']) ? (is_array($meta['_stripe_customer_id']) ? $meta['_stripe_customer_id'][0] : $meta['_stripe_customer_id']) : '',
                '_stripe_source_id' => isset($meta['_stripe_source_id']) ? (is_array($meta['_stripe_source_id']) ? $meta['_stripe_source_id'][0] : $meta['_stripe_source_id']) : '',
            ];
        }
        return $subscriptions;
    }

    public static function get_coupons($offset = 0, $limit = 50)
    {
        global $wpdb;
        $query = $wpdb->prepare("
            SELECT ID, post_title, post_excerpt, post_status 
            FROM {$wpdb->posts} 
            WHERE post_type = 'shop_coupon' 
            AND post_status IN ('publish', 'private') 
            ORDER BY ID ASC 
            LIMIT %d OFFSET %d
        ", $limit, $offset);

        $posts = $wpdb->get_results($query);
        $coupons = [];
        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID);
            
                $raw_p_ids = isset($meta['product_ids']) ? $meta['product_ids'][0] : '';
                $raw_e_ids = isset($meta['exclude_product_ids']) ? $meta['exclude_product_ids'][0] : '';
                $raw_emails = isset($meta['customer_email']) ? $meta['customer_email'][0] : '';

                $coupons[] = [
                    'ID' => $post->ID,
                    'code' => $post->post_title,
                    'description' => $post->post_excerpt,
                    'discount_type' => isset($meta['discount_type']) ? $meta['discount_type'][0] : 'fixed_cart',
                    'coupon_amount' => isset($meta['coupon_amount']) ? $meta['coupon_amount'][0] : '0',
                    'usage_limit' => isset($meta['usage_limit']) ? $meta['usage_limit'][0] : '',
                    'usage_limit_per_user' => isset($meta['usage_limit_per_user']) ? $meta['usage_limit_per_user'][0] : '',
                    'expiry_date' => isset($meta['date_expires']) ? $meta['date_expires'][0] : (isset($meta['expiry_date']) ? $meta['expiry_date'][0] : ''),
                    'free_shipping' => isset($meta['free_shipping']) ? $meta['free_shipping'][0] : 'no',
                    'minimum_amount' => isset($meta['minimum_amount']) ? $meta['minimum_amount'][0] : '',
                    'maximum_amount' => isset($meta['maximum_amount']) ? $meta['maximum_amount'][0] : '',
                    'product_ids' => !empty($raw_p_ids) ? (is_serialized($raw_p_ids) ? maybe_unserialize($raw_p_ids) : explode(',', $raw_p_ids)) : [],
                    'exclude_product_ids' => !empty($raw_e_ids) ? (is_serialized($raw_e_ids) ? maybe_unserialize($raw_e_ids) : explode(',', $raw_e_ids)) : [],
                    'customer_email' => !empty($raw_emails) ? (is_serialized($raw_emails) ? maybe_unserialize($raw_emails) : explode(',', $raw_emails)) : [],
                    'wcs_number_payments' => isset($meta['_wcs_number_payments']) ? $meta['_wcs_number_payments'][0] : '',
                ];
        }
        return $coupons;
    }

    public static function get_product_attribute($product_id){
        $product = wc_get_product($product_id);
        $all_attributes = [];

        if ($product) {
            $attributes = $product->get_attributes();

            foreach ($attributes as $attribute) {

                if ($attribute->is_taxonomy()) {
                    $options = wc_get_product_terms($product_id, $attribute->get_name(), ['fields' => 'names']);
                } else {
                    $options = $attribute->get_options();
                }

                $all_attributes[] = [
                    'name'      => $attribute->get_name(),
                    'options'   => $options,
                    'position'  => $attribute->get_position(),
                    'visible'   => $attribute->get_visible(),
                    'variation' => $attribute->get_variation()
                ];
            }
        }
        return $all_attributes;
    }

    public static function get_variations($wc_id)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT ID, post_title FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'product_variation'", $wc_id));
    }

    public static function get_product_variation_meta_data($wc_var_id)
    {
        $meta = get_post_meta($wc_var_id);

        // Return full meta so ProductMigrator can use the same logic/keys if needed, or structured ones
        $result = [];
        foreach ($meta as $key => $values) {
            $result[$key] = $values[0];
        }

        // Add some helper flattened fields too
        $result['manage_stock'] = isset($meta['_manage_stock']) && $meta['_manage_stock'][0] === 'yes';
        $result['stock_qty'] = isset($meta['_stock']) && $meta['_stock'][0] !== '' ? (int) $meta['_stock'][0] : null;
        $result['sku'] = isset($meta['_sku']) ? $meta['_sku'][0] : '';
        $result['price'] = isset($meta['_price']) ? $meta['_price'][0] : '';
        $result['regular_price'] = isset($meta['_regular_price']) ? $meta['_regular_price'][0] : '';
        $result['sale_price'] = isset($meta['_sale_price']) ? $meta['_sale_price'][0] : '';
        $result['_sale_price'] = isset($meta['_sale_price']) ? $meta['_sale_price'][0] : '';
        $result['_downloadable'] = isset($meta['_downloadable']) ? $meta['_downloadable'][0] : 'no';
        $result['_download_limit'] = isset($meta['_download_limit']) ? $meta['_download_limit'][0] : '';
        $result['_download_expiry'] = isset($meta['_download_expiry']) ? $meta['_download_expiry'][0] : '';
        $result['_downloadable_files'] = isset($meta['_downloadable_files']) ? maybe_unserialize($meta['_downloadable_files'][0]) : [];

        return $result;
    }

    
    public static function get_count($module)
    {
        global $wpdb;
        $type = '';
        if ($module === 'products') {
            $type = "IN ('product') AND post_status IN ('publish', 'private')";
        } elseif ($module === 'orders') {
            if (function_exists('wc_get_orders')) {
                $orders = wc_get_orders([
                    'limit' => -1,
                    'return' => 'ids',
                    'status' => 'any',
                ]);
                return count($orders);
            }
            $type = "= 'shop_order'";
        } elseif ($module === 'subscriptions') {
            $type = "= 'shop_subscription'";
        } elseif ($module === 'coupons') {
            $type = "= 'shop_coupon'";
        }

        if ($module === 'customers') {
            $capabilities_key = $wpdb->prefix . 'capabilities';
            return $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id WHERE um.meta_key = %s AND um.meta_value LIKE %s",
                $capabilities_key, '%customer%'
            ));
        }

        if ($type) {
            return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type $type");
        }
        return 0;
    }

    public static function get_grouped_products()
    {
        $products = self::get_products(0, 1000);
        return array_filter($products, function($p) {
            return $p['product_type'] === 'grouped';
        });
    }

    public static function get_parent_grouped_id($child_id)
    {
        global $wpdb;
        $query = $wpdb->prepare("
            SELECT post_id 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_children' 
            AND meta_value LIKE %s
        ", '%' . $wpdb->esc_like(serialize((string)$child_id)) . '%');
        
        $parent_id = $wpdb->get_var($query);
        
        // If not found with string ID, try with integer ID (WC storage varies)
        if (!$parent_id) {
             $query = $wpdb->prepare("
                SELECT post_id 
                FROM {$wpdb->postmeta} 
                WHERE meta_key = '_children' 
                AND meta_value LIKE %s
            ", '%' . $wpdb->esc_like(serialize((int)$child_id)) . '%');
            $parent_id = $wpdb->get_var($query);
        }

        return $parent_id;
    }
}
