<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class MigrationController
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new MigrationController();
            self::$instance->init();
        }
        return self::$instance;
    }

    public function init()
    {
        MigrationQueue::init();
        add_action('wp_ajax_schedule_woo_to_sure_migration', [$this, 'schedule_migration']);
        add_action('wp_ajax_get_woo_to_sure_current_progress', [$this, 'get_woo_to_sure_current_progress']);
        add_action('wp_ajax_save_surecart_token',[$this,'save_surecart_token']);
        add_action('wp_ajax_smack_wc_surecart_completed_modules',[$this,'smack_wc_surecart_completed_modules']);
        add_action('wp_ajax_smack_wc_surecart_get_module_count',[$this,'smack_wc_surecart_get_module_count']);
        add_action('wp_ajax_fetch_woocommerce_status',[$this,'fetch_woocommerce_status']);
        add_action('smack_sc_start_migration', [$this, 'smack_sc_start_migration_callback']);

    }

    public function schedule_migration()
    {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        if (!UltimatePro::is_woo_to_sure_available()) { wp_send_json_error(['message' => 'WooCommerce and SureCart are required.']); wp_die(); }
        
        $module = isset($_POST['module']) ? sanitize_text_field($_POST['module']) : '';
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 5;
        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        $starttime = isset($_POST['start_time']) ? sanitize_text_field($_POST['start_time']) : '';
        $startdate = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $timezone = isset($_POST['timezone']) ? sanitize_text_field($_POST['timezone']) : '';  
        $run_now = isset($_POST['run_now']) ? sanitize_text_field($_POST['run_now']) : '';
        
        $sc_token_valid = hash_equals(
            (string) ScheduleCredentialCipher::decrypt(get_option('surecart_api_key')),
            (string) sanitize_text_field($_POST['sc_token'])
        );

        if(!$sc_token_valid){
            wp_send_json([
                'message' => 'Invalid SureCart token',
                'success' => false,
                'scheduled' => false
            ]);
            wp_die();
        } 

        if (empty($module) || empty($starttime) || empty($startdate)) {
            wp_send_json_error(['message' => 'Missing required parameters']);
        }
        
        if($timezone == 'Asia/Calcutta' || empty($timezone)){
            $timezone = 'Asia/Kolkata';
        }

        $datetime = new \DateTime($startdate . ' ' . $starttime, new \DateTimeZone($timezone));
        $timestamp = $datetime->getTimestamp();

        if (!$timestamp) {
            wp_send_json([
                'message' => 'Invalid date or time format',
                'scheduled' => false
            ]);
            wp_die();
        }

        $data = [
            'module' => $module,
            'limit' => $limit,
            'offset' => $offset,
            'starttime' => $starttime,
            'startdate' => $startdate,
            'run_now' => $run_now
        ];

        $total = WooFetcher::get_count($module);
        $modules = get_option('smack_wc_surecart_progress',[]);
        if(!is_array($modules)){
            $modules = [];
        }

        if(!in_array('products', $modules)){
            $modules[] = 'products';
            update_option('smack_wc_surecart_progress', $modules);
        }
        if($run_now == 'true'){
            update_option('smack_sc_migration_config', $data);
            do_action("smack_sc_migrate_{$module}", $offset, $limit);

            wp_send_json([
                'message' => 'Migration started successfully',
                'data' => $data,
                'scheduled' => false,
                'next_offset' => $offset + $limit,
                'modules' => $modules,
                'total' => $total,
                'completed' => $offset+$limit >= $total,
            ]);
            wp_die();

        }else{
            update_option('smack_sc_migration_config', $data);
        }
            
        if (!wp_next_scheduled('smack_sc_start_migration')) {
            wp_schedule_single_event($timestamp, 'smack_sc_start_migration');
        }

        wp_send_json([
            'message' => 'Migration scheduled successfully',
            'timestamp' => $timestamp,
            'data' => $data,
            'modules' => $modules,
            'scheduled' => true
        ]);
        wp_die();
    }


    public function fetch_woocommerce_status(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $is_active = is_plugin_active('woocommerce/woocommerce.php') || class_exists('WooCommerce');
        wp_send_json([
            'is_active' => $is_active
        ]);
        wp_die();
    }
        

    public function smack_sc_start_migration_callback()
    {
        if (!UltimatePro::is_woo_to_sure_available()) { return; }
        $config = get_option('smack_sc_migration_config');

        if (empty($config)) {
            return;
        }

        $module = isset($config['module']) ? sanitize_text_field($config['module']) : '';
        $limit = isset($config['limit']) ? (int) $config['limit'] : 5;
        $offset = isset($config['offset']) ? (int) $config['offset'] : 0;
        
        if (empty($module)) {
            wp_send_json(['message' => 'Module is missing']);
            wp_die();
            return;
        }

        $total = WooFetcher::get_count($module);

        if ($offset < $total) {
            do_action("smack_sc_migrate_{$module}", $offset, $limit);

            if (($offset + $limit) < $total) {
                $config['offset'] = $offset + $limit;
                update_option('smack_sc_migration_config', $config);

                if (!wp_next_scheduled('smack_sc_start_migration')) {
                    wp_schedule_single_event(time(), 'smack_sc_start_migration');
                }
            }
        }
    }

    public function save_surecart_token(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

        $sc_token = isset($_POST['sc_token']) ? sanitize_text_field($_POST['sc_token']) : '';
        $modules = get_option('smack_wc_surecart_progress',[]);

        if(empty($modules)){
            $modules[] = 'products';
            update_option('smack_wc_surecart_progress', $modules);
        }

        if(!empty($sc_token)){
            $is_valid = $this->is_surecart_token_valid($sc_token);
            if($is_valid){
                update_option('surecart_api_key', ScheduleCredentialCipher::encrypt($sc_token));
                wp_send_json([
                    'message' => 'SureCart Token saved successfully',
                    'success' => true,
                    'sc_token' => $sc_token,
                    'modules' => $modules
                ]);
                wp_die();
            }else{
                wp_send_json([
                    'message' => 'SureCart Token is invalid',
                    'success' => false,
                    'sc_token' => '',
                    'modules' => $modules
                ]);
                wp_die();
            }
        }else{
            $sc_token = ScheduleCredentialCipher::decrypt(get_option('surecart_api_key'));
            if(empty($sc_token)){
                wp_send_json([
                    'message' => 'SureCart Token is Missing',
                    'success' => false,
                    'sc_token' => '',
                    'modules' => $modules
                ]);
                wp_die();
            }

            wp_send_json([
                'message' => 'SureCart Token is already saved',
                'success' => true,
                'sc_token' => $sc_token,
                'modules' => $modules
            ]);
            wp_die();
        }

    }
    
    public function is_surecart_token_valid( $token ) 
    {

        if ( empty( $token ) ) {
            return false;
        }

        $response = wp_remote_get( 'https://api.surecart.com/v1/account', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'timeout' => 20
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $status_code = wp_remote_retrieve_response_code( $response );

        if ( $status_code === 200 ) {
            return true; // Token is valid
        }

        return false; // Token invalid or expired
    }
    
    public function get_woo_to_sure_current_progress(){

        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        if (!UltimatePro::is_woo_to_sure_available()) { wp_send_json_error(['message' => 'WooCommerce and SureCart are required.']); wp_die(); }

        $config = get_option('smack_sc_migration_config');

        if (empty($config)) {
            wp_send_json_error(['message' => 'No migration scheduled']);
            return;
        }

        $module = isset($config['module']) ? sanitize_text_field($config['module']) : '';
        $limit = isset($config['limit']) ? (int) $config['limit'] : 5;
        $offset = isset($config['offset']) ? (int) $config['offset'] : 0;
        
        if (empty($module)) {
            wp_send_json([
                'message' => 'Module is missing',
                'total' => 0,
                'offset' => 0,
                'completed' => 0,
                'limit' => 0
            ]);
            wp_die();
            return;
        }

        $total = WooFetcher::get_count($module);

        wp_send_json_success([
            'message' => 'Migration progress',
            'module' => $module,
            'total' => $total,
            'offset' => $offset,
            'completed' => $offset,
            'limit' => $limit
        ]);
    }

    public function smack_wc_surecart_completed_modules(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        if (!UltimatePro::is_woo_to_sure_available()) { wp_send_json_error(['message' => 'WooCommerce and SureCart are required.']); wp_die(); }

        $progress = get_option('smack_wc_surecart_progress');

        if (empty($progress)) {
            wp_send_json([
                'message' => 'No migration scheduled',
                'modules' => []
            ]);
            wp_die();
        }

        wp_send_json([
            'message' => 'Migration progress',
            'progress' => $progress
        ]);
        wp_die();
    }

    public function smack_wc_surecart_get_module_count(){
    
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        if (!UltimatePro::is_woo_to_sure_available()) { wp_send_json_error(['message' => 'WooCommerce and SureCart are required.']); wp_die(); }

        $module = isset($_POST['module']) ? sanitize_text_field($_POST['module']) : '';

        if(empty($module)){
            wp_send_json([
                'message' => 'Module is missing',
                'count' => 0
            ]);
            wp_die();
            return;
        }

        $count = WooFetcher::get_count($module);

        wp_send_json([
            'message' => 'Module count',
            'module' => $module,
            'count' => $count
        ]);
        wp_die();
    }

}

