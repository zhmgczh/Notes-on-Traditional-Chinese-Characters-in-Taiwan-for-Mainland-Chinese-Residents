<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class MigrationLogger
{
    public static function log($module, $entity_id, $status, $error_message = '')
    {
        $upload_dir = wp_upload_dir();
        $log_file = $upload_dir['basedir'] . '/smack-migration.log';
        $timestamp = current_time('H:i:s');

        $entity_id_str = $entity_id ? $entity_id : 'N/A';
        $module_name = ucfirst($module);

        $status_label = strtoupper($status);
        if ($status === 'success') {
            $log_entry = "[$timestamp] $module_name $entity_id_str migrated successfully\n";
        } elseif ($status === 'info' || $status === 'warning') {
            $log_entry = "[$timestamp] $module_name $entity_id_str [$status_label]: $error_message\n";
        } else {
            $log_entry = "[$timestamp] $module_name $entity_id_str FAILED: $error_message\n";
        }

        file_put_contents($log_file, $log_entry, FILE_APPEND);
    }
}
