<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class MigrationQueue
{
    public static function init()
    {
        add_action('smack_sc_migrate_products', [self::class, 'process_products'], 10, 2);
        add_action('smack_sc_migrate_customers', [self::class, 'process_customers'], 10, 2);
        add_action('smack_sc_migrate_orders', [self::class, 'process_orders'], 10, 2);
        add_action('smack_sc_migrate_subscriptions', [self::class, 'process_subscriptions'], 10, 2);
        add_action('smack_sc_migrate_coupons', [self::class, 'process_coupons'], 10, 2);
    }



    public static function process_products($offset, $limit)
    {
        $migrator = new ProductMigrator();
        $migrator->process_batch($offset, $limit);
        $total = WooFetcher::get_count('products');
        if($total <= $offset+$limit){
            $modules = get_option('smack_wc_surecart_progress',[]);
            if(in_array('products', $modules) && !in_array('customers', $modules)){
                $modules[] = 'customers';
                update_option('smack_wc_surecart_progress', $modules);
            }
        }
    }

    public static function process_customers($offset, $limit)
    {
        $migrator = new CustomerMigrator();
        $migrator->process_batch($offset, $limit);
        $total = WooFetcher::get_count('customers');
        if($total <= $offset+$limit){
            $modules = get_option('smack_wc_surecart_progress',[]);
            if(in_array('customers', $modules) && !in_array('coupons', $modules)){
                $modules[] = 'coupons';
                update_option('smack_wc_surecart_progress', $modules);
            }
        }
    }

    public static function process_orders($offset, $limit)
    {
        $migrator = new OrderMigrator();
        $migrator->process_batch($offset, $limit);
    }

    public static function process_subscriptions($offset, $limit)
    {
        $migrator = new SubscriptionMigrator();
        $migrator->process_batch($offset, $limit);
    }

    public static function process_coupons($offset, $limit)
    {
        $migrator = new CouponMigrator();
        $migrator->process_batch($offset, $limit);

        $total = WooFetcher::get_count('coupons');
        if($total <= $offset+$limit){
            $modules = get_option('smack_wc_surecart_progress',[]);
            if(in_array('coupons', $modules) && !in_array('orders', $modules)){
                $modules[] = 'orders';
                update_option('smack_wc_surecart_progress', $modules);
            }
        }
    }
}
