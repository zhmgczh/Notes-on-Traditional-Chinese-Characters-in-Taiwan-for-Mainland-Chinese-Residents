<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class OrderMigrator
{
    public function process_batch($offset, $limit)
    {
        $orders = WooFetcher::get_orders($offset, $limit);
        if (empty($orders))
            return;

        $completed = 0;
        foreach ($orders as $order) {
            $this->migrate_order($order);
            $completed++;
        }

        $this->update_progress($completed);
    }

    private function migrate_order($order)
    {
        $wc_id = $order['ID'];
        // echo "    -> Migrating Order ID: $wc_id (status: {$order['status']})\n";

        if (IdMapper::get_status('order', $wc_id) === 'completed') {
            // echo "    -> Mapping already exists for order $wc_id, skipping.\n";
            return;
        }

        // Resolve SureCart customer
        $sc_customer_id = IdMapper::get_sc_id('customer', $order['_customer_user']);
        if (!$sc_customer_id) {
            // echo "    -> No mapped SureCart customer for WC customer {$order['_customer_user']}, skipping order $wc_id.\n";
            MigrationLogger::log('orders', $wc_id, 'failed', "No mapped customer for WC customer {$order['_customer_user']}");
            return;
        }

        // ── Step 1: Create a blank checkout session ──
        $create_payload = OrderDataBuilder::build_checkout_create_payload($order);
        $checkout = SureCartSender::create_checkout($create_payload);
        if (is_wp_error($checkout)) {
            // echo "    -> Error creating checkout: " . $checkout->get_error_message() . "\n";
            MigrationLogger::log('orders', $wc_id, 'failed', 'Checkout create: ' . $checkout->get_error_message());
            return;
        }
        $checkout_id = $checkout['id'];
        // echo "    -> Step 1: Created checkout: $checkout_id\n";

        // ── Step 2: Add products (line items) ──
        $products_payload = OrderDataBuilder::build_step_products_payload($order);
        if (empty($products_payload['line_items'])) {
            //  echo "    -> No valid line items for order $wc_id, skipping.\n";
             MigrationLogger::log('orders', $wc_id, 'failed', 'No valid mapped line items');
             return;
        }
        $updated_products = SureCartSender::update_checkout($checkout_id, $products_payload);
        if (is_wp_error($updated_products)) {
            // echo "    -> Error adding products: " . $updated_products->get_error_message() . "\n";
            return;
        }
        // echo "    -> Step 2: Products added to checkout\n";

        // ── Step 3: Assign customer ──
        $customer_payload = OrderDataBuilder::build_step_customer_payload($sc_customer_id);
        $updated_customer = SureCartSender::update_checkout($checkout_id, $customer_payload);
        if (is_wp_error($updated_customer)) {
            // echo "    -> Error assigning customer: " . $updated_customer->get_error_message() . "\n";
            return;
        }
        // echo "    -> Step 3: Customer assigned to checkout\n";

        // ── Step 4: Add addresses, coupons, and metadata (consolidated update) ──
        $address_payload = OrderDataBuilder::build_step_address_payload($order);
        $metadata_payload = OrderDataBuilder::build_step_metadata_payload($order);
        $coupon_payload = OrderDataBuilder::build_step_coupon_payload($order);

        $final_update_payload = array_merge($address_payload, $metadata_payload, $coupon_payload);
        // echo "    -> Step 4: Adding address, metadata, and coupons to checkout...\n";
        $updated_final = SureCartSender::update_checkout($checkout_id, $final_update_payload);
        if (is_wp_error($updated_final)) {
            //  echo "    -> Error adding address/metadata: " . $updated_final->get_error_message() . "\n";
             return;
        }
        // echo "    -> Step 4: Address, metadata, and coupons added successfully\n";

        // ── Step 5: Process payment or finalize ──
        // Important: Include metadata again in the final call to ensure it persists to the Order object.
        $final_step_payload = OrderDataBuilder::build_step_metadata_payload($order);
        
        if (OrderDataBuilder::is_paid_status($order['status'])) {
            // echo "    -> Step 5: Paying checkout to create order (including metadata)...\n";
            $paid = SureCartSender::manually_pay_checkout($checkout_id, $final_step_payload);
        } else {
            // echo "    -> Step 5: Finalizing unpaid checkout to create order (including metadata)...\n";
            $paid = SureCartSender::finalize_checkout($checkout_id, $final_step_payload);
        }
        
        if (is_wp_error($paid)) {
            // echo "    -> Error creating order: " . $paid->get_error_message() . "\n";
            MigrationLogger::log('orders', $wc_id, 'failed', 'Step 5 Error: ' . $paid->get_error_message());
            return;
        }

        // Resolve Order ID
        $sc_order_id = null;
        if (isset($paid['order']) && is_array($paid['order']) && isset($paid['order']['id'])) {
            $sc_order_id = $paid['order']['id'];
        } elseif (isset($paid['order']) && is_string($paid['order'])) {
            $sc_order_id = $paid['order'];
        }

        if (!$sc_order_id) {
            // echo "    -> Warning: Could not resolve Order ID from checkout response. Using checkout_id as fallback.\n";
            $sc_order_id = $checkout_id;
        }
        // echo "    -> Order resolved: $sc_order_id\n";

        // ── Step 6: Create or ensure Invoice ──
        // echo "    -> Step 6: Generating invoice with visibility enhancements...\n";
        $memo = "Migrated from WooCommerce. WC ID: $wc_id. Payment: " . ($order['_payment_method_title'] ?: 'N/A') . ". Transaction: " . ($order['_transaction_id'] ?: 'N/A') . ". Original Status: " . $order['status'];
        
        $invoice_payload = [
            'checkout' => $checkout_id,
            'memo' => $memo,
            'metadata' => [
                'wc_id'                => (string) $wc_id,
                'transaction_id'       => $order['_transaction_id'],
                'payment_method'       => $order['_payment_method'],
                'payment_method_title' => $order['_payment_method_title'],
                'original_status'      => $order['status']
            ]
        ];
        $invoice = SureCartSender::create_invoice($invoice_payload);
        if (is_wp_error($invoice)) {
            // echo "    -> Warning: Could not create invoice: " . $invoice->get_error_message() . "\n";
        } else {
            // echo "    -> Invoice created successfully: " . $invoice['id'] . "\n";
            // echo "    -> Memo added: $memo\n";
        }

        // ── Step 7: Change Status to match WooCommerce ──
        $sc_status = OrderDataBuilder::map_status($order['status']);
        // echo "    -> Step 7: Changing status to: $sc_status (original: {$order['status']})\n";
        
        // Small delay to allow platform propagation
        // sleep(2);

        $patch_payload = [
            'status' => $sc_status
        ];
        if (!empty($order['date_created'])) {
            $patch_payload['created_at'] = $order['date_created'];
        }
        
        $patch_resp = SureCartSender::update_order($sc_order_id, $patch_payload);
        if (is_wp_error($patch_resp)) {
            // echo "    -> Warning: Could not update status for order $sc_order_id: " . $patch_resp->get_error_message() . " (Status Code: " . ($patch_resp->get_error_data()['status'] ?? 'unknown') . ")\n";
        } else {
            // echo "    -> Status updated successfully to $sc_status\n";
        }

        IdMapper::save_mapping('order', $wc_id, $sc_order_id, 'completed');
        MigrationLogger::log('orders', $wc_id, 'success');
        $this->update_migration_option($wc_id, $sc_order_id, 'completed');
        // echo "    -> Order $wc_id migrated successfully → SC order $sc_order_id\n";
    }

    public function update_migration_option($wc_id, $sc_id, $status)
    {
        $migrated_orders = get_option('sc_order_migration', []);
        if (!is_array($migrated_orders)) {
            $migrated_orders = [];
        }
        $migrated_orders[] = [
            'wc_id'        => $wc_id,
            'sc_id'        => $sc_id,
            'status'       => $status,
            'sc_edit_url'  => admin_url('admin.php?page=surecart#/orders/' . $sc_id),
        ];
        update_option('sc_order_migration', $migrated_orders);
    }

    private function update_progress($processed)
    {
        // $progress = get_option('smack_wc_surecart_progress', []);
        // if (empty($progress) || $progress['module'] !== 'orders') {
        //     $progress = [
        //         'total' => WooFetcher::get_count('orders'),
        //         'completed' => 0,
        //         'module' => 'orders'
        //     ];
        // }
        // $progress['completed'] += $processed;
        // update_option('smack_wc_surecart_progress', $progress);
    }
}
