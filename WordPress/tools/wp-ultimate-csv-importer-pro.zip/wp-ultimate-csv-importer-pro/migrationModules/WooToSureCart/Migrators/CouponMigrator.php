<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class CouponMigrator
{
    public function process_batch($offset,$limit)
    {
        $coupons = WooFetcher::get_coupons($offset, $limit);
        if (empty($coupons))
            return;

        $completed = 0;
        foreach ($coupons as $coupon) {
            $this->migrate_coupon($coupon);
            $completed++;
        }

        $this->update_progress($completed);

        
    }

    private function migrate_coupon($coupon)
    {
        $wc_id = $coupon['ID'];
        if (IdMapper::get_status('coupon', $wc_id) === 'completed') {
            return;
        }

        $mapped_data = CouponDataBuilder::build($coupon);

        // Deduplication: Check if coupon with same name already exists in SureCart
        try {
            $existing = SureCartSender::request('coupons?query=' . urlencode($mapped_data['name']), 'GET');
            if (!is_wp_error($existing) && is_array($existing) && !empty($existing['data'])) {
                foreach ($existing['data'] as $ec) {
                    if (isset($ec['name']) && strtolower($ec['name']) === strtolower($mapped_data['name'])) {
                        // Already exists — save mapping and skip
                        IdMapper::save_mapping('coupon', $wc_id, $ec['id'], 'completed');
                        MigrationLogger::log('coupons', $wc_id, 'info', 'Coupon already exists in SureCart: ' . $ec['id']);
                        $this->update_migration_option($wc_id, $ec['id'], 'completed');
                        return;
                    }
                }
            }
        } catch (\Throwable $e) {
            // Continue with creation if check fails
        }

        // Handle customer restrictions via promotions
        $promotions = [];
        if (!empty($mapped_data['customer_emails'])) {
            foreach ($mapped_data['customer_emails'] as $email) {
                $user = get_user_by('email', $email);
                if ($user) {
                    $sc_customer_id = IdMapper::get_sc_id('customer', $user->ID);
                    if ($sc_customer_id) {
                        $promotions[] = [
                            'code' => $coupon['code'],
                            'customer' => $sc_customer_id
                        ];
                    }
                }
            }
            unset($mapped_data['customer_emails']);
        }

        // Always ensure at least one promotion is created (either customer-specific or general)
        if (empty($promotions)) {
            $promotions[] = [
                'code' => $coupon['code']
            ];
        }

        $mapped_data['promotions'] = $promotions;

        MigrationLogger::log('coupons', $wc_id, 'info', 'Sending to SC: ' . wp_json_encode($mapped_data));
        $response = SureCartSender::create_coupon($mapped_data);

        if (is_wp_error($response)) {
            IdMapper::update_status('coupon', $wc_id, 'failed');
            MigrationLogger::log('coupons', $wc_id, 'failed', $response->get_error_message());
        } elseif (isset($response['id'])) {
            $sc_id = $response['id'];            

            IdMapper::save_mapping('coupon', $wc_id, $sc_id, 'completed');
            MigrationLogger::log('coupons', $wc_id, 'success');
            $this->update_migration_option($wc_id, $sc_id, 'completed');
        } else {
            IdMapper::update_status('coupon', $wc_id, 'failed');
            MigrationLogger::log('coupons', $wc_id, 'failed', wp_json_encode($response));
        }
    }

    private function update_progress($processed)
    {
        // $progress = get_option('smack_wc_surecart_progress', []);
        // if (empty($progress) || $progress['module'] !== 'coupons') {
        //     $progress = [
        //         'total' => WooFetcher::get_count('coupons'),
        //         'completed' => 0,
        //         'module' => 'coupons'
        //     ];
        // }
        // $progress['completed'] += $processed;
        // update_option('smack_wc_surecart_progress', $progress);
    }

    public function update_migration_option($wc_id, $sc_id, $status)
    {
        $migrated_coupons = get_option('sc_coupon_migration', []);
        if (!is_array($migrated_coupons)) {
            $migrated_coupons = [];
        }
        $migrated_coupons[] = [
            'wc_id'        => $wc_id,
            'sc_id'        => $sc_id,
            'status'       => $status,
            'sc_edit_url'  => admin_url('admin.php?page=surecart#/coupons/' . $sc_id),
        ];
        update_option('sc_coupon_migration', $migrated_coupons);
    }
}
