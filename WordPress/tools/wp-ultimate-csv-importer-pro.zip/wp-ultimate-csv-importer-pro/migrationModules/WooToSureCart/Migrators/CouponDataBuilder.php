<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}
class CouponDataBuilder{
    public static function build($coupon) {
        $mapped_data = [
            'name' => !empty($coupon['description']) ? $coupon['description'] : $coupon['code'],
            'max_redemptions' => !empty($coupon['usage_limit']) ? (int) $coupon['usage_limit'] : null,
            'max_redemptions_per_customer' => !empty($coupon['usage_limit_per_user']) ? (int) $coupon['usage_limit_per_user'] : null,
            'duration' => 'once', // Default to once as per documentation
        ];

        // Subscription Duration Mapping
        if (!empty($coupon['wcs_number_payments'])) {
            $num_payments = (int) $coupon['wcs_number_payments'];
            if ($num_payments === 0) {
                $mapped_data['duration'] = 'forever';
            } else {
                $mapped_data['duration'] = 'repeating';
                $mapped_data['duration_in_months'] = $num_payments;
            }
        }

        $currency = function_exists('get_woocommerce_currency') ? strtolower(get_woocommerce_currency()) : 'usd';

        if ($coupon['discount_type'] === 'percent') {
            $mapped_data['percent_off'] = (float) $coupon['coupon_amount'];
        } else {
            $mapped_data['amount_off'] = (int) ((float) $coupon['coupon_amount'] * 100);
            $mapped_data['currency'] = $currency;
        }

        if (!empty($coupon['expiry_date'])) {
            $mapped_data['redeem_by'] = is_numeric($coupon['expiry_date']) ? (int) $coupon['expiry_date'] : strtotime($coupon['expiry_date']);
        }

        if (!empty($coupon['minimum_amount'])) {
            $mapped_data['min_subtotal_amount'] = (int) ((float) $coupon['minimum_amount'] * 100);
            $mapped_data['min_subtotal_amount_currency'] = $currency;
        }

        if (!empty($coupon['maximum_amount'])) {
            $mapped_data['max_subtotal_amount'] = (int) ((float) $coupon['maximum_amount'] * 100);
            $mapped_data['max_subtotal_amount_currency'] = $currency;
        }

        // Map product restrictions
        $product_ids = [];
        if (!empty($coupon['product_ids'])) {
            foreach ($coupon['product_ids'] as $wc_pid) {
                $sc_pid = IdMapper::get_sc_id('product', $wc_pid);
                if (!$sc_pid) {
                    $sc_pid = IdMapper::get_sc_id('variant', $wc_pid);
                }
                if ($sc_pid) {
                    $product_ids[] = $sc_pid;
                }
            }
        }
        $mapped_data['product_ids'] = $product_ids;

        // Note: SureCart API (per documentation provided) doesn't explicitly show 'exclude_product_ids' for the coupon object,
        // but it shows 'product_ids' as an array of IDs the coupon applies to. 
        // We'll focus on the applied products for now as requested.

        // Pass through customer emails for promotions handling in Migrator
        $mapped_data['customer_emails'] = !empty($coupon['customer_email']) ? $coupon['customer_email'] : [];

        return $mapped_data;
    }
}