<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}
class CustomerDataBuilder{
    public static function build($customer) {
        $billing_first = $customer['billing_first_name'] ?? '';
        $billing_last = $customer['billing_last_name'] ?? '';
        $shipping_first = $customer['shipping_first_name'] ?? '';
        $shipping_last = $customer['shipping_last_name'] ?? '';

        return [
            'email' => $customer['user_email'] ?? '',
            'name' => trim($billing_first . ' ' . $billing_last),
            'phone' => !empty($customer['billing_phone']) ? $customer['billing_phone'] : ($customer['shipping_phone'] ?? ''),
            'billing_address' => [
                'name' => trim($billing_first . ' ' . $billing_last),
                'line_1' => $customer['billing_address_1'] ?? '',
                'line_2' => $customer['billing_address_2'] ?? '',
                'city' => $customer['billing_city'] ?? '',
                'state' => $customer['billing_state'] ?? '',
                'country' => $customer['billing_country'] ?? '',
                'postal_code' => $customer['billing_postcode'] ?? '',
            ],
            'shipping_address' => [
                'name' => trim($shipping_first . ' ' . $shipping_last) ?: trim($billing_first . ' ' . $billing_last),
                'line_1' => $customer['shipping_address_1'] ?? '',
                'line_2' => $customer['shipping_address_2'] ?? '',
                'city' => $customer['shipping_city'] ?? '',
                'state' => $customer['shipping_state'] ?? '',
                'country' => $customer['shipping_country'] ?? '',
                'postal_code' => $customer['shipping_postcode'] ?? '',
            ],
            'metadata' => [
                'wp_user_id' => (string) ($customer['ID'] ?? 0)
            ]
        ];
    }
}