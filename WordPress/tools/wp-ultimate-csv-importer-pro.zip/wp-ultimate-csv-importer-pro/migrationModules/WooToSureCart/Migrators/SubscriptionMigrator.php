<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class SubscriptionMigrator
{
    public function process_batch($offset, $limit)
    {
        $subs = WooFetcher::get_subscriptions($offset, $limit);
        if (empty($subs))
            return;

        $completed = 0;
        foreach ($subs as $sub) {
            $this->migrate_subscription($sub);
            $completed++;
        }

        $this->update_progress($completed);
    }

    private function migrate_subscription($sub)
    {
        $wc_id = $sub['ID'];
        if (IdMapper::mapping_exists('subscription', $wc_id)) {
            return;
        }

        $sc_customer_id = IdMapper::get_sc_id('customer', $sub['_customer_user']);

        $mapped_data = [
            'customer_id' => $sc_customer_id,
            'status' => $sub['status'] === 'active' ? 'active' : 'canceled',
            'interval' => $sub['_billing_period'],
            'interval_count' => $sub['_billing_interval'],
            'next_payment_date' => $sub['_schedule_next_payment'],
            'metadata' => [
                'payment_method' => $sub['_payment_method'],
                'stripe_customer_id' => $sub['_stripe_customer_id'],
                'stripe_source_id' => $sub['_stripe_source_id']
            ]
        ];

        if ($sub['_payment_method'] === 'stripe' && empty($sub['_stripe_customer_id'])) {
            MigrationLogger::log('subscriptions', $wc_id, 'info', 'Flagged for payment reauthentication due to missing stripe tokens');
            $mapped_data['metadata']['needs_reauth'] = true;
        }

        $response = SureCartSender::create_subscription($mapped_data);

        if (is_wp_error($response)) {
            MigrationLogger::log('subscriptions', $wc_id, 'failed', $response->get_error_message());
        } elseif (isset($response['id'])) {
            IdMapper::save_mapping('subscription', $wc_id, $response['id'], 'completed');
            MigrationLogger::log('subscriptions', $wc_id, 'success');
            $this->update_migration_option($wc_id, $response['id'], 'completed');
        } else {
            MigrationLogger::log('subscriptions', $wc_id, 'failed', wp_json_encode($response));
        }
    }

    public function update_migration_option($wc_id, $sc_id, $status)
    {
        $migrated_subs = get_option('sc_subscription_migration', []);
        if (!is_array($migrated_subs)) {
            $migrated_subs = [];
        }
        $migrated_subs[] = [
            'wc_id'        => $wc_id,
            'sc_id'        => $sc_id,
            'status'       => $status,
            'sc_edit_url'  => admin_url('admin.php?page=surecart#/subscriptions/' . $sc_id),
        ];
        update_option('sc_subscription_migration', $migrated_subs);
    }

    private function update_progress($processed)
    {
        // $progress = get_option('smack_wc_surecart_progress', []);
        // if (empty($progress) || $progress['module'] !== 'subscriptions') {
        //     $progress = [
        //         'total' => WooFetcher::get_count('subscriptions'),
        //         'completed' => 0,
        //         'module' => 'subscriptions'
        //     ];
        // }
        // $progress['completed'] += $processed;
        // update_option('smack_wc_surecart_progress', $progress);
    }
}
