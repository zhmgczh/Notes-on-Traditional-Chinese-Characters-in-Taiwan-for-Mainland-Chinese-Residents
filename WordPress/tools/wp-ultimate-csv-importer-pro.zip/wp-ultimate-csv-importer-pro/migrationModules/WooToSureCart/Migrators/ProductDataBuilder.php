<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class ProductDataBuilder
{
    public static function build_product_group($product, $options = [])
    {
        $payload = [
            'name' => $product['post_title'],
            'description' => $product['post_content'],
        ];

        // Set option names (up to 3)
        $i = 1;
        foreach ($options as $name) {
            if ($i <= 3) {
                $payload["option_{$i}_name"] = $name;
                $i++;
            }
        }

        return $payload;
    }

    public static function build_product($product)
    {
        $wc_id = $product['ID'];
        $status = 'published';
        $archived = false;
        if (isset($product['post_status']) && $product['post_status'] === 'draft') {
            $status = 'draft';
        } elseif (isset($product['post_status']) && $product['post_status'] === 'trash') {
            $archived = true;
        }

        // Identify if it is variable
        $type = 'simple';
        if (empty($product['product_group_id'])) {
            $raw_attrs = isset($product['_product_attributes']) ? $product['_product_attributes'] : [];
            if (is_array($raw_attrs)) {
                foreach ($raw_attrs as $attr_slug => $attr) {
                    if (!empty($attr['is_variation'])) {
                        $type = 'variable';
                        break;
                    }
                }
            }
        }

        $product_data = [
            'name' => $product['post_title'],
            'description' => isset($product['post_content']) ? $product['post_content'] : '',
            'short_description' => isset($product['post_excerpt']) ? $product['post_excerpt'] : '',
            'type' => $type,
            'status' => $status,
            'shipping_enabled' => !(isset($product['_virtual']) && $product['_virtual'] === 'yes'),
            'stock_enabled' => isset($product['_manage_stock']) && $product['_manage_stock'] === 'yes',
            'allow_out_of_stock_purchases' => isset($product['_backorders']) && $product['_backorders'] === 'yes',
            'weight_unit' => 'kg',
            'search_engine_listing' => [
                'page_title' => $product['post_title'],
                'meta_description' => isset($product['post_excerpt']) && $product['post_excerpt'] !== '' ? $product['post_excerpt'] : wp_trim_words(strip_tags($product['post_content'] ?? ''), 30),
            ],
            'metadata' => [
                'wc_id' => (string) $wc_id,
                'page_title' => $product['post_title'],
                'meta_description' => isset($product['post_excerpt']) && $product['post_excerpt'] !== '' ? $product['post_excerpt'] : wp_trim_words(strip_tags($product['post_content'] ?? ''), 30),
            ],
        ];

        // Simple data
        $product_data['sku'] = isset($product['_sku']) ? (string) $product['_sku'] : '';
        $weight = isset($product['_weight']) && $product['_weight'] !== '' ? (float) $product['_weight'] : null;
        if ($weight !== null) {
            $product_data['weight'] = $weight;
        }

        $thumb_id = get_post_thumbnail_id($wc_id) ?: ($product['_thumbnail_id'] ?? 0);
        $featured_url = !empty($product['featured_image_url']) ? $product['featured_image_url'] : ($thumb_id ? wp_get_attachment_url($thumb_id) : '');

        $gallery_payload = [];
        $product_medias = [];

        if ($thumb_id) {
            $gallery_payload[] = ['id' => (int) $thumb_id];
        }
        if ($featured_url) {
            $product_data['image_url'] = $featured_url;
            $product_medias[] = ['url' => $featured_url];
        }

        if (!empty($product['gallery_images']) && is_array($product['gallery_images'])) {
            foreach ($product['gallery_images'] as $img) {
                $g_id = is_array($img) ? ($img['id'] ?? 0) : 0;
                $g_url = is_array($img) ? ($img['url'] ?? '') : (is_string($img) ? $img : '');

                if ($g_id) {
                    $found = false;
                    foreach ($gallery_payload as $gp) {
                        if ($gp['id'] == $g_id) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $gallery_payload[] = ['id' => (int) $g_id];
                    }
                }

                if ($g_url) {
                    $found = false;
                    foreach ($product_medias as $pm) {
                        if ($pm['url'] === $g_url) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $product_medias[] = ['url' => $g_url];
                    }
                }
            }
        }

        if (!empty($product_medias)) {
            $product_data['product_medias'] = $product_medias;
        }

        if (!empty($gallery_payload)) {
            $product_data['gallery_ids'] = $gallery_payload;
            $product_data['metadata'] = (object) array_merge(
                (array) ($product_data['metadata'] ?? []),
                ['gallery_ids' => $gallery_payload]
            );
        }

        if ($thumb_id) {
            $product_data['featured_product_media'] = ['id' => (int) $thumb_id];
        }

        // Add collections if provided
        if (!empty($product['collection_ids'])) {
            $product_data['product_collections'] = $product['collection_ids'];
        }

        if ($product_data['stock_enabled'] && isset($product['_stock'])) {
            $product_data['stock_adjustment'] = (float) $product['_stock'];
        }

        // Dimensions
        $length = isset($product['_length']) && $product['_length'] !== '' ? (float) $product['_length'] : 0;
        $width = isset($product['_width']) && $product['_width'] !== '' ? (float) $product['_width'] : 0;
        $height = isset($product['_height']) && $product['_height'] !== '' ? (float) $product['_height'] : 0;

        if ($length > 0 || $width > 0 || $height > 0) {
            $product_data['dimensions'] = [
                'length' => $length > 0 ? $length : 1,
                'width' => $width > 0 ? $width : 1,
                'height' => $height > 0 ? $height : 1,
                'unit' => 'cm',
            ];
        }

        if ($archived) {
            $product_data['archived'] = true;
        }

        // Handle variant options for variable products
        if (!empty($product['variant_options'])) {
            $product_data['variant_options'] = $product['variant_options'];
        }

        // Handle variants link
        if (!empty($product['product_group_id'])) {
            $product_data['product_group'] = $product['product_group_id'];

            // Map option values
            if (isset($product['option_mapping'])) {
                foreach ($product['option_mapping'] as $attr_slug => $pos) {
                    $meta_key = 'attribute_' . $attr_slug;
                    if (isset($product[$meta_key])) {
                        $product_data['option_' . $pos] = $product[$meta_key];
                    }
                }
            }
        }

        return $product_data;
    }

    public static function product_price_creation($sc_id, $product)
    {
        $reg_val = isset($product['_regular_price']) && $product['_regular_price'] !== '' ? $product['_regular_price'] : (isset($product['regular_price']) ? $product['regular_price'] : '');
        $sale_val = isset($product['_sale_price']) && $product['_sale_price'] !== '' ? $product['_sale_price'] : (isset($product['sale_price']) ? $product['sale_price'] : '');
        $price_val = isset($product['_price']) && $product['_price'] !== '' ? $product['_price'] : (isset($product['price']) ? $product['price'] : '');

        $regular_price = $reg_val !== '' ? (float) $reg_val : 0;
        $sale_price = $sale_val !== '' ? (float) $sale_val : 0;
        $price = $price_val !== '' ? (float) $price_val : 0;

        $active_amount = 0;
        if ($sale_price > 0) {
            $active_amount = (int) round($sale_price * 100);
        } elseif ($price > 0) {
            $active_amount = (int) round($price * 100);
        } elseif ($regular_price > 0) {
            $active_amount = (int) round($regular_price * 100);
        }

        if ($active_amount <= 0) {
            return;
        }

        $regular_amount = $regular_price > 0 ? (int) round($regular_price * 100) : 0;

        $price_data = [
            'product'  => $sc_id,
            'amount'   => $active_amount,
            'currency' => strtolower(function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'usd'),
            'name'     => 'Default Price',
        ];

        if ($regular_amount > $active_amount) {
            $price_data['scratch_amount']    = $regular_amount;
            $price_data['compare_at_amount'] = $regular_amount;
        }

        return $price_data;
    }

    public static function product_media_creation($product, $sc_id)
    {
        $wc_id = $product['ID'] ?? 0;
        $thumb_id = get_post_thumbnail_id($wc_id) ?: ($product['_thumbnail_id'] ?? 0);
        $featured_url = !empty($product['featured_image_url']) ? $product['featured_image_url'] : ($thumb_id ? wp_get_attachment_url($thumb_id) : '');

        $gallery_payload = [];
        $product_medias = [];

        if ($thumb_id) {
            $gallery_payload[] = ['id' => (int) $thumb_id];
        }
        if ($featured_url) {
            $product_medias[] = ['url' => $featured_url];
        }

        if (!empty($product['gallery_images']) && is_array($product['gallery_images'])) {
            foreach ($product['gallery_images'] as $img) {
                $g_id = is_array($img) ? ($img['id'] ?? 0) : 0;
                $g_url = is_array($img) ? ($img['url'] ?? '') : (is_string($img) ? $img : '');

                if ($g_id) {
                    $found = false;
                    foreach ($gallery_payload as $gp) {
                        if ($gp['id'] == $g_id) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $gallery_payload[] = ['id' => (int) $g_id];
                    }
                }

                if ($g_url) {
                    $found = false;
                    foreach ($product_medias as $pm) {
                        if ($pm['url'] === $g_url) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $product_medias[] = ['url' => $g_url];
                    }
                }
            }
        }

        if (empty($product_medias) && empty($gallery_payload)) {
            return false;
        }

        $patch_data = [];

        if (!empty($product_medias)) {
            $patch_data['product_medias'] = $product_medias;
            $patch_data['image_url'] = $product_medias[0]['url'];
        }

        if (!empty($gallery_payload)) {
            $patch_data['gallery_ids'] = $gallery_payload;
            $patch_data['metadata'] = [
                'gallery_ids' => $gallery_payload
            ];
        }

        if ($thumb_id) {
            $patch_data['featured_product_media'] = ['id' => (int) $thumb_id];
        }

        return $patch_data;
    }

    public static function build_variant($var_meta, $sc_id, $var, $option_mapping = [])
    {
        $reg_val = $var_meta['_regular_price'] ?? ($var_meta['regular_price'] ?? '');
        $sale_val = $var_meta['_sale_price'] ?? ($var_meta['sale_price'] ?? '');
        $price_val = $var_meta['_price'] ?? ($var_meta['price'] ?? '');

        $regular_price = $reg_val !== '' ? (float) $reg_val : 0;
        $sale_price = $sale_val !== '' ? (float) $sale_val : 0;
        $price = $price_val !== '' ? (float) $price_val : 0;

        $active_amount = 0;
        if ($sale_price > 0) {
            $active_amount = (int) round($sale_price * 100);
        } elseif ($price > 0) {
            $active_amount = (int) round($price * 100);
        } elseif ($regular_price > 0) {
            $active_amount = (int) round($regular_price * 100);
        }

        $regular_amount = $regular_price > 0 ? (int) round($regular_price * 100) : 0;

        $variant_data = [
            'amount' => $active_amount,
            'sku' => $var_meta['_sku'] ?? '',
            'shipping_enabled' => !(isset($var_meta['_virtual']) && $var_meta['_virtual'] === 'yes'),
            'stock_enabled' => ($var_meta['_manage_stock'] ?? 'no') === 'yes',
            'allow_out_of_stock_purchases' => ($var_meta['_backorders'] ?? 'no') === 'yes',
            'weight' => !empty($var_meta['_weight']) ? (float) $var_meta['_weight'] : null,
            'weight_unit' => 'kg',
            'search_engine_listing' => [
                'page_title' => $var->post_title,
                'meta_description' => $var->post_title,
            ],
            'metadata' => [
                'wc_id' => (string) $var->ID,
            ],
            'product' => $sc_id,
        ];

        if (!empty($var_meta['_thumbnail_id'])) {
            $variant_data['metadata']['wp_media'] = (int) $var_meta['_thumbnail_id'];
        }

        if ($regular_amount > $active_amount) {
            $variant_data['scratch_amount']    = $regular_amount;
            $variant_data['compare_at_amount'] = $regular_amount;
        }

        // Map attributes to option_1, option_2, option_3
        foreach ($option_mapping as $attr_name => $mapping) {
            $position = $mapping['position'];
            $possible_values = $mapping['values'];

            // Support both taxonomy (pa_*) and custom attributes
            $attr_slug = strtolower(str_replace(' ', '-', $attr_name));
            $meta_key = 'attribute_' . $attr_slug;

            $val = $var_meta[$meta_key] ?? ($var_meta['attribute_' . $attr_name] ?? null);

            if ($val !== null) {
                // Find matching value in possible_values (case-insensitive match)
                foreach ($possible_values as $pv) {
                    if (strtolower($pv) === strtolower($val)) {
                        $variant_data['option_' . $position] = $pv;
                        break;
                    }
                }
            }
        }

        if ($variant_data['stock_enabled']) {
            $variant_data['stock_adjustment'] = $var_meta['_stock'] ?? 0;
        }

        // Add dimensions only if at least one value is set (API requires valid numeric values)
        if (!empty($var_meta['_length']) || !empty($var_meta['_width']) || !empty($var_meta['_height'])) {
            $variant_data['dimensions'] = [
                'length' => !empty($var_meta['_length']) ? (float) $var_meta['_length'] : 0,
                'width' => !empty($var_meta['_width']) ? (float) $var_meta['_width'] : 0,
                'height' => !empty($var_meta['_height']) ? (float) $var_meta['_height'] : 0,
                'unit' => 'cm',
            ];
        }

        return $variant_data;
    }
    public static function build_download($file, $sc_id, $variant_id = null)
    {
        $payload = [
            'name' => $file['name'],
            'title' => $file['name'],
            'url' => $file['file'],
            'product' => $sc_id,
        ];

        if ($variant_id) {
            $payload['variant'] = $variant_id;
        }

        return $payload;
    }
}
