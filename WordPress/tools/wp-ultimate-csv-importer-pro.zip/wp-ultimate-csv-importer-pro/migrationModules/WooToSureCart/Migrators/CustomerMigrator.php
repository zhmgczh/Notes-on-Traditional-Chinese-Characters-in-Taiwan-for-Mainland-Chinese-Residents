<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class CustomerMigrator
{
    public function process_batch($offset, $limit)
    {
        $customers = WooFetcher::get_customers($offset, $limit);
        if (empty($customers))
            return;

        $completed = 0;
        foreach ($customers as $customer) {
            $this->migrate_customer($customer);
            $completed++;
        }

        $this->update_progress($completed);
    }

    private function migrate_customer($customer)
    {
        $wc_id = $customer['ID'];
        if (IdMapper::get_status('customer', $wc_id) === 'completed') {
            return;
        }

        $mapped_data = CustomerDataBuilder::build($customer);

        // Deduplication: Check if customer with same email already exists in SureCart
        $email = $mapped_data['email'] ?? '';
        if (!empty($email)) {
            try {
                $existing = SureCartSender::request('customers?email=' . urlencode($email), 'GET');
                if (!is_wp_error($existing) && is_array($existing) && !empty($existing['data'])) {
                    foreach ($existing['data'] as $ec) {
                        if (isset($ec['email']) && strtolower($ec['email']) === strtolower($email)) {
                            // Already exists — save mapping and skip
                            IdMapper::save_mapping('customer', $wc_id, $ec['id'], 'completed');
                            MigrationLogger::log('customers', $wc_id, 'info', 'Customer already exists in SureCart: ' . $ec['id']);
                            $this->update_migration_option($wc_id, $ec['id'], 'completed');

                            // Connect WP User to SureCart Customer mapping
                            $mode = empty($ec['live_mode']) ? 'test' : 'live';
                            $meta = (array) get_user_meta($wc_id, 'sc_customer_ids', true);
                            $meta[$mode] = $ec['id'];
                            update_user_meta($wc_id, 'sc_customer_ids', $meta);

                            $wp_user = get_userdata($wc_id);
                            if ($wp_user) {
                                $wp_user->add_role('sc_customer');
                            }
                            return;
                        }
                    }
                }
            } catch (\Throwable $e) {
                // Continue with creation if check fails
            }
        }

        $response = SureCartSender::create_customer($mapped_data);

        if (is_wp_error($response)) {
            IdMapper::update_status('customer', $wc_id, 'failed');
            MigrationLogger::log('customers', $wc_id, 'failed', $response->get_error_message());
        } elseif (isset($response['id'])) {
            IdMapper::save_mapping('customer', $wc_id, $response['id'], 'completed');
            MigrationLogger::log('customers', $wc_id, 'success');
            $this->update_migration_option($wc_id, $response['id'], 'completed');

            // Connect WP User to SureCart Customer mapping
            $mode = empty($response['live_mode']) ? 'test' : 'live';
            $meta = (array) get_user_meta($wc_id, 'sc_customer_ids', true);
            $meta[$mode] = $response['id'];
            update_user_meta($wc_id, 'sc_customer_ids', $meta);

            // Assign SureCart Customer Role
            $wp_user = get_userdata($wc_id);
            if ($wp_user) {
                $wp_user->add_role('sc_customer');
            }
        } else {
            IdMapper::update_status('customer', $wc_id, 'failed');
            MigrationLogger::log('customers', $wc_id, 'failed', wp_json_encode($response));
        }
    }

    private function update_progress($processed)
    {
        // $progress = get_option('smack_wc_surecart_progress', []);
        // if (empty($progress) || $progress['module'] !== 'customers') {
        //     $progress = [
        //         'total' => WooFetcher::get_count('customers'),
        //         'completed' => 0,
        //         'module' => 'customers'
        //     ];
        // }
        // $progress['completed'] += $processed;
        // update_option('smack_wc_surecart_progress', $progress);
    }

    public function update_migration_option($wc_id, $sc_id, $status)
    {
        $migrated_customers = get_option('sc_customer_migration', []);
        if (!is_array($migrated_customers)) {
            $migrated_customers = [];
        }
        $migrated_customers[] = [
            'wc_id'        => $wc_id,
            'sc_id'        => $sc_id,
            'status'       => $status,
            'sc_edit_url'  => admin_url('admin.php?page=surecart#/customers/' . $sc_id)
        ];
        update_option('sc_customer_migration', $migrated_customers);
    }
}
