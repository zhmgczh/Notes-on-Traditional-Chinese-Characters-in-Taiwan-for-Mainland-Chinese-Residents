<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class ProductMigrator
{
    public function process_batch($offset, $limit)
    {
        $products = WooFetcher::get_products($offset, $limit);
        if (empty($products))
            return;

        $completed = 0;
        foreach ($products as $product) {
            if ($product['post_type'] === 'product') {
                $this->migrate_product($product);
            }
            $completed++;
        }

        $this->update_progress($completed);
    }

    public function migrate_product($product)
    {
        $wc_id = $product['ID'];

        // If already migrated, still run media migration to ensure images are updated/migrated on re-tests!
        if (IdMapper::mapping_exists('product', $wc_id)) {
            $sc_id = IdMapper::get_sc_id('product', $wc_id);
            if ($sc_id) {
                $this->migrate_product_media($product, $sc_id);
                $this->update_migration_option($wc_id, $sc_id, 'completed');
                return;
            }
        }

        // Handle Grouped Product Parent
        if ($product['product_type'] === 'grouped') {
            // error_log("[MIGRATION] WC $wc_id: is grouped parent, handling as product group\n", 3, WP_CONTENT_DIR.'/migration.log');
            $sc_group_id = $this->get_or_create_sc_group_id($wc_id);
            if ($sc_group_id) {
                MigrationLogger::log('products', $wc_id, 'info', "Handled Product Group Parent: $sc_group_id");
                $this->update_migration_option($wc_id, $sc_group_id, 'completed');
            } else {
                IdMapper::update_status('product', $wc_id, 'failed');
            }
            return;
        }

        // Handle Grouped Product Child Check
        $parent_grouped_wc_id = WooFetcher::get_parent_grouped_id($wc_id);
        $sc_group_id = null;
        if ($parent_grouped_wc_id) {
            $sc_group_id = $this->get_or_create_sc_group_id($parent_grouped_wc_id);
        }

        // Handle Categories & Tags -> SureCart Collections
        $collection_ids = [];
        if (!empty($product['categories'])) {
            foreach ($product['categories'] as $cat) {
                $sc_coll_id = IdMapper::get_sc_id('collection', $cat['id']);

                // Check SureCart by name to prevent duplicate creation
                if (!$sc_coll_id) {
                    if (class_exists('\SureCart\Models\ProductCollection')) {
                        try {
                            $coll_models = \SureCart\Models\ProductCollection::where(['query' => $cat['name'], 'limit' => 10])->get();
                            if ($coll_models && isset($coll_models->data) && is_array($coll_models->data)) {
                                foreach ($coll_models->data as $item) {
                                    if (strtolower(trim($item->name ?? '')) === strtolower(trim($cat['name']))) {
                                        $sc_coll_id = $item->id;
                                        break;
                                    }
                                }
                            }
                        } catch (\Throwable $t) {}
                    }
                }

                // If still not found, create new SureCart ProductCollection
                if (!$sc_coll_id) {
                    if (class_exists('\SureCart\Models\ProductCollection')) {
                        try {
                            $sc_coll = \SureCart\Models\ProductCollection::create([
                                'name'        => $cat['name'],
                                'slug'        => $cat['slug'] ?: sanitize_title($cat['name']),
                                'description' => $cat['description'] ?? '',
                            ]);
                            if (!is_wp_error($sc_coll) && !empty($sc_coll->id)) {
                                $sc_coll_id = $sc_coll->id;
                            }
                        } catch (\Throwable $t) {}
                    }

                    if (!$sc_coll_id) {
                        $coll_resp = SureCartSender::create_collection($cat['name'], $cat['slug'], $cat['description']);
                        if (!is_wp_error($coll_resp) && isset($coll_resp['id'])) {
                            $sc_coll_id = $coll_resp['id'];
                        }
                    }

                    if ($sc_coll_id) {
                        IdMapper::save_mapping('collection', $cat['id'], $sc_coll_id);
                    }
                }

                if ($sc_coll_id && !in_array($sc_coll_id, $collection_ids)) {
                    $collection_ids[] = $sc_coll_id;
                }
            }
        }
        $product['collection_ids'] = $collection_ids;

            // Fetch attributes to get option names and values
            $attributes = WooFetcher::get_product_attribute($wc_id);
            $variant_options = [];
            $option_mapping = [];
            $pos = 1;
            if (!empty($attributes)) {
                foreach ($attributes as $attribute) {
                    if ($attribute['variation'] && $pos <= 3) {
                        $values = array_values(array_unique(array_map('strval', $attribute['options'])));
                        $variant_options[] = [
                            'name' => $attribute['name'],
                            'values' => $values
                        ];
                        $option_mapping[$attribute['name']] = [
                            'position' => $pos,
                            'values' => $values
                        ];
                        $pos++;
                    }
                }
            }
            $product['variant_options'] = $variant_options;

            $product_data = ProductDataBuilder::build_product($product);
        // error_log("[MIGRATION] WC $wc_id: calling SureCartSender::create_product with data: " . wp_json_encode($product_data) . "\n", 3, WP_CONTENT_DIR.'/migration.log');
        $reponse = SureCartSender::create_product($product_data);
        if (is_wp_error($reponse)) {
                // error_log("[MIGRATION] WC $wc_id: FAILED to create product: " . $reponse->get_error_message() . "\n", 3, WP_CONTENT_DIR.'/migration.log');
                MigrationLogger::log('products', $wc_id, 'error', "Failed to create product: " . $reponse->get_error_message());
                IdMapper::update_status('product', $wc_id, 'failed');
                return;
            }

        $sc_id = $reponse['id'];
        // error_log("[MIGRATION] WC $wc_id: product created successfully, SC ID: $sc_id. Downloadable: {$product['_downloadable']}, files: " . (is_array($product['_downloadable_files'] ?? null) ? count($product['_downloadable_files']) : 0) . "\n", 3, WP_CONTENT_DIR.'/migration.log');
            IdMapper::save_mapping('product', $wc_id, $sc_id, 'completed');
            $this->handle_downloads($product, $sc_id);

        // Link to group if this is a child
        if ($sc_group_id) {
            SureCartSender::update_product($sc_id, [
                'associated_product_group_id' => $sc_group_id,
                'associated_upgrade_group_id' => $sc_group_id,
                'product_group' => $sc_group_id
            ]);
            MigrationLogger::log('products', $wc_id, 'info', "Linked child $sc_id to group $sc_group_id");
        }

        // Handle Media Migration
        $media_patch = ProductDataBuilder::product_media_creation($product, $sc_id);
        if ($media_patch) {
            $media_resp = SureCartSender::update_product($sc_id, $media_patch);
            if (is_wp_error($media_resp)) {
                MigrationLogger::log('products', $wc_id, 'warning', "Error updating product media: " . $media_resp->get_error_message());
            }
        }

        // Sync image thumbnail to local sc_product CPT post in WordPress
        $wc_thumb_id = get_post_thumbnail_id($wc_id);
        if ($wc_thumb_id) {
            global $wpdb;
            $sc_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s ORDER BY post_id DESC LIMIT 1",
                $sc_id
            ));
            if (!$sc_post_id && !empty($product['post_title'])) {
                $sc_post_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'sc_product' AND post_title = %s ORDER BY ID DESC LIMIT 1",
                    $product['post_title']
                ));
            }
            if ($sc_post_id) {
                set_post_thumbnail($sc_post_id, $wc_thumb_id);
            }
        }

        $variation_data = WooFetcher::get_variations($wc_id);
        if (!empty($variation_data)) {
            foreach ($variation_data as $variation) {
                $wc_var_id      = $variation->ID;
                $variation_meta = WooFetcher::get_product_variation_meta_data($wc_var_id);

                $variant_data = ProductDataBuilder::build_variant($variation_meta, $sc_id, $variation, $option_mapping);
                $var_resp = SureCartSender::create_variant($sc_id, $variant_data);
                if (is_wp_error($var_resp)) {
                    // echo "    -> Error creating variant for WC_ID $wc_var_id: " . $var_resp->get_error_message() . PHP_EOL;
                } else {
                    IdMapper::save_mapping('variant', $wc_var_id, $var_resp['id']);
                    // Create downloads after variant is mapped so SC variant ID is available
                    $this->handle_downloads($variation_meta, $sc_id, $wc_var_id);

                    // Create a price on the parent product for this variant so orders can reference it
                    $var_amount = isset($variation_meta['_price']) && $variation_meta['_price'] !== ''
                        ? (int) round((float) $variation_meta['_price'] * 100)
                        : (int) $var_resp['amount'];

                    $currency = function_exists('get_woocommerce_currency') ? strtolower(get_woocommerce_currency()) : 'usd';
                    $var_price_data = ProductDataBuilder::product_price_creation($sc_id, $variation_meta);
                    if ($var_price_data) {
                        // Override product & currency for safety
                        $var_price_data['product']  = $sc_id;
                        $var_price_data['currency']  = $currency;
                        $var_price_resp = SureCartSender::create_price($var_price_data);
                        if (!is_wp_error($var_price_resp) && !empty($var_price_resp['id'])) {
                            IdMapper::save_mapping('price', $wc_var_id, $var_price_resp['id']);
                        }
                    }
                }
            }
        }

        // For simple products or products with a single price
        if ($product_data['type'] === 'simple') {
            $price_data = ProductDataBuilder::product_price_creation($sc_id, $product);
            if ($price_data) {
                $price_resp = SureCartSender::create_price($price_data);
                if (is_wp_error($price_resp)) {
                    // echo "    -> Error creating price: " . $price_resp->get_error_message() . PHP_EOL;
                } elseif (!empty($price_resp['id'])) {
                    // Save price ID mapped to WC product ID so orders can reference it
                    IdMapper::save_mapping('price', $wc_id, $price_resp['id']);
                }
            }
        }

            $this->update_migration_option($wc_id, $sc_id, 'completed');
    }

    public function update_migration_option($wc_id, $sc_id, $status)
    {
        $migrated_products = get_option('sc_product_migration', []);
        if (!is_array($migrated_products)) {
            $migrated_products = [];
        }
        $migrated_products[] = [
            'wc_id'        => $wc_id,
            'sc_id'        => $sc_id,
            'status'       => $status,
            'sc_edit_url'  => admin_url('admin.php?page=surecart#/products/' . $sc_id),
        ];
        update_option('sc_product_migration', $migrated_products);
    }

    public function get_or_create_sc_group_id($wc_parent_id)
    {
        $sc_group_id = IdMapper::get_sc_id('product_group', $wc_parent_id);
        if ($sc_group_id) {
            return $sc_group_id;
        }

        $parent_post = get_post($wc_parent_id);
        if (!$parent_post) {
            return null;
        }

        $group_data = [
            'name' => $parent_post->post_title,
            'description' => $parent_post->post_content,
        ];
        
        $response = SureCartSender::create_product_group($group_data);
        if (!is_wp_error($response) && isset($response['id'])) {
            $sc_group_id = $response['id'];
            IdMapper::save_mapping('product_group', $wc_parent_id, $sc_group_id, 'completed');
            // Ensure parent product status is also updated
            IdMapper::save_mapping('product', $wc_parent_id, $sc_group_id, 'completed');
            return $sc_group_id;
        }
        
        return null;
    }



    private function update_progress($processed)
    {
        // $progress = get_option('smack_wc_surecart_progress', []);
        // if (empty($progress) || $progress['module'] !== 'products') {
        //     $progress = [
        //         'total' => WooFetcher::get_count('products'),
        //         'completed' => 0,
        //         'module' => 'products'
        //     ];
        // }
        // $progress['completed'] += $processed;
        // update_option('smack_wc_surecart_progress', $progress);
    }

    private function handle_downloads($data, $sc_id, $wc_variant_id = null)
    {
        $entity_id = $data['ID'] ?? 0;
        // error_log("[MIGRATION] handle_downloads called for entity $entity_id, sc_id=$sc_id, _downloadable=" . ($data['_downloadable'] ?? 'NOT SET') . ", files=" . (is_array($data['_downloadable_files'] ?? null) ? count($data['_downloadable_files']) : 'NOT SET') . "\n", 3, WP_CONTENT_DIR.'/migration.log');

        if (isset($data['_downloadable']) && $data['_downloadable'] === 'yes' && !empty($data['_downloadable_files'])) {
            $sc_variant_id = $wc_variant_id ? IdMapper::get_sc_id('variant', $wc_variant_id) : null;
            // error_log("[MIGRATION] entity $entity_id: processing " . count($data['_downloadable_files']) . " download files for SC product $sc_id" . ($sc_variant_id ? ", variant $sc_variant_id" : '') . "\n", 3, WP_CONTENT_DIR.'/migration.log');

            foreach ($data['_downloadable_files'] as $key => $file) {
                // error_log("[MIGRATION] entity $entity_id: file key=$key, name=" . ($file['name'] ?? 'NO NAME') . ", url=" . ($file['file'] ?? 'NO FILE') . "\n", 3, WP_CONTENT_DIR.'/migration.log');
                if (empty($file['file'])) {
                    // error_log("[MIGRATION] entity $entity_id: SKIPPING file - empty url\n", 3, WP_CONTENT_DIR.'/migration.log');
                    continue;
                }

                $download_data = ProductDataBuilder::build_download($file, $sc_id, $sc_variant_id);
                // error_log("[MIGRATION] entity $entity_id: sending download to API: " . wp_json_encode($download_data) . "\n", 3, WP_CONTENT_DIR.'/migration.log');
                $resp = SureCartSender::create_download($download_data);
                if (is_wp_error($resp)) {
                    // error_log("[MIGRATION] entity $entity_id: FAILED download creation: " . $resp->get_error_message() . "\n", 3, WP_CONTENT_DIR.'/migration.log');
                    MigrationLogger::log('products', $entity_id, 'error', "Failed to create download {$file['file']}: " . $resp->get_error_message());
                } else {
                    // error_log("[MIGRATION] entity $entity_id: download created OK, id=" . ($resp['id'] ?? 'no id') . "\n", 3, WP_CONTENT_DIR.'/migration.log');
                    MigrationLogger::log('products', $entity_id, 'info', "Download created: {$file['name']} -> " . ($resp['id'] ?? 'no id'));
                }
            }
        } else {
            // error_log("[MIGRATION] entity $entity_id: NOT downloadable or no files, skipping downloads\n", 3, WP_CONTENT_DIR.'/migration.log');
        }
    }

    public function migrate_product_media($product, $sc_id)
    {
        global $wpdb;
        $wc_id = $product['ID'] ?? 0;

        // 1. Featured Image
        $wc_thumb_id = get_post_thumbnail_id($wc_id) ?: ($product['_thumbnail_id'] ?? 0);
        $featured_url = '';
        if (!empty($product['featured_image_url'])) {
            $featured_url = $product['featured_image_url'];
        } elseif ($wc_thumb_id) {
            $featured_url = wp_get_attachment_url($wc_thumb_id);
        }

        // 2. Gallery Images
        $gallery_urls = [];
        $gallery_ids = [];
        $gallery_meta = get_post_meta($wc_id, '_product_image_gallery', true);
        if (!empty($gallery_meta)) {
            $gallery_ids = array_filter(array_map('intval', explode(',', $gallery_meta)));
        } elseif (!empty($product['gallery_images'])) {
            foreach ($product['gallery_images'] as $img) {
                if (is_array($img) && !empty($img['id'])) {
                    $gallery_ids[] = (int) $img['id'];
                }
            }
        }

        foreach ($gallery_ids as $gid) {
            $gurl = wp_get_attachment_url($gid);
            if ($gurl && $gurl !== $featured_url && !in_array($gurl, $gallery_urls)) {
                $gallery_urls[] = $gurl;
            }
        }

        // Also check if gallery_images in $product array has raw URLs
        if (!empty($product['gallery_images']) && is_array($product['gallery_images'])) {
            foreach ($product['gallery_images'] as $img) {
                $raw_url = is_array($img) ? ($img['url'] ?? '') : (is_string($img) ? $img : '');
                if ($raw_url && $raw_url !== $featured_url && !in_array($raw_url, $gallery_urls)) {
                    $gallery_urls[] = $raw_url;
                }
            }
        }

        // 3. Sync to WordPress local sc_product CPT post thumbnail so wp-admin/admin.php?page=sc-products renders it
        $sc_post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sc_id' AND meta_value = %s ORDER BY post_id DESC LIMIT 1",
            $sc_id
        ));
        if (!$sc_post_id && !empty($product['post_title'])) {
            $sc_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'sc_product' AND post_title = %s ORDER BY ID DESC LIMIT 1",
                $product['post_title']
            ));
        }

        if (!$sc_post_id && !empty($product['post_title'])) {
            $sc_post_id = wp_insert_post([
                'post_title'   => $product['post_title'],
                'post_content' => $product['post_content'] ?? '',
                'post_excerpt' => $product['post_excerpt'] ?? '',
                'post_status'  => 'publish',
                'post_type'    => 'sc_product',
            ]);
        }

        if ($sc_post_id && !is_wp_error($sc_post_id)) {
            update_post_meta($sc_post_id, 'sc_id', $sc_id);
            if ($wc_thumb_id) {
                set_post_thumbnail($sc_post_id, $wc_thumb_id);
            }
            if (!empty($gallery_ids)) {
                update_post_meta($sc_post_id, '_product_image_gallery', implode(',', $gallery_ids));
            }
        }

        // Assemble all images to migrate
        $all_images = [];
        if ($featured_url) {
            $all_images[] = ['url' => $featured_url, 'is_featured' => true];
        }
        foreach ($gallery_urls as $gurl) {
            $all_images[] = ['url' => $gurl, 'is_featured' => false];
        }

        if (empty($all_images)) {
            return;
        }

        $first_pmedia_id = null;
        $success_count = 0;

        // Strategy 1 & Strategy 2: Create Media & ProductMedia objects
        foreach ($all_images as $img_item) {
            $url = $img_item['url'];
            $is_feat = $img_item['is_featured'];

            $media_id = null;
            $pmedia_id = null;

            // Strategy 1: SureCart PHP SDK Models (when SureCart plugin is active)
            if (class_exists('\SureCart\Models\Media') && class_exists('\SureCart\Models\ProductMedia')) {
                try {
                    $media_model = \SureCart\Models\Media::create(['url' => $url]);
                    if (!is_wp_error($media_model) && !empty($media_model->id)) {
                        $media_id = $media_model->id;
                    }
                } catch (\Throwable $t) {}

                if ($media_id) {
                    try {
                        $pmedia_model = \SureCart\Models\ProductMedia::create([
                            'product' => $sc_id,
                            'media'   => $media_id,
                        ]);
                        if (!is_wp_error($pmedia_model) && !empty($pmedia_model->id)) {
                            $pmedia_id = $pmedia_model->id;
                        }
                    } catch (\Throwable $t) {}
                }
            }

            // Strategy 2: SureCart REST API via HTTP
            if (!$pmedia_id) {
                $med_res = SureCartSender::request('medias', 'POST', ['media' => ['url' => $url]]);
                if (!is_wp_error($med_res) && !empty($med_res['id'])) {
                    $media_id = $med_res['id'];
                    $pmed_res = SureCartSender::request('product_medias', 'POST', [
                        'product_media' => [
                            'product' => $sc_id,
                            'media'   => $media_id,
                        ]
                    ]);
                    if (!is_wp_error($pmed_res) && !empty($pmed_res['id'])) {
                        $pmedia_id = $pmed_res['id'];
                    }
                }
            }

            if ($pmedia_id) {
                $success_count++;
                if ($is_feat || !$first_pmedia_id) {
                    $first_pmedia_id = $pmedia_id;
                }
            }
        }

        // Set featured_product_media on product
        if ($first_pmedia_id) {
            if (class_exists('\SureCart\Models\Product')) {
                try {
                    \SureCart\Models\Product::update($sc_id, ['featured_product_media' => $first_pmedia_id]);
                } catch (\Throwable $t) {}
            }
            SureCartSender::update_product($sc_id, ['featured_product_media' => $first_pmedia_id]);
        }

        // Strategy 3: Bulk update product with product_medias URLs array & image_url
        $bulk_medias = array_map(function($img) {
            return ['url' => $img['url']];
        }, $all_images);

        SureCartSender::update_product($sc_id, [
            'product_medias' => $bulk_medias,
            'image_url'      => $featured_url,
        ]);

        MigrationLogger::log('products', $wc_id, 'info', "Migrated {$success_count} media images and synced CPT thumbnail for SureCart Product {$sc_id}");
    }
}
