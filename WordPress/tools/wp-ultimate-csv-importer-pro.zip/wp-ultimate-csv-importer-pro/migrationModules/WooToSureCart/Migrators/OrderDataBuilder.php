<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class OrderDataBuilder
{
    /**
     * Build the initial checkout creation payload.
     *
     * @param array $order WooCommerce order data.
     * @return array
     */
    public static function build_checkout_create_payload($order)
    {
        return [
            'processor_type' => 'manual',
            'metadata' => [
                'wc_id' => (string) $order['ID'],
            ],
        ];
    }

    /**
     * Build the manual payment payload.
     *
     * @param array $order WooCommerce order data.
     * @return array
     */
    public static function build_manual_pay_payload($order)
    {
        return []; // Typically empty for manual pay
    }

    /**
     * Build the checkout update payload (customer, line items, addresses, metadata).
     * Used to populate the checkout session before payment.
     *
     * @param array  $order          WooCommerce order data from WooFetcher.
     * @param string $sc_customer_id SureCart customer ID (already migrated).
     * @return array|false Payload array, or false if line items could not be built.
     */
    public static function build_checkout_payload($order, $sc_customer_id)
    {
        $line_items = self::build_line_items($order);

        if (empty($line_items)) {
            return false;
        }

        $payload = [
            'customer'   => $sc_customer_id,
            'line_items' => $line_items,
            'metadata'   => [
                'wc_id'                => (string) $order['ID'],
                'payment_method'       => $order['_payment_method'],
                'payment_method_title' => $order['_payment_method_title'],
                'transaction_id'       => $order['_transaction_id'],
                'date_paid'            => $order['date_paid'],
                'customer_note'        => $order['customer_note'],
                'original_status'      => $order['status'],
                'original_date'        => $order['date_created'],
            ],
            'processor_type' => 'manual',
        ];
        
        if (!empty($order['coupons'])) {
            // SureCart expects 'discount' => ['promotion_code' => 'CODE'] for applying coupons in PATCH
            $payload['discount'] = [
                'promotion_code' => $order['coupons'][0] // Applying the first coupon
            ];
        }
 
        if (!empty($order['billing_address']['line_1']) || !empty($order['billing_address']['city'])) {
            $payload['billing_address'] = $order['billing_address'];
        }

        if (!empty($order['shipping_address']['line_1']) || !empty($order['shipping_address']['city'])) {
            $payload['shipping_address'] = $order['shipping_address'];
        }

        return $payload;
    }

    /**
     * Build line items payload only.
     */
    public static function build_step_products_payload($order)
    {
        return [
            'line_items' => self::build_line_items($order)
        ];
    }

    /**
     * Build customer payload only.
     */
    public static function build_step_customer_payload($sc_customer_id)
    {
        return [
            'customer' => $sc_customer_id
        ];
    }

    /**
     * Build address payload only.
     */
    public static function build_step_address_payload($order)
    {
        $payload = [];
        if (!empty($order['billing_address']['line_1']) || !empty($order['billing_address']['city'])) {
            $payload['billing_address'] = $order['billing_address'];
        }
        if (!empty($order['shipping_address']['line_1']) || !empty($order['shipping_address']['city'])) {
            $payload['shipping_address'] = $order['shipping_address'];
        }
        return $payload;
    }

    /**
     * Build coupon payload only.
     */
    public static function build_step_coupon_payload($order)
    {
        if (empty($order['coupons'])) {
            return [];
        }
        return [
            'discount' => [
                'promotion_code' => $order['coupons'][0]
            ]
        ];
    }

    /**
     * Build metadata payload only.
     */
    public static function build_step_metadata_payload($order)
    {
        return [
            'metadata' => [
                'wc_id'                => (string) $order['ID'],
                'payment_method'       => $order['_payment_method'],
                'payment_method_title' => $order['_payment_method_title'],
                'transaction_id'       => $order['_transaction_id'],
                'date_paid'            => $order['date_paid'],
                'customer_note'        => $order['customer_note'],
                'original_status'      => $order['status'],
                'original_date'        => $order['date_created'],
            ],
            'shipping_address_accuracy_requirement' => 'none' // Important for finalize validation
        ];
    }

    /**
     * Build the order patch payload (status, date, etc.).
     * Called after the order has been created to override the default "paid" status
     * and set the original creation date.
     *
     * @param array $order WooCommerce order data.
     * @return array|null Payload for PATCH /orders/{id}, or null if no update needed.
     */
    public static function build_order_patch_payload($order)
    {
        $payload = [];
        $sc_status = self::map_status($order['status']);

        // Set status
        $payload['status'] = $sc_status;

        if (!empty($order['date_created'])) {
            $payload['created_at'] = $order['date_created'];
        }

        return $payload;
    }

    /**
     * Returns true when the WC status maps to "paid" in SureCart.
     * For these orders the checkout manually_pay step is sufficient.
     */
    public static function is_paid_status($wc_status)
    {
        return self::map_status($wc_status) === 'paid';
    }

    /**
     * Build line items for a WooCommerce order, resolving SureCart price IDs.
     * Looks up already-migrated price mappings first; falls back to creating a
     * dynamic price on the parent SC product when none exists.
     *
     * @param array $order WooCommerce order data from WooFetcher.
     * @return array SureCart-compatible line items array.
     */
    public static function build_line_items($order)
    {
        $line_items = [];

        foreach ($order['line_items'] as $item) {
            $is_variation  = !empty($item['variation_id']);
            $wc_product_id = $item['product_id'];
            $wc_var_id     = $item['variation_id'];
            $quantity      = (int) $item['quantity'] > 0 ? (int) $item['quantity'] : 1;

            // 1. Look up already-created SureCart price ID
            $sc_price_id   = null;
            $sc_variant_id = null;

            if ($is_variation) {
                // Price was created during product migration, keyed to WC variation ID
                $sc_price_id   = IdMapper::get_sc_id('price', $wc_var_id)
                                 ?: IdMapper::get_sc_id('price', $wc_product_id);
                $sc_variant_id = IdMapper::get_sc_id('variant', $wc_var_id);
            } else {
                $sc_price_id = IdMapper::get_sc_id('price', $wc_product_id);
            }

            if ($sc_price_id) {
                echo "    -> Using mapped price ID $sc_price_id for '{$item['name']}'\n";
                $line_item = [
                    'price'    => $sc_price_id,
                    'quantity' => $quantity,
                ];
                if ($sc_variant_id) {
                    $line_item['variant'] = $sc_variant_id;
                }
                $line_items[] = $line_item;
                continue;
            }

            // 2. No price mapping – create a dynamic price on the SC parent product
            $sc_product_id = IdMapper::get_sc_id('product', $wc_product_id);
            if (!$sc_product_id) {
                // Create / reuse a catch-all dummy product for unmapped items
                $sc_product_id = get_option('dummy_product_id');
                if (!$sc_product_id) {
                    $dummy = SureCartSender::create_product([
                        'name'             => 'Legacy Migrated Order Items',
                        'type'             => 'simple',
                        'status'           => 'published',
                        'shipping_enabled' => false,
                    ]);
                    if (!is_wp_error($dummy) && isset($dummy['id'])) {
                        $sc_product_id = $dummy['id'];
                        update_option('dummy_product_id', $sc_product_id);
                    }
                }
            }

            $unit_price   = $item['quantity'] > 0
                ? (float) $item['subtotal'] / (int) $item['quantity']
                : (float) $item['subtotal'];
            $amount_cents = (int) round($unit_price * 100);

            $price_data = [
                'amount'   => $amount_cents,
                'currency' => 'usd',   // SureCart account is USD-only
                'name'     => $item['name'] ?: 'Item',
                'product'  => $sc_product_id,
            ];

            echo "    -> Creating dynamic price for '{$item['name']}': " . json_encode($price_data) . "\n";
            $price_resp = SureCartSender::create_price($price_data);

            if (!is_wp_error($price_resp) && isset($price_resp['id'])) {
                $line_item = [
                    'price'    => $price_resp['id'],
                    'quantity' => $quantity,
                ];
                if ($sc_variant_id) {
                    $line_item['variant'] = $sc_variant_id;
                }
                $line_items[] = $line_item;
            } else {
                echo "    -> Failed to create dynamic price for '{$item['name']}': ";
                echo is_wp_error($price_resp) ? $price_resp->get_error_message() : json_encode($price_resp);
                echo "\n";
            }
        }

        return $line_items;
    }

    /**
     * Map a WooCommerce order status to the equivalent SureCart order status.
     */
    public static function map_status($wc_status)
    {
        $map = [
            'pending'    => 'processing',
            'processing' => 'paid',
            'completed'  => 'paid',
            'on-hold'    => 'processing',
            'cancelled'  => 'void',
            'refunded'   => 'refunded',
            'failed'     => 'payment_failed',
        ];
        return isset($map[$wc_status]) ? $map[$wc_status] : 'processing';
    }
}