<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class FieldMapper
{
    public static function get_product_mapping()
    {
        return [
            'post_title' => 'name',
            'post_content' => 'description',
            '_price' => 'price',
            '_sku' => 'sku',
            '_stock' => 'inventory'
        ];
    }

    public static function get_customer_mapping()
    {
        return [
            'user_email' => 'email',
            'billing_first_name' => 'first_name',
            'billing_last_name' => 'last_name',
            'billing_phone' => 'phone',
            'billing_address_1' => 'address_1',
            'billing_address_2' => 'address_2',
            'billing_city' => 'city',
            'billing_state' => 'state',
            'billing_postcode' => 'postcode',
            'billing_country' => 'country'
        ];
    }

    public static function get_order_mapping()
    {
        return [
            'order_id' => 'external_id',
            'order_items' => 'line_items',
            'status' => 'status',
            'total' => 'total',
            'payment_method' => 'gateway'
        ];
    }
}
