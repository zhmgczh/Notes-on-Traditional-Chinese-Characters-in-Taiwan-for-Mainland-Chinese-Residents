<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class IdMapper {
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL,
            wc_id bigint(20) NOT NULL,
            sc_id varchar(100) NOT NULL,
            status varchar(20) DEFAULT 'started' NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY type_wc_id (type, wc_id),
            KEY sc_id (sc_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        $result_010 = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}smack_sc_map'");
		if($result_010 != 0){
			$wpdb->query("RENAME TABLE {$wpdb->prefix}smack_sc_map TO {$wpdb->prefix}sm_uci_addon_pro_sc_map");
		}
    }

    public static function save_mapping($type, $wc_id, $sc_id, $status = 'completed') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        
        if (self::mapping_exists($type, $wc_id)) {
            $wpdb->update(
                $table_name,
                array(
                    'sc_id' => $sc_id, 
                    'status' => $status,
                    'created_at' => current_time('mysql')
                ),
                array('type' => $type, 'wc_id' => $wc_id),
                array('%s', '%s', '%s'),
                array('%s', '%d')
            );
        } else {
            $wpdb->insert(
                $table_name,
                array(
                    'type' => $type,
                    'wc_id' => $wc_id,
                    'sc_id' => $sc_id,
                    'status' => $status
                ),
                array('%s', '%d', '%s', '%s')
            );
        }
    }

    public static function update_status($type, $wc_id, $status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        $wpdb->update(
            $table_name,
            array('status' => $status),
            array('type' => $type, 'wc_id' => $wc_id),
            array('%s'),
            array('%s', '%d')
        );
    }

    public static function get_status($type, $wc_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        return $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM $table WHERE type = %s AND wc_id = %d",
            $type, $wc_id
        ));
    }

    public static function get_sc_id($type, $wc_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        return $wpdb->get_var($wpdb->prepare(
            "SELECT sc_id FROM $table_name WHERE type = %s AND wc_id = %d AND status = 'completed' AND sc_id != '' ORDER BY id DESC LIMIT 1",
            $type, $wc_id
        ));
    }

    public static function mapping_exists($type, $wc_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE type = %s AND wc_id = %d LIMIT 1",
            $type, $wc_id
        ));
        return !empty($id);
    }

    public static function get_wc_sc_mapping($module) {
        global $wpdb;

        $table = $wpdb->prefix . 'sm_uci_addon_pro_sc_map';

        $rows = $wpdb->get_results(
            "SELECT type, wc_id, sc_id, status FROM $table ORDER BY id ASC",
            ARRAY_A
        );

        $result = [];
        $line = 1;
        $current_line = '';

        foreach ($rows as $row) {

            // PRODUCT MODULE
            if ($module === 'products' && in_array($row['type'], ['product','variant','price'])) {

                if ($row['type'] === 'product') {

                    $current_line = 'line' . $line;

                    $result[$current_line] = [
                        'product_wc_id' => $row['wc_id'],
                        'product_sc_id' => $row['sc_id'],
                        'status' => $row['status'],
                        'variants' => []
                    ];

                    $line++;
                }

                if ($row['type'] === 'variant') {

                    $result[$current_line]['variants'][$row['wc_id']]['variant_sc_id'] = $row['sc_id'];
                }

                if ($row['type'] === 'price') {

                    if (isset($result[$current_line]['variants'][$row['wc_id']])) {

                        $result[$current_line]['variants'][$row['wc_id']]['price_sc_id'] = $row['sc_id'];

                    } else {

                        $result[$current_line]['price_sc_id'] = $row['sc_id'];
                    }
                }
            }

            // CUSTOMER MODULE
            if ($module === 'customers' && $row['type'] === 'customer') {
                $result['line'.$line] = [
                    'customer_wc_id' => $row['wc_id'],
                    'customer_sc_id' => $row['sc_id'],
                    'status' => $row['status']
                ];
                $line++;
            }

            // COUPON MODULE
            if ($module === 'coupons' && in_array($row['type'], ['coupon','promotion'])) {

                $result['line'.$line] = [
                    'coupon_wc_id' => $row['wc_id'],
                    'coupon_sc_id' => $row['sc_id'],
                    'status' => $row['status']
                ];

                $line++;
            }
        }

        return $result;
    }
}
