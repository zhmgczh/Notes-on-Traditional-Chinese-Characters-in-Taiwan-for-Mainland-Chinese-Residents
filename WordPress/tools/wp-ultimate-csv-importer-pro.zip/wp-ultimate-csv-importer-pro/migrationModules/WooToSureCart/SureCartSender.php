<?php
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH')) {
    exit;
}

class SureCartSender
{
    public static function get_api_key()
    {
        $key = get_option('surecart_api_key', '');
        return ScheduleCredentialCipher::decrypt($key);
    }

    public static function get_api_url()
    {
        return 'https://api.surecart.com/v1/';
    }

    public static function request($endpoint, $method = 'POST', $data = [])
    {
        $url = self::get_api_url() . ltrim($endpoint, '/');
        $api_key = self::get_api_key();

        if (empty($api_key)) {
            // Check if SureCart localized API exists but the instructions say SureCart REST API & Bearer Toker.
            // Using API key for authentication.
        }

        $args = [
            'method' => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'timeout' => 45,
        ];

        if ($method === 'POST' || $method === 'PATCH' || $method === 'PUT') {
            $args['body'] = wp_json_encode($data);
        }

        $attempts = 0;
        $max_retries = 3;

        while ($attempts < $max_retries) {
            $response = wp_remote_request($url, $args);
            
            $log_prefix = "[API REQUEST] " . date('Y-m-d H:i:s') . " $method $url\n";
            $log_body = "Payload: " . wp_json_encode($data) . "\n";
            // error_log($log_prefix . $log_body, 3, WP_CONTENT_DIR.'/migration.log');

            if (!is_wp_error($response)) {
                $status_code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);
                
                $log_resp = "[API RESPONSE] Status: $status_code, Body: $body\n";
                // error_log($log_resp, 3, WP_CONTENT_DIR.'/migration.log');

                if ($status_code >= 200 && $status_code < 300) {
                    return json_decode($body, true);
                }

                MigrationLogger::log('api', $endpoint, 'error', "API request to $endpoint failed with status $status_code: " . $body);

                if ($status_code == 429 || $status_code >= 500) {
                    $attempts++;
                    sleep(2);
                    continue;
                }

                return new \WP_Error('surecart_api_error', wp_remote_retrieve_body($response));
            } else {
                $err_msg = "[API ERROR] " . $response->get_error_message() . "\n";
                // error_log($err_msg, 3, WP_CONTENT_DIR.'/migration.log');
            }

            $attempts++;
            if ($attempts >= $max_retries) {
                return $response;
            }
            sleep(2);
        }

        return new \WP_Error('surecart_api_error', 'Max retries exceeded');
    }

    public static function create_product($data)
    {
        return self::request('products', 'POST', ['product' => $data]);
    }

    public static function update_product($id, $data)
    {
        return self::request("products/{$id}", 'PATCH', ['product' => $data]);
    }

    public static function create_variant($product_id, $data)
    {
        $data['product'] = $product_id;
        return self::request('variants', 'POST', ['variant' => $data]);
    }

    public static function update_variant($variant_id, $data)
    {
        return self::request("variants/{$variant_id}", 'PATCH', $data);
    }

    public static function create_collection($name, $slug = '', $description = '')
    {
        return self::request('product_collections', 'POST', [
            'product_collection' => [
                'name' => $name,
                'slug' => $slug ?: sanitize_title($name),
                'description' => $description
            ]
        ]);
    }

    public static function create_price($data)
    {
        return self::request('prices', 'POST', ['price' => $data]);
    }

    public static function create_customer($data)
    {
        return self::request('customers', 'POST', ['customer' => $data]);
    }

    public static function create_order($data)
    {
        return self::request('orders', 'POST', $data);
    }

    public static function create_subscription($data)
    {
        return self::request('subscriptions', 'POST', $data);
    }

    public static function create_coupon($data)
    {
        return self::request('coupons', 'POST', ['coupon' => $data]);
    }

    public static function create_promotion($coupon_id, $code)
    {
        return self::request('promotions', 'POST', [
            'promotion' => [
                'coupon_id' => $coupon_id,
                'code' => $code
            ]
        ]);
    }

    public static function create_product_group($data)
    {
        return self::request('product_groups', 'POST', ['product_group' => $data]);
    }

    public static function update_order($order_id, $data)
    {
        return self::request("orders/{$order_id}", 'PATCH', ['order' => $data]);
    }

    
    public static function create_invoice($data)
    {
        return self::request('invoices', 'POST', ['invoice' => $data]);
    }

    public static function create_checkout($data = [])
    {
        // processor_type must be set or SureCart API returns 500
        if (!isset($data['processor_type'])) {
            $data['processor_type'] = 'manual';
        }
        return self::request('checkouts', 'POST', ['checkout' => $data]);
    }

    public static function update_checkout($checkout_id, $data)
    {
        return self::request("checkouts/{$checkout_id}", 'PATCH', ['checkout' => $data]);
    }
 
    public static function finalize_checkout($checkout_id, $data = [])
    {
        return self::request("checkouts/{$checkout_id}/finalize", 'PATCH', ['checkout' => $data]);
    }

    public static function manually_pay_checkout($checkout_id, $data = [])
    {
        return self::request("checkouts/{$checkout_id}/manually_pay", 'PATCH', ['checkout' => $data]);
    }


    public static function create_download($data)
    {
        return self::request('downloads', 'POST', ['download' => $data]);
    }
}
