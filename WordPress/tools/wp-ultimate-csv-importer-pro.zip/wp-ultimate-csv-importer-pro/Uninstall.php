<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

/**
 * Class SmackUCIUnInstall
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

class SmackUCIUnInstall {
	/**
	 * UnInstall UCI Pro.
	 */
	protected static $instance = null;
	public $plugin;	
	public function __construct() {
		$this->plugin = null;
	}

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * unInstall
	 *
	 * @return void
	 */
	public static function unInstall() {
		global $wpdb;
		$wpdb->hide_errors();
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Clean up all scheduled cron events
		self::cleanup_cron_events();

		// Clean up plugin options
		self::cleanup_options();

		// Clean up database tables
		self::cleanup_database_tables();
	}

	/**
	 * Clean up plugin options
	 */
	private static function cleanup_options() {
		// Remove plugin options specific to Ultimate Pro
		delete_option('sm_uci_ultimate_pro_settings');
		delete_option('ULTIMATE_CSV_IMP_VERSION');
		delete_option('sm_uci_db_version');
		delete_option('sm_uci_pro_automation_api_key');
		delete_option('sm_uci_pro_media_download_settings');
		wp_clear_scheduled_hook('sm_uci_pro_media_queue_cron');

		// Remove any other Ultimate Pro-specific options
		global $wpdb;
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'sm_uci_ultimate_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'ultimate_csv_importer_%'");
	}

	/**
	 * Clean up database tables
	 */
	private static function cleanup_database_tables() {
		global $wpdb;
		$prefix = $wpdb->prefix;
		
		// Check if user wants to drop tables (from settings)
		$ucisettings = get_option('sm_uci_ultimate_pro_settings');
		$droptable = isset($ucisettings['drop_table']) ? $ucisettings['drop_table'] : '';		
		// If plugin is being completely uninstalled, force drop tables
		if(!empty($droptable) && $droptable == 'true'){
			$tables = array(
				"{$prefix}sm_uci_addon_pro_external_file_schedules",
				"{$prefix}sm_uci_addon_pro_ftp_schedules",
				"{$prefix}ultimate_csv_importer_mappingtemplate",
				"{$prefix}sm_uci_addon_pro_scheduled_import",
				"{$prefix}sm_uci_addon_pro_scheduled_export",
				"{$prefix}sm_uci_addon_pro_export_template",
				"{$prefix}import_detail_log",
				"{$prefix}smackcsv_file_events",
				"{$prefix}sm_uci_addon_pro_media_report",
				"{$prefix}ultimate_csv_importer_shortcode_manager",	
				"{$prefix}smackuci_events",
				"{$prefix}sm_uci_addon_pro_field_types",
				"{$prefix}ultimate_csv_importer_acf_fields",
				"{$prefix}sm_uci_addon_pro_post_entries_table",
				"{$prefix}sm_uci_addon_pro_clitemplate",
				"{$prefix}sm_uci_addon_pro_retry_queue",
				"{$prefix}sm_uci_addon_pro_retry_history",
				"{$prefix}sm_uci_addon_pro_import_checkpoint",
				"{$prefix}sm_uci_addon_pro_import_row_log",
				"{$prefix}sm_uci_addon_pro_ai_reviews",
				"{$prefix}sm_uci_addon_pro_ai_usage_log",
				"{$prefix}sm_uci_addon_pro_ai_prompt_templates",
				"{$prefix}sm_uci_addon_pro_db_connections",
				"{$prefix}sm_uci_addon_pro_db_import_sessions",
				"{$prefix}sm_uci_addon_pro_automation_jobs"
			);
			
			foreach($tables as $table) {
				$wpdb->query("DROP TABLE IF EXISTS {$table}");
			}
		}
	}

	/**
	 * Deactivation method - called when plugin is deactivated
	 * Only cleans up cron events, doesn't drop tables
	 */
	public static function deactivate() {
		self::cleanup_cron_events();
	}

	/**
	 * Public method to manually clear cron events (for debugging/testing)
	 */
	public static function manual_cron_cleanup() {
		self::cleanup_cron_events();
	}

	/**
	 * Clean up all scheduled cron events when plugin is deactivated
	 */
	private static function cleanup_cron_events() {
		// Clear all scheduled events with custom schedules
		wp_clear_scheduled_hook('smack_uci_cron_scheduler');
		wp_clear_scheduled_hook('smack_uci_cron_scheduled_export');
		wp_clear_scheduled_hook('smack_uci_image_scheduler');
		wp_clear_scheduled_hook('smack_uci_email_scheduler');
		wp_clear_scheduled_hook('smack_uci_schedule_heartbeat');
		wp_clear_scheduled_hook('smack_uci_replace_inline_images');
		wp_clear_scheduled_hook('uci_pro_automation_execute');
		wp_clear_scheduled_hook('sm_uci_pro_media_queue_cron');
		
		// Clear image schedule hooks
		wp_clear_scheduled_hook('smackcf_image_schedule_hook');
		
		// Get all scheduled events and clear any that use our custom schedules
		$cron_events = _get_cron_array();
		if (!empty($cron_events)) {
			foreach ($cron_events as $timestamp => $cron) {
				foreach ($cron as $hook => $events) {
					foreach ($events as $sig => $event) {
						// Check if this event uses any of our custom schedules
						$schedule = $event['schedule'];
						if (strpos($schedule, 'smack_') === 0 || 
							strpos($schedule, 'wp_ultimate_csv_importer_') === 0 ||
							$schedule === 'smack_image_every_second' ||
							$schedule === 'smack_inline_every_second' ||
							$schedule === 'smack_every_five_minutes' ||
							$schedule === 'smack_every_ten_minutes' ||
							$schedule === 'smack_every_fifteen_minutes' ||
							$schedule === 'smack_every_thirty_minutes' ||
							$schedule === 'smack_every_one_hour' ||
							$schedule === 'smack_every_two_hrs' ||
							$schedule === 'smack_every_four_hrs' ||
							$schedule === 'smack_daily' ||
							$schedule === 'smack_weekly' ||
							$schedule === 'smack_monthly' ||
							$schedule === 'smack_one_time') {
							wp_unschedule_event($timestamp, $hook, $event['args']);
						}
					}
				}
			}
		}
		
		// Clear any remaining scheduled events for our hooks
		wp_clear_scheduled_hook('smack_uci_cron_scheduler');
		wp_clear_scheduled_hook('smack_uci_cron_scheduled_export');
		wp_clear_scheduled_hook('smack_uci_image_scheduler');
		wp_clear_scheduled_hook('smack_uci_email_scheduler');
		wp_clear_scheduled_hook('smack_uci_schedule_heartbeat');
		wp_clear_scheduled_hook('smack_uci_replace_inline_images');
		wp_clear_scheduled_hook('uci_pro_automation_execute');
		wp_clear_scheduled_hook('smackcf_image_schedule_hook');
		
		// Also clear any events that might be using our custom schedules but with different hook names
		$all_schedules = array(
			'smack_image_every_second',
			'smack_inline_every_second',
			'smack_every_five_minutes',
			'smack_every_ten_minutes',
			'smack_every_fifteen_minutes',
			'smack_every_thirty_minutes',
			'smack_every_one_hour',
			'smack_every_two_hrs',
			'smack_every_four_hrs',
			'smack_daily',
			'smack_weekly',
			'smack_monthly',
			'smack_one_time',
			'wp_ultimate_csv_importer_scheduled_csv_data',
			'wp_ultimate_csv_importer_scheduled_export_data',
			'wp_ultimate_csv_importer_scheduled_emails',
		);
		
		// Force clear any events using these schedules
		foreach ($all_schedules as $schedule) {
			$cron_events = _get_cron_array();
			if (!empty($cron_events)) {
				foreach ($cron_events as $timestamp => $cron) {
					foreach ($cron as $hook => $events) {
						foreach ($events as $sig => $event) {
							if ($event['schedule'] === $schedule) {
								wp_unschedule_event($timestamp, $hook, $event['args']);
							}
						}
					}
				}
			}
		}
	}
}
