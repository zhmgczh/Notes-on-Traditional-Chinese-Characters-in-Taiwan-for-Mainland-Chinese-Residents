<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

/**
 * Class ScheduleExtension
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

class ScheduleExtension {

	private static $instance=null;
	public $plugin;	
	private static $smackcsv_instance = null,$save_mapping,$ftp_upload,$schedule_import = null,$smack_instance, $url_upload , $sftp_upload = null;
	private const DEBUG_LOG_FILE = 'wp-importer-debug.log';

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
			self::$save_mapping = SaveMapping::getInstance();
			self::$ftp_upload = FtpUpload::getInstance();
			self::$schedule_import = ScheduleImport::getInstance();
			self::$url_upload = UrlUpload::getInstance();
			self::$sftp_upload = SftpUpload::getInstance();
			self::$instance->doHooks();
			//self::$instance->smack_uci_cron_scheduler();
		}
		return self::$instance;
	}

	public  function doHooks(){
		add_action('wp_ajax_save_schedule_info',array($this,'saveEventInformationToSchedule'));
		add_action('wp_ajax_timezone' ,array($this,'timezone'));
	}	

	/**
	 * ScheduleExtension constructor.
	 * Set values into global variables based on post value
	 */
	public function __construct() {
		$this->plugin = class_exists("Smackcoders\UCI\Core\UCICore") ? \Smackcoders\UCI\Core\UCICore::getInstance() : null;	
	}

	private function debug_log($function_name, $stage, $data = array())
	{
		// Intentionally disabled — schedule debug file logging removed for production.
	}

	private function get_retry_transient_key($schedule_id)
	{
		return 'import_retry_' . intval($schedule_id);
	}

	private function is_retryable_failure_reason($reason)
	{
		return ScheduleStateService::getInstance()->is_retryable_failure( $reason );
	}

	private function reset_retry_counter($schedule_id, $stage = 'reset')
	{
		$retry_key = $this->get_retry_transient_key($schedule_id);
		delete_transient($retry_key);
		ScheduleStateService::getInstance()->reset_retry_count( (int) $schedule_id );
		$this->debug_log(__FUNCTION__, $stage, array(
			'schedule_id' => intval($schedule_id),
			'retry_key' => $retry_key,
		));
	}

	/**
	 * Release the isrun lock so a schedule can be picked up on the next cron tick.
	 * Required when import is skipped or fails before doSchedule() runs — otherwise
	 * isrun stays 1 and the schedule is permanently excluded from the due-query.
	 *
	 * @param int    $schedule_id Schedule row ID.
	 * @param string $reason      Short reason for debug logging.
	 */
	private function release_schedule_lock( $schedule_id, $reason = '' ) {
		ScheduleStateService::getInstance()->release_lock( $schedule_id, $reason );
		$this->debug_log( __FUNCTION__, 'lock_released', array(
			'schedule_id' => (int) $schedule_id,
			'reason'      => $reason,
		) );
	}

	/**
	 * Recover schedules stuck with isrun=1 after a fatal error, timeout, or skipped path.
	 */
	private function recover_stale_schedule_locks() {
		$count = ScheduleStateService::getInstance()->recover_stale_locks();
		if ( $count > 0 ) {
			$this->debug_log( __FUNCTION__, 'stale_lock_batch_recovered', array( 'count' => $count ) );
		}
	}

	private function maybe_reschedule_retry($scheduledEvent, $failure_reason, $schedule_table)
	{
		$schedule_id = intval($scheduledEvent->id);
		$state_service = ScheduleStateService::getInstance();

		if (!$this->is_retryable_failure_reason($failure_reason)) {
			return false;
		}

		$scheduled = $state_service->schedule_retry( $schedule_id, $failure_reason );
		if ( ! $scheduled ) {
			delete_transient( $this->get_retry_transient_key( $schedule_id ) );
			$this->debug_log(__FUNCTION__, 'final_fail_after_retries', array(
				'schedule_id' => $schedule_id,
				'failure_reason' => $failure_reason,
			));
			return false;
		}

		$meta = $state_service->get_heartbeat_meta( $schedule_id );
		$this->debug_log(__FUNCTION__, 'rescheduled_retry', array(
			'schedule_id' => $schedule_id,
			'retry_count' => $meta['retry_count'],
			'max_retries' => $meta['max_retries'],
			'failure_reason' => $failure_reason,
			'delay_seconds' => $state_service->calculate_backoff_seconds( $meta['retry_count'] ),
		));

		return true;
	}

	/**
	 * Refresh OAuth tokens before cloud URL / provider schedule fetch.
	 *
	 * @param string $file_url External file URL.
	 * @return array{success: bool, message?: string}
	 */
	private function ensure_oauth_before_cloud_fetch( $file_url ) {
		$file_url = (string) $file_url;
		if ( $file_url === '' ) {
			return array( 'success' => true );
		}
		if (
			strpos( $file_url, 'docs.google.com/spreadsheets' ) !== false
			|| preg_match( '#^(gdrive|onedrive)://#i', $file_url )
		) {
			return OAuthScheduleRefresh::ensure_all_for_schedule();
		}
		return array( 'success' => true );
	}

	public static function parseDataToExport() {
		global $wpdb;
		require_once ('class-uci-exporter.php');
		die();
	}

	public function saveEventInformationToSchedule() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		global $wpdb;
		$schedule_table = $wpdb->prefix.'sm_uci_addon_pro_scheduled_import';
		$eventKey = sanitize_key($_POST['eventkey']);
		$import_mode = 'Schedule';
		$import_module = sanitize_text_field($_POST['module']);
		$file_type = sanitize_text_field($_POST['FileType']);
		$import_method = isset($_POST['method']) ? $_POST['method'] :'';
		$time_zone = sanitize_text_field($_POST['UTC']);
		$check_filter = sanitize_text_field($_POST['mappingFilterCheck']);
		$check_manage_filter = $check_filter == 'false' ? false : true;
		if(empty($time_zone)){
			$time_zone = 'Asia/Kolkata';
		}
		$templateId = $this->getTemplateInformation($eventKey);
		if(isset($_POST['configData']['limit'])){
			$import_limit = sanitize_text_field($_POST['configData']['limit']);
		}else{
			$import_limit = 1;
		}

		if(isset($_POST['configData']['offset'])){
			$scheduleRows = sanitize_text_field($_POST['configData']['offset']);
		}else{
			$scheduleRows = '';
		}

		if(isset($_POST['UpdateUsing'])){
        	update_option('csv_importer_update_using', $_POST['UpdateUsing']);
		}
			
		$duplicateHeaders = $_POST['duplicate_header'];
		switch (sanitize_text_field(($_POST['frequency']))) {
			case 'OneTime':
				$frequency = 0;
				break;
			case 'Daily':
				$frequency = 1;
				break;
			case 'Weekly':
				$frequency = 2;
				break;
			case 'Monthly':
				$frequency = 3;
				break;
			case 'Hourly':
				$frequency = 4;
				break;
			case 'Every 30 mins':
				$frequency = 5;
				break;
			case 'Every 15 mins':
				$frequency = 6;
				break;
			case 'Every 10 mins':
				$frequency = 7;
				break;
			case 'Every 5 mins':
				$frequency = 8;
				break;
			case 'Every 2 hours':
				$frequency = 9;
			    break;
			case 'Every 4 hours':
				$frequency = 10;
			    break;
		}
		$nextRun = date("Y-m-d H:i:s", strtotime(sanitize_text_field($_POST['date']) . ' ' . (sanitize_text_field($_POST['Time']))));
		$currentDate = current_time('mysql', 0);
		$currentUser = wp_get_current_user();
		$eventSchedulerId = $currentUser->ID; // Get current user id
		$timestamp = strtotime($_POST['date']);
		$dbdate = date("Y-m-d", $timestamp);
		$wpdb->insert($schedule_table,
				array('templateid' => $templateId,
					'createdtime' => $currentDate,
					'scheduledtimetorun' => sanitize_text_field($_POST['Time']),
					'scheduleddate' => $dbdate,
					'module'	=> $import_module,
					'file_type' => $file_type,
					'event_key'	=> $eventKey,
					'importbymethod' => $import_method,
					'import_limit'	=> $import_limit,
					'import_row_ids' => $scheduleRows,
					'frequency' => $frequency,
					'nexrun' => $nextRun,
					'scheduled_by_user' => $eventSchedulerId,
					'import_mode' => $import_mode,
					'duplicate_headers' => $duplicateHeaders,
					'time_zone' => $time_zone,
					'check_manage_filter' => $check_manage_filter
				     ),
				array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%d', '%s','%d', '%s', '%s', '%s', '%s','%s','%d')
				);
		if(!is_wp_error($wpdb->insert_id)) {

			//update schedule hook name 
			$wpdb->update($schedule_table, ['hook_name' => 'smack_cron_schedule_function_'. $wpdb->insert_id], ['id' => $wpdb->insert_id]);

			if ($import_method == 'url') {
				$file_url = isset( $_POST['fileurl'] ) ? esc_url_raw( wp_unslash( $_POST['fileurl'] ) ) : '';
				// Keep long AWIN column lists intact (must not use varchar(255) truncation).
				$wpdb->insert(
					$wpdb->prefix . 'sm_uci_addon_pro_external_file_schedules',
					array(
						'schedule_id' => (int) $wpdb->insert_id,
						'file_url'    => $file_url,
						'filename'    => $eventKey,
					),
					array( '%d', '%s', '%s' )
				);
			} else {
				if ($import_method == 'ftp' || $import_method == 'ftps' || $import_method == 'sftp') {
					$ftp_password = ScheduleCredentialCipher::encrypt( sanitize_text_field( wp_unslash( $_POST['password'] ?? '' ) ) );
					$wpdb->insert(
						$wpdb->prefix . 'sm_uci_addon_pro_ftp_schedules',
						array(
							'schedule_id'   => (int) $wpdb->insert_id,
							'hostname'      => sanitize_text_field( wp_unslash( $_POST['hostname'] ?? '' ) ),
							'username'      => sanitize_text_field( wp_unslash( $_POST['username'] ?? '' ) ),
							'password'      => $ftp_password,
							'initial_path'  => sanitize_text_field( wp_unslash( $_POST['initialpath'] ?? '' ) ),
							'filename'      => $eventKey,
							'port_no'       => sanitize_text_field( wp_unslash( $_POST['portnumber'] ?? '' ) ),
						),
						array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
					);
				}
			}
			/**************** Store Schedule Order ***************/
			$newSchedule_data = array();
			$getSchedule_data = array();
			$getSchedule_data = get_option('WP_CSV_IMPORT_SCHEDULE_ORDER');
			$newSchedule_data[$wpdb->insert_id]['scheduled_order']['scheduled_id'] = $wpdb->insert_id;
			$newSchedule_data[$wpdb->insert_id]['scheduled_order']['module'] = $import_module;
			if (!is_array($getSchedule_data)) {
				$getSchedule_data = $newSchedule_data;
			} else {
				$scheduleList = array();
				foreach ($getSchedule_data as $schedule_key => $schedule_val) {
					$scheduleList[$schedule_key] = $schedule_val;
					foreach ($newSchedule_data as $new_schedule_key => $new_schedule_val) {
						$scheduleList[$new_schedule_key] = $new_schedule_val;
					}
				}
				$getSchedule_data = $scheduleList;
			}

			update_option('WP_CSV_IMPORT_SCHEDULE_ORDER', $getSchedule_data);
			/*************** End Schedule Order *************/
			$data['notification'] = 'Scheduled CSV successfully'
				;
		} else {
			$data['notification'] = 'Error while inserting into table';
		}
		$data = str_replace('\\', '',$data);
		echo wp_json_encode($data);
		wp_die();
	}

	public  function timezone(){
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		static $regions = array(
				\DateTimeZone::AFRICA,
				\DateTimeZone::AMERICA,
				\DateTimeZone::ANTARCTICA,
				\DateTimeZone::ASIA,
				\DateTimeZone::ATLANTIC,
				\DateTimeZone::AUSTRALIA,
				\DateTimeZone::EUROPE,
				\DateTimeZone::INDIAN,
				\DateTimeZone::PACIFIC,
				);
		$timezones = array();
		foreach( $regions as $region )
		{
			$timezones = array_merge( $timezones, \DateTimeZone::listIdentifiers( $region ) );
		}

		$timezone_offsets = array();
		foreach( $timezones as $timezone )
		{
			$tz = new \DateTimeZone($timezone);
			$timezone_offsets[$timezone] = $tz->getOffset(new \DateTime);
		}
		asort($timezone_offsets);
		$timezone_list = array();
		$i = 0;
		foreach( $timezone_offsets as $timezone => $offset )
		{
			$offset_prefix = $offset < 0 ? '-' : '+';
			$offset_formatted = gmdate( 'H:i', abs($offset) );
			$pretty_offset = "UTC{$offset_prefix}{$offset_formatted}";
			$timezone_list[$timezone] = "({$pretty_offset}) $timezone";
			$result[$i]['timezone'] = $timezone ;
			$result[$i]['offset']= $timezone_list[$timezone];
			$i++;
		}
		echo  wp_json_encode($result);
		wp_die();
	}

	public  function smack_uci_cron_scheduler() {
		global $wpdb;
		$cron_started_at = microtime( true );
		$this->debug_log(__FUNCTION__, 'cron_start', array(
			'hook'       => 'smack_uci_cron_scheduler',
			'trigger_at' => gmdate( 'Y-m-d H:i:s' ),
			'memory_mb'  => round( memory_get_usage( true ) / 1048576, 2 ),
		) );
		$this->recover_stale_schedule_locks();
		$endDate = '';
		$schedule_table = $wpdb->prefix.'sm_uci_addon_pro_scheduled_import';
		$exturl_schedule_table = $wpdb->prefix.'sm_uci_addon_pro_external_file_schedules';
		$schedule_tableName = $wpdb->prefix.'sm_uci_addon_pro_scheduled_import';
		$ftp_schedule_table = $wpdb->prefix.'sm_uci_addon_pro_ftp_schedules';
		$file_table_name = $wpdb->prefix.'smackcsv_file_events';
		$nextDate = null;
		$state_service = ScheduleStateService::getInstance();

		// Due detection must use EACH schedule's own timezone. Using the first
		// incomplete row's TZ for all jobs left later schedules stuck in pending.
		$scheduleList = $state_service->get_due_schedules( $schedule_tableName );
		$this->debug_log(__FUNCTION__, 'due_schedules_fetched', array(
			'due_count' => is_array( $scheduleList ) ? count( $scheduleList ) : 0,
		));

		if (!empty($scheduleList)) {
			foreach ($scheduleList as $scheduledEvent) {
				$job_started_at    = microtime( true );
				$import_dispatched = false;
				// Reset per job — a prior URL/FTP failure must not block later schedules.
				$proceed_scheduling = 1;
				try {
				$resolved_tz = $state_service->resolve_timezone( isset( $scheduledEvent->time_zone ) ? $scheduledEvent->time_zone : '' );
				$state_service->persist_timezone_if_missing( $schedule_tableName, (int) $scheduledEvent->id, $resolved_tz );
				$current_timestamp = $state_service->current_timestamp_for_timezone( $resolved_tz );

				$this->debug_log(__FUNCTION__, 'job_start', array(
					'schedule_id' => $scheduledEvent->id,
					'import_id' => $scheduledEvent->templateid,
					'event_key' => $scheduledEvent->event_key,
					'import_method' => $scheduledEvent->importbymethod,
					'file_source_type' => ($scheduledEvent->importbymethod === 'url' ? 'url' : $scheduledEvent->importbymethod),
					'status_before_execution' => $scheduledEvent->cron_status,
					'time_zone' => $resolved_tz,
					'current_timestamp' => $current_timestamp,
				));
				if ( ! $state_service->acquire_lock( (int) $scheduledEvent->id ) ) {
					$this->debug_log( __FUNCTION__, 'lock_not_acquired', array(
						'schedule_id' => $scheduledEvent->id,
						'reason'      => 'already_running',
					) );
					continue;
				}
				$this->debug_log( __FUNCTION__, 'lock_acquired', array(
					'schedule_id' => $scheduledEvent->id,
				) );
				$templateid=$scheduledEvent->templateid;
				$runSchedule = false;
				$data = array();
				$frequency = $scheduledEvent->frequency;
				$startDate = strtotime($scheduledEvent->lastrun);
				$startDate = $scheduledEvent->scheduleddate . ' ' . $scheduledEvent->scheduledtimetorun;
				$startDate = strtotime($startDate);
				if($frequency == 0) {
					$nextDate =  date("Y-m-d H:i:s", $startDate);
					if($nextDate <= $current_timestamp){
						$runSchedule = true;
					}
					$nextRun = $nextDate;
				}
				elseif ($frequency == 1) {          // Daily
					$endDate = strtotime("+1 day", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+1 day", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+1 day", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 2) {   // Weekly
					$endDate = strtotime("+1 week", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+1 week", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+1 week", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 3) {   // Monthly
					$endDate = strtotime("+1 month", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+1 month", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+1 month", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				}
				elseif ($frequency == 4) {   // Hourly
					$endDate = strtotime("+1 hour", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+1 hour", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+1 hour", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				}
				elseif ($frequency == 5) {
					$endDate = strtotime("+30 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+30 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+30 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 6) {
					$endDate = strtotime("+15 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+15 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+15 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 7) {
					$endDate = strtotime("+10 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+10 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+10 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 8) {
					$endDate = strtotime("+5 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+5 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+5 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 9) {   //Every 2 hours
					$endDate = strtotime("+120 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+120 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+120 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} elseif ($frequency == 10) {   //Every 4 hours
					$endDate = strtotime("+240 minutes", $startDate);
					$nextDate = date("Y-m-d H:i:s", $endDate);
					if($nextDate <= $current_timestamp) {
						$runSchedule = true;
					}
					$nextDate = strtotime($current_timestamp);
					$nextRun = strtotime("+240 minutes", $nextDate);
					$nextRun = date("Y-m-d H:i:s", $nextRun);
					if($nextRun <= $current_timestamp) {
						$nextRun = strtotime("+240 minutes", $current_timestamp);
						$nextRun = date("Y-m-d H:i:s", $nextRun);
					}
				} 
				$hashkey = $wpdb->get_results("select eventkey from {$wpdb->prefix}ultimate_csv_importer_mappingtemplate where id = $templateid");
				$array=json_decode(json_encode($hashkey),true);
				$hashkeys=$array[0]['eventkey'];
				$data['manage_filter_check'] = $scheduledEvent->check_manage_filter; 
				$data['start_limit'] = $scheduledEvent->start_limit;
				$data['end_limit'] = $scheduledEvent->end_limit;
				$data['eventkey'] = $scheduledEvent->event_key;
				$data1['eventkey'] = $hashkeys;
				$data['import_limit'] = $scheduledEvent->import_limit;
				$data['import_row_ids'] = !empty($scheduledEvent->import_row_ids) ? unserialize($scheduledEvent->import_row_ids) : '';
				$data['nexrun'] = $nextRun;
				$data['lastrun'] = $current_timestamp;
				$data['frequency'] = $scheduledEvent->frequency;
				$data['module'] = $scheduledEvent->module;
				$data['duplicate_headers'] = $scheduledEvent->duplicate_headers;
				$data['extension'] = $scheduledEvent->file_type;
				$data['import_mode'] = $scheduledEvent->import_mode;
				$data['csv_name'] = $scheduledEvent->event_key;
				$data['scheduled_by_user'] = $scheduledEvent->scheduled_by_user;
				$data['template_id'] = $scheduledEvent->templateid;
				$data['id'] = $scheduledEvent->id;
				$data['scheduleddate'] = $scheduledEvent->scheduleddate;
				$data['scheduledtimetorun'] = $scheduledEvent->scheduledtimetorun;
				$runSchedule = true ;
				if ($runSchedule === true && $scheduledEvent->importbymethod == 'url') {
					$external_scheduleList = $wpdb->get_results("select filename, file_url from {$wpdb->prefix}sm_uci_addon_pro_external_file_schedules where schedule_id = $scheduledEvent->id");

					if ($external_scheduleList[0]->filename != '') {
						$external_url = $external_scheduleList[0]->file_url;
						$this->debug_log(__FUNCTION__, 'url_source_identified', array(
							'schedule_id' => $scheduledEvent->id,
							'file_url' => $external_url,
							'file_source_type' => (strpos($external_url, 'docs.google.com/spreadsheets') !== false ? 'Google Sheets' : 'URL'),
						));
						$oauth_check = $this->ensure_oauth_before_cloud_fetch( $external_url );
						if ( empty( $oauth_check['success'] ) ) {
							$proceed_scheduling = 0;
							$failure_reason = isset( $oauth_check['message'] ) ? $oauth_check['message'] : 'OAuth token refresh failed';
							$scheduled = $this->maybe_reschedule_retry( $scheduledEvent, $failure_reason, $schedule_tableName );
							if ( ! $scheduled ) {
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									(int) $scheduledEvent->id
								) );
							}
							$this->debug_log( __FUNCTION__, 'job_failed_oauth_refresh', array(
								'schedule_id'    => $scheduledEvent->id,
								'failure_reason' => $failure_reason,
								'retry_scheduled' => $scheduled,
							) );
							continue;
						}
						$returnData = self::$url_upload->externalfile_handling($external_url);
						$this->debug_log(__FUNCTION__, 'url_fetch_result', array(
							'schedule_id' => $scheduledEvent->id,
							'result' => $returnData,
						));
						if ($returnData['success'] === false) {
							$proceed_scheduling = 0;
							$failure_reason = isset($returnData['message']) ? $returnData['message'] : 'External URL handling failed';
							$scheduled = $this->maybe_reschedule_retry($scheduledEvent, $failure_reason, $schedule_tableName);
							if (!$scheduled) {
								$wpdb->get_results("UPDATE $schedule_tableName SET  cron_status = 'Failed', isrun = 0 WHERE event_key = '{$data['eventkey']}'");
							}
							$this->debug_log(__FUNCTION__, 'job_failed_pre_import', array(
								'schedule_id' => $scheduledEvent->id,
								'failure_reason' => $failure_reason,
								'retry_scheduled' => $scheduled,
							));
						} else {
							$this->reset_retry_counter($scheduledEvent->id, 'url_fetch_success_reset');
							$data['csv_name'] = $returnData['hashkey'];
							$data['filename'] = $returnData['filename'];
							$data['uploaded_name'] = $returnData['filename'];
							$data['version'] = isset($returnData['version']) ? $returnData['version'] : '';
							$data['extension'] = isset($returnData['extension']) ? $returnData['extension'] : '';
							$wpdb->query("update {$exturl_schedule_table} set filename = '{$returnData['hashkey']}' where schedule_id = '{$scheduledEvent->id}'");
							if ( ! $this->copy_mapping_template_to_event_key( $data1['eventkey'], $data['csv_name'] ) ) {
								$proceed_scheduling = 0;
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									$scheduledEvent->id
								) );
								$this->debug_log( __FUNCTION__, 'job_failed_pre_import', array(
									'schedule_id'    => $scheduledEvent->id,
									'failure_reason' => 'Mapping template missing for eventKey ' . $data1['eventkey'],
								) );
							} else {
								$wpdb->query("UPDATE $file_table_name SET hash_key = '".$returnData['hashkey']."' WHERE hash_key = '".$data['eventkey']."'");
								$data['eventkey'] = $returnData['hashkey'];
								$wpdb->query("UPDATE $schedule_tableName SET event_key = '".$returnData['hashkey']."' WHERE ID = ".$scheduledEvent->id);
							}
						}
					}
				}
				elseif ($runSchedule === true && ($scheduledEvent->importbymethod == 'ftp' || $scheduledEvent->importbymethod == 'ftps') ) {
					$ftp_scheduleList = $wpdb->get_results("select * from {$wpdb->prefix}sm_uci_addon_pro_ftp_schedules where schedule_id = $scheduledEvent->id");
					if ($ftp_scheduleList[0]->filename != '') {
						$data['HostName'] = $ftp_scheduleList[0]->hostname;
						$data['HostPort'] = $ftp_scheduleList[0]->port_no;
						$data['HostPath'] = $ftp_scheduleList[0]->initial_path;
						$data['HostUserName'] = $ftp_scheduleList[0]->username;
						$data['HostPassword'] = ScheduleCredentialCipher::decrypt( $ftp_scheduleList[0]->password );
						$returnData = self::$ftp_upload->ftp_upload($data);
						if ($returnData['success'] === false) {
							$proceed_scheduling = 0;
							$failure_reason = isset( $returnData['message'] ) ? $returnData['message'] : 'FTP upload failed';
							$scheduled = $this->maybe_reschedule_retry( $scheduledEvent, $failure_reason, $schedule_tableName );
							if ( ! $scheduled ) {
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									(int) $scheduledEvent->id
								) );
							}
							$this->debug_log( __FUNCTION__, 'job_failed_ftp_pre_import', array(
								'schedule_id'     => $scheduledEvent->id,
								'failure_reason'  => $failure_reason,
								'retry_scheduled' => $scheduled,
							) );
						} else {
							$data['csv_name'] = $returnData['hashkey'];
							$data['filename'] = $returnData['filename'];
							$data['uploaded_name'] = $returnData['filename'];
							$wpdb->query("update {$ftp_schedule_table} set filename = '{$returnData['hashkey']}' where schedule_id = '{$scheduledEvent->id}'");
							if ( ! $this->copy_mapping_template_to_event_key( $data1['eventkey'], $data['csv_name'] ) ) {
								$proceed_scheduling = 0;
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									$scheduledEvent->id
								) );
							} else {
								$wpdb->query("UPDATE $file_table_name SET hash_key = '".$returnData['hashkey']."' WHERE hash_key = '".$data['eventkey']."'");
								$data['eventkey'] = $returnData['hashkey'];
								$wpdb->query("UPDATE $schedule_tableName SET event_key = '".$returnData['hashkey']."' WHERE ID = ".$scheduledEvent->id);
							}
						}
					}
				}

				elseif ($runSchedule === true && $scheduledEvent->importbymethod == 'sftp') {
					$ftp_scheduleList = $wpdb->get_results("select * from {$wpdb->prefix}sm_uci_addon_pro_ftp_schedules where schedule_id = $scheduledEvent->id");
					if ($ftp_scheduleList[0]->filename != '') {
						$data['HostName'] = $ftp_scheduleList[0]->hostname;
						$data['HostPort'] = $ftp_scheduleList[0]->port_no;
						$data['HostPath'] = $ftp_scheduleList[0]->initial_path;
						$data['HostUserName'] = $ftp_scheduleList[0]->username;
						$data['HostPassword'] = ScheduleCredentialCipher::decrypt( $ftp_scheduleList[0]->password );
						$returnData = self::$sftp_upload->sftp_upload($data);
						if ($returnData['success'] === false) {
							$proceed_scheduling = 0;
							$failure_reason = isset( $returnData['message'] ) ? $returnData['message'] : 'SFTP upload failed';
							$scheduled = $this->maybe_reschedule_retry( $scheduledEvent, $failure_reason, $schedule_tableName );
							if ( ! $scheduled ) {
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									(int) $scheduledEvent->id
								) );
							}
							$this->debug_log( __FUNCTION__, 'job_failed_sftp_pre_import', array(
								'schedule_id'     => $scheduledEvent->id,
								'failure_reason'  => $failure_reason,
								'retry_scheduled' => $scheduled,
							) );
						} else {
							$data['csv_name'] = $returnData['hashkey'];
							$data['filename'] = $returnData['filename'];
							$data['uploaded_name'] = $returnData['filename'];
							$wpdb->query("update {$ftp_schedule_table} set filename = '{$returnData['hashkey']}' where schedule_id = '{$scheduledEvent->id}'");
							$source_event_key = ! empty( $data1['eventkey'] ) ? $data1['eventkey'] : $data['eventkey'];
							if ( ! $this->copy_mapping_template_to_event_key( $source_event_key, $data['csv_name'] ) ) {
								$proceed_scheduling = 0;
								$wpdb->query( $wpdb->prepare(
									"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
									$scheduledEvent->id
								) );
							} else {
								$wpdb->query("UPDATE $file_table_name SET hash_key = '".$returnData['hashkey']."' WHERE hash_key = '".$data['eventkey']."'");
								$data['eventkey'] = $returnData['hashkey'];
								$wpdb->query("UPDATE $schedule_tableName SET event_key = '".$returnData['hashkey']."' WHERE ID = ".$scheduledEvent->id);
							}
						}
					}
				}

				if ($proceed_scheduling == 1 && $runSchedule === true) {
					$this->debug_log(__FUNCTION__, 'dispatch_schedule_import', array(
						'schedule_id' => $scheduledEvent->id,
						'event_key' => $data['eventkey'],
					));
					$import_dispatched = true;
					self::doSchedule($data,$current_timestamp);
					$post_status = $wpdb->get_var("SELECT cron_status FROM $schedule_tableName WHERE id = " . intval($scheduledEvent->id));
					if (strtolower((string) $post_status) !== 'failed') {
						$this->reset_retry_counter($scheduledEvent->id, 'import_success_reset');
						$this->debug_log(__FUNCTION__, 'job_success', array(
							'schedule_id' => $scheduledEvent->id,
							'cron_status' => $post_status,
							'duration_sec' => round( microtime( true ) - $job_started_at, 3 ),
							'memory_mb' => round( memory_get_usage( true ) / 1048576, 2 ),
						));
					}
				} else {
					$this->debug_log(__FUNCTION__, 'job_skipped_or_failed', array(
						'schedule_id' => $scheduledEvent->id,
						'proceed_scheduling' => $proceed_scheduling,
						'runSchedule' => $runSchedule,
					));
				}
				} catch ( \Throwable $e ) {
					$this->debug_log( __FUNCTION__, 'job_exception', array(
						'schedule_id' => $scheduledEvent->id,
						'message'     => $e->getMessage(),
						'file'        => $e->getFile(),
						'line'        => $e->getLine(),
					) );
					$wpdb->query( $wpdb->prepare(
						"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
						(int) $scheduledEvent->id
					) );
				} finally {
					// doSchedule() releases isrun; pre-import failures must release here.
					if ( ! $import_dispatched ) {
						$still_locked = (int) $wpdb->get_var( $wpdb->prepare(
							"SELECT isrun FROM $schedule_tableName WHERE id = %d",
							(int) $scheduledEvent->id
						) );
						if ( 1 === $still_locked ) {
							$this->release_schedule_lock( (int) $scheduledEvent->id, 'import_not_dispatched' );
						}
					}
				}
			}
		}
		$this->debug_log( __FUNCTION__, 'cron_end', array(
			'duration_sec' => round( microtime( true ) - $cron_started_at, 3 ),
			'memory_mb'    => round( memory_get_usage( true ) / 1048576, 2 ),
			'peak_memory_mb' => round( memory_get_peak_usage( true ) / 1048576, 2 ),
		) );
	}

	/**
	 * Safely copy a mapping template from one eventKey to another (URL/FTP re-fetch).
	 * Uses $wpdb->insert/update so serialized mappings with quotes are not corrupted.
	 *
	 * @param string $source_event_key Original template eventKey.
	 * @param string $target_event_key New file hash / eventKey.
	 * @return bool True when mapping was copied or already present with content.
	 */
	private function copy_mapping_template_to_event_key( $source_event_key, $target_event_key ) {
		global $wpdb;

		$source_event_key = (string) $source_event_key;
		$target_event_key = (string) $target_event_key;
		if ( $source_event_key === '' || $target_event_key === '' ) {
			return false;
		}

		$table = $wpdb->prefix . 'ultimate_csv_importer_mappingtemplate';
		$template_info = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT mapping, module FROM {$table} WHERE eventKey = %s",
				$source_event_key
			),
			ARRAY_A
		);

		if ( empty( $template_info['mapping'] ) ) {
			return false;
		}

		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE eventKey = %s",
				$target_event_key
			)
		);

		if ( $existing_id ) {
			$updated = $wpdb->update(
				$table,
				array(
					'mapping' => $template_info['mapping'],
					'module'  => $template_info['module'],
				),
				array( 'eventKey' => $target_event_key ),
				array( '%s', '%s' ),
				array( '%s' )
			);
			return false !== $updated;
		}

		$inserted = $wpdb->insert(
			$table,
			array(
				'mapping'  => $template_info['mapping'],
				'module'   => $template_info['module'],
				'eventKey' => $target_event_key,
			),
			array( '%s', '%s', '%s' )
		);

		return false !== $inserted;
	}

	public  function get_wordpress_currentdate($type, $gmt = 0) {
		$date = array();
		$time = current_time($type, $gmt);
		$date['timstamp'] = $time;
		$date['date'] = date('Y-m-d', strtotime($time));
		$date['time'] = date('H:i', strtotime($time));
		$date['day'] = date('l', strtotime($time));
		$date['datetime'] = date('Y-m-d H:i:s', strtotime($time));
		return $date;
	}

	public static function getTemplateInformation($eventKey) {
		global $wpdb;
		$templateid = $wpdb->get_col($wpdb->prepare("select id from {$wpdb->prefix}ultimate_csv_importer_mappingtemplate where eventKey = %s",$eventKey));
		$template_id = $templateid[0];
		return $template_id;
	}

	public  function doSchedule($data,$current_timestamp) {		
		global $wpdb;
		$this->debug_log(__FUNCTION__, 'start', array(
			'schedule_id' => isset($data['id']) ? $data['id'] : '',
			'event_key' => isset($data['eventkey']) ? $data['eventkey'] : '',
			'current_timestamp' => $current_timestamp,
		));
		$offset = get_option('gmt_offset');
		$seconds = 0;
		if (is_numeric($offset)) {
			$seconds = (int) round(((float) $offset) * HOUR_IN_SECONDS);
		}
		$tz = timezone_name_from_abbr('', $seconds, 1);
		if($tz === false) {
			$tz = timezone_name_from_abbr('', $seconds, 0);
		}
		if($tz === false || empty($tz)) {
			$tz = wp_timezone_string();
		}
		if(empty($tz)) {
			$tz = 'UTC';
		}
		try {
			$datetime = new \DateTime($data['scheduleddate'] .' '.$data['scheduledtimetorun']);
			$zone_time = new \DateTimeZone($tz);
			$datetime->setTimezone($zone_time);
			$admin_scheduled_date = $datetime->format('Y-m-d H:i:s');
		} catch ( \Exception $e ) {
			$admin_scheduled_date = $data['scheduleddate'] . ' ' . $data['scheduledtimetorun'];
		}
		$schedule_tableName = $wpdb->prefix.'sm_uci_addon_pro_scheduled_import';
		$offset = '';
		$getScheduling_data = $wpdb->get_results("select cron_status, importbymethod, duplicate_headers from $schedule_tableName where id = {$data['id']}");
		$this->debug_log(__FUNCTION__, 'status_before_execution', array(
			'schedule_id' => $data['id'],
			'cron_status' => isset($getScheduling_data[0]->cron_status) ? $getScheduling_data[0]->cron_status : '',
			'import_method' => isset($getScheduling_data[0]->importbymethod) ? $getScheduling_data[0]->importbymethod : '',
		));
	
		ScheduleStateService::getInstance()->set_status( (int) $data['id'], ScheduleStateService::STATUS_PROCESSING );
		if ( ! empty( $getScheduling_data[0]->duplicate_headers ) ) {
			$duplicate_headers = @unserialize( $getScheduling_data[0]->duplicate_headers );
			if ( is_string( $duplicate_headers ) ) {
				$duplicate_headers = trim( $duplicate_headers );
			}
		}
		$original_file_name = isset($data['filename']) ? $data['filename'] :'';
		$test = new ScheduleImport();
		$test->schedule_import($data);
		$latest_status = $wpdb->get_var("SELECT cron_status FROM $schedule_tableName WHERE id = " . intval($data['id']));
		$this->debug_log(__FUNCTION__, 'post_import_status', array(
			'schedule_id' => $data['id'],
			'cron_status' => $latest_status,
		));

		/**************** End Scheduling process ***************/
		$smack_instance = UltimatePro::getInstance();
		$upload_dir = $smack_instance->create_upload_dir();
		$hash_key = $data['eventkey'];
		$eventLogFile = $upload_dir.$hash_key.'/'.$hash_key.'.html';
		$ucisettings = get_option('sm_uci_pro_settings');
		if(isset($ucisettings['send_log_email']) && $ucisettings['send_log_email'] == 'true') {
			require_once(ABSPATH . "wp-includes/pluggable.php");
			$user_info = get_userdata($data['scheduled_by_user']);
			$first_name = $user_info->first_name;
			$last_name = $user_info->last_name;
			$recievermail = $first_name . ' ' . $last_name . "<$user_info->user_email>";
			
			$subject = "Schedule Log for schedule_id: {$data['id']} & filename: $original_file_name";
			$message = "$subject" . "\n";
			$message .= "Scheduled file based on your wp-admin timezone with time:".$admin_scheduled_date . "\n";
			$headers = array();
			$headers[] = "From: $user_info->display_name <$user_info->user_email>" . "\r\n";
			$attachments = array ( $eventLogFile );
			wp_mail( $recievermail, $subject, $message, $headers, $attachments );
		}

		$data_id = $data['id'];
	
		//if($data['frequency'] != 0) {
			//$wpdb->query("update $schedule_tableName set isrun = 0 where id = '{$data['id']}'");
			$wpdb->query("UPDATE $schedule_tableName set isrun = 0 where id = $data_id ");
		//}

		// check if schedule is completed
		$check_schedule_complete = $wpdb->get_results("SELECT id FROM {$wpdb->prefix}sm_uci_addon_pro_scheduled_import WHERE cron_status = 'completed' AND isrun = 1 AND id = $data_id");
		if(!empty($check_schedule_complete)){
			wp_clear_scheduled_hook('smack_cron_schedule_function_'. $data_id);
		}
		$final_status = $wpdb->get_var("SELECT cron_status FROM $schedule_tableName WHERE id = " . intval($data_id));
		$this->debug_log(__FUNCTION__, 'final_status', array(
			'schedule_id' => $data_id,
			'status' => $final_status,
			'result' => (strtolower((string) $final_status) === 'failed' ? 'Failed' : 'Success'),
		));
	}
}