<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

/**
 * Class ScheduleImport
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */

class ScheduleImport {

	protected static $instance=null;
	protected static $smackcsv_instance = null;
	protected static $save_mapping_instance = null;
	protected static $core = null;
	private static $validatefile;
	private const DEBUG_LOG_FILE = 'wp-importer-debug.log';


	public static  function getInstance() {
		if (ScheduleImport::$instance == null) {
			ScheduleImport::$instance = new ScheduleImport;
			ScheduleImport::$validatefile = new ValidateFile;
			ScheduleImport::$smackcsv_instance = UltimatePro::getInstance();
			ScheduleImport::$save_mapping_instance = SaveMapping::getInstance();
			return self::$instance;
		}
		return self::$instance;
	}

	/**
	 * Clear per-schedule batch pagination options between recurring import cycles.
	 * Stale smack_csv_record_limit_* values cause tiny batch sizes on the next run.
	 *
	 * @param int $schedule_id Schedule row ID.
	 */
	private function reset_schedule_batch_options( $schedule_id ) {
		ScheduleStateService::getInstance()->reset_batch_options( (int) $schedule_id );
	}

	/**
	 * After each cron batch, ensure cron_status reflects progress (not stuck on initialized).
	 *
	 * @param int    $schedule_id   Schedule ID.
	 * @param string $hash_key        Event hash.
	 * @param int    $data_id         Alias of schedule id.
	 * @param int    $page_number     Current batch page.
	 * @param int    $total_rows      Total CSV rows.
	 * @param string $terminal_status Optional terminal status already set.
	 */
	private function finalize_schedule_batch_status( $schedule_id, $hash_key, $page_number, $total_rows, $terminal_status = '' ) {
		global $wpdb;
		$schedule_id   = (int) $schedule_id;
		$state_service = ScheduleStateService::getInstance();
		$table         = $wpdb->prefix . 'sm_uci_addon_pro_scheduled_import';

		if ( '' !== $terminal_status ) {
			return;
		}

		$current = $wpdb->get_var( $wpdb->prepare( "SELECT cron_status FROM {$table} WHERE id = %d", $schedule_id ) );
		$done_statuses = array(
			strtolower( ScheduleStateService::STATUS_COMPLETED ),
			strtolower( ScheduleStateService::STATUS_WAITING_NEXT ),
			strtolower( ScheduleStateService::STATUS_FAILED ),
		);
		if ( in_array( strtolower( (string) $current ), $done_statuses, true ) ) {
			return;
		}

		$log_status = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT status FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);

		if ( 'Completed' === $log_status ) {
			return;
		}

		$state_service->set_status( $schedule_id, ScheduleStateService::STATUS_PROCESSING );
		$state_service->heartbeat( $schedule_id );
		$this->debug_log( __FUNCTION__, 'batch_paused_awaiting_next_cron', array(
			'schedule_id' => $schedule_id,
			'page_number' => (int) $page_number,
			'total_rows'  => (int) $total_rows,
			'log_status'  => $log_status,
		) );
	}

	/**
	 * Strip UTF-8 BOM from a string (common in Excel-exported CSV headers).
	 *
	 * @param mixed $value Raw value.
	 * @return mixed
	 */
	private function strip_utf8_bom( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}
		return preg_replace( '/^\xEF\xBB\xBF/', '', $value );
	}

	/**
	 * Normalize CSV header row so BOM does not break field lookup.
	 *
	 * @param array $headers Header cells.
	 * @return array
	 */
	private function sanitize_csv_headers( $headers ) {
		if ( ! is_array( $headers ) ) {
			return array();
		}
		$clean = array();
		foreach ( $headers as $header ) {
			$clean[] = trim( (string) $this->strip_utf8_bom( $header ) );
		}
		return $clean;
	}

	/**
	 * Strip BOM from mapped CSV header names inside a mapping template array.
	 *
	 * @param mixed $map Unserialized mapping.
	 * @return mixed
	 */
	private function sanitize_mapping_headers( $map ) {
		if ( ! is_array( $map ) ) {
			return $map;
		}
		foreach ( $map as $group => $fields ) {
			if ( ! is_array( $fields ) ) {
				continue;
			}
			foreach ( $fields as $field => $header ) {
				if ( is_string( $header ) ) {
					$map[ $group ][ $field ] = $this->strip_utf8_bom( $header );
				}
			}
		}
		return $map;
	}

	/**
	 * Snapshot import_detail_log counters for debug.
	 *
	 * @param string $hash_key Event hash.
	 * @return array
	 */
	private function get_import_result_snapshot( $hash_key ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, total_records, created, updated, skipped, failed FROM {$wpdb->prefix}import_detail_log WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			),
			ARRAY_A
		);
		return is_array( $row ) ? $row : array();
	}

	private function debug_log($function_name, $stage, $data = array())
	{
		// Intentionally disabled — schedule debug file logging removed for production.
	}

	public function schedule_import($data_array){	
		global $wpdb,$core_instance;
		$this->debug_log(__FUNCTION__, 'start', array(
			'schedule_id' => isset($data_array['id']) ? $data_array['id'] : '',
			'event_key' => isset($data_array['eventkey']) ? $data_array['eventkey'] : '',
			'file_source_type' => isset($data_array['import_mode']) ? $data_array['import_mode'] : '',
			'status_before_execution' => 'initialized_or_pending',
		));
		$hash_key  = $data_array['eventkey'];
		$check = $data_array['duplicate_headers'];
		$last_run = $data_array['lastrun'];
		$next_run = $data_array['nexrun'];
		$data_id = $data_array['id'];
		$check_filter = $data_array['manage_filter_check'];
		$frequency = $data_array['frequency'];
		$helpers_instance = ImportHelpers::getInstance();
		// Ensure customFunction.php is loaded for Header Manipulation on cron (same as manual).
		if ( class_exists( __NAMESPACE__ . '\\CustomFunctionService' ) ) {
			CustomFunctionService::load_definitions();
		}
		$core_instance = CoreFieldsImport::getInstance();
		$file_manager_instance = FileManager::getInstance();
		$log_manager_instance = LogManager::getInstance();
		$response = [];
		$file_table_name = $wpdb->prefix ."smackcsv_file_events";
		$template_table_name = $wpdb->prefix ."ultimate_csv_importer_mappingtemplate";
		$log_table_name = $wpdb->prefix ."import_detail_log";
		$schedule_tableName = $wpdb->prefix.'sm_uci_addon_pro_scheduled_import';
		ScheduleImport::$smackcsv_instance = UltimatePro::getInstance();
		$upload_dir = ScheduleImport::$smackcsv_instance->create_upload_dir();
		$background_values = $wpdb->get_results("SELECT mapping ,mapping_filter, module  FROM $template_table_name WHERE `eventKey` = '$hash_key' ");
		$this->debug_log(__FUNCTION__, 'mapping_lookup', array(
			'event_key' => $hash_key,
			'mapping_found' => !empty($background_values),
		));
		if (empty($background_values)) {
			$wpdb->query("UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = " . intval($data_array['id']));
			return false;
		}
		$gmode = 'Schedule';
		$manage_filter ='';
		$schedule_array = array($hash_key,'hash_key');
		// if ( ! wp_next_scheduled( 'smackcsv_image_schedule_hook', $schedule_array) ) {
		// 	wp_schedule_event( time(), 'smack_image_every_second', 'smackcsv_image_schedule_hook', $schedule_array );	
		// }
		foreach($background_values as $values){
			$mapped_fields_values = $values->mapping;	
			$mapping_filter = $values->mapping_filter;
			$selected_type = $values->module;
		}
		$manage_filter = unserialize($mapping_filter);
		$get_id  = $wpdb->get_results( "SELECT id , mode ,file_name , total_rows FROM $file_table_name WHERE `hash_key` = '$hash_key'");
		$this->debug_log(__FUNCTION__, 'file_event_lookup', array(
			'event_key' => $hash_key,
			'file_event_found' => !empty($get_id),
		));
		if (empty($get_id) || !isset($get_id[0])) {
			$wpdb->query("UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = " . intval($data_array['id']));
			return false;
		}
		$get_mode = $get_id[0]->mode;
		//$total_rows = $get_id[0]->total_rows;
		
		//changed
		$get_rows  = $wpdb->get_results( "SELECT total_rows FROM $file_table_name WHERE `hash_key` = '$hash_key' order by id desc");
		if (empty($get_rows) || !isset($get_rows[0])) {
			$wpdb->query("UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = " . intval($data_array['id']));
			return false;
		}
		$total_rows = $get_rows[0]->total_rows;
		$file_name = $get_id[0]->file_name;
		$file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
		if(empty($file_extension)){
			$file_extension = 'xml';
		}
		if($file_extension == 'xlsx' || $file_extension == 'xls' || $file_extension == 'json'){
			$file_extension = 'csv';
		}
		$this->debug_log(__FUNCTION__, 'import_file_ready', array(
			'event_key' => $hash_key,
			'file_name' => $file_name,
			'file_extension' => $file_extension,
			'total_rows' => $total_rows,
		));

		if ( class_exists( ImportResumeService::class ) ) {
			// Recurring/one-time schedule cycles reuse the same hash_key. Without clearing
			// per-row resume logs, later runs skip every row as "already imported (resume)"
			// and leave created=0 while status becomes "waiting for next schedule".
			$check_page_number_early = (int) get_option( 'smack_csv_page_number_' . $data_id, 0 );
			$is_new_schedule_cycle   = ( 0 === $check_page_number_early );
			if ( $is_new_schedule_cycle || ! empty( $data_array['automation_rerun'] ) ) {
				ImportResumeService::getInstance()->clear_row_progress_for_rerun( $hash_key );
				$this->debug_log( __FUNCTION__, 'schedule_cycle_resume_reset', array(
					'schedule_id' => (int) $data_id,
					'event_key'   => $hash_key,
					'reason'      => $is_new_schedule_cycle ? 'new_schedule_cycle' : 'automation_rerun',
				) );
			}

			$resume_svc = ImportResumeService::getInstance();
			$existing   = $resume_svc->get_checkpoint_row( $hash_key );
			if ( ! $existing || ImportResumeService::STATE_COMPLETED === $existing['state'] ) {
				$resume_svc->start_checkpoint(
					$hash_key,
					array(
						'import_mode'  => 'schedule',
						'import_type'  => $file_extension,
						'file_name'    => $file_name,
						'schedule_id'  => (int) $data_id,
						'page_number'  => 1,
						'queue_snapshot' => array(
							'total_records' => (int) $total_rows,
						),
					)
				);
			} else {
				$resume_svc->mark_running( $hash_key );
			}
			$resume_svc->heartbeat( $hash_key );
		}
		ScheduleStateService::getInstance()->heartbeat( (int) $data_id );
		$oauth_refresh = OAuthScheduleRefresh::ensure_all_for_schedule();
		if ( empty( $oauth_refresh['success'] ) ) {
			$failure_reason = isset( $oauth_refresh['message'] ) ? $oauth_refresh['message'] : 'OAuth token refresh failed';
			$state_service  = ScheduleStateService::getInstance();
			if ( ! $state_service->schedule_retry( (int) $data_id, $failure_reason ) ) {
				$wpdb->query( $wpdb->prepare(
					"UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = %d",
					(int) $data_id
				) );
			} else {
				$state_service->release_lock( (int) $data_id, 'oauth_refresh_failed' );
			}
			$this->debug_log( __FUNCTION__, 'oauth_refresh_failed', array(
				'schedule_id'    => (int) $data_id,
				'failure_reason' => $failure_reason,
			) );
			return false;
		}
		$import_file_path = $upload_dir.$hash_key.'/'.$hash_key;
		if (!file_exists($import_file_path)) {
			$wpdb->query("UPDATE $schedule_tableName SET cron_status = 'Failed', isrun = 0 WHERE id = " . intval($data_array['id']));
			return false;
		}
		$file_size = filesize($import_file_path);
		$filesize = $helpers_instance->formatSizeUnits($file_size);

		$update_based_on = get_option('csv_importer_update_using');
        if(empty($update_based_on)){
            $update_based_on = 'normal';
        }

		$wpdb->insert( $log_table_name , array('file_name' => $file_name , 'hash_key' => $hash_key , 'total_records' => $total_rows, 'filesize' => $filesize  ) );
		$current_log_id = (int) $wpdb->insert_id;
		$map = $this->sanitize_mapping_headers( unserialize( $mapped_fields_values ) );
		$core_title_header = isset( $map['CORE']['post_title'] ) ? $map['CORE']['post_title'] : '';
		$this->debug_log( __FUNCTION__, 'mapping_sanitized', array(
			'schedule_id'       => (int) $data_id,
			'event_key'         => $hash_key,
			'module'            => $selected_type,
			'post_title_header' => $core_title_header,
			'post_title_hex'    => is_string( $core_title_header ) ? bin2hex( $core_title_header ) : '',
			'mapping_groups'    => is_array( $map ) ? array_keys( $map ) : array(),
		) );

		if ( class_exists( ImportResumeService::class ) && ! empty( $data_array['automation_rerun'] ) ) {
			// Already cleared above for schedule cycles; keep for mid-batch safety.
			ImportResumeService::getInstance()->clear_row_progress_for_rerun( $hash_key );
		}

		//uncomment after setting limit
		$check_page_number = get_option( 'smack_csv_page_number_' . $data_id, 0 );
		$page_number       = (int) $check_page_number + 1;
		$this->debug_log( __FUNCTION__, 'batch_started', array(
			'schedule_id' => (int) $data_id,
			'page_number' => $page_number,
			'event_key'   => $hash_key,
		) );

		if ($page_number == 1) {
			HooksHandler::getInstance()->importActions()->fire_before_import($hash_key);
		}

		if($file_extension == 'csv' || $file_extension == 'txt' || $file_extension == 'xls'){
			global $wpdb;
			$status = 'running';

			if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
				if (!ini_get("auto_detect_line_endings")) {  // If auto_detect_line_endings is not enabled
					ini_set("auto_detect_line_endings", true);  // Enable it to handle different line endings
				}
			}
			$info = [];
			$file_path = $upload_dir . $hash_key . '/' . $hash_key;
			$delimiter = ScheduleImport::$validatefile->getFileDelimiter($file_path, 5);
			if($delimiter == '\t'){
				$delimiter ='~'; 
				$file_paths = $upload_dir . $hash_key . '/' . $hash_key.'temp';
			}else{
				$file_paths = $upload_dir . $hash_key . '/' . $hash_key;
			}
			if (($h = fopen($file_paths, "r")) !== FALSE) 
			{
				$this->debug_log(__FUNCTION__, 'import_process_file_opened', array(
					'file_path' => $file_paths,
					'total_rows' => $total_rows,
				));
				$inputFile = $upload_dir.$hash_key.'/'.$hash_key;
				// $lines = file($inputFile); 
				// //$totRecords = count($lines);
				// $file_table_name = $wpdb->prefix . "smackcsv_file_events";
				// //$totRecords = count($lines);
                // $recordcount =  $wpdb->get_results("SELECT total_rows FROM $file_table_name WHERE hash_key = '$hash_key' ", ARRAY_A);
				// $count =count($recordcount);
				// $count -- ;
				// $tot=json_decode(json_encode($recordcount),true);
				// $totRecords = $tot[$count]['total_rows'];
				
				$totRecords = $total_rows;
			
				//comment these 2 lines after setting limit
				// $line_number = 0;
				// $addHeader = true;

				$header_array = [];
				$value_array = [];
				
                $delimiters = array( ',','\t',';','|',':','&nbsp');
				// $file_path = $upload_dir . $hash_key . '/' . $hash_key;
				// $delimiter = ScheduleImport::$validatefile->getFileDelimiter($file_path, 5);
				$array_index = array_search($delimiter,$delimiters);
				if($array_index == 5){
					$delimiters[$array_index] = ' ';
				}

				
				//uncomment after setting limit
				$get_limit = get_option('smack_csv_record_limit_'.$data_id);
				if(!empty($get_limit)){
					$record_limit = $get_limit;

					//added get total pages count for deleting csv records - settings option
					$total_pages = ceil($total_rows/$record_limit);
				}
				else{
					$record_limit = $totRecords;

					//added get total pages count for deleting csv records - settings option
					$total_pages = ceil($total_rows/$record_limit);
				}
			
				$line_number = (($record_limit * $page_number) - $record_limit) + 1;
				$limit = ($record_limit * $page_number);
				if($page_number == 1)
				{
					$addHeader = true;
				}
				$info = [];
				$i = 0;
			
				// time calculation for next 50 seconds
				$datetime_now = new \DateTime($last_run);
				$datetime_now->modify('+50 seconds');
				$datetime_after_50_sec = $datetime_now->format('Y-m-d H:i:s');	
				$processed_in_loop = 0;
				while (($data = fgetcsv($h, 0, $delimiter, '"', '\\')) !== FALSE) 
				{	
				
					ignore_user_abort(1);
					//set_time_limit(0);
				
					$schedule_exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $schedule_tableName WHERE id = %d", (int) $data_id ) );
					if ( empty( $schedule_exists ) ) {
						return true;
					}
					$trimmed_array = array_map('trim', $data);
					//uncomment after setting limit
					if ($i == 0) {
						$header_array = $this->sanitize_csv_headers( $trimmed_array );
						$this->debug_log( __FUNCTION__, 'csv_headers_loaded', array(
							'schedule_id'    => (int) $data_id,
							'event_key'      => $hash_key,
							'header_count'   => count( $header_array ),
							'first_header'   => isset( $header_array[0] ) ? $header_array[0] : '',
							'first_header_hex' => isset( $header_array[0] ) ? bin2hex( $header_array[0] ) : '',
							'has_post_title' => in_array( 'post_title', $header_array, true ),
						) );
						$i++;
						continue;
					}
					//$unmatched_rows = '';
					$unmatched_row_value = get_option('sm_uci_pro_settings');
					$unmatched_rows = isset($unmatched_row_value['unmatchedrow']) ? $unmatched_row_value['unmatchedrow'] : '';
				
					if ($i >= $line_number && $i <= $limit) {
						$value_array = $trimmed_array;
						$title_header = isset( $map['CORE']['post_title'] ) ? $map['CORE']['post_title'] : 'post_title';
						$title_key    = array_search( $title_header, $header_array, true );
						$row_title    = ( false !== $title_key && isset( $value_array[ $title_key ] ) ) ? $value_array[ $title_key ] : '';
						$this->debug_log(__FUNCTION__, 'mapping_triggered', array(
							'event_key' => $hash_key,
							'schedule_id' => (int) $data_id,
							'row_index' => $i,
							'mapping_triggered' => true,
							'resolved_post_title' => $row_title,
							'title_header_matched' => ( false !== $title_key ),
							'mode' => $get_mode,
							'module' => $selected_type,
						));
						$get_arr = ScheduleImport::$save_mapping_instance->main_import_process($map, $header_array, $value_array, $selected_type, $get_mode, $i, $unmatched_rows,$check, $hash_key, $update_based_on,$gmode,'','',$check_filter,$manage_filter);
						$processed_in_loop++;
						$post_id = $get_arr['id'];
						$core_instance->detailed_log = $get_arr['detail_log'];
						$row_log = isset( $core_instance->detailed_log[ $i ] ) ? $core_instance->detailed_log[ $i ] : ( isset( $core_instance->detailed_log[ $line_number ] ) ? $core_instance->detailed_log[ $line_number ] : array() );
						$this->debug_log( __FUNCTION__, 'row_import_result', array(
							'event_key'   => $hash_key,
							'schedule_id' => (int) $data_id,
							'row_index'   => $i,
							'post_id'     => $post_id,
							'state'       => isset( $row_log['state'] ) ? $row_log['state'] : ( isset( $row_log['Status'] ) ? $row_log['Status'] : '' ),
							'message'     => isset( $row_log['Message'] ) ? $row_log['Message'] : ( isset( $row_log['Instruction'] ) ? $row_log['Instruction'] : '' ),
							'post_title'  => isset( $row_log['post_title'] ) ? $row_log['post_title'] : $row_title,
						) );
						//$helpers_instance->get_post_ids($post_id, $hash_key);
						$remaining_records = $total_rows - $i;
						$this->update_schedule_log_row( $log_table_name, $current_log_id, $hash_key, $i, $remaining_records, 'Processing' );
						if ($i == $total_rows) {
							$this->update_schedule_log_row( $log_table_name, $current_log_id, $hash_key, $i, $remaining_records, 'Completed' );
							\Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression::disable();
						}

						if (count($core_instance->detailed_log) > 5) {
							$log_manager_instance->get_event_log($hash_key, $file_name, $file_extension, $get_mode, $total_rows, $selected_type, $core_instance->detailed_log, $addHeader);
							$addHeader = false;
							$core_instance->detailed_log = [];
						}
					}
					if ($i > $limit) {
						break;
					}

					$get_timezone = $wpdb->get_var("SELECT time_zone FROM $schedule_tableName WHERE id = $data_id ");
					$date = new \DateTime('now', new \DateTimeZone($get_timezone));
					$current_timestamp_now=$date->format('Y-m-d H:i:s');
			
					// if($current_timestamp_now >= $datetime_after_50_sec){
					// 	$get_limit = get_option('smack_csv_record_limit_'.$data_id);
					// 	if(empty($get_limit)){
					// 		$smack_record_limit = $total_rows - $remaining_records;
					// 		update_option('smack_csv_record_limit_'.$data_id,$smack_record_limit);
					// 	}
					// 	break;
					// }


					$get_limit = get_option('smack_csv_record_limit_'.$data_id);
					if(empty($get_limit)){
						if($current_timestamp_now >= $datetime_after_50_sec){
							$smack_record_limit = $total_rows - $remaining_records;
							update_option('smack_csv_record_limit_'.$data_id,$smack_record_limit);
							break;
						}
					}

					$i++;
					if($i > $totRecords) {
						$result_snapshot = $this->get_import_result_snapshot( $hash_key );
						$this->debug_log(__FUNCTION__, 'import_process_completed_iteration', array(
							'event_key' => $hash_key,
							'schedule_id' => (int) $data_id,
							'processed_rows' => $processed_in_loop,
							'total_rows' => $total_rows,
							'import_result' => $result_snapshot,
							'next_status' => ( $frequency != 0 ) ? 'waiting for next schedule' : 'completed',
							'zero_creates_warning' => ( isset( $result_snapshot['created'] ) && (int) $result_snapshot['created'] === 0 && isset( $result_snapshot['updated'] ) && (int) $result_snapshot['updated'] === 0 ),
						));
						$status = 'waiting';	
						// $wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '{$data_array['lastrun']}',nexrun = '{$data_array['nexrun']}', cron_status = 'completed' where id = '{$data_array['id']}'" );
						if($frequency != 0){

							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$existing_next_run = $wpdb->get_var("SELECT nexrun FROM {$wpdb->prefix}sm_uci_addon_pro_scheduled_import WHERE id = $data_id ");
							$last_run = $existing_next_run;
							$frequency_times = array(
								1 => '+1 day',
								2 => '+1 week',
								3 => '+1 month',
								4 => '+1 hour',
								5 => '+30 minutes',
								6 => '+15 minutes',
								7 => '+10 minutes',
								8 => '+5 minutes',
								9 => '+120 minutes',
								10 => '+240 minutes'
							);
	
							$existing_next_runs = new \DateTime($existing_next_run);
							$existing_next_runs->modify($frequency_times[$frequency]);
							$next_run = $existing_next_runs->format('Y-m-d H:i:s');	
							$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' WHERE id = $data_id" );
							$this->debug_log( __FUNCTION__, 'status_set_waiting_for_next_schedule', array(
								'schedule_id' => (int) $data_id,
								'lastrun'     => $last_run,
								'nexrun'      => $next_run,
								'import_result' => $result_snapshot,
							) );

							//uncomment
							//$page_number = 0;
							//$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' where id = $data_id" );
						}
						else{
							//uncomment
							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'completed' where id = $data_id" );
							HooksHandler::getInstance()->importActions()->fire_after_import($data_id);
							wp_clear_scheduled_hook('smack_cron_schedule_function_'. $data_id);
						}
						break;
					}	
				}
				fclose($h);
				$this->debug_log(__FUNCTION__, 'import_process_file_closed', array(
					'event_key' => $hash_key,
					'processed_rows' => $processed_in_loop,
					'total_rows' => $total_rows,
					'data_received' => ($processed_in_loop > 0),
				));
			} else {
				$this->debug_log(__FUNCTION__, 'failure_point_file_open_failed', array(
					'event_key' => $hash_key,
					'file_path' => $file_paths,
					'reason' => 'fopen returned false',
				));
			}
		}
		if($file_extension == 'tsv'){
			global $wpdb;
			$status = 'running';
			if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
				if (!ini_get("auto_detect_line_endings")) {  // If auto_detect_line_endings is not enabled
					ini_set("auto_detect_line_endings", true);  // Enable it to handle different line endings
				}
			}
			$info = [];
			$file_path = $upload_dir . $hash_key . '/' . $hash_key;
			$delimiter = ScheduleImport::$validatefile->getFileDelimiter($file_path, 5);
			if (($h = fopen($file_path, "r")) !== FALSE) 
			{
				$totRecords = $total_rows;
				$header_array = [];
				$value_array = [];
				$get_limit = get_option('smack_csv_record_limit_'.$data_id);
				if(!empty($get_limit)){
					$record_limit = $get_limit;
					$total_pages = ceil($total_rows/$record_limit);
				}
				else{
					$record_limit = $totRecords;
					$total_pages = ceil($total_rows/$record_limit);
				}
				$line_number = (($record_limit * $page_number) - $record_limit) + 1;
				$limit = ($record_limit * $page_number);
				if($page_number == 1)
				{
					$addHeader = true;
				}
				$info = [];
				$i = 0;
			
				// time calculation for next 50 seconds
				$datetime_now = new \DateTime($last_run);
				$datetime_now->modify('+50 seconds');
				$datetime_after_50_sec = $datetime_now->format('Y-m-d H:i:s');	
				while (($data = fgetcsv($h, 0, "\t", '"', '\\')) !== FALSE) 
				{	
				
					ignore_user_abort(1);
					//set_time_limit(0);
				
					$schedule_exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $schedule_tableName WHERE id = %d", (int) $data_id ) );
					if ( empty( $schedule_exists ) ) {
						return true;
					}
					$trimmed_array = array_map('trim', $data);
					//uncomment after setting limit
					if ($i == 0) {
						$header_array = $this->sanitize_csv_headers( $trimmed_array );
						$i++;
						continue;
					}
					//$unmatched_rows = '';
					$unmatched_row_value = get_option('sm_uci_pro_settings');
					$unmatched_rows = isset($unmatched_row_value['unmatchedrow']) ? $unmatched_row_value['unmatchedrow'] : '';
				
					if ($i >= $line_number && $i <= $limit) {
						$value_array = $trimmed_array;
						$get_arr = ScheduleImport::$save_mapping_instance->main_import_process($map, $header_array, $value_array, $selected_type, $get_mode, $i, $unmatched_rows,$check, $hash_key, $update_based_on,$gmode,'','',$check_filter,$manage_filter);
						$post_id = $get_arr['id'];
						$core_instance->detailed_log = $get_arr['detail_log'];
						//$helpers_instance->get_post_ids($post_id, $hash_key);
						$remaining_records = $total_rows - $i;
						$wpdb->get_results("UPDATE $log_table_name SET processing_records = $i , remaining_records = $remaining_records , status = 'Processing' WHERE hash_key = '$hash_key'");
						if ($i == $total_rows) {
							$wpdb->get_results("UPDATE $log_table_name SET status = 'Completed' WHERE hash_key = '$hash_key'");
							\Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression::disable();
						}

						if (count($core_instance->detailed_log) > 5) {
							$log_manager_instance->get_event_log($hash_key, $file_name, $file_extension, $get_mode, $total_rows, $selected_type, $core_instance->detailed_log, $addHeader);
							$addHeader = false;
							$core_instance->detailed_log = [];
						}
					}
					if ($i > $limit) {
						break;
					}

					$get_timezone = $wpdb->get_var("SELECT time_zone FROM $schedule_tableName WHERE id = $data_id ");
					$date = new \DateTime('now', new \DateTimeZone($get_timezone));
					$current_timestamp_now=$date->format('Y-m-d H:i:s');
			
					// if($current_timestamp_now >= $datetime_after_50_sec){
					// 	$get_limit = get_option('smack_csv_record_limit_'.$data_id);
					// 	if(empty($get_limit)){
					// 		$smack_record_limit = $total_rows - $remaining_records;
					// 		update_option('smack_csv_record_limit_'.$data_id,$smack_record_limit);
					// 	}
					// 	break;
					// }


					$get_limit = get_option('smack_csv_record_limit_'.$data_id);
					if(empty($get_limit)){
						if($current_timestamp_now >= $datetime_after_50_sec){
							$smack_record_limit = $total_rows - $remaining_records;
							update_option('smack_csv_record_limit_'.$data_id,$smack_record_limit);
							break;
						}
					}

					$i++;
					if($i > $totRecords) {	
						$status = 'waiting';
						// $wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '{$data_array['lastrun']}',nexrun = '{$data_array['nexrun']}', cron_status = 'completed' where id = '{$data_array['id']}'" );
						if($frequency != 0){

							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$existing_next_run = $wpdb->get_var("SELECT nexrun FROM {$wpdb->prefix}sm_uci_addon_pro_scheduled_import WHERE id = $data_id ");
							$last_run = $existing_next_run;
							$frequency_times = array(
								1 => '+1 day',
								2 => '+1 week',
								3 => '+1 month',
								4 => '+1 hour',
								5 => '+30 minutes',
								6 => '+15 minutes',
								7 => '+10 minutes',
								8 => '+5 minutes',
								9 => '+120 minutes',
								10 => '+240 minutes'
							);
	
							$existing_next_runs = new \DateTime($existing_next_run);
							$existing_next_runs->modify($frequency_times[$frequency]);
							$next_run = $existing_next_runs->format('Y-m-d H:i:s');	
							$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' WHERE id = $data_id" );

							//uncomment
							//$page_number = 0;
							//$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' where id = $data_id" );
						}
						else{
							//uncomment
							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'completed' where id = $data_id" );
							HooksHandler::getInstance()->importActions()->fire_after_import($data_id);
							wp_clear_scheduled_hook('smack_cron_schedule_function_'. $data_id);
						}
						break;
					}	
				}
				fclose($h);
			}
		}
		if($file_extension == 'xlsx'){
			$status = 'running';

					$inputFile = $upload_dir.$hash_key.'/'.$hash_key;
					$totRecords = $total_rows;
					$path = $upload_dir . $hash_key . '/' . $hash_key;
					$i=0;

					if(!empty($get_limit)){
						$record_limit = $get_limit;
					}
					else{
						$record_limit = $total_rows;
					}

					$lined_number = (($record_limit * $page_number) - $record_limit);
					$limit = ($record_limit * $page_number) - 1;
		
					if($page_number == 1)
					{
						$addHeader = true;
					}
					$datetime_now = new \DateTime($last_run);
					$datetime_now->modify('+50 seconds');
					$datetime_after_50_sec = $datetime_now->format('Y-m-d H:i:s');	
					$file_path = $upload_dir . $hash_key . '/' . $hash_key;
					if ( $xlsx = SimpleXLSX::parse($file_path) ) {
						$get_file=$xlsx->rows();
					} 
					else {
						echo SimpleXLSX::parseError();
					}
					$header_array = $get_file[0];
					unset($get_file[0]);
					$value_arrays['values'] =$get_file;
					$all_value_array=$value_arrays['values'];
					//$unmatched_rows = '';
					$unmatched_row_value = get_option('sm_uci_pro_settings');
					$unmatched_rows = isset($unmatched_row_value['unmatchedrow']) ? $unmatched_row_value['unmatchedrow'] : '';
					
					foreach($all_value_array as $i => $value_array){
						$get_arr = ScheduleImport::$save_mapping_instance->main_import_process($map, $header_array, $value_array, $selected_type, $get_mode, $i, $unmatched_rows,$check, $hash_key, $update_based_on,$gmode,'','',$check_filter,$manage_filter);
						
						$post_id = $get_arr['id'];
						$core_instance->detailed_log = $get_arr['detail_log'];
						$helpers_instance->get_post_ids($post_id, $hash_key);
						$remaining_records = $total_rows - $i;
						$wpdb->get_results("UPDATE $log_table_name SET processing_records = $i , remaining_records = $remaining_records , status = 'Processing' WHERE hash_key = '$hash_key'");
						if ($i == $total_rows) {
							$wpdb->get_results("UPDATE $log_table_name SET status = 'Completed' WHERE hash_key = '$hash_key'");
							\Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression::disable();
						}
		
						if (count($core_instance->detailed_log) > 5) {
							$log_manager_instance->get_event_log($hash_key, $file_name, $file_extension, $get_mode, $total_rows, $selected_type, $core_instance->detailed_log, $addHeader);
							$addHeader = false;
							$core_instance->detailed_log = [];
						}
					}
					$get_timezone = $wpdb->get_var("SELECT time_zone FROM $schedule_tableName WHERE id = $data_id ");
					$date = new \DateTime('now', new \DateTimeZone($get_timezone));
					$current_timestamp_now=$date->format('Y-m-d H:i:s');
					$get_limit = get_option('smack_csv_record_limit_'.$data_id);
					if(empty($get_limit)){
						if($current_timestamp_now >= $datetime_after_50_sec){
							$smack_record_limit = $total_rows - $remaining_records;
							update_option('smack_csv_record_limit_'.$data_id,$smack_record_limit);
								
						}
					}
					$i++;
					if($i >= $total_rows) {
						$status = 'waiting';	
						if($frequency != 0){
							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$existing_next_run = $wpdb->get_var("SELECT nexrun FROM {$wpdb->prefix}sm_uci_addon_pro_scheduled_import WHERE id = $data_id ");
							$last_run = $existing_next_run;
							$frequency_times = array(
								1 => '+1 day',
								2 => '+1 week',
								3 => '+1 month',
								4 => '+1 hour',
								5 => '+30 minutes',
								6 => '+15 minutes',
								7 => '+10 minutes',
								8 => '+5 minutes',
								9 => '+120 minutes',
								10 => '+240 minutes'
							);
							$existing_next_runs = new \DateTime($existing_next_run);
							$existing_next_runs->modify($frequency_times[$frequency]);
							$next_run = $existing_next_runs->format('Y-m-d H:i:s');	
						
							$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' WHERE id = $data_id" );

						}
						else{
							//uncomment
							$page_number = 0;
							$this->reset_schedule_batch_options( $data_id );
							$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'completed' WHERE id = $data_id" );
							HooksHandler::getInstance()->importActions()->fire_after_import($data_id);
						}
					}			
		}

		if($file_extension == 'xml'){
			$status = 'running';

			$path = $upload_dir . $hash_key . '/' . $hash_key;

			$get_limit = get_option('smack_xml_record_limit_'.$data_id);
			
			$total_rows = json_decode($total_rows);
			$background_values = $wpdb->get_results("SELECT mapping , module  FROM $template_table_name WHERE `eventKey` = '$hash_key' ");
			foreach ($background_values as $values) {
				$mapped_fields_values = $values->mapping;
				$selected_type = $values->module;
			}
			$map = $this->sanitize_mapping_headers( unserialize( $mapped_fields_values ) );
			$upload_dir = ScheduleImport::$smackcsv_instance->create_upload_dir();
			$path = $upload_dir . $hash_key . '/' . $hash_key;    

			$xml = simplexml_load_file($path);
			$xml_arr = json_decode( json_encode($xml) , 1);
			if (count($xml_arr) == count($xml_arr, COUNT_RECURSIVE)) 
			{
				$item = $xml->addchild('item');
				foreach($xml_arr as $key => $value){
					$xml->item->addchild($key,$value);
					unset($xml->$key);
				}
				$arraytype = "not parent";
				$xmls['item'] =$xml_arr;
			}
			else
			{
				$arraytype = "parent";
			
			}
			$i=0;
			$childs=array();
			foreach($xml->children() as $child => $val){   
				// $child_name =  $child->getName();  
				$values =(array)$val;
				if(empty($values)){
					if (!in_array($child, $childs,true))
					{
						$childs[$i++] = $child;
		
					}
				}
				else{
					if(array_key_exists("@attributes",$values)){
						if (!in_array($child, $childs,true))
						{
							$childs[$i++] = $child;
						}   
					}
					else{
						foreach($values as $k => $v){
							$checks =(string)$values[$k];
							if(is_numeric($k)){
								if(empty($checks)){
									if (!in_array($child, $childs,true))
									{
										$childs[$i++] = $child;
									}   	
								}
							}
							else{
								if(!empty($checks)){
									if (!in_array($child, $childs,true))
									{
										$childs[$i++] = $child;
									}   	
								}
							}
						}
					}
				}
			}			
			$h=0;
			if($arraytype == "parent"){
				foreach($childs as $child_name){
					$totalrows = count($xml->xpath("//$child_name"));
					foreach ($map as $field => $value) {
						foreach ($value as $head => $val) {
							$str = str_replace(array( '(','[',']', ')' ), '', $val);
							$ex = explode('/',$str);
							$last = substr($ex[2],-1);
							if(is_numeric($last)){
								$substr = substr($ex[2], 0, -1);
							}
							else{
								$substr = $ex[2];
							}							
							if($substr == $child_name){
								$count='count'.$h;
								// $totalrows = $total_rows->$count;
							}
						}
					}
				$h++;
				}
			}
			else{
				$count='count'.$h;
				//$totalrows = $total_rows->$count;
			}
			$total_rows = $totalrows;
			if(!empty($get_limit)){
				$record_limit = $get_limit;
			}
			else{
				$record_limit = $total_rows;
			}

			$lined_number = (($record_limit * $page_number) - $record_limit);
			$limit = ($record_limit * $page_number) - 1;
			// $header_array = [];
			// $value_array = [];
			$i = 0;
			$info = [];
			if($page_number == 1)
			{
				$addHeader = true;
			}

			// time calculation for next 50 seconds
			$datetime_now = new \DateTime($last_run);
			$datetime_now->modify('+50 seconds');
			$datetime_after_50_sec = $datetime_now->format('Y-m-d H:i:s');	
			
			for ($line_number = 0; $line_number < $total_rows; $line_number++) {
				if ( $i >= $lined_number && $i <= $limit) {
					$xml_class = new XmlHandler();
					$parse_xml = $xml_class->parse_xmls($hash_key,$i);
					$j = 0;
					$header_array = [];
					$value_array = [];
					$head = array();
					$value = array();
					$count = array();
					foreach($parse_xml as $xml_key => $xml_value){
						if(is_array($xml_value)){
							foreach ($xml_value as $e_key => $e_value){
								$head['header'][$j] = $e_value['name'];
								$value['value'][$j] = $e_value['value'];
								$j++;
							}
							array_push($header_array,$head);
							array_push($value_array,$value);
						}
						else{
							if(strpos($xml_key, 'count') !== false){
								array_push($count,$xml_value);
							}
						}
					}
					$xml = simplexml_load_file($path);
					// foreach($xml->children() as $child){   
					// 	$tag = $child->getName();     
					// }
					$xml_arr = json_decode( json_encode($xml) , 1);
					if (count($xml_arr) == count($xml_arr, COUNT_RECURSIVE)) 
					{
						$item = $xml->addchild('item');
						foreach($xml_arr as $key => $value){
							$xml->item->addchild($key,$value);
							unset($xml->$key);
						}
						$arraytype = "not parent";
						$xmls['item'] =$xml_arr;
					}
					else
					{
						$arraytype = "parent";
					}
					$childs=array();
					$s=0;
					foreach($xml->children() as $child => $val){   
						// $tag = $child->getName(); 
						$tag = (array)$val;
						if(empty($tag)){   
							if (!in_array($child, $childs,true))
							{
								$childs[$s++] = $child;
	
							}    
						} 
						else{
							if(array_key_exists("@attributes",$tag)){
								if (!in_array($child, $childs,true))
								{
									$childs[$s++] = $child;
								}   
							}
							else{
								foreach($tag as $k => $v){
									$checks =(string)$tag[$k];
									if(is_numeric($k)){
										if(empty($checks)){
											if (!in_array($child, $childs,true))
											{
												$childs[$s++] = $child;
											}   	
										}
									}
									else{
										if(!empty($checks)){
											if (!in_array($child, $childs,true))
											{
												$childs[$s++] = $child;
											}   	
										}
									}
								}
							}
						}
					}
					// $tag =current($childs);
					$h=0;
			
					// $total_xml_count = $xml_class->get_xml_count($path , $tag);
					// if($total_xml_count == 0){
					// 	$sub_child = $xml_class->get_child($child,$path);
					// 	$tag = $sub_child['child_name'];
					// 	$total_xml_count = $sub_child['total_count'];
					// }

					// $doc = new \DOMDocument();
					// $doc->load($path);
					// foreach ($map as $field => $value) {
					// 	foreach ($value as $head => $val) {
					// 		if (preg_match('/{/',$val) && preg_match('/}/',$val)){
					// 			preg_match_all('/{(.*?)}/', $val, $matches);
					// 			$line_numbers = $i+1;	
					// 			$val = preg_replace("{"."(".$tag."[+[0-9]+])"."}", $tag."[".$line_numbers."]", $val);
					// 			for($k = 0 ; $k < count($matches[1]) ; $k++){		
					// 				$matches[1][$k] = preg_replace("(".$tag."[+[0-9]+])", $tag."[".$line_numbers."]", $matches[1][$k]);
					// 				$value = $this->parse_element($doc, $matches[1][$k], $i);	
					// 				$search = '{'.$matches[1][$k].'}';
					// 				$val = str_replace($search, $value, $val);
					// 			}
					// 			$mapping[$field][$head] = $val;	
					// 		} 
					// 		else{
					// 			$mapping[$field][$head] = $val;
					// 		}
					// 	}
					// }

					// array_push($info, $value_array['value']);
					$unmatched_rows = '';
					$unmatched_row_value = get_option('sm_uci_pro_settings');
					$unmatched_rows = isset($unmatched_row_value['unmatchedrow']) ? $unmatched_row_value['unmatchedrow'] : '';
					
					// $get_arr = ScheduleImport::$save_mapping_instance->main_import_process($mapping, $header_array['header'], $value_array['value'], $selected_type, $get_mode, $i,$unmatched_rows, $check, $hash_key, $update_based_on, $gmode);
					// $post_id = $get_arr['id'];
					// $core_instance->detailed_log = $get_arr['detail_log'];
					if($arraytype == 'parent'){
						foreach($childs as $tag){
							$mapping=array();
					// $total_xml_count = $this->get_xml_count($path , $tag);
							$total_xml_count = $xml_class->get_xml_count($path , $tag);
							foreach($xml->children() as $child){  
								$child_names =  $child->getName();  
							}
							if($total_xml_count == 0){
								$sub_child = $xml_class->get_child($child,$path);
								$tag = $sub_child['child_name'];
								$total_xml_count = $sub_child['total_count'];
							}
							$doc = new \DOMDocument();
							$doc->load($path);
							foreach ($map as $field => $value) {
								foreach ($value as $head => $val) {
									$str = str_replace(array( '(','[',']', ')' ), '', $val);
									$ex = explode('/',$str);
									
									$last = substr($ex[2],-1);
									if(is_numeric($last)){
										$substr = substr($ex[2], 0, -1);
									}
									else{
										$substr = $ex[2];
									}

									if($substr == $tag){
										if (preg_match('/{/',$val) && preg_match('/}/',$val)){
											preg_match_all('/{(.*?)}/', $val, $matches);
											$line_numbers = $i+1;	
											$val = preg_replace("{"."(".$tag."[+[0-9]+])"."}", $tag."[".$line_numbers."]", $val);
											for($k = 0 ; $k < count($matches[1]) ; $k++){		
												$matches[1][$k] = preg_replace("(".$tag."[+[0-9]+])", $tag."[".$line_numbers."]", $matches[1][$k]);
												$value = $this->parse_element($doc, $matches[1][$k], $i);	
												$search = '{'.$matches[1][$k].'}';
												$val = str_replace($search, $value, $val);
											}
											$mapping[$field][$head] = $val;	
										} 
										else{
											$mapping[$field][$head] = $val;
										}
									}
									else{
										$mapping[$field][$head] = $val;
									}
								}
							}
							array_push($info, $value_array[$h]['value']);
							if(!empty($mapping)){
								$get_arr = ScheduleImport::$save_mapping_instance->main_import_process($mapping, $header_array[$h]['header'], $value_array[$h]['value'], $selected_type, $get_mode, $i, $unmatched_rows, $check, $hash_key, $update_based_on, $gmode,'','',$check_filter,$manage_filter);
								$post_id = $get_arr['id'];
								$core_instance->detailed_log = $get_arr['detail_log'];
							}
							$h++;
						}
					}
					else{
						$total_xml_count = 1;
						$doc = new \DOMDocument();
						$doc->load($path);
						foreach ($map as $field => $value) {
							foreach ($value as $head => $val) {
								if (preg_match('/{/',$val) && preg_match('/}/',$val)){
									preg_match_all('/{(.*?)}/', $val, $matches);
									$line_numbers = $i+1;	
									$val = preg_replace("{"."(".$tag."[+[0-9]+])"."}", $tag."[".$line_numbers."]", $val);
									for($k = 0 ; $k < count($matches[1]) ; $k++){		
										$matches[1][$k] = preg_replace("(".$tag."[+[0-9]+])", $tag."[".$line_numbers."]", $matches[1][$k]);
										$value = $this->parse_element($doc, $matches[1][$k], $i);	
										$search = '{'.$matches[1][$k].'}';
										$val = str_replace($search, $value, $val);
									}
									$mapping[$field][$head] = $val;	
								} 
								else{
									$mapping[$field][$head] = $val;
								}
							}
						}
						array_push($info, $value_array[$h]['value']);
						if(!empty($mapping)){
							$get_arr = ScheduleImport::$save_mapping_instance->main_import_process($mapping, $header_array[$h]['header'], $value_array[$h]['value'], $selected_type, $get_mode, $i, $unmatched_rows, $check, $hash_key, $update_based_on, $gmode,'','',$check_filter,$manage_filter);
							
							$post_id = $get_arr['id'];
							$core_instance->detailed_log = $get_arr['detail_log'];
						}
					}
					$helpers_instance->get_post_ids($post_id, $hash_key);
					$line_numbers = $i + 1;
					$remaining_records = $total_rows - $line_numbers;
					$wpdb->get_results("UPDATE $log_table_name SET processing_records = $i + 1 , remaining_records = $remaining_records, status = 'Processing' WHERE hash_key = '$hash_key'");


					if ($i == $total_rows - 1) {
						$wpdb->get_results("UPDATE $log_table_name SET status = 'Completed' WHERE hash_key = '$hash_key'");
						\Smackcoders\UCI\Proaddons\UltimatePro\ImportEmailSuppression::disable();
					}
	
					if (is_countable($core_instance->detailed_log) && count($core_instance->detailed_log) > 5) {
						$log_manager_instance->get_event_log($hash_key, $file_name, $file_extension, $get_mode, $total_rows, $selected_type, $core_instance->detailed_log, $addHeader);
						$addHeader = false;
						$core_instance->detailed_log = [];
					}

					// if($i == $total_rows - 1) {	
					// 	$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'completed' where id = $data_id" );
					// }

				}
				if ($i > $limit) {
					break;
				}

				$get_timezone = $wpdb->get_var("SELECT time_zone FROM $schedule_tableName WHERE id = $data_id ");
				$date = new \DateTime('now', new \DateTimeZone($get_timezone));
				$current_timestamp_now=$date->format('Y-m-d H:i:s');
		
				if($current_timestamp_now >= $datetime_after_50_sec){
					$get_limit = get_option('smack_xml_record_limit_'.$data_id);
					if(empty($get_limit)){
						$smack_record_limit = $total_rows - $remaining_records;
						update_option('smack_xml_record_limit_'.$data_id,$smack_record_limit);
					}
					break;
				}

				$i++;

				if($i >= $total_rows) {	
					$status = 'waiting';
					if($frequency != 0){
						$page_number = 0;
						$this->reset_schedule_batch_options( $data_id );
						$existing_next_run = $wpdb->get_var("SELECT nexrun FROM {$wpdb->prefix}sm_uci_addon_pro_scheduled_import WHERE id = $data_id ");
						$last_run = $existing_next_run;

						$frequency_times = array(
							1 => '+1 day',
							2 => '+1 week',
							3 => '+1 month',
							4 => '+1 hour',
							5 => '+30 minutes',
							6 => '+15 minutes',
							7 => '+10 minutes',
							8 => '+5 minutes',
							9 => '+120 minutes',
							10 => '+240 minutes'
						);

						$existing_next_runs = new \DateTime($existing_next_run);
						$existing_next_runs->modify($frequency_times[$frequency]);
						$next_run = $existing_next_runs->format('Y-m-d H:i:s');	
					
						$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' WHERE id = $data_id" );

						//uncomment
						//$page_number = 0;
						//$wpdb->query( "update {$wpdb->prefix}sm_uci_addon_pro_scheduled_import set start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'waiting for next schedule' where id = $data_id" );
					}
					else{
						//uncomment
						$page_number = 0;
						$this->reset_schedule_batch_options( $data_id );
						$wpdb->query( "UPDATE {$wpdb->prefix}sm_uci_addon_pro_scheduled_import SET start_limit = 0, lastrun = '$last_run',nexrun = '$next_run', cron_status = 'completed' WHERE id = $data_id" );
						HooksHandler::getInstance()->importActions()->fire_after_import($data_id);
					}
				}		
			}
		}
	
		//added code for deleting records from csv - settings options
		if (($unmatched_rows == 'true') && ($status == 'waiting')){
		// if ($unmatched_rows == 'true'){
			$post_entries_value = $wpdb->get_results("select ID from {$wpdb->prefix}sm_uci_addon_pro_post_entries_table " ,ARRAY_A);
			$type = $wpdb->get_var("select type from {$wpdb->prefix}sm_uci_addon_pro_post_entries_table ");
			foreach($post_entries_value as $product_id){
				$test [] = $product_id['ID'];
			}
		
		    $unmatched_object = new ExtensionHandler;
			$import_type = $unmatched_object->import_type_as($selected_type);
			$import_type_value = $unmatched_object->import_post_types($import_type);
			$import_name_as = $unmatched_object->import_name_as($import_type);
			if($type == 'cct'){
				$jettable=$wpdb->prefix.'jet_cct_'.$import_type;
				$get_total_row_count =  $wpdb->get_col("SELECT DISTINCT _ID FROM $jettable WHERE cct_status != 'trash' ");
				$unmatched_id=array_diff($get_total_row_count,$test);
					foreach($unmatched_id as $keys => $values){
						$wpdb->get_results("DELETE FROM $jettable WHERE `_ID`='$values' ");
					}
			}
			else{
				if($import_type_value == 'category' || $import_type_value == 'post_tag' || $import_type_value == 'product_cat' || $import_type_value == 'product_tag'){
					
					$get_total_row_count =  $wpdb->get_col("SELECT term_id FROM {$wpdb->prefix}term_taxonomy WHERE taxonomy = '$import_type_value'");
					$unmatched_id=array_diff($get_total_row_count,$test);

					foreach($unmatched_id as $keys => $values){
						$wpdb->get_results("DELETE FROM {$wpdb->prefix}terms WHERE `term_id` = '$values' ");
					}
				}
				if($import_type_value == 'post' || $import_type_value == 'product' || $import_type_value == 'page' || $import_name_as == 'CustomPosts'){
					
					$get_total_row_count =  $wpdb->get_col("SELECT DISTINCT ID FROM {$wpdb->prefix}posts WHERE post_type = '{$import_type_value}' AND post_status != 'trash' ");
					$unmatched_id=array_diff($get_total_row_count,$test);
					foreach($unmatched_id as $keys => $values){
						$wpdb->get_results("DELETE FROM {$wpdb->prefix}posts WHERE `ID` = '$values' ");
					}
				}
			}
			$wpdb->get_results("DELETE FROM {$wpdb->prefix}sm_uci_addon_pro_post_entries_table");
			
		}

		//uncomment
		update_option('smack_csv_page_number_'. $data_id, $page_number);

		$terminal_status = $wpdb->get_var( $wpdb->prepare( "SELECT cron_status FROM $schedule_tableName WHERE id = %d", (int) $data_id ) );
		$this->finalize_schedule_batch_status( (int) $data_id, $hash_key, (int) $page_number, (int) $total_rows, (string) $terminal_status );
		$this->debug_log( __FUNCTION__, 'batch_completed', array(
			'schedule_id' => (int) $data_id,
			'page_number' => (int) $page_number,
			'cron_status' => $terminal_status,
		) );
	
		if (is_countable($core_instance->detailed_log) && count($core_instance->detailed_log) > 0) {
			$log_manager_instance->get_event_log($hash_key , $file_name , $file_extension, $get_mode , $total_rows , $selected_type , $core_instance->detailed_log, $addHeader);
		}

		$file_manager_instance->manage_records($hash_key ,$selected_type , $file_name , $total_rows);
		$upload = wp_upload_dir();
		$upload_base_url = $upload['baseurl'];
		$upload_url = $upload_base_url . '/smack_uci_uploads/imports/';
		$log_path = $upload_dir.$hash_key.'/'.$hash_key.'.html';

		$log_value = $log_manager_instance->displayLogValue();



		//for log
		global $wpdb;
		$table_name = $wpdb->prefix . 'summary';

		//  data for batch insert
		$data_to_insert = array();

		foreach ($log_value as $item) {
			$inserted_id = isset($item['id']) ? $item['id'] : null;
			$post_title = isset($item['post_title']) ? $item['post_title'] : null;
			$post_type = isset($item['post_type']) ? $item['post_type'] : null;
			$status = isset($item['Status']) ? $item['Status'] : null;
			$total_images = isset($item['total_image']) ? $item['total_image'] : 0;
			$failed_images = isset($item['failed_image_count']) ? $item['failed_image_count'] : 0;

			// $categorie = ($post_type == 'Categories') ? 1 : 0;
			if ($post_type == 'Categories') {
				$categorie = 1;
			} elseif ($post_type == 'Tags' || $post_type == 'Taxonomies') {

				$categorie = 2;
			} elseif ($post_type == 'users') {
				$categorie = 3;
			} elseif ($post_type == 'Comment' || $post_type == 'Reviews') {
				$categorie = 4;
			} else {
				$categorie = 0;
			}


			$data_to_insert[] = $wpdb->prepare(
				"(%d, %s, %s, %s, %s, %d, %d, %d)",
				$inserted_id,
				$hash_key,
				$post_title,
				$post_type,
				$status,
				$categorie,
				$total_images,
				$failed_images
			);
		}
		// Batch insert for boosting speed
		if (!empty($data_to_insert)) {
			$query = "INSERT INTO $table_name (post_id, event_id, post_title, post_type, status, is_category, associated_media, failed_media) VALUES " . implode(", ", $data_to_insert);
			$wpdb->query($query);
		}
		//for failed media log
		global $wpdb;
		$table_name = $wpdb->prefix . 'failed_media';

		if (!empty($failed_media_log)) {
			// Data for batch insert
			$data_to_insert = array();

			foreach ($failed_media_log as $item) {
				$inserted_id = $item['post_id'];
				$post_title = $item['post_title'];
				$media_id = $item['media_id'];
				$image_url = $item['actual_url'];
				$status = 'Failed';
				// Correct the number of placeholders and arguments
				$data_to_insert[] = $wpdb->prepare(
					"(%d, %s, %s,  %d, %s , %s)",
					$inserted_id,
					$hash_key,
					$post_title,
					$media_id,
					$image_url,
					$status
				);
			}

			// Batch insert for boosting speed
			if (!empty($data_to_insert)) {
				$query = "INSERT INTO $table_name (post_id, event_id, title,  media_id, actual_url,status) VALUES " . implode(", ", $data_to_insert);
				$wpdb->query($query);
			}
		}

		if ( class_exists( ImportResumeService::class ) ) {
			$log_status = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT status FROM $log_table_name WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
					$hash_key
				)
			);
			if ( 'Completed' === $log_status ) {
				ImportResumeService::getInstance()->mark_completed( $hash_key );
			} else {
				ImportResumeService::getInstance()->sync_checkpoint_from_log( $hash_key );
			}
		}

		if(file_exists($log_path)){
			$log_link_path = $upload_url. $hash_key .'/'.$hash_key.'.html';
			$response['success'] = true;
			$response['log_link'] = $log_link_path;
		}else{
			$latest_import_log = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT status, processing_records, total_records FROM $log_table_name WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
					$hash_key
				),
				ARRAY_A
			);
			$latest_status = isset($latest_import_log['status']) ? strtolower((string) $latest_import_log['status']) : '';
			$has_import_activity = !empty($latest_import_log) && ($latest_status === 'processing' || $latest_status === 'completed');
			$response['success'] = $has_import_activity;
			if (!$has_import_activity) {
			}
		}
	}
	
	/**
	 * Update the active import log row for this schedule run (not every historical log).
	 *
	 * @param string $log_table_name Log table.
	 * @param int    $current_log_id Log row id from current insert.
	 * @param string $hash_key       Event hash fallback.
	 * @param int    $processed      Processed row index.
	 * @param int    $remaining      Remaining rows.
	 * @param string $status         Log status.
	 */
	private function update_schedule_log_row( $log_table_name, $current_log_id, $hash_key, $processed, $remaining, $status ) {
		global $wpdb;
		if ( $current_log_id > 0 ) {
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$log_table_name} SET processing_records = %d, remaining_records = %d, status = %s WHERE id = %d",
					(int) $processed,
					(int) $remaining,
					$status,
					(int) $current_log_id
				)
			);
			return;
		}
		$log_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$log_table_name} WHERE hash_key = %s ORDER BY id DESC LIMIT 1",
				$hash_key
			)
		);
		if ( $log_id > 0 ) {
			$this->update_schedule_log_row( $log_table_name, $log_id, $hash_key, $processed, $remaining, $status );
		}
	}

	public function parse_element($xml,$query){
		$query = strip_tags($query);
		$xpath = new \DOMXPath($xml);
		$entries = $xpath->query($query);
		$content = $entries->item(0)->textContent;
		return $content;
	}
}