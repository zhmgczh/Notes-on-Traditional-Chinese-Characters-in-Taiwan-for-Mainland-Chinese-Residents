<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (! defined('ABSPATH'))
	exit; // Exit if accessed directly

class MediaHandling
{
	private static $instance = null, $smack_instance, $smack_csv_instance;
	public static $failed_image_instance;
	public static $uci_core_mediahandling = null;
	public $header_array = array();
	public $value_array = array();
	public static $global_header_array = array();
	public static $global_value_array = array();

	/**
	 * Download a remote image with retries, longer timeouts, and Range resume on partial timeouts.
	 * Streams to a temp file so interrupted transfers can resume.
	 *
	 * @param string      $url
	 * @param string      $user_agent
	 * @param int|null    $timeout
	 * @param int|null    $line_number
	 * @param int|null    $connection_timeout
	 * @param string      $file_ext
	 * @return array|\WP_Error
	 */
	public static function fetch_remote_image( $url, $user_agent = '', $timeout = null, $line_number = null, $connection_timeout = null, $file_ext = '' ) {
		if ( empty( $user_agent ) ) {
			$user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36';
		}

		$settings = self::get_download_settings( $file_ext );
		if ( null === $connection_timeout ) {
			$connection_timeout = $settings['connection_timeout'];
		} else {
			$connection_timeout = max( 1, (int) $connection_timeout );
		}
		if ( null === $timeout ) {
			$timeout = $settings['download_timeout'];
		} else {
			$timeout = max( 1, (int) $timeout );
		}
		$max_attempts = $settings['max_retry_count'];

		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( $host ) {
			// Warm DNS cache before download attempts.
			gethostbyname( $host );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'smack_uci_uploads/tmp_media/';
		if ( ! is_dir( $tmp_dir ) ) {
			wp_mkdir_p( $tmp_dir );
		}
		$tmp_file = $tmp_dir . 'dl_' . md5( $url . microtime( true ) ) . '.part';
		@unlink( $tmp_file );

		$last_error = '';

		for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {
			$have = file_exists( $tmp_file ) ? (int) filesize( $tmp_file ) : 0;

			$result = self::curl_download_to_file( $url, $tmp_file, $user_agent, $timeout, $have, $connection_timeout );
			if ( is_wp_error( $result ) ) {
				$last_error = $result->get_error_message();
				if ( $attempt < $max_attempts ) {
					usleep( (int) self::backoff_sleep_seconds( $attempt ) * 1000000 );
				}
				continue;
			}

			$http_code = (int) $result['code'];
			$size      = file_exists( $tmp_file ) ? (int) filesize( $tmp_file ) : 0;
			$complete  = ! empty( $result['complete'] );

			if ( in_array( $http_code, array( 404, 403, 401, 500, 502, 503, 504 ), true ) ) {
				@unlink( $tmp_file );
				return new \WP_Error( 'uci_http_error', 'HTTP ' . $http_code, array( 'status' => $http_code ) );
			}

			if ( in_array( $http_code, array( 200, 206 ), true ) && $size > 0 && $complete ) {
				if ( ! self::validate_downloaded_file( $tmp_file ) ) {
					@unlink( $tmp_file );
					$last_error = 'Downloaded file failed validation';
					if ( $attempt < $max_attempts ) {
						usleep( (int) self::backoff_sleep_seconds( $attempt ) * 1000000 );
					}
					continue;
				}
				$rawdata = (string) file_get_contents( $tmp_file );
				@unlink( $tmp_file );
				return array(
					'body'     => $rawdata,
					'code'     => 200,
					'response' => null,
				);
			}

			$last_error = 'HTTP ' . $http_code;
			if ( $attempt < $max_attempts ) {
				usleep( (int) self::backoff_sleep_seconds( $attempt ) * 1000000 );
			}
		}

		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $url, $timeout );
		if ( ! is_wp_error( $tmp ) && is_string( $tmp ) && file_exists( $tmp ) ) {
			if ( self::validate_downloaded_file( $tmp ) ) {
				$rawdata = (string) file_get_contents( $tmp );
				@unlink( $tmp );
				@unlink( $tmp_file );
				return array(
					'body'     => $rawdata,
					'code'     => 200,
					'response' => null,
				);
			}
			@unlink( $tmp );
			$last_error = 'Downloaded file failed validation';
		} elseif ( is_wp_error( $tmp ) ) {
			$last_error = $tmp->get_error_message();
		}

		@unlink( $tmp_file );
		return new \WP_Error(
			'uci_download_failed',
			$last_error ? $last_error : 'Remote download failed after retries',
			array( 'url' => $url )
		);
	}

	/**
	 * Stream URL into temp file; append when $offset > 0 (HTTP Range resume).
	 *
	 * @return array|\WP_Error { code, complete }
	 */
	public static function curl_download_to_file( $url, $tmp_file, $user_agent, $timeout, $offset = 0, $connection_timeout = null ) {
		if ( null === $connection_timeout ) {
			$connection_timeout = self::get_download_settings()['connection_timeout'];
		}
		$connection_timeout = max( 1, (int) $connection_timeout );
		if ( ! function_exists( 'curl_init' ) ) {
			$headers = array();
			if ( $offset > 0 ) {
				$headers['Range'] = 'bytes=' . $offset . '-';
			}
			$response = wp_remote_get(
				$url,
				array(
					'timeout'    => $timeout,
					'user-agent' => $user_agent,
					'headers'    => $headers,
				)
			);
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = (string) wp_remote_retrieve_body( $response );
			if ( $code === 206 || $offset > 0 ) {
				file_put_contents( $tmp_file, $body, FILE_APPEND );
			} else {
				file_put_contents( $tmp_file, $body );
			}
			return array( 'code' => $code, 'complete' => ( $body !== '' && in_array( $code, array( 200, 206 ), true ) ) );
		}

		$fp = fopen( $tmp_file, $offset > 0 ? 'ab' : 'wb' );
		if ( ! $fp ) {
			return new \WP_Error( 'uci_tmp_open', 'Cannot open temp file for download' );
		}

		$ch = curl_init( $url );
		curl_setopt_array(
			$ch,
			array(
				CURLOPT_FILE            => $fp,
				CURLOPT_FOLLOWLOCATION  => true,
				CURLOPT_MAXREDIRS       => 5,
				CURLOPT_CONNECTTIMEOUT  => max( 1, (int) $connection_timeout ),
				CURLOPT_TIMEOUT         => (int) $timeout,
				CURLOPT_USERAGENT       => $user_agent,
				CURLOPT_SSL_VERIFYPEER  => true,
				CURLOPT_SSL_VERIFYHOST  => 2,
				CURLOPT_FAILONERROR     => false,
				CURLOPT_NOSIGNAL        => true,
			)
		);
		if ( $offset > 0 ) {
			curl_setopt( $ch, CURLOPT_RANGE, $offset . '-' );
		}

		$ok   = curl_exec( $ch );
		$err  = curl_error( $ch );
		$code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
		curl_close( $ch );
		fclose( $fp );

		$size = file_exists( $tmp_file ) ? (int) filesize( $tmp_file ) : 0;

		// Timeout but bytes landed — resume next attempt
		if ( ! $ok && $size > $offset ) {
			return array( 'code' => 206, 'complete' => false );
		}

		if ( ! $ok && $size <= $offset ) {
			return new \WP_Error( 'uci_curl', $err ? $err : 'cURL download failed' );
		}

		return array( 'code' => $code ? $code : 200, 'complete' => true );
	}

	/**
	 * Read admin media download settings with optional extension-based floor.
	 *
	 * @param string $file_ext File extension hint.
	 * @return array{connection_timeout:int,download_timeout:int,max_retry_count:int}
	 */
	public static function get_download_settings( $file_ext = '' ) {
		$settings_class = '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadSettings';
		if ( class_exists( $settings_class ) ) {
			return array(
				'connection_timeout' => (int) call_user_func( array( $settings_class, 'get_connection_timeout' ) ),
				'download_timeout'   => (int) call_user_func( array( $settings_class, 'get_download_timeout' ), $file_ext ),
				'max_retry_count'    => (int) call_user_func( array( $settings_class, 'get_max_retry_count' ) ),
			);
		}

		return array(
			'connection_timeout' => 10,
			'download_timeout'   => 30,
			'max_retry_count'    => 3,
		);
	}

	/**
	 * Exponential backoff seconds: min(120, 5 * 2^(attempt-1)).
	 *
	 * @param int $attempt 1-based attempt number.
	 * @return int
	 */
	public static function backoff_sleep_seconds( $attempt ) {
		$settings_class = '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadSettings';
		if ( class_exists( $settings_class ) ) {
			return (int) call_user_func( array( $settings_class, 'retry_backoff_seconds' ), $attempt );
		}
		$attempt = max( 1, (int) $attempt );
		return min( 120, 5 * ( 2 ** ( $attempt - 1 ) ) );
	}

	/**
	 * @param string $file_path Local temp file path.
	 * @return bool
	 */
	public static function validate_downloaded_file( $file_path ) {
		if ( ! is_string( $file_path ) || $file_path === '' || ! file_exists( $file_path ) ) {
			return false;
		}
		$size = (int) filesize( $file_path );
		if ( $size <= 0 ) {
			return false;
		}
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$mime = finfo_file( $finfo, $file_path );
				finfo_close( $finfo );
				if ( empty( $mime ) || 'application/x-empty' === $mime ) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Validate in-memory download bytes (size and basic MIME sanity).
	 *
	 * @param string $body     Downloaded content.
	 * @param string $file_ext Expected extension when known.
	 * @return true|\WP_Error
	 */
	public static function validate_remote_download( $body, $file_ext = '' ) {
		if ( ! is_string( $body ) || '' === $body ) {
			return new \WP_Error( 'uci_empty_download', 'Downloaded file is empty' );
		}

		$mime = '';
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$sample = strlen( $body ) > 8192 ? substr( $body, 0, 8192 ) : $body;
				$mime   = (string) finfo_buffer( $finfo, $sample );
				finfo_close( $finfo );
			}
		}

		$blocked = array( 'text/html', 'text/plain', 'application/json', 'application/xml', 'text/xml', 'application/x-empty' );
		if ( $mime && in_array( $mime, $blocked, true ) ) {
			return new \WP_Error( 'uci_invalid_mime', 'Unexpected content type: ' . $mime );
		}

		if ( $file_ext && $mime ) {
			$image_exts = array( 'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg' );
			if ( in_array( strtolower( $file_ext ), $image_exts, true ) && 0 !== strpos( $mime, 'image/' ) ) {
				return new \WP_Error( 'uci_mime_mismatch', 'Downloaded content is not an image' );
			}
		}

		return true;
	}

	public function __construct()
	{
		//require_once(ABSPATH.'wp-load.php');
		require_once(ABSPATH . 'wp-admin/includes/image.php');
		require_once(ABSPATH . 'wp-admin/includes/media.php');
		require_once(ABSPATH . 'wp-admin/includes/post.php');
		require_once(ABSPATH . 'wp-admin/includes/file.php');

		add_action('wp_ajax_zip_upload', array($this, 'zipImageUpload'));
		add_action('wp_ajax_image_options', array($this, 'imageOptions'));
		add_action('wp_ajax_delete_image', array($this, 'deleteImage'));
		add_action('wp_ajax_media_report', array($this, 'mediaReport'));
	}

	public static function imageOptions()
	{
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$media_settings['use_ExistingImage'] = sanitize_text_field($_POST['use_ExistingImage']);
		$media_settings['overwriteImage'] = sanitize_text_field($_POST['overwriteImage']);
		$media_settings['enable_postcontent_image'] = sanitize_text_field($_POST['postContent_image_option']);
		$media_settings['newImage'] = sanitize_text_field($_POST['newImage']);
		$media_settings['title'] = sanitize_text_field($_POST['title']);
		$media_settings['caption'] = sanitize_text_field($_POST['caption']);
		$media_settings['alttext'] = sanitize_text_field($_POST['alttext']);
		$media_settings['description'] = sanitize_text_field($_POST['description']);
		$media_settings['file_name'] = sanitize_text_field($_POST['file_name']);
		$media_settings['media_handle_option'] = sanitize_text_field($_POST['media_handle_option']);
		$image_info = array(
			'media_settings'  => $media_settings
		);
		update_option('smack_image_options', $image_info);
		$result['success'] = 'true';
		echo wp_json_encode($result);
		wp_die();
	}

	public static function getInstance()
	{
		if (MediaHandling::$instance == null) {
			MediaHandling::$instance = new MediaHandling;
			MediaHandling::$smack_instance = UltimatePro::getInstance();
			MediaHandling::$smack_csv_instance = SmackCSVInstall::getInstance();
			MediaHandling::$uci_core_mediahandling = class_exists('\Smackcoders\UCI\Core\MediaHandling') ? \Smackcoders\UCI\Core\MediaHandling::getInstance() : null;
			return MediaHandling::$instance;
		}
		return MediaHandling::$instance;
	}

	/**
	 * Whether a media SEO option value is an unresolved mapping field key
	 * (e.g. "featured_image_title") rather than real title/caption text.
	 *
	 * @param mixed $value Option or row value.
	 * @return bool
	 */
	public static function is_unresolved_media_seo_value( $value ) {
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return true;
		}
		static $tokens = array(
			'featured_image_title',
			'featured_image_caption',
			'featured_image_alt_text',
			'featured_image_description',
			'featured_file_name',
			'product_gallery_image_title',
			'product_gallery_image_caption',
			'product_gallery_image_alt_text',
			'product_gallery_image_description',
		);
		return in_array( $value, $tokens, true );
	}

	/**
	 * Helper to fire the gallery image hook safely.
	 * 
	 * @param int $post_id   The parent post ID.
	 * @param int $attach_id The attachment ID.
	 */
	public function fire_gallery_image_hook($post_id, $attach_id) {
		if (empty($attach_id) || !is_numeric($attach_id)) return;
		
		// Prevent double-firing for the same post-attachment pair in one process
		static $fired_hooks = [];
		$hook_key = $post_id . '_' . $attach_id;
		if (isset($fired_hooks[$hook_key])) return;
		$fired_hooks[$hook_key] = true;

		$filepath = get_attached_file($attach_id);
		$media_handle = get_option('smack_image_options');
		$is_keep_existing = ($media_handle['media_settings']['use_ExistingImage'] == 'true') ? 1 : '';
		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_gallery_image($post_id, $attach_id, $filepath, $is_keep_existing);
	}

	/**
	 * Helper to fire the attachment uploaded hook safely.
	 * 
	 * @param int $post_id   The parent post ID.
	 * @param int $attach_id The attachment ID.
	 */
	public function fire_attachment_uploaded_hook($post_id, $attach_id) {
		if (empty($attach_id) || !is_numeric($attach_id)) return;
		
		static $fired_uploads = [];
		if (isset($fired_uploads[$attach_id])) return;
		$fired_uploads[$attach_id] = true;

		$filepath = get_attached_file($attach_id);
		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_attachment_uploaded($post_id, $attach_id, $filepath);
	}


	public function zipImageUpload()
	{
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		// Check if the ZIP extension is loaded
		if (!extension_loaded('zip')) {
			$result['success'] = false;
			$result['message'] = 'The PHP ZIP extension is not installed. Please contact your server administrator to install it.';
			echo wp_json_encode($result);
			wp_die();
		}
		// Check if a file was uploaded
		if (isset($_FILES['zipFile']['name'])) {
			$zip_file_name = $_FILES['zipFile']['name'];
			$file_ext = pathinfo($zip_file_name, PATHINFO_EXTENSION);

			// Validate file extension
			if (strtolower($file_ext) !== 'zip') {
				$result['success'] = false;
				$result['message'] = 'Invalid file format. Please upload a zip file.';
				echo wp_json_encode($result);
				wp_die();
			}

			$hash_key = MediaHandling::$smack_instance->convert_string2hash_key($zip_file_name);
			$media_dir = wp_get_upload_dir();
			$upload_dir = MediaHandling::$smack_instance->create_upload_dir();
			$path = $upload_dir . $hash_key . '.zip';
			$extract_path = $media_dir['path'] . '/';

			if (file_exists($path)) {
				chmod($path, 0777);
			}

			move_uploaded_file($_FILES['zipFile']['tmp_name'], $path);
			$zip = new \ZipArchive;
			$res = $zip->open($path);

			if ($res === TRUE) {
				$filename = [];
				$size = [];
				$kbsize = [];

				for ($i = 0; $i < $zip->numFiles; $i++) {

					$filename[$i] = $zip->getNameIndex($i);
					if (substr($zip->getNameIndex($i), -1) == '/' || !self::$uci_core_mediahandling->isValidImageFile($filename[$i])) {
						continue;
					}
					$sanitized_filename = str_replace(' ', '-', basename($filename[$i]));
					$sanitized_filename = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $sanitized_filename);
					$full_extract_path = $extract_path . $sanitized_filename;
					$fp = $zip->getStream($filename[$i]);
					$size[$i] = $zip->statIndex($i)['size'];
					$kbsize[$i] = self::$uci_core_mediahandling->convertToReadableSize($size[$i]);
					$ofp = fopen($full_extract_path, 'w');
					while (!feof($fp)) {
						fwrite($ofp, fread($fp, 8192));
					}

					fclose($fp);
					fclose($ofp);
				}
				$filename = self::$uci_core_mediahandling->ValidImageFileAdded($filename);
				$kbsize = self::$uci_core_mediahandling->ImageFileSizeAdded($filename, $kbsize);
				$zip->close();
				$result['success'] = true;
				$result['zip_file_name'] = $zip_file_name;
				$result['count'] = count($filename);
				$result['filename'] = $filename;
				$result['size'] = $kbsize;
			} else {
				$result['success'] = false;
				$result['message'] = 'Failed to open the zip file.';
			}
		} else {
			$result['success'] = false;
			$result['message'] = 'No file uploaded.';
		}

		echo wp_json_encode($result);
		wp_die();
	}
	// private function ImageFileSizeAdded($filenames, $sizes)
	// {
	// 	$newSizes = [];
	// 	$sizes = array_values($sizes);
	// 	$sizeIndex = 0;
	// 	foreach ($filenames as $index => $filename) {
	// 		if (substr($filename, -1) === '/') {
	// 			// Skip if it's a directory
	// 			continue;
	// 		} else {
	// 			if (isset($sizes[$sizeIndex])) {
	// 				$newSizes[$index] = $sizes[$sizeIndex];
	// 				$sizeIndex++;
	// 			}
	// 		}
	// 	}
	// 	return $newSizes;
	// }
	// private function ValidImageFileAdded($filename)
	// {
	// 	$validExtensions = ['jpg', 'jpeg', 'png', 'svg','webp','bmp'];
	// 	$filteredFiles = [];
	// 	for ($i = 0; $i < count($filename); $i++) {
	// 		$fileInfo = pathinfo($filename[$i]);
	// 		if ( strpos($filename[$i], '__MACOSX/') === 0 || (substr($fileInfo['basename'], 0, 1) === '.') && (!in_array(strtolower($fileInfo['extension']), $validExtensions))) {
	// 			continue;
	// 		} else {
	// 			if (substr($filename[$i], -1) === '/' || in_array(strtolower($fileInfo['extension']), $validExtensions)) {
	// 				$filteredFiles[$i] = $filename[$i];
	// 			}
	// 		}
	// 	}
	// 	$filenames = array_values($filteredFiles);
	// 	return $filenames;
	// }
	// private function isValidImageFile($filename)
	// {
	// 	$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
	// 	if (in_array($ext, ['jpg', 'jpeg', 'png', 'svg','webp', 'bmp'])) {
	// 		return true;
	// 	} else {
	// 		return false;
	// 	}
	// }
	// public function convertToReadableSize($size)
	// {
	// 	$base = log($size) / log(1024);
	// 	$suffix = array("", "KB", "MB", "GB", "TB");
	// 	$f_base = floor($base);
	// 	return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
	// }

	public function deleteImage()
	{
		if (!is_user_logged_in() || !current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Unauthorized access.'], 403);
			return;
		}

		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$images = json_decode(stripslashes($_POST['images']), true);
		if (!empty($images)) {
			if (empty($images) || !is_array($images)) {
				wp_send_json_error(['message' => 'Invalid input.'], 400);
				return;
			}

			// Get the media upload directory
			$media_dir = wp_get_upload_dir();
			$upload_path = realpath($media_dir['path']); // Get absolute path

			if (!$upload_path) {
				wp_send_json_error(['message' => 'Upload directory not found.'], 500);
				return;
			}

			foreach ($images as $image) {
				// Sanitize the filename to prevent directory traversal
				$deleteimage = sanitize_file_name(basename($image));
				$file_path = realpath(trailingslashit($upload_path) . $deleteimage);

				// Ensure the file is inside the uploads directory
				if (!$file_path || strpos($file_path, $upload_path) !== 0) {
					wp_send_json_error(['message' => 'Invalid file path.'], 403);
					return;
				}

				// Delete the file if it exists
				if (file_exists($file_path) && is_file($file_path)) {
					unlink($file_path);
				}
				$result['success'] = 'true';
			}

		} 
		else {
			$result['success'] = 'true';
		}


		echo wp_json_encode($result);
		wp_die();
	}

	public function media_handling($img_url, $post_id, $data_array = null, $plugin = null, $import_type = null, $acf_wpname_element = null, $templatekey = null, $unikey = null, $unikey_name = null, $header_array = null, $value_array = null, $wpml_array = null, $image_metas = null, $line_number = null, $indexs = null, $acf_image_meta = null, $media_type = null, $media_id = null, $jet_child_object_id = null, $parent_object_id = null, $media_mode = null,$featured= false)
	{
		global $wpdb;
		$img_url = trim(html_entity_decode(rawurldecode($img_url), ENT_QUOTES, 'UTF-8'));
		$img_url = $this->normalize_single_image_url( $img_url, $plugin, $indexs, $featured );

        $h_arr = is_array($header_array) ? $header_array : (is_array($templatekey) ? $templatekey : (is_array($this->header_array) ? $this->header_array : array()));
        $v_arr = is_array($value_array) ? $value_array : (is_array($unikey) ? $unikey : (is_array($this->value_array) ? $this->value_array : array()));

        // Prepare article data and record data for the filter
        $articleData = is_array($data_array) ? $data_array : array();
        
        // Final Fallback: If everything else failed, use static global context
        if (empty($h_arr)) $h_arr = self::$global_header_array;
        if (empty($v_arr)) $v_arr = self::$global_value_array;

        $current_process_record_data = (!empty($h_arr) && !empty($v_arr) && count($h_arr) === count($v_arr)) ? array_combine($h_arr, $v_arr) : array();
        
        // Fallback: If articleData is empty, use record data
        if (empty($articleData)) {
            $articleData = $current_process_record_data;
        }


		$url = parse_url($img_url);
		$media_handle = get_option('smack_image_options');
		if (isset($url['scheme']) && ($url['scheme'] == 'http' || $url['scheme'] == 'https')) {
			if (strstr($img_url, 'https://drive.google.com')) {
				preg_match('~/d/\K[^/]+(?=/)~', $img_url, $result_id);
				$image_title = isset($result_id[0]) ? $result_id[0] : basename($img_url);
			} else {
				$image_name = basename($img_url);
				$image_title = sanitize_file_name(pathinfo($image_name, PATHINFO_FILENAME));
			}
		} else {
			$image_title = preg_replace('/\\.[^.\\s]{3,4}$/', '', $img_url);
		}

		if (strpos($img_url, 'wp-ultimate-csv-importer-pro/assets/images/loading-image.jpg') !== false) {
			$existing_loading_image_id = $wpdb->get_results("SELECT ID FROM {$wpdb->prefix}posts WHERE post_name LIKE 'loading-image%' AND guid LIKE '%loading-image%' ", ARRAY_A);
			if (!empty($existing_loading_image_id[0]['ID'])) {
				$attach_id = $existing_loading_image_id[0]['ID'];
				return $attach_id;
			}
		}

		// Download external images to your media if true
		if ($media_handle['media_settings']['media_handle_option'] == 'true') {
			if ($media_handle['media_settings']['use_ExistingImage'] == 'true') {

				if (empty($img_url)) {
					$attach_id = $img_url;
					if (!empty($data_array)) {
						foreach ($data_array as $values) {
							$attachment = $wpdb->get_var(
								$wpdb->prepare(
									"SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
									$values
								)
							);

							if ($attachment) {
								delete_post_thumbnail($post_id);
							} else {
								set_post_thumbnail($post_id, $attach_id);
								$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
							}
							$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
							$this->fire_gallery_image_hook($post_id, $attach_id);
							return $attach_id;
						}
					}
				}

				if (is_numeric($img_url)) {
					$attach_id = $img_url;
					if ($attach_id == 0) {
						delete_post_thumbnail($post_id);
					} else {
						if (!empty($data_array['featured_image'])) {
							set_post_thumbnail($post_id, $attach_id);
						}
					}
					$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
					$this->fire_gallery_image_hook($post_id, $attach_id);
					return $attach_id;
				} else {
					// Prefer source-URL identity over post_title. Title matching alone is unsafe
					// after SEO metadata has renamed attachments (cross-product image leak).
					// CDN sources often share basename (e.g. 1_org_zoom.jpg) for different images.
					$attachment_id = array();
					if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' ) ) {
						$existing_by_url = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::find_existing( $img_url, basename( (string) $img_url ) );
						if ( $existing_by_url > 0 ) {
							$attachment_id = array( array( 'ID' => (int) $existing_by_url ) );
						}
					}
					// Basename/title reuse only for non-remote sources (local filenames).
					$is_remote = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' )
						? \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::is_remote_url( $img_url )
						: (bool) preg_match( '#^https?://#i', (string) $img_url );
					if ( empty( $attachment_id ) && ! $is_remote && $image_title !== '' && ! self::is_unresolved_media_seo_value( $image_title ) ) {
						$candidate_rows = $wpdb->get_results(
							$wpdb->prepare(
								"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_title = %s AND post_title != 'image-failed' LIMIT 5",
								$image_title
							),
							ARRAY_A
						);
						foreach ( (array) $candidate_rows as $row ) {
							$cid = isset( $row['ID'] ) ? (int) $row['ID'] : 0;
							$ok  = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' )
								? \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::attachment_matches_source( $cid, $img_url )
								: ( $cid > 0 );
							if ( $ok ) {
								$attachment_id = array( array( 'ID' => $cid ) );
								break;
							}
						}
					}
				}
				if (!empty($attachment_id) && empty($media_mode)) {
					$wpml_multi_lang_mode = true;
					foreach ($attachment_id as $value) {
						if (!empty($wpml_array['language_code'])) {
							$attached_id = $value['ID'];
							$lang_code = $wpml_array['language_code'];
							$get_image_element_id = $wpdb->get_results(
								$wpdb->prepare(
									"SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE element_type = 'post_attachment' AND element_id = %d AND language_code = %s",
									$attached_id,
									$lang_code
								),
								ARRAY_A
							);
							if (!empty($get_image_element_id[0]['element_id'])) {
								$wpml_multi_lang_mode = false;
								$get_lang_image_id = $get_image_element_id[0]['element_id'];
								return $get_lang_image_id;
							}
						} else {
							$attach_id = $value['ID'];
							if (!wp_get_attachment_url($attach_id)) {
								$attach_id = $this->image_function($img_url, $post_id, $data_array, '', 'use_existing_image', $header_array, $value_array, $wpml_array, $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
							} else {
								if (!empty($data_array['featured_image'])) {
									set_post_thumbnail($post_id, $attach_id);
								}
							}
						}
					}

					if ((!empty($wpml_array['language_code'])) && ($wpml_multi_lang_mode)) {
						$attach_id = $this->image_function($img_url, $post_id, $data_array, '', 'use_existing_image', $header_array, $value_array, $wpml_array, $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
						return $attach_id;
					}

					$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
				} else {
					$attach_id = $this->image_function($img_url, $post_id, $data_array, '', 'use_existing_image', $header_array, $value_array, $wpml_array, $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
					if (!empty($attach_id)) {
						$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
					}
				}
			} elseif ($media_handle['media_settings']['overwriteImage'] == 'true') {

				// // Get the file name from the URL
				$fimg_name = @basename($img_url);
				$pathinfo = pathinfo($fimg_name);
				$imagename = $pathinfo['filename'];
				$image_title = str_replace(' ', '-', trim($imagename));
				// Replace dots with dashes and ensure lowercase
				$fil_name = strtolower(str_replace('.', '-', $image_title));
				// Remove any characters that are not alphanumeric, dashes, or underscores
				$fil_name = preg_replace('/[^a-z0-9-_]/', '', $fil_name);
				$fil_name = esc_sql($fil_name);
				$guid_like = esc_sql('%' . $wpdb->esc_like($fimg_name) . '%');
				if (!empty($media_handle['media_settings']['title'])) {
					$image_title   = $media_handle['media_settings']['title'];
				}
				$get_id = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_name = %s LIMIT 1",
						$fil_name
					),
					ARRAY_A
				);
				if (!empty($get_id)) {
					$attach_id = $get_id[0]['ID'];
					$this->overwrite($attach_id, $img_url);
					if (!empty($data_array['featured_image'])) {
						set_post_thumbnail($post_id, $attach_id);
					}
					$this->fire_gallery_image_hook($post_id, $attach_id);
				} else {
					$attach_id = $this->image_function($img_url, $post_id, $data_array, '', '', $header_array, $value_array, [], $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
				}
				$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array,$featured, $media_type);
			} else {
				$attach_id = $this->image_function($img_url, $post_id, $data_array, '', '', $header_array, $value_array, [], $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
			}
		} else { // Use local url if available, leave the post as attachment free 

			$guid_url = $img_url;
			$attachment_id = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE guid = %s",
					$guid_url
				),
				ARRAY_A
			);

			if (!empty($attachment_id)) {

				foreach ($attachment_id as $value) {
					$attach_id = $value['ID'];
					if ($_wp_attachment_metadata = get_post_meta($attach_id, '_wp_attachment_metadata', true)) {
						// When an attachment is available on Media and not has attachment link
						if (!is_array($_wp_attachment_metadata)) {
							$attach_id = $this->image_function($img_url, $post_id, $data_array, '', '', $header_array, $value_array, [], $unikey, $image_metas, $line_number, $plugin, $import_type, $acf_wpname_element, $templatekey, $indexs, $acf_image_meta, $media_type, $media_id, $jet_child_object_id, $parent_object_id, $media_mode,$featured);
						}
					}
				}
			}
		}
		$attach_id = isset($attach_id) ? $attach_id : '';
		if (!empty($attach_id)) {
			$this->fire_gallery_image_hook($post_id, $attach_id);
		}
		return $attach_id;
	}

	public function mediaReport()
	{
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		global $wpdb;
		$list_of_images = $wpdb->get_results("select * from {$wpdb->prefix}sm_uci_addon_pro_media_report  ", ARRAY_A);

		if (!empty($list_of_images)) {
			foreach ($list_of_images as $list_key => $list_val) {
				if (!empty($list_val['hash_key'])) {
					$file_name = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT file_name FROM {$wpdb->prefix}smackcsv_file_events WHERE hash_key = %s",
							$list_val['hash_key']
						),
						ARRAY_A
					);
				}

				$filename[$list_key] = $file_name[0]['file_name'];
				$module[$list_key] = $list_val['module'];
				$success_count[$list_key] = $list_val['success_count'];
				$fail_count[$list_key] = $list_val['fail_count'];
				$image_type[$list_key] = $list_val['image_type'];
				$image_status[$list_key] = $list_val['status'];
			}
			$response['file_name'] = $filename;
			$response['module'] = $module;
			$response['success_count'] = $success_count;
			$response['fail_count'] = $fail_count;
			$response['image_type'] = $image_type;
			$response['status'] = $image_status;
		} else {
			$response['success_count'] = array();
		}
		echo wp_json_encode($response);
		wp_die();
	}

	public function getAuthor($post_author)
	{
		$helpers_instance = ImportHelpers::getInstance();
		if (isset($post_author)) {
			$user_records = $helpers_instance->get_from_user_details($post_author);
			$post_author = $user_records['user_id'];
		}
		return $post_author;
	}

	public function image_function($f_img, $post_id, $data_array = null, $option_name = null, $use_existing_image = false, $header_array = null, $value_array = null, $wpml_array = null, $unikey = null, $image_metas = null, $line_number = null, $plugin = null, $import_type = null, $acf_wpname_element = null, $hashkey = null, $indexs = null, $acf_image_meta = null, $media_type = null, $media_id = null, $jet_child_object_id = null, $parent_object_id = null, $media_mode = null,$featured = false)
	{
		global $wpdb;

		// File Extension Validation (strip query/fragment so CDN URLs like image.jpg?w=800 pass)
		$allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'pdf', 'mp4', 'mp3', 'zip', 'svg');
		$path_for_ext = parse_url($f_img, PHP_URL_PATH);
		$path_for_ext = is_string($path_for_ext) && $path_for_ext !== '' ? $path_for_ext : $f_img;
		$file_ext = strtolower(pathinfo($path_for_ext, PATHINFO_EXTENSION));
		if (!empty($file_ext) && !in_array($file_ext, $allowed_extensions, true)) {
			return null;
		}

		$user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36';
		if (isset($data_array['post_author'])) {
			$data_array['post_author'] = $this->getAuthor($data_array['post_author']);
		} else {
			if (!empty($data_array) && is_array($data_array)) {
				$data_array['post_author'] = "admin";
			} else {
				$data_array = array();
				$data_array['post_author'] = "admin";
			}
		}
		$media_handle = get_option('smack_image_options');
		$media_settings = [];
		if (!empty($header_array) && !empty($value_array)) {
			if (count($header_array) !== count($value_array)) {
				if (count($value_array) < count($header_array)) {
					$value_array = array_pad($value_array, count($header_array), '');
				} else {
					$value_array = array_slice($value_array, 0, count($header_array));
				}
			}
			$media_settings = array_combine($header_array, $value_array);
		} else {
			if (!empty($unikey) && !is_array($unikey)) {
				$get_array_value = get_option('smack_media_seo' . $unikey);
				if (!empty($get_array_value)) {
					$header_array = $get_array_value['header_array'];
            $value_array  = $get_array_value['value_array'];
					if (count($header_array) !== count($value_array)) {
						if (count($value_array) < count($header_array)) {
							$value_array = array_pad($value_array, count($header_array), '');
						} else {
							$value_array = array_slice($value_array, 0, count($header_array));
						}
					}
					$media_settings = array_combine($header_array, $value_array);
				}
			}
		}


		if (!empty($media_handle['media_settings']['alttext'])) {
			$alttext['_wp_attachment_image_alt'] = $media_handle['media_settings']['alttext'];
		}
		if (!empty($media_handle['postcontent_image_alt'])) {
			$alttext['_wp_postcontent_image_alt'] = $media_handle['postcontent_image_alt'];
		}

		if (preg_match_all('/\b(?:(?:https?|http|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $f_img, $matchedlist, PREG_PATTERN_ORDER)) {
			$f_img = trim($f_img);
		} else {
			$media_dir = wp_get_upload_dir();
			$names = glob($media_dir['path'] . '/' . '*.*');
			foreach ($names as $values) {
					if (!empty($f_img) && strpos($values, $f_img) !== false) {

					$local_file_name_setting = isset( $media_handle['media_settings']['file_name'] ) ? (string) $media_handle['media_settings']['file_name'] : '';
					if ( $local_file_name_setting !== '' && self::is_unresolved_media_seo_value( $local_file_name_setting ) ) {
						$local_file_name_setting = '';
					}
					if ( $local_file_name_setting !== '' ) {
						$file_type = wp_check_filetype($f_img, null);
						if (pathinfo($local_file_name_setting, PATHINFO_EXTENSION) !== $file_type['ext']) {
							$fimg_name = $local_file_name_setting . '.' . $file_type['ext'];
						} else {
							$fimg_name = $local_file_name_setting;
						}
						$f_img = $media_dir['url'] . '/' . $fimg_name;
					} else {
						$f_img = $media_dir['url'] . '/' . $f_img;
					}
				}
			}
		}
		$image_name = pathinfo($f_img);
		$file_name_setting = isset( $media_handle['media_settings']['file_name'] ) ? (string) $media_handle['media_settings']['file_name'] : '';
		// Skip unresolved mapping field keys (e.g. "featured_file_name") — using them as a
		// literal filename forces every product onto the same attachment via duplicate detection.
		if ( $file_name_setting !== '' && self::is_unresolved_media_seo_value( $file_name_setting ) ) {
			$file_name_setting = '';
		}
		if ($file_name_setting !== '' && ($featured || $media_type == 'External')) {
			$file_type = wp_check_filetype($f_img, null);
			$ext = !empty($file_type['ext']) ? '.' . $file_type['ext'] : '';

			if (isset($media_settings[$file_name_setting])) {
				$fimg_name = $media_settings[$file_name_setting] . $ext;
			} else {
				$fimg_name = str_replace(' ', '', $file_name_setting);
				$fimg_name .= $ext;
			}
		}
		 elseif (!empty($image_metas)) {
			$file_type = wp_check_filetype($f_img, null);
			$ext = '.' . $file_type['ext'];
			$fimg_name = $image_metas . $ext;
		} else {
			$fimg_name = $image_name['basename'];

			$fimg_name_without_ext = $image_name['filename'];
			if (empty($fimg_name_without_ext)) {
				$fimg_name_without_ext = $fimg_name;
			}
			// CDN catalogs frequently reuse the same basename (e.g. 1_org_zoom.jpg).
			// Prefix with a short hash of the full URL so each remote asset gets a distinct local file.
			if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' )
				&& \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::is_remote_url( $f_img )
				&& ! empty( $fimg_name )
			) {
				$path = (string) ( wp_parse_url( $f_img, PHP_URL_PATH ) ?: '' );
				$parent = $path !== '' ? basename( dirname( $path ) ) : '';
				$short  = substr( \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::url_hash( $f_img ), 0, 10 );
				$prefix = ( $parent !== '' && $parent !== '.' && $parent !== '/' )
					? sanitize_file_name( $parent )
					: $short;
				if ( $prefix !== '' && strpos( $fimg_name, $prefix ) !== 0 ) {
					$fimg_name = $prefix . '-' . $fimg_name;
				}
			}
		}

		$file_type = wp_check_filetype($fimg_name, null);
		if ($use_existing_image) {
			$existing_file_name_setting = isset( $media_handle['media_settings']['file_name'] ) ? (string) $media_handle['media_settings']['file_name'] : '';
			if ( $existing_file_name_setting !== '' && self::is_unresolved_media_seo_value( $existing_file_name_setting ) ) {
				$existing_file_name_setting = '';
			}
			if ($existing_file_name_setting !== '' && $media_type == 'External') {
				$image_file_name = $existing_file_name_setting;
				if (strpos($image_file_name, ' ') !== false) {
					$image_file_name = str_replace(' ', '-', $image_file_name);
					$image_file_name = preg_replace('/[^a-zA-Z0-9._\-]/', '', $image_file_name);
				}
				$attachment_id = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid LIKE %s",
						'%' . $wpdb->esc_like($image_file_name) . '%'
					)
				);
				if ($attachment_id != false) {
					$fimg_name = $image_file_name;
				} else {
					$fimg_name = $image_file_name;
				}
			} else {
				if (empty($file_type['ext']) && $existing_file_name_setting === '') {
					$fimg_name = @basename($f_img);
					$fimg_name = str_replace(' ', '-', trim($fimg_name));
					$fimg_name = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $fimg_name);
				}

				if (strstr($f_img, 'https://drive.google.com')) {
					preg_match('/[?&]id=([^&]+)/', $f_img, $matches);
					$fimg_name = isset($matches[1]) ? $matches[1] : basename($f_img);
				}
			}
			$f_img_check = str_replace(" ", "%20", $fimg_name);
			$attachment_id = null;
			$attachment_ids = array();

			$wp_content_url = content_url();
			if ((!empty($media_mode) || $media_mode == 'MediaUpdate')) {
				$attachment_ids = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_title != 'image-failed' AND guid LIKE %s",
						'%' . $wpdb->esc_like($f_img_check) . '%'
					),
					ARRAY_A
				);
				// For remote sources with shared CDN basenames, only keep URL-identity matches.
				if ( ! empty( $attachment_ids ) && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' )
					&& \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::is_remote_url( $f_img ) ) {
					$filtered = array();
					foreach ( $attachment_ids as $row ) {
						$cid = isset( $row['ID'] ) ? (int) $row['ID'] : 0;
						if ( $cid && \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::attachment_matches_source( $cid, $f_img ) ) {
							$filtered[] = array( 'ID' => $cid );
							break;
						}
					}
					$attachment_ids = $filtered;
				}
				if (!empty($attachment_ids[0]['ID'])) {
					$_attach_post   = get_post($attachment_ids[0]['ID']);
					$_target_dir    = wp_upload_dir();
					$_target_dir    = isset($_target_dir['path']) ? $_target_dir['path'] : '';
					$_filtered_post = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_get_image_from_gallery_filter($_attach_post, $fimg_name, $_target_dir);
					if ($_filtered_post instanceof \WP_Post && !empty($_filtered_post->ID)) {
						$attachment_ids[0]['ID'] = $_filtered_post->ID;
					}
					return $attachment_ids[0]['ID'];
				}
			} else if (strpos($f_img, $wp_content_url) !== FALSE) {
				$attachment_ids = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid = %s",
						$f_img
					),
					ARRAY_A
				);
			} else {
				// Remote / external URL: identity by source URL hash / exact GUID only.
				// Never guid LIKE '%1_org_zoom.jpg%' — CDN catalogs reuse that basename.
				if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' ) ) {
					$existing_remote = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::find_existing( $f_img, $fimg_name );
					if ( $existing_remote > 0 ) {
						$attachment_ids = array( array( 'ID' => $existing_remote ) );
					}
				} else {
					$attachment_ids = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid = %s AND post_title != 'image-failed'",
							$f_img
						),
						ARRAY_A
					);
				}
			}
			// Apply sm_uci_pro_get_image_from_gallery filter before processing
			if (!empty($attachment_ids[0]['ID'])) {
				$_attach_post   = get_post($attachment_ids[0]['ID']);
				$_target_dir    = wp_upload_dir();
				$_target_dir    = isset($_target_dir['path']) ? $_target_dir['path'] : '';
				$_filtered_post = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_get_image_from_gallery_filter($_attach_post, $fimg_name, $_target_dir);
				if ($_filtered_post instanceof \WP_Post && !empty($_filtered_post->ID)) {
					$attachment_ids[0]['ID'] = $_filtered_post->ID;
				}
			}

			if (!empty($attachment_ids[0]['ID'])) {
				if (($media_type == 'Local' || $media_type == 'External') && empty($media_id) && empty($post_id)) {
					return $attachment_ids[0]['ID'];
				} else if ($plugin == 'Featured') {
					return $attachment_ids[0]['ID'];
				} else if (empty($media_id) && empty($media_type)) {
					$attach_id = $attachment_ids[0]['ID'];
					$table_name = $wpdb->prefix . 'smackcsv_file_events';
					$post_title = $wpdb->get_var(
						$wpdb->prepare(
							"SELECT post_title FROM {$wpdb->posts} WHERE ID = %d AND post_status != 'trash'",
							$post_id
						)
					);
					$file_name = $wpdb->get_var(
						$wpdb->prepare(
							"SELECT file_name FROM {$table_name} WHERE hash_key = %s",
							$hashkey
						)
					);
					$shortcode_table = $wpdb->prefix . "ultimate_csv_importer_shortcode_manager";
					$check_id = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT ID FROM {$wpdb->posts} WHERE ID = %d AND post_title = 'image-failed' AND post_type = 'attachment' AND guid LIKE %s",
							$attach_id,
							'%' . $wpdb->esc_like($f_img_check) . '%'
						),
						ARRAY_A
					);
					if (!empty($check_id)) {
						$failed_ids = $wpdb->get_results(
							$wpdb->prepare(
								"SELECT * FROM {$wpdb->prefix}ultimate_csv_importer_shortcode_manager WHERE post_id = %d AND media_id = %d",
								$post_id,
								$attach_id
							)
						);
						if (!empty($failed_ids) && $failed_ids[0]->post_id != $post_id) {
							$attach_id = $check_id[0]['ID'];
							$insert_status = $wpdb->insert(
								$shortcode_table,
								array('post_id' => $post_id, 'post_title' => $post_title, 'image_shortcode' => $plugin . '_image__' . $acf_wpname_element, 'media_id' => $attach_id, 'original_image' => $f_img, 'indexs' => $indexs, 'image_meta' => $acf_image_meta, 'hash_key' => $hashkey, 'import_type' => $import_type, 'file_name' => $file_name, 'jet_child_object_id' => $jet_child_object_id, 'jet_parent_object_id' => $parent_object_id),
								array('%d', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
							);
							if ($insert_status) {
								$this->store_failed_image_ids($attach_id);
								$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $f_img);
							}
						} elseif (!empty($post_id) && !empty($failed_ids) && ($failed_ids[0]->post_id == $post_id) && ($check_id[0]['ID'] == $failed_ids[0]->media_id)) {
							$attach_id = $check_id[0]['ID'];
							$insert_status = $wpdb->insert(
								$shortcode_table,
								array('post_id' => $post_id, 'post_title' => $post_title, 'image_shortcode' => $plugin . '_image__' . $acf_wpname_element, 'media_id' => $attach_id, 'original_image' => $f_img, 'indexs' => $indexs, 'image_meta' => $acf_image_meta, 'hash_key' => $hashkey, 'import_type' => $import_type, 'file_name' => $file_name, 'jet_child_object_id' => $jet_child_object_id, 'jet_parent_object_id' => $parent_object_id),
								array('%d', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
							);
							if ($insert_status) {
								$this->store_failed_image_ids($attach_id);
								$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $f_img);
							}
						} elseif (empty($failed_ids)) {
							$insert_status = $wpdb->insert(
								$shortcode_table,
								array('post_id' => $post_id, 'post_title' => $post_title, 'image_shortcode' => $plugin . '_image__' . $acf_wpname_element, 'media_id' => $attach_id, 'original_image' => $f_img, 'indexs' => $indexs, 'image_meta' => $acf_image_meta, 'hash_key' => $hashkey, 'import_type' => $import_type, 'file_name' => $file_name, 'jet_child_object_id' => $jet_child_object_id, 'jet_parent_object_id' => $parent_object_id),
								array('%d', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
							);
							if ($insert_status) {
								$this->store_failed_image_ids($attach_id);
								$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $f_img);
							}
						}
					}
					return $attach_id;
				}
			}

			if (is_array($attachment_ids) && !empty($attachment_ids))
				$attachment_id = $attachment_ids[0]['ID'];

			if (strpos($f_img, 'loading-image.jpg') !== FALSE) {
			} else {
				$this->imageMetaImport($attachment_id, $media_handle, $header_array, $value_array,$featured, $media_type);
			}
			if ($attachment_id) {
				if (!empty($data_array['featured_image'])) {
					set_post_thumbnail($post_id, $attachment_id);
					return $attachment_id;
				} else {

					if (!empty($wpml_array['language_code'])) {
						$lang_code = $wpml_array['language_code'];
						$image_trid_id = $wpdb->get_var(
							$wpdb->prepare(
								"SELECT trid FROM {$wpdb->prefix}icl_translations WHERE element_type = 'post_attachment' AND element_id = %d",
								$attachment_id
							)
						);
						$image_lang_id = $wpdb->get_var(
							$wpdb->prepare(
								"SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE element_type = 'post_attachment' AND trid = %d AND language_code = %s",
								$image_trid_id,
								$lang_code
							)
						);
						return $image_lang_id;
					} else {
						return $attachment_id;
					}
				}
			}
		}

		$attachment_title = sanitize_file_name(pathinfo($fimg_name, PATHINFO_FILENAME));

		// Advanced Media Download Engine: duplicate detection before HTTP fetch.
		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' ) ) {
			$dup_attach_id = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::resolve( $f_img, $fimg_name );
			if ( 0 === $dup_attach_id ) {
				return null;
			}
			if ( $dup_attach_id > 0 ) {
				\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::stamp_source_url( $dup_attach_id, $f_img );
				if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper' ) ) {
					\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper::apply(
						$dup_attach_id,
						\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper::from_row_data( is_array( $data_array ) ? $data_array : array(), $featured )
					);
				}
				if ( ! empty( $data_array['featured_image'] ) ) {
					set_post_thumbnail( $post_id, $dup_attach_id );
				}
				$this->fire_gallery_image_hook( $post_id, $dup_attach_id );
				return $dup_attach_id;
			}
		}

		$file_type = wp_check_filetype($fimg_name, null);
		$dir = wp_upload_dir();
		$dirname = date('Y') . '/' . date('m');
		$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
		if ($uploads_use_yearmonth == 1) {
			$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
			$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
		} else {

			$parsed_url = parse_url($f_img, PHP_URL_PATH);

			// Match /uploads/YYYY/MM/ dynamically
			if (preg_match('#/uploads/(\d{4}/\d{2})/#', $parsed_url, $matches)) {
				$dirname = $matches[1];
			} else {
				$dirname = date('Y') . '/' . date('m');
			}
			$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
			$uploaddir_url = $dir['baseurl'] . '/' . $dirname;

		}

		$uploads_init = array(
			'path'    => $uploaddir_paths,
			'url'     => $uploaddir_url,
			'subdir'  => '/' . $dirname,
			'basedir' => $dir['basedir'],
			'baseurl' => $dir['baseurl'],
			'error'   => false
		);

		$current_node = (!empty($header_array) && !empty($value_array) && count($header_array) === count($value_array)) ? array_combine($header_array, $value_array) : array();
		$filtered_uploads = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_attachments_uploads_dir_filter($uploads_init, $data_array, $current_node, $unikey);

		if (is_array($filtered_uploads)) {
			$uploaddir_paths = isset($filtered_uploads['path']) ? $filtered_uploads['path'] : $uploaddir_paths;
			$uploaddir_url   = isset($filtered_uploads['url']) ? $filtered_uploads['url'] : $uploaddir_url;
		}

		$f_img = str_replace(" ", "%20", $f_img);
		$late_file_name_setting = isset( $media_handle['media_settings']['file_name'] ) ? (string) $media_handle['media_settings']['file_name'] : '';
		if ( $late_file_name_setting !== '' && self::is_unresolved_media_seo_value( $late_file_name_setting ) ) {
			$late_file_name_setting = '';
		}
		if ( $late_file_name_setting !== '' ) {
			$file_type = wp_check_filetype($f_img, null);
			if (empty($file_type['ext'])) {
				$file_type['ext'] = 'jpeg';
			}
			$ext = '.' . $file_type['ext'];
			if ($featured || $media_type == 'External') {
				if (strrpos($late_file_name_setting, '.')) {
					$fimg_name = $late_file_name_setting;
				} else {
					$fimg_name = $late_file_name_setting . $ext;
				}
			}
		} else if (empty($file_type['ext'])) {
			if (strstr($f_img, 'https://drive.google.com')) {
				preg_match('/[?&]id=([^&]+)/', $f_img, $matches);
				$fimg_name = isset($matches[1]) ? $matches[1] : basename($f_img);
			} else {
				$fimg_name = @basename($f_img);
				$fimg_name = str_replace(' ', '-', trim($fimg_name));
				$fimg_name = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $fimg_name);
			}
		}
		if ($uploaddir_paths != "" && $uploaddir_paths) {
			if (strpos($fimg_name, ' ') !== false) {
				$fimg_name = str_replace(' ', '-', $fimg_name);
				$fimg_name = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $fimg_name);
			}
			$uploaddir_path = $uploaddir_paths . "/" . $fimg_name;
		}

		// Apply image filename filters
		if ($featured) {
			$_img_title     = isset($data_array['featured_image_title'])     ? $data_array['featured_image_title']     : (isset($media_handle['media_settings']['title']) ? $media_handle['media_settings']['title'] : '');
			$_img_caption   = isset($data_array['featured_image_caption'])   ? $data_array['featured_image_caption']   : (isset($media_handle['media_settings']['caption']) ? $media_handle['media_settings']['caption'] : '');
			$_img_alt       = isset($data_array['featured_image_alt_text'])  ? $data_array['featured_image_alt_text']  : (isset($media_handle['media_settings']['alt']) ? $media_handle['media_settings']['alt'] : '');
			$_img_file_name = isset($data_array['featured_file_name']) && !empty($data_array['featured_file_name']) ? $data_array['featured_file_name'] : $fimg_name;
			if ( self::is_unresolved_media_seo_value( $_img_title ) ) {
				$_img_title = '';
			}
			if ( self::is_unresolved_media_seo_value( $_img_caption ) ) {
				$_img_caption = '';
			}
			if ( self::is_unresolved_media_seo_value( $_img_alt ) ) {
				$_img_alt = '';
			}
			if ( self::is_unresolved_media_seo_value( $_img_file_name ) ) {
				$_img_file_name = $fimg_name;
			}

			$_filtered_filename = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_image_filename_filter(
				$_img_file_name, $_img_title, $_img_caption, $_img_alt, $data_array, $unikey, $f_img
			);
		} else {
			$_filtered_filename = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_api_image_filename_filter(
				$fimg_name, $f_img, $post_id
			);
		}

		if (!empty($_filtered_filename) && is_string($_filtered_filename)) {
			$fimg_name      = sanitize_file_name($_filtered_filename);
			$uploaddir_path = $uploaddir_paths . '/' . $fimg_name;
		}

		$http_code = 200;
		$engine_processor = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadProcessor' )
			? \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDownloadProcessor::getInstance()
			: null;
		if (strstr($f_img, 'https://drive.google.com')) {

			$response = null;
			if (strstr($f_img, 'https://drive.google.com/uc?export=download&id')) {
				$rawdata = file_get_contents($f_img);
			} else if (strpos($f_img, 'https://drive.google.com/file/d/') !== false) {
				// Extract the file ID using string functions
				$file_id_start = strpos($f_img, '/d/') + 3; // Find position after '/d/'
				$file_id_end = strpos($f_img, '/view', $file_id_start); // Find position of '/view'
				$file_id = substr($f_img, $file_id_start, $file_id_end - $file_id_start);
				$f_img = "https://drive.google.com/uc?export=download&id=$file_id";
				//$response = wp_remote_get($f_img);
				$response = wp_remote_get($f_img, array('timeout' => 30));
				$rawdata = wp_remote_retrieve_body($response);
			} else {
				$page_content = file_get_contents($f_img);
				if (empty($page_content)) {
					preg_match('~/d/\K[^/]+(?=/)~', $f_img, $result_id);
					$image_link_id = isset($result_id[0]) ? $result_id[0] : $f_img;
					$rawdata = file_get_contents(html_entity_decode('https://drive.google.com/uc?export=download&id=' . $image_link_id));
				} else {

					$dom_obj = new \DOMDocument();
					$dom_obj->loadHTML($page_content);
					$meta_val = null;
					foreach ($dom_obj->getElementsByTagName('meta') as $meta) {
						if ($meta->getAttribute('property') == 'og:image') {
							$meta_val = $meta->getAttribute('content');
						}
					}
					$ch = curl_init($meta_val);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
					$rawdata = curl_exec($ch);

					// if(empty($rawdata)){
					// 	preg_match('~/d/\K[^/]+(?=/)~', $f_img, $result_id);
					// 	$image_link_id = isset($result_id[0]) ? $result_id[0] : $f_img;	
					// 	$image_link = 'https://drive.google.com/uc?export=download&id=' . $image_link_id;
					// 	$rawdata = file_get_contents($image_link);	
					// }
				}
			}
		} elseif (isset($media_dir['url']) && strstr($f_img, $media_dir['url'])) {
			if ($plugin == 'Media' && !empty($media_id)) { // write update media
				$attach_id = $media_id;
				$post_info = array('ID' => $attach_id, 'post_title' => $attachment_title);
				wp_update_post($post_info);
				$new_guid = $uploaddir_url . '/' . $fimg_name;
				$wpdb->update($wpdb->posts, array('guid' => $new_guid), array('ID' => $attach_id), array('%s'), array('%d'));
				update_attached_file($attach_id, $uploaddir_path);
				$attach_data = wp_generate_attachment_metadata($attach_id, $uploaddir_path);
				wp_update_attachment_metadata($attach_id, $attach_data);
			} else {
				$post_info = array(
					'guid' => $uploaddir_url . "/" . $fimg_name,
					'post_mime_type' => $file_type['type'],
					'post_title' => $attachment_title,
					'post_content' => '',
					'post_status' => 'inherit',
					'post_author' => $data_array['post_author']
				);
				$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);
				$attach_data = wp_generate_attachment_metadata($attach_id, $uploaddir_path);
				wp_update_attachment_metadata($attach_id, $attach_data);
				$this->fire_attachment_uploaded_hook($post_id, $attach_id);
				$this->fire_gallery_image_hook($post_id, $attach_id);
			}
			if (!empty($data_array['featured_image'])) {
				set_post_thumbnail($post_id, $attach_id);
			}

			if (strpos($f_img, 'loading-image.jpg') !== FALSE) {
			} else {
				$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array, $featured, $media_type);
			}
			return $attach_id;
		} else if (strstr($f_img, 'https://www.dropbox.com/')) {
			$page_content = file_get_contents($f_img);
			$dom_obj = new \DOMDocument();
			$dom_obj->loadHTML($page_content);
			$meta_val = null;
			foreach ($dom_obj->getElementsByTagName('meta') as $meta) {
				if ($meta->getAttribute('property') == 'og:image') {
					$meta_val = $meta->getAttribute('content');
				}
			}
			usleep(500000); // Throttling: 0.5s delay
			$response = wp_remote_get($meta_val, array('user-agent' => $user_agent));
			$rawdata = wp_remote_retrieve_body($response);
			$http_code = (int) wp_remote_retrieve_response_code($response);
		} else {
			usleep(500000); // Throttling: 0.5s delay
			$response  = null;
			$rawdata   = '';
			$http_code = 0;

			if ( $engine_processor && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaQueueManager' ) ) {
				$deferred = $engine_processor->maybe_defer_download(
					$hashkey,
					array(
						'url'               => $f_img,
						'post_id'           => $post_id,
						'data_array'        => $data_array,
						'plugin'            => $plugin,
						'import_type'       => $import_type,
						'acf_wpname_element' => $acf_wpname_element,
						'header_array'      => $header_array,
						'value_array'       => $value_array,
						'line_number'       => $line_number,
						'indexs'            => $indexs,
						'acf_image_meta'    => $acf_image_meta,
						'media_type'        => $media_type,
						'media_id'          => $media_id,
						'featured'          => $featured,
						'metadata'          => class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper' )
							? \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper::from_row_data( is_array( $data_array ) ? $data_array : array(), $featured )
							: array(),
					)
				);
				if ( $deferred ) {
					return null;
				}
			}

			if ( $engine_processor ) {
				$fetch = $engine_processor->fetch_remote( $f_img, $file_type['ext'] ?? '' );
				if ( null === $fetch ) {
					return null;
				}
				$rawdata   = $fetch['body'];
				$http_code = (int) $fetch['code'];
			} else {
				usleep( 300000 );
				$settings = self::get_download_settings( $file_type['ext'] ?? '' );
				$fetched  = self::fetch_remote_image(
					$f_img,
					$user_agent,
					$settings['download_timeout'],
					$line_number,
					$settings['connection_timeout'],
					$file_type['ext'] ?? ''
				);
				if ( is_wp_error( $fetched ) ) {
					return null;
				}
				$rawdata   = $fetched['body'];
				$http_code = $fetched['code'];
				$response  = $fetched['response'];
			}
		}
		if ( isset( $response ) && is_wp_error( $response ) && ( ! isset( $rawdata ) || $rawdata === '' ) ) {
			return null;
		}
		$rawdata = isset( $rawdata ) ? $rawdata : '';
		if ( is_string( $rawdata ) && strpos( $rawdata, '<img src=' ) !== false ) {
			$raw_file = explode('<img src', $rawdata);
			$urls = rtrim(end($raw_file), '>');
			$urls = ltrim($urls, '=');
			$urls = str_replace(' ', '', $urls);
			usleep(300000);
			$settings = self::get_download_settings( $file_type['ext'] ?? '' );
			$fetched  = self::fetch_remote_image(
				$urls,
				$user_agent,
				$settings['download_timeout'],
				$line_number,
				$settings['connection_timeout'],
				$file_type['ext'] ?? ''
			);
			if ( is_wp_error( $fetched ) ) {
				return null;
			}
			$rawdata   = $fetched['body'];
			$http_code = $fetched['code'];
			$response  = $fetched['response'];
		}
		$valid_body = self::validate_remote_download( $rawdata, isset( $file_type['ext'] ) ? (string) $file_type['ext'] : '' );
		if ( is_wp_error( $valid_body ) ) {
			if ( isset( $engine_processor ) && $engine_processor ) {
				$engine_processor->record_http_failure( $f_img, $valid_body->get_error_message(), $post_id, (int) $line_number, (string) $hashkey );
			}
			return null;
		}
		if ($http_code == 404 || $http_code == 403 || $http_code == 500 || $http_code == 401 || $http_code == 408 || $http_code == 502 || $http_code == 503 || $http_code == 504) {
			if ( isset( $engine_processor ) && $engine_processor ) {
				$engine_processor->record_http_failure( $f_img, 'HTTP ' . $http_code, $post_id, (int) $line_number, (string) $hashkey );
			}
			return null;
		}
		if ($http_code != 200 && strpos($rawdata, 'Not Found') != 0) {
			if ( isset( $engine_processor ) && $engine_processor ) {
				$engine_processor->record_http_failure( $f_img, 'HTTP ' . $http_code, $post_id, (int) $line_number, (string) $hashkey );
			}
			return null;
		}


		if ($rawdata == false) {
			return null;
		} else {
			if ($plugin == 'Media' && !empty($media_id)) {
				$old_file_path = get_attached_file($media_id);
				if (file_exists($old_file_path)) {
					unlink($old_file_path);
				}
			} else {
				if (file_exists($uploaddir_path)) {
					$i = 1;
					$exist = true;
					while ($exist) {
						$fimg_name = $attachment_title . "-" . $i . "." . $file_type['ext'];
						$uploaddir_path = $uploaddir_paths . "/" . $fimg_name;

						if (file_exists($uploaddir_path)) {
							$i = $i + 1;
						} else {
							$exist = false;
						}
					}
				}
			}

			$directory_path = dirname($uploaddir_path);

			// Check if directory exists
			if (!file_exists($directory_path)) {
				// Create the directory (recursive)
				if (mkdir($directory_path, 0755, true)) {
					//   echo "Directory created: " . $directory_path;
				} else {
					//   echo "Failed to create directory: " . $directory_path;
				}
			} else {
				//   echo "Directory already exists: " . $directory_path;
			}
			$fp = fopen($uploaddir_path, 'x');
			if ($fp !== false) {
				fwrite($fp, $rawdata);
				fclose($fp);
			} else {
				return null;
			}
		}

		if (empty($file_type['type'])) {
			$file_type['type'] = 'image/jpeg';
		}

		// Apply sm_uci_pro_handle_upload filter
		$_upload_file = array(
			'file' => $uploaddir_path,
			'url'  => $uploaddir_url . '/' . $fimg_name,
			'type' => $file_type['type'],
		);
		$_upload_file = \Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importFilters()->apply_handle_upload_filter($_upload_file);
		if (is_array($_upload_file)) {
			$uploaddir_path  = isset($_upload_file['file']) ? $_upload_file['file'] : $uploaddir_path;
			$_filtered_url   = isset($_upload_file['url'])  ? $_upload_file['url']  : ($uploaddir_url . '/' . $fimg_name);
			$fimg_name       = basename($uploaddir_path);
			$uploaddir_url   = dirname($_filtered_url);
			$file_type['type'] = isset($_upload_file['type']) ? $_upload_file['type'] : $file_type['type'];
		}

		if ($plugin == 'Media' && !empty($media_id)) {
			$attach_id = $media_id;
			$post_info = array('ID' => $attach_id, 'post_title' => $attachment_title);
			wp_update_post($post_info);
			$new_guid = $uploaddir_url . '/' . $fimg_name;
			$wpdb->update($wpdb->posts, array('guid' => $new_guid), array('ID' => $attach_id), array('%s'), array('%d'));
			update_attached_file($attach_id, $uploaddir_path);
			$attach_data = wp_generate_attachment_metadata($attach_id, $uploaddir_path);
			wp_update_attachment_metadata($attach_id, $attach_data);
			$this->fire_gallery_image_hook($post_id, $attach_id);
		} else {
			$post_info = array(
				'guid' => $uploaddir_url . "/" . $fimg_name,
				'post_mime_type' => $file_type['type'],
				'post_title' => $attachment_title,
				'post_content' => '',
				'post_status' => 'inherit',
				'post_author' => $data_array['post_author']
			);
			$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);
			if ( is_wp_error( $attach_id ) || empty( $attach_id ) ) {
				return null;
			}
			$attach_data = wp_generate_attachment_metadata($attach_id, $uploaddir_path);
			wp_update_attachment_metadata($attach_id, $attach_data);
			$this->fire_attachment_uploaded_hook($post_id, $attach_id);
			$this->fire_gallery_image_hook($post_id, $attach_id);
			if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector' ) ) {
				\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaDuplicateDetector::stamp_source_url( $attach_id, $f_img );
			}
			if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper' ) ) {
				\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper::apply(
					$attach_id,
					\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaMetadataMapper::from_row_data( is_array( $data_array ) ? $data_array : array(), $featured )
				);
			}
		}

		//added..
		if (strstr($f_img, 'https://drive.google.com')) {
			$finfo = finfo_open(FILEINFO_MIME_TYPE);
			$mime = finfo_file($finfo, $uploaddir_path);

			if ($mime == 'image/jpeg') {
				$extension = 'jpg';
			} elseif ($mime == 'image/png') {
				$extension = 'png';
			} else {
				$explode_ext = explode('/', $mime);
				$extension = $explode_ext[1];
			}
			$image_file_path = get_attached_file($attach_id);
			if ($image_file_path) {
				$extension_exists = '.' . $extension;
				if (strpos($image_file_path, $extension_exists) !== false) {
				} else {
					if (substr($image_file_path, -1) == '.') {
						$new_image_file_path = $image_file_path . $extension;
					} else {
						$new_image_file_path = $image_file_path . '.' . $extension;
					}

					rename($image_file_path, $new_image_file_path);
					update_attached_file($attach_id, $new_image_file_path);
				}
			}
		}
		if (strpos($f_img, 'loading-image.jpg') !== FALSE) {
		} else {
			$this->imageMetaImport($attach_id, $media_handle, $header_array, $value_array, $featured, $media_type);
		}

		if (!empty($data_array['featured_image'])) {
			set_post_thumbnail($post_id, $attach_id);
		}

		if (!empty($wpml_array['language_code']) && empty($media_id)) {
			$lang_code = $wpml_array['language_code'];
			$image_trid_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT trid FROM {$wpdb->prefix}icl_translations WHERE element_type = 'post_attachment' AND element_id = %d",
					$attach_id
				)
			);

			$image_lang_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE element_type = 'post_attachment' AND trid = %d AND language_code = %s",
					$image_trid_id,
					$lang_code
				)
			);
			return $image_lang_id;
		} else {
			return $attach_id;
		}
	}

	public function imageMetaImport($attach_id, $media_handle, $header_array = null, $value_array = null, $featured = false, $media_type = null)
	{
		$media_handle = get_option('smack_image_options');
		if ($attach_id && ($featured || $media_type == 'Local' || $media_type == 'External')) {
			if (!empty($media_handle['media_settings']['media_handle_option'])) {
				$ms = isset( $media_handle['media_settings'] ) && is_array( $media_handle['media_settings'] ) ? $media_handle['media_settings'] : array();

				$alt_raw = isset( $ms['alttext'] ) ? (string) $ms['alttext'] : '';
				if ( $alt_raw !== '' && ! self::is_unresolved_media_seo_value( $alt_raw ) ) {
					$alttext['_wp_attachment_image_alt'] = $alt_raw;
				}
				if (isset($media_handle['postcontent_image_alt'])) {
					$alttext['_wp_postcontent_image_alt'] = $media_handle['postcontent_image_alt'];
				}

				$caption_raw     = isset( $ms['caption'] ) ? (string) $ms['caption'] : '';
				$description_raw = isset( $ms['description'] ) ? (string) $ms['description'] : '';
				$title_raw       = isset( $ms['title'] ) ? (string) $ms['title'] : '';

				$post_update = array( 'ID' => $attach_id );
				$changed     = false;
				if ( $description_raw !== '' && ! self::is_unresolved_media_seo_value( $description_raw ) ) {
					$post_update['post_content'] = $description_raw;
					$changed = true;
				}
				if ( $caption_raw !== '' && ! self::is_unresolved_media_seo_value( $caption_raw ) ) {
					$post_update['post_excerpt'] = $caption_raw;
					$changed = true;
				}
				if ( $title_raw !== '' && ! self::is_unresolved_media_seo_value( $title_raw ) ) {
					$post_update['post_title'] = $title_raw;
					$changed = true;
				}
				if ( $changed ) {
					wp_update_post( $post_update );
				}

				if ($attach_id != null && isset($alttext['_wp_attachment_image_alt'])) {
					update_post_meta($attach_id, '_wp_attachment_image_alt', $alttext['_wp_attachment_image_alt']);
				}

				if ($attach_id != null && isset($alttext['_wp_postcontent_image_alt'])) {
					update_post_meta($attach_id, '_wp_attachment_image_alt', $alttext['_wp_postcontent_image_alt']);
				}
			}
		}

	}

	public function acfgalleryMetaImports($attach_id, $media_handle, $plugin)
	{
		if (is_array($attach_id)) {

			foreach ($attach_id as $attachid => $attachvalid) {
				if (isset($media_handle[$plugin . '_gallery_caption'][$attachid]) || isset($media_handle[$plugin . '_gallery_description'][$attachid])) {
					wp_update_post(array(
						'ID' => $attachvalid,
						'post_content' => $media_handle[$plugin . '_gallery_description'][$attachid],
						'post_excerpt' => $media_handle[$plugin . '_gallery_caption'][$attachid]
					));
				}
				if (isset($media_handle[$plugin . '_gallery_title'][$attachid])) {
					wp_update_post(array(
						'ID' => $attachvalid,
						'post_title' => $media_handle[$plugin . '_gallery_title'][$attachid]
					));
				}
				if ($attachvalid != null && isset($media_handle[$plugin . '_gallery_file_name'][$attachid])) {
					global $wpdb;
					$guid = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT guid FROM {$wpdb->posts} WHERE ID = %d",
							$attachvalid
						),
						ARRAY_A
					);
					$dirname = date('Y') . '/' . date('m');
					$file_type = wp_check_filetype($guid[0]['guid'], null);
					$ext = '.' . $file_type['ext'];
					$dir = wp_upload_dir();

					// $uploaddir_paths = $dir ['basedir'] . '/' . $dirname ;
					// $uploaddir_url = $dir ['baseurl'] . '/' . $dirname;
					$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
					if ($uploads_use_yearmonth == 1) {

						$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
						$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
					} else {

						$uploaddir_paths = $dir['basedir'];
						$uploaddir_url = $dir['baseurl'];
					}
					$guids = $uploaddir_url . '/' . $media_handle[$plugin . '_gallery_file_name'][$attachid] . $ext;
					$wpdb->update($wpdb->posts, ['guid' => $guids], ['ID' => $attachvalid]);
					$fimg_name = $dirname . '/' . $media_handle[$plugin . '_gallery_file_name'][$attachid] . $ext;
					update_post_meta($attachvalid, '_wp_attached_file', $fimg_name);
				}
				if ($attachvalid != null && isset($media_handle[$plugin . '_gallery_alt_text'][$attachid])) {
					update_post_meta($attachvalid, '_wp_attachment_image_alt', $media_handle[$plugin . '_gallery_alt_text'][$attachid]);
				}
			}
		} else {

			if (isset($media_handle[$plugin . '_gallery_caption'][0]) || isset($media_handle[$plugin . '_gallery_description'][0])) {
				wp_update_post(array(
					'ID' => $attach_id,
					'post_content' => $media_handle[$plugin . '_gallery_description'][0],
					'post_excerpt' => $media_handle[$plugin . '_gallery_caption'][0]
				));
			}
			if (isset($media_handle[$plugin . '_title'][0])) {
				wp_update_post(array(
					'ID' => $attach_id,
					'post_title' => $media_handle[$plugin . '_gallery_title'][0]
				));
			}
			if ($attach_id != null && isset($media_handle[$plugin . '_gallery_file_name'][0])) {
				global $wpdb;
				$guid = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT guid FROM {$wpdb->posts} WHERE ID = %d",
						$attach_id
					),
					ARRAY_A
				);
				$dirname = date('Y') . '/' . date('m');
				$file_type = wp_check_filetype($guid[0]['guid'], null);
				$ext = '.' . $file_type['ext'];
				$dir = wp_upload_dir();

				// $uploaddir_paths = $dir ['basedir'] . '/' . $dirname ;
				// $uploaddir_url = $dir ['baseurl'] . '/' . $dirname;
				$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
				if ($uploads_use_yearmonth == 1) {

					$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
					$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
				} else {

					$uploaddir_paths = $dir['basedir'];
					$uploaddir_url = $dir['baseurl'];
				}
				$guids = $uploaddir_url . '/' . $media_handle[$plugin . '_gallery_file_name'][0] . $ext;
				$wpdb->update($wpdb->posts, ['guid' => $guids], ['ID' => $attach_id]);
				$fimg_name = $dirname . '/' . $media_handle[$plugin . '_gallery_file_name'][0] . $ext;
				update_post_meta($attach_id, '_wp_attached_file', $fimg_name);
			}
			if ($attach_id != null && isset($media_handle[$plugin . '_gallery_alt_text'][0])) {
				update_post_meta($attach_id, '_wp_attachment_image_alt', $media_handle[$plugin . '_gallery_alt_text'][0]);
			}
		}
	}

	public function acfimageMetaImports($attach_id, $media_handle, $plugin)
	{
		if (is_array($attach_id)) {
			foreach ($attach_id as $attachid => $attachvalid) {
				if (isset($media_handle[$plugin . '_caption'][$attachid]) || isset($media_handle[$plugin . '_description'][$attachid])) {
					wp_update_post(array(
						'ID' => $attachvalid,
						'post_content' => $media_handle[$plugin . '_description'][$attachid],
						'post_excerpt' => $media_handle[$plugin . '_caption'][$attachid]
					));
				}
				if (isset($media_handle[$plugin . '_title'][$attachid])) {
					wp_update_post(array(
						'ID' => $attachvalid,
						'post_title' => $media_handle[$plugin . '_title'][$attachid]
					));
				}
				if ($attachvalid != null && isset($media_handle[$plugin . '_file_name'][$attachid])) {
					global $wpdb;
					$guid = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT guid FROM {$wpdb->posts} WHERE ID = %d",
							$attachvalid
						),
						ARRAY_A
					);
					$dirname = date('Y') . '/' . date('m');
					$file_type = wp_check_filetype($guid[0]['guid'], null);
					$ext = '.' . $file_type['ext'];
					$dir = wp_upload_dir();

					// $uploaddir_paths = $dir ['basedir'] . '/' . $dirname ;
					// $uploaddir_url = $dir ['baseurl'] . '/' . $dirname;
					$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
					if ($uploads_use_yearmonth == 1) {

						$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
						$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
					} else {

						$uploaddir_paths = $dir['basedir'];
						$uploaddir_url = $dir['baseurl'];
					}
					$guids = $uploaddir_url . '/' . $media_handle[$plugin . '_file_name'][$attachid] . $ext;
					$wpdb->update($wpdb->posts, ['guid' => $guids], ['ID' => $attachvalid]);
					$fimg_name = $dirname . '/' . $media_handle[$plugin . '_file_name'][$attachid] . $ext;
					update_post_meta($attachvalid, '_wp_attached_file', $fimg_name);
				}
				if ($attachvalid != null && isset($media_handle[$plugin . '_alt_text'][$attachid])) {
					update_post_meta($attachvalid, '_wp_attachment_image_alt', $media_handle[$plugin . '_alt_text'][$attachid]);
				}
			}
		} else {

			if (isset($media_handle[$plugin . '_caption'][0]) || isset($media_handle[$plugin . '_description'][0])) {
				wp_update_post(array(
					'ID' => $attach_id,
					'post_content' => $media_handle[$plugin . '_description'][0],
					'post_excerpt' => $media_handle[$plugin . '_caption'][0]
				));
			}
			if (isset($media_handle[$plugin . '_title'][0])) {
				wp_update_post(array(
					'ID' => $attach_id,
					'post_title' => $media_handle[$plugin . '_title'][0]
				));
			}
			if ($attach_id != null && isset($media_handle[$plugin . '_file_name'][0])) {
				global $wpdb;
				$guid = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT guid FROM {$wpdb->posts} WHERE ID = %d",
						$attach_id
					),
					ARRAY_A
				);
				$dirname = date('Y') . '/' . date('m');
				$file_type = wp_check_filetype($guid[0]['guid'], null);
				$ext = '.' . $file_type['ext'];
				$dir = wp_upload_dir();

				// $uploaddir_paths = $dir ['basedir'] . '/' . $dirname ;
				// $uploaddir_url = $dir ['baseurl'] . '/' . $dirname;
				$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
				if ($uploads_use_yearmonth == 1) {

					$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
					$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
				} else {

					$uploaddir_paths = $dir['basedir'];
					$uploaddir_url = $dir['baseurl'];
				}
				$guids = $uploaddir_url . '/' . $media_handle[$plugin . '_file_name'][0] . $ext;
				$wpdb->update($wpdb->posts, ['guid' => $guids], ['ID' => $attach_id]);
				$fimg_name = $dirname . '/' . $media_handle[$plugin . '_file_name'][0] . $ext;
				update_post_meta($attach_id, '_wp_attached_file', $fimg_name);
			}
			if ($attach_id != null && isset($media_handle[$plugin . '_alt_text'][0])) {
				update_post_meta($attach_id, '_wp_attachment_image_alt', $media_handle[$plugin . '_alt_text'][0]);
			}
		}
	}
	function overwrite($post_id, $img_url)
	{
		global $wpdb;
		$sql = $wpdb->prepare(
			"SELECT post_mime_type FROM {$wpdb->posts} WHERE ID = %d",
			$post_id
		);
		list($current_filetype) = $wpdb->get_row($sql, ARRAY_N);
		$current_filename = wp_get_attachment_url($post_id);
		$current_guid = $current_filename;
		$current_filename = substr($current_filename, (strrpos($current_filename, "/") + 1));
		$ID = $post_id;
		$current_file = get_attached_file($ID);
		$current_path = substr($current_file, 0, (strrpos($current_file, "/")));
		$current_file = preg_replace("|(?<!:)/{2,}|", "/", $current_file);
		$current_filename = basename($current_file);
		$current_metadata = wp_get_attachment_metadata($post_id);

		$new_filename = basename($img_url);
		$file_type = wp_check_filetype($new_filename, null);
		$new_filetype = $file_type["type"];
		if (empty($new_filetype['ext'])) {
			$new_filename = @basename($img_url);
			$new_filename = str_replace(' ', '-', trim($new_filename));
			$new_filename = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $new_filename);
		}
		if (empty($new_filetype)) {
			$new_filetype = 'image/jpeg';
		}
		if (preg_match_all('/\b(?:(?:https?|http|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $img_url, $matchedlist, PREG_PATTERN_ORDER)) {
			$img_url = $img_url;
		} else {
			$media_dir = wp_get_upload_dir();
			$names = glob($media_dir['path'] . '/' . '*.*');
			foreach ($names as $values) {
				$exp = basename($values);
				if ($exp == $img_url) {
					$attach_data = wp_generate_attachment_metadata($ID, $values);
					wp_update_attachment_metadata($ID, $attach_data);
				}

				if (!empty($f_img) && strpos($values, $img_url) !== false) {
					$img_url = $media_dir['url'] . '/' . $img_url;
				}
			}
			return true;
		}
		$original_file_perms = fileperms($current_file) & 0777;
		$this->emr_delete_current_files($current_file, $post_id, $current_metadata);
		//	$new_filename = wp_unique_filename( $current_path, $new_filename );
		$new_file = $current_path . "/" . $new_filename;

		$data = file_get_contents($img_url);
		file_put_contents($new_file, $data);
		@chmod($current_file, $original_file_perms);
		$new_filetitle = preg_replace('/\.[^.]+$/', '', basename($new_file));
		$new_guid = str_replace($current_filename, $new_filename, $current_guid);
		$post_date = gmdate('Y-m-d H:i:s');
		$sql = $wpdb->prepare(
			"UPDATE {$wpdb->posts} SET post_title = %s, post_name = %s, guid = %s, post_mime_type = %s, post_date = %s, post_date_gmt = %s WHERE ID = %d",
			$new_filetitle,
			$new_filetitle,
			$new_guid,
			$new_filetype,
			$post_date,
			$post_date,
			$post_id
		);
		$wpdb->query($sql);
		$sql = $wpdb->prepare(
			"SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND post_id = %d",
			$post_id
		);
		$old_meta_name = $wpdb->get_row($sql, ARRAY_A);
		$old_meta_name = $old_meta_name["meta_value"];
		// Make new postmeta _wp_attached_file
		$new_meta_name = str_replace($current_filename, $new_filename, $old_meta_name);
		$sql = $wpdb->prepare(
			"UPDATE {$wpdb->postmeta} SET meta_value = %s WHERE meta_key = '_wp_attached_file' AND post_id = %d",
			$new_meta_name,
			$post_id
		);
		$wpdb->query($sql);
		$new_metadata = wp_generate_attachment_metadata($post_id, $new_file);
		wp_update_attachment_metadata($post_id, $new_metadata);
		$current_base_url = $this->emr_get_match_url($current_guid); //  .wp-contet.uplodas/ dae name without ext
		$sql = $wpdb->prepare(
			"SELECT ID, post_content FROM {$wpdb->prefix}posts WHERE post_status = 'publish' AND post_content LIKE %s;",
			'%' . $current_base_url . '%'
		);
		$rs = $wpdb->get_results($sql, ARRAY_A);
		$number_of_updates = 0;

		if (!empty($rs)) {
			$search_urls = $this->emr_get_file_urls($current_guid, $current_metadata);
			$replace_urls = $this->emr_get_file_urls($new_guid, $new_metadata);
			$replace_urls = $this->emr_normalize_file_urls($search_urls, $replace_urls);
			foreach ($rs as $rows) {
				$number_of_updates = $number_of_updates + 1;
				$post_content = $rows["post_content"];
				$post_content = addslashes(str_replace($search_urls, $replace_urls, $post_content));
				$sql = $wpdb->prepare(
					"UPDATE {$wpdb->posts} SET post_content = %s WHERE ID = %d",
					$post_content,
					$rows["ID"]
				);
				$wpdb->query($sql);
			}
		}
		update_attached_file($post_id, $new_file);
	}

	function emr_delete_current_files($current_file, $post_id, $metadata = null)
	{
		$current_path = substr($current_file, 0, (strrpos($current_file, "/")));
		if (file_exists($current_file)) {
			clearstatcache();
			if (is_writable($current_file)) {
				unlink($current_file);
			} else {
				printf(esc_html__('The file %1$s can not be deleted by the web server, most likely because the permissions on the file are wrong.'), $current_file);
				exit;
			}
		}
		// Delete old resized versions if this was an image
		$suffix = substr($current_file, (strlen($current_file) - 4));
		$prefix = substr($current_file, 0, (strlen($current_file) - 4));
		if (strtolower($suffix) === ".pdf") {
			$prefix .= "-pdf";
			$suffix = ".jpg";
		}
		$imgAr = array(".png", ".gif", ".jpg", ".jpeg");
		if (in_array($suffix, $imgAr)) {
			// It's a png/gif/jpg based on file name
			// Get thumbnail filenames from metadata
			if (empty($metadata)) {
				$metadata = wp_get_attachment_metadata($post_id);
			}
			if (is_array($metadata)) { // Added fix for error messages when there is no metadata (but WHY would there not be? I don't know…)
				foreach ($metadata["sizes"] as $thissize) {
					// Get all filenames and do an unlink() on each one;
					$thisfile = $thissize["file"];
					// Create array with all old sizes for replacing in posts later
					$oldfilesAr[] = $thisfile;
					// Look for files and delete them
					if (strlen($thisfile)) {
						$thisfile = $current_path . "/" . $thissize["file"];
						if (file_exists($thisfile)) {
							unlink($thisfile);
						}
					}
				}
			}
		}
	}

	function emr_get_match_url($url)
	{
		$url = $this->emr_remove_scheme($url);
		$url = $this->emr_maybe_remove_query_string($url);
		$url = $this->emr_remove_size_from_filename($url, true);
		$url = $this->emr_remove_domain_from_filename($url);
		return $url;
	}

	function emr_remove_scheme($url)
	{
		return preg_replace('/^(?:http|https):/', '', $url);
	}

	function emr_maybe_remove_query_string($url)
	{
		$parts = explode('?', $url);
		return reset($parts);
	}

	function emr_remove_size_from_filename($url, $remove_extension = false)
	{
		$url = preg_replace('/^(\S+)-[0-9]{1,4}x[0-9]{1,4}(\.[a-zA-Z0-9\.]{2,})?/', '$1$2', $url);
		if ($remove_extension) {
			$ext = pathinfo($url, PATHINFO_EXTENSION);
			$url = str_replace(".$ext", '', $url);
		}
		return $url;
	}

	function emr_remove_domain_from_filename($url)
	{
		$url = str_replace($this->emr_remove_scheme(get_bloginfo('url')), '', $url);
		return $url;
	}


	function emr_get_file_urls($guid, $metadata)
	{
		$urls = array();
		$guid = $this->emr_remove_scheme($guid);
		$guid = $this->emr_remove_domain_from_filename($guid);
		$urls['guid'] = $guid;
		if (empty($metadata)) {
			return $urls;
		}
		$base_url = dirname($guid);
		if (!empty($metadata['file'])) {
			$urls['file'] = trailingslashit($base_url) . wp_basename($metadata['file']);
		}

		if (!empty($metadata['sizes'])) {
			foreach ($metadata['sizes'] as $key => $value) {
				$urls[$key] = trailingslashit($base_url) . wp_basename($value['file']);
			}
		}
		return $urls;
	}

	function emr_normalize_file_urls($old, $new)
	{
		$result = array();
		if (empty($new['guid'])) {
			return $result;
		}
		$guid = $new['guid'];
		foreach ($old as $key => $value) {
			$result[$key] = empty($new[$key]) ? $guid : $new[$key];
		}
		return $result;
	}

	public function get_filename_path($image_url, $media_type = null)
	{
		$media_handle = get_option('smack_image_options');
		$path_file_name = isset( $media_handle['media_settings']['file_name'] ) ? (string) $media_handle['media_settings']['file_name'] : '';
		if ( $path_file_name !== '' && self::is_unresolved_media_seo_value( $path_file_name ) ) {
			$path_file_name = '';
		}
		if ($path_file_name !== '' && $media_type == 'External') {
			$fimg_name = $path_file_name;
			$fimg_name = str_replace(' ', '-', trim($fimg_name));
			$fimg_name = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $fimg_name);
			$dir = wp_upload_dir();
			$dirname = date('Y') . '/' . date('m');
			$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
			if ($uploads_use_yearmonth == 1) {

				$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
				$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
			} else {

				$parsed_url = parse_url($image_url, PHP_URL_PATH);

				// Match /uploads/YYYY/MM/ dynamically
				if (preg_match('#/uploads/(\d{4}/\d{2})/#', $parsed_url, $matches)) {
					$dirname = $matches[1];
				} else {
					$dirname = date('Y') . '/' . date('m');
				}
				$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
				$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
			}
			if ($uploaddir_paths != "" && $uploaddir_paths) {
				$uploaddir_path = $uploaddir_paths . "/" . $fimg_name;
			}
			return ['uploaddir_path' => $uploaddir_path, 'uploaddir_url' => $uploaddir_url, 'fimg_name' => $fimg_name];
		} else {
			$image_name = pathinfo($image_url);
			$fimg_name = $image_name['basename'];
			$fimg_name_without_ext = $image_name['filename'];
			if (empty($fimg_name_without_ext)) {
				$fimg_name_without_ext = $fimg_name;
			}
			$file_type = wp_check_filetype($fimg_name, null);
			if (empty($file_type['ext'])) {
				$fimg_name = @basename($image_url);
				$fimg_name = str_replace(' ', '-', trim($fimg_name));
				$fimg_name = preg_replace('/[^a-zA-Z0-9._\-\s]/', '', $fimg_name);
			}

			if (strstr($image_url, 'https://drive.google.com')) {
				preg_match('/[?&]id=([^&]+)/', $image_url, $matches);
				$fimg_name = isset($matches[1]) ? $matches[1] : basename($image_url);
			}
			$dir = wp_upload_dir();
			$dirname = date('Y') . '/' . date('m');
			$uploads_use_yearmonth = get_option('uploads_use_yearmonth_folders');
			if ($uploads_use_yearmonth == 1) {

				$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
				$uploaddir_url = $dir['baseurl'] . '/' . $dirname;
			} else {

				$parsed_url = parse_url($image_url, PHP_URL_PATH);

				// Match /uploads/YYYY/MM/ dynamically
				if (preg_match('#/uploads/(\d{4}/\d{2})/#', $parsed_url, $matches)) {
					$dirname = $matches[1];
				} else {
					$dirname = date('Y') . '/' . date('m');
				}

				$uploaddir_paths = $dir['basedir'] . '/' . $dirname;
				$uploaddir_url = $dir['baseurl'] . '/' . $dirname;

			}
			if ($uploaddir_paths != "" && $uploaddir_paths) {
				$uploaddir_path = $uploaddir_paths . "/" . $fimg_name;
			}

			return ['uploaddir_path' => $uploaddir_path, 'uploaddir_url' => $uploaddir_url, 'fimg_name' => $fimg_name];
		}
	}
	public function image_meta_table_entry($line_number, $post_values, $post_id, $acf_wpname_element, $acf_csv_name, $hash_key, $plugin, $get_import_type, $templatekey = null, $gmode = null, $header_array = null, $value_array = null, $imgformat = null, $typecct = null, $indexs = null, $media_type = null, $jet_child_object_id = null, $parent_object_id = null)
	{
		global $wpdb;
		$acf_wpname_element = isset($acf_wpname_element) ? $acf_wpname_element : '';
		$table_name = $wpdb->prefix . 'smackcsv_file_events';
		$file_name = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT file_name FROM {$table_name} WHERE hash_key = %s",
				$hash_key
			)
		);
		$get_path_values = $this->get_filename_path($acf_csv_name, $media_type);
		$uploaddir_path = $get_path_values['uploaddir_path'] ?? '';
		$uploaddir_url = $get_path_values['uploaddir_url'] ?? '';
		$fimg_name = $get_path_values['fimg_name'] ?? '';
		$file_type = 'image/jpeg';

		if ($plugin == 'Media') {
			return $this->handle_media_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $indexs, $media_type, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path);
		}

		if (isset($post_id) && !empty($acf_csv_name) && !empty($plugin)) {
			$post_title = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_title FROM {$wpdb->posts} WHERE ID = %d AND post_status != 'trash'",
					$post_id
				)
			);
			$shortcode_table = $wpdb->prefix . "ultimate_csv_importer_shortcode_manager";
			$failed_ids = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT post_title, post_id, image_shortcode, media_id, original_image FROM {$wpdb->prefix}ultimate_csv_importer_shortcode_manager WHERE image_shortcode = 'Featured_image_' AND post_id = %d AND original_image = %s",
					$post_id,
					$acf_csv_name
				)
			);
			if ($plugin == 'inline') {
				return $this->handle_inline_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $indexs, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name);
			}

			if ($plugin == 'Featured') {
				return $this->handle_featured_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name, $failed_ids);
			}

			return $this->handle_custom_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $imgformat, $typecct, $indexs, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name, $jet_child_object_id, $parent_object_id);
		}

		return '';
	}

	public function handle_media_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $indexs, $media_type, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path)
	{
		$media_handle = get_option('smack_image_options');
		$attach_id = $this->media_handling($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, '', '', $header_array, $value_array, '', '', $line_number, $indexs, '', $media_type);
		if (!empty($attach_id) && !is_wp_error($attach_id)) {
			return $attach_id;
		}

		$post_info = array(
			'guid' => $uploaddir_url . "/" . $fimg_name,
			'post_mime_type' => $file_type,
			'post_title' => 'image-failed',
			'post_content' => '',
			'post_status' => 'inherit',
			'post_author' => $post_values['author'] ?? ''
		);
		$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);
		if (is_wp_error($attach_id) || empty($attach_id)) {
			$this->failed_media_data($line_number, $post_id, 'image-failed', 0, $acf_csv_name);
			return 0;
		}
		// Do NOT call imageMetaImport here — it overwrites post_title and hides the failure sentinel.
		update_post_meta( $attach_id, '_uci_media_import_failed', 1 );
		update_post_meta( $attach_id, '_uci_media_import_failed_url', $acf_csv_name );
		update_post_meta( $attach_id, '_uci_media_import_failed_reason', 'remote_download_failed' );
		$this->store_failed_image_ids($attach_id);
		$this->failed_media_data($line_number, $post_id, 'image-failed', $attach_id, $acf_csv_name);
		return $attach_id;
	}

	public function handle_inline_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $indexs, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name)
	{
		global $wpdb;
		$failed_inline_ids = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_title, post_id, image_shortcode, media_id, original_image FROM {$wpdb->prefix}ultimate_csv_importer_shortcode_manager WHERE image_shortcode = 'inline_image_' AND post_id = %d",
				$post_id
			)
		);

		$attach_id = $this->media_handling($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, '', '', $header_array, $value_array, '', '', $line_number, $indexs);
		if (!empty($attach_id)) {
			return $attach_id;
		}

		if (empty($failed_inline_ids) || $failed_inline_ids[0]->original_image != $acf_csv_name) {
			$post_info = array(
				'guid' => $uploaddir_url . "/" . $fimg_name,
				'post_mime_type' => $file_type,
				'post_title' => 'image-failed',
				'post_content' => '',
				'post_status' => 'inherit',
				'post_author' => $post_values['author'] ?? ''
			);
			$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);
		}

		if (empty($failed_inline_ids)) {
			$insert_status = $wpdb->insert($shortcode_table, array(
				'post_id' => $post_id,
				'post_title' => $post_title,
				'image_shortcode' => $plugin . '_image_' . $acf_wpname_element,
				'media_id' => $attach_id,
				'original_image' => $acf_csv_name,
				'indexs' => $indexs,
				'hash_key' => $hash_key,
				'import_type' => $get_import_type,
				'file_name' => $file_name
			), array('%d', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s'));

			if ($insert_status) {
				$this->store_failed_image_ids($attach_id);
				$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $acf_csv_name);
			}
		} elseif (isset($failed_inline_ids[0]->post_id) && $failed_inline_ids[0]->post_id == $post_id) {
			$this->store_failed_image_ids($failed_inline_ids[0]->media_id);
			$this->failed_media_data($line_number, $failed_inline_ids[0]->post_id, $failed_inline_ids[0]->post_title, $failed_inline_ids[0]->media_id, $failed_inline_ids[0]->original_image);
		}

		return $attach_id;
	}

	public function handle_featured_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name, $failed_ids)
	{
		global $wpdb;
		if (empty($failed_ids)) {
			$attach_id = $this->media_handling($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, '', '', $header_array, $value_array, '', '', $line_number, '', '', '', '', '', '', '', $featured_image = true);
			if (!empty($attach_id)) {
				return $attach_id;
			}
		}

		if (empty($attach_id) || !empty($failed_ids)) {
			$post_info = array(
				'guid' => $uploaddir_url . "/" . $fimg_name,
				'post_mime_type' => $file_type,
				'post_title' => 'image-failed',
				'post_content' => '',
				'post_status' => 'inherit',
				'post_author' => $post_values['author'] ?? ''
			);
			$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);
			if (empty($failed_ids)) {
				$insert_status = $wpdb->insert($shortcode_table, array(
					'post_id' => $post_id,
					'post_title' => $post_title,
					'image_shortcode' => $plugin . '_image_' . $acf_wpname_element,
					'media_id' => $attach_id,
					'original_image' => $acf_csv_name,
					'hash_key' => $hash_key,
					'import_type' => $get_import_type,
					'file_name' => $file_name
				), array('%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s'));

				if ($insert_status) {
					$this->store_failed_image_ids($attach_id);
					$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $acf_csv_name);
					if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager' ) ) {
						\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager::annotate_existing_failure(
							$post_id,
							$attach_id,
							'download_failed',
							$hash_key,
							(int) $line_number
						);
					}
				}
			}
		}

		return $attach_id;
	}

	public function handle_custom_image($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, $header_array, $value_array, $line_number, $imgformat, $typecct, $indexs, $uploaddir_url, $fimg_name, $file_type, $uploaddir_path, $shortcode_table, $post_title, $file_name, $jet_child_object_id, $parent_object_id)
	{
		global $wpdb;

		if (strpos($plugin, 'jetengine_') !== false) {
			if (isset($header_array) && isset($value_array)) {
				$image_meta_value = array(
					'headerarray' => $header_array,
					'valuearray' => $value_array,
					'tablename' => $typecct,
					'returnformat' => $imgformat
				);
				$acf_image_meta = json_encode($image_meta_value);
			}
		}
		$acf_wpname_element = isset($acf_wpname_element) ? $acf_wpname_element : '';
		$acf_image_meta = isset($acf_image_meta) ? $acf_image_meta : '';
		$failed_id = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_title, post_id, image_shortcode, media_id, original_image FROM {$wpdb->prefix}ultimate_csv_importer_shortcode_manager WHERE post_id = %d AND original_image = %s AND image_shortcode = %s",
				$post_id,
				$acf_csv_name,
				$plugin . '_image__' . $acf_wpname_element
			)
		);
		$attach_id = $this->media_handling($acf_csv_name, $post_id, $post_values, $plugin, $get_import_type, $acf_wpname_element, $hash_key, '', '', $header_array, $value_array, '', '', $line_number, $indexs, $acf_image_meta, '', '', $jet_child_object_id, $parent_object_id);

		if (!empty($attach_id)) {
			return $attach_id;
		}

		if (empty($failed_id)) {
			$post_info = array(
				'guid' => $uploaddir_url . "/" . $fimg_name,
				'post_mime_type' => $file_type,
				'post_title' => 'image-failed',
				'post_content' => '',
				'post_status' => 'inherit',
				'post_author' => $post_values['author'] ?? ''
			);
			$attach_id = wp_insert_attachment($post_info, $uploaddir_path, $post_id);

			$insert_status = $wpdb->insert($shortcode_table, array(
				'post_id' => $post_id,
				'post_title' => $post_title,
				'image_shortcode' => $plugin . '_image__' . $acf_wpname_element,
				'media_id' => $attach_id,
				'original_image' => $acf_csv_name,
				'indexs' => $indexs,
				'image_meta' => $acf_image_meta,
				'hash_key' => $hash_key,
				'import_type' => $get_import_type,
				'file_name' => $file_name,
				'jet_child_object_id' => $jet_child_object_id,
				'jet_parent_object_id' => $parent_object_id
			), array('%d', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s'));

			if ($insert_status) {
				$this->store_failed_image_ids($attach_id);
				$this->failed_media_data($line_number, $post_id, $post_title, $attach_id, $acf_csv_name);
				if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager' ) ) {
					\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager::annotate_existing_failure(
						$post_id,
						$attach_id,
						'download_failed',
						$hash_key,
						(int) $line_number
					);
				}
			}
		} else {
			$media_id = $failed_id[0]->media_id;
			$attachment_id = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE ID = %d AND post_title = 'image-failed' AND post_type = 'attachment' AND guid LIKE %s",
					$media_id,
					'%' . $wpdb->esc_like($fimg_name) . '%'
				),
				ARRAY_A
			);
			$attach_id = $attachment_id[0]['ID'];
		}

		return $attach_id;
	}

	public function store_image_ids($attach_id)
	{
		//get number of images count
		$stored_ids = get_option('total_attachment_ids', '');
		$att_id = $attach_id;
		if ($stored_ids === '') {
			add_option('total_attachment_ids', serialize(array($att_id)));
			$stored_ids = unserialize(get_option('total_attachment_ids', ''));
		} else {
			$get_stored_ids = unserialize(get_option('total_attachment_ids', ''));
			if (is_array($get_stored_ids) && !empty($att_id)) {
				$att_id = is_array($att_id) ? $att_id : array($att_id);
				$stored_ids = array_merge($get_stored_ids, $att_id);
			} else {
				$stored_ids = $att_id;
			}
			update_option('total_attachment_ids', serialize($stored_ids));
			$stored_ids = unserialize(get_option('total_attachment_ids', ''));
		}
	}
	public function store_failed_data($data, $option_name)
	{
		$stored_data = get_option($option_name, '');
		// Initialize array for new data if no stored data exists
		if ($stored_data === '') {
			add_option($option_name, serialize(array($data)));
			$stored_data = unserialize(get_option($option_name, ''));
		} else {
			// Unserialize stored data
			$stored_data = unserialize($stored_data);
			$data = is_array($data) ? $data : array($data);
			$stored_data = array_merge($stored_data, $data);
			update_option($option_name, serialize($stored_data));
			$stored_data = unserialize(get_option($option_name, ''));
		}

		return $stored_data;
	}

	/**
	 * For featured/single-image fields: use first URL when value is pipe- or comma-separated.
	 * Gallery imports pass one URL per index and must not be split here.
	 *
	 * @param string   $img_url  Raw field value.
	 * @param string   $plugin   Import plugin context.
	 * @param int|null $indexs   Gallery index when applicable.
	 * @param bool     $featured Featured image context.
	 * @return string
	 */
	private function normalize_single_image_url( $img_url, $plugin, $indexs, $featured ) {
		if ( '' === $img_url || is_numeric( $img_url ) ) {
			return $img_url;
		}

		// Per-slot gallery URLs are already a single URL.
		if ( null !== $indexs && '' !== $indexs && false !== $indexs ) {
			return $img_url;
		}

		if ( false === strpos( $img_url, '|' ) && false === strpos( $img_url, ',' ) ) {
			return $img_url;
		}

		if ( class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter' ) ) {
			$parts = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::parse_urls( $img_url );
			if ( ! empty( $parts[0] ) && $parts[0] !== $img_url ) {
				return $parts[0];
			}
			if ( count( $parts ) === 1 ) {
				return $parts[0];
			}
		}

		// Legacy fallback (matches CoreFieldsImport::check_for_featured_image_url).
		if ( strpos( $img_url, '|' ) !== false ) {
			$split = explode( '|', $img_url );
			return trim( $split[0] );
		}
		if ( strpos( $img_url, ',' ) !== false ) {
			$split = explode( ',', $img_url );
			return trim( $split[0] );
		}

		return $img_url;
	}

	public function store_failed_image_ids($attach_id)
	{
		$option_name = 'failed_attachment_ids';
		$stored_data = $this->store_failed_data($attach_id, $option_name);
		return $stored_data;
	}

	public function failed_media_data($line_number, $post_id, $post_title, $media_id, $actual_url)
	{
		global $core_instance;
		$core_instance = CoreFieldsImport::getInstance();

		$option_name = 'failed_line_number';
		$stored_ids = $this->store_failed_data($media_id, $option_name);

		$count = count($stored_ids);

		$data = array('post_id' => $post_id, 'post_title' => $post_title, 'media_id' => $media_id, 'actual_url' => $actual_url);
		$core_instance->failed_media_data[$count] = $data;

		$error = new \WP_Error('import_failed', 'Media failed to import: ' . $actual_url);
		\Smackcoders\UCI\Proaddons\UltimatePro\HooksHandler::getInstance()->importActions()->fire_import_failed($error);
	}
}
