<?php
/**
 * Standalone ImportValueResolver smoke test (run: php tests/test-import-value-resolver.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __DIR__ ) . '/' );
}

if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) {
		return $value;
	}
}

require_once dirname( __DIR__ ) . '/includes/ImportValueResolver.php';

use Smackcoders\UCI\Proaddons\UltimatePro\ImportValueResolver;

$cases = array(
	array( 'csv' => '', 'existing' => 'Keep', 'mapped' => true, 'expect' => 'Keep' ),
	array( 'csv' => 'New', 'existing' => 'Keep', 'mapped' => true, 'expect' => 'New' ),
	array( 'csv' => 'New', 'existing' => 'Keep', 'mapped' => false, 'expect' => 'Keep' ),
	array( 'csv' => null, 'existing' => 'Keep', 'mapped' => true, 'expect' => 'Keep' ),
);

$failed = 0;
foreach ( $cases as $index => $case ) {
	$result = ImportValueResolver::resolve( $case['csv'], $case['existing'], $case['mapped'], 'test_field' );
	if ( $result !== $case['expect'] ) {
		echo "FAIL case {$index}: expected {$case['expect']}, got {$result}\n";
		++$failed;
	}
}

if ( ! ImportValueResolver::should_apply_in_update_mode( '', true, 'Update' ) ) {
	echo "PASS should_apply blank mapped update\n";
} else {
	echo "FAIL should_apply blank mapped update\n";
	++$failed;
}

if ( $failed === 0 ) {
	echo "All ImportValueResolver tests passed.\n";
	exit( 0 );
}

echo "{$failed} test(s) failed.\n";
exit( 1 );
