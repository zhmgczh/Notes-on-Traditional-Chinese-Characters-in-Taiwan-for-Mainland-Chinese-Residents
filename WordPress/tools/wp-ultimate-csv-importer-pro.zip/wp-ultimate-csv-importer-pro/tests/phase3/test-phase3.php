<?php
/**
 * Phase 3 smoke tests (run: php tests/phase3/test-phase3.php).
 *
 * Covers unit-testable PH3 cases without full WordPress bootstrap.
 */

$root = dirname( __DIR__, 2 );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', $root . '/' );
}

if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $str ) {
		return is_scalar( $str ) ? trim( (string) $str ) : '';
	}
}

if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) {
		return $value;
	}
}

if ( ! function_exists( 'do_action' ) ) {
	function do_action() {
	}
}

if ( ! function_exists( 'wp_cache_delete' ) ) {
	function wp_cache_delete() {
		return true;
	}
}

$failed = 0;

function ph3_assert( $label, $condition ) {
	global $failed;
	if ( ! $condition ) {
		echo "FAIL {$label}\n";
		++$failed;
		return;
	}
	echo "PASS {$label}\n";
}

// PH3-01/02: ExportBatchContext lifecycle
require_once $root . '/includes/ExportBatchContext.php';

use Smackcoders\UCI\Proaddons\UltimatePro\ExportBatchContext;

$ctx = new ExportBatchContext(
	array(
		'offset' => 100,
		'limit'  => 50,
		'module' => 'CustomPosts',
	)
);
$ctx->set_post_ids( array( 1, 2, 3 ) );
$ctx->set_temp_row( 1, array( 'post_title' => 'A' ) );
$usage = $ctx->get_memory_usage();
ph3_assert( 'PH3-01 ExportBatchContext instantiable', $ctx instanceof ExportBatchContext );
ph3_assert( 'PH3-02 memory usage keys', isset( $usage['peak_bytes'], $usage['delta_bytes'] ) );

$ctx->reset();
ph3_assert( 'PH3-02 reset clears temp data', empty( $ctx->get_temp_data() ) );
ph3_assert( 'PH3-02 reset increments batch index', 1 === $ctx->get_batch_index() );

$ctx->destroy();
ph3_assert( 'PH3-02 destroy clears batch index', 0 === $ctx->get_batch_index() );

// PH3-07: exponential backoff helper (MediaRetryManager)
$retry_file = $root . '/media/Services/MediaRetryManager.php';
if ( is_readable( $retry_file ) ) {
	require_once $retry_file;
	if ( method_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager', 'backoff_seconds' ) ) {
		$backoff = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager::backoff_seconds( 3 );
		ph3_assert( 'PH3-12 backoff attempt 3 = 20s', 20 === $backoff );
		$backoff_max = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaRetryManager::backoff_seconds( 10 );
		ph3_assert( 'PH3-12 backoff capped at 120s', 120 === $backoff_max );
	} else {
		echo "SKIP PH3-12 MediaRetryManager::backoff_seconds not implemented yet\n";
		++$failed;
	}
} else {
	echo "SKIP PH3-12 MediaRetryManager file missing\n";
	++$failed;
}

// PH3-14: gallery URL parsing
$gallery_file = $root . '/media/Services/MediaGalleryImporter.php';
if ( is_readable( $gallery_file ) ) {
	require_once $gallery_file;
	$urls = \Smackcoders\UCI\Proaddons\UltimatePro\Media\Services\MediaGalleryImporter::parse_urls( 'http://a.com/1.jpg|http://b.com/2.jpg|http://c.com/3.jpg' );
	ph3_assert( 'PH3-14 gallery parses 3 URLs', 3 === count( $urls ) );
} else {
	echo "SKIP PH3-14 MediaGalleryImporter missing\n";
	++$failed;
}

// PH3-20: FeatureLoader media_queue gate (static check)
$loader_src = file_get_contents( $root . '/includes/FeatureLoader.php' );
ph3_assert(
	'PH3-20 media_queue gated in FeatureLoader',
	false !== strpos( $loader_src, "FeatureRegistry::is_enabled( 'media_queue' )" )
);

// PH3-21: google_sheets skip in FeatureLoader
ph3_assert(
	'PH3-21 google_sheets gating in FeatureLoader',
	false !== strpos( $loader_src, 'google_sheets' ) && false !== strpos( $loader_src, 'GsheetUpload' )
);

// PH3-22/23: builder extension gating
ph3_assert(
	'PH3-22 bricks_builder gating',
	false !== strpos( $loader_src, 'bricks_builder' )
);
ph3_assert(
	'PH3-23 wpbakery gating',
	false !== strpos( $loader_src, 'wpbakery' )
);

// PH3-24: woo_native_csv gate
ph3_assert(
	'PH3-24 woo_native_csv gated',
	false !== strpos( $loader_src, "FeatureRegistry::is_enabled( 'woo_native_csv' )" )
);

// PH3-10/11: MediaHandling settings helper
$media_src = file_get_contents( $root . '/MediaHandling.php' );
ph3_assert(
	'PH3-10 MediaHandling uses MediaDownloadSettings',
	false !== strpos( $media_src, 'MediaDownloadSettings' )
);

// PH3-15: GSheet transport improvements
$transport_src = file_get_contents( $root . '/uploadModules/GoogleSheetsHttpTransport.php' );
ph3_assert(
	'PH3-15 transport has reason_code or status retry',
	false !== strpos( $transport_src, 'reason_code' ) || false !== strpos( $transport_src, 'should_retry' )
);

if ( 0 === $failed ) {
	echo "\nAll Phase 3 smoke tests passed.\n";
	exit( 0 );
}

echo "\n{$failed} test(s) failed.\n";
exit( 1 );
