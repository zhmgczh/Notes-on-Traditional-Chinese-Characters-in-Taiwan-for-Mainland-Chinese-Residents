<?php
/**
 * Phase 4 smoke tests (run: php tests/phase4/test-phase4.php).
 *
 * Covers FeatureLoader / hook stub / Phase 4 gate wiring without full WP bootstrap.
 */

$root = dirname( __DIR__, 2 );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', $root . '/' );
}

if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $str ) {
		return is_scalar( $str ) ? trim( (string) $str ) : '';
	}
}

if ( ! function_exists( 'sanitize_key' ) ) {
	function sanitize_key( $key ) {
		$key = strtolower( (string) $key );
		return preg_replace( '/[^a-z0-9_\-]/', '', $key );
	}
}

if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) {
		return $value;
	}
}

if ( ! function_exists( 'add_action' ) ) {
	function add_action() {
	}
}

if ( ! function_exists( 'get_option' ) ) {
	function get_option( $key, $default = false ) {
		global $uci_ph4_options;
		if ( ! is_array( $uci_ph4_options ) ) {
			$uci_ph4_options = array();
		}
		return array_key_exists( $key, $uci_ph4_options ) ? $uci_ph4_options[ $key ] : $default;
	}
}

if ( ! function_exists( 'update_option' ) ) {
	function update_option( $key, $value, $autoload = null ) {
		global $uci_ph4_options;
		if ( ! is_array( $uci_ph4_options ) ) {
			$uci_ph4_options = array();
		}
		$uci_ph4_options[ $key ] = $value;
		return true;
	}
}

if ( ! function_exists( 'add_option' ) ) {
	function add_option( $key, $value, $deprecated = '', $autoload = 'yes' ) {
		return update_option( $key, $value );
	}
}

$failed = 0;

function ph4_assert( $label, $condition ) {
	global $failed;
	if ( ! $condition ) {
		echo "FAIL {$label}\n";
		++$failed;
		return;
	}
	echo "PASS {$label}\n";
}

function ph4_reset_feature_registry_cache() {
	$reflection = new ReflectionClass( '\Smackcoders\UCI\Proaddons\UltimatePro\FeatureRegistry' );
	$property = $reflection->getProperty( 'states_cache' );
	$property->setAccessible( true );
	$property->setValue( null );
}

require_once $root . '/includes/FeatureRegistry.php';
require_once $root . '/includes/FeatureLoader.php';
require_once $root . '/includes/ImportFileResolver.php';

use Smackcoders\UCI\Proaddons\UltimatePro\FeatureRegistry;
use Smackcoders\UCI\Proaddons\UltimatePro\FeatureLoader;
use Smackcoders\UCI\Proaddons\UltimatePro\ImportFileResolver;

$defs = FeatureRegistry::get_definitions();
ph4_assert( 'PH4-12 registry has 15 features', 15 === count( $defs ) );

$expected_ids = array(
	'ai_import', 'wpbakery', 'bricks_builder', 'oxygen_builder', 'db_migration',
	'google_sheets', 'automation_api', 'hook_system', 'media_queue', 'woo_native_csv',
	'spreadsheet_editor', 'import_preview', 'import_retry', 'import_resume', 'woo_surecart_migration',
);
foreach ( $expected_ids as $id ) {
	ph4_assert( "PH4-12 registry has {$id}", isset( $defs[ $id ] ) );
}

// Simulate all OFF
$off = array();
foreach ( $expected_ids as $id ) {
	$off[ $id ] = false;
}
FeatureRegistry::save_states( $off );

foreach ( $expected_ids as $id ) {
	ph4_assert( "PH4-toggle OFF {$id}", false === FeatureRegistry::is_enabled( $id ) );
}

// Simulate missing option (fresh install) with no saved feature states
global $uci_ph4_options;
$uci_ph4_options = array();
ph4_reset_feature_registry_cache();
foreach ( $expected_ids as $id ) {
	ph4_assert( "PH4-toggle missing option OFF {$id}", false === FeatureRegistry::is_enabled( $id ) );
}

// Simulate all ON
$on = array();
foreach ( $expected_ids as $id ) {
	$on[ $id ] = true;
}
FeatureRegistry::save_states( $on );
foreach ( $expected_ids as $id ) {
	ph4_assert( "PH4-toggle ON {$id}", true === FeatureRegistry::is_enabled( $id ) );
}

// Hook stub when OFF
FeatureRegistry::save_states( array( 'hook_system' => false ) );
require_once $root . '/includes/HooksHandlerStub.php';
$import_actions = \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Actions::getInstance();
$import_filters = \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Filters::getInstance();
ph4_assert( 'PH4-01 stub Import Actions instantiable', is_object( $import_actions ) );
ph4_assert( 'PH4-01 stub has is_import_active', property_exists( $import_actions, 'is_import_active' ) || isset( \Smackcoders\UCI\Proaddons\UltimatePro\Hooks\Import\Actions::$is_import_active ) );
ph4_assert( 'PH4-01 stub filter pass-through', 'keep' === $import_filters->apply_custom_field_filter( 'keep', 1, 'k', 'keep', array(), 'h' ) );
ph4_assert( 'PH4-01 stub action no-op', null === $import_actions->fire_after_post_create( 123 ) );

$stub_src = file_get_contents( $root . '/includes/HooksHandlerStub.php' );
$hooks_boot = file_get_contents( $root . '/wp-csv-custom-hooks.php' );
ph4_assert( 'PH4-02 hooks bootstrap gates hook_system', false !== strpos( $hooks_boot, "FeatureRegistry::is_enabled( 'hook_system' )" ) );
ph4_assert( 'PH4-02 stub file present', false !== strpos( $stub_src, 'hook_system is OFF' ) );

$main = file_get_contents( $root . '/wp-ultimate-csv-importer-pro.php' );
ph4_assert( 'PH4-03 spreadsheet_editor gated require', false !== strpos( $main, "FeatureRegistry::is_enabled( 'spreadsheet_editor' )" ) && false !== strpos( $main, 'SpreadsheetEditorService.php' ) );
ph4_assert( 'PH4-05 import_preview gated require', false !== strpos( $main, "FeatureRegistry::is_enabled( 'import_preview' )" ) && false !== strpos( $main, 'ImportPreviewService.php' ) );
ph4_assert( 'PH4-06 import_retry gated require', false !== strpos( $main, "FeatureRegistry::is_enabled( 'import_retry' )" ) && false !== strpos( $main, 'RetryController.php' ) );
ph4_assert( 'PH4-07 import_resume gated require', false !== strpos( $main, "FeatureRegistry::is_enabled( 'import_resume' )" ) && false !== strpos( $main, 'ImportResumeController.php' ) );

$loader = file_get_contents( $root . '/includes/FeatureLoader.php' );
ph4_assert( 'PH4-08 woo_surecart gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'woo_surecart_migration' )" ) );
ph4_assert( 'PH4-media_queue gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'media_queue' )" ) );
ph4_assert( 'PH4-ai_import gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'ai_import' )" ) );
ph4_assert( 'PH4-google_sheets gate in upload modules', false !== strpos( $loader, 'google_sheets' ) && false !== strpos( $loader, 'GsheetUpload' ) );
ph4_assert( 'PH4-builders gated', false !== strpos( $loader, 'bricks_builder' ) && false !== strpos( $loader, 'wpbakery' ) && false !== strpos( $loader, 'oxygen_builder' ) );
ph4_assert( 'PH4-woo_native_csv gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'woo_native_csv' )" ) );
ph4_assert( 'PH4-db_migration gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'db_migration' )" ) );
ph4_assert( 'PH4-automation_api gated', false !== strpos( $loader, "FeatureRegistry::is_enabled( 'automation_api' )" ) );

$resolver = new ImportFileResolver();
ph4_assert( 'PH4-03 ImportFileResolver instantiable', $resolver instanceof ImportFileResolver );

$gate_js = file_get_contents( $root . '/app/components/FeatureModuleGate.js' );
ph4_assert( 'PH4-11 FeatureModuleGate exists', false !== strpos( $gate_js, 'FEATURE_MODULE_DISABLED_BANNER' ) );

$enabled_js = file_get_contents( $root . '/app/utils/enabledFeatures.js' );
ph4_assert( 'PH4-10 getPostMappingComponent exists', false !== strpos( $enabled_js, 'getPostMappingComponent' ) );
ph4_assert( 'PH4-10 spreadsheet_editor checked in post-mapping', false !== strpos( $enabled_js, 'spreadsheet_editor' ) );

$upload_js = file_get_contents( $root . '/app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/uploadOptions.js' );
ph4_assert( 'PH4-06 import_resume banner gated', false !== strpos( $upload_js, "isFeatureEnabled('import_resume')" ) );
ph4_assert( 'PH4-03 spreadsheet render gated', false !== strpos( $upload_js, "isFeatureEnabled('spreadsheet_editor')" ) );
ph4_assert( 'PH4-05 preview render gated', false !== strpos( $upload_js, "isFeatureEnabled('import_preview')" ) );

$bulk_js = file_get_contents( $root . '/app/admin/uploader/uploadoptions/uploadAdvancedModeOptions/bulkImport.js' );
ph4_assert( 'PH4-06 import_retry UI gated', false !== strpos( $bulk_js, "isFeatureEnabled('import_retry')" ) );

$rankmath = file_get_contents( $root . '/importExtensions/RankMathImport.php' );
ph4_assert( 'PH4-30 Rank Math uses ImportValueResolver or mapped guard', false !== strpos( $rankmath, 'has_mapped_rankmath_values' ) && false !== strpos( $rankmath, 'ImportValueResolver' ) );

if ( 0 === $failed ) {
	echo "\nAll Phase 4 smoke tests passed.\n";
	exit( 0 );
}

echo "\n{$failed} test(s) failed.\n";
exit( 1 );
