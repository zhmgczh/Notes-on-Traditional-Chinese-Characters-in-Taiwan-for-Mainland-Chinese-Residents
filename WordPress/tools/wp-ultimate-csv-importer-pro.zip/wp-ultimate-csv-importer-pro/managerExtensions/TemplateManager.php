<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class TemplateManager {

    private static $instance = null;
    private static $smack_csv_instance = null;

    public function __construct(){
        add_action('wp_ajax_displayTemplates',array($this,'display_templates'));
        add_action('wp_ajax_saveTemplate',array($this,'save_template'));
        add_action('wp_ajax_deleteTemplate',array($this,'delete_template'));
    }

    public static function getInstance() {
		if (TemplateManager::$instance == null) {
			TemplateManager::$instance = new TemplateManager;
            TemplateManager::$smack_csv_instance = UltimatePro::getInstance();
			return TemplateManager::$instance;
		}
		return TemplateManager::$instance;
    }


    /**
	 * Save template details.
	 */
    public function save_template(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        global $wpdb;
        $type          = isset($_POST['Types']) ? sanitize_text_field($_POST['Types']) : '';
		$map_fields    = isset($_POST['MappedFields']) ? wp_unslash($_POST['MappedFields']) : '';
        $template_name = isset($_POST['TemplateName']) ? sanitize_text_field($_POST['TemplateName']) : '';
        $new_template_name = isset($_POST['NewTemplate']) ? sanitize_text_field($_POST['NewTemplate']) : '';
        $mapping_type = isset($_POST['MappingType']) ? sanitize_text_field($_POST['MappingType']) : '';
        $mapping_filter = null;
		$filters = !empty($_POST['MappedFilter']) ? json_decode(stripslashes($_POST['MappedFilter']), true) : '';
		if(!empty($filters)){
			$mapping_filter = serialize($filters);		
		}
        $response = [];        
        $template_table_name = $wpdb->prefix . "ultimate_csv_importer_mappingtemplate";
        $template = $this->get_template_for_save($template_table_name, $template_name, $type);

        if (empty($template)) {
wp_send_json_error(array('message' => 'Template not found'));
			return;
        }

        $mapdata = ImportHelpers::decode_mapping_payload($map_fields);
        if (!is_array($mapdata)) {
wp_send_json_error(array('message' => 'Invalid mapping payload. Existing template mapping was not changed.'));
			return;
        }

        $mapping_fields = serialize( $mapdata );
        $time = date('Y-m-d H:i:s');
        $saved_template_name = !empty($new_template_name) ? $new_template_name : $template_name;
        $update_response = $wpdb->update(
			$template_table_name,
			array(
				'templatename'    => $saved_template_name,
				'mapping'         => $mapping_fields,
				'mapping_filter'  => $mapping_filter ?: '',
				'createdtime'     => $time,
				'module'          => $type,
				'mapping_type'    => $mapping_type,
			),
			array('id' => (int) $template->id),
			array('%s', '%s', '%s', '%s', '%s', '%s'),
			array('%d')
		);

        if ($update_response === false) {
wp_send_json_error(array('message' => 'Unable to save template mapping'));
			return;
        }

$response['success'] = true;
		echo wp_json_encode($response); 	
		wp_die();
    }

	private function get_template_for_save($template_table_name, $template_name, $type){
		global $wpdb;

		$template = null;
		if (!empty($type)) {
			$template = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, eventKey FROM $template_table_name WHERE templatename = %s AND module = %s ORDER BY id DESC LIMIT 1",
					$template_name,
					$type
				)
			);
		}

		if (empty($template)) {
			$template = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, eventKey FROM $template_table_name WHERE templatename = %s ORDER BY id DESC LIMIT 1",
					$template_name
				)
			);
		}

		return $template;
	}

    /**
	 * Deletes Template.
	 */
    public function delete_template(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        $template_name = isset($_POST['TemplateName']) ? sanitize_text_field($_POST['TemplateName']) : '';
    
        $return_message = [];
        global $wpdb;

        $template_table_name = $wpdb->prefix . "ultimate_csv_importer_mappingtemplate";
        $id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $template_table_name WHERE templatename = %s",
				$template_name
			)
		);

		if (empty($id)) {
			$return_message['message'] = 'Template not found';
			$return_message['success'] = false;
			echo wp_json_encode($return_message);
		    wp_die();
		}

		if($this->checkTemplate_scheduled($id)){
			// Check whether scheduled template count want to show or not. In pro Count was showed but not here.
			$return_message['message'] = 'Template assigned to Scheduler. So can not delete it.';
			$return_message['success'] = false;
			echo wp_json_encode($return_message); 	
		    wp_die();
		}
		$delete_response = $wpdb->delete($template_table_name ,array('id' => $id));
		if($delete_response){
			$return_message['message'] = 'Deleted Successfully';
			$return_message['success'] = true;
		}
		else {
			$return_message['message'] = 'Error occured while deleting';
			$return_message['success'] = false;
		}
		echo wp_json_encode($return_message); 	
		wp_die();
    }


    /**
	 * Checks whether a template has been scheduled.
	 * @param  int $id - template id
	 * @return boolean
	 */
    public function checkTemplate_scheduled($id){
		global $wpdb;
		$get_templateDetails = $wpdb->get_results($wpdb->prepare("select count(*) from {$wpdb->prefix}sm_uci_addon_pro_scheduled_import where templateid = %d and isrun = %d",$id,0));
		foreach($get_templateDetails[0] as $key => $value) {
			if($value != "0"){
				return true;
			}
			else{
				return false;
			}
        }
    }


    /**
	 * Retrieves and display template details
	 */
    public function display_templates(){
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
        global $wpdb;
        $response = [];
        $details = [];
        $info = [];        
        $template_table_name = $wpdb->prefix."ultimate_csv_importer_mappingtemplate";
		$get_result = $wpdb->get_results("SELECT id, templatename, createdtime, module, csvname, eventKey, mapping FROM $template_table_name WHERE templatename != '' order by id desc ");
       
        if(!empty($get_result)){
            foreach($get_result as $value){
                $template_name = $value->templatename;    
                $created_time = $value->createdtime;
                $module = $this->resolve_template_module($value);
                $module_label = $this->get_module_label($module);
                
				$details = [];
                $details['template_id'] = isset( $value->id ) ? absint( $value->id ) : 0;
                $details['template_name'] = $template_name;
                $details['module'] = $module;
                $details['module_label'] = $module_label;
                $details['created_time'] = $created_time;   
                $details['csv_name'] = isset($value->csvname) ? sanitize_text_field($value->csvname) : '';
                array_push($info , $details);
                
            }
            $response['success'] = true;
			$response['info'] = $info;
        }else{
            $response['success'] = false;
            $response['message'] = "No Templates Found";
        }
        echo wp_json_encode($response);
		wp_die();
    }

	private function resolve_template_module($template){
		global $wpdb;

		$module = isset($template->module) ? trim((string) $template->module) : '';
		if (!empty($module)) {
			return sanitize_text_field($module);
		}

		$template_id = isset($template->id) ? absint($template->id) : 0;
		if (!empty($template_id)) {
			$scheduled_module = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT module FROM {$wpdb->prefix}ultimate_csv_importer_scheduled_import WHERE templateid = %d AND module != '' ORDER BY id DESC LIMIT 1",
					$template_id
				)
			);
			if (!empty($scheduled_module)) {
				return sanitize_text_field($scheduled_module);
			}
		}

		$event_key = isset($template->eventKey) ? sanitize_text_field($template->eventKey) : '';
		if (!empty($event_key)) {
			$scheduled_module = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT module FROM {$wpdb->prefix}ultimate_csv_importer_scheduled_import WHERE event_key = %s AND module != '' ORDER BY id DESC LIMIT 1",
					$event_key
				)
			);
			if (!empty($scheduled_module)) {
				return sanitize_text_field($scheduled_module);
			}

			$events_table = $wpdb->prefix . 'smackuci_events';
			if ($this->table_exists($events_table)) {
				$event_module = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT import_type FROM $events_table WHERE eventKey = %s AND import_type != '' ORDER BY id DESC LIMIT 1",
						$event_key
					)
				);
				if (!empty($event_module)) {
					return sanitize_text_field($event_module);
				}
			}
		}

		return $this->infer_module_from_mapping(isset($template->mapping) ? $template->mapping : '');
	}

	private function infer_module_from_mapping($mapping){
		$mapping_data = maybe_unserialize($mapping);
		if (!is_array($mapping_data)) {
			return '';
		}

		$registered_modules = array_merge(get_post_types([], 'names'), get_taxonomies([], 'names'));
		$mapped_values = $this->flatten_mapping_values($mapping_data);

		foreach ($mapped_values as $mapped_value) {
			$mapped_value = is_scalar($mapped_value) ? trim((string) $mapped_value) : '';
			if (!empty($mapped_value) && in_array($mapped_value, $registered_modules, true)) {
				return sanitize_text_field($mapped_value);
			}
		}

		return '';
	}

	private function flatten_mapping_values($mapping_data){
		$values = [];
		foreach ($mapping_data as $value) {
			if (is_array($value)) {
				$values = array_merge($values, $this->flatten_mapping_values($value));
			} else {
				$values[] = $value;
			}
		}

		return $values;
	}

	private function get_module_label($module){
		$module = trim((string) $module);
		if (empty($module)) {
			return __( 'Uncategorized', 'wp-ultimate-csv-importer' );
		}

		if (class_exists(__NAMESPACE__ . '\ExtensionHandler')) {
			$extension_handler = ExtensionHandler::getInstance();
			$import_modules = $extension_handler->get_import_post_types();
			foreach ($import_modules as $label => $value) {
				if ($module === $value || $module === $label) {
					return sanitize_text_field($label);
				}
			}
		}

		$post_type = get_post_type_object($module);
		if (!empty($post_type->labels->name)) {
			return sanitize_text_field($post_type->labels->name);
		}

		$taxonomy = get_taxonomy($module);
		if (!empty($taxonomy->labels->name)) {
			return sanitize_text_field($taxonomy->labels->name);
		}

		return ucwords(str_replace(['_', '-'], ' ', sanitize_text_field($module)));
	}

	private function table_exists($table_name){
		global $wpdb;
		return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name;
	}
}
