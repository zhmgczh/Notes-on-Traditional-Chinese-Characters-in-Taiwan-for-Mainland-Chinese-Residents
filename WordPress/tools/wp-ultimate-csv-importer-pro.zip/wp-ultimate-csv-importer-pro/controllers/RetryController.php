<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX endpoints for failed-record retry queue.
 */
class RetryController {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_get_retry_records', array( $this, 'get_retry_records' ) );
		add_action( 'wp_ajax_retry_failed_records', array( $this, 'retry_failed_records' ) );
		add_action( 'wp_ajax_download_failed_records_csv', array( $this, 'download_failed_records_csv' ) );
		add_action( 'wp_ajax_get_import_retry_summary', array( $this, 'get_import_retry_summary' ) );
		add_action( 'wp_ajax_get_retry_audit_history', array( $this, 'get_retry_audit_history' ) );
	}

	private function verify_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	private function resolve_session_id() {
		if ( ! empty( $_POST['session_id'] ) ) {
			return sanitize_text_field( wp_unslash( $_POST['session_id'] ) );
		}
		if ( ! empty( $_POST['hash_key'] ) ) {
			return sanitize_key( wp_unslash( $_POST['hash_key'] ) );
		}
		if ( ! empty( $_POST['HashKey'] ) ) {
			return sanitize_key( wp_unslash( $_POST['HashKey'] ) );
		}
		if ( ! empty( $_POST['filename'] ) && isset( $_POST['revision'] ) ) {
			$service = RetryQueueService::getInstance();
			return $service->resolve_session_id_from_log(
				sanitize_file_name( wp_unslash( $_POST['filename'] ) ),
				sanitize_text_field( wp_unslash( $_POST['revision'] ) )
			);
		}
		return '';
	}

	public function get_retry_records() {
		$this->verify_request();

		$session_id = $this->resolve_session_id();
		if ( empty( $session_id ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$page     = isset( $_POST['page'] ) ? (int) $_POST['page'] : 1;
		$per_page = isset( $_POST['per_page'] ) ? (int) $_POST['per_page'] : 20;
		$status   = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : null;

		$service = RetryQueueService::getInstance();
		$result  = $service->get_records( $session_id, $page, $per_page, $status );
		$stats   = $service->get_session_stats( $session_id );

		wp_send_json(
			array(
				'success'    => true,
				'session_id' => $session_id,
				'stats'      => $stats,
				'records'    => $result['records'],
				'pagination' => array(
					'total'    => $result['total'],
					'page'     => $result['page'],
					'per_page' => $result['per_page'],
					'pages'    => $result['pages'],
				),
			)
		);
	}

	public function retry_failed_records() {
		$this->verify_request();

		$session_id = $this->resolve_session_id();
		if ( empty( $session_id ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$batch_size = isset( $_POST['batch_size'] ) ? (int) $_POST['batch_size'] : 25;
		$process_all = ! empty( $_POST['process_all'] ) && ( $_POST['process_all'] === 'true' || $_POST['process_all'] === '1' );

		$service  = RetryQueueService::getInstance();
		$total_recovered = 0;
		$total_failed    = 0;
		$iterations      = 0;
		$max_iterations  = $process_all ? 500 : 1;

		try {
			$previous_pending = null;
			do {
				$result = $service->process_retry_batch( $session_id, $batch_size );
				if ( empty( $result['success'] ) ) {
					wp_send_json( $result );
				}
				$batch_recovered = (int) ( $result['recovered'] ?? 0 );
				$batch_failed    = (int) ( $result['failed'] ?? 0 );
				$batch_processed = (int) ( $result['processed'] ?? 0 );
				$total_recovered += $batch_recovered;
				$total_failed    += $batch_failed;
				$pending         = (int) ( $result['pending'] ?? $service->get_pending_count( $session_id ) );
				$iterations++;

				// Unfixable rows stay pending — do not spin the same failure hundreds of times.
				if ( $batch_recovered === 0 && $batch_processed > 0 ) {
					break;
				}
				if ( null !== $previous_pending && $pending >= $previous_pending ) {
					break;
				}
				$previous_pending = $pending;
			} while ( $process_all && $pending > 0 && $iterations < $max_iterations && $batch_recovered > 0 );
		} catch ( \Throwable $e ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => $e->getMessage(),
				)
			);
		}

		$stats = $service->get_session_stats( $session_id );
		$audit = $this->get_audit_payload( $session_id );

		wp_send_json(
			array(
				'success'   => true,
				'recovered' => $total_recovered,
				'failed'    => $total_failed,
				'pending'   => $stats['pending'],
				'stats'     => $stats,
				'audit'     => $audit,
			)
		);
	}

	public function download_failed_records_csv() {
		$this->verify_request();

		$session_id = $this->resolve_session_id();
		if ( empty( $session_id ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$status  = isset( $_POST['queue_status'] ) ? sanitize_text_field( wp_unslash( $_POST['queue_status'] ) ) : RetryQueueService::STATUS_PENDING;
		$service = RetryQueueService::getInstance();
		$result  = $service->build_failed_records_csv( $session_id, $status );

		wp_send_json( $result );
	}

	/**
	 * Import completion / summary screen stats.
	 */
	public function get_import_retry_summary() {
		$this->verify_request();

		$session_id = $this->resolve_session_id();
		if ( empty( $session_id ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		global $wpdb;
		$log_table = $wpdb->prefix . 'import_detail_log';
		$counts    = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT total_records, created, updated, skipped, failed FROM {$log_table} WHERE hash_key = %s LIMIT 1",
				$session_id
			)
		);

		$service = RetryQueueService::getInstance();
		$stats   = $service->get_session_stats( $session_id );
		$audit   = $this->get_audit_payload( $session_id );

		wp_send_json(
			array(
				'success'       => true,
				'session_id'    => $session_id,
				'total'         => isset( $counts->total_records ) ? (int) $counts->total_records : 0,
				'created'       => isset( $counts->created ) ? (int) $counts->created : 0,
				'updated'       => isset( $counts->updated ) ? (int) $counts->updated : 0,
				'skipped'       => isset( $counts->skipped ) ? (int) $counts->skipped : 0,
				'failed'        => max( isset( $counts->failed ) ? (int) $counts->failed : 0, $stats['pending'] ),
				'pending_retry' => $stats['pending'],
				'recovered'     => $stats['recovered'],
				'audit'         => $audit,
			)
		);
	}

	public function get_retry_audit_history() {
		$this->verify_request();

		$session_id = $this->resolve_session_id();
		if ( empty( $session_id ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		wp_send_json(
			array(
				'success' => true,
				'audit'   => $this->get_audit_payload( $session_id ),
				'history' => $this->get_history_rows( $session_id ),
			)
		);
	}

	private function get_audit_payload( $session_id ) {
		global $wpdb;
		$events_table = $wpdb->prefix . 'smackuci_events';

		$event = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT created, updated, skipped, failed, retry_recovered, retry_remaining FROM {$events_table} WHERE eventKey = %s ORDER BY id DESC LIMIT 1",
				$session_id
			)
		);

		$service = RetryQueueService::getInstance();
		$stats   = $service->get_session_stats( $session_id );

		$original_success = 0;
		if ( $event ) {
			$original_success = (int) $event->created + (int) $event->updated;
		}

		return array(
			'original' => array(
				'success' => $original_success,
				'failed'  => $event ? (int) $event->failed : 0,
				'skipped' => $event ? (int) $event->skipped : 0,
			),
			'retry'    => array(
				'recovered'        => $event ? (int) $event->retry_recovered : $stats['recovered'],
				'remaining_failed' => $stats['pending'],
			),
		);
	}

	private function get_history_rows( $session_id ) {
		global $wpdb;
		$table = RetryQueueService::history_table_name();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, recovered_count, failed_count, user_id, retried_at FROM {$table} WHERE session_id = %s ORDER BY retried_at DESC LIMIT 50",
				$session_id
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}
}
