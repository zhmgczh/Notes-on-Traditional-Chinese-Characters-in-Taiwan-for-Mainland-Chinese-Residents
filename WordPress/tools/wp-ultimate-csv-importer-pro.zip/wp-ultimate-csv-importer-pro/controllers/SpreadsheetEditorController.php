<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX endpoints for Spreadsheet Live Editor.
 */
class SpreadsheetEditorController {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_spreadsheet_get_meta', array( $this, 'spreadsheet_get_meta' ) );
		add_action( 'wp_ajax_spreadsheet_get_rows', array( $this, 'spreadsheet_get_rows' ) );
		add_action( 'wp_ajax_spreadsheet_save_edits', array( $this, 'spreadsheet_save_edits' ) );
		add_action( 'wp_ajax_spreadsheet_validate_rows', array( $this, 'spreadsheet_validate_rows' ) );
		add_action( 'wp_ajax_spreadsheet_finalize', array( $this, 'spreadsheet_finalize' ) );
		add_action( 'wp_ajax_spreadsheet_discard_edits', array( $this, 'spreadsheet_discard_edits' ) );
	}

	private function verify_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
		$service = SpreadsheetEditorService::getInstance();
		if ( ! $service->is_enabled() ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Spreadsheet editor is disabled.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	private function get_hash_key() {
		if ( ! empty( $_POST['HashKey'] ) ) {
			return sanitize_key( wp_unslash( $_POST['HashKey'] ) );
		}
		if ( ! empty( $_POST['hash_key'] ) ) {
			return sanitize_key( wp_unslash( $_POST['hash_key'] ) );
		}
		return '';
	}

	public function spreadsheet_get_meta() {
		$this->verify_request();
		if ( class_exists( 'Smackcoders\\UCI\\Proaddons\\UltimatePro\\Tables' ) ) {
			Tables::getInstance()->create_tables();
		}
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		wp_send_json( SpreadsheetEditorService::getInstance()->get_meta( $hash_key ) );
	}

	public function spreadsheet_get_rows() {
		$this->verify_request();
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		$args = array(
			'page'          => isset( $_POST['page'] ) ? (int) $_POST['page'] : 1,
			'per_page'      => isset( $_POST['per_page'] ) ? (int) $_POST['per_page'] : 100,
			'search'        => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
			'search_scope'  => isset( $_POST['search_scope'] ) ? sanitize_text_field( wp_unslash( $_POST['search_scope'] ) ) : 'all',
			'search_col'    => isset( $_POST['search_col'] ) ? (int) $_POST['search_col'] : -1,
			'search_mode'   => isset( $_POST['search_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['search_mode'] ) ) : 'partial',
			'filter'        => isset( $_POST['filter'] ) ? sanitize_text_field( wp_unslash( $_POST['filter'] ) ) : '',
			'filter_column' => isset( $_POST['filter_column'] ) ? (int) $_POST['filter_column'] : -1,
			'filter_value'  => isset( $_POST['filter_value'] ) ? sanitize_text_field( wp_unslash( $_POST['filter_value'] ) ) : '',
		);
		wp_send_json( SpreadsheetEditorService::getInstance()->get_rows( $hash_key, $args ) );
	}

	public function spreadsheet_save_edits() {
		$this->verify_request();
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		$edits = array();
		if ( ! empty( $_POST['edits'] ) ) {
			$decoded = json_decode( wp_unslash( $_POST['edits'] ), true );
			if ( is_array( $decoded ) ) {
				$edits = $decoded;
			}
		}
		wp_send_json( SpreadsheetEditorService::getInstance()->save_edits( $hash_key, $edits ) );
	}

	public function spreadsheet_validate_rows() {
		$this->verify_request();
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		$rows = array();
		if ( ! empty( $_POST['rows'] ) ) {
			$decoded = json_decode( wp_unslash( $_POST['rows'] ), true );
			if ( is_array( $decoded ) ) {
				$rows = $decoded;
			}
		}
		wp_send_json( SpreadsheetEditorService::getInstance()->validate_rows_request( $hash_key, $rows ) );
	}

	public function spreadsheet_finalize() {
		$this->verify_request();
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		wp_send_json( SpreadsheetEditorService::getInstance()->finalize( $hash_key ) );
	}

	public function spreadsheet_discard_edits() {
		$this->verify_request();
		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ) ) );
		}
		wp_send_json( SpreadsheetEditorService::getInstance()->discard_edits( $hash_key ) );
	}
}
