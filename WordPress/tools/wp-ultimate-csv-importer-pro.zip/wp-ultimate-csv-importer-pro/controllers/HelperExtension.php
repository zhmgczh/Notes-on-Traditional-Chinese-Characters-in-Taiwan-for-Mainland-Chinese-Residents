<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (! defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * Class HelperExtension
 * @package Smackcoders\UCI\Proaddons\UltimatePro
 */
class HelperExtension
{
    protected static $instance = null;
    public $plugin;

    public static function getInstance()
    {
        if (null == self::$instance) {
            self::$instance = new self;
            self::$instance->doHooks();
        }
        return self::$instance;
    }

    /**
     * HelperExtension constructor.
     */
    public function __construct()
    {
        $this->plugin = class_exists("Smackcoders\UCI\Core\UCICore") ? \Smackcoders\UCI\Core\UCICore::getInstance() : null;
    }


    /**
     * HelperExtension hooks.
     */
    public function doHooks()
    {
        add_action('wp_ajax_helperImport', array($this, 'HelperImport'));
        add_action('wp_ajax_helperSearch', array($this, 'SearchWord'));
    }
    public static function SearchWord()
    {
        self::handleAjaxRequest('Search');
    }

    public static function HelperImport()
    {
        self::handleAjaxRequest('Import', 'Import%20Update%20Media%20Export');
    }

    private static function handleAjaxRequest($mode, $search_term = null)
    {
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

        if ($_POST) {
            $search_term = $search_term ?? sanitize_text_field($_POST['searchInput']);

            if (!empty($search_term)) {
                $encoded_term = rawurlencode($search_term);
                $transient_key = 'smack_support_search_' . md5($encoded_term);
                $data = get_transient($transient_key);
                if ($data === false) {
                    $search_url = 'https://www.smackcoders.com/?swp_form%5Bform_id%5D=1&s=' . $encoded_term;
                    // Use HTTP API so HTTPS works when allow_url_fopen=0 (file_get_contents cannot open remote URLs).
                    $response = wp_remote_get(
                        $search_url,
                        array(
                            'timeout'     => 15,
                            'redirection' => 3,
                            'user-agent'  => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ),
                        )
                    );

                    if ( is_wp_error( $response ) ) {
                        wp_send_json_error(
                            array(
                                'error'   => 'Failed to fetch content',
                                'message' => $response->get_error_message(),
                            )
                        );
                        wp_die();
                    }

                    $code = (int) wp_remote_retrieve_response_code( $response );
                    if ( $code < 200 || $code >= 300 ) {
                        wp_send_json_error(
                            array(
                                'error'  => 'Failed to fetch content',
                                'status' => $code,
                            )
                        );
                        wp_die();
                    }

                    $html = wp_remote_retrieve_body( $response );
                    if ( $html === '' || $html === null ) {
                        wp_send_json_error( array( 'error' => 'Failed to fetch content' ) );
                        wp_die();
                    }

                    $data = self::parseHtml($html);
                    set_transient($transient_key, $data, 24 * HOUR_IN_SECONDS);
                }
                if (!empty($data)) {
                    $response = ['result' => $data];
                    wp_send_json_success($response);
                } else {
                    wp_send_json_error(['message' => 'No data found.']);
                }
                wp_die();
            }
        }
    }

    private static function parseHtml($html)
    {
        try {
            $doc = new \DOMDocument();
            @$doc->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

            $xpath = new \DOMXPath($doc);
            $result = [];
            foreach ($xpath->query("//article") as $index => $article) {

                $title = trim($xpath->query(".//h2", $article)->item(0)->textContent ?? '');
                $link = $xpath->query(".//a", $article)->item(0)->getAttribute("href") ?? '';
                $content = trim($xpath->query(".//p", $article)->item(0)->textContent ?? '');
                //$img_url = $xpath->query(".//img", $article)->item(0)->getAttribute("src") ?? '';

                $result[] = [
                    "title" => $title,
                    "content" => $content,
                    "link" => $link,
                ];
            }
            return $result;
        } catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}
