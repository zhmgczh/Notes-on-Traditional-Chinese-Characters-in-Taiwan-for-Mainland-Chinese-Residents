<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

use Smackcoders\UCI\Proaddons\UltimatePro\AI\Review\ReviewManager;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Review\ReviewStorage;
use Smackcoders\UCI\Proaddons\UltimatePro\AI\Services\AISettingsService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX endpoints for AI settings, generation, and review workflow.
 */
class AIReviewController {

	private static $instance = null;

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$actions = array(
			'uci_ai_get_settings'   => 'get_settings',
			'uci_ai_save_settings'  => 'save_settings',
			'uci_ai_generate_batch' => 'generate_batch',
			'uci_ai_get_reviews'    => 'get_reviews',
			'uci_ai_update_review'  => 'update_review',
			'uci_ai_bulk_review'    => 'bulk_review',
			'uci_ai_clear_reviews'  => 'clear_reviews',
			'uci_ai_review_status'  => 'review_status',
		);
		foreach ( $actions as $action => $method ) {
			add_action( 'wp_ajax_' . $action, array( $this, $method ) );
		}
	}

	private function verify_request() {
		if ( ! FeatureRegistry::is_enabled( 'ai_import' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'AI Import is disabled in Feature Modules.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	private function resolve_hash_key() {
		if ( ! empty( $_POST['HashKey'] ) ) {
			return sanitize_key( wp_unslash( $_POST['HashKey'] ) );
		}
		if ( ! empty( $_POST['hash_key'] ) ) {
			return sanitize_key( wp_unslash( $_POST['hash_key'] ) );
		}
		return '';
	}

	public function get_settings() {
		$this->verify_request();
		wp_send_json(
			array(
				'success'  => true,
				'settings' => AISettingsService::getInstance()->get_public_settings(),
			)
		);
	}

	public function save_settings() {
		$this->verify_request();
		$input = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : array();
		if ( ! is_array( $input ) ) {
			$input = array();
		}
		$saved = AISettingsService::getInstance()->save( $input );
		wp_send_json(
			array(
				'success'  => true,
				'settings' => $saved,
			)
		);
	}

	public function generate_batch() {
		$this->verify_request();
		$hash   = $this->resolve_hash_key();
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$config = isset( $_POST['config'] ) ? json_decode( wp_unslash( $_POST['config'] ), true ) : array();
		if ( ! is_array( $config ) ) {
			$config = array();
		}
		if ( empty( $hash ) ) {
			wp_send_json( array( 'success' => false, 'message' => __( 'Invalid import session.', 'wp-ultimate-csv-importer' ) ) );
		}
		if ( ! empty( $_POST['reset'] ) && ( '1' === $_POST['reset'] || 'true' === $_POST['reset'] ) ) {
			ReviewStorage::getInstance()->clear_import( $hash );
		}
		wp_send_json( ReviewManager::getInstance()->generate_batch( $hash, $offset, $config ) );
	}

	public function get_reviews() {
		$this->verify_request();
		$hash = $this->resolve_hash_key();
		if ( empty( $hash ) ) {
			wp_send_json( array( 'success' => false ) );
		}
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$limit  = isset( $_POST['limit'] ) ? min( 500, (int) $_POST['limit'] ) : 100;
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		$args   = array( 'offset' => $offset, 'limit' => $limit );
		if ( '' !== $status ) {
			$args['status'] = $status;
		}
		$rows = ReviewStorage::getInstance()->get_reviews( $hash, $args );
		wp_send_json(
			array(
				'success' => true,
				'reviews' => $rows,
				'counts'  => ReviewStorage::getInstance()->count_by_status( $hash ),
			)
		);
	}

	public function update_review() {
		$this->verify_request();
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id < 1 ) {
			wp_send_json( array( 'success' => false ) );
		}
		$data = array();
		if ( isset( $_POST['status'] ) ) {
			$status = sanitize_key( wp_unslash( $_POST['status'] ) );
			if ( in_array( $status, array( 'pending', 'approved', 'rejected', 'edited' ), true ) ) {
				$data['status'] = $status;
			}
		}
		if ( isset( $_POST['suggested_value'] ) ) {
			$data['suggested_value'] = wp_kses_post( wp_unslash( $_POST['suggested_value'] ) );
			if ( ! isset( $data['status'] ) ) {
				$data['status'] = 'edited';
			}
		}
		ReviewStorage::getInstance()->update( $id, $data );
		wp_send_json( array( 'success' => true ) );
	}

	public function bulk_review() {
		$this->verify_request();
		$hash   = $this->resolve_hash_key();
		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		if ( empty( $hash ) || ! in_array( $action, array( 'approve_all', 'reject_all', 'approve_pending', 'reject_pending' ), true ) ) {
			wp_send_json( array( 'success' => false ) );
		}
		$storage = ReviewStorage::getInstance();
		switch ( $action ) {
			case 'approve_all':
				$storage->bulk_update_status( $hash, 'approved' );
				break;
			case 'reject_all':
				$storage->bulk_update_status( $hash, 'rejected' );
				break;
			case 'approve_pending':
				$storage->bulk_update_status( $hash, 'approved', 'pending' );
				break;
			case 'reject_pending':
				$storage->bulk_update_status( $hash, 'rejected', 'pending' );
				break;
		}
		wp_send_json(
			array(
				'success' => true,
				'counts'  => $storage->count_by_status( $hash ),
			)
		);
	}

	public function clear_reviews() {
		$this->verify_request();
		$hash = $this->resolve_hash_key();
		if ( ! empty( $hash ) ) {
			ReviewStorage::getInstance()->clear_import( $hash );
		}
		wp_send_json( array( 'success' => true ) );
	}

	public function review_status() {
		$this->verify_request();
		$settings = AISettingsService::getInstance();
		wp_send_json(
			array(
				'success'       => true,
				'enabled'       => $settings->is_review_flow_enabled(),
				'openai_ready'  => $settings->is_openai_ready(),
				'features'      => $settings->get_active_features(),
				'settings'      => $settings->get_public_settings(),
				'settings_url'  => $settings->get_connectors_settings_url(),
			)
		);
	}
}
