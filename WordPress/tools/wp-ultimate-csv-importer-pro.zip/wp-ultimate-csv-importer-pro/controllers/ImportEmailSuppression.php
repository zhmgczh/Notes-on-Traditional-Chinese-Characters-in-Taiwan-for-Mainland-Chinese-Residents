<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Suppresses ALL user-related emails during CSV import.
 * Prevents: wp_new_user_notification, send_password_change_email,
 * send_email_change_email, and plugin SendPassword feature.
 */
class ImportEmailSuppression {

	const TRANSIENT_KEY = 'smack_uci_suppress_emails';
	const TRANSIENT_EXPIRY = 900; // 15 minutes

	/** Tracks whether filters were added this request (prevents accumulation when enable() called per row) */
	private static $filters_added = false;

	/**
	 * Enable email suppression (call at start of import).
	 * Sets transient and adds filters once per request.
	 */
	public static function enable() {
		set_transient( self::TRANSIENT_KEY, true, self::TRANSIENT_EXPIRY );
		self::add_filters();
	}

	/**
	 * Disable email suppression (call when import completes).
	 * Clears transient so subsequent requests won't suppress emails.
	 */
	public static function disable() {
		delete_transient( self::TRANSIENT_KEY );
	}

	/**
	 * Check if suppression is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return (bool) get_transient( self::TRANSIENT_KEY );
	}

	/**
	 * Add suppression filters. Called by enable() and maybe_add_filters().
	 * Filters are added only once per request to prevent accumulation.
	 */
	private static function add_filters() {
		if ( self::$filters_added ) {
			return;
		}
		self::$filters_added = true;

		// Hard safeguard: prevent WP from sending signup/registration emails.
		// (We still use filters below, but removing the action guarantees "zero email triggering".)
		remove_action( 'register_new_user', 'wp_send_new_user_notifications' );

		// WordPress 6.1+ notification filters
		add_filter( 'wp_send_new_user_notification_to_user', '__return_false', 999 );
		add_filter( 'wp_send_new_user_notification_to_admin', '__return_false', 999 );

		// Password/email change notifications
		add_filter( 'send_password_change_email', '__return_false', 999 );
		add_filter( 'send_email_change_email', '__return_false', 999 );

		// Allow UsersImport to skip SendPassword during import
		add_filter( 'smack_uci_send_password_during_import', '__return_false', 999 );
	}

	/**
	 * Register suppression filters when transient is set (e.g. batch import).
	 * Call from plugin init.
	 */
	public static function maybe_add_filters() {
		if ( self::is_active() ) {
			self::add_filters();
		}
	}
}
