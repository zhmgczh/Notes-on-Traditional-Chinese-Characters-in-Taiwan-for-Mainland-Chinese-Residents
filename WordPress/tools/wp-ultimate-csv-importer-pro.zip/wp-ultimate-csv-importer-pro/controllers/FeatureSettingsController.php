<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX settings for #1442 feature module toggles.
 */
class FeatureSettingsController {

	/** @var self|null */
	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_uci_pro_get_feature_toggles', array( $this, 'get_feature_toggles' ) );
		add_action( 'wp_ajax_uci_pro_save_feature_toggles', array( $this, 'save_feature_toggles' ) );
	}

	private function verify_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	public function get_feature_toggles() {
		$this->verify_request();

		$features = array();
		foreach ( FeatureRegistry::get_all() as $id => $meta ) {
			$features[] = $meta;
		}

		wp_send_json(
			array(
				'success'  => true,
				'features' => $features,
			)
		);
	}

	public function save_feature_toggles() {
		$this->verify_request();

		$raw = isset( $_POST['toggles'] ) ? wp_unslash( $_POST['toggles'] ) : '';
		if ( is_string( $raw ) && $raw !== '' ) {
			$decoded = json_decode( $raw, true );
			$states  = is_array( $decoded ) ? $decoded : array();
		} elseif ( is_array( $raw ) ) {
			$states = $raw;
		} else {
			$states = array();
			foreach ( array_keys( FeatureRegistry::get_definitions() ) as $id ) {
				if ( isset( $_POST[ $id ] ) ) {
					$states[ $id ] = filter_var( wp_unslash( $_POST[ $id ] ), FILTER_VALIDATE_BOOLEAN );
				}
			}
		}

		if ( empty( $states ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'No toggle data received.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		FeatureRegistry::save_states( $states );

		wp_send_json(
			array(
				'success'  => true,
				'features' => array_values( FeatureRegistry::get_all() ),
				'message'  => __( 'Feature settings saved.', 'wp-ultimate-csv-importer' ),
			)
		);
	}
}
