<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX endpoints for Import Preview and validation retry.
 *
 * Actions:
 * - uci_pro_get_import_preview
 * - uci_pro_retry_preview_validation
 */
class ImportPreviewController {

	private static $instance = null;

	/**
	 * @return self
	 */
	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_uci_pro_get_import_preview', array( $this, 'ajax_get_import_preview' ) );
		add_action( 'wp_ajax_uci_pro_retry_preview_validation', array( $this, 'ajax_retry_preview_validation' ) );
	}

	/**
	 * Verify nonce and manage_options capability.
	 */
	private function verify_request() {
		check_ajax_referer( 'smack-ultimate-csv-importer-pro', 'securekey' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Permission denied.', 'wp-ultimate-csv-importer' ),
				)
			);
		}
	}

	/**
	 * @return string
	 */
	private function get_hash_key() {
		if ( ! empty( $_POST['HashKey'] ) ) {
			return sanitize_key( wp_unslash( $_POST['HashKey'] ) );
		}
		if ( ! empty( $_POST['hash_key'] ) ) {
			return sanitize_key( wp_unslash( $_POST['hash_key'] ) );
		}
		return '';
	}

	/**
	 * Build and return import preview rows.
	 */
	public function ajax_get_import_preview() {
		$this->verify_request();

		$service = ImportPreviewService::getInstance();
		if ( ! $service->is_enabled() ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Import preview is disabled.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$hash_key = $this->get_hash_key();
		if ( empty( $hash_key ) ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid session.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$preview_limit = isset( $_POST['preview_limit'] ) ? (int) $_POST['preview_limit'] : ImportPreviewService::DEFAULT_ROW_LIMIT;
		$offset        = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 1;

		$result = $service->build_preview(
			$hash_key,
			array(
				'preview_limit' => $preview_limit,
				'offset'        => $offset,
			)
		);

		wp_send_json( $result );
	}

	/**
	 * Re-run validation for a single preview row.
	 */
	public function ajax_retry_preview_validation() {
		$this->verify_request();

		$hash_key   = $this->get_hash_key();
		$row_number = isset( $_POST['row_number'] ) ? (int) $_POST['row_number'] : 0;

		if ( empty( $hash_key ) || $row_number < 1 ) {
			wp_send_json(
				array(
					'success' => false,
					'message' => __( 'Invalid preview retry request.', 'wp-ultimate-csv-importer' ),
				)
			);
		}

		$row_data = array();
		if ( ! empty( $_POST['row_data'] ) ) {
			$decoded = json_decode( wp_unslash( $_POST['row_data'] ), true );
			if ( is_array( $decoded ) ) {
				$row_data = $decoded;
			}
		}

		do_action( 'uci_pro_before_retry_validation', $hash_key, $row_number, $row_data );

		$result = ImportPreviewService::getInstance()->retry_row_validation( $hash_key, $row_number, $row_data );

		do_action( 'uci_pro_after_retry_validation', $hash_key, $row_number, $result );

		wp_send_json( $result );
	}
}
