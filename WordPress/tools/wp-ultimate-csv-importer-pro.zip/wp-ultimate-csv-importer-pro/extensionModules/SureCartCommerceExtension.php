<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if (!defined('ABSPATH'))
    exit;

class SureCartCommerceExtension extends ExtensionHandler
{

    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Process SureCart extension and return field mappings
     *
     * @param string $data - selected import type
     * @return array - mapping fields per module
     */
    public function processExtension($data)
    {

        $import_type = $this->import_name_as($data);

        $surecartFields = [];
        $resultKey = '';

        switch ($import_type) {

            case 'SURECART_PRODUCTS':
                $surecartFields = [
                    'Product ID' => 'product_id',
                    'Product Name' => 'product_name',
                    'Description' => 'post_content',
                    'Short Description' => 'short_description',
                    'SKU' => 'sku',
                    'Price Name' => 'price_name',
                    'Price' => 'price',
                    'Sale Price' => 'sale_price',
                    'Compare at Price' => 'compare_at_price',
                    'Stock Enabled' => 'stock_enabled',
                    'Stock Quantity' => 'stock_quantity',
                    'Allow Backorders' => 'allow_purchase_out_of_stock',
                    'Tax Enabled' => 'tax_enabled',
                    'Tax Status' => 'tax_status',
                    'Tax Rate' => 'tax_rate',
                    'Featured Image' => 'featured_image',
                    'Gallery Images' => 'gallery_images',
                    'Product Type' => 'product_type',
                    'Product Is Varient' => 'product_is_varient', 
                    'Recurring Interval' => 'recurring_interval',
                    'Recurring Period' => 'recurring_period',
                    'Recurring Price' => 'recurring_price',
                    'Variants' => 'variants',
                    'Product Categories' => 'product_categories',
                    'Product Tags' => 'product_tags',
                    'Purchase Link Text' => 'purchase_link_text',
                    'Purchase Link URL' => 'purchase_link_url',
                    'Download Files' => 'download_files',
                    'Product Meta' => 'product_meta',
                    'Collection' => 'product_collections',
                    'Shipping Profile' => 'shipping_profile',
                    'SEO Title' => 'seo_title',
                    'SEO Description' => 'seo_description',
                    'Variant Options' => 'variant_options',
                    'License' => 'license',
                    'License Count' => 'license_count',
                    'Status' => 'post_status',
                    'Slug' => 'post_name',
                    'Date' => 'post_date',
                    'Weight' => 'weight',
                    'Length' => 'length',
                    'Width' => 'width',
                    'Height' => 'height',
                    'Weight Unit' => 'weight_unit',
                    'Parent SKU' => 'parent_sku',
                    'Custom Affiliate Commission' => 'custom_affiliate_commission',
                    'Commission Type' => 'commission_type',
                    'Percent Commission' => 'percent_commission',
                    'Amount Commission' => 'amount_commission',
                    'Subscription Commission Enabled' => 'subscription_commission_enabled',
                    'Subscription Commission Days' => 'subscription_commission_days',
                    'Lifetime Commission Enabled' => 'lifetime_commission_enabled',
                    'Lifetime Commission Days' => 'lifetime_commission_days'
                ];
                $resultKey = 'SURECART_PRODUCTS';
                break;

            case 'SURECART_ORDERS':
                $surecartFields = [
                    'SC ID' => 'sc_id',
                    'Order ID' => 'order_id',
                    'Order Number' => 'order_number',
                    'Order Status' => 'order_status',
                    'Order Date' => 'order_date',
                    'Customer Email' => 'customer_email',
                    'Customer ID' => 'customer_id',
                    'Customer Name' => 'customer_name',
                    'Billing First Name' => 'billing_first_name',
                    'Billing Last Name' => 'billing_last_name',
                    'Billing Address Line 1' => 'billing_address_line_1',
                    'Billing Address Line 2' => 'billing_address_line_2',
                    'Billing City' => 'billing_city',
                    'Billing State' => 'billing_state',
                    'Billing Postal Code' => 'billing_postal_code',
                    'Billing Country' => 'billing_country',
                    'Shipping First Name' => 'shipping_first_name',
                    'Shipping Last Name' => 'shipping_last_name',
                    'Shipping Address Line 1' => 'shipping_address_line_1',
                    'Shipping Address Line 2' => 'shipping_address_line_2',
                    'Shipping City' => 'shipping_city',
                    'Shipping State' => 'shipping_state',
                    'Shipping Postal Code' => 'shipping_postal_code',
                    'Shipping Country' => 'shipping_country',
                    'Order Total' => 'total',
                    'Currency' => 'currency',
                    'Subtotal' => 'subtotal',
                    'Tax Amount' => 'tax_amount',
                    'Discount Amount' => 'discount_amount',
                    'Shipping Amount' => 'shipping_amount',
                    'Payment Method' => 'payment_method',
                    'Payment Status' => 'payment_status',
                    'Transaction ID' => 'transaction_id',
                    'Line Items' => 'line_items',
                    'Order Meta' => 'order_meta',
                    'Subscription ID' => 'subscription_id',
                    'Coupon Code' => 'coupon_code'
                ];
                $resultKey = 'SURECART_ORDERS';
                break;

            case 'SURECART_CUSTOMERS':
                $surecartFields = [
                    'SC ID' => 'sc_id',
                    'Customer ID' => 'customer_id',
                    'Customer Email' => 'customer_email',
                    'Customer Name' => 'customer_name',
                    'First Name' => 'first_name',
                    'Last Name' => 'last_name',
                    'User ID' => 'user_id',
                    'User Login' => 'user_login',
                    'User Email' => 'user_email',
                    'Billing Address Line 1' => 'billing_address_line_1',
                    'Billing Address Line 2' => 'billing_address_line_2',
                    'Billing City' => 'billing_city',
                    'Billing State' => 'billing_state',
                    'Billing Postal Code' => 'billing_postal_code',
                    'Billing Country' => 'billing_country',
                    'Phone Number' => 'phone_number',
                    'Purchase Count' => 'purchase_count',
                    'Lifetime Value' => 'lifetime_value',
                    'Date Created' => 'date_created',
                    'Customer Meta' => 'customer_meta',
                    'Order IDs' => 'order_ids',
                    'Notes' => 'notes'
                ];
                $resultKey = 'SURECART_CUSTOMERS';
                break;

            case 'SURECART_SUBSCRIPTIONS':
                $surecartFields = [
                    'Subscription ID' => 'subscription_id',
                    'Customer ID' => 'customer_id',
                    'Customer Email' => 'customer_email',
                    'Product ID' => 'product_id',
                    'Product Name' => 'product_name',
                    'Order ID' => 'order_id',
                    'Status' => 'subscription_status',
                    'Interval' => 'interval',
                    'Period' => 'period',
                    'Price' => 'price',
                    'Start Date' => 'start_date',
                    'End Date' => 'end_date',
                    'Next Payment Date' => 'next_payment_date',
                    'Trial End Date' => 'trial_end_date',
                    'Cancel Date' => 'cancel_date',
                    'Cancel Reason' => 'cancel_reason',
                    'Billing Cycle Count' => 'billing_cycle_count',
                    'Total Payments' => 'total_payments',
                    'Subscription Meta' => 'subscription_meta'
                ];
                $resultKey = 'SURECART_SUBSCRIPTIONS';
                break;

            case 'SURECART_COUPONS':
                $surecartFields = [
                    'Coupon ID' => 'coupon_id',
                    'Coupon Code' => 'coupon_code',
                    'Promotion Codes' => 'promotion_codes',
                    'Discount Type' => 'discount_type',
                    'Discount Amount' => 'discount_amount',
                    'Status' => 'status',
                    'Usage Limit' => 'usage_limit',
                    'Usage Count' => 'usage_count',
                    'Usage Limit Per User' => 'usage_limit_per_user',
                    'Start Date' => 'start_date',
                    'End Date' => 'end_date',
                    'Minimum Amount' => 'minimum_amount',
                    'Maximum Amount' => 'maximum_amount',
                    'First Order Only' => 'first_order_only',
                    'Applies To' => 'applies_to',
                    'Duration' => 'duration',
                    'Duration In Months' => 'duration_in_months',
                    'Product Requirements' => 'product_requirements',
                    'Excluded Products' => 'excluded_products',
                    'Category Requirements' => 'category_requirements',
                    'Excluded Categories' => 'excluded_categories',
                    'Currency' => 'currency',
                    'Archived' => 'archived',
                    'Coupon Meta' => 'coupon_meta'
                ];
                $resultKey = 'SURECART_COUPONS';
                break;

            case 'SURECART_REPORTS':
                $surecartFields = [
                    'Report Date' => 'report_date',
                    'Order Count' => 'order_count',
                    'Total Earnings' => 'total_earnings',
                    'Total Tax' => 'total_tax',
                    'Total Shipping' => 'total_shipping',
                    'Gateway' => 'gateway',
                    'Product ID' => 'product_id',
                    'Product Name' => 'product_name'
                ];
                $resultKey = 'SURECART_REPORTS';
                break;

            default:
                return [];
        }

        $mapping_array = $this->convert_static_fields_to_array($surecartFields);

        return [
            $resultKey => $mapping_array
        ];
    }

    /**
     * SureCart extension supported import types
     *
     * @param string $import_type
     * @return boolean
     */
    public function extensionSupportedImportType($import_type)
    {

        if (!is_plugin_active('surecart/surecart.php')) {
            return false;
        }

        if ($import_type === 'nav_menu_item') {
            return false;
        }

        $import_type = $this->import_name_as($import_type);
        $supported = [
            'SURECART_PRODUCTS',
            'SURECART_ORDERS',
            'SURECART_CUSTOMERS',
            'SURECART_SUBSCRIPTIONS',
            'SURECART_COUPONS',
            'SURECART_REPORTS'
        ];

        $is_supported = in_array($import_type, $supported, true);

        return $is_supported;
    }
}

