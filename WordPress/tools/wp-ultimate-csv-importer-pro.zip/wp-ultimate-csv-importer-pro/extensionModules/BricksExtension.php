<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class BricksExtension extends ExtensionHandler{
	private static $instance = null;

	public static function getInstance() {	
		if (BricksExtension::$instance == null) {
			BricksExtension::$instance = new BricksExtension;
		}
		return BricksExtension::$instance;
	}

	/**
	 * Provides Bricks Meta fields for specific post type
	 * @param string $data - selected import type
	 * @return array - mapping fields
	 */
	public function processExtension($data){  

		$import_type = $data;
		$response = [];
		$import_type = $this->import_name_as($import_type);
		
		if( defined('BRICKS_VERSION') ){   
			if($import_type == 'bricks_template' || $import_type == 'Posts' || $import_type == 'Pages' || $import_type == 'CustomPosts'){
				$bricks_fields = array(
					'Bricks Layout JSON' => '_bricks_page_content_2',
					'Bricks Template Type' => '_bricks_template_type',
					'Used Custom Component' => 'bricks_components',
					'Used Custom CSS' => 'bricks_global_classes'
				);
			}
		}

		$bricks_meta_fields_line = $this->convert_static_fields_to_array($bricks_fields);
		$response['bricks_meta_fields'] = $bricks_meta_fields_line; 

		return $response;
	}

	/**
	 * Bricks Meta extension supported import types
	 * @param string $import_type - selected import type
	 * @return boolean
	 */
	public function extensionSupportedImportType($import_type ){
		$import_type = $this->import_name_as($import_type);
		if( defined('BRICKS_VERSION') ){
			if($import_type == 'bricks_template' || $import_type == 'Pages' || $import_type == 'Posts' || $import_type == 'CustomPosts') { 
				return true;
			}else{
				return false;
			}
		}
	}
}
