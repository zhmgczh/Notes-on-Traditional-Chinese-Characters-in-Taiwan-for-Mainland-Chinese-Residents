<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class OxygenExtension extends ExtensionHandler {
	private static $instance = null;

	public static function getInstance() {	
		if (OxygenExtension::$instance == null) {
			OxygenExtension::$instance = new OxygenExtension;
		}
		return OxygenExtension::$instance;
	}

	/**
	 * Provides Oxygen Meta fields for specific post type
	 * @param string $data - selected import type
	 * @return array - mapping fields
	 */
	public function processExtension($data){  
		$import_type = $data;
		$response = [];
		$import_type = $this->import_name_as($import_type);
		
		if( is_plugin_active('oxygen/functions.php') ){   
			if($import_type == 'Posts' || $import_type == 'Pages' || $import_type == 'ct_template' || $import_type == 'CustomPosts'){
				$pro_meta_fields = array(
					'Oxygen Layout JSON' => '_ct_builder_json',
					'Oxygen Shortcodes' => '_ct_builder_shortcodes',
					'Oxygen Custom CSS' => '_ct_custom_css',
					'Oxygen Media' => 'oxygen_media'
				);
				
				$pro_meta_fields_line = $this->convert_static_fields_to_array($pro_meta_fields);
				$response['oxygen_meta_fields'] = $pro_meta_fields_line; 
			}
		}

		return $response;
	}

	/**
	 * Oxygen Meta extension supported import types
	 * @param string $import_type - selected import type
	 * @return boolean
	 */
	public function extensionSupportedImportType($import_type ){
		$import_type = $this->import_name_as($import_type);
		if( is_plugin_active('oxygen/functions.php') ){
			if($import_type == 'Pages' || $import_type == 'Posts' || $import_type == 'ct_template' || $import_type == 'CustomPosts') { 
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
}
