<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

class MappingExtension{
	private static $instance = null,$extension_handler;
	private static $extension = [];
	private static $validatefile,$wpquery_export;

	public function __construct(){
		add_action('wp_ajax_mappingfields',array($this,'mapping_field_function'));
		add_action('wp_ajax_getfields',array($this,'get_fields'));
		add_action('wp_ajax_get_export_fields',array($this,'get_export_fields'));
		add_action('wp_ajax_templateinfo',array($this,'get_template_info'));
		add_action('wp_ajax_search_template',array($this,'search_template'));
		add_action('wp_ajax_get_post_titles', array($this, 'get_post_titles'));
	}

	public static function getInstance() {
		if (MappingExtension::$instance == null) {
			MappingExtension::$instance = new MappingExtension;
			MappingExtension::$validatefile = new ValidateFile;
			MappingExtension::$wpquery_export = new WPQueryExport;

			foreach(get_declared_classes() as $class){
				if(is_subclass_of($class, 'Smackcoders\UCI\Proaddons\UltimatePro\ExtensionHandler')){ 
					array_push(MappingExtension::$extension ,$class::getInstance() );	
				}
			}
			return MappingExtension::$instance;
		}
		return MappingExtension::$instance;
	}
	/**
	* Ajax Call 
	* Provides all Widget Fields for Mapping Section
	* @return array - mapping fields
	*/
	public function mapping_field_function(){

		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$import_type = sanitize_text_field($_POST['Types']);
		$hash_key = sanitize_key($_POST['HashKey']);
		$mode = sanitize_text_field($_POST['Mode']);
		$media_type = '';
        if (isset($_POST['MediaType'])) {
            $media_type = sanitize_key($_POST['MediaType']);
        }
		$operation_mode = sanitize_text_field($_POST['OperationMode']);
		$update_mode = '';
		if (isset($_POST['UpdateMode'])) {
			$update_mode = sanitize_text_field($_POST['UpdateMode']);
		} elseif (isset($_POST['update_mode'])) {
			$update_mode = sanitize_text_field($_POST['update_mode']);
		}
	
		update_option("smack_operation_mode_".$hash_key, $operation_mode);
		if ( ! empty( $_POST['WcCsvFormat'] ) && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector' ) ) {
			\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector::store_user_format(
				$hash_key,
				sanitize_text_field( wp_unslash( $_POST['WcCsvFormat'] ) )
			);
		}
		if ( ! empty( $import_type ) && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector' ) ) {
			\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector::store_import_module( $hash_key, $import_type );
		}
		if (!empty($update_mode)) {
			$update_mode = strtolower(trim($update_mode));
			if (in_array($update_mode, ['replace','skip','append'], true)) {
				update_option("smack_update_mode_".$hash_key, $update_mode);
			}
		}
		global $wpdb;

		$response = [];
		$administratorRole = wp_get_current_user();
        $roles = $administratorRole->roles;
		$current_user_role = '';
		if (in_array('administrator', $roles)) {
			$current_user_role = 'administrator';
		}
		$details = [];
		$info = [];

		$table_name = $wpdb->prefix."smackcsv_file_events";
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE $table_name SET mode = %s WHERE hash_key = %s",
				$mode,
				$hash_key
			)
		);

		$get_result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT file_name,total_rows FROM $table_name WHERE hash_key = %s",
				$hash_key
			)
		);
		if ( empty( $get_result ) || ! isset( $get_result[0] ) ) {
			$response['success'] = false;
			$response['message'] = 'File event not found for this import. Please re-upload the file/URL and try again.';
			echo wp_json_encode($response);
			wp_die();
		}
		$filename = isset($get_result[0]->file_name) ? $get_result[0]->file_name : '';
		$total_rows = isset($get_result[0]->total_rows) ? $get_result[0]->total_rows : 0;
		if ( empty( $filename ) ) {
			$response['success'] = false;
			$response['message'] = 'Missing filename for this import. Please re-upload the file/URL and try again.';
			echo wp_json_encode($response);
			wp_die();
		}
		$file_extension = pathinfo($filename, PATHINFO_EXTENSION);
		if(empty($file_extension)){
			$file_extension = 'xml';
		}
		if($file_extension == 'xlsx' || $file_extension == 'xls' || $file_extension == 'json') {
			$file_extension = 'csv';
		}
		$template_table_name = $wpdb->prefix."ultimate_csv_importer_mappingtemplate";
		$wc_native_import    = class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector' )
			&& \Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector::uses_wc_importer( $hash_key, $import_type );

		$get_result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, templatename, createdtime, module, csvname, mapping FROM $template_table_name WHERE templatename != '' AND (module = %s OR ((module IS NULL OR module = '') AND csvname = %s)) ORDER BY id DESC",
				$import_type,
				$filename
			)
		);
		/* Provides Template Details, if Templates are stored */
		if ( ! empty( $get_result ) && ! $wc_native_import ) {
			foreach($get_result as $value){
				$details = [];
				$template_name = $value->templatename;
				$mapping = isset($value->mapping) ? $value->mapping : '';
				//$mapped_elements = unserialize($mapping);
				$mapped_elements = array();
				$mapping_fields = maybe_unserialize($mapping);
				if (!is_array($mapping_fields)) {
					$mapping_fields = [];
				}
                foreach ($mapping_fields as $key => $mapping_value) {
					if (!is_array($mapping_value)) {
						continue;
					}

					if($key == "ATTRMETA"){
						$mapped_elements[$key] =array();
					}
					foreach($mapping_value as $map_key=>$map_value){
						if (is_int($map_key)) {
							if($key == "ATTRMETA"){
								if (is_int($map_key)) {
									$mapped_elements[$key] = array_merge($mapped_elements[$key], $map_value);
								}
								else{
									$mapped_elements[$key][$map_key]=$map_value;
								}

							}
							else{
								unset($mapping_value[$map_key]);
							}
							
						}else{
							$mapped_elements[$key][$map_key]=$map_value;
						}
                        
                	}    
           		}
				$matched_count = $this->get_matched_count($mapped_elements, $template_name);	
				$created_time = $value->createdtime;
				$module = $this->resolve_template_module($value, $import_type);
				$details['template_name'] = $template_name;
				$details['created_time'] = $created_time;
				$details['module'] = $module;
				$details['module_label'] = $this->get_module_label($module);
				$details['count'] = $matched_count;
				array_push($info , $details);
			}
				
			$response['success'] = true;
			$response['show_template'] = true;
			$response['info'] = $info;
			$response['currentuser']=$current_user_role;
			$response['total_records'] = (int)$total_rows;
			echo wp_json_encode($response);
			wp_die();
		}
		/* Provides widget fields, if templates are not stored */
		else{
		
			$smackcsv_instance = UltimatePro::getInstance();
			$upload_dir = $smackcsv_instance->create_upload_dir();
			$response = [];
			if($file_extension == 'csv' || $file_extension == 'txt'){
				if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
					if (!ini_get("auto_detect_line_endings")) {  // If auto_detect_line_endings is not enabled
						ini_set("auto_detect_line_endings", true);  // Enable it to handle different line endings
					}
				}
				$info = [];
				if (($h = fopen($upload_dir.$hash_key.'/'.$hash_key, "r")) !== FALSE) 
				{
				// Convert each line into the local $data variable
				$delimiters = array( ',','\t',';','|',':','&nbsp');
				$file_path = $upload_dir . $hash_key . '/' . $hash_key;
				$delimiter = MappingExtension::$validatefile->getFileDelimiter($file_path, 5);
				$array_index = array_search($delimiter,$delimiters);
				if($array_index == 5){
					$delimiters[$array_index] = ' ';
				}
				if($delimiter == '\t'){
					$delimiter ='~';
					 $temp=$file_path.'temp';
					 if (($handles = fopen($temp, 'r')) !== FALSE){
						while (($data = fgetcsv($handles, 0, $delimiter, '"', '\\')) !== FALSE)
						{
							$trimmed_array = array_map('trim', $data);
							array_push($info , $trimmed_array);	
							$exp_line = $info[0];
							$response['success'] = true;
							$response['show_template'] = false;
							$response['csv_fields'] = $exp_line;
							$response['currentuser']=$current_user_role;
							if(!empty($media_type) && $import_type == 'Media'){
								$value = $this->media_mapping_fields($import_type,$mode,$media_type);
							}else{
								$value = $this->mapping_fields($import_type);
							}
							$response['fields'] = $value;	
							$response['total_records'] = (int)$total_rows;				
							$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
							echo wp_json_encode($response);
							wp_die();  			  			
						}
					}

					fclose($handles);
				}
				else{
					while (($data = fgetcsv($h, 0, $delimiters[$array_index], '"', '\\')) !== FALSE) 
					{	
		
						// Read the data from a single line
						$trimmed_array = array_map('trim', $data);
						array_push($info , $trimmed_array);	
						$exp_line = $info[0];
						$response['success'] = true;
						$response['show_template'] = false;
						$response['csv_fields'] = $exp_line;
						$response['currentuser']=$current_user_role;
						if(!empty($media_type) && $import_type == 'Media'){
							$value = $this->media_mapping_fields($import_type,$mode,$media_type);
						}else{
							$value = $this->mapping_fields($import_type);
						}
						$response['fields'] = $value;
						$response['total_records'] = (int)$total_rows;					
						$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
						echo wp_json_encode($response);
						wp_die();  			
					}	
					// Close the file
					fclose($h);
				}
				}
			}	
			if($file_extension == 'tsv'){
				if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
					if (!ini_get("auto_detect_line_endings")) {
						ini_set("auto_detect_line_endings", true);
					}
				}
				$info = [];
				if (($h = fopen($upload_dir.$hash_key.'/'.$hash_key, "r")) !== FALSE) 
				{
					
					$file_path = $upload_dir . $hash_key . '/' . $hash_key;
					$delimiter = MappingExtension::$validatefile->getFileDelimiter($file_path, 5);
					if($delimiter == '\t'){
						$hs = $upload_dir . $hash_key . '/' . $hash_key;
						$line =file($hs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
						$data = explode("\t", $line[0]);
						$trimmed_array = array_map('trim', $data);
						array_push($info , $trimmed_array);	
						$exp_line = $info[0];
						$response['success'] = true;
						$response['show_template'] = false;
						$response['csv_fields'] = $exp_line;
						$response['currentuser']=$current_user_role;
						if(!empty($media_type) && $import_type == 'Media'){
							$value = $this->media_mapping_fields($import_type,$mode,$media_type);
						}else{
							$value = $this->mapping_fields($import_type);
						}
						$response['fields'] = $value;	
						$response['total_records'] = (int)$total_rows;				
						$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
						echo wp_json_encode($response);
						wp_die();					}	
				}
			}
			if($file_extension == 'xml'){
				$xml_class = new XmlHandler();
				$upload_dir_path = $upload_dir. $hash_key;
				if (!is_dir($upload_dir_path)) {
					wp_mkdir_p( $upload_dir_path);
				}
				chmod($upload_dir_path, 0777);   
				$path = $upload_dir . $hash_key . '/' . $hash_key;   
				$xml = @simplexml_load_file($path);
				if ($xml === false) {
					$sample = '';
					$raw = '';
					if (file_exists($path) && filesize($path) > 0) {
						$raw = (string) @file_get_contents($path, false, null, 0, 800);
						$sample = preg_replace('/\s+/', ' ', $raw);
					}
					// If it's not XML (most likely CSV), fall back to CSV header mapping to avoid hard-blocking.
					$trimmed = ltrim($raw);
					if ($trimmed !== '' && $trimmed[0] !== '<') {
						$delimiter = MappingExtension::$validatefile->getFileDelimiter($path, 5);
						if ($delimiter === '\t') {
							$delimiter = "\t";
						}
						$fp = @fopen($path, 'r');
						if ($fp) {
							$header = fgetcsv($fp, 0, $delimiter, '"', '\\');
							fclose($fp);
							if (is_array($header) && !empty($header)) {
								$response['success'] = true;
								$response['show_template'] = false;
								$response['csv_fields'] = array_map('trim', $header);
								if(!empty($media_type) && $import_type == 'Media'){
									$value = $this->media_mapping_fields($import_type,$mode,$media_type);
								}else{
									$value = $this->mapping_fields($import_type);
								}
								$response['currentuser']=$current_user_role;
								$response['fields'] = $value;
								$response['total_records'] = (int)$total_rows;
								echo wp_json_encode($response);
								wp_die();
							}
						}
					}

					$response['success'] = false;
					$response['message'] = 'XML parse failed. The downloaded file may be HTML/error response or invalid XML.';
					echo wp_json_encode($response);
					wp_die();
				}
				$xml_arr = json_decode( json_encode($xml) , 1);
			
				foreach($xml->children() as $child){   
					$child_name = $child->getName();    
				}
				$parse_xml = $xml_class->parse_xmls($hash_key);
				$i = 0;
				$headers = [];
				foreach($parse_xml as $xml_key => $xml_value){
					if(is_array($xml_value)){
						foreach ($xml_value as $e_key => $e_value){
							$headers[$i] = $e_value['name'];
							$i++;
						}
					}
				}
				$response['success'] = true;
				$response['show_template'] = false;
				$response['csv_fields'] = $headers;
				if(!empty($media_type) && $import_type == 'Media'){
					$value = $this->media_mapping_fields($import_type,$mode,$media_type);
				}else{
					$value = $this->mapping_fields($import_type);
				}
				$response['currentuser']=$current_user_role;
				$response['fields'] = $value;
				$response['total_records'] = (int)$total_rows;
				echo wp_json_encode($response);
				wp_die();  			
			}
		}
	}
	public function media_mapping_fields($import_type,$mode =null,$media_type=null){
		MappingExtension::$extension_handler = new ExtensionHandler();
		$support_instance = [];
		if($import_type == 'Media') {
			if($media_type == 'local'){
				$wordpressfields = array(
					'File Name' => 'file_name',
					'Caption' => 'caption',
					'Alt text' => 'alt_text',
					'Desctiption' => 'description',
					'Title' => 'title',
					'Media ID' => 'media_id',
				);
				if(trim($mode) == 'Insert'){
					unset($wordpressfields['Media ID']);
				}
			}else{
				$wordpressfields = array(
					'Post ID' => 'post_id',
					'Media ID' => 'media_id',
					'Actual URL' => 'actual_url',
					'File Name' => 'file_name',
					'Title' => 'title',
					'Caption' => 'caption',
					'Alt text' => 'alt_text',
					'Desctiption' => 'description'		
				);
				if(trim($mode) == 'Insert'){
					unset($wordpressfields['Post ID']);
					unset($wordpressfields['Media ID']);
					
				}
			}
			
		}
		$wordpress_value = MappingExtension::$extension_handler->convert_static_fields_to_array($wordpressfields);
		$response[]['core_fields'] = $wordpress_value ;
		return $response;
	}


	/**
	 * Attach WooCommerce-native auto-mapping metadata when headers match WC format.
	 *
	 * @param array  $response    Response payload.
	 * @param string $hash_key    Import hash.
	 * @param string $import_type Import type.
	 * @return array
	 */
	private function maybe_enrich_wc_native_mapping( $response, $hash_key = '', $import_type = '' ) {
		if ( empty( $response['csv_fields'] ) || ! is_array( $response['csv_fields'] ) ) {
			return $response;
		}
		if ( ! class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\ImportBridge' ) ) {
			return $response;
		}
		$response = \Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\ImportBridge::enrich_mapping_response(
			$response,
			$response['csv_fields'],
			$hash_key,
			$import_type
		);
		if (
			! empty( $response['wc_native_skip_mapping'] )
			&& ! empty( $hash_key )
			&& class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\WcNativeImportRunner' )
		) {
			global $wpdb;
			$file_table = $wpdb->prefix . 'smackcsv_file_events';
			$file_name  = $wpdb->get_var( $wpdb->prepare( "SELECT file_name FROM {$file_table} WHERE hash_key = %s LIMIT 1", $hash_key ) );
			\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\WcNativeImportRunner::ensure_mapping_template(
				$hash_key,
				$import_type,
				(string) $file_name
			);
		}
		return $response;
	}

	public function mapping_fields($import_type, $process_type = null){
		// UI sends friendly labels (e.g. "ProfilePress MembershipPlan"); extensions expect canonical keys (PPRESS_*).
		$import_type = ExtensionHandler::getInstance()->import_type_as($import_type);
		$support_instance = [];
		$value = [];
		for($i = 0 ; $i < count(MappingExtension::$extension) ; $i++){
			$extension_instance = MappingExtension::$extension[$i];
			if($extension_instance->extensionSupportedImportType($import_type)){
				array_push($support_instance , $extension_instance);		
			}	
		}
		for($i = 0 ;$i < count($support_instance) ; $i++){	
			$supporting_instance = $support_instance[$i];
			$fields = $supporting_instance->processExtension($import_type, $process_type);
			if($process_type == 'Export'){
				if(is_array($fields)){
					if(array_key_exists('nextgen_gallery_fields',$fields)){
						continue;
					}
					else
						array_push($value , $fields);
				}
			}
			else{
				array_push($value , $fields);	
			}										
		}
		update_option('mapping_fields', $value);
		return $value;
	}

	/**
	* Ajax Call 
	* Provides all Widget Fields for Export Section
	* @return array - mapping fields
	*/
	public function get_export_fields() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		$import_type = sanitize_text_field($_POST['Types']);
		$response = [];

		$query_data = isset($_POST['query_data']) ? sanitize_text_field($_POST['query_data']) : '';
		$type       = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';

		if (empty($import_type) && $type === 'post') {
			$import_type = MappingExtension::$wpquery_export->getposttype($query_data);
		} elseif (empty($import_type) && $type === 'user') {
			$import_type = 'Users';
		} elseif (empty($import_type) && $type === 'comment') {
			$import_type = 'Comments';
		}

		$value           = $this->mapping_fields($import_type, 'Export');
		$categories_list = $this->get_categories_list($import_type);

		$response['success']    = true;
		$response['fields']     = $value;
		$response['cat_fields'] = $categories_list;

		global $wpdb;
		$results = $wpdb->get_results("SELECT meta_value FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities'");
		$roles   = [];

		foreach ($results as $row) {
			$capabilities = maybe_unserialize($row->meta_value);
			if (is_array($capabilities)) {
				$filtered = array_filter(array_keys($capabilities), function($key) {
					return !preg_match('/^(wpcf_|wpml_|translate)/', (string) $key);
				});

				if (!empty($filtered)) {
					$roles[] = $filtered[0];
				}
			}
		}

		$unique_roles            = array_unique($roles);
		$response['user_roles']  = array_values($unique_roles);

		if (function_exists('wc_get_products')) {
			$products = \wc_get_products([
				'limit'  => -1,
				'status' => 'publish',
				'return' => 'ids',
				'type'   => ['simple', 'variable', 'grouped', 'external'],
			]);
		} else {
			$products = [];
		}

		if (class_exists('\WC_Payment_Gateways')) {
			$gateways = \WC_Payment_Gateways::instance()->get_available_payment_gateways();
		} else {
			$gateways = [];
		}

		$payment = [];
		foreach ($gateways as $gateway) {
			$payment[] = $gateway->id;
		}

		$titles = [];
		if (function_exists('wc_get_product')) {
			foreach ($products as $product_id) {
				$product = \wc_get_product($product_id);
				if ($product) {
					$titles[] = $product->get_name();
				}
			}
		}

		$response['product_titles']  = $titles;
		$response['payment_methods'] = $payment;

		$product_types = [];
		if (function_exists('wc_get_product_types')) {
			foreach (\wc_get_product_types() as $type_slug => $type_label) {
				$product_types[] = [
					'value' => $type_slug,
					'label' => $type_label,
				];
			}
		}
		$response['product_types'] = $product_types;

		echo wp_json_encode($response);
		wp_die();
	}

	/**
	* Provides all Widget Fields for Export Section
	* @return array - categories list
	*/

	public function get_categories_list($import_type){
			$cat_fields = [];
		if($import_type == 'WooCommerce' || strpos($import_type, 'WooCommerce') !== false){
			$categories = get_terms( array('taxonomy'   => 'product_cat','hide_empty' => false,) );
			if ( ! empty( $categories ) ) {
				foreach ( $categories as $category ) {
					$cat_fields[] = $category->name;
				}
			}
		}
		elseif($import_type == 'lp_course'){
			$categories = get_categories( array('taxonomy'   => 'course_category','hide_empty' => false,) );
			if (!empty($categories)) {
				foreach ($categories as $category) {
					$cat_fields[] = $category->name;
				}
			}
		}
		elseif ($import_type == 'estate_property') {
			$taxonomies = [
				'property_category',
				'property_action_category',
				'property_city',
				'property_area',
				'property_features',
				'property_status',
			];
		
			foreach ($taxonomies as $taxonomy) {
				$categories = get_categories([
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				]);
		
				if (!empty($categories)) {
					foreach ($categories as $category) {
						$cat_fields[] = $category->name;
					}
				}
			}
		}
		elseif ($import_type == 'estate_agent') {
			$cat_fields[] ='';
		}
		 else{
			$categories = get_categories( array('taxonomy'   => 'category','hide_empty' => false,) );
			if (!empty($categories)) {
				foreach ($categories as $category) {
					$cat_fields[] = $category->name;
				}
			}
		}
			return $cat_fields;
	}

	public function get_categories_list_IDs($import_type) {
		
		if ($import_type == 'WooCommerce' || strpos($import_type, 'WooCommerce') !== false) {
			$categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
		} else {
			$categories = get_categories(array('taxonomy' => 'category', 'hide_empty' => false));
		}
		
		if (!empty($categories)) {
			foreach ($categories as $category) {
				$cat_fields[] = $category->term_id; // Store category ID instead of name
			}
		}
		
		return $cat_fields;
	}

	public function get_category_ids_from_names($category_names, $import_type): array {
		$cat_ids = [];
		if($import_type == 'WooCommerce' || strpos($import_type, 'WooCommerce') !== false){
			$taxonomy = 'product_cat';
		}else{
			$taxonomy = 'category';
		}
		foreach ($category_names as $category_name) {
			$term = get_term_by('name', $category_name, $taxonomy);
			if ($term) {
				$cat_ids[] = $term->term_id;
			}
		}
	
		return $cat_ids;
	}

	public function CustomPostCheck($post_type){
        $all_post_types = get_post_types([], 'names'); // Retrieve all post types
        if (in_array($post_type, $all_post_types)) {
			return true;
		}
		return false;
	}
	
	public function get_post_titles() {
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey'); // Ensure nonce security
	
		$response = [];
	
		// Get the post type from the AJAX request
		$raw_post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : 'post';
		
		$module_to_cpt = [
			'SURECART_PRODUCTS' => 'sc_product',
			'SURECART_ORDERS' => 'sc_order',
			'SURECART_CUSTOMERS' => 'sc_customer',
			'SURECART_SUBSCRIPTIONS' => 'sc_subscription',
			'SURECART_COUPONS' => 'sc_coupon',
			'WooCommerce' => 'product',
			'WooCommerceOrders' => 'shop_order',
			'WooCommerceCoupons' => 'shop_coupon',
			'WooCommerceVariations' => 'product_variation',
			'EDD_DOWNLOADS' => 'download',
		];

		$cpt = isset($module_to_cpt[$raw_post_type]) ? $module_to_cpt[$raw_post_type] : $raw_post_type;
		$post_titles = [];

		if (strpos($raw_post_type, 'SURECART_') !== false || strpos($cpt, 'sc_') !== false) {
			if (class_exists('\\Smackcoders\\UCI\\Proaddons\\UltimatePro\\SureCartExport')) {
				$post_titles = \Smackcoders\UCI\Proaddons\UltimatePro\SureCartExport::getInstance()->get_surecart_post_titles($raw_post_type);
			}
		} else {
			// Fetch local WP CPT post titles
			$posts = get_posts([
				'post_type'      => $cpt,
				'posts_per_page' => -1,
				'post_status'    => 'any',
				'fields'         => 'ids'
			]);

			if (!empty($posts)) {
				foreach ($posts as $post_id) {
					$post_obj = get_post($post_id);
					if ($post_obj && $post_obj->post_status !== 'trash' && !empty($post_obj->post_title)) {
						$post_titles[] = $post_obj->post_title;
					}
				}
			}
		}

		if (!empty($post_titles)) {
			$response['success'] = true;
			$response['post_titles'] = $post_titles;
		} else {
			$response['success'] = false;
			$response['message'] = 'No posts found for the selected post type.';
		}
	
		echo wp_json_encode($response);
		wp_die(); // Properly terminate AJAX request
	}

	/**
	* Provides all Widget Fields for Export Section
	* @return array - mapping fields
	*/
	public function get_fields($module){ 
		$import_type = $module;
		$response = [];

		$value = $this->mapping_fields($import_type, 'Export');
		$response['fields'] = $value;
		return $response;
	}


	/**
	* Ajax Call 
	* Provides mapped fields from Template
	* @return array - already mapped fields
	*/
	public function get_template_info(){
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		global $wpdb;	
		$template_name = isset($_POST['TemplateName']) ? sanitize_text_field($_POST['TemplateName']) : '';
		$import_type = sanitize_text_field($_POST['Types']);
		$hash_key = sanitize_key($_POST['HashKey']);
		if ( ! empty( $_POST['WcCsvFormat'] ) && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector' ) ) {
			\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector::store_user_format(
				$hash_key,
				sanitize_text_field( wp_unslash( $_POST['WcCsvFormat'] ) )
			);
		}
		if ( ! empty( $import_type ) && class_exists( '\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector' ) ) {
			\Smackcoders\UCI\Proaddons\UltimatePro\WooCommerceNative\FormatDetector::store_import_module( $hash_key, $import_type );
		}
		$requested_hash_key = $hash_key;
		$ai_status = ConnectorsHelper::get_status();
		$response = [];
		$file_name = '';
		$total_rows = 0;
		$template_event_key = '';
		$get_mapping = '';
		$get_mapping_filter = '';
		$mapping_type = '';
		$file_type = '';
		$result = [];
		$mapping_filter = [];
		$mode = isset($_POST['Mode']) ? sanitize_text_field($_POST['Mode']) : '';
		$media_type = '';
        if (isset($_POST['MediaType'])) {
            $media_type = sanitize_key($_POST['MediaType']);
        }
		$template_table_name = $wpdb->prefix . "ultimate_csv_importer_mappingtemplate";
		$table_name = $wpdb->prefix."smackcsv_file_events";
		$response['success'] = true;
		$response['get_key'] = $ai_status['configured'] ? 'configured' : '';
		$response['ai_status'] = $ai_status;
		if (!empty($hash_key)) {
			$total_rows = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT total_rows FROM $table_name WHERE hash_key = %s",
					$hash_key
				)
			);
		}
		$administratorRole = wp_get_current_user();
        $roles = $administratorRole->roles;
		$current_user_role = '';
		if (in_array('administrator', $roles)) {
			$current_user_role = 'administrator';
		}
		if(!empty($template_name)){
			$get_detail = $this->get_template_detail($template_table_name, $template_name, $import_type);
			if(!empty($get_detail)){
				$get_mapping = isset($get_detail[0]->mapping) ? $get_detail[0]->mapping : null;
				$get_mapping_filter = isset($get_detail[0]->mapping_filter) ? $get_detail[0]->mapping_filter : null;
				$mapping_type = $this->normalize_template_mapping_type(isset($get_detail[0]->mapping_type) ? $get_detail[0]->mapping_type : '');
				$file_name = isset($get_detail[0]->csvname) ? $get_detail[0]->csvname : null;
				$template_event_key = isset($get_detail[0]->eventKey) ? sanitize_key($get_detail[0]->eventKey) : '';
				$file_type = $file_name ? pathinfo($file_name, PATHINFO_EXTENSION) : null;
}

			if(empty($template_event_key) && !empty($template_name) && !empty($requested_hash_key)){
				$wpdb->update($template_table_name,array('eventKey' => $requested_hash_key),array('templatename' => trim($template_name)));
				$template_event_key = $requested_hash_key;
			}
			if(empty($hash_key)){
				if(!empty($file_name)){
					$hash_key = $wpdb->get_var(
						$wpdb->prepare(
							"SELECT hash_key FROM $table_name WHERE file_name = %s ORDER BY id DESC LIMIT 1",
							$file_name
						)
					);
				}
				if(empty($hash_key)){
					$hash_key = $template_event_key;
				}
				if (!empty($hash_key)) {
					$total_rows = (int) $wpdb->get_var(
						$wpdb->prepare(
							"SELECT total_rows FROM $table_name WHERE hash_key = %s",
							$hash_key
						)
					);
				}
			}
			$result = maybe_unserialize($get_mapping);
			$result = is_array($result) ? $result : [];
			$mapping_filter = maybe_unserialize($get_mapping_filter);
			foreach($result as $result_key => $result_val){
				if($result_key == 'ATTRMETA' && is_array($result_val)){
					foreach($result_val as $res => $rest){
						if(is_int($res)){
							$result[$result_key] =array();
						}
					}
					foreach($result_val as $res_key=>$res_value){
						if (is_int($res_key) && $result_key =="ATTRMETA") {
							//if($key == "ATTRMETA"){
								$result[$result_key] = array_merge($result[$result_key], $res_value);

							//}
						}
					}
					
				}
			}

			$response['already_mapped'] = $result;
			$response['currentuser']=$current_user_role;
			$response['mapping_type'] = $mapping_type;
			$response['mapping_filter'] = $mapping_filter;
			$response['file_type'] = $file_type;
			$response['hash_key'] = $hash_key;
		}
		if(empty($hash_key)){
			if($import_type == 'Media'){
				$hash_key = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT eventKey FROM $template_table_name WHERE templatename = %s AND module = %s",
						$template_name,
						'Media'
					)
				);
			}else{
				$hash_key = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT eventKey FROM $template_table_name WHERE templatename = %s",
						$template_name
					)
				);
			}
		}
		$get_result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT file_name, total_rows FROM $table_name WHERE hash_key = %s",
				$hash_key
			)
		);
		$filename = isset($get_result[0]->file_name) ? $get_result[0]->file_name : $file_name;
		if (isset($get_result[0]->total_rows)) {
			$total_rows = (int) $get_result[0]->total_rows;
		}
		
		if(empty($filename)){
			$filename = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT csvname FROM $template_table_name WHERE eventKey = %s",
					$hash_key
				)
			);
		}
		$file_extension = pathinfo($filename, PATHINFO_EXTENSION);
		if($file_extension == 'xlsx' ||  $file_extension == 'xls' || $file_extension == 'json'){
			$file_extension = 'csv';
		}
		if(empty($file_extension)){
			$file_extension = 'xml';
		}
		$response['file_type'] = $file_extension;
		
		$smackcsv_instance = UltimatePro::getInstance();
		$upload_dir = $smackcsv_instance->create_upload_dir();

		if($file_extension == 'csv' || $file_extension == 'txt'){
			if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
				if (!ini_get("auto_detect_line_endings")) {  // If auto_detect_line_endings is not enabled
					ini_set("auto_detect_line_endings", true);  // Enable it to handle different line endings
				}
			}
			$info = [];
			if (($h = fopen($upload_dir.$hash_key.'/'.$hash_key, "r")) !== FALSE) 
			{
			// Convert each line into the local $data variable
			$delimiters = array( ',','\t',';','|',':','&nbsp');
			$file_path = $upload_dir . $hash_key . '/' . $hash_key;
			$delimiter = MappingExtension::$validatefile->getFileDelimiter($file_path, 5);
			$array_index = array_search($delimiter,$delimiters);
			if($array_index == 5){
				$delimiters[$array_index] = ' ';
			}
			if($delimiter == '\t'){
				$delimiter ='~';
				 $temp=$file_path.'temp';
				 if (($handles = fopen($temp, 'r')) !== FALSE){
					while (($data = fgetcsv($handles, 0, $delimiter, '"', '\\')) !== FALSE)
					{
						// Read the data from a single line
						$trimmed_array = array_map('trim', $data);
						array_push($info , $trimmed_array);
						$exp_line = $info[0];									
						
						$response['csv_fields'] = $exp_line;					
						//$value = $this->mapping_fields($import_type);
						
						if(!empty($media_type) && $import_type == 'Media'){
							$value = $this->media_mapping_fields($import_type,$mode,$media_type);
						}else{
							$value = $this->mapping_fields($import_type);
						}


						$response['fields'] = $value;	
						$response['total_records'] = (int)$total_rows;				
						$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
						echo wp_json_encode($response);
						wp_die();  	
					}
				}
			}
			else{
				while (($data = fgetcsv($h, 0, $delimiters[$array_index], '"', '\\')) !== FALSE) 
				{		
					// Read the data from a single line
					$trimmed_array = array_map('trim', $data);
					array_push($info , $trimmed_array);
					$exp_line = $info[0];									
					
					$response['csv_fields'] = $exp_line;					
					if(!empty($media_type) && $import_type == 'Media'){
						$value = $this->media_mapping_fields($import_type,$mode,$media_type);
					}else{
						$value = $this->mapping_fields($import_type);
					}

					$response['fields'] = $value;	
					$response['total_records'] = (int)$total_rows;				
					$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
					echo wp_json_encode($response);
					wp_die();  			
				}	
				// Close the file
				fclose($h);
			}
			}
			
		}
		if($file_extension == 'tsv'){
			if (version_compare(PHP_VERSION, '8.1.0', '<')) {  // Only do this if PHP version is less than 8.1.0
				if (!ini_get("auto_detect_line_endings")) {  // If auto_detect_line_endings is not enabled
					ini_set("auto_detect_line_endings", true);  // Enable it to handle different line endings
				}
			}
			$info = [];
			if (($h = fopen($upload_dir.$hash_key.'/'.$hash_key, "r")) !== FALSE) 
			{
				$file_path = $upload_dir . $hash_key . '/' . $hash_key;
				$delimiter = MappingExtension::$validatefile->getFileDelimiter($file_path, 5);
				if($delimiter == '\t'){
					$hs = $upload_dir . $hash_key . '/' . $hash_key;
					$line =file($hs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
					$data = explode("\t", $line[0]); 
					$trimmed_array = array_map('trim', $data);
					array_push($info , $trimmed_array);
					$exp_line = $info[0];		
					$response['csv_fields'] = $exp_line;					
					if(!empty($media_type) && $import_type == 'Media'){
						$value = $this->media_mapping_fields($import_type,$mode,$media_type);
					}else{
						$value = $this->mapping_fields($import_type);
					}

					$response['fields'] = $value;	
					$response['total_records'] = (int)$total_rows;				
					$response = $this->maybe_enrich_wc_native_mapping( $response, $hash_key, $import_type );
					echo wp_json_encode($response);
					wp_die();
						
				}
			}
		}

		if($file_extension == 'xml'){
			$xml_class = new XmlHandler();
			
			$upload_dir_path = $upload_dir. $hash_key;
			if (!is_dir($upload_dir_path)) {
				wp_mkdir_p( $upload_dir_path);
			}
			chmod($upload_dir_path, 0777);   
			$path = $upload_dir . $hash_key . '/' . $hash_key; 
			$xml = simplexml_load_file($path);
			$xml_arr = json_decode( json_encode($xml) , 1);	
			foreach($xml->children() as $child){   
				$child_name = $child->getName();    
			}
			$parse_xml = $xml_class->parse_xmls($hash_key);
			$i = 0;
			$headers = [];
			foreach($parse_xml as $xml_key => $xml_value){
				if(is_array($xml_value)){
					foreach ($xml_value as $e_key => $e_value){
						$headers[$i] = $e_value['name'];
						$i++;
					}
				}
			}
			$response['show_template'] = false;
			$response['csv_fields'] = $headers;
			if(!empty($media_type) && $import_type == 'Media'){
				$value = $this->media_mapping_fields($import_type,$mode,$media_type);
			}else{
				$value = $this->mapping_fields($import_type);
			}
			$response['fields'] = $value;
			$response['total_records'] = (int)$total_rows;
			echo wp_json_encode($response);
			
			wp_die();  			
		}

		$response['show_template'] = false;
		$response['csv_fields'] = $this->extract_csv_fields_from_mapping($result);
		if(!empty($media_type) && $import_type == 'Media'){
			$value = $this->media_mapping_fields($import_type,$mode,$media_type);
		}else{
			$value = $this->mapping_fields($import_type);
		}
		$response['fields'] = $value;
		$response['total_records'] = (int)$total_rows;
echo wp_json_encode($response);
		wp_die();
	}

	private function get_template_detail($template_table_name, $template_name, $import_type){
		global $wpdb;

		if($import_type == 'Media'){
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT mapping, mapping_filter, csvname, mapping_type, eventKey, module FROM $template_table_name WHERE templatename = %s AND module = %s ORDER BY id DESC LIMIT 1",
					$template_name,
					'Media'
				)
			);
		}

		$get_detail = [];
		if(!empty($import_type)){
			$get_detail = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT mapping, mapping_filter, csvname, mapping_type, eventKey, module FROM $template_table_name WHERE templatename = %s AND module = %s ORDER BY id DESC LIMIT 1",
					$template_name,
					$import_type
				)
			);
		}

		if(empty($get_detail)){
			$get_detail = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT mapping, mapping_filter, csvname, mapping_type, eventKey, module FROM $template_table_name WHERE templatename = %s ORDER BY id DESC LIMIT 1",
					$template_name
				)
			);
		}

		return $get_detail;
	}

	private function normalize_template_mapping_type($mapping_type){
		$mapping_type = trim((string) $mapping_type);
		if($mapping_type === 'normal' || $mapping_type === ''){
			return 'mapping-section';
		}
		if($mapping_type === 'advanced'){
			return 'dragdrop-section';
		}
		return $mapping_type;
	}

	private function extract_csv_fields_from_mapping($mapping){
		$csv_fields = [];
		$this->collect_csv_fields_from_mapping($mapping, $csv_fields);
		return array_values(array_unique($csv_fields));
	}

	private function collect_csv_fields_from_mapping($mapping, &$csv_fields){
		if(!is_array($mapping)){
			return;
		}

		foreach($mapping as $key => $value){
			if(is_array($value)){
				$this->collect_csv_fields_from_mapping($value, $csv_fields);
				continue;
			}

			if(!is_scalar($value)){
				continue;
			}

			$value = trim((string) $value);
			if($value === '' || $value === 'Header Manipulation'){
				continue;
			}

			if(strpos((string) $key, '->') !== false){
				continue;
			}

			$csv_fields[] = $value;
		}
	}

	private function resolve_template_module($template, $fallback_module = ''){
		$module = isset($template->module) ? trim((string) $template->module) : '';
		if (!empty($module)) {
			return sanitize_text_field($module);
		}

		$fallback_module = trim((string) $fallback_module);
		if (!empty($fallback_module)) {
			return sanitize_text_field($fallback_module);
		}

		return $this->infer_module_from_mapping(isset($template->mapping) ? $template->mapping : '');
	}

	private function infer_module_from_mapping($mapping){
		$mapping_data = maybe_unserialize($mapping);
		if (!is_array($mapping_data)) {
			return '';
		}

		$registered_modules = array_merge(get_post_types([], 'names'), get_taxonomies([], 'names'));
		$mapped_values = $this->flatten_mapping_values($mapping_data);

		foreach ($mapped_values as $mapped_value) {
			$mapped_value = is_scalar($mapped_value) ? trim((string) $mapped_value) : '';
			if (!empty($mapped_value) && in_array($mapped_value, $registered_modules, true)) {
				return sanitize_text_field($mapped_value);
			}
		}

		return '';
	}

	private function flatten_mapping_values($mapping_data){
		$values = [];
		foreach ($mapping_data as $value) {
			if (is_array($value)) {
				$values = array_merge($values, $this->flatten_mapping_values($value));
			} else {
				$values[] = $value;
			}
		}

		return $values;
	}

	private function get_module_label($module){
		$module = trim((string) $module);
		if (empty($module)) {
			return __( 'Uncategorized', 'wp-ultimate-csv-importer' );
		}

		if (class_exists(__NAMESPACE__ . '\ExtensionHandler')) {
			$extension_handler = ExtensionHandler::getInstance();
			$import_modules = $extension_handler->get_import_post_types();
			foreach ($import_modules as $label => $value) {
				if ($module === $value || $module === $label) {
					return sanitize_text_field($label);
				}
			}
		}

		$post_type = get_post_type_object($module);
		if (!empty($post_type->labels->name)) {
			return sanitize_text_field($post_type->labels->name);
		}

		$taxonomy = get_taxonomy($module);
		if (!empty($taxonomy->labels->name)) {
			return sanitize_text_field($taxonomy->labels->name);
		}

		return ucwords(str_replace(['_', '-'], ' ', sanitize_text_field($module)));
	}

	/**
	* Provides mapped fields count from template
	* @param array $mappingList
	* @return int - count
	*/
	public function get_matched_count($mappingList, $templateName = null){
		$count = 0;

		//added
		$plugins_array = array(
			'ACF' => 'advanced-custom-fields/acf.php',
			'GF' => 'advanced-custom-fields-pro/acf.php',
			'RF' => 'advanced-custom-fields-pro/acf.php',
			'FC' => 'advanced-custom-fields-pro/acf.php',
			'ACFIMAGEMETA' => 'advanced-custom-fields-pro/acf.php',
			'TYPES' => 'types/wpcf.php',
			'TYPESIMAGEMETA' => 'types/wpcf.php',
			'PODS' => 'pods/init.php',
			'PODSIMAGEMETA' => 'pods/init.php',
			'CFS' => 'custom-field-suite/cfs.php',
			'AIOSEO' => 'all-in-one-seo-pack/all_in_one_seo_pack.php',
			'YOASTSEO' => 'wordpress-seo/wp-seo.php',
			'RANKMATH' => 'seo-by-rank-math/rank-math.php',
			'WPMEMBERS' => 'wp-members/wp-members.php',
			'ECOMMETA' => 'woocommerce/woocommerce.php',
			'BUNDLEMETA' => 'woocommerce-product-bundles/woocommerce-product-bundles.php',
			'LISTINGMETA' => 'woocommerce-product-bundles/woocommerce-product-bundles.php',
			'PRODUCTIMAGEMETA' => 'woocommerce/woocommerce.php',
			'ORDERMETA' => 'woocommerce/woocommerce.php',
			'COUPONMETA' => 'woocommerce/woocommerce.php',
			'REFUNDMETA' => 'woocommerce/woocommerce.php',
			'WPECOMMETA' => 'wp-e-commerce-custom-fields/custom-fields.php',
			'EVENTS' => 'events-manager/events-manager.php',
			'EventCalendarMeta' => 'the-events-calendar/the-events-calendar.php',
			'EventCalendarVenue' => 'the-events-calendar/the-events-calendar.php',
			'EventCalendarOrganizer' => 'the-events-calendar/the-events-calendar.php',
			'EventCalendarCustom' => 'events-calendar-pro/events-calendar-pro.php',
			'EventCalendarRecurrence' => 'events-calendar-pro/events-calendar-pro.php',
			'EventCalendarSeries' => 'events-calendar-pro/events-calendar-pro.php',
			'EventCalendarTickets' => 'event-tickets/event-tickets.php',
			'NEXTGEN' => 'nextgen-gallery/nggallery.php',
			'WPML' => 'wpml-multilingual-cms/sitepress.php',
			'CMB2' => 'cmb2/init.php',
			'JE' => 'jet-engine/jet-engine.php',
			'JERF' => 'jet-engine/jet-engine.php',
			'JECPT' => 'jet-engine/jet-engine.php',
			'JECPTRF' => 'jet-engine/jet-engine.php',
			'JECCT' => 'jet-engine/jet-engine.php',
			'JECCTRF' => 'jet-engine/jet-engine.php',
			'JETAX' => 'jet-engine/jet-engine.php',
			'JETAXRF' => 'jet-engine/jet-engine.php',
			'JEREL' => 'jet-engine/jet-engine.php',
			'LPCOURSE' => 'learnpress/learnpress.php',
			'LPCURRICULUM' => 'learnpress/learnpress.php',
			'LPLESSON' => 'learnpress/learnpress.php',
			'LPQUIZ' => 'learnpress/learnpress.php',
			'LPQUESTION' => 'learnpress/learnpress.php',
			'LPORDER' => 'learnpress/learnpress.php',
			'LIFTERLESSON' => 'lifterlms/lifterlms.php',
			'LIFTERCOURSE' => 'lifterlms/lifterlms.php',
			'LIFTERCOUPON' => 'lifterlms/lifterlms.php',
			'LIFTERQUIZ' => 'lifterlms/lifterlms.php',
			'STMCOURSE' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'STMCURRICULUM' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'STMLESSON' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'STMQUIZ' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'STMQUESTION' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'STMORDER' => 'masterstudy-lms-learning-management-system/masterstudy-lms-learning-management-system.php',
			'FORUM' => 'bbpress/bbpress.php',
			'TOPIC' => 'bbpress/bbpress.php',
			'REPLY' => 'bbpress/bbpress.php',
			'POLYLANG' => 'polylang/polylang.php',
		);
		if(is_plugin_active('advanced-custom-fields-pro/acf.php'))
		{
			$plugins_array['GF'] = 'advanced-custom-fields-pro/acf.php';
		}
		if(is_plugin_active('advanced-custom-fields/acf.php'))
		{
			$plugins_array['GF'] = 'advanced-custom-fields/acf.php';
		}
		else{
			if(is_plugin_active('secure-custom-fields/secure-custom-fields.php')){
				$plugins_array['GF'] = 'secure-custom-fields/secure-custom-fields.php';	
			}
		}
		foreach ($mappingList as $templatename => $group) {				
			//added condition to check whether mapped fields plugin is active or not, if not remove it from mapping
			if(array_key_exists($templatename, $plugins_array)){
				if($templatename == 'WPML'){
					if(!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'POLYLANG'){
					if(!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('polylang-pro/polylang.php')){						
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'RF' ){					
					if(!is_plugin_active($plugins_array[$templatename]) && (!is_plugin_active('advanced-custom-fields/acf.php') || !is_plugin_active('secure-custom-fields/secure-custom-fields.php'))){						
						unset($mappingList[$templatename]);
						continue;
					}
					elseif((is_plugin_active('advanced-custom-fields/acf.php') || is_plugin_active('secure-custom-fields/secure-custom-fields.php')) && !is_plugin_active('acf-repeater/acf-repeater.php')) {						
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'ACF'){
					if((!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('secure-custom-fields/secure-custom-fields.php'))&& !is_plugin_active('advanced-custom-fields-pro/acf.php')){
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'AIOSEO'){
					if(!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('all-in-one-seo-pack-pro/all_in_one_seo_pack.php')){
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'RANKMATH'){
					if(!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('seo-by-rank-math-pro/rank-math-pro.php')){
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif($templatename == 'YOASTSEO'){
					if(!is_plugin_active($plugins_array[$templatename]) && !is_plugin_active('wordpress-seo-premium/wp-seo-premium.php')){
						unset($mappingList[$templatename]);
						continue;
					}
				}
				elseif(!is_plugin_active($plugins_array[$templatename])){
					unset($mappingList[$templatename]);
					continue;
				}				
			}

			$count += count(array_filter($group));
		}
	
		//added - updated mapping in template table
		if(!empty($templateName)){
			global $wpdb;
			$template_table_name = $wpdb->prefix."ultimate_csv_importer_mappingtemplate";
			$mapping_fields = serialize($mappingList);
			$mapping_fields = $wpdb->_real_escape($mapping_fields);
			 $wpdb->get_results("UPDATE $template_table_name SET mapping ='$mapping_fields' WHERE templatename = '$templateName' ");
		}

		return $count;	
	}
	
	

	/**
	* Ajax Call 
	* Searches Templates based on Template Name and Dates
	* @return array - Template Details
	*/
	public function search_template(){
		check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');
		global $wpdb;
		$template_name = isset($_POST['TemplateName']) ? sanitize_text_field($_POST['TemplateName']) : '';
		$start_date = isset($_POST['FromDate']) ? sanitize_text_field($_POST['FromDate']) : '';
		$end_date = isset($_POST['ToDate']) ? sanitize_text_field($_POST['ToDate']) : '';
		$filename = isset($_POST['filename']) ? sanitize_text_field($_POST['filename']) : '';
		$module = isset($_POST['module']) ? sanitize_text_field($_POST['module']) : '';
		$info = [];
		$details = [];
		$where = ["templatename != ''"];
		$params = [];

		if (!empty($module)) {
			$where[] = "(module = %s OR ((module IS NULL OR module = '') AND csvname = %s))";
			$params[] = $module;
			$params[] = $filename;
		} elseif (!empty($filename)) {
			$where[] = "csvname = %s";
			$params[] = $filename;
		}

		if ($start_date !== 'Invalid date' && !empty($start_date)) {
			$where[] = 'createdtime >= %s';
			$params[] = $start_date . ' 00:00:00';
		}

		if ($end_date !== 'Invalid date' && !empty($end_date)) {
			$where[] = 'createdtime <= %s';
			$params[] = $end_date . ' 23:59:59';
		}

		if (!empty($template_name)) {
			$where[] = 'templatename LIKE %s';
			$params[] = '%' . $wpdb->esc_like($template_name) . '%';
		}

		$query = "SELECT id, templatename, createdtime, module, mapping, csvname FROM {$wpdb->prefix}ultimate_csv_importer_mappingtemplate WHERE " . implode(' AND ', $where) . " ORDER BY id DESC";
		$templateList = !empty($params) ? $wpdb->get_results($wpdb->prepare($query, $params)) : $wpdb->get_results($query);
		
		if(!empty($templateList)){
			foreach($templateList as $value){
				$details = [];
				$templateName = $value->templatename;
		
				if(!empty($templateName)){					
					$module_name = $this->resolve_template_module($value, $module);
					$details['template_name'] = $templateName;
					$details['module'] = $module_name;
					$details['module_label'] = $this->get_module_label($module_name);
					$details['created_time'] = $value->createdtime;
					$mapping = $value->mapping;
					$map = maybe_unserialize($mapping);
					$map = is_array($map) ? $map : [];
					$count = $this->get_matched_count($map);
					$details['count'] = $count;	
					array_push($info , $details);
				}	
			}
			$response['success'] = true;
			$response['info'] = $info;
		}else{
			$response['success'] = false;
			$response['message'] = "Templates not found";
		}
		echo wp_json_encode($response);
		wp_die(); 	
	}
	

}	