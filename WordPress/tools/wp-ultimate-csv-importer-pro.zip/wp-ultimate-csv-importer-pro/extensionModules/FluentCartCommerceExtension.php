<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) )
    exit; 

class FluentCartCommerceExtension extends ExtensionHandler {

    private static $instance = null;

    public static function getInstance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Process FluentCart extension and return field mappings
     *
     * @param string $data - selected import type
     * @return array - mapping fields per module
     */
    public function processExtension( $data ) {
        $import_type = $this->import_name_as( $data );
        $fluentcartFields   = [];
        $resultKey   = '';

        switch ( $import_type ) {

            case 'FLUENTCART_PRODUCTS':
            // case 'CustomPosts':
                $fluentcartFields = [
                   
                    // FLuentcart products_details table
                    'Fulfillment Type'          => 'fulfillment_type', // in variation table  "fulfillment_type"
                    'Min Price'                 => 'min_price',
                    'Max Price'                 => 'max_price',
                    'Default Variation Id'      => 'default_variation_id',
                    'Default Media'             => 'default_media',
                    'Manage Stock'              => 'manage_stock',// in variation table "manage_stock"
                    'Stock Availablility'       => 'stock_availability', // in variation table "stock_status"
                    'Variation Type'            => 'variation_type',
                    'Manage Downloadable'       => 'manage_downloadable',
                    'Other Info'                => 'other_info',
                    'Created at'                => 'created_at', // in variation table "created_at"
                    'Updated at'                => 'updated_at',// in variation table "updated_at"
                    //// FLuentcart products_variations table 
                    'Variation Id'              => 'variation_id',
                    'Media Id'                  => 'media_id',
                    'Serial Index'              => 'serial_index',
                    'Sold Individually'         => 'sold_individually',
                    'Variation Title'           => 'variation_title',
                    'Variation Identifier'      => 'variation_identifier',
                    'Payment Type'              => 'payment_type',
                    'Variation Stock status'    => 'stock_status',
                    'Variation Stock'           => 'variation_manage_stock',
                    'Backorders'                => 'backorders',
                    'Total Stock'               => 'total_stock',
                    'On Hold'                   => 'on_hold',
                    'Committed'                 => 'committed',
                    'Available'                 => 'available',
                    'Item Status'               => 'item_status',
                    'Manage Cost'               => 'manage_cost',
                    'Item Price'                => 'item_price',
                    'Item Cost'                 => 'item_cost',
                    'Compare Price'             => 'compare_price',
                    'Shipping Class'            => 'shipping_class',
                    'Variation Other info'      => 'variation_other_info',
                    'Variation is Downloadable' => 'variation_downloadable',
                    
                    //product meta table
                    'Object Type'               => 'object_type',
                    'Meta Key'                  => 'meta_key',
                    'Meta Value'                => 'meta_value',

                    // product download table
                    'Download Product Variation Id' => 'download_product_variation_id',
                    'Download Identifier'           => 'download_identifier',
                    'Download Title'                => 'download_title',
                    'Download Type'                 => 'download_type',
                    'Download Driver'               => 'download_driver',
                    'Download File Name'            => 'download_file_name',
                    'Download File Path'            => 'download_file_path',
                    'Download File Url'             => 'download_file_url',
                    'Download File Size'            => 'download_file_size',
                    'Download Settings'             => 'download_settings',
                    'Download Serial'               => 'download_serial',
                    'Download Created At'           => 'download_created_at',
                    'Download Updated At'           => 'download_updated_at',
                    
                   
                ];
                $resultKey = 'FLUENTCART_PRODUCTS';
                break;

            case 'FLUENTCART_ORDERS':

                $fluentcartFields = [

                'Order ID'=>'order_id',
                'Order UUID'=>'uuid',
                'Receipt Number'=>'receipt_number',
                'Invoice Number'=>'invoice_no',
                'Created At'=>'created_at',
                'Updated At'=>'updated_at',

                'Customer ID'=>'customer_id',
                'Order Status'=>'order_status',
                'Payment Status'=>'payment_status',
                'Payment Method'=>'payment_method',
                'Payment Method Title'=>'payment_method_title',
                'Currency'=>'currency',

                'Subtotal'=>'subtotal',
                'Manual Discount'=>'manual_discount_total',
                'Coupon Discount'=>'coupon_discount_total',
                'Shipping Tax'=>'shipping_tax',
                'Shipping Total'=>'shipping_total',
                'Tax Total'=>'tax_total',
                'Total Amount'=>'total_amount',
                'Total Paid'=>'total_paid',

                'Order Type'=>'order_type',
                'Order Mode'=>'order_mode',
                'Fulfillment Type'=>'order_fulfillment_type',

                'Ordered Items'=>'ordered_items',
                'Order Meta'=>'order_meta',
                'Transactions'=>'transactions',

                'Billing Name'=>'billing_name',
                'Billing Address 1'=>'billing_address_1',
                'Billing Address 2'=>'billing_address_2',
                'Billing City'=>'billing_city',
                'Billing State'=>'billing_state',
                'Billing Postcode'=>'billing_postcode',
                'Billing Country'=>'billing_country',

                'Shipping Name'=>'shipping_name',
                'Shipping Address 1'=>'shipping_address_1',
                'Shipping Address 2'=>'shipping_address_2',
                'Shipping City'=>'shipping_city',
                'Shipping State'=>'shipping_state',
                'Shipping Postcode'=>'shipping_postcode',
                'Shipping Country'=>'shipping_country',

                ];

                $resultKey='FLUENTCART_ORDERS';
                break;

            case 'FLUENTCART_CUSTOMERS':
                $fluentcartFields = [
                    //`wp_fct_customers` data
                    'ID'                        => 'ID',
                    'WP user ID'                => 'user_id',
                    'Contact ID'                => 'contact_id',
                    'Login Email'               => 'login_email',
                    'First Name'                => 'first_name',
                    'Last Name'                 => 'last_name',
                    'status'                    => 'status',
                    'Purchase Value'            => 'purchase_value',
                    'Purchase Count'            => 'purchase_count',
                    'Ltv'                       => 'ltv',
                    'First Purchase Date'       => 'first_purchase_date',
                    'Laste Purchase Date'       => 'last_purchase_date',
                    'AOV'                       => 'aov',
                    'Notes'                     => 'notes',
                    'UUID'                      => 'uuid',
                    'Country'                   => 'country',
                    'City'                      => 'city',
                    'State'                     => 'state',
                    'PostCode'                  => 'postcode',
                    'Created at'                => 'created_at',
                    'Updated at'                => 'updated_at',
                    //`wp_fct_customer_addresses` data
                    'Is Primary Address'        => 'address_is_primary',
                    'Email Type'                => 'address_type',
                    'Address Status'            => 'address_status',
                    'Address Label'             => 'address_label',
                    'Address Name'              => 'address_name',
                    'Address 1'                 => 'address_1',
                    'Address 2'                 => 'address_2',
                    'Address City'              => 'address_city',
                    'Address State'             => 'address_state',
                    'Address Phone'             => 'address_phone',
                    'Address Email'             => 'address_email',
                    'Address Postcode'          => 'address_postcode',
                    'Address Country'           => 'address_country',
                    'Address Meta'              => 'address_meta',
                    'Address Created at'        => 'address_created_at',
                    'Address Updated at'        => 'address_updated_at',
                    //`wp_fct_customer_meta` data
                    'Meta Key'                  => 'meta_key',
                    'Meta Value'                => 'meta_value',
                    'Meta Created At'           => 'meta_created_at',
                    'Meta Updated At'           => 'meta_updated_at',

                    //`wp_users` data
                    'WP user table data'                => 'wp_core_user_data',
                    
                ];
                $resultKey = 'FLUENTCART_CUSTOMERS';
                break;

            case 'FLUENTCART_SUBSCRIPTIONS':
                $fluentcartFields = [
                    'Subscription ID'           => 'subscription_id',
                    'Customer ID'               => 'customer_id',
                    'Customer Email'            => 'customer_email',
                    'Product ID'                => 'product_id',
                    'Product Name'              => 'product_name',
                    'Order ID'                  => 'order_id',
                    'Status'                    => 'subscription_status',
                    'Interval'                  => 'interval',
                    'Period'                    => 'period',
                    'Price'                     => 'price',
                    'Start Date'                => 'start_date',
                    'End Date'                  => 'end_date',
                    'Next Payment Date'         => 'next_payment_date',
                    'Trial End Date'            => 'trial_end_date',
                    'Cancel Date'               => 'cancel_date',
                    'Cancel Reason'             => 'cancel_reason',
                    'Billing Cycle Count'       => 'billing_cycle_count',
                    'Total Payments'            => 'total_payments',
                    'Subscription Meta'         => 'subscription_meta'
                ];
                $resultKey = 'FLUENTCART_SUBSCRIPTIONS';
                break;

            case 'FLUENTCART_COUPONS':
                $fluentcartFields = [
                    'Coupon ID'                 => 'ID',
                    'Coupon Title'              => 'coupon_title',
                    'Coupon Code'               => 'coupon_code',
                    'Priority'                  => 'coupon_priority',
                    'Discount Type'             => 'discount_type',
                    
                    'Maximum Uses'              => 'max_uses_limit',
                    'Buy Quantity'              => 'buy_quantity',
                    'Get Quantity'              => 'get_quantity',
                    'Is Recurring'              => 'is_recurring',
                    'Usage Limit Per User'      => 'usage_limit_per_user',
                    'Apply to Quantity'         => 'apply_to_quantity',
                    'Excluded Products'         => 'excluded_products',
                    'Included Products'         => 'included_products',
                    'Email Restrictions'        => 'email_restrictions',
                    'Apply to Whole Cart'       => 'apply_to_whole_cart',
                    'Included Categories'       => 'included_categories',
                    'Excluded Categories'       => 'excluded_categories',
                    'Maximum Discount Amount'   => 'max_discount_amount',
                    'Maximum Purchase Amount'   => 'maximum_amount',
                    'Minimum Purchase Amount'   => 'minimum_amount',
                    
                    'Discount Amount'           => 'discount_amount',
                    'Usage Count'               => 'usage_count',
                    'Discount Status'           => 'status',
                    'Coupon notes'              => 'coupon_notes',
                    'Coupon is Stockable'       => 'coupon_stackable',
                    'Show on Checkout'          => 'coupon_show_on_checkout',
                    'Start Date'                => 'start_date',
                    'End Date'                  => 'end_date',
                    'Coupon Created At'         => 'created_at',
                    'Coupon Updated At'         => 'updated_at',
                ];
                $resultKey = 'FLUENTCART_COUPONS';
                break;
                        case 'FLUENTCART_DOWNLOADS':
                $fluentcartFields = [
                    'Download ID'                => 'download_id',
                    'Product ID'                => 'product_id',
                    'Product Name'              => 'product_name',
                    'File Name'                 => 'file_name',
                    'File URL'                  => 'file_url',
                    'Download Limit'            => 'download_limit',
                    'Download Expiry'           => 'download_expiry',
                    'License Key'               => 'license_key',
                    'Activation Limit'          => 'activation_limit',
                    'License Status'            => 'license_status',
                    'Customer ID'                => 'customer_id',
                    'Customer Email'            => 'customer_email',
                    'Order ID'                  => 'order_id',
                    'Date Created'              => 'date_created',
                    'Date Expires'              => 'date_expires',
                    'Download Count'            => 'download_count',
                    'Download Meta'             => 'download_meta'
                ];
                $resultKey = 'FLUENTCART_DOWNLOADS';
                break;

            case 'FLUENTCART_REPORTS':
                $fluentcartFields = [
                    'Report Date'               => 'report_date',
                    'Order Count'               => 'order_count',
                    'Total Earnings'            => 'total_earnings',
                    'Total Tax'                 => 'total_tax',
                    'Total Shipping'            => 'total_shipping',
                    'Gateway'                   => 'gateway',
                    'Product ID'                => 'product_id',
                    'Product Name'              => 'product_name'
                ];
                $resultKey = 'FLUENTCART_REPORTS';
                break;



            default:
                return [];
        }

        $mapping_array = $this->convert_static_fields_to_array( $fluentcartFields );
        // error_log("return data : ".print_r($mapping_array,true));
        // error_log("return data key : ".$resultKey);
        return [
            $resultKey => $mapping_array
        ];
    }

    /**
     * FluentCart extension supported import types
     *
     * @param string $import_type
     * @return boolean
     */
    public function extensionSupportedImportType( $import_type ) {

        if ( ! is_plugin_active( 'fluent-cart/fluent-cart.php' ) ) {
            return false;
        }

        if ( $import_type === 'nav_menu_item' ) {
            return false;
        }

        $import_type = $this->import_name_as( $import_type );
        // error_log("import_type : ".$import_type);
        $supported = [
            'FLUENTCART_PRODUCTS',
            'FLUENTCART_ORDERS',
            'FLUENTCART_CUSTOMERS',
            'FLUENTCART_SUBSCRIPTIONS',
            'FLUENTCART_COUPONS',
            'FLUENTCART_DOWNLOADS',
            'FLUENTCART_REPORTS',
            // 'CustomPosts'
        ];

        $is_supported = in_array( $import_type, $supported, true );

        return $is_supported;
    }
}

