<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Mapping widgets for The Events Calendar / Events Calendar Pro / Event Tickets.
 */
class EventCalendarExtension extends ExtensionHandler {

	private static $instance = null;

	/**
	 * Supported TEC CPT aliases used across import / export UI.
	 *
	 * @var string[]
	 */
	public static $supported_types = array(
		'tribe_events',
		'tribe_venue',
		'tribe_organizer',
		'tribe_event_series',
		'Events Calendar',
		'Event Venues',
		'Event Organizers',
		'Event Series',
	);

	public static function getInstance() {
		if ( EventCalendarExtension::$instance == null ) {
			EventCalendarExtension::$instance = new EventCalendarExtension();
		}
		return EventCalendarExtension::$instance;
	}

	/**
	 * Whether The Events Calendar is active.
	 *
	 * @return bool
	 */
	public static function is_tec_active() {
		return is_plugin_active( 'the-events-calendar/the-events-calendar.php' )
			|| class_exists( 'Tribe__Events__Main' );
	}

	/**
	 * Whether Events Calendar Pro is active.
	 *
	 * @return bool
	 */
	public static function is_tec_pro_active() {
		return is_plugin_active( 'events-calendar-pro/events-calendar-pro.php' )
			|| class_exists( 'Tribe__Events__Pro__Main' );
	}

	/**
	 * Whether Event Tickets is active.
	 *
	 * @return bool
	 */
	public static function is_event_tickets_active() {
		return is_plugin_active( 'event-tickets/event-tickets.php' )
			|| class_exists( 'Tribe__Tickets__Main' );
	}

	/**
	 * Normalize friendly labels to CPT slugs.
	 *
	 * @param string $import_type Import type label or slug.
	 * @return string
	 */
	public static function normalize_type( $import_type ) {
		$map = array(
			'Events Calendar'  => 'tribe_events',
			'Event Venues'     => 'tribe_venue',
			'Event Organizers' => 'tribe_organizer',
			'Event Series'     => 'tribe_event_series',
		);
		return isset( $map[ $import_type ] ) ? $map[ $import_type ] : $import_type;
	}

	/**
	 * Provides Events Calendar mapping fields for the selected import type.
	 *
	 * @param string $data Selected import type.
	 * @return array
	 */
	public function processExtension( $data ) {
		$response = array();

		if ( ! self::is_tec_active() ) {
			return $response;
		}

		$type = self::normalize_type( $data );

		if ( 'tribe_events' === $type ) {
			$response['eventcalendar_meta_fields']       = $this->convert_static_fields_to_array( $this->get_event_detail_fields() );
			$response['eventcalendar_venue_fields']      = $this->convert_static_fields_to_array( $this->get_event_venue_fields() );
			$response['eventcalendar_organizer_fields']  = $this->convert_static_fields_to_array( $this->get_event_organizer_fields() );

			if ( self::is_tec_pro_active() ) {
				$custom = $this->get_pro_custom_fields();
				if ( ! empty( $custom ) ) {
					$response['eventcalendar_custom_fields'] = $this->convert_static_fields_to_array( $custom );
				}
				$response['eventcalendar_recurrence_fields'] = $this->convert_static_fields_to_array( $this->get_recurrence_fields() );
				$response['eventcalendar_series_fields']     = $this->convert_static_fields_to_array( $this->get_series_fields() );
			}

			if ( self::is_event_tickets_active() ) {
				$response['eventcalendar_tickets_fields'] = $this->convert_static_fields_to_array( $this->get_tickets_fields() );
			}
		} elseif ( 'tribe_venue' === $type ) {
			$response['eventcalendar_venue_fields'] = $this->convert_static_fields_to_array( $this->get_standalone_venue_fields() );
		} elseif ( 'tribe_organizer' === $type ) {
			$response['eventcalendar_organizer_fields'] = $this->convert_static_fields_to_array( $this->get_standalone_organizer_fields() );
		} elseif ( 'tribe_event_series' === $type && self::is_tec_pro_active() ) {
			$response['eventcalendar_series_fields'] = $this->convert_static_fields_to_array( $this->get_standalone_series_fields() );
		}

		return $response;
	}

	/**
	 * Core event detail / date / cost / visibility / virtual fields.
	 *
	 * @return array
	 */
	private function get_event_detail_fields() {
		$fields = array(
			'Event Start Date'       => '_EventStartDate',
			'Event Start Time'       => 'event_start_time',
			'Event End Date'         => '_EventEndDate',
			'Event End Time'         => 'event_end_time',
			'Event Start Date UTC'   => '_EventStartDateUTC',
			'Event End Date UTC'     => '_EventEndDateUTC',
			'Event All Day'          => '_EventAllDay',
			'Event Timezone'         => '_EventTimezone',
			'Event Timezone Abbr'    => '_EventTimezoneAbbr',
			'Event Timezone Mode'    => 'event_timezone_mode',
			'Event Cost'             => '_EventCost',
			'Event Currency Symbol'  => '_EventCurrencySymbol',
			'Event Currency Code'    => '_EventCurrencyCode',
			'Event Currency Position'=> '_EventCurrencyPosition',
			'Event URL'              => '_EventURL',
			'Event Show Map'         => '_EventShowMap',
			'Event Show Map Link'    => '_EventShowMapLink',
			'Event Hide From Upcoming' => '_EventHideFromUpcoming',
			'Featured Event'         => '_tribe_featured',
			'Event Status'           => '_tribe_events_status',
			'Event Status Reason'    => '_tribe_events_status_reason',
			'Event Origin'           => '_EventOrigin',
			'Event Venue ID'         => '_EventVenueID',
			'Event Organizer ID'     => '_EventOrganizerID',
		);

		if ( self::is_tec_pro_active() ) {
			$fields['Is Virtual Event']              = '_tribe_events_is_virtual';
			$fields['Is Hybrid Event']               = '_tribe_events_is_hybrid';
			$fields['Virtual Event Type']            = '_tribe_virtual_events_type';
			$fields['Virtual Event URL']             = '_tribe_events_virtual_url';
			$fields['Virtual Video Source']          = '_tribe_events_virtual_video_source';
			$fields['Virtual Embed Video']           = '_tribe_events_virtual_embed_video';
			$fields['Virtual Linked Button']         = '_tribe_events_virtual_linked_button';
			$fields['Virtual Linked Button Text']    = '_tribe_events_virtual_linked_button_text';
			$fields['Virtual Show Embed At']         = '_tribe_events_virtual_show_embed_at';
			$fields['Virtual Show On Event']         = '_tribe_events_virtual_show_on_event';
			$fields['Virtual Show On Views']         = '_tribe_events_virtual_show_on_views';
		}

		return $fields;
	}

	/**
	 * Venue fields nested under event import.
	 *
	 * @return array
	 */
	private function get_event_venue_fields() {
		return array(
			'Venue ID'          => 'event_venue_id',
			'Venue Name'        => 'event_venue_name',
			'Venue Description' => 'event_venue_description',
			'Venue Address'     => 'event_venue_address',
			'Venue City'        => 'event_venue_city',
			'Venue State'       => 'event_venue_state',
			'Venue Province'    => 'event_venue_province',
			'Venue ZIP'         => 'event_venue_zip',
			'Venue Country'     => 'event_venue_country',
			'Venue Phone'       => 'event_venue_phone',
			'Venue Website'     => 'event_venue_website',
			'Venue Latitude'    => 'event_venue_lat',
			'Venue Longitude'   => 'event_venue_lng',
			'Venue Show Map'    => 'event_venue_show_map',
			'Venue Show Map Link' => 'event_venue_show_map_link',
		);
	}

	/**
	 * Organizer fields nested under event import.
	 *
	 * @return array
	 */
	private function get_event_organizer_fields() {
		return array(
			'Organizer ID'          => 'event_organizer_id',
			'Organizer Name'        => 'event_organizer_name',
			'Organizer Description' => 'event_organizer_description',
			'Organizer Phone'       => 'event_organizer_phone',
			'Organizer Email'       => 'event_organizer_email',
			'Organizer Website'     => 'event_organizer_website',
		);
	}

	/**
	 * Standalone venue CPT fields.
	 *
	 * @return array
	 */
	private function get_standalone_venue_fields() {
		return array(
			'Venue Address'      => '_VenueAddress',
			'Venue City'         => '_VenueCity',
			'Venue State'        => '_VenueState',
			'Venue Province'     => '_VenueProvince',
			'Venue StateProvince'=> '_VenueStateProvince',
			'Venue ZIP'          => '_VenueZip',
			'Venue Country'      => '_VenueCountry',
			'Venue Phone'        => '_VenuePhone',
			'Venue Website'      => '_VenueURL',
			'Venue Latitude'     => '_VenueLat',
			'Venue Longitude'    => '_VenueLng',
			'Venue Show Map'     => '_VenueShowMap',
			'Venue Show Map Link'=> '_VenueShowMapLink',
		);
	}

	/**
	 * Standalone organizer CPT fields.
	 *
	 * @return array
	 */
	private function get_standalone_organizer_fields() {
		return array(
			'Organizer Phone'   => '_OrganizerPhone',
			'Organizer Email'   => '_OrganizerEmail',
			'Organizer Website' => '_OrganizerWebsite',
		);
	}

	/**
	 * Recurrence fields (Events Calendar Pro).
	 *
	 * @return array
	 */
	private function get_recurrence_fields() {
		return array(
			'Recurrence Type'           => 'recurrence_type',
			'Recurrence Interval'       => 'recurrence_interval',
			'Recurrence Weekdays'       => 'recurrence_weekdays',
			'Recurrence Month Day'      => 'recurrence_month_day',
			'Recurrence Month Number'   => 'recurrence_month_number',
			'Recurrence Year Month'     => 'recurrence_year_month',
			'Recurrence End Type'       => 'recurrence_end_type',
			'Recurrence End Count'      => 'recurrence_end_count',
			'Recurrence End Date'       => 'recurrence_end_date',
			'Recurrence Exclusions'     => 'recurrence_exclusions',
			'Recurrence Additional Dates' => 'recurrence_additional_dates',
			'Recurrence Description'    => 'recurrence_description',
			'Recurrence iCal Rule'      => 'recurrence_ical',
		);
	}

	/**
	 * Series fields nested under event import.
	 *
	 * @return array
	 */
	private function get_series_fields() {
		return array(
			'Event Series ID'    => 'event_series_id',
			'Event Series Title' => 'event_series_title',
		);
	}

	/**
	 * Standalone series CPT fields.
	 *
	 * @return array
	 */
	private function get_standalone_series_fields() {
		return array(
			'Series Event IDs' => 'series_event_ids',
		);
	}

	/**
	 * Event Tickets event-level fields (capacity / global stock).
	 *
	 * @return array
	 */
	private function get_tickets_fields() {
		return array(
			'Ticket Use Global Stock'   => '_tribe_ticket_use_global_stock',
			'Ticket Global Stock Level' => '_tribe_ticket_global_stock_level',
		);
	}

	/**
	 * Dynamically discover Events Calendar Pro additional fields.
	 *
	 * @return array Label => meta key.
	 */
	private function get_pro_custom_fields() {
		$fields = array();
		if ( ! function_exists( 'tribe_get_option' ) ) {
			return $fields;
		}

		$custom_fields = tribe_get_option( 'custom-fields', array() );
		if ( empty( $custom_fields ) || ! is_array( $custom_fields ) ) {
			return $fields;
		}

		foreach ( $custom_fields as $field ) {
			if ( empty( $field['name'] ) ) {
				continue;
			}
			$label = ! empty( $field['label'] ) ? $field['label'] : $field['name'];
			$type  = ! empty( $field['type'] ) ? ' (' . $field['type'] . ')' : '';
			$fields[ $label . $type ] = $field['name'];
		}

		return $fields;
	}

	/**
	 * Whether this extension supports the selected import type.
	 *
	 * @param string $import_type Selected import type.
	 * @return bool
	 */
	public function extensionSupportedImportType( $import_type ) {
		if ( ! self::is_tec_active() ) {
			return false;
		}

		if ( 'nav_menu_item' === $import_type ) {
			return false;
		}

		$type = self::normalize_type( $import_type );

		if ( in_array( $type, array( 'tribe_events', 'tribe_venue', 'tribe_organizer' ), true ) ) {
			return true;
		}

		if ( 'tribe_event_series' === $type && self::is_tec_pro_active() ) {
			return true;
		}

		return false;
	}
}
