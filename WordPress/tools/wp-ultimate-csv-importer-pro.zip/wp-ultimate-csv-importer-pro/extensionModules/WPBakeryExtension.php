<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPBakeryExtension extends ExtensionHandler {

	private static $instance = null;

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new WPBakeryExtension();
		}
		return self::$instance;
	}

	/**
	 * @param string $data Selected import type label or slug.
	 * @return array
	 */
	public function processExtension( $data ) {
		$pro_meta_fields = array();
		$import_type = $this->import_name_as( $data );
		if ( self::is_wpbakery_active() ) {
			if ( in_array( $import_type, array( 'vc_templates', 'Posts', 'Pages', 'WooCommerce', 'CustomPosts' ), true ) ) {
				$pro_meta_fields = array(
					'Page Template'          => '_wp_page_template',
					'WPBakery Status'        => '_wpb_vc_js_status',
					'WPBakery Editor Type'   => '_wpb_vc_editor_type',
					'WPBakery Custom Layout' => '_wpb_post_custom_layout',
					'WPBakery Default CSS Updated' => '_wpb_shortcodes_default_css_updated',
					'WPBakery Shortcode CSS Updated' => '_wpb_shortcodes_custom_css_updated',
					'WPBakery Default CSS'  => '_wpb_shortcodes_default_css',
					'WPBakery Custom JS Header' => '_wpb_post_custom_js_header',
					'Media Files'            => 'media_files',
					'Custom CSS'             => '_wpb_post_custom_css',
					'Shortcode CSS'          => '_wpb_shortcodes_custom_css',
				);
			}
		}

		$pro_meta_fields_line = $this->convert_static_fields_to_array( $pro_meta_fields );
		$response = array(
			'wpbakery_meta_fields' => $pro_meta_fields_line,
		);

		return $response;
	}

	/**
	 * @param string $import_type
	 * @return bool
	 */
	public function extensionSupportedImportType( $import_type ) {
		$import_type = $this->import_name_as( $import_type );
		if ( self::is_wpbakery_active() ) {
			if ( in_array( $import_type, array( 'vc_templates', 'Pages', 'Posts', 'WooCommerce', 'CustomPosts' ), true ) ) {
				return true;
			}
		}
		return false;
	}

	public static function is_wpbakery_active() {
		return is_plugin_active( 'js_composer/js_composer.php' )
			|| function_exists( 'vc_map' )
			|| defined( 'WPB_VC_VERSION' );
	}
}
