<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\UCI\Proaddons\UltimatePro;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ProfilePressExtension extends ExtensionHandler {
	protected static $instance = null;
	/** @var array<string, array<int, string>> Cached DB columns per table */
	private static $schema_cache = [];
	/** @var array<string, int> */
	private static $cache_attachment_by_sha1 = [];
	/** @var array<string, int> */
	private static $cache_attachment_by_filename = [];
	/** @var array<int, int> user_id => customer_id */
	private static $cache_customer_id_by_user = [];
	/** @var array<string, int> plan_name(lower) => plan_id */
	private static $cache_plan_id_by_name = [];
	/** @var array<int, string> plan_id => plan_name */
	private static $cache_plan_name_by_id = [];

	// Standard WP user meta keys that ProfilePress also displays
	const STANDARD_USER_FIELDS = [
		'first_name',
		'last_name',
		'nickname',
		'description',
		'user_url',
	];

	// Fields stored in wp_ppress_customers
	const CUSTOMER_TABLE_FIELDS = [
		'total_spend',
		'purchase_count',
		'last_login',
	];

	// Subscription source meta keys (mapped in WP Ultimate CSV Importer Pro).
	// ProfilePress subscription tables are created/updated from these.
	const SUBSCRIPTION_META_KEYS = [
		'pp_member_type',
		'pp_member_start',
		'pp_member_end',
		'pp_member_amount',
	];

	// File fields: stored as filename only (not full URL)
	const FILE_FIELDS = [
		'pp_profile_avatar',
		'pp_profile_cover_image',
	];

	// Serialized upload field
	const UPLOADED_FILES_KEY = 'pp_uploaded_files';

	// Fields stored in wp_users table (NOT wp_usermeta) — must use wp_update_user()
	const WP_USER_FIELDS = [
		'user_email',
		'user_login',
		'display_name',
		'user_pass',
		'user_nicename',
		'user_url',
		'user_registered',
	];

	public static function getInstance() {
		if ( self::$instance == null ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	// =========================================================================
	// EXPORT: Fetch ProfilePress-only user IDs
	// Primary condition: wp_ppress_customers.user_id
	// Fallback: wp_usermeta with pp_* / ppress_* keys (if table missing)
	// =========================================================================
	public function getProfilePressUsersForExport( $conditions = [] ) {
		global $wpdb;

		$customers_table = $wpdb->prefix . 'ppress_customers';
		$table_exists    = (bool) $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $customers_table )
		);

		if ( $table_exists ) {
			// Primary: only users who have a customers row
			$sql = "SELECT DISTINCT ppc.user_id
					FROM {$customers_table} ppc
					INNER JOIN {$wpdb->users} u ON u.ID = ppc.user_id";

			// Date-range filter
			if ( ! empty( $conditions['specific_period']['is_check'] ) && $conditions['specific_period']['is_check'] === 'true' ) {
				$from = esc_sql( $conditions['specific_period']['from'] );
				$to   = esc_sql( $conditions['specific_period']['to'] );
				if ( $from === $to ) {
					$sql .= " WHERE u.user_registered >= '{$from}'";
				} else {
					$sql .= " WHERE u.user_registered >= '{$from}' AND u.user_registered <= '{$to} 23:59:59'";
				}
			}

			$sql .= ' ORDER BY ppc.user_id ASC';
		} else {
			// Fallback: use meta-key presence
			$sql = "SELECT DISTINCT u.ID
					FROM {$wpdb->users} u
					INNER JOIN {$wpdb->usermeta} um ON um.user_id = u.ID
					WHERE ( um.meta_key LIKE 'pp_%' OR um.meta_key LIKE 'ppress_%' )";

			if ( ! empty( $conditions['specific_period']['is_check'] ) && $conditions['specific_period']['is_check'] === 'true' ) {
				$from = esc_sql( $conditions['specific_period']['from'] );
				$to   = esc_sql( $conditions['specific_period']['to'] );
				if ( $from === $to ) {
					$sql .= " AND u.user_registered >= '{$from}'";
				} else {
					$sql .= " AND u.user_registered >= '{$from}' AND u.user_registered <= '{$to} 23:59:59'";
				}
			}

			$sql .= ' ORDER BY u.ID ASC';
		}

		$user_ids = $wpdb->get_col( $sql );
		return is_array( $user_ids ) ? array_map( 'intval', $user_ids ) : [];
	}

	// =========================================================================
	// EXPORT: Build complete ordered field list for ProfilePress
	// =========================================================================
	public function getProfilePressFields() {
		global $wpdb;

		$fields = [];

		// 0. wp_users table fields (always first — email, login, display_name)
		$wp_users_labels = [
			'ID'           => 'User ID',
			'user_email'   => 'Email',
			'user_login'   => 'Username',
			'display_name' => 'Display Name',
		];
		foreach ( $wp_users_labels as $field => $label ) {
			$fields[ $field ] = $label;
		}

		// 1. Standard WP usermeta fields
		foreach ( self::STANDARD_USER_FIELDS as $field ) {
			if ( ! isset( $fields[ $field ] ) ) {
				$fields[ $field ] = ucwords( str_replace( '_', ' ', $field ) );
			}
		}

		// Subscription source meta fields (for consistent export/mapping).
		foreach ( self::SUBSCRIPTION_META_KEYS as $field ) {
			if ( ! isset( $fields[ $field ] ) ) {
				$label          = str_replace( 'pp_', '', $field );
				$fields[ $field ] = ucwords( str_replace( '_', ' ', $label ) );
			}
		}

		// Subscription status is not stored as pp_ meta; it comes from ProfilePress subscription records.
		if ( ! isset( $fields['subscription_status'] ) ) {
			$fields['subscription_status'] = 'Subscription Status';
		}

		// 2. Dynamic pp_* / ppress_* meta keys present in the DB
		$meta_keys = $wpdb->get_col(
			"SELECT DISTINCT meta_key
			 FROM {$wpdb->usermeta}
			 WHERE meta_key LIKE 'pp_%'
			    OR meta_key LIKE 'ppress_%'
			 ORDER BY meta_key ASC"
		);

		foreach ( $meta_keys as $key ) {
			// Skip the raw serialized file key — will be expanded later
			if ( $key === self::UPLOADED_FILES_KEY ) {
				continue;
			}
			$label           = preg_replace( '/^(pp_|ppress_)/', '', $key );
			$label           = ucwords( str_replace( '_', ' ', $label ) );
			$fields[ $key ]  = $label;
		}

		// 3. Dynamic fields from wp_ppress_formsmeta (field_key column)
		$formsmeta_table = $wpdb->prefix . 'ppress_formsmeta';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $formsmeta_table ) ) ) {
			$form_fields = $wpdb->get_col(
				"SELECT DISTINCT meta_value
				 FROM {$formsmeta_table}
				 WHERE meta_key = 'field_key'
				   AND meta_value != ''
				 ORDER BY meta_value ASC"
			);
			foreach ( $form_fields as $field_key ) {
				if ( ! isset( $fields[ $field_key ] ) ) {
					$label          = ucwords( str_replace( '_', ' ', $field_key ) );
					$fields[ $field_key ] = $label;
				}
			}
		}

		// 4. wp_ppress_customers table columns
		foreach ( self::CUSTOMER_TABLE_FIELDS as $col ) {
			if ( ! isset( $fields[ $col ] ) ) {
				$fields[ $col ] = ucwords( str_replace( '_', ' ', $col ) );
			}
		}

		// 5. Orders (single latest order per user row for roundtrip support)
		$order_fields = [
			'ppress_order_plan_id'        => 'Order Plan ID',
			'ppress_order_plan_name'      => 'Order Plan Name',
			'ppress_order_amount'         => 'Order Amount',
			'ppress_order_status'         => 'Order Status',
			'ppress_order_payment_method' => 'Order Payment Method',
			'ppress_order_transaction_id' => 'Order Transaction ID',
			'ppress_order_date_created'   => 'Order Date Created',
		];
		foreach ( $order_fields as $k => $label ) {
			if ( ! isset( $fields[ $k ] ) ) {
				$fields[ $k ] = $label;
			}
		}

		return $fields; // [ meta_key => label ]
	}

	// =========================================================================
	// IMPORT: Save all ProfilePress fields for a user
	// =========================================================================
	public function processProfilePressImport( $data_array, $user_id ) {
		global $wpdb;

		$line_number = isset( $data_array['_uci_line_number'] ) ? intval( $data_array['_uci_line_number'] ) : 0;
		$update_mode = ImportHelpers::resolve_import_update_mode( $data_array['_uci_hash_key'] ?? '', $data_array['_uci_update_mode'] ?? '' );
		$ops         = new ImportRowUndoStack( $line_number );

		try {
		if ( empty( $user_id ) || ! is_numeric( $user_id ) ) {
			// FALLBACK: If core importer didn't create the user, try here
			$email = $data_array['user_email'] ?? ( $data_array['email'] ?? '' );
			if ( empty( $email ) ) {
				return;
			}
			if ( ! is_email( $email ) ) {
				return;
			}
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				$user_id = $user->ID;
			} else {
				if ( $update_mode === 'skip' ) {
					return;
				}
				// Right-before-write duplicate check (concurrent / double-submit safe).
				$race_user = get_user_by( 'email', $email );
				if ( $race_user ) {
					$user_id = intval( $race_user->ID );
				} else {
				$user_id = wp_insert_user( [
					'user_login' => sanitize_user( $email ),
					'user_email' => $email,
					'user_pass'  => wp_generate_password( 12, false ),
					'role'       => $data_array['role'] ?? 'subscriber',
				] );
				if ( is_wp_error( $user_id ) ) {
					return;
				}
				$created_user_id = intval( $user_id );
				$ops->pushUndo( function() use ( $created_user_id ) {
					require_once ABSPATH . 'wp-admin/includes/user.php';
					wp_delete_user( $created_user_id );
				}, 'delete_created_user' );
				}
			}
		}

		$user_id          = intval( $user_id );
		$customer_data    = [];          // Fields for wp_ppress_customers
		$uploaded_files   = [];          // Collected flattened file upload keys
		$normalized_row   = [];          // All detected CSV/meta keys after normalization
		$order_data       = [];          // Order import payload (ppress_orders)

		// Prefix for expanded uploaded_files columns: pp_uploaded_files_{key}
		$upload_prefix = self::UPLOADED_FILES_KEY . '_';

		// Fields that should be treated as part of pp_uploaded_files if they appear as bare keys
		$direct_upload_fields = [ 'resume', 'cv', 'file_upload' ];

		// Collect wp_users fields to update via wp_update_user()
		$wp_user_update = [];

		// Early validation: user_id + email (do not do remote calls here).
		if ( ! $this->validate_row( $user_id, $data_array, $line_number ) ) {
			$ops->rollback( 'row validation failed' );
			return;
		}

		foreach ( $data_array as $raw_key => $raw_value ) {
			$meta_key   = $this->normalize_key( $raw_key );
			$meta_value = is_string( $raw_value ) ? trim( (string) $raw_value ) : (string) $raw_value;

			if ( empty( $meta_key ) ) {
				continue;
			}

			// Keep a normalized copy of the row (for derived fields / customer mapping).
			$normalized_row[ $meta_key ] = $meta_value;

			// ---- A-ORDER. Order fields (prefixed) ----
			// Supports importing a single (latest) order per row.
			// Expected keys:
			// - ppress_order_plan_id OR ppress_order_plan_name
			// - ppress_order_amount
			// - ppress_order_status
			// - ppress_order_payment_method
			// - ppress_order_transaction_id
			// - ppress_order_date_created
			if ( strpos( $meta_key, 'ppress_order_' ) === 0 ) {
				$order_data[ $meta_key ] = $meta_value;
				continue;
			}

			// Boolean normalization (True/False → 1/0).
			if ( is_string( $meta_value ) ) {
				$lower = strtolower( trim( $meta_value ) );
				if ( $lower === 'true' ) {
					$meta_value = '1';
				} elseif ( $lower === 'false' ) {
					$meta_value = '0';
				}
			}

			// Date conversion fix for known Dutch columns (after normalization).
			if ( in_array( $meta_key, [ 'datuminschr', 'datumeind', 'datumgeboren' ], true ) ) {
				$meta_value = $this->convert_date( $meta_value );
				if ( $meta_value === null ) {
					$meta_value = '';
				}
			}

			// Map Dutch membership columns to ProfilePress subscription meta keys.
			// SoortLid → pp_member_type, DatumInschr → pp_member_start, DatumEind → pp_member_end
			if ( $meta_key === 'soortlid' && $meta_value !== '' ) {
				update_user_meta( $user_id, 'pp_member_type', $meta_value );
			} elseif ( $meta_key === 'datuminschr' ) {
				update_user_meta( $user_id, 'pp_member_start', $meta_value );
			} elseif ( $meta_key === 'datumeind' ) {
				// Blank end date means lifetime/active — still write the empty value.
				update_user_meta( $user_id, 'pp_member_end', $meta_value );
			} elseif ( $meta_key === 'bedrag' && $meta_value !== '' ) {
				update_user_meta( $user_id, 'pp_member_amount', $meta_value );
			}

			// ---- A0. wp_users table fields (NOT usermeta) ----
			// user_email, user_login, display_name → wp_update_user()
			if ( in_array( $meta_key, self::WP_USER_FIELDS, true ) ) {
				if ( $meta_key === 'user_email' && ! empty( $meta_value ) ) {
					if ( ! is_email( $meta_value ) ) {
						continue; // skip invalid email
					}
				}
				if ( $meta_value !== '' ) {
					$wp_user_update[ $meta_key ] = $meta_value;
				}
				continue;
			}

			// ---- A. wp_ppress_customers columns ----
			if ( in_array( $meta_key, self::CUSTOMER_TABLE_FIELDS, true ) ) {
				$customer_data[ $meta_key ] = $meta_value;
				continue;
			}

			// ---- B. Flattened pp_uploaded_files_{subkey} columns ----
			if ( strpos( $meta_key, $upload_prefix ) === 0 ) {
				$subkey = substr( $meta_key, strlen( $upload_prefix ) );
				if ( $subkey !== '' ) {
					$uploaded_files[ $subkey ] = basename( $meta_value ); // store filename only
				}
				continue;
			}

			// ---- B1. Direct upload fields (e.g., 'resume' -> serialized in pp_uploaded_files) ----
			if ( in_array( $meta_key, $direct_upload_fields, true ) && ! empty( $meta_value ) ) {
				$uploaded_files[ $meta_key ] = basename( $meta_value );
				continue;
			}

			// ---- C. Avatar / cover image: store filename only ----
			if ( in_array( $meta_key, self::FILE_FIELDS, true ) ) {
				// CRITICAL: Avatar import support.
				// If CSV provides a URL, sideload into media library and set WP User Avatar meta.
				if ( $meta_key === 'pp_profile_avatar' && is_string( $meta_value ) && filter_var( $meta_value, FILTER_VALIDATE_URL ) ) {
					$this->importWpUserAvatarFromUrl( $user_id, $meta_value, $line_number, $update_mode, $ops );
					// Ensure ProfilePress does not override with pp_profile_avatar filename.
					delete_user_meta( $user_id, 'pp_profile_avatar' );
					continue;
				}

				// Otherwise accept both full URLs and bare filenames for ProfilePress storage.
				$meta_value = basename( $meta_value );
				$meta_value = strtok( $meta_value, '?' );
				if ( ! empty( $meta_value ) ) {
					$prev = get_user_meta( $user_id, $meta_key, true );
					$ops->pushUndo( function() use ( $user_id, $meta_key, $prev ) {
						if ( $prev === '' || $prev === null ) {
							delete_user_meta( $user_id, $meta_key );
						} else {
							update_user_meta( $user_id, $meta_key, $prev );
						}
					}, 'restore_file_field_'.$meta_key );

					ImportHelpers::apply_import_user_meta( $user_id, $meta_key, sanitize_file_name( $meta_value ), $update_mode );
				}
				continue;
			}

			// ---- D. pp_* / ppress_* meta keys ----
			$is_pp_field = ( strpos( $meta_key, 'pp_' ) === 0 || strpos( $meta_key, 'ppress_' ) === 0 );

			// ---- E. Standard WP user meta fields ----
			$is_standard = in_array( $meta_key, self::STANDARD_USER_FIELDS, true );

			if ( $is_pp_field || $is_standard ) {
				// Handle values that look like JSON arrays
				$save_value = $meta_value;
				if ( is_string( $meta_value ) && in_array( substr( $meta_value, 0, 1 ), [ '[', '{' ], true ) ) {
					$decoded = json_decode( $meta_value, true );
					if ( json_last_error() === JSON_ERROR_NONE ) {
						$save_value = $decoded;
					}
				}

				// For subscription-driven fields, always write even when empty
				// (e.g. CSV blank `pp_member_end` means "lifetime active").
				$force_write_for_subscription_keys = in_array( $meta_key, self::SUBSCRIPTION_META_KEYS, true );
				if ( $save_value !== '' || $force_write_for_subscription_keys ) {
					$prev = get_user_meta( $user_id, $meta_key, true );
					$ops->pushUndo( function() use ( $user_id, $meta_key, $prev ) {
						if ( $prev === '' || $prev === null ) {
							delete_user_meta( $user_id, $meta_key );
						} else {
							update_user_meta( $user_id, $meta_key, $prev );
						}
					}, 'restore_meta_'.$meta_key );

					$update_result = ImportHelpers::apply_import_user_meta( $user_id, $meta_key, $save_value, $update_mode );
					if ( false === $update_result ) {
						// Note: update_user_meta returns false if value is SAME as existing
						// error_log("PROFILEPRESS IMPORT: Meta update returned false for $meta_key");
					}
				}
				continue;
			}

			// ---- F. ProfilePress form-builder fields (whitelist only) ----
			// Previous behavior dropped unknown fields. New behavior: allow ALL unknown fields.
			if ( $this->isAllowedProfilePressField( $meta_key ) && preg_match( '/^[a-z0-9_\-]+$/i', $meta_key ) ) {
				$prev = get_user_meta( $user_id, $meta_key, true );
				$ops->pushUndo( function() use ( $user_id, $meta_key, $prev ) {
					if ( $prev === '' || $prev === null ) {
						delete_user_meta( $user_id, $meta_key );
					} else {
						update_user_meta( $user_id, $meta_key, $prev );
					}
				}, 'restore_allowed_field_'.$meta_key );
				ImportHelpers::apply_import_user_meta( $user_id, $meta_key, $meta_value, $update_mode );
			} else {
				// Allow ALL unknown fields (dynamic + complete). Do NOT skip.
				$prev = get_user_meta( $user_id, $meta_key, true );
				$ops->pushUndo( function() use ( $user_id, $meta_key, $prev ) {
					if ( $prev === '' || $prev === null ) {
						delete_user_meta( $user_id, $meta_key );
					} else {
						update_user_meta( $user_id, $meta_key, $prev );
					}
				}, 'restore_unknown_field_'.$meta_key );
				ImportHelpers::apply_import_user_meta( $user_id, $meta_key, $meta_value, $update_mode );
			}
		}

		// ---- G. Rebuild & save pp_uploaded_files serialized array ----
		if ( ! empty( $uploaded_files ) ) {
			$prev = get_user_meta( $user_id, self::UPLOADED_FILES_KEY, true );
			$ops->pushUndo( function() use ( $user_id, $prev ) {
				if ( empty( $prev ) ) {
					delete_user_meta( $user_id, self::UPLOADED_FILES_KEY );
				} else {
					update_user_meta( $user_id, self::UPLOADED_FILES_KEY, $prev );
				}
			}, 'restore_pp_uploaded_files' );
			ImportHelpers::apply_import_user_meta_array( $user_id, self::UPLOADED_FILES_KEY, $uploaded_files, $update_mode );
		}

		// ---- H. Upsert wp_ppress_customers (MANDATORY) ----
		// Also support Dutch CSV columns for spend / purchase_count when present.
		if ( ! isset( $customer_data['total_spend'] ) ) {
			$customer_data['total_spend'] = isset( $normalized_row['bedrag'] ) && is_numeric( $normalized_row['bedrag'] ) ? (float) $normalized_row['bedrag'] : 0;
		}
		if ( ! isset( $customer_data['purchase_count'] ) ) {
			$customer_data['purchase_count'] = isset( $normalized_row['aantaltermijnen'] ) && is_numeric( $normalized_row['aantaltermijnen'] ) ? (float) $normalized_row['aantaltermijnen'] : 0;
		}
		if ( ! isset( $customer_data['last_login'] ) ) {
			$customer_data['last_login'] = current_time( 'mysql' );
		}
		$this->upsertCustomerRow( $user_id, $customer_data );

		// ---- I. Update wp_users fields via wp_update_user() ----
		if ( ! empty( $wp_user_update ) ) {
			$wp_user_update['ID'] = $user_id;
			wp_update_user( $wp_user_update );
		}

		// ---- J. Create/update ProfilePress subscription from saved meta ----
		$this->maybeSyncSubscriptionsFromUserMeta( $user_id, $line_number, $update_mode );

		// ---- K. Create/update ProfilePress order (optional, supports transaction matching) ----
		if ( ! empty( $order_data ) ) {
			$this->maybeSyncOrderFromRow( $user_id, $order_data, $line_number, $update_mode, $ops );
		}

		// Digital downloads (simple user-linked attachments)
		$this->maybeSyncDigitalDownloadFromRow( $user_id, $normalized_row, $line_number, $update_mode, $ops );

		// Content protection rule mapping (global rules)
		$this->maybeSyncContentProtectionFromRow( $normalized_row, $line_number, $update_mode, $ops );

		// Final relationship validation for this row (best-effort).
		$this->validate_relationships( $user_id, $normalized_row, $line_number );
		} catch ( \Throwable $e ) {
			$ops->rollback( $e->getMessage() );
			return;
		}
	}

	/**
	 * Create or update a ProfilePress order for the user.
	 *
	 * Uses:
	 * - Core API `ppress_subscribe_user_to_plan()` when inserting.
	 * - Direct DB update when matching existing order by transaction_id + customer_id.
	 *
	 * @param int   $user_id
	 * @param array $order_data normalized keys (ppress_order_*)
	 * @param int   $line_number
	 */
	private function maybeSyncOrderFromRow( $user_id, $order_data, $line_number = 0, $update_mode = 'replace', $ops = null ) {
		global $wpdb;

		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return;
		}

		// Require ProfilePress membership APIs.
		if ( ! function_exists( 'ppress_subscribe_user_to_plan' ) ) {
			return;
		}

		$customers_table = $wpdb->prefix . 'ppress_customers';
		$orders_table    = $wpdb->prefix . 'ppress_orders';
		$plans_table     = $wpdb->prefix . 'ppress_plans';

		if ( ! $this->ppTableExists( $customers_table ) || ! $this->ppTableExists( $orders_table ) ) {
			return;
		}

		$customer_id = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$customers_table} WHERE user_id = %d LIMIT 1", $user_id )
		);
		$customer_id = $customer_id ? intval( $customer_id ) : 0;
		if ( $customer_id <= 0 ) {
			return;
		}

		$plan_id = 0;
		$plan_id_raw = trim( (string) ( $order_data['ppress_order_plan_id'] ?? '' ) );
		$plan_name   = trim( (string) ( $order_data['ppress_order_plan_name'] ?? '' ) );
		if ( $plan_id_raw !== '' && is_numeric( $plan_id_raw ) ) {
			$plan_id = intval( $plan_id_raw );
		} elseif ( $plan_name !== '' && $this->ppTableExists( $plans_table ) ) {
			$cols = $this->ppGetColumns( $plans_table );
			$name_col = in_array( 'name', $cols, true ) ? 'name' : ( in_array( 'title', $cols, true ) ? 'title' : '' );
			if ( $name_col !== '' ) {
				$plan_id = intval(
					$wpdb->get_var(
						$wpdb->prepare( "SELECT id FROM {$plans_table} WHERE {$name_col} = %s LIMIT 1", $plan_name )
					)
				);
			}
		}

		if ( $plan_id <= 0 ) {
			return;
		}

		$amount_raw       = trim( (string) ( $order_data['ppress_order_amount'] ?? '' ) );
		$status           = trim( (string) ( $order_data['ppress_order_status'] ?? '' ) );
		$payment_method   = trim( (string) ( $order_data['ppress_order_payment_method'] ?? '' ) );
		$transaction_id   = trim( (string) ( $order_data['ppress_order_transaction_id'] ?? '' ) );
		$date_created_raw = trim( (string) ( $order_data['ppress_order_date_created'] ?? '' ) );

		$amount = is_numeric( $amount_raw ) ? (float) $amount_raw : 0.0;
		$date_created = $date_created_raw !== '' ? $this->ppParseCsvDateToMysql( $date_created_raw ) : current_time( 'mysql' );
		if ( $date_created === '' ) {
			$date_created = current_time( 'mysql' );
		}

		// If transaction id provided, attempt update (prevent duplicates).
		if ( $transaction_id !== '' ) {
			$order_cols = $this->ppGetColumns( $orders_table );
			if ( in_array( 'transaction_id', $order_cols, true ) && in_array( 'customer_id', $order_cols, true ) ) {
				$existing_order_id = intval(
					$wpdb->get_var(
						$wpdb->prepare(
							"SELECT id FROM {$orders_table} WHERE customer_id = %d AND transaction_id = %s ORDER BY id DESC LIMIT 1",
							$customer_id,
							$transaction_id
						)
					)
				);
				if ( $existing_order_id > 0 ) {
					if ( $update_mode === 'skip' ) {
						return;
					}
					if ( $update_mode === 'append' ) {
						return;
					}

					$prev_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$orders_table} WHERE id = %d LIMIT 1", $existing_order_id ), ARRAY_A );
					if ( $ops instanceof ImportRowUndoStack && is_array( $prev_row ) ) {
						$ops->pushUndo( function() use ( $wpdb, $orders_table, $existing_order_id, $prev_row ) {
							$wpdb->update( $orders_table, $prev_row, [ 'id' => $existing_order_id ] );
						}, 'restore_order_row' );
					}
					$update = [];
					if ( $status !== '' && in_array( 'status', $order_cols, true ) ) {
						$update['status'] = $status;
					}
					if ( $amount > 0 && in_array( 'amount', $order_cols, true ) ) {
						$update['amount'] = $amount;
					} elseif ( $amount > 0 && in_array( 'total', $order_cols, true ) ) {
						$update['total'] = $amount;
					}
					if ( $payment_method !== '' && in_array( 'payment_method', $order_cols, true ) ) {
						$update['payment_method'] = $payment_method;
					}
					if ( ! empty( $update ) ) {
						$wpdb->update( $orders_table, $update, [ 'id' => $existing_order_id ], null, [ '%d' ] );
					}
					return;
				}
			}
		}

		// Without transaction_id, we cannot dedupe safely at enterprise scale.
		// In SKIP/APPEND, never create a new order without transaction_id.
		if ( $transaction_id === '' && ( $update_mode === 'skip' || $update_mode === 'append' ) ) {
			return;
		}

		if ( $update_mode === 'skip' ) {
			return;
		}

		// Insert by subscribing user to plan (creates order + subscription per ProfilePress rules).
		$args = [
			'amount'         => $amount,
			'order_status'   => $status,
			'payment_method' => $payment_method,
			'transaction_id' => $transaction_id,
			'date_created'   => $date_created,
		];


		// Atomic duplicate prevention right-before-write: recheck txn+customer.
		if ( $transaction_id !== '' ) {
			$existing_order_id = intval(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT id FROM {$orders_table} WHERE customer_id = %d AND transaction_id = %s ORDER BY id DESC LIMIT 1",
						$customer_id,
						$transaction_id
					)
				)
			);
			if ( $existing_order_id > 0 ) {
				return;
			}
		}

		$res = ppress_subscribe_user_to_plan( $plan_id, $customer_id, $args, false );
		if ( is_wp_error( $res ) ) {
			return;
		}

		if ( is_array( $res ) && isset( $res['order_id'] ) ) {
			if ( $ops instanceof ImportRowUndoStack ) {
				$created_order_id = intval( $res['order_id'] );
				$created_sub_id   = isset( $res['subscription_id'] ) ? intval( $res['subscription_id'] ) : 0;
				$ops->pushUndo( function() use ( $wpdb, $orders_table, $created_order_id ) {
					$wpdb->delete( $orders_table, [ 'id' => $created_order_id ], [ '%d' ] );
				}, 'delete_created_order' );
				if ( $created_sub_id > 0 ) {
					$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';
					$ops->pushUndo( function() use ( $wpdb, $subscriptions_table, $created_sub_id ) {
						$wpdb->delete( $subscriptions_table, [ 'id' => $created_sub_id ], [ '%d' ] );
					}, 'delete_created_subscription' );
				}
			}
		}
	}

	/**
	 * Download avatar URL, avoid duplicates by content hash,
	 * attach to media library, and assign as WP User Avatar for the user.
	 *
	 * @param int    $user_id
	 * @param string $url
	 * @param int    $line_number
	 */
	private function importWpUserAvatarFromUrl( $user_id, $url, $line_number = 0, $update_mode = 'replace', $ops = null ) {
		global $wpdb, $blog_id;

		$user_id = intval( $user_id );
		$url     = trim( (string) $url );

		if ( $user_id <= 0 || $url === '' ) {
			return;
		}

		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';


		// Mode behavior: skip/append should not overwrite existing avatar.
		$meta_key = $wpdb->get_blog_prefix( $blog_id ) . 'user_avatar';
		$existing_avatar_id = intval( get_user_meta( $user_id, $meta_key, true ) );
		if ( $update_mode === 'skip' && $existing_avatar_id > 0 ) {
			return;
		}
		if ( $update_mode === 'append' && $existing_avatar_id > 0 ) {
			return;
		}

		// rollback: restore previous mapping
		if ( $ops instanceof ImportRowUndoStack ) {
			$prev_attachment_id = $existing_avatar_id;
			$ops->pushUndo( function() use ( $user_id, $meta_key, $prev_attachment_id, $wpdb ) {
				if ( $prev_attachment_id > 0 ) {
					update_user_meta( $user_id, $meta_key, $prev_attachment_id );
				} else {
					delete_user_meta( $user_id, $meta_key );
				}
				delete_metadata( 'post', null, '_wp_attachment_wp_user_avatar', $user_id, true );
				if ( $prev_attachment_id > 0 ) {
					update_post_meta( $prev_attachment_id, '_wp_attachment_wp_user_avatar', $user_id );
				}
			}, 'restore_avatar_mapping' );
		}

		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			return;
		}

		$sha1 = @sha1_file( $tmp );
		if ( ! is_string( $sha1 ) || $sha1 === '' ) {
			$sha1 = '';
		}

		$existing_id = 0;
		if ( $sha1 !== '' ) {
			if ( isset( self::$cache_attachment_by_sha1[ $sha1 ] ) ) {
				$existing_id = intval( self::$cache_attachment_by_sha1[ $sha1 ] );
			} else {
			$existing_id = intval(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
						'_smack_uci_file_sha1',
						$sha1
					)
				)
			);
				if ( $existing_id > 0 ) {
					self::$cache_attachment_by_sha1[ $sha1 ] = $existing_id;
				}
			}
		}

		$attachment_id = 0;

		if ( $existing_id > 0 && wp_attachment_is_image( $existing_id ) ) {
			@unlink( $tmp );
			$attachment_id = $existing_id;
		} else {
			$filename = basename( parse_url( $url, PHP_URL_PATH ) );
			$filename = $filename ? $filename : ( 'avatar-' . $user_id . '.jpg' );
			$filename = sanitize_file_name( $filename );
			$filename_key = strtolower( $filename );

			// Fallback dedupe when SHA1 not available.
			if ( $sha1 === '' ) {
				if ( isset( self::$cache_attachment_by_filename[ $filename_key ] ) ) {
					@unlink( $tmp );
					$attachment_id = intval( self::$cache_attachment_by_filename[ $filename_key ] );
				} else {
					$post_name = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
					if ( $post_name !== '' ) {
						$existing_by_name = intval(
							$wpdb->get_var(
								$wpdb->prepare(
									"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_name = %s ORDER BY ID DESC LIMIT 1",
									$post_name
								)
							)
						);
						if ( $existing_by_name > 0 ) {
							self::$cache_attachment_by_filename[ $filename_key ] = $existing_by_name;
							@unlink( $tmp );
							$attachment_id = $existing_by_name;
						}
					}
				}
			}

			if ( empty( $attachment_id ) ) {

			$file_array = [
				'name'     => $filename,
				'tmp_name' => $tmp,
			];

			$attachment_id = media_handle_sideload( $file_array, 0, 'ProfilePress User Avatar' );

			if ( is_wp_error( $attachment_id ) ) {
				@unlink( $tmp );
				return;
			}

			$attachment_id = intval( $attachment_id );
			if ( $sha1 !== '' ) {
				update_post_meta( $attachment_id, '_smack_uci_file_sha1', $sha1 );
				self::$cache_attachment_by_sha1[ $sha1 ] = $attachment_id;
			}
			self::$cache_attachment_by_filename[ $filename_key ] = $attachment_id;
			}
		}

		if ( $attachment_id <= 0 ) {
			return;
		}

		// Associate attachment to user (WP User Avatar uses this post meta + user meta).
		delete_metadata( 'post', null, '_wp_attachment_wp_user_avatar', $user_id, true );
		update_post_meta( $attachment_id, '_wp_attachment_wp_user_avatar', $user_id );
		update_user_meta( $user_id, $meta_key, $attachment_id );

	}

	/**
	 * Relationship validation (best-effort, never fatal).
	 */
	private function validate_relationships( $user_id, $normalized_row, $line_number = 0 ) {
		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		// If order fields are present, ensure customer exists.
		if ( isset( $normalized_row['ppress_order_transaction_id'] ) || isset( $normalized_row['ppress_order_plan_id'] ) || isset( $normalized_row['ppress_order_plan_name'] ) ) {
			global $wpdb;
			$customers_table = $wpdb->prefix . 'ppress_customers';
			if ( $this->ppTableExists( $customers_table ) ) {
				$cid = intval( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$customers_table} WHERE user_id = %d LIMIT 1", $user_id ) ) );
				if ( $cid <= 0 ) {
				}
			}
		}

		return true;
	}

	/**
	 * Lightweight row validation.
	 * Returns false when the row should be skipped safely.
	 */
	private function validate_row( $user_id, $normalized_row, $line_number = 0 ) {
		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		// Validate email if present.
		$email = trim( (string) ( $normalized_row['user_email'] ?? $normalized_row['email'] ?? '' ) );
		if ( $email !== '' && ! is_email( $email ) ) {
			return false;
		}

		// Validate URLs (no remote head to keep bulk fast).
		foreach ( [ 'pp_profile_avatar', 'download_url' ] as $url_key ) {
			if ( isset( $normalized_row[ $url_key ] ) && $normalized_row[ $url_key ] !== '' ) {
				$u = trim( (string) $normalized_row[ $url_key ] );
				if ( ! filter_var( $u, FILTER_VALIDATE_URL ) ) {
					return false;
				}
			}
		}

		// Validate plan if order is being imported.
		if ( ! empty( $normalized_row['ppress_order_plan_id'] ) || ! empty( $normalized_row['ppress_order_plan_name'] ) ) {
			$pid = trim( (string) ( $normalized_row['ppress_order_plan_id'] ?? '' ) );
			$pname = trim( (string) ( $normalized_row['ppress_order_plan_name'] ?? '' ) );
			if ( $pid === '' && $pname === '' ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Digital downloads module (simple user-linked downloads).
	 *
	 * Columns:
	 * - download_url
	 * - download_title
	 */
	private function maybeSyncDigitalDownloadFromRow( $user_id, $normalized_row, $line_number, $update_mode, $ops ) {
		$user_id = intval( $user_id );
		$url   = trim( (string) ( $normalized_row['download_url'] ?? '' ) );
		$title = trim( (string) ( $normalized_row['download_title'] ?? '' ) );

		if ( $url === '' ) {
			return;
		}
		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return;
		}

		$attachment_id = $this->sideloadAnyFileByUrl( $url, $line_number, $ops );
		if ( ! $attachment_id ) {
			return;
		}

		$meta_key = 'ppress_digital_downloads';
		$prev = get_user_meta( $user_id, $meta_key, true );
		$prev_arr = is_array( $prev ) ? $prev : [];
		$incoming_item = [
			'id'    => intval( $attachment_id ),
			'title' => $title !== '' ? $title : get_the_title( $attachment_id ),
			'url'   => $url,
		];

		if ( $ops instanceof ImportRowUndoStack ) {
			$ops->pushUndo( function() use ( $user_id, $meta_key, $prev ) {
				if ( empty( $prev ) ) {
					delete_user_meta( $user_id, $meta_key );
				} else {
					update_user_meta( $user_id, $meta_key, $prev );
				}
			}, 'restore_digital_downloads_meta' );
		}

		if ( $update_mode === 'skip' ) {
			return;
		}

		if ( $update_mode === 'replace' ) {
			update_user_meta( $user_id, $meta_key, [ $incoming_item ] );
			return;
		}

		// append: do not duplicate by URL or attachment id
		foreach ( $prev_arr as $it ) {
			if ( is_array( $it ) && ( ( $it['url'] ?? '' ) === $url || intval( $it['id'] ?? 0 ) === intval( $attachment_id ) ) ) {
				return;
			}
		}
		$prev_arr[] = $incoming_item;
		update_user_meta( $user_id, $meta_key, $prev_arr );
	}

	/**
	 * Content protection import.
	 *
	 * Columns:
	 * - content_id
	 * - membership_plan (plan id or name)
	 * - restriction_type (currently mapped to who_can_access=login)
	 */
	private function maybeSyncContentProtectionFromRow( $normalized_row, $line_number, $update_mode, $ops ) {
		$content_id = intval( $normalized_row['content_id'] ?? 0 );
		$plan_raw   = trim( (string) ( $normalized_row['membership_plan'] ?? '' ) );
		$type_raw   = trim( (string) ( $normalized_row['restriction_type'] ?? '' ) );

		if ( $content_id <= 0 || $plan_raw === '' ) {
			return;
		}

		if ( ! class_exists( '\\ProfilePress\\Core\\Classes\\PROFILEPRESS_sql' ) ) {
			return;
		}

		$post_type = get_post_type( $content_id );
		if ( ! $post_type ) {
			return;
		}

		$plan_id = 0;
		if ( is_numeric( $plan_raw ) ) {
			$plan_id = intval( $plan_raw );
		} else {
			// resolve by name
			global $wpdb;
			$plans_table = $wpdb->prefix . 'ppress_plans';
			if ( $this->ppTableExists( $plans_table ) ) {
				$plan_id = intval( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$plans_table} WHERE name = %s LIMIT 1", $plan_raw ) ) );
			}
		}

		if ( $plan_id <= 0 ) {
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'ppress_meta_data';
		$meta_key = 'content_restrict_data';

		// Build rule data structure.
		$condition_id = $post_type . '_selected';
		$rule = [
			'title' => 'Imported Rule: ' . $content_id,
			'is_active' => 'true',
			'is_new' => 'true',
			'content' => [
				[
					[
						'condition' => $condition_id,
						'value'     => [ $content_id ],
					],
				],
			],
			'exempt' => [],
			'access_condition' => [
				'who_can_access' => 'login',
				'access_membership_plans' => [ $plan_id ],
				'access_roles' => [],
				'access_wp_users' => [],
			],
		];

		// Find existing matching rule by scanning (best-effort; meta_value is serialized).
		$existing_id = 0;
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, meta_value FROM {$table} WHERE meta_key = %s ORDER BY id DESC LIMIT 500", $meta_key ),
			ARRAY_A
		);
		foreach ( $rows as $r ) {
			$val = @unserialize( $r['meta_value'], [ 'allowed_classes' => false ] );
			if ( ! is_array( $val ) ) {
				continue;
			}
			$access_plans = $val['access_condition']['access_membership_plans'] ?? [];
			$content = $val['content'][0][0]['value'][0] ?? null;
			if ( intval( $content ) === $content_id && is_array( $access_plans ) && in_array( $plan_id, array_map( 'intval', $access_plans ), true ) ) {
				$existing_id = intval( $r['id'] );
				break;
			}
		}

		if ( $existing_id > 0 ) {
			if ( $update_mode === 'skip' ) {
				return;
			}
			$prev = \ProfilePress\Core\Classes\PROFILEPRESS_sql::get_meta_value( $existing_id, $meta_key );
			if ( $ops instanceof ImportRowUndoStack ) {
				$ops->pushUndo( function() use ( $existing_id, $meta_key, $prev ) {
					\ProfilePress\Core\Classes\PROFILEPRESS_sql::update_meta_value( $existing_id, $meta_key, $prev );
				}, 'restore_content_rule' );
			}
			\ProfilePress\Core\Classes\PROFILEPRESS_sql::update_meta_value( $existing_id, $meta_key, $rule );
			return;
		}

		if ( $update_mode === 'skip' ) {
			return;
		}

		$new_id = \ProfilePress\Core\Classes\PROFILEPRESS_sql::add_meta_data( $meta_key, $rule );
		if ( $new_id && $ops instanceof ImportRowUndoStack ) {
			$rid = intval( $new_id );
			$ops->pushUndo( function() use ( $rid ) {
				\ProfilePress\Core\Classes\PROFILEPRESS_sql::delete_meta_data( $rid );
			}, 'delete_created_rule' );
		}
	}

	/**
	 * Generic URL sideload with SHA1 dedup (attachments only).
	 *
	 * @return int|false attachment_id
	 */
	private function sideloadAnyFileByUrl( $url, $line_number = 0, $ops = null ) {
		global $wpdb;

		$url = trim( (string) $url );
		if ( $url === '' || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return false;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			return false;
		}

		$sha1 = @sha1_file( $tmp );
		$sha1 = is_string( $sha1 ) ? $sha1 : '';

		// Dedup chain:
		// 1) SHA1 meta (cache + DB)
		// 2) filename post_name match
		// 3) guid LIKE %filename%
		if ( $sha1 !== '' ) {
			if ( isset( self::$cache_attachment_by_sha1[ $sha1 ] ) ) {
				@unlink( $tmp );
				return intval( self::$cache_attachment_by_sha1[ $sha1 ] );
			}
			$existing_id = intval(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
						'_smack_uci_file_sha1',
						$sha1
					)
				)
			);
			if ( $existing_id > 0 ) {
				self::$cache_attachment_by_sha1[ $sha1 ] = $existing_id;
				@unlink( $tmp );
				return $existing_id;
			}
		}

		$filename = basename( parse_url( $url, PHP_URL_PATH ) );
		$filename = $filename ? $filename : ( 'download-' . time() );
		$filename = sanitize_file_name( $filename );

		$filename_key = strtolower( $filename );
		if ( isset( self::$cache_attachment_by_filename[ $filename_key ] ) ) {
			@unlink( $tmp );
			return intval( self::$cache_attachment_by_filename[ $filename_key ] );
		}

		// Fallback: post_name match
		$post_name = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
		if ( $post_name !== '' ) {
			$existing_by_name = intval(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_name = %s ORDER BY ID DESC LIMIT 1",
						$post_name
					)
				)
			);
			if ( $existing_by_name > 0 ) {
				self::$cache_attachment_by_filename[ $filename_key ] = $existing_by_name;
				@unlink( $tmp );
				return $existing_by_name;
			}
		}

		// Fallback: guid LIKE %filename%
		$like = '%' . $wpdb->esc_like( $filename ) . '%';
		$existing_by_guid = intval(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND guid LIKE %s ORDER BY ID DESC LIMIT 1",
					$like
				)
			)
		);
		if ( $existing_by_guid > 0 ) {
			self::$cache_attachment_by_filename[ $filename_key ] = $existing_by_guid;
			@unlink( $tmp );
			return $existing_by_guid;
		}

		$file_array = [ 'name' => $filename, 'tmp_name' => $tmp ];
		$attachment_id = media_handle_sideload( $file_array, 0, 'ProfilePress Digital Download' );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp );
			return false;
		}

		$attachment_id = intval( $attachment_id );
		if ( $sha1 !== '' ) {
			update_post_meta( $attachment_id, '_smack_uci_file_sha1', $sha1 );
			self::$cache_attachment_by_sha1[ $sha1 ] = $attachment_id;
		}
		self::$cache_attachment_by_filename[ $filename_key ] = $attachment_id;

		if ( $ops instanceof ImportRowUndoStack ) {
			$ops->pushUndo( function() use ( $attachment_id ) {
				if ( ProfilePressExtension::rollback_safety_check_attachment( $attachment_id ) ) {
					wp_delete_attachment( $attachment_id, true );
				}
			}, 'delete_created_attachment' );
		}

		return $attachment_id;
	}

	/**
	 * Rollback safety check for attachments.
	 * Returns true if attachment looks safe to delete (not shared/referenced).
	 */
	public static function rollback_safety_check_attachment( $attachment_id ) {
		global $wpdb;
		$attachment_id = intval( $attachment_id );
		if ( $attachment_id <= 0 ) {
			return false;
		}
		// If used as featured image anywhere, do not delete.
		$thumb_refs = intval(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d",
					$attachment_id
				)
			)
		);
		if ( $thumb_refs > 0 ) {
			return false;
		}
		// If referenced by other users as avatar, do not delete.
		$avatar_refs = intval(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_value = %s AND meta_key LIKE %s",
					(string) $attachment_id,
					'%user_avatar'
				)
			)
		);
		if ( $avatar_refs > 0 ) {
			return false;
		}
		return true;
	}

	// =========================================================================
	// SUBSCRIPTIONS: Create/update ProfilePress subscription records
	// =========================================================================
	/**
	 * Sync ProfilePress subscriptions based on user meta fields.
	 *
	 * Meta keys (map in ProfilePress import):
	 * - pp_member_type       => plan name (maps to wp_ppress_plans.*)
	 * - pp_member_start      => CSV date
	 * - pp_member_end        => CSV date (optional, blank => active)
	 * - pp_member_amount     => billing amount
	 *
	 * Status:
	 * - active when pp_member_end is empty OR pp_member_end >= now
	 * - expired when pp_member_end is in the past
	 *
	 * Bulk safety:
	 * - wraps in try/catch, logs and skips broken rows.
	 *
	 * @param int $user_id
	 * @param int $line_number
	 * @return void
	 */
	public function maybeSyncSubscriptionsFromUserMeta( $user_id, $line_number = 0, $update_mode = 'replace' ) {
		global $wpdb;

		try {
			$user_id = intval( $user_id );
			if ( $user_id <= 0 ) {
				return;
			}

			// Prefer the dedicated ProfilePress handler (more accurate schema + plan mapping).
			if ( class_exists( '\\Smackcoders\\WCSV\\ProfilePressProperHandler' ) ) {
				\Smackcoders\UCI\Proaddons\UltimatePro\ProfilePressProperHandler::handle_ppress_subscription( $user_id, [], null );
				return;
			}

			// Task requirement: verify ProfilePress is active before touching its tables.
			if ( ! class_exists( '\\ProfilePress\\Core\\Membership\\Services\\CustomerService' ) ) {
				return;
			}

			$plan_name = trim( (string) get_user_meta( $user_id, 'pp_member_type', true ) );
			if ( $plan_name === '' ) {
				// Roundtrip support: accept exported numeric plan id as a fallback.
				$plan_id_fallback = intval( get_user_meta( $user_id, 'ppress_plan_id', true ) );
				if ( $plan_id_fallback > 0 ) {
					$plans_table = $wpdb->prefix . 'ppress_plans';
					if ( $this->ppTableExists( $plans_table ) ) {
						$plan_name = (string) $wpdb->get_var(
							$wpdb->prepare( "SELECT name FROM {$plans_table} WHERE id = %d LIMIT 1", $plan_id_fallback )
						);
					}
				}
			}
			if ( $plan_name === '' ) {
				return;
			}

			$start_raw  = trim( (string) get_user_meta( $user_id, 'pp_member_start', true ) );
			$end_raw    = trim( (string) get_user_meta( $user_id, 'pp_member_end', true ) );
			$amount_raw = trim( (string) get_user_meta( $user_id, 'pp_member_amount', true ) );

			$start_sql = $this->ppParseCsvDateToMysql( $start_raw );
			if ( $start_sql === '' ) {
				if ( $start_raw === '' ) {
					$start_sql = current_time( 'mysql' );
				} else {
					// Broken date -> skip row
					return;
				}
			}

			$end_sql = $this->ppParseCsvDateToMysql( $end_raw );

			$now_ts  = (int) current_time( 'timestamp' );
			$end_ts  = $end_raw === '' ? null : $this->ppParseCsvDateToTimestamp( $end_raw );
			if ( $end_raw !== '' && $end_ts === false ) {
				return;
			}

			$status = ( $end_raw === '' || ( $end_ts !== null && $end_ts >= $now_ts ) ) ? 'active' : 'expired';
			$billing_amount = is_numeric( $amount_raw ) ? (float) $amount_raw : 0.0;

			$customers_table     = $wpdb->prefix . 'ppress_customers';
			$subscriptions_table = $wpdb->prefix . 'ppress_subscriptions';
			$plans_table         = $wpdb->prefix . 'ppress_plans';

			if ( ! $this->ppTableExists( $customers_table ) || ! $this->ppTableExists( $subscriptions_table ) || ! $this->ppTableExists( $plans_table ) ) {
				return;
			}

			$customer_id = $this->ppGetCustomerIdByUserId( $user_id, $customers_table );
			if ( ! $customer_id ) {
				$customer_id = $this->ppEnsureCustomerRow( $user_id, $customers_table );
			}
			if ( ! $customer_id ) {
				return;
			}

			$plan_id = $this->ppGetPlanIdByName( $plan_name, $plans_table );
			if ( ! $plan_id ) {
				return;
			}

			$existing_subscription_id = $this->ppGetExistingSubscriptionId( $customer_id, $plan_id, $subscriptions_table );
			if ( $existing_subscription_id && $update_mode === 'skip' ) {
				return;
			}
			if ( $existing_subscription_id && $update_mode === 'append' ) {
				return;
			}

			$subscription_data = [
				'status'           => $status,
				'start_date'      => $start_sql,
				'expiration_date' => ( $end_sql !== '' ? $end_sql : null ),
				'billing_amount'  => $billing_amount,
			];

			$write_ok = false;
			if ( $existing_subscription_id ) {
				$write_ok = $this->ppUpdateSubscriptionRow( $existing_subscription_id, $subscription_data, $subscriptions_table );
			} else {
				$insert_data = $subscription_data + [
					'customer_id' => $customer_id,
					'plan_id'      => $plan_id,
					'created_at'  => current_time( 'mysql' ),
				];
				$write_ok = $this->ppInsertSubscriptionRow( $insert_data, $subscriptions_table );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	// =========================================================================
	// Subscription helpers
	// =========================================================================
	private function ppParseCsvDateToTimestamp( $raw ) {
		$raw = trim( (string) $raw );
		if ( $raw === '' ) {
			return false;
		}

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $raw ) ) {
			$ts = strtotime( $raw );
			return $ts !== false ? (int) $ts : false;
		}

		$d = \DateTimeImmutable::createFromFormat( 'n/j/Y', $raw );
		if ( $d instanceof \DateTimeImmutable ) {
			return (int) $d->getTimestamp();
		}

		$d = \DateTimeImmutable::createFromFormat( 'j/n/Y', $raw );
		if ( $d instanceof \DateTimeImmutable ) {
			return (int) $d->getTimestamp();
		}

		$ts = strtotime( $raw );
		return $ts !== false ? (int) $ts : false;
	}

	private function ppParseCsvDateToMysql( $raw ) {
		$raw = trim( (string) $raw );
		if ( $raw === '' ) {
			return '';
		}

		$ts = $this->ppParseCsvDateToTimestamp( $raw );
		if ( $ts === false ) {
			return '';
		}

		return date_i18n( 'Y-m-d H:i:s', $ts );
	}

	private function ppTableExists( $table ) {
		global $wpdb;
		$table = (string) $table;
		if ( $table === '' ) {
			return false;
		}
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	}

	/**
	 * @return int|null
	 */
	private function ppGetCustomerIdByUserId( $user_id, $customers_table ) {
		global $wpdb;

		$user_id = intval( $user_id );
		if ( $user_id <= 0 ) {
			return null;
		}
		if ( isset( self::$cache_customer_id_by_user[ $user_id ] ) ) {
			return intval( self::$cache_customer_id_by_user[ $user_id ] );
		}

		$cols = $this->ppGetColumns( $customers_table );
		if ( ! in_array( 'id', $cols, true ) || ! in_array( 'user_id', $cols, true ) ) {
			return null;
		}

		$customer_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$customers_table} WHERE user_id = %d LIMIT 1",
				$user_id
			)
		);

		if ( $customer_id ) {
			self::$cache_customer_id_by_user[ $user_id ] = intval( $customer_id );
			return intval( $customer_id );
		}
		return null;
	}

	/**
	 * @return int|null
	 */
	private function ppEnsureCustomerRow( $user_id, $customers_table ) {
		global $wpdb;

		$cols = $this->ppGetColumns( $customers_table );
		if ( ! in_array( 'user_id', $cols, true ) ) {
			return null;
		}

		$insert_data = [ 'user_id' => intval( $user_id ) ];
		$formats     = [ '%d' ];

		if ( in_array( 'created_at', $cols, true ) ) {
			$insert_data['created_at'] = current_time( 'mysql' );
			$formats[]                 = '%s';
		}

		$ok = $wpdb->insert( $customers_table, $insert_data, $formats );
		if ( ! $ok ) {
			return null;
		}

		$cid = $this->ppGetCustomerIdByUserId( $user_id, $customers_table );
		if ( $cid ) {
			self::$cache_customer_id_by_user[ intval( $user_id ) ] = intval( $cid );
		}
		return $cid;
	}

	/**
	 * @return int|null
	 */
	private function ppGetPlanIdByName( $plan_name, $plans_table ) {
		global $wpdb;

		$plan_name = trim( (string) $plan_name );
		if ( $plan_name === '' ) {
			return null;
		}
		$cache_key = strtolower( $plan_name );
		if ( isset( self::$cache_plan_id_by_name[ $cache_key ] ) ) {
			return intval( self::$cache_plan_id_by_name[ $cache_key ] );
		}

		$cols = $this->ppGetColumns( $plans_table );
		if ( ! in_array( 'id', $cols, true ) ) {
			return null;
		}

		// Try the task-required column name first, then fallbacks.
		$candidates = [];
		if ( in_array( 'name', $cols, true ) ) {
			$candidates[] = 'name';
		}
		if ( in_array( 'plan_name', $cols, true ) ) {
			$candidates[] = 'plan_name';
		}
		if ( in_array( 'title', $cols, true ) ) {
			$candidates[] = 'title';
		}

		foreach ( $candidates as $col ) {
			$plan_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$plans_table} WHERE {$col} = %s LIMIT 1",
					$plan_name
				)
			);
			if ( $plan_id ) {
				$pid = intval( $plan_id );
				self::$cache_plan_id_by_name[ $cache_key ] = $pid;
				self::$cache_plan_name_by_id[ $pid ]       = $plan_name;
				return $pid;
			}
		}

		return null;
	}

	/**
	 * @return int|null
	 */
	private function ppGetExistingSubscriptionId( $customer_id, $plan_id, $subscriptions_table ) {
		global $wpdb;

		$customer_id = intval( $customer_id );
		$plan_id     = intval( $plan_id );
		if ( $customer_id <= 0 || $plan_id <= 0 ) {
			return null;
		}

		$cols = $this->ppGetColumns( $subscriptions_table );
		if ( ! in_array( 'id', $cols, true ) || ! in_array( 'customer_id', $cols, true ) || ! in_array( 'plan_id', $cols, true ) ) {
			return null;
		}

		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$subscriptions_table} WHERE customer_id = %d AND plan_id = %d LIMIT 1",
				$customer_id,
				$plan_id
			)
		);

		return $existing_id ? intval( $existing_id ) : null;
	}

	private function ppUpdateSubscriptionRow( $subscription_id, $data, $subscriptions_table ) {
		global $wpdb;

		$subscription_id = intval( $subscription_id );
		if ( $subscription_id <= 0 ) {
			return false;
		}

		$cols = $this->ppGetColumns( $subscriptions_table );
		if ( ! in_array( 'id', $cols, true ) ) {
			return false;
		}

		$update = [];
		$format = [];
		foreach ( $data as $key => $val ) {
			if ( ! in_array( $key, $cols, true ) ) {
				continue;
			}
			$update[ $key ] = $val;
			if ( $val === null ) {
				$format[] = '%s';
			} elseif ( is_numeric( $val ) && $key === 'billing_amount' ) {
				$format[] = '%f';
			} else {
				$format[] = '%s';
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		return (bool) $wpdb->update(
			$subscriptions_table,
			$update,
			[ 'id' => $subscription_id ],
			$format,
			[ '%d' ]
		);
	}

	private function ppInsertSubscriptionRow( $data, $subscriptions_table ) {
		global $wpdb;

		$cols = $this->ppGetColumns( $subscriptions_table );
		if ( empty( $cols ) ) {
			return false;
		}

		$insert = [];
		$format = [];
		foreach ( $data as $key => $val ) {
			if ( ! in_array( $key, $cols, true ) ) {
				continue;
			}
			$insert[ $key ] = $val;
			if ( $val === null ) {
				$format[] = '%s';
			} elseif ( is_numeric( $val ) && $key === 'billing_amount' ) {
				$format[] = '%f';
			} elseif ( in_array( $key, [ 'customer_id', 'plan_id' ], true ) ) {
				$format[] = '%d';
			} else {
				$format[] = '%s';
			}
		}

		if ( empty( $insert ) ) {
			return false;
		}

		return (bool) $wpdb->insert( $subscriptions_table, $insert, $format );
	}

	/**
	 * @return array<int, string>
	 */
	private function ppGetColumns( $table ) {
		global $wpdb;

		$table = (string) $table;
		if ( $table === '' ) {
			return [];
		}

		if ( isset( self::$schema_cache[ $table ] ) ) {
			return self::$schema_cache[ $table ];
		}

		$columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $table );
		if ( ! is_array( $columns ) ) {
			$columns = [];
		}

		self::$schema_cache[ $table ] = $columns;
		return $columns;
	}

	// =========================================================================
	// Helper: Check if field is in ProfilePress forms whitelist (ignore unknown CSV columns)
	// =========================================================================
	private function isAllowedProfilePressField( $meta_key ) {
		global $wpdb;
		$formsmeta_table = $wpdb->prefix . 'ppress_formsmeta';
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $formsmeta_table ) ) ) {
			return false;
		}
		$exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$formsmeta_table} WHERE meta_key = 'field_key' AND meta_value = %s LIMIT 1",
				$meta_key
			)
		);
		return (bool) $exists;
	}

	// =========================================================================
	// Helper: Insert or update wp_ppress_customers row
	// =========================================================================
	private function upsertCustomerRow( $user_id, $data ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ppress_customers';
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return;
		}

		$existing_id = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$table} WHERE user_id = %d LIMIT 1", $user_id )
		);

		// Type casting for numeric columns; if empty, ensure row exists for ProfilePress visibility
		$format = [];
		$values = [];

		if ( ! empty( $data ) ) {
			foreach ( $data as $col => $val ) {
				$values[ $col ] = $val;
				$format[]       = in_array( $col, [ 'total_spend', 'purchase_count' ], true ) ? '%f' : '%s';
			}
		}

		if ( $existing_id ) {
			if ( ! empty( $values ) ) {
				$wpdb->update( $table, $values, [ 'user_id' => $user_id ], $format, [ '%d' ] );
			}
		} else {
			$values['user_id'] = $user_id;
			$format[]          = '%d';
			// Ensure defaults for ProfilePress customer table
			foreach ( self::CUSTOMER_TABLE_FIELDS as $col ) {
				if ( ! isset( $values[ $col ] ) ) {
					$values[ $col ] = in_array( $col, [ 'total_spend', 'purchase_count' ], true ) ? 0 : '';
					$format[]       = in_array( $col, [ 'total_spend', 'purchase_count' ], true ) ? '%f' : '%s';
				}
			}
			$wpdb->insert( $table, $values, $format );
		}
	}

	// =========================================================================
	// Normalization helpers (dynamic + safe meta keys)
	// =========================================================================
	/**
	 * Normalize a CSV header / key into a safe meta key.
	 * Matches task requirement: lower + replace space, /, - with underscore.
	 *
	 * @param string $key
	 * @return string
	 */
	private function normalize_key( $key ) {
		$key = strtolower( (string) $key );
		$key = str_replace( [ ' ', '/', '-' ], '_', $key );
		$key = trim( $key );
		// Keep only characters safe for WP meta keys (fallback).
		$key = preg_replace( '/[^a-z0-9_\-]/', '', $key );
		return (string) $key;
	}

	/**
	 * Convert date string into Y-m-d.
	 *
	 * @param string $date
	 * @return string|null
	 */
	private function convert_date( $date ) {
		$date = trim( (string) $date );
		if ( $date === '' ) {
			return null;
		}
		$ts = strtotime( $date );
		if ( $ts === false ) {
			return null;
		}
		return date( 'Y-m-d', $ts );
	}

	// =========================================================================
	// FIELD LIST for import mapping UI
	// =========================================================================
	public function processExtension( $import_type, $process_type = null ) {
		$response = [];

		$pp_active     = is_plugin_active( 'profilepress/profilepress.php' );
		$avatar_active = is_plugin_active( 'wp-user-avatar/wp-user-avatar.php' );

		if ( $import_type === 'PPRESS_MEMBERSHIP_PLAN' || $import_type === 'PPRESS_ORDER' ) {
			if ( ! self::is_profilepress_plugin_active() ) {
				return $response;
			}
			return $this->build_ppress_table_mapping_fields( $import_type );
		}

		if ( ! $pp_active && ! $avatar_active ) {
			return $response;
		}

		// Core WP users table fields — always shown first
		$mapping_array = [
			[ 'label' => 'Email',        'name' => 'user_email' ],
			[ 'label' => 'Username',     'name' => 'user_login' ],
			[ 'label' => 'Display Name', 'name' => 'display_name' ],
			[ 'label' => 'First Name',   'name' => 'first_name' ],
			[ 'label' => 'Last Name',    'name' => 'last_name' ],
			[ 'label' => 'Nickname',     'name' => 'nickname' ],
			[ 'label' => 'Description',  'name' => 'description' ],
			[ 'label' => 'Website URL',  'name' => 'user_url' ],
		];

		global $wpdb;

		// Dynamic pp_* / ppress_* meta keys
		$pp_meta_keys = $wpdb->get_col(
			"SELECT DISTINCT meta_key
			 FROM {$wpdb->usermeta}
			 WHERE meta_key LIKE 'pp_%'
			    OR meta_key LIKE 'ppress_%'
			 ORDER BY meta_key ASC"
		);

		$seen = [];
		// Ensure subscription meta fields are available even if they don't exist in DB yet.
		foreach ( self::SUBSCRIPTION_META_KEYS as $sub_meta_key ) {
			if ( ! isset( $seen[ $sub_meta_key ] ) ) {
				$seen[ $sub_meta_key ] = true;
				$label                 = str_replace( 'pp_', '', $sub_meta_key );
				$mapping_array[]       = [
					'label' => ucwords( str_replace( '_', ' ', $label ) ),
					'name'  => $sub_meta_key,
				];
			}
		}
		// Export/mapping field for subscription status is derived from ProfilePress subscription records.
		if ( ! isset( $seen['subscription_status'] ) ) {
			$seen['subscription_status'] = true;
			$mapping_array[]              = [
				'label' => 'Subscription Status',
				'name'  => 'subscription_status',
			];
		}
		foreach ( $pp_meta_keys as $key ) {
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;

			if ( $key === self::UPLOADED_FILES_KEY ) {
				// Expose flattened sub-keys from existing DB data
				$sample = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT meta_value FROM {$wpdb->usermeta}
						 WHERE meta_key = %s AND meta_value != '' LIMIT 5",
						$key
					)
				);
				foreach ( $sample as $serialized ) {
					$arr = @unserialize( $serialized );
					if ( is_array( $arr ) ) {
						foreach ( array_keys( $arr ) as $subkey ) {
							$flat_key = self::UPLOADED_FILES_KEY . '_' . $subkey;
							if ( ! isset( $seen[ $flat_key ] ) ) {
								$seen[ $flat_key ]  = true;
								$mapping_array[] = [
									'label' => 'Uploaded File: ' . ucwords( str_replace( '_', ' ', $subkey ) ),
									'name'  => $flat_key,
								];
							}
						}
					}
				}
				continue;
			}

			$label           = preg_replace( '/^(pp_|ppress_)/', '', $key );
			$label           = ucwords( str_replace( '_', ' ', $label ) );
			$mapping_array[] = [ 'label' => $label, 'name' => $key ];
		}

		// Dynamic fields from wp_ppress_formsmeta
		$formsmeta_table = $wpdb->prefix . 'ppress_formsmeta';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $formsmeta_table ) ) ) {
			$form_fields = $wpdb->get_col(
				"SELECT DISTINCT meta_value
				 FROM {$formsmeta_table}
				 WHERE meta_key = 'field_key'
				   AND meta_value != ''
				 ORDER BY meta_value ASC"
			);
			foreach ( $form_fields as $fk ) {
				if ( ! isset( $seen[ $fk ] ) ) {
					$seen[ $fk ]     = true;
					$mapping_array[] = [
						'label' => ucwords( str_replace( '_', ' ', $fk ) ),
						'name'  => $fk,
					];
				}
			}
		}

		// wp_ppress_customers columns
		foreach ( self::CUSTOMER_TABLE_FIELDS as $col ) {
			if ( ! isset( $seen[ $col ] ) ) {
				$seen[ $col ]    = true;
				$mapping_array[] = [
					'label' => ucwords( str_replace( '_', ' ', $col ) ),
					'name'  => $col,
				];
			}
		}

		$response['profilepress_fields'] = $mapping_array;
		return $response;
	}

	// =========================================================================
	// extensionSupportedImportType — unchanged
	// =========================================================================
	public function extensionSupportedImportType( $import_type ) {
		$pp_active     = is_plugin_active( 'profilepress/profilepress.php' );
		$avatar_active = is_plugin_active( 'wp-user-avatar/wp-user-avatar.php' );

		if ( $import_type === 'PPRESS_MEMBERSHIP_PLAN' || $import_type === 'PPRESS_ORDER' ) {
			if ( ! self::is_profilepress_plugin_active() ) {
				return false;
			}
			return $import_type === 'PPRESS_MEMBERSHIP_PLAN' ? 'ppress_membership_plan_fields' : 'ppress_order_fields';
		}

		if ( ! $pp_active && ! $avatar_active ) {
			return false;
		}

		$supported_types = [ 'PROFILEPRESS', 'ProfilePress Users', 'Users' ];

		if ( in_array( $import_type, $supported_types, true ) ) {
			return 'profilepress_fields';
		}

		return false;
	}

	/**
	 * Mapping fields for ProfilePress custom DB tables (export + import UI).
	 *
	 * @param string $import_type PPRESS_MEMBERSHIP_PLAN|PPRESS_ORDER
	 * @return array
	 */
	private function build_ppress_table_mapping_fields( $import_type ) {
		global $wpdb;

		$table_suffix = ( $import_type === 'PPRESS_MEMBERSHIP_PLAN' ) ? 'ppress_plans' : 'ppress_orders';
		$result_key   = ( $import_type === 'PPRESS_MEMBERSHIP_PLAN' ) ? 'ppress_membership_plan_fields' : 'ppress_order_fields';
		$table        = $wpdb->prefix . $table_suffix;

		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return [ $result_key => [] ];
		}

		$cols = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}`" );
		$assoc = [];
		if ( is_array( $cols ) ) {
			foreach ( $cols as $col ) {
				if ( ! isset( $col->Field ) ) {
					continue;
				}
				$fn             = (string) $col->Field;
				$assoc[ ucwords( str_replace( '_', ' ', $fn ) ) ] = $fn;
			}
		}

		if ( $import_type === 'PPRESS_MEMBERSHIP_PLAN' ) {
			$assoc['Plan Id'] = 'plan_id';
		} else {
			$assoc['Order Id'] = 'order_id';
		}

		return [ $result_key => $this->convert_static_fields_to_array( $assoc ) ];
	}
}