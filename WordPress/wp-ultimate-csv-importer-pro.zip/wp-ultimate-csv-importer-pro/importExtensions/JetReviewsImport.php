<?php

/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\WCSV;

if (! defined('ABSPATH'))
    exit; // Exit if accessed directly

class JetReviewsImport
{

    private static $instance = null, $media_instance;

    public static function getInstance()
    {
        if (JetReviewsImport::$instance == null) {
            JetReviewsImport::$instance = new JetReviewsImport;
            JetReviewsImport::$media_instance = MediaHandling::getInstance();
        }
        return JetReviewsImport::$instance;
    }
    function set_jet_reviews_values($header_array, $value_array, $map, $post_id, $type, $mode, $hash_key, $line_number, $gmode, $templatekey)
    {
        $post_values = [];
        $helpers_instance = ImportHelpers::getInstance();
        $post_values = $helpers_instance->get_header_values($map, $header_array, $value_array);
        $this->jet_reviews_import_function($post_values, $type, $post_id, $mode, $hash_key, $line_number, $header_array, $value_array, $gmode, $templatekey);
    }

    public function jet_reviews_import_function($data_array, $type, $post_id, $mode, $hash_key, $line_number, $header_array, $value_array, $gmode, $templatekey)
    {
        global $wpdb;
        $helpers_instance = ImportHelpers::getInstance();
        $plugin = 'jetengine-reviews';
        $media_instance = MediaHandling::getInstance();
        $darray = array();
        $listTaxonomy = get_taxonomies();
        if (in_array($type, $listTaxonomy)) {
            $get_import_type = 'term';
        } elseif ($type == 'Users' || $type == 'user') {
            $get_import_type = 'user';
        } elseif ($type == 'Comments') {
            $get_import_type = 'comment';
        } else {
            $get_import_type = 'post';
        }
        foreach ($data_array as $dkey => $dvalue) {

            $dvalue = trim($dvalue);

            if ($dkey == 'jet-review-title') {
                update_post_meta($post_id, $dkey, $dvalue);
            } else if ($dkey == 'jet-review-items') {
                $items = explode(',', $dvalue);
                $data = [];
                foreach ($items as $index => $item) {
                    // Split each item by '|' to get the label, value, and max
                    list($field_label, $field_value, $field_max) = explode('|', $item);

                    $data["item-$index"] = [
                        'field_label' => $field_label,
                        'field_value' => $field_value,
                        'field_max' => $field_max
                    ];
                }
                update_post_meta($post_id, $dkey, $data);
            } 
            else if($dkey == 'jet-review-data-image'){
                if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $dvalue ) ) {
                    $media_instance->store_image_ids($i=1);
                    $attach_id = $media_instance->image_meta_table_entry($line_number,$data_array, $post_id, $dkey,$dvalue, $hash_key, $plugin,$get_import_type,$templatekey,$gmode,$header_array, $value_array,'','','');
                }
                else if(is_numeric($dvalue)){
                    $attach_id = $dvalue;
                }
                update_post_meta($post_id, $dkey, $attach_id);

            }
            else {
                update_post_meta($post_id, $dkey, $dvalue);
            }
        }
    }
}
