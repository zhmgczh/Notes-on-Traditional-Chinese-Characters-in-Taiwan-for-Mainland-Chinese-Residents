<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/
namespace Smackcoders\WCSV;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
// Include Composer autoloader
require_once __DIR__ . '/../vendor/autoload.php'; 

// Use statements for Google API classes
use Google_Client;
use Google_Service_Sheets;
use Google_Service_Sheets_ValueRange;
use Google_Service_Sheets_Spreadsheet; // Add this line to import Google_Service_Sheets_Spreadsheet

class GoogleSheetsExporter {
    private $client_id;
    private $client_secret;
    private $redirect_uri;
    private $access_token;

    public function __construct() {
        // Hook into the AJAX action
        add_action('wp_ajax_export_to_gsheet', [$this, 'handle_export_to_gsheet']);

    }

    // Load Google credentials from the WordPress options table
    public function load_google_credentials() {
        $credentials = maybe_unserialize(get_option('google_sheet_credentials'));
        if ($credentials) {
            $this->client_id = $credentials['client_id'];
            $this->client_secret = $credentials['client_secret'];
            $this->redirect_uri = $credentials['redirect_uri'];
            $this->access_token = $credentials['access_token']; // Fetch stored access token
        } else {
            wp_die('Error: Google credentials not found.');
        }
    }

    public function handle_export_to_gsheet() {
        check_ajax_referer('smack-ultimate-csv-importer-pro', 'securekey');

        // Check for valid nonce
        if (!isset($_POST['securekey']) || !wp_verify_nonce($_POST['securekey'], 'smack-ultimate-csv-importer-pro')) {
            wp_send_json_error(['message' => 'Invalid security token']);
            return;
        }
        $this->load_google_credentials(); // Load credentials on construct

        // Get the CSV file path and other parameters
        $file_name = sanitize_text_field($_POST['fileName']);
        // Check if the file name already contains '.csv', if not, append it
           if (pathinfo($file_name, PATHINFO_EXTENSION) !== 'csv') {
           $file_name .= '.csv';
}

        $csv_file_path = WP_CONTENT_DIR . "/uploads/smack_uci_uploads/exports/" . $file_name;
        if (!file_exists($csv_file_path)) {
            wp_send_json_error(['message' => 'CSV file not found']);
            return;
        }

        // Now, upload the CSV to Google Sheets
        $gsheet_url = $this->upload_csv_to_gsheet($csv_file_path);
        if ($gsheet_url) {
            wp_send_json_success(['gsheet_url' => $gsheet_url]);
        } else {
            wp_send_json_error(['message' => 'Failed to upload to Google Sheets', 'details' => 'Check your credentials or try again later.']);
        }
    }

    public function upload_csv_to_gsheet($csv_file_path) {
        // Set up Google API client using stored credentials
        $client = new Google_Client();
        $client->setApplicationName('Google Sheets API Export');
        $client->setScopes([Google_Service_Sheets::SPREADSHEETS]);
    
        // Load credentials from WordPress options table
        $credentials = maybe_unserialize(get_option('google_sheet_credentials'));
        if (!$credentials) {
            wp_die('Error: Google Sheets credentials are not available.');
        }
    
        // Set client ID and secret
        $client->setClientId($credentials['client_id']);
        $client->setClientSecret($credentials['client_secret']);
    
        // Check and refresh access token if necessary
        $access_token = $this->checkAndRefreshToken($credentials);
        $client->setAccessToken($access_token);
    
        // Create a Google Sheets service instance
        $service = new Google_Service_Sheets($client);
    
        // Create a new Google Sheet
        $spreadsheet = new Google_Service_Sheets_Spreadsheet([
            'properties' => [
                'title' => 'Exported CSV Data'
            ]
        ]);
    
        // Create the spreadsheet and get its ID
        try {
            $spreadsheet = $service->spreadsheets->create($spreadsheet, [
                'fields' => 'spreadsheetId'
            ]);
            $spreadsheetId = $spreadsheet->spreadsheetId;
        } catch (Exception $e) {
            wp_die('Error creating spreadsheet: ' . $e->getMessage());
        }
    
        // Read CSV file and convert it into an array for Google Sheets
        $csv_data = array_map('str_getcsv', file($csv_file_path));
    
        // Ensure that CSV data is valid and has rows
        if (empty($csv_data)) {
            wp_die('Error: CSV file is empty or not properly formatted.');
        }
    
        // Prepare the request to insert data into the Google Sheet
        $body = new Google_Service_Sheets_ValueRange([
            'values' => $csv_data
        ]);
    
        // Set parameters for data insertion
        $params = [
            'valueInputOption' => 'RAW'
        ];
    
        // Upload CSV data to the first sheet of the spreadsheet
        try {
            $service->spreadsheets_values->update($spreadsheetId, 'A1', $body, $params);
            
            // Return the Google Sheets URL
            return "https://docs.google.com/spreadsheets/d/{$spreadsheetId}/edit";
            
        } catch (Exception $e) {
            wp_die('Error uploading data to Google Sheets: ' . $e->getMessage());
        }
    }
    
    private function checkAndRefreshToken($credentials) {
        // Create a new Google Client
        $client = new Google_Client();
        $client->setClientId($credentials['client_id']);
        $client->setClientSecret($credentials['client_secret']);
    
        // Set the access token
        $client->setAccessToken($credentials['access_token']);
    
        // Check if the access token is expired
        if ($client->isAccessTokenExpired()) {
            $refreshToken = $credentials['refresh_token'];
            if ($refreshToken) {
                $client->fetchAccessTokenWithRefreshToken($refreshToken);
                // Get new access token
                $new_access_token = $client->getAccessToken();
                // Update credentials in WordPress options
                $credentials['access_token'] = $new_access_token['access_token'];
                $credentials['expires_at'] = time() + $new_access_token['expires_in'];
                update_option('google_sheet_credentials', maybe_serialize($credentials));
            } else {
                wp_die('Error: Refresh token is missing.');
            }
        }
    
        // Return the valid access token
        return $client->getAccessToken()['access_token'];
    }
    
}
// Instantiate the class
new GoogleSheetsExporter();
